"""Vulnerability detection and service fingerprinting database."""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
import re

# Service-to-vulnerability mappings
VULNERABILITY_DATABASE = {
    # SSH
    22: {
        "service": "SSH",
        "common_versions": ["OpenSSH 2.x", "OpenSSH 3.x", "OpenSSH 4.x", "OpenSSH 5.x", "OpenSSH 6.x", "OpenSSH 7.x", "OpenSSH 8.x"],
        "vulnerabilities": {
            "OpenSSH 2.0-2.3": ["SSH1 weak cryptography", "Integer overflow"],
            "OpenSSH 5.3-5.8": ["CBC padding oracle"],
            "OpenSSH 6.0-6.5": ["GHOST (glibc) vulnerability when using gssapi-with-mic"],
            "OpenSSH 7.4-7.10": ["Unauthenticated integer overflow"],
        },
        "risk_level": "HIGH",
        "notes": "SSH key exchange should support strong algorithms. Check for outdated protocol versions.",
    },
    
    # HTTP
    80: {
        "service": "HTTP",
        "common_versions": ["Apache 1.x", "Apache 2.x", "nginx 1.x", "nginx 1.x", "IIS 5.0-10.0"],
        "vulnerabilities": {},
        "risk_level": "HIGH",
        "notes": "Unencrypted HTTP is vulnerable to MITM attacks. Use HTTPS (443) instead.",
    },
    
    # HTTPS
    443: {
        "service": "HTTPS",
        "common_versions": ["Apache 2.x", "nginx 1.x", "IIS 5.0-10.0"],
        "vulnerabilities": {},
        "risk_level": "MEDIUM",
        "notes": "Check SSL/TLS version and cipher strength. Look for self-signed certificates.",
    },
    
    # SMTP
    25: {
        "service": "SMTP",
        "common_versions": ["Postfix", "Sendmail", "Exim"],
        "vulnerabilities": {
            "Sendmail < 8.12.9": ["Remote code execution vulnerability (CAN-2003-0161)"],
        },
        "risk_level": "HIGH",
        "notes": "SMTP can be used for spam. Check for open relay configuration.",
    },
    
    # FTP
    21: {
        "service": "FTP",
        "common_versions": ["vsftpd", "wu-ftpd", "ProFTPD"],
        "vulnerabilities": {
            "wu-ftpd < 2.6.0": ["Remote code execution"],
            "vsftpd 2.3.4": ["Backdoor - executes shell on port 6200"],
        },
        "risk_level": "CRITICAL",
        "notes": "FTP sends credentials in plain text. Use SFTP or FTPS instead.",
    },
    
    # DNS
    53: {
        "service": "DNS",
        "common_versions": ["BIND 9.x", "dnsmasq", "Unbound"],
        "vulnerabilities": {
            "BIND 9.1.0-9.9.13": ["DNS response rate limiting bypass"],
        },
        "risk_level": "HIGH",
        "notes": "DNS can be used for amplification attacks. Ensure proper access controls.",
    },
    
    # POP3
    110: {
        "service": "POP3",
        "common_versions": ["Courier POP3", "Dovecot"],
        "vulnerabilities": {},
        "risk_level": "HIGH",
        "notes": "POP3 sends credentials in plain text. Use POP3S instead.",
    },
    
    # RPC
    111: {
        "service": "RPC",
        "common_versions": ["SunRPC"],
        "vulnerabilities": {},
        "risk_level": "HIGH",
        "notes": "RPC services can be exploited. Restrict access to trusted networks.",
    },
    
    # IMAP
    143: {
        "service": "IMAP",
        "common_versions": ["Dovecot", "Courier", "Cyrus"],
        "vulnerabilities": {},
        "risk_level": "HIGH",
        "notes": "IMAP sends credentials in plain text. Use IMAPS instead.",
    },
    
    # LDAP
    389: {
        "service": "LDAP",
        "common_versions": ["OpenLDAP", "Active Directory"],
        "vulnerabilities": {},
        "risk_level": "HIGH",
        "notes": "LDAP can be used for directory enumeration. Ensure proper access controls.",
    },
    
    # HTTPS Alt
    8443: {
        "service": "HTTPS (Alt)",
        "common_versions": ["Apache 2.x", "nginx 1.x"],
        "vulnerabilities": {},
        "risk_level": "MEDIUM",
        "notes": "Alternative HTTPS port. Check SSL/TLS configuration.",
    },
    
    # MySQL
    3306: {
        "service": "MySQL",
        "common_versions": ["MySQL 5.x", "MySQL 8.x", "MariaDB"],
        "vulnerabilities": {},
        "risk_level": "CRITICAL",
        "notes": "Database service should not be exposed. Restrict access and use strong passwords.",
    },
    
    # MSSQL
    1433: {
        "service": "MSSQL",
        "common_versions": ["MSSQL 2008-2019"],
        "vulnerabilities": {},
        "risk_level": "CRITICAL",
        "notes": "Database service should not be exposed. Enable encryption and strong authentication.",
    },
    
    # Oracle DB
    1521: {
        "service": "Oracle Database",
        "common_versions": ["Oracle 10g-21c"],
        "vulnerabilities": {},
        "risk_level": "CRITICAL",
        "notes": "Database service should not be exposed. Restrict network access.",
    },
    
    # PostgreSQL
    5432: {
        "service": "PostgreSQL",
        "common_versions": ["PostgreSQL 9.x-14.x"],
        "vulnerabilities": {},
        "risk_level": "CRITICAL",
        "notes": "Database service should not be exposed. Use strong authentication.",
    },
    
    # RDP
    3389: {
        "service": "RDP",
        "common_versions": ["Windows RDP 5.0-10.0"],
        "vulnerabilities": {},
        "risk_level": "CRITICAL",
        "notes": "RDP is frequently attacked. Use NLA, strong passwords, and restrict access.",
    },
    
    # VNC
    5900: {
        "service": "VNC",
        "common_versions": ["TightVNC", "RealVNC", "UltraVNC"],
        "vulnerabilities": {},
        "risk_level": "CRITICAL",
        "notes": "VNC can expose desktop. Use strong encryption and authentication.",
    },
}

# Banner regex patterns for service detection
BANNER_PATTERNS = {
    "SSH": r"SSH-([0-9.]+)-(.+)",
    "FTP": r"220\s+(.+?)(?:FTP|Server)",
    "SMTP": r"220\s+(.+?)\s+SMTP",
    "HTTP": r"(?:HTTP/|Server:)\s*(.+)",
    "MySQL": r"MySQL\s+([0-9.]+)",
    "PostgreSQL": r"PostgreSQL\s+([0-9.]+)",
    "SMTP": r"ESMTP\s+(.+)",
}

SERVICE_RISK_LEVELS = {
    "CRITICAL": 4,
    "HIGH": 3,
    "MEDIUM": 2,
    "LOW": 1,
    "INFO": 0,
}


def get_vulnerability_info(port: int) -> Optional[Dict]:
    """Get vulnerability information for a specific port."""
    return VULNERABILITY_DATABASE.get(port)


def extract_service_version_from_banner(banner: str) -> Tuple[str, Optional[str]]:
    """Extract service name and version from banner."""
    for service, pattern in BANNER_PATTERNS.items():
        match = re.search(pattern, banner, re.IGNORECASE)
        if match:
            version = match.group(1) if match.groups() else None
            return service, version
    return "Unknown", None


def check_vulnerable_version(service: str, version: str) -> List[str]:
    """Check if a service version is vulnerable."""
    vulnerabilities = []
    for port_info in VULNERABILITY_DATABASE.values():
        if port_info.get("service") == service:
            vulns = port_info.get("vulnerabilities", {})
            for vuln_version, issues in vulns.items():
                if version.lower() in vuln_version.lower() or vuln_version.lower() in version.lower():
                    vulnerabilities.extend(issues)
    return vulnerabilities


def get_risk_score(port: int, is_open: bool = True) -> int:
    """Calculate risk score for a port (0-10 scale)."""
    if not is_open:
        return 0
    
    vuln_info = get_vulnerability_info(port)
    if not vuln_info:
        return 2  # Unknown service = low risk
    
    risk_level = vuln_info.get("risk_level", "INFO")
    return SERVICE_RISK_LEVELS.get(risk_level, 1) * 2.5


def generate_risk_report(ports_dict: Dict[int, bool]) -> Dict:
    """Generate a risk assessment report."""
    total_risk = 0
    critical_ports = []
    high_risk_ports = []
    
    for port, is_open in ports_dict.items():
        if is_open:
            risk = get_risk_score(port, True)
            total_risk += risk
            
            vuln_info = get_vulnerability_info(port)
            if vuln_info:
                risk_level = vuln_info.get("risk_level")
                if risk_level == "CRITICAL":
                    critical_ports.append((port, vuln_info.get("service")))
                elif risk_level == "HIGH":
                    high_risk_ports.append((port, vuln_info.get("service")))
    
    overall_risk = min(10, int(total_risk / max(1, len([p for p, o in ports_dict.items() if o]))))
    
    return {
        "overall_risk_score": overall_risk,
        "critical_ports": critical_ports,
        "high_risk_ports": high_risk_ports,
        "risk_assessment": "CRITICAL" if overall_risk >= 8 else "HIGH" if overall_risk >= 6 else "MEDIUM" if overall_risk >= 4 else "LOW",
    }
