import re
from typing import Dict, Tuple

COMMON_SERVICES = {
    20: "ftp-data", 21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp",
    53: "dns", 67: "dhcp", 68: "dhcp", 69: "tftp", 80: "http",
    110: "pop3", 111: "rpcbind", 119: "nntp", 123: "ntp", 135: "msrpc",
    137: "netbios", 138: "netbios", 139: "netbios-ssn", 143: "imap",
    161: "snmp", 162: "snmp-trap", 179: "bgp", 194: "irc", 389: "ldap",
    443: "https", 445: "microsoft-ds", 465: "smtps", 500: "isakmp",
    514: "syslog", 515: "printer", 587: "submission", 631: "ipp",
    636: "ldaps", 993: "imaps", 995: "pop3s", 1080: "socks",
    1194: "openvpn", 1433: "mssql", 1521: "oracle", 1723: "pptp",
    2049: "nfs", 2181: "zookeeper", 2375: "docker", 2376: "docker-ssl",
    3000: "http-dev", 3306: "mysql", 3389: "rdp", 3690: "svn",
    4444: "metasploit", 4848: "glassfish", 5000: "upnp", 5432: "postgresql",
    5900: "vnc", 5985: "winrm", 6379: "redis", 6443: "kubernetes",
    7001: "weblogic", 8000: "http-alt", 8008: "http-alt", 8080: "http-proxy",
    8443: "https-alt", 8888: "jupyter", 9000: "php-fpm", 9090: "prometheus",
    9200: "elasticsearch", 9300: "elasticsearch", 10250: "kubelet", 11211: "memcached",
    15672: "rabbitmq", 27017: "mongodb", 27018: "mongodb", 50000: "db2",
}

TITLE_RE = re.compile(r"<title>([^<]+)</title>", re.IGNORECASE)
HEADER_RE = re.compile(r"^([^:]+):\s*(.*)$")


def parse_http_response(banner: str) -> Dict[str, str]:
    details = {}
    if not banner:
        return details
    lines = banner.splitlines()
    if lines and lines[0].startswith("HTTP/"):
        details["status_line"] = lines[0].strip()
        for line in lines[1:]:
            if not line.strip():
                continue
            match = HEADER_RE.match(line)
            if match:
                key = match.group(1).lower().replace("-", "_")
                details[key] = match.group(2).strip()
        title_match = TITLE_RE.search(banner)
        if title_match:
            details["http_title"] = title_match.group(1).strip()
    return details


def parse_ssh_banner(banner: str) -> Dict[str, str]:
    details = {}
    if banner.startswith("SSH-"):
        parts = banner.split(" ", 1)
        details["ssh_banner"] = parts[0]
        if len(parts) > 1:
            details["ssh_version_info"] = parts[1].strip()
    return details


def identify_service(port: int, protocol: str, banner: str, metadata: Dict[str, str]) -> Tuple[str, Dict[str, str]]:
    service_name = COMMON_SERVICES.get(port, "")
    details = dict(metadata)

    banner = banner or ""
    if banner.startswith("SSH-"):
        service_name = service_name or "ssh"
        details.update(parse_ssh_banner(banner))
    elif banner.startswith("HTTP/") or "HTTP/" in banner:
        service_name = service_name or "http"
        details.update(parse_http_response(banner))
    elif "smtp" in banner.lower():
        service_name = service_name or "smtp"
    elif "ftp" in banner.lower():
        service_name = service_name or "ftp"
    elif "imap" in banner.lower():
        service_name = service_name or "imap"
    elif "pop3" in banner.lower():
        service_name = service_name or "pop3"

    if not service_name and details.get("server"):
        service_name = details.get("server")
    return service_name or "unknown", details
