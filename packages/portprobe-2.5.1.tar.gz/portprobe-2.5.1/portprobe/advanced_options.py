"""Advanced scanning options and techniques."""

from enum import Enum
from dataclasses import dataclass
from typing import List, Optional, Dict


class ScanTechnique(Enum):
    """Advanced scanning techniques."""
    SYN = "syn"              # SYN stealth scan
    FIN = "fin"              # FIN scan
    NULL = "null"            # NULL scan
    XMAS = "xmas"            # XMAS scan
    ACK = "ack"              # ACK scan
    UDP = "udp"              # UDP scan
    CONNECT = "connect"      # Full TCP connect
    IDLE = "idle"            # Idle/Zombie scan
    AGGRESSIVE = "aggressive" # Aggressive scan


class ScanProfile(Enum):
    """Predefined scan profiles."""
    STEALTH = "stealth"          # Slow, stealthy scan
    AGGRESSIVE = "aggressive"    # Fast, aggressive scan
    NORMAL = "normal"            # Balanced scan
    INTENSE = "intense"          # Very thorough scan
    QUICK = "quick"              # Quick scan of top ports
    VULN_CHECK = "vuln_check"   # Vulnerability assessment


@dataclass
class ScanOptions:
    """Advanced scanning options."""
    technique: ScanTechnique = ScanTechnique.CONNECT
    profile: ScanProfile = ScanProfile.NORMAL
    timeout: float = 2.0
    retries: int = 2
    aggressive: bool = False
    randomize_ports: bool = False
    spoof_mac: Optional[str] = None
    fragment_packets: bool = False
    decoy_ips: Optional[List[str]] = None
    user_agent: Optional[str] = None
    proxy_chain: Optional[List[str]] = None
    use_dns_cache: bool = True
    skip_ping: bool = False
    os_detection: bool = False
    service_detection: bool = True
    script_scanning: bool = False
    version_detection: bool = True
    vulnerability_scan: bool = False
    enum_users: bool = False
    enum_shares: bool = False
    
    def get_port_list_for_profile(self) -> str:
        """Get recommended ports for scan profile."""
        port_map = {
            ScanProfile.QUICK: "top20",
            ScanProfile.STEALTH: "top100",
            ScanProfile.NORMAL: "top1000",
            ScanProfile.INTENSE: "all",
            ScanProfile.AGGRESSIVE: "top1000",
            ScanProfile.VULN_CHECK: "top100,135,139,445,3306,5432,6379,27017",
        }
        return port_map.get(self.profile, "top100")
    
    def get_timeout_for_profile(self) -> float:
        """Get recommended timeout for scan profile."""
        timeout_map = {
            ScanProfile.QUICK: 0.5,
            ScanProfile.STEALTH: 5.0,
            ScanProfile.NORMAL: 2.0,
            ScanProfile.INTENSE: 3.0,
            ScanProfile.AGGRESSIVE: 1.0,
            ScanProfile.VULN_CHECK: 2.5,
        }
        return timeout_map.get(self.profile, self.timeout)
    
    def get_thread_count_for_profile(self) -> int:
        """Get recommended thread count for scan profile."""
        thread_map = {
            ScanProfile.QUICK: 100,
            ScanProfile.STEALTH: 5,
            ScanProfile.NORMAL: 50,
            ScanProfile.INTENSE: 100,
            ScanProfile.AGGRESSIVE: 200,
            ScanProfile.VULN_CHECK: 50,
        }
        return thread_map.get(self.profile, 50)


# Exploit database for common services
EXPLOIT_DATABASE = {
    "SSH": [
        {
            "name": "SSH Brute Force",
            "severity": "HIGH",
            "cve": "N/A",
            "description": "Attempt to brute-force SSH credentials",
        },
        {
            "name": "OpenSSH 7.4 - 7.10 Unauthenticated Integer Overflow",
            "severity": "CRITICAL",
            "cve": "CVE-2018-15473",
            "description": "Information disclosure through version scanning",
        },
    ],
    "HTTP": [
        {
            "name": "HTTP Methods",
            "severity": "MEDIUM",
            "cve": "N/A",
            "description": "Dangerous HTTP methods enabled (PUT, DELETE)",
        },
        {
            "name": "Directory Traversal",
            "severity": "HIGH",
            "cve": "N/A",
            "description": "Potential path traversal vulnerabilities",
        },
    ],
    "FTP": [
        {
            "name": "Anonymous FTP Access",
            "severity": "HIGH",
            "cve": "N/A",
            "description": "FTP service allows anonymous logins",
        },
        {
            "name": "FTP Bounce Attack",
            "severity": "HIGH",
            "cve": "N/A",
            "description": "FTP server can be used for port scanning",
        },
    ],
    "SMB": [
        {
            "name": "SMB Null Session",
            "severity": "HIGH",
            "cve": "N/A",
            "description": "NULL session allows anonymous enumeration",
        },
        {
            "name": "Eternal Blue",
            "severity": "CRITICAL",
            "cve": "CVE-2017-0144",
            "description": "Remote code execution in SMB",
        },
    ],
}


def get_exploit_info(service: str) -> List[Dict]:
    """Get known exploits for a service."""
    return EXPLOIT_DATABASE.get(service, [])


def get_scan_profile_description(profile: ScanProfile) -> str:
    """Get description for a scan profile."""
    descriptions = {
        ScanProfile.STEALTH: "Slow, stealthy scan to avoid detection (IDS evasion)",
        ScanProfile.AGGRESSIVE: "Fast, aggressive scan with maximum threads",
        ScanProfile.NORMAL: "Standard balanced scan",
        ScanProfile.INTENSE: "Thorough scan of all ports with version detection",
        ScanProfile.QUICK: "Quick scan of common ports",
        ScanProfile.VULN_CHECK: "Vulnerability assessment focused scan",
    }
    return descriptions.get(profile, "Unknown profile")
