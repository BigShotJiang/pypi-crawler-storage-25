"""Additional output formats: HTML, XML, and Markdown reports."""

import json
from datetime import datetime
from typing import Dict, List
from .scan import ScanResult
from .vulnerabilities import get_vulnerability_info, get_risk_score, generate_risk_report


def format_html(result: ScanResult, include_risk_assessment: bool = True) -> str:
    """Generate an HTML report of scan results."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Calculate risk metrics
    ports_dict = {p.port: p.state == "open" for p in result.ports}
    risk_report = generate_risk_report(ports_dict) if include_risk_assessment else {}
    overall_risk = risk_report.get("overall_risk_score", 0) if risk_report else 0
    risk_color = "red" if overall_risk >= 8 else "orange" if overall_risk >= 6 else "yellow" if overall_risk >= 4 else "green"
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PortProbe Scan Report - {result.target}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #1e1e1e; color: #e0e0e0; line-height: 1.6; }}
        .container {{ max-width: 1200px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 8px; margin-bottom: 30px; color: white; }}
        .header h1 {{ font-size: 2.5em; margin-bottom: 10px; }}
        .header p {{ font-size: 1.1em; opacity: 0.9; }}
        .risk-badge {{ display: inline-block; padding: 8px 16px; border-radius: 4px; font-weight: bold; margin: 10px 0; background-color: {risk_color}; color: white; }}
        .summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }}
        .summary-card {{ background: #2d2d2d; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; }}
        .summary-card h3 {{ color: #667eea; margin-bottom: 10px; }}
        .summary-card .number {{ font-size: 2em; font-weight: bold; color: #e0e0e0; }}
        table {{ width: 100%; border-collapse: collapse; margin-bottom: 30px; background: #2d2d2d; border-radius: 8px; overflow: hidden; }}
        th {{ background: #3d3d3d; color: #667eea; padding: 15px; text-align: left; font-weight: 600; }}
        td {{ padding: 12px 15px; border-bottom: 1px solid #3d3d3d; }}
        tr:last-child td {{ border-bottom: none; }}
        .open {{ color: #4caf50; font-weight: bold; }}
        .closed {{ color: #999; }}
        .filtered {{ color: #ff9800; }}
        .vulnerable {{ background-color: #c3221426; }}
        .section {{ margin-bottom: 30px; }}
        .section h2 {{ color: #667eea; font-size: 1.8em; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #667eea; }}
        .vulnerability {{ background: #3d1a1a; padding: 15px; border-radius: 4px; margin-bottom: 10px; border-left: 4px solid #f44336; }}
        .vulnerability h4 {{ color: #f44336; margin-bottom: 5px; }}
        .vulnerability p {{ color: #ccc; font-size: 0.95em; }}
        .port-detail {{ background: #3d3d3d; padding: 15px; border-radius: 4px; margin-bottom: 10px; }}
        .port-detail h4 {{ color: #4caf50; margin-bottom: 10px; }}
        .footer {{ text-align: center; color: #999; padding: 20px; border-top: 1px solid #3d3d3d; margin-top: 30px; }}
        .critical {{ color: #f44336; font-weight: bold; }}
        .high {{ color: #ff9800; font-weight: bold; }}
        .info-row {{ display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #3d3d3d; }}
        .info-row:last-child {{ border-bottom: none; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>PortProbe Scan Report</h1>
            <p>Target: <strong>{result.target}</strong></p>
            <p>Scan Date: {timestamp}</p>
            {f'<div class="risk-badge">Risk Level: {risk_report.get("risk_assessment", "UNKNOWN")}</div>' if risk_report else ''}
        </div>
        
        <div class="summary">
            <div class="summary-card">
                <h3>Total Ports Scanned</h3>
                <div class="number">{result.total_ports_scanned}</div>
            </div>
            <div class="summary-card">
                <h3>Open Ports</h3>
                <div class="number" style="color: #4caf50;">{sum(1 for p in result.ports if p.state == "open")}</div>
            </div>
            <div class="summary-card">
                <h3>Closed Ports</h3>
                <div class="number">{sum(1 for p in result.ports if p.state == "closed")}</div>
            </div>
            <div class="summary-card">
                <h3>Filtered Ports</h3>
                <div class="number">{sum(1 for p in result.ports if p.state in ("filtered", "open|filtered"))}</div>
            </div>
        </div>
        
        <div class="section">
            <h2>Target Information</h2>
            <div class="info-row"><strong>Input:</strong> {result.target}</div>
            <div class="info-row"><strong>IP Address:</strong> {result.ip or 'N/A'}</div>
            <div class="info-row"><strong>Hostname:</strong> {result.hostname or 'N/A'}</div>
            {f'<div class="info-row"><strong>OS Detection:</strong> {result.os_guess}</div>' if result.os_guess else ''}
            <div class="info-row"><strong>Scan Duration:</strong> {result.scan_duration:.2f}s</div>
            <div class="info-row"><strong>Scan Type:</strong> {result.scan_type.upper()}</div>
        </div>
        
        <div class="section">
            <h2>Open Services</h2>
            <table>
                <tr>
                    <th>Port</th>
                    <th>Protocol</th>
                    <th>State</th>
                    <th>Service</th>
                    <th>Response Time</th>
                    <th>Risk Level</th>
                </tr>
"""
    
    for port in result.ports:
        if port.state == "open":
            vuln_info = get_vulnerability_info(port.port)
            risk_level = vuln_info.get("risk_level", "INFO") if vuln_info else "INFO"
            risk_color_map = {
                "CRITICAL": "red",
                "HIGH": "orange",
                "MEDIUM": "yellow",
                "LOW": "green",
                "INFO": "blue",
            }
            
            html += f"""                <tr class="vulnerable">
                    <td><strong>{port.port}</strong></td>
                    <td>{port.protocol.upper()}</td>
                    <td class="open">{port.state.upper()}</td>
                    <td>{port.service or 'Unknown'}</td>
                    <td>{port.response_time_ms:.1f}ms</td>
                    <td><span style="color: {risk_color_map.get(risk_level, 'white')}">{risk_level}</span></td>
                </tr>
"""
    
    html += """            </table>
        </div>
"""
    
    # Add vulnerability section
    if risk_report and (risk_report.get("critical_ports") or risk_report.get("high_risk_ports")):
        html += """        <div class="section">
            <h2>Identified Vulnerabilities</h2>
"""

        for port, service in risk_report.get("critical_ports", []):
            vuln_info = get_vulnerability_info(port)
            if vuln_info:
                html += f"""            <div class="vulnerability">
                <h4>CRITICAL: {service} on Port {port}</h4>
                <p>{vuln_info.get('notes', 'No additional information')}</p>
            </div>
"""
        
        for port, service in risk_report.get("high_risk_ports", []):
            vuln_info = get_vulnerability_info(port)
            if vuln_info:
                html += f"""            <div class="vulnerability">
                <h4>HIGH RISK: {service} on Port {port}</h4>
                <p>{vuln_info.get('notes', 'No additional information')}</p>
            </div>
"""
        
        html += """        </div>
"""
    
    html += f"""        <div class="footer">
            <p>Generated by PortProbe v2.5 | {timestamp}</p>
            <p>Scan completed in {result.scan_duration:.2f} seconds</p>
        </div>
    </div>
</body>
</html>
"""
    
    return html


def format_xml(result: ScanResult) -> str:
    """Generate XML output (Nmap-like format)."""
    timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    
    xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE nmaprun>
<nmaprun scanner="portprobe" args="portprobe scan" start="{timestamp}" version="2.5">
    <scaninfo type="{result.scan_type}" protocol="{result.scan_type}" numservices="{result.total_ports_scanned}" services="1-{result.total_ports_scanned}"/>
    <verbose level="0"/>
    <debugging level="0"/>
    <host starttime="{timestamp}" endtime="{timestamp}">
        <status state="up" reason="user-input" reason_ttl="0"/>
        <address addr="{result.ip}" addrtype="ipv4"/>
        <hostnames>
"""
    
    if result.hostname:
        xml += f'            <hostname name="{result.hostname}" type="PTR"/>\n'
    
    xml += """        </hostnames>
        <ports>
"""
    
    for port in result.ports:
        xml += f"""            <port protocol="{port.protocol}" portid="{port.port}">
                <state state="{port.state}" reason="syn-ack" reason_ttl="0"/>
                <service name="{port.service or 'unknown'}" tunnel="ssl" method="table" conf="10"/>
            </port>
"""
    
    xml += """        </ports>
        <times srtt="-1" rttvar="-1" to="1000000"/>
    </host>
    <runstats>
        <finished time="{}" timestr="{}"/>
        <summary numhosts="1" numservices="{}" numscantime="{}"/>
    </runstats>
</nmaprun>
""".format(timestamp, timestamp, result.total_ports_scanned, result.scan_duration)
    
    return xml


def format_markdown(result: ScanResult, include_risk_assessment: bool = True) -> str:
    """Generate a Markdown report."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Calculate risk metrics
    ports_dict = {p.port: p.state == "open" for p in result.ports}
    risk_report = generate_risk_report(ports_dict) if include_risk_assessment else {}
    overall_risk = risk_report.get("overall_risk_score", 0) if risk_report else 0
    
    md = f"""# PortProbe Scan Report

## Overview

**Target:** `{result.target}`  
**IP Address:** `{result.ip or 'N/A'}`  
**Hostname:** `{result.hostname or 'N/A'}`  
**Scan Type:** `{result.scan_type.upper()}`  
**Scan Date:** {timestamp}  
**Scan Duration:** {result.scan_duration:.2f}s  
**Total Ports Scanned:** {result.total_ports_scanned}

### Risk Assessment

- **Overall Risk Score:** {overall_risk}/10
- **Risk Level:** {risk_report.get('risk_assessment', 'UNKNOWN') if risk_report else 'UNKNOWN'}

### Summary Statistics

| Metric | Count |
|--------|-------|
| Open Ports | {sum(1 for p in result.ports if p.state == "open")} |
| Closed Ports | {sum(1 for p in result.ports if p.state == "closed")} |
| Filtered Ports | {sum(1 for p in result.ports if p.state in ("filtered", "open|filtered"))} |

## Open Services

| Port | Protocol | Service | Risk Level | Response Time |
|------|----------|---------|-----------|----------------|
"""
    
    for port in result.ports:
        if port.state == "open":
            vuln_info = get_vulnerability_info(port.port)
            risk_level = vuln_info.get("risk_level", "INFO") if vuln_info else "INFO"
            md += f"| {port.port} | {port.protocol.upper()} | {port.service or 'Unknown'} | {risk_level} | {port.response_time_ms:.1f}ms |\n"
    
    md += "\n## Vulnerability Summary\n\n"
    
    if risk_report and (risk_report.get("critical_ports") or risk_report.get("high_risk_ports")):
        md += "### Critical Issues\n\n"
        for port, service in risk_report.get("critical_ports", []):
            md += f"- **Port {port} ({service}):** CRITICAL - Immediate action required\n"
        
        md += "\n### High Risk Issues\n\n"
        for port, service in risk_report.get("high_risk_ports", []):
            md += f"- **Port {port} ({service}):** HIGH RISK - Should be addressed\n"
    else:
        md += "No critical or high-risk vulnerabilities detected.\n"
    
    md += f"\n---\n\n*Generated by PortProbe v2.5 | {timestamp}*\n"
    
    return md
