import ipaddress
import socket
import ssl
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

TLS_PORTS = {443, 8443, 465, 993, 995, 636}
HTTP_PORTS = {80, 8080, 8000, 8008, 8888, 443, 8443}


@dataclass
class TargetInfo:
    input_value: str
    ip: str
    hostname: str
    is_ip: bool
    is_private: bool
    version: int


def _is_private_ip(ip: str) -> bool:
    try:
        address = ipaddress.ip_address(ip)
        return address.is_private or address.is_loopback
    except ValueError:
        return False


def resolve_target(target: str) -> Tuple[str, str]:
    try:
        ip = str(ipaddress.ip_address(target))
        try:
            hostname = socket.gethostbyaddr(ip)[0]
        except Exception:
            hostname = ""
        if ipaddress.ip_address(ip).is_loopback:
            hostname = "localhost" if not hostname or hostname != "localhost" else hostname
        return ip, hostname
    except ValueError:
        try:
            ip = socket.gethostbyname(target)
            return ip, target
        except socket.gaierror as exc:
            raise ValueError(f"Cannot resolve target: {target}") from exc


def resolve_target_info(target: str) -> TargetInfo:
    ip, hostname = resolve_target(target)
    is_ip = False
    version = 4
    try:
        parsed = ipaddress.ip_address(target)
        is_ip = True
        version = parsed.version
    except ValueError:
        try:
            parsed = ipaddress.ip_address(ip)
            version = parsed.version
        except ValueError:
            version = 4
    return TargetInfo(
        input_value=target,
        ip=ip,
        hostname=hostname,
        is_ip=is_ip,
        is_private=_is_private_ip(ip),
        version=version,
    )


def expand_cidr(cidr: str) -> List[str]:
    try:
        return [str(ip) for ip in ipaddress.ip_network(cidr, strict=False).hosts()]
    except ValueError:
        return [cidr]


def grab_banner(ip: str, port: int, timeout: float = 2.0) -> Tuple[str, Dict[str, str]]:
    banner = ""
    details: Dict[str, str] = {}
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((ip, port))
        if port in TLS_PORTS:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            sock = context.wrap_socket(sock, server_hostname=ip)
            try:
                cert = sock.getpeercert()
                issuer = cert.get("issuer")
                if issuer:
                    details["tls_issuer"] = ", ".join("=".join(item) for sub in issuer for item in sub)
                subject = cert.get("subject")
                if subject:
                    details["tls_subject"] = ", ".join("=".join(item) for sub in subject for item in sub)
            except Exception:
                pass
        if port in HTTP_PORTS:
            sock.sendall(b"HEAD / HTTP/1.0\r\nHost: " + ip.encode() + b"\r\n\r\n")
        else:
            sock.sendall(b"\r\n")
        data = sock.recv(2048)
        banner = data.decode("utf-8", errors="replace").strip()
    except Exception:
        banner = ""
    finally:
        if sock is not None:
            try:
                sock.close()
            except Exception:
                pass
    return banner, details
