"""
EvrGuard Python SDK -- Remote Mode
====================================
Open-source HTTP client for the hosted EvrGuard verification API.

The proprietary engine (neuro-symbolic gradient steering, compliance packs,
safety net classifier) runs on the hosted API. This SDK is a thin wrapper
that posts actions to /verify and surfaces verdicts to your application.

Usage:

    from evrguard import EvrmindGuard, EvrmindSteered

    guard = EvrmindGuard(api_url="https://evrguard.up.railway.app")

    @guard.wrap_tool
    def execute_query(sql):
        return db.execute(sql)

    try:
        execute_query("DROP TABLE users")
    except EvrmindSteered as e:
        print(e.verdict["enforcement_notice"])
"""

import os
import json
import time
import hmac
import hashlib
import functools
import threading
import asyncio
import logging

logger = logging.getLogger("evrguard")

DEFAULT_API_URL = "https://evrguard.up.railway.app"
DEFAULT_TIMEOUT = 30
DEFAULT_AUDIT_LOG = "evrguard_audit.jsonl"


class EvrmindSteered(Exception):
    """Raised when an action is steered (intercepted but correctable)."""

    def __init__(self, message, verdict_data):
        super().__init__(message)
        self.verdict = verdict_data


class EvrmindBlocked(Exception):
    """Raised when an action is blocked (adversarial or fail-safe)."""

    def __init__(self, message, verdict_data):
        super().__init__(message)
        self.verdict = verdict_data


class EvrmindAuthError(Exception):
    """Raised when API key authentication fails."""

    pass


class EvrmindGuard:
    """
    Thread-safe EvrGuard client for the hosted verification API.

    Args:
        api_url: URL of the EvrGuard API (default: https://evrguard.up.railway.app)
        api_key: Optional API key sent as the X-Evrmind-Key header
        hmac_key: Optional shared secret for verifying HMAC-SHA256 proofs
                  returned by the API. If omitted, verify_proof returns False.
        audit_log_path: Path to local audit log file (default: evrguard_audit.jsonl).
                        Set to None to disable local audit logging.
        timeout: HTTP timeout in seconds (default: 30)
        max_retries: Retries on transient HTTP errors (default: 3)
        enforcement_mode: "enforce" (default) raises on STEERED/BLOCKED.
                          "monitor" logs verdicts but never blocks.
    """

    def __init__(
        self,
        api_url=None,
        api_key=None,
        hmac_key=None,
        audit_log_path=DEFAULT_AUDIT_LOG,
        timeout=DEFAULT_TIMEOUT,
        max_retries=3,
        enforcement_mode="enforce",
    ):
        self.api_url = (api_url or DEFAULT_API_URL).rstrip("/")
        self.api_key = api_key
        self.hmac_key = hmac_key.encode() if isinstance(hmac_key, str) else hmac_key
        self.audit_log_path = audit_log_path
        self.timeout = timeout
        self.max_retries = max_retries
        self.enforcement_mode = enforcement_mode

        self._lock = threading.Lock()
        self._audit_lock = threading.Lock()
        self._action_log = []

    # ── Verification ──────────────────────────────────────────────

    def verify(self, action_text, api_key=None):
        """
        Verify an action against the hosted EvrGuard constitution.

        Args:
            action_text: The proposed action as a string.
            api_key: Optional override for the request's X-Evrmind-Key header.

        Returns:
            dict with verdict, proof_hash, violated_rules, enforcement_notice,
            explanation, action, latency_ms, timestamp, enforcement_mode.
        """
        t0 = time.perf_counter()
        result = self._verify_remote(action_text, api_key=api_key)
        result["latency_ms"] = round((time.perf_counter() - t0) * 1000.0, 2)
        result["timestamp"] = time.time()
        result["enforcement_mode"] = self.enforcement_mode
        result["action"] = action_text

        with self._lock:
            self._action_log.append(result)
        self._write_audit(result)
        return result

    def _verify_remote(self, action_text, api_key=None):
        """POST the action to the EvrGuard API and normalise the response."""
        import urllib.request
        import urllib.error

        payload = json.dumps({"action": action_text}).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "evrguard-python/0.1.0",
        }
        key = api_key or self.api_key
        if key:
            headers["X-Evrmind-Key"] = key

        req = urllib.request.Request(
            f"{self.api_url}/verify",
            data=payload,
            headers=headers,
            method="POST",
        )

        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    raw = json.loads(resp.read().decode("utf-8"))
                return self._normalise_response(raw)
            except urllib.error.HTTPError as e:
                if e.code == 401 or e.code == 403:
                    raise EvrmindAuthError(
                        f"API authentication failed (HTTP {e.code}). "
                        f"Check your api_key."
                    )
                last_error = e
                if attempt < self.max_retries and 500 <= e.code < 600:
                    time.sleep((2 ** attempt) * 0.1)
                    continue
                break
            except (urllib.error.URLError, TimeoutError) as e:
                last_error = e
                if attempt < self.max_retries:
                    time.sleep((2 ** attempt) * 0.1)
                    continue
                break

        # Fail safe: return BLOCKED so the wrapped action does not proceed
        return {
            "verdict": "BLOCKED",
            "proof_hash": "API_UNREACHABLE",
            "violated_rules": ["API_UNREACHABLE"],
            "violated_bits": [],
            "explanation": f"EvrGuard API unreachable: {last_error}",
            "enforcement_notice": (
                "EvrGuard could not verify this action because the API is "
                "unreachable. The action has been blocked as a precaution. "
                "Check your network and api_url, then retry."
            ),
            "input_norm": 0.0,
            "output_norm": 0.0,
            "safety": 0.0,
        }

    @staticmethod
    def _normalise_response(raw):
        """Normalise API response field names to a stable client schema."""
        # The hosted API may return either `proof` or `proof_hash`,
        # and either `rules` or `violated_rules`. Normalise both.
        result = dict(raw)
        if "proof_hash" not in result and "proof" in result:
            result["proof_hash"] = result["proof"]
        if "violated_rules" not in result and "rules" in result:
            result["violated_rules"] = result["rules"]
        result.setdefault("verdict", "UNKNOWN")
        result.setdefault("violated_rules", [])
        result.setdefault("explanation", "")
        result.setdefault("enforcement_notice", None)
        result.setdefault("proof_hash", "")
        return result

    # ── HMAC proof verification ───────────────────────────────────

    def verify_proof(self, result, signature=None):
        """
        Verify an HMAC-SHA256 signature on a verdict result.

        Returns True if the signature matches, False if it does not match,
        and False if no hmac_key was configured on this client.

        Args:
            result: A verdict dict returned by verify().
            signature: Optional explicit signature to check.
                       Defaults to result["hmac_signature"].
        """
        if not self.hmac_key:
            return False
        sig = signature or result.get("hmac_signature", "")
        if not sig:
            return False
        # Sign a stable JSON projection of the verdict body
        body = json.dumps(
            {k: result.get(k) for k in sorted(result.keys()) if k != "hmac_signature"},
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
        expected = hmac.new(self.hmac_key, body, hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, sig)

    # ── Decorator ─────────────────────────────────────────────────

    def wrap_tool(self, func=None, *, api_key=None):
        """
        Decorator that verifies every call before execution.

        Usage:
            @guard.wrap_tool
            def my_func(arg):
                ...

            @guard.wrap_tool(api_key="custom-key")
            def my_func(arg):
                ...
        """

        def decorator(f):
            @functools.wraps(f)
            def wrapper(*args, **kwargs):
                arg_strs = [repr(a) for a in args]
                arg_strs += [f"{k}={repr(v)}" for k, v in kwargs.items()]
                action_text = f"{f.__name__}({', '.join(arg_strs)})"

                result = self.verify(action_text, api_key=api_key)

                if self.enforcement_mode == "monitor":
                    return f(*args, **kwargs)

                verdict = result.get("verdict", "UNKNOWN")
                if verdict == "BLOCKED":
                    raise EvrmindBlocked(
                        f"Blocked: {action_text}\n"
                        f"Rules: {', '.join(result.get('violated_rules', []))}\n"
                        f"Proof: {result.get('proof_hash', '')}",
                        result,
                    )
                if verdict == "STEERED":
                    raise EvrmindSteered(
                        f"Steered: {action_text}\n"
                        f"Rules: {', '.join(result.get('violated_rules', []))}\n"
                        f"Enforcement: {result.get('enforcement_notice', '')}\n"
                        f"Proof: {result.get('proof_hash', '')}",
                        result,
                    )
                return f(*args, **kwargs)

            return wrapper

        if func is not None:
            return decorator(func)
        return decorator

    # ── Audit logging ─────────────────────────────────────────────

    def _write_audit(self, result):
        """Append a single audit entry to the local log file."""
        if not self.audit_log_path:
            return
        entry = {
            "timestamp": result.get("timestamp", time.time()),
            "action": result.get("action", ""),
            "verdict": result.get("verdict", ""),
            "violated_rules": result.get("violated_rules", []),
            "proof_hash": result.get("proof_hash", ""),
            "latency_ms": result.get("latency_ms", 0),
            "enforcement_mode": result.get("enforcement_mode", ""),
        }
        with self._audit_lock:
            try:
                with open(self.audit_log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry) + "\n")
            except OSError as e:
                logger.warning("Audit log write failed: %s", e)

    def get_log(self):
        """Return the in-memory action log."""
        with self._lock:
            return list(self._action_log)

    def get_log_summary(self):
        """Return summary stats over the in-memory action log."""
        with self._lock:
            log = list(self._action_log)
        passed = sum(1 for r in log if r.get("verdict") == "PASS")
        steered = sum(1 for r in log if r.get("verdict") == "STEERED")
        blocked = sum(1 for r in log if r.get("verdict") == "BLOCKED")
        return {
            "total": len(log),
            "passed": passed,
            "steered": steered,
            "blocked": blocked,
        }


class AsyncEvrmindGuard:
    """
    Async wrapper around EvrmindGuard.

    Usage:
        guard = AsyncEvrmindGuard(api_url="https://evrguard.up.railway.app")
        result = await guard.verify("DROP TABLE users")
    """

    def __init__(self, *args, **kwargs):
        self._sync_guard = EvrmindGuard(*args, **kwargs)
        self._executor = None

    async def verify(self, action_text, api_key=None):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self._executor,
            lambda: self._sync_guard.verify(action_text, api_key=api_key),
        )

    def verify_proof(self, result, signature=None):
        return self._sync_guard.verify_proof(result, signature)

    def wrap_tool(self, func=None, *, api_key=None):
        def decorator(f):
            @functools.wraps(f)
            async def wrapper(*args, **kwargs):
                arg_strs = [repr(a) for a in args]
                arg_strs += [f"{k}={repr(v)}" for k, v in kwargs.items()]
                action_text = f"{f.__name__}({', '.join(arg_strs)})"

                result = await self.verify(action_text, api_key=api_key)

                if self._sync_guard.enforcement_mode == "monitor":
                    return await f(*args, **kwargs)

                verdict = result.get("verdict", "UNKNOWN")
                if verdict == "BLOCKED":
                    raise EvrmindBlocked(
                        f"Blocked: {action_text}\nProof: {result.get('proof_hash', '')}",
                        result,
                    )
                if verdict == "STEERED":
                    raise EvrmindSteered(
                        f"Steered: {action_text}\nProof: {result.get('proof_hash', '')}",
                        result,
                    )
                return await f(*args, **kwargs)

            return wrapper

        if func is not None:
            return decorator(func)
        return decorator

    def get_log(self):
        return self._sync_guard.get_log()

    def get_log_summary(self):
        return self._sync_guard.get_log_summary()
