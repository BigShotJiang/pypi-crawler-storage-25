"""
EvrGuard MCP Safety Server -- Remote Mode
==========================================
Model Context Protocol server with Content-Length framing.
Calls the hosted EvrGuard API for verification. Works with Claude Code,
Claude Desktop, OpenClaw, and any MCP-compatible client.

Run:

    python -m evrguard.mcp_server
    python -m evrguard.mcp_server --api-url https://evrguard.up.railway.app
    python -m evrguard.mcp_server --transport sse --port 3001
"""

import sys
import os
import json
import logging
import threading

from .sdk import EvrmindGuard

logger = logging.getLogger("evrguard.mcp")


class EvrmindMCPServer:
    """
    MCP server that proxies tool calls through the hosted EvrGuard API.

    Args:
        api_url: URL of the EvrGuard API (default: env EVRGUARD_API_URL or
                 https://evrguard.up.railway.app)
        api_key: Optional API key for the EvrGuard API
        audit_log_path: Local audit log path
        tool_config_path: Optional JSON file describing proxied tools
    """

    def __init__(
        self,
        api_url=None,
        api_key=None,
        audit_log_path=None,
        tool_config_path=None,
    ):
        self._guard = EvrmindGuard(
            api_url=api_url or os.environ.get("EVRGUARD_API_URL"),
            api_key=api_key or os.environ.get("EVRGUARD_API_KEY"),
            audit_log_path=audit_log_path or "evrguard_mcp_audit.jsonl",
        )
        self._audit_lock = threading.Lock()

        self._proxied_tools = {}
        if tool_config_path and os.path.isfile(tool_config_path):
            with open(tool_config_path, encoding="utf-8") as f:
                self._proxied_tools = json.load(f).get("tools", {})
            logger.info("Loaded %d proxied tools", len(self._proxied_tools))

        self._initialized = False

    def verify_action(self, action_text):
        return self._guard.verify(action_text)

    @staticmethod
    def _build_action_text(tool_name, arguments):
        arg_parts = []
        for k, v in arguments.items():
            val = json.dumps(v) if isinstance(v, (dict, list)) else repr(v)
            arg_parts.append(f"{k}={val}")
        return f"{tool_name}({', '.join(arg_parts)})"

    # ── JSON-RPC handling ─────────────────────────────────────────

    def handle_message(self, message):
        method = message.get("method", "")
        msg_id = message.get("id")
        params = message.get("params", {})

        if msg_id is None and method.startswith("notifications/"):
            if method == "notifications/initialized":
                self._initialized = True
            return None

        if method == "initialize":
            self._initialized = True
            return self._response(
                msg_id,
                {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {
                        "name": "evrguard-safety",
                        "version": "0.1.0",
                    },
                },
            )

        if method == "ping":
            return self._response(msg_id, {})

        if method == "tools/list":
            tools = [
                {
                    "name": "evrguard_verify",
                    "description": (
                        "Verify an action against the EvrGuard safety constitution. "
                        "Returns verdict (PASS/STEERED/BLOCKED), proof hash, and "
                        "enforcement guidance."
                    ),
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "action": {
                                "type": "string",
                                "description": "The action to verify",
                            },
                        },
                        "required": ["action"],
                    },
                }
            ]
            for name, tool_def in self._proxied_tools.items():
                tools.append(
                    {
                        "name": name,
                        "description": tool_def.get("description", ""),
                        "inputSchema": tool_def.get(
                            "inputSchema", {"type": "object", "properties": {}}
                        ),
                    }
                )
            return self._response(msg_id, {"tools": tools})

        if method == "tools/call":
            tool_name = params.get("name", "")
            arguments = params.get("arguments", {})

            if tool_name == "evrguard_verify":
                action = arguments.get("action", "")
                result = self.verify_action(action)
                return self._tool_response(msg_id, result)

            if tool_name in self._proxied_tools:
                action = self._build_action_text(tool_name, arguments)
                result = self.verify_action(action)
                if result.get("verdict") == "PASS":
                    return self._response(
                        msg_id,
                        {
                            "content": [
                                {
                                    "type": "text",
                                    "text": json.dumps(
                                        {
                                            "evrguard_verdict": "PASS",
                                            "evrguard_proof": result.get("proof_hash", ""),
                                            "result": (
                                                f"Tool {tool_name} verified safe. "
                                                "Forward to your real tool implementation."
                                            ),
                                        },
                                        indent=2,
                                    ),
                                }
                            ]
                        },
                    )
                return self._tool_response(msg_id, result)

            # Unknown tool: still verify it
            action = self._build_action_text(tool_name, arguments)
            result = self.verify_action(action)
            return self._tool_response(msg_id, result)

        return self._error(msg_id, -32601, f"Unknown method: {method}")

    def _tool_response(self, msg_id, result):
        verdict = result.get("verdict", "UNKNOWN")
        if verdict == "PASS":
            return self._response(
                msg_id,
                {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(
                                {
                                    "verdict": "PASS",
                                    "proof_hash": result.get("proof_hash", ""),
                                    "message": "Action verified safe. Proceed with execution.",
                                },
                                indent=2,
                            ),
                        }
                    ]
                },
            )
        return self._response(
            msg_id,
            {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps(
                            {
                                "verdict": verdict,
                                "proof_hash": result.get("proof_hash", ""),
                                "violated_rules": result.get("violated_rules", []),
                                "enforcement_notice": result.get("enforcement_notice", ""),
                                "explanation": result.get("explanation", ""),
                                "message": "Action denied. Follow the enforcement notice.",
                            },
                            indent=2,
                        ),
                    }
                ],
                "isError": verdict == "BLOCKED",
            },
        )

    @staticmethod
    def _response(msg_id, result):
        return {"jsonrpc": "2.0", "id": msg_id, "result": result}

    @staticmethod
    def _error(msg_id, code, message):
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {"code": code, "message": message},
        }

    # ── Stdio transport with Content-Length framing ───────────────

    def run_stdio(self):
        sys.stderr.write("[EvrGuard MCP] Starting on stdio (Content-Length framing)\n")
        sys.stderr.write(f"[EvrGuard MCP] API: {self._guard.api_url}\n")
        sys.stderr.flush()

        reader = sys.stdin.buffer
        writer = sys.stdout.buffer

        while True:
            try:
                message = self._read_message(reader)
                if message is None:
                    break
                response = self.handle_message(message)
                if response is not None:
                    self._write_message(writer, response)
            except json.JSONDecodeError as e:
                sys.stderr.write(f"[EvrGuard MCP] Invalid JSON: {e}\n")
            except Exception as e:
                sys.stderr.write(f"[EvrGuard MCP] Error: {e}\n")
                sys.stderr.flush()

    @staticmethod
    def _read_message(reader):
        headers = {}
        while True:
            line = reader.readline()
            if not line:
                return None
            line = line.decode("utf-8").strip()
            if line == "":
                break
            if ":" in line:
                key, value = line.split(":", 1)
                headers[key.strip().lower()] = value.strip()
        content_length = int(headers.get("content-length", 0))
        if content_length == 0:
            return None
        body = reader.read(content_length)
        return json.loads(body.decode("utf-8"))

    @staticmethod
    def _write_message(writer, message):
        body = json.dumps(message).encode("utf-8")
        header = f"Content-Length: {len(body)}\r\n\r\n".encode("utf-8")
        writer.write(header)
        writer.write(body)
        writer.flush()

    # ── SSE transport for HTTP-based clients ──────────────────────

    def run_sse(self, host="127.0.0.1", port=3001):
        try:
            from flask import Flask, request as flask_request, Response, jsonify
        except ImportError:
            raise RuntimeError(
                "SSE transport requires Flask. Install with: pip install flask"
            )

        app = Flask(__name__)

        @app.route("/sse", methods=["GET"])
        def sse_endpoint():
            def generate():
                yield "event: endpoint\ndata: /message\n\n"

            return Response(
                generate(),
                mimetype="text/event-stream",
                headers={"Cache-Control": "no-cache"},
            )

        @app.route("/message", methods=["POST"])
        def message_endpoint():
            message = flask_request.get_json()
            response = self.handle_message(message)
            if response is None:
                return jsonify({}), 204
            return jsonify(response)

        sys.stderr.write(f"[EvrGuard MCP] SSE server on http://{host}:{port}\n")
        app.run(host=host, port=port, debug=False, threaded=True)


def main():
    import argparse

    parser = argparse.ArgumentParser(description="EvrGuard MCP Safety Server")
    parser.add_argument("--api-url", default=None,
                        help="EvrGuard API URL (default: env EVRGUARD_API_URL "
                             "or https://evrguard.up.railway.app)")
    parser.add_argument("--api-key", default=None)
    parser.add_argument("--transport", default="stdio", choices=["stdio", "sse"])
    parser.add_argument("--port", type=int, default=3001)
    parser.add_argument("--tool-config", default=None,
                        help="Optional JSON file describing proxied tools")
    args = parser.parse_args()

    server = EvrmindMCPServer(
        api_url=args.api_url,
        api_key=args.api_key,
        tool_config_path=args.tool_config,
    )

    if args.transport == "sse":
        server.run_sse(port=args.port)
    else:
        server.run_stdio()


if __name__ == "__main__":
    main()
