"""
EvrGuard Python SDK
====================
Deterministic safety for AI agents. Mathematics, not prompts.

Quick start:

    from evrguard import EvrmindGuard

    guard = EvrmindGuard(api_url="https://evrguard.up.railway.app")

    @guard.wrap_tool
    def execute_query(sql):
        return db.execute(sql)

This is the open-source integration layer. The proprietary verification
engine, compliance packs, and constitutional algorithms run on the hosted
EvrGuard API. See https://labs.evrmind.io for details.
"""

from .sdk import (
    EvrmindGuard,
    AsyncEvrmindGuard,
    EvrmindSteered,
    EvrmindBlocked,
    EvrmindAuthError,
)

__version__ = "0.1.0"
__all__ = [
    "EvrmindGuard",
    "AsyncEvrmindGuard",
    "EvrmindSteered",
    "EvrmindBlocked",
    "EvrmindAuthError",
    "__version__",
]
