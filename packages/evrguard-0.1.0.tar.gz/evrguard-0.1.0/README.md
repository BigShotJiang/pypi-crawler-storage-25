# EvrGuard

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://img.shields.io/pypi/v/evrguard.svg)](https://pypi.org/project/evrguard/)

**Deterministic safety for AI agents. Mathematics, not prompts.**

---

## What is EvrGuard?

EvrGuard wraps any AI agent with mathematical safety verification. Every
action is checked against constitutional rules using neuro-symbolic
gradient steering. Every decision carries a cryptographic proof.

Not AI watching AI. Mathematics governing AI.

## Quick Start

```python
from evrguard import EvrmindGuard

guard = EvrmindGuard(api_url="https://evrguard.up.railway.app")

@guard.wrap_tool
def execute_query(sql):
    return db.execute(sql)
```

That is the entire integration. Three lines plus a decorator on each
guarded tool.

## Installation

```bash
pip install evrguard
```

Python 3.9 or newer. The only runtime dependency is `requests` (the
SDK falls back to the standard library `urllib` if it is not present).

## MCP Server for Claude Code

EvrGuard ships an MCP server. Add to your `.mcp.json`:

```json
{
  "mcpServers": {
    "evrguard": {
      "command": "python",
      "args": ["-m", "evrguard.mcp_server"],
      "env": {
        "EVRGUARD_API_URL": "https://evrguard.up.railway.app"
      }
    }
  }
}
```

Restart Claude Code. The `evrguard_verify` tool is now available to the
agent for every action.

## Features

- **Triple-layer detection** — pattern matching, geometric safety net,
  and intent analysis. **97.3% hostile catch rate** on the OWASP
  Agentic AI red-team baseline (87/87).
- **Neuro-symbolic gradient steering** — does not just block. Steers
  the agent toward a compliant alternative on a 32-dimensional
  constitutional manifold.
- **Cryptographic proofs** — every verdict carries an HMAC-SHA256
  signature and a Merkle-anchored proof hash. Verifiable by any
  auditor.
- **10 industry constitutions** — pre-built rule sets for finance,
  healthcare, legal, devops, retail, education, insurance, government,
  critical infrastructure, and general enterprise.
- **OWASP Agentic Top 10** — preset compliance pack covering all ten
  agentic AI threats.
- **Monitor mode** — log verdicts without blocking. Run for a week
  before enforcing.
- **Allowlist mode** — for maximum control, allow only explicitly
  permitted actions and block everything else.

## Industry Constitutions

| Industry                | Rules | Use For                                 |
|-------------------------|-------|-----------------------------------------|
| General Enterprise      | 12    | Any business using AI agents            |
| Financial Services      | 14    | Banks, trading, fintech, payments       |
| Healthcare              | 12    | Hospitals, clinics, health tech         |
| Legal                   | 11    | Law firms, legal tech, compliance       |
| DevOps / Engineering    | 12    | Software teams, coding agents           |
| Retail / E-commerce     | 11    | Online retailers, marketplaces          |
| Education               | 10    | Schools, universities, edtech           |
| Insurance               | 12    | Insurers, brokers, insurtechs           |
| Government              | 12    | Public sector, civil service            |
| Critical Infrastructure | 14    | Energy, water, telecoms, transport      |

All ten templates ship in the `constitutions/` directory.

## Integration Examples

| Framework  | Example                                                          |
|------------|------------------------------------------------------------------|
| LangChain  | [examples/langchain_integration.py](examples/langchain_integration.py)   |
| LangGraph  | [examples/langgraph_integration.py](examples/langgraph_integration.py)   |
| AutoGen    | [examples/autogen_integration.py](examples/autogen_integration.py)       |
| CrewAI     | [examples/crewai_integration.py](examples/crewai_integration.py)         |
| Claude Code| [examples/claude_code_setup.md](examples/claude_code_setup.md)           |
| OpenClaw   | [examples/openclaw_setup.md](examples/openclaw_setup.md)                 |

## Hardware Enforcement

For environments requiring physical enforcement, the same constitutional
rules compile to the Evrmind safety processor on dedicated silicon.
**7.47 ns interdiction.** Same constitution. Two layers.

Learn more at [labs.evrmind.io](https://labs.evrmind.io).

## How it Works

```
   action ─▶  Layer 1: Pattern Matcher  ─▶
              Layer 2: Geometric Safety Net  ─▶
              Layer 3: Intent Analysis  ─▶  verdict + proof
```

The verification engine runs on the hosted EvrGuard API. The Python SDK
in this repository is the open-source integration layer.

## Licence

MIT. See [LICENCE](LICENCE).

Copyright © 2026 Evrmind Limited.

---

[labs.evrmind.io](https://labs.evrmind.io) · [GitHub](https://github.com/Evrmind-UK/evrguard-sdk) · [PyPI](https://pypi.org/project/evrguard/)
