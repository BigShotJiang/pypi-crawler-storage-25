#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Test suite for config.py"""

import os
import tempfile
import pytest

from landingzones import config


class TestLoadYamlConfig:
    """Test the _load_yaml_config function"""
    
    def test_explicit_config_file(self, tmp_path):
        """Test loading an explicitly specified config file"""
        config_file = tmp_path / "custom_config.yaml"
        config_file.write_text("transfers_file: custom/transfers.tsv\nlog_dir: custom_log\n")
        
        result = config._load_yaml_config(str(config_file))
        
        assert result['transfers_file'] == 'custom/transfers.tsv'
        assert result['log_dir'] == 'custom_log'
    
    def test_explicit_config_file_not_found(self, tmp_path):
        """Test loading a non-existent explicit config file returns empty dict"""
        result = config._load_yaml_config(str(tmp_path / "nonexistent.yaml"))
        
        assert result == {}
    
    def test_search_config_in_cwd(self, tmp_path, monkeypatch):
        """Test finding config.yaml in current working directory"""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("log_dir: found_in_cwd\n")
        
        monkeypatch.chdir(tmp_path)
        result = config._load_yaml_config()
        
        assert result['log_dir'] == 'found_in_cwd'
    
    def test_search_config_in_config_subdir(self, tmp_path, monkeypatch):
        """Test finding config.yaml in config/ subdirectory"""
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        config_file = config_dir / "config.yaml"
        config_file.write_text("log_dir: found_in_config_subdir\n")
        
        monkeypatch.chdir(tmp_path)
        result = config._load_yaml_config()
        
        assert result['log_dir'] == 'found_in_config_subdir'
    
    def test_cwd_takes_priority_over_config_subdir(self, tmp_path, monkeypatch):
        """Test that config in CWD takes priority over config/ subdirectory"""
        # Create config in config/ subdir
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        subdir_config = config_dir / "config.yaml"
        subdir_config.write_text("log_dir: from_subdir\n")
        
        # Create config in CWD
        cwd_config = tmp_path / "config.yaml"
        cwd_config.write_text("log_dir: from_cwd\n")
        
        monkeypatch.chdir(tmp_path)
        result = config._load_yaml_config()
        
        # CWD should take priority
        assert result['log_dir'] == 'from_cwd'
    
    def test_search_alternative_config_names(self, tmp_path, monkeypatch):
        """Test finding config files with alternative names"""
        config_file = tmp_path / "landingzones.yaml"
        config_file.write_text("log_dir: found_landingzones_yaml\n")
        
        monkeypatch.chdir(tmp_path)
        result = config._load_yaml_config()
        
        assert result['log_dir'] == 'found_landingzones_yaml'
    
    def test_config_yml_extension(self, tmp_path, monkeypatch):
        """Test finding config files with .yml extension"""
        config_file = tmp_path / "config.yml"
        config_file.write_text("log_dir: found_yml\n")
        
        monkeypatch.chdir(tmp_path)
        result = config._load_yaml_config()
        
        assert result['log_dir'] == 'found_yml'
    
    def test_no_config_found(self, tmp_path, monkeypatch):
        """Test returns empty dict when no config file found"""
        monkeypatch.chdir(tmp_path)
        result = config._load_yaml_config()
        
        assert result == {}
    
    def test_empty_config_file(self, tmp_path, monkeypatch):
        """Test loading an empty config file returns empty dict"""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("")
        
        monkeypatch.chdir(tmp_path)
        result = config._load_yaml_config()
        
        assert result == {}
    
    def test_config_with_only_comments(self, tmp_path, monkeypatch):
        """Test loading a config file with only comments returns empty dict"""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("# This is a comment\n# Another comment\n")
        
        monkeypatch.chdir(tmp_path)
        result = config._load_yaml_config()
        
        assert result == {}


class TestExpandPath:
    """Test the _expand_path function"""
    
    def test_expand_user_home(self):
        """Test expanding ~ to user home directory"""
        result = config._expand_path("~/test/path")
        
        assert result.startswith(os.path.expanduser("~"))
        assert "~" not in result
    
    def test_expand_env_variable(self, monkeypatch):
        """Test expanding environment variables in path"""
        monkeypatch.setenv("TEST_VAR", "/test/value")
        
        result = config._expand_path("$TEST_VAR/subdir")
        
        assert result == "/test/value/subdir"
    
    def test_none_path(self):
        """Test that None path returns None"""
        result = config._expand_path(None)
        
        assert result is None
    
    def test_empty_path(self):
        """Test that empty path returns empty string"""
        result = config._expand_path("")
        
        assert result == ""


class TestConfigClass:
    """Test the Config class"""
    
    def test_default_values(self, tmp_path, monkeypatch):
        """Test that Config uses sensible defaults"""
        monkeypatch.chdir(tmp_path)
        # Clear any LZ_ environment variables
        for key in list(os.environ.keys()):
            if key.startswith('LZ_'):
                monkeypatch.delenv(key, raising=False)
        
        cfg = config.Config()
        
        assert cfg.log_dir == 'log'
        assert cfg.output_dir == 'output'
        assert cfg.input_dir == 'input'
        assert cfg.validation_scripts_dir == os.path.join('output', 'validation_scripts')
    
    def test_config_from_yaml(self, tmp_path, monkeypatch):
        """Test that Config loads values from config.yaml"""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "report_transfer_log_file: shared/transfers.tsv\n"
            "log_dir: custom_log\n"
            "output_dir: custom_output\n"
            "validation_scripts_dir: custom_validation\n"
            "rit_managed_locations:\n"
            "  server1: /srv/rit_managed\n"
            "rit_managed_folder_structure:\n"
            "  sh_output: scripts/out\n"
        )
        
        monkeypatch.chdir(tmp_path)
        cfg = config.Config()
        
        assert cfg.log_dir == 'custom_log'
        assert cfg.output_dir == 'custom_output'
        assert cfg.report_transfer_log_file == 'shared/transfers.tsv'
        assert cfg.validation_scripts_dir == 'custom_validation'
        assert cfg.get_rit_managed_location('server1') == '/srv/rit_managed'
        assert cfg.get_rit_managed_location('unknown') == 'custom_output'
        assert cfg.get_rit_managed_path('server1', 'sh_output') == '/srv/rit_managed/scripts/out'
        assert cfg.get_flock_path('server1') == '/usr/bin/flock'

    def test_report_transfer_log_file_accepts_legacy_yaml_key(self, tmp_path, monkeypatch):
        """Older configs using transfer_log_file should keep working."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("transfer_log_file: legacy/transfers.tsv\n")

        monkeypatch.chdir(tmp_path)
        cfg = config.Config()

        assert cfg.report_transfer_log_file == 'legacy/transfers.tsv'
        assert cfg.transfer_log_file == 'legacy/transfers.tsv'
    
    def test_config_from_config_subdir(self, tmp_path, monkeypatch):
        """Test that Config loads values from config/config.yaml"""
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        config_file = config_dir / "config.yaml"
        config_file.write_text("log_dir: log_from_subdir\n")
        
        monkeypatch.chdir(tmp_path)
        cfg = config.Config()
        
        assert cfg.log_dir == 'log_from_subdir'
    
    def test_env_variable_override(self, tmp_path, monkeypatch):
        """Test that environment variables override config file values"""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("log_dir: from_yaml\n")
        
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("LZ_LOG_DIR", "from_env")
        
        cfg = config.Config()
        
        assert cfg.log_dir == 'from_env'

    def test_runtime_ids_from_yaml_env_and_runtime(self, tmp_path, monkeypatch):
        """Runtime IDs should resolve with the normal config priority."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "runtime_ids:\n"
            "  - yaml_runtime.local\n"
            "  - yaml_runtime.local\n"
        )

        monkeypatch.chdir(tmp_path)
        cfg = config.Config()
        assert cfg.runtime_ids == ['yaml_runtime.local']

        monkeypatch.setenv("LZ_RUNTIME_IDS", "env_one.local, env_two.local")
        assert cfg.runtime_ids == ['env_one.local', 'env_two.local']

        cfg.load_config(runtime_ids=['runtime.local', 'runtime.local'])
        assert cfg.runtime_ids == ['runtime.local']

    def test_report_transfer_log_file_accepts_legacy_env_var(self, tmp_path, monkeypatch):
        """Older automation environments should still resolve LZ_TRANSFER_LOG_FILE."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("LZ_TRANSFER_LOG_FILE", "/tmp/legacy.tsv")

        cfg = config.Config()

        assert cfg.report_transfer_log_file == '/tmp/legacy.tsv'

    def test_path_variables_merge_env_yaml_and_runtime(self, tmp_path, monkeypatch):
        """Config path variables should merge env, YAML, and runtime values."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "path_variables:\n"
            "  YAML_ONLY: /yaml/root\n"
            "  SHARED_ROOT: /yaml/shared\n"
        )

        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("ENV_ONLY", "/env/root")
        monkeypatch.setenv("SHARED_ROOT", "/env/shared")

        cfg = config.Config()
        cfg.load_config(path_variables={
            'RUNTIME_ONLY': '/runtime/root',
            'SHARED_ROOT': '/runtime/shared',
        })

        assert cfg.path_variables['ENV_ONLY'] == '/env/root'
        assert cfg.path_variables['YAML_ONLY'] == '/yaml/root'
        assert cfg.path_variables['RUNTIME_ONLY'] == '/runtime/root'
        assert cfg.path_variables['SHARED_ROOT'] == '/runtime/shared'

    def test_rit_managed_paths_preserve_configured_paths(self, tmp_path, monkeypatch):
        """Test that rit_managed config values are preserved verbatim."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "rit_managed_locations:\n"
            "  server1: ~/server1/output\n"
            "  Promethion_1: $TEST_ROOT/prom/output\n"
            "rit_managed_folder_structure:\n"
            "  sh_output: scripts/out/\n"
        )

        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("TEST_ROOT", "/tmp/test-root")

        cfg = config.Config()

        assert cfg.get_rit_managed_location('server1') == "~/server1/output"
        assert cfg.get_rit_managed_location('Promethion_1') == "$TEST_ROOT/prom/output"
        assert cfg.get_rit_managed_path('server1', 'sh_output') == "~/server1/output/scripts/out/"

    def test_resolve_managed_file_path_from_filename(self, tmp_path, monkeypatch):
        """Test resolving a filename against a system-specific managed directory."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "rit_managed_locations:\n"
            "  server1: /srv/rit\n"
            "rit_managed_folder_structure:\n"
            "  log: log/\n"
        )

        monkeypatch.chdir(tmp_path)
        cfg = config.Config()

        assert cfg.resolve_managed_file_path('server1', 'test.log', 'log') == '/srv/rit/log/test.log'

    def test_resolve_managed_file_path_preserves_explicit_path(self, tmp_path, monkeypatch):
        """Test resolving leaves explicit paths unchanged."""
        monkeypatch.chdir(tmp_path)
        cfg = config.Config()

        assert cfg.resolve_managed_file_path('server1', '$HOME/test.log', 'log') == '$HOME/test.log'

    def test_get_flock_path_default_and_override(self, tmp_path, monkeypatch):
        """Test per-system flock path override with default fallback."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "flock_paths:\n"
            "  server1: /opt/bin/flock\n"
        )

        monkeypatch.chdir(tmp_path)
        cfg = config.Config()

        assert cfg.get_flock_path('server1') == '/opt/bin/flock'
        assert cfg.get_flock_path('other') == '/usr/bin/flock'

    def test_notifications_from_yaml_runtime_and_env(self, tmp_path, monkeypatch):
        """Notification settings should merge YAML, runtime, and env overrides."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "notifications:\n"
            "  endpoint: https://yaml.example/events\n"
            "  token_env: YAML_TOKEN\n"
            "  title: YAML title\n"
            "  body: YAML body\n"
            "  timeout_seconds: 9\n"
        )

        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("LZ_NOTIFICATION_ENDPOINT", "https://env.example/events")
        cfg = config.Config()
        cfg.load_config(notifications={
            'body': 'Runtime body',
            'status_file': 'notifications.tsv',
        })

        assert cfg.notifications['endpoint'] == 'https://env.example/events'
        assert cfg.notifications['token_env'] == 'YAML_TOKEN'
        assert cfg.notifications['title'] == 'YAML title'
        assert cfg.notifications['body'] == 'Runtime body'
        assert cfg.notifications['timeout_seconds'] == '9'
        assert cfg.notifications['status_file'] == 'notifications.tsv'


class TestLoadConfig:
    """Test the Config.load_config method"""
    
    def test_load_config_applies_values(self, tmp_path, monkeypatch):
        """Test that load_config applies values from config file"""
        config_file = tmp_path / "custom.yaml"
        config_file.write_text("log_dir: custom_log_dir\n")
        
        monkeypatch.chdir(tmp_path)
        
        cfg = config.Config()
        cfg.load_config(config_file=str(config_file))
        
        assert cfg.log_dir == 'custom_log_dir'
    
    def test_load_config_with_overrides(self, tmp_path, monkeypatch):
        """Test that load_config accepts override values"""
        monkeypatch.chdir(tmp_path)
        
        cfg = config.Config()
        cfg.load_config(log_dir='override_log')
        
        assert cfg.log_dir == 'override_log'

    def test_load_config_file_resets_previous_runtime_overrides(self, tmp_path, monkeypatch):
        """Loading a new config file should not keep stale runtime overrides."""
        config_file = tmp_path / "config.yaml"
        transfers_file = tmp_path / "from_yaml.tsv"
        config_file.write_text(
            "transfers_file: {0}\n"
            "runtime_ids:\n"
            "  - yaml_runtime.local\n".format(transfers_file)
        )

        monkeypatch.chdir(tmp_path)

        cfg = config.Config()
        cfg.load_config(
            transfers_file="from_previous_call.tsv",
            runtime_ids=["old_runtime.local"],
        )
        cfg.load_config(config_file=str(config_file))

        assert cfg.transfers_file == str(transfers_file)
        assert cfg.runtime_ids == ["yaml_runtime.local"]

    def test_snapshot_and_restore_state(self, tmp_path, monkeypatch):
        """Snapshots should restore YAML-backed and runtime config state."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text(
            "log_dir: from_yaml\n"
            "output_dir: from_yaml_output\n"
        )

        monkeypatch.chdir(tmp_path)

        cfg = config.Config()
        snapshot = cfg.snapshot_state()

        cfg.load_config(log_dir='override_log', output_dir='override_output')
        assert cfg.log_dir == 'override_log'
        assert cfg.output_dir == 'override_output'

        cfg.restore_state(snapshot)
        assert cfg.log_dir == 'from_yaml'
        assert cfg.output_dir == 'from_yaml_output'
