from glotter.settings import get_settings
from glotter.source import filter_sources, get_sources


def run(args):
    sources_by_type = filter_sources(args, get_sources(get_settings().source_root))
    for project_type, sources in sources_by_type.items():
        params = _prompt_params(project_type)
        for source in sources:
            _build_and_run(source, params)


def _prompt_params(project_type):
    if not get_settings().projects[project_type].requires_parameters:
        return ""
    return input(f'input parameters for "{project_type}": ')


def _build_and_run(source, params):
    print()
    print(f'Running "{source.name}{source.extension}"...')
    try:
        source.build()
        print(source.run(params))
    finally:
        source.cleanup()
