"""Thin HTTP client for the Mindcase REST API."""

import asyncio
import os
import httpx

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BASE_URL = "https://api.mindcase.co/api/v1"
POLL_INTERVAL = 5  # seconds
MAX_POLL_TIME = 300  # 5 minutes


def _api_key() -> str:
    key = os.environ.get("MINDCASE_API_KEY", "")
    if not key:
        raise RuntimeError(
            "MINDCASE_API_KEY is not set. "
            "Add it to your .env file or set it as an environment variable."
        )
    return key


def _headers() -> dict:
    return {
        "Authorization": f"Bearer {_api_key()}",
        "Content-Type": "application/json",
        "User-Agent": "mindcase-mcp/0.1.0",
    }


def _handle_error(resp: httpx.Response) -> str:
    """Extract a readable error message from an HTTP error response."""
    try:
        body = resp.json()
        return body.get("detail", body.get("error", resp.text))
    except Exception:
        return resp.text


# ── Sync methods (used during startup for agent registration) ────────────────


def list_agents() -> list[dict]:
    """Fetch all agents. Public endpoint — no auth required."""
    resp = httpx.get(f"{BASE_URL}/agents/all", timeout=15)
    resp.raise_for_status()
    return resp.json().get("agents", [])


def get_agent(group: str, slug: str) -> dict:
    """Fetch agent details including parameter schema."""
    resp = httpx.get(f"{BASE_URL}/agents/{group}/{slug}", headers=_headers(), timeout=15)
    resp.raise_for_status()
    return resp.json()


# ── Async methods (used during tool execution) ──────────────────────────────


async def async_run_agent(group: str, slug: str, params: dict) -> dict:
    """Start an agent job. Returns job metadata."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            f"{BASE_URL}/agents/{group}/{slug}/run",
            headers=_headers(),
            json={"params": params},
        )
        if resp.status_code != 200:
            return {"status": "error", "error": _handle_error(resp)}
        return resp.json()


async def async_get_job(job_id: str) -> dict:
    """Get job status."""
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(f"{BASE_URL}/jobs/{job_id}", headers=_headers())
        resp.raise_for_status()
        return resp.json()


async def async_get_results(job_id: str) -> dict:
    """Get job results."""
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(f"{BASE_URL}/jobs/{job_id}/results", headers=_headers())
        resp.raise_for_status()
        return resp.json()


async def async_get_credits() -> float:
    """Get remaining credit balance."""
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(f"{BASE_URL}/credits", headers=_headers())
        resp.raise_for_status()
        return resp.json().get("credits_remaining", 0)


async def async_run_and_wait(group: str, slug: str, params: dict) -> dict:
    """Run an agent and poll until results are ready."""
    job = await async_run_agent(group, slug, params)

    if job.get("status") == "error":
        return job

    job_id = job.get("job_id")
    if not job_id:
        return {"status": "error", "error": "No job_id returned", "response": job}

    # Poll until done
    elapsed = 0
    while elapsed < MAX_POLL_TIME:
        status_resp = await async_get_job(job_id)
        status = status_resp.get("status", "unknown")

        if status == "completed":
            results = await async_get_results(job_id)
            results["job_id"] = job_id
            return results

        if status == "failed":
            return {
                "status": "failed",
                "error": status_resp.get("error_message", "Job failed"),
                "job_id": job_id,
            }

        if status == "cancelled":
            return {"status": "cancelled", "job_id": job_id}

        await asyncio.sleep(POLL_INTERVAL)
        elapsed += POLL_INTERVAL

    return {"status": "error", "error": f"Job {job_id} timed out after {MAX_POLL_TIME}s"}
