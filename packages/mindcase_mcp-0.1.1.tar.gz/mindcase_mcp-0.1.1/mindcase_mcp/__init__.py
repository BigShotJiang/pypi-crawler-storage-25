"""Mindcase MCP Server — exposes 30+ data collection agents as Claude tools."""
