"""Mindcase MCP Server — exposes 30+ data collection agents as Claude tools."""

import json
import logging
import time
from mcp.server.fastmcp import FastMCP

from mindcase_mcp import api_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("mindcase-mcp")

mcp = FastMCP(
    "mindcase",
    instructions=(
        "Mindcase provides 30+ data collection agents for scraping structured data "
        "from LinkedIn, Instagram, Google Maps, Amazon, YouTube, and more. "
        "Use list_agents to discover available agents and get_agent_details to see "
        "required parameters before running an agent."
    ),
)

# ── Utility tools ────────────────────────────────────────────────────────────


@mcp.tool()
async def list_agents(group: str | None = None) -> str:
    """List all available Mindcase data collection agents.

    Args:
        group: Optional platform filter (e.g. "linkedin", "instagram", "amazon").
               If omitted, returns all agents across all platforms.
    """
    agents = api_client.list_agents()

    if group:
        agents = [a for a in agents if a["group"] == group]

    if not agents:
        return f"No agents found{f' for group {group!r}' if group else ''}."

    lines = []
    current_group = None
    for a in agents:
        if a["group"] != current_group:
            current_group = a["group"]
            lines.append(f"\n## {current_group}")
        lines.append(
            f"  - **{a['name']}** (`{a['group']}/{a['slug']}`) — "
            f"{a['description'][:80]}... [{a['credits_per_row']} cr/row]"
        )

    return f"**{len(agents)} agents available:**\n" + "\n".join(lines)


@mcp.tool()
async def check_credits() -> str:
    """Check remaining Mindcase credit balance."""
    try:
        credits = await api_client.async_get_credits()
        return f"**{credits:,.1f}** credits remaining."
    except Exception as e:
        return f"Error checking credits: {e}"


@mcp.tool()
async def get_agent_details(agent_path: str) -> str:
    """Get full details and required parameters for a specific agent.

    Args:
        agent_path: Agent identifier in "group/slug" format (e.g. "instagram/profiles", "google-maps/businesses").
    """
    parts = agent_path.split("/", 1)
    if len(parts) != 2:
        return f"Invalid agent path: {agent_path!r}. Use format 'group/slug'."

    group, slug = parts
    try:
        agent = api_client.get_agent(group, slug)
    except Exception as e:
        return f"Agent {agent_path!r} not found: {e}"

    lines = [
        f"## {agent.get('name', agent_path)}",
        f"**Path:** `{group}/{slug}`",
        f"**Description:** {agent.get('description', '')}",
        f"**Credits:** {agent.get('credits_per_row', '?')} per row",
        "",
        "### Parameters:",
    ]

    params = agent.get("parameters", {})
    for name, info in params.items():
        req = "required" if info.get("required") else "optional"
        ptype = info.get("type", "string")
        desc = info.get("description", "")
        default = info.get("default")
        line = f"  - `{name}` ({ptype}, {req}): {desc}"
        if default is not None:
            line += f" [default: {default}]"
        lines.append(line)

    if not params:
        lines.append("  No parameters documented.")

    return "\n".join(lines)


# ── Dynamic agent tools ──────────────────────────────────────────────────────


def _format_results(results: dict, max_rows: int = 10) -> str:
    """Format API results into a readable string for Claude."""
    status = results.get("status", "unknown")

    if status in ("error", "failed"):
        return f"**Error:** {results.get('error', 'Unknown error')}"

    if status == "cancelled":
        return f"**Job cancelled.** Job ID: {results.get('job_id')}"

    data = results.get("data", [])
    row_count = results.get("row_count", len(data))
    credits_used = results.get("credits_used", "?")
    job_id = results.get("job_id", "?")

    if not data:
        return f"**No results returned.** Job ID: {job_id}"

    columns = list(data[0].keys())

    lines = [
        f"**{row_count} rows** collected | **{credits_used} credits** used | Job: `{job_id}`",
        "",
    ]

    show = data[:max_rows]
    # Limit to 6 columns for readability
    show_cols = columns[:6]
    lines.append("| " + " | ".join(show_cols) + " |")
    lines.append("| " + " | ".join(["---"] * len(show_cols)) + " |")

    for row in show:
        vals = [str(row.get(c, ""))[:40] for c in show_cols]
        lines.append("| " + " | ".join(vals) + " |")

    if row_count > max_rows:
        lines.append(f"\n*Showing {max_rows} of {row_count} rows.*")

    if len(columns) > 6:
        lines.append(f"\n*Showing 6 of {len(columns)} columns: {', '.join(columns)}*")

    return "\n".join(lines)


def _make_tool_name(group: str, slug: str) -> str:
    """Convert group/slug to valid MCP tool name."""
    return f"{group}_{slug}".replace("-", "_")


def _register_agent_tool(agent: dict, params_schema: dict) -> None:
    """Register a single agent as an MCP tool."""
    group = agent["group"]
    slug = agent["slug"]
    tool_name = _make_tool_name(group, slug)
    description = (
        f"{agent['name']}: {agent['description']} "
        f"[{agent.get('credits_per_row', '?')} credits/row]"
    )

    # Build JSON schema for tool inputs
    properties = {}
    required = []

    for param_name, param_info in params_schema.items():
        prop: dict = {"description": param_info.get("description", "")}

        ptype = param_info.get("type", "string")
        if ptype == "array":
            prop["type"] = "array"
            prop["items"] = {"type": "string"}
        elif ptype == "integer":
            prop["type"] = "integer"
        elif ptype == "boolean":
            prop["type"] = "boolean"
        else:
            prop["type"] = "string"

        if "enum" in param_info:
            prop["enum"] = param_info["enum"]
        if "default" in param_info:
            prop["default"] = param_info["default"]

        properties[param_name] = prop
        if param_info.get("required"):
            required.append(param_name)

    input_schema = {
        "type": "object",
        "properties": properties,
        "required": required,
    }

    # Capture group/slug in closure
    _group, _slug = group, slug

    # Build a function with a proper signature so FastMCP validates correctly.
    # We create a wrapper that accepts a single `params` JSON string,
    # since dynamic Python signatures are fragile.
    async def _run(params: str = "{}") -> str:
        """params: JSON string of agent parameters. E.g. '{"usernames": ["nike"]}'"""
        try:
            parsed = json.loads(params) if isinstance(params, str) else params
            results = await api_client.async_run_and_wait(_group, _slug, parsed)
            return _format_results(results)
        except json.JSONDecodeError:
            return f"**Error:** Invalid JSON in params: {params}"
        except Exception as e:
            return f"**Error running {_group}/{_slug}:** {e}"

    # Register tool
    mcp.tool(
        name=tool_name,
        description=description + f"\n\nAccepts a JSON string with these parameters:\n{json.dumps(input_schema['properties'], indent=2)}\nRequired: {', '.join(required) if required else 'none'}",
        annotations={"readOnlyHint": True},
    )(_run)


def _register_all_agents() -> None:
    """Fetch all agents from the API and register them as MCP tools."""
    try:
        agents = api_client.list_agents()
        logger.info(f"Fetched {len(agents)} agents from API")
    except Exception as e:
        logger.error(f"Failed to fetch agents: {e}")
        return

    for i, agent in enumerate(agents):
        group = agent["group"]
        slug = agent["slug"]
        try:
            details = api_client.get_agent(group, slug)
            params = details.get("parameters", {})
            _register_agent_tool(agent, params)
            logger.info(f"Registered tool: {_make_tool_name(group, slug)}")
            # Respect rate limits during registration
            if (i + 1) % 5 == 0:
                time.sleep(1)
        except Exception as e:
            logger.warning(f"Skipped {group}/{slug}: {e}")

    logger.info(f"MCP server ready with {len(mcp._tool_manager._tools)} tools")


# ── Startup ──────────────────────────────────────────────────────────────────

_register_all_agents()

if __name__ == "__main__":
    mcp.run()
