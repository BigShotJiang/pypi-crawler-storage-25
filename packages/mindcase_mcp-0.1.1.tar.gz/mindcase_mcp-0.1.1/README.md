# Mindcase MCP Server

[![PyPI](https://img.shields.io/pypi/v/mindcase-mcp)](https://pypi.org/project/mindcase-mcp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-black.svg)](https://opensource.org/licenses/MIT)

MCP server for [Mindcase](https://mindcase.co) — access 30+ data collection agents from Claude. Scrape LinkedIn, Instagram, Google Maps, Amazon, YouTube, and more with natural language.

## Features

- **30+ data agents** across LinkedIn, Instagram, Amazon, Google Maps, YouTube, and more
- **Natural language** — just ask Claude, no code or parameters to learn
- **Works everywhere** — Claude Code, Claude Desktop, Cursor, Windsurf
- **Auto-discovery** — agents register automatically on startup
- **Structured results** — get tables, not raw text
- **Credit tracking** — check your balance anytime

## Quick Start

### 1. Get an API key

Sign up at [app.mindcase.co](https://app.mindcase.co) and create an API key in the API Console.

### 2. Add to Claude

**Claude Code (CLI):**
```bash
claude mcp add mindcase -- uvx mindcase-mcp
```

Then set your API key:
```bash
export MINDCASE_API_KEY=mk_live_your_api_key_here
```

**Claude Desktop:**

Add to your config (`~/Library/Application Support/Claude/claude_desktop_config.json` on Mac, `%APPDATA%\Claude\claude_desktop_config.json` on Windows):

```json
{
  "mcpServers": {
    "mindcase": {
      "command": "uvx",
      "args": ["mindcase-mcp"],
      "env": {
        "MINDCASE_API_KEY": "mk_live_your_api_key_here"
      }
    }
  }
}
```

### 3. Use it

Ask Claude things like:
- "Find coffee shops in Manhattan with ratings above 4.5"
- "Search LinkedIn for AI startups in San Francisco"
- "Get Instagram profiles for Nike, Adidas, and Puma"
- "Scrape Amazon reviews for this product"
- "Find Python developer jobs on Indeed in New York"

## Available Tools

### Utility Tools

| Tool | Description |
|------|-------------|
| `list_agents` | Browse all 30+ available data agents |
| `check_credits` | Check your remaining credit balance |
| `get_agent_details` | View parameters and pricing for a specific agent |

### Data Collection Tools

All agents from the Mindcase API are registered as individual tools:

| Platform | Tools |
|----------|-------|
| **LinkedIn** | Profiles, Companies, Employees, Jobs, Posts, People Search, Company Search, Domain Lookup |
| **Instagram** | Profiles, Posts, Comments |
| **YouTube** | Videos, Channels, Comments, Shorts |
| **Amazon** | Products, Reviews, Bestsellers, India Products |
| **Google Maps** | Businesses, Reviews, Reverse Geocoding |
| **Twitter / X** | Posts |
| **TikTok** | Profiles |
| **Reddit** | Posts |
| **Shopify** | Products |
| **Indeed** | Jobs |
| **App Store** | Reviews |
| **Flipkart** | Products |
| **Myntra** | Products |

Each tool accepts the agent's specific parameters and returns structured data in a table format.

## How It Works

1. On startup, the server fetches all available agents from the Mindcase API
2. Each agent is registered as an MCP tool with its parameter schema
3. When Claude calls a tool, the server runs the agent via the API
4. The server polls for results and returns structured data to Claude

## Configuration

| Environment Variable | Description | Required |
|---------------------|-------------|----------|
| `MINDCASE_API_KEY` | Your Mindcase API key (`mk_live_...`) | Yes |

## Documentation

- [Mindcase API Docs](https://docs.mindcase.co)
- [Agent Reference](https://docs.mindcase.co/agents-overview)
- [Python SDK](https://pypi.org/project/mindcase/)
- [Node.js SDK](https://www.npmjs.com/package/mindcase)

## Also Available

- **[Python SDK](https://pypi.org/project/mindcase/)** — `pip install mindcase` for programmatic access
- **[Node.js SDK](https://www.npmjs.com/package/mindcase)** — `npm install mindcase` for JavaScript/TypeScript

## Privacy

See [privacy-policy.md](privacy-policy.md) for details on data handling.

## License

MIT

<!-- mcp-name: io.github.mindcase-co/mindcase -->
