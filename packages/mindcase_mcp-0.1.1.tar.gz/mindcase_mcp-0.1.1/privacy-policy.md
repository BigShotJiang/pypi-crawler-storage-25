# Mindcase MCP Server — Privacy Policy

**Last updated:** April 2026

## What this server does

The Mindcase MCP server connects Claude to the Mindcase API, enabling data collection from public web sources (LinkedIn, Instagram, Google Maps, Amazon, etc.). When you use a Mindcase tool through Claude, the server sends your query parameters to the Mindcase API and returns structured results.

## Data collection

- **API key**: Your Mindcase API key is stored locally as an environment variable. It is never sent to Anthropic or any third party — only to `api.mindcase.co`.
- **Query parameters**: The search terms and filters you provide (e.g., "coffee shops in Manhattan") are sent to the Mindcase API to execute the data collection job.
- **Results**: Collected data is returned to Claude and displayed in your conversation. Mindcase does not store conversation context.

## Data storage

- **Job history**: Mindcase retains job metadata (agent used, parameters, row count, credits used) for billing and usage tracking. See [Mindcase Terms of Service](https://mindcase.co/terms) for retention details.
- **No conversation data**: The MCP server does not log or store your Claude conversations.

## Third-party sharing

- Data is not shared with third parties beyond what is necessary to execute the data collection (e.g., the underlying web platforms being scraped).
- No advertising or analytics trackers are used by the MCP server.

## Data sources

Mindcase collects publicly available data from web platforms. Users are responsible for ensuring their use of collected data complies with applicable laws and platform terms of service.

## Contact

For privacy questions: team@mindcase.co
