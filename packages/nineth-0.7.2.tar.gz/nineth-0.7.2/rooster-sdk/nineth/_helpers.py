"""Internal payload, error, SSE, and response-shaping helpers.

Responsibilities in this module:

- normalize request payload fields (services, callback wiring, messaging)
    - includes default-service alias expansion and deduplication
    - includes callback_url propagation into include-service and inbound templates
    - includes messaging-driven auto-enable rules for email/telegram services
- sanitize and mask provider-facing errors for stable SDK exceptions
- parse SSE frames into structured events
- trim server payloads to the public SDK response shape
- coerce JSON response mode when callers request ``response_format='json'``

Not part of the public API contract.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, Iterator, List, Optional, Union

import httpx


# ---------------------------------------------------------------------------
# Payload builder
# ---------------------------------------------------------------------------

_EMAIL_MESSAGING_SERVICE_NAMES = ["send_email", "send_reply"]
_TELEGRAM_MESSAGING_SERVICE_NAMES = [
    "send_message",
    "edit_message",
    "edit_message_caption",
    "send_photo",
    "send_voice",
]
_DEFAULT_SERVICE_ALIAS_GROUPS = {
    "browser": [
        "search_web",
        "search_news",
        "search_discussions",
        "search_unified",
        "search_context",
        "search_places",
        "search_local_pois",
        "search_poi_descriptions",
        "search_rich",
        "search_videos",
        "search_images",
        "search_answers",
        "read",
        "deepsearch",

    ],
    "knowledge": [
        "list_documents",
        "read_document_metadata",
        "search_documents",
        "read_document",
        "read_document_markdown",
        "search_knowledge",
        "journal_read",
        "journal_list",
        "journal_search",
        "memory_read",
        "media_list",
        "media_recall",
        "media_search",
        "media_read_manifest",
    ],
    "computer": [
        "create_sandbox",
        "sandbox_status",
        "run",
        "destroy_sandbox",
        "sandbox",
        "volume_write_file",
        "volume_read_file",
        "volume_search_replace",
        "volume_list",
        "create_scratch",
        "write_scratch",
        "read_scratch",
        "list_scratches",
        "search_scratches",
        "delete_scratch",
        "index_document",
        "delete_document",
        "journal_write",
        "journal_search_replace",
        "journal_delete",
        "media_write_manifest",
        "media_write_transcript",
        "media_update",
        "media_decompress",
        "media_delete",
        "set_alarm",
        "schedule_at",
        "get_current_time",
        "cancel_alarm",
        "set_plan",
        "get_plan",
        "update_plan",
        "clear_plan",
    ],
    "workspace": [
        "gh_clone",
        "gh_new",
        "gh_run",
        "gh_commit",
        "gh_push",
        "gh_pull",
        "gh_branch",
        "gh_status",
        "gh_pr",
        "gh_list",
    ],
    "voice": [
        "voice_list",
        "voice_generate",
        "voice_transcribe",
    ],
    "trading": [
        "fund_balances",
        "data_get_current_price",
        "data_get_historical_ohlc",
        "data_get_market_buffer",
        "data_get_live_ticks",
        "data_get_available_symbols",
        "portfolio_list",
        "portfolio_add",
        "portfolio_update",
        "portfolio_remove",
        "performance",
        "initialize_client",
        "get_terminal_status",
        "get_account_snapshot",
        "get_open_positions",
        "get_pending_orders",
        "get_closed_orders",
        "get_available_symbols",
        "get_current_price",
        "get_historical_ohlc",
        "get_live_ticks",
        "get_market_buffer",
        "trade_market_buy",
        "trade_market_sell",
        "trade_buy_limit",
        "trade_sell_limit",
        "trade_buy_stop",
        "trade_sell_stop",
        "trade_buy_stop_limit",
        "trade_sell_stop_limit",
        "trade_modify_position",
        "trade_close_position_partial",
        "trade_close_position_full",
        "trade_close_position_by_opposite",
        "trade_cancel_order",
    ],
    "shop": [
        "shop_apply",
        "shop_read",
        "shop_patch",
        "shop_delete",
        "shop_list",
        "shop_status",
        "shop_stop",
        "shop_start",
        "shop_restart",
        "shop_scaffold",
        "shop_glossary",
    ],
}
_SDK_PROVIDER_NAME_PATTERN = re.compile(r"\b(?:together(?:\s+ai)?|ollama|resend|telegram)\b", flags=re.IGNORECASE)
_SDK_URL_PATTERN = re.compile(r"https?://\S+|www\.\S+", flags=re.IGNORECASE)


def _normalize_messaging_payload(messaging: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not isinstance(messaging, dict):
        return None

    normalized: Dict[str, Any] = {}
    for key in ("email", "telegram"):
        value = messaging.get(key)
        if isinstance(value, dict):
            cleaned = {item_key: item_value for item_key, item_value in value.items() if item_value is not None}
            if cleaned:
                normalized[key] = cleaned
    return normalized or None


def _normalize_callback_url(value: Optional[str]) -> Optional[str]:
    text = str(value or "").strip()
    return text or None


def _normalize_vcache(value: Optional[Dict[str, Any]]) -> Optional[Dict[str, str]]:
    if not isinstance(value, dict):
        return None

    name = str(value.get("name") or value.get("cache_name") or "").strip()
    cache_id = str(value.get("cache_id") or value.get("cacheId") or value.get("id") or "").strip()
    if not name or not cache_id:
        return None
    return {"name": name, "cache_id": cache_id}


def _apply_callback_url_to_messaging(
    messaging: Optional[Dict[str, Any]],
    callback_url: Optional[str],
) -> Optional[Dict[str, Any]]:
    if not isinstance(messaging, dict) or not callback_url:
        return messaging

    email_messaging = messaging.get("email")
    if not isinstance(email_messaging, dict):
        return messaging

    templates = email_messaging.get("templates")
    if not isinstance(templates, list):
        return messaging

    changed = False
    updated_templates: List[Any] = []
    for template in templates:
        if not isinstance(template, dict):
            updated_templates.append(template)
            continue
        existing_url = str(template.get("url") or "").strip()
        if not existing_url:
            updated = dict(template)
            updated["url"] = callback_url
            updated_templates.append(updated)
            changed = True
            continue
        updated_templates.append(template)

    if not changed:
        return messaging

    updated_messaging = dict(messaging)
    updated_email = dict(email_messaging)
    updated_email["templates"] = updated_templates
    updated_messaging["email"] = updated_email
    return updated_messaging


def _merge_service_names(
    existing: Optional[List[str]],
    required: List[str],
) -> List[str]:
    merged: List[str] = []
    seen = set()
    for raw_name in (existing or []) + required:
        name = str(raw_name).strip()
        if not name or name in seen:
            continue
        seen.add(name)
        merged.append(name)
    return merged


def _expand_default_service_names(default_service: List[str]) -> List[str]:
    expanded: List[str] = []
    seen = set()

    for raw_name in default_service:
        name = str(raw_name).strip()
        if not name:
            continue

        alias_key = name.lower().replace("-", "_").replace(" ", "_")
        if alias_key == "search":
            alias_key = "browser"
        members = _DEFAULT_SERVICE_ALIAS_GROUPS.get(alias_key)
        if members:
            for member in members:
                if member in seen:
                    continue
                seen.add(member)
                expanded.append(member)
            continue

        if name in seen:
            continue
        seen.add(name)
        expanded.append(name)

    return expanded


def _should_auto_enable_email_services(email_messaging: Optional[Dict[str, Any]]) -> bool:
    if not isinstance(email_messaging, dict):
        return False

    templates = email_messaging.get("templates")
    if not isinstance(templates, list) or not templates:
        return True

    has_outbound_templates = any(
        isinstance(template, dict) and str(template.get("type") or "").strip().lower() == "outbound"
        for template in templates
    )
    return has_outbound_templates

def _build_payload(
    task_input: str,
    model: str,
    *,
    max_iterations: int,
    reasoning: Optional[str],
    temperature: Optional[float],
    top_p: Optional[float],
    min_p: Optional[float],
    top_k: Optional[int],
    repetition_penalty: Optional[float],
    presence_penalty: Optional[float],
    frequency_penalty: Optional[float],
    seed: Optional[int],
    show_reasoning: bool,
    images: Optional[List[str]],
    audio: Optional[List[Any]],
    policy: Optional[str],
    guardrail: Optional[str],
    continuous: Optional[bool] = None,
    session: bool = False,
    process_id: Optional[str] = None,
    vcache: Optional[Dict[str, Any]] = None,
    base_system: bool = True,
    default_service: Union[bool, List[str]] = False,
    include_service: Optional[Union[List[Any], Dict[str, Any]]] = None,
    client_service_results: Optional[List[Dict[str, Any]]] = None,
    verbose: bool = False,
    response_format: str = "text",
    compute: bool = False,
    messaging: Optional[Dict[str, Any]] = None,
    callback_url: Optional[str] = None,
) -> Dict[str, Any]:
    normalized_vcache = _normalize_vcache(vcache)
    if process_id and not session and not client_service_results:
        raise ValueError("process_id requires session=True.")

    normalized_callback_url = _normalize_callback_url(callback_url)
    normalized_messaging = _normalize_messaging_payload(messaging)
    normalized_messaging = _apply_callback_url_to_messaging(normalized_messaging, normalized_callback_url)

    if isinstance(default_service, bool):
        services_enabled = default_service
        service_names = None
    else:
        service_names = _expand_default_service_names(default_service)
        services_enabled = bool(service_names)
        service_names = service_names or None

    if normalized_messaging:
        required_services: List[str] = []
        if _should_auto_enable_email_services(normalized_messaging.get("email")):
            required_services.extend(_EMAIL_MESSAGING_SERVICE_NAMES)
        if normalized_messaging.get("telegram"):
            required_services.extend(_TELEGRAM_MESSAGING_SERVICE_NAMES)

        if required_services:
            if service_names is None and isinstance(default_service, bool):
                if not services_enabled:
                    service_names = list(required_services)
                    services_enabled = True
            else:
                service_names = _merge_service_names(service_names, required_services)
                services_enabled = True

    include_service_values: Optional[Union[List[Any], Dict[str, Any]]] = None
    if include_service:
        if isinstance(include_service, dict):
            callback_value = include_service.get("callback")
            callback_url = ""
            if isinstance(callback_value, dict):
                callback_url = str(callback_value.get("url") or "").strip()
            elif callback_value is True:
                callback_url = ""
            elif callback_value is not False and callback_value is not None:
                callback_url = str(callback_value).strip()

            schema_values = include_service.get("schema")
            if schema_values is None:
                schema_values = include_service.get("schemas")
            if schema_values is None:
                schema_values = []
            if not isinstance(schema_values, list):
                schema_values = [schema_values]

            seen_paths = set()
            seen_client_services = set()
            normalized_schemas: List[Any] = []
            for raw_item in schema_values:
                if isinstance(raw_item, dict):
                    name = str(raw_item.get("name", "")).strip()
                    if not name or name in seen_client_services:
                        continue
                    seen_client_services.add(name)
                    normalized_schemas.append(raw_item)
                    continue

                path = str(raw_item).strip()
                if not path or path in seen_paths:
                    continue
                seen_paths.add(path)
                normalized_schemas.append(path)

            if callback_value is False:
                include_service_values = {
                    "callback": False,
                    "schema": normalized_schemas,
                }
            else:
                include_service_values = {}
                if not callback_url and normalized_callback_url:
                    callback_url = normalized_callback_url

                if callback_url:
                    include_service_values["callback"] = {"url": callback_url}
                if normalized_schemas:
                    include_service_values["schema"] = normalized_schemas
                if not include_service_values:
                    include_service_values = None
        else:
            seen_paths = set()
            seen_client_services = set()
            include_service_values_list: List[Any] = []
            for raw_item in include_service:
                if isinstance(raw_item, dict):
                    name = str(raw_item.get("name", "")).strip()
                    if not name or name in seen_client_services:
                        continue
                    seen_client_services.add(name)
                    include_service_values_list.append(raw_item)
                    continue

                path = str(raw_item).strip()
                if not path or path in seen_paths:
                    continue
                seen_paths.add(path)
                include_service_values_list.append(path)
            if include_service_values_list and normalized_callback_url:
                include_service_values = {
                    "callback": {"url": normalized_callback_url},
                    "schema": include_service_values_list,
                }
            else:
                include_service_values = include_service_values_list or None

    payload: Dict[str, Any] = {
        "task_input": task_input,
        "model": model,
        "max_iterations": max_iterations,
        "show_reasoning": show_reasoning,
        "continuous": continuous if continuous is not None else (max_iterations > 10),
        "session": bool(session),
        "base_system": bool(base_system),
        "default_service": service_names if service_names else services_enabled,
        "verbose": verbose,
    }
    if reasoning is not None:
        payload["reasoning_effort"] = reasoning
    if temperature is not None:
        payload["temperature"] = temperature
    if top_p is not None:
        payload["top_p"] = top_p
    if min_p is not None:
        payload["min_p"] = min_p
    if top_k is not None:
        payload["top_k"] = top_k
    if repetition_penalty is not None:
        payload["repetition_penalty"] = repetition_penalty
    if presence_penalty is not None:
        payload["presence_penalty"] = presence_penalty
    if frequency_penalty is not None:
        payload["frequency_penalty"] = frequency_penalty
    if seed is not None:
        payload["seed"] = seed
    if include_service_values:
        payload["include_service"] = include_service_values
    if client_service_results:
        payload["client_service_results"] = client_service_results
    if images:
        payload["images"] = images
    if audio:
        payload["audio"] = audio
    if policy:
        payload["policy"] = policy
    if guardrail:
        payload["guardrail"] = guardrail
    if normalized_messaging:
        payload["messaging"] = normalized_messaging
    if normalized_callback_url:
        payload["callback_url"] = normalized_callback_url
    if str(response_format or "text").strip().lower() == "json":
        payload["response_format"] = "json"
    if compute:
        payload["compute"] = True
    if process_id:
        payload["process_id"] = process_id
    if normalized_vcache:
        payload["vcache"] = normalized_vcache
    return payload


# ---------------------------------------------------------------------------
# Error helpers
# ---------------------------------------------------------------------------

def _sanitize_sdk_error_text(message: str) -> str:
    text = str(message or "")
    text = _SDK_URL_PATTERN.sub("", text)
    text = _SDK_PROVIDER_NAME_PATTERN.sub("tooig", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip(" \n\t:;,-")

def _mask_model_unavailable_error(
    message: str,
    *,
    model: Optional[str],
    status_code: Optional[int] = None,
) -> str:
    original_text = (message or "").strip()
    text = _sanitize_sdk_error_text(original_text)
    lowered = original_text.lower()
    is_subscription_error = (
        "requires a subscription" in lowered
        or "upgrade for access" in lowered
        or "unable to access model" in lowered
        or "please visit https://api.together.ai/models to view the list of supported models." in lowered
        or "you (district) have reached your weekly usage limit, upgrade for higher limits: (ref: a0342a0c-31f8-42a1-8c25-9ffafaa0e5e4) (status code: 429)" in lowered
        or "credit limit exceeded" in lowered
    )

    if not is_subscription_error:
        return text or "Request failed."
    if status_code is not None and status_code != 403:
        return text or "Request failed."
    resolved_model = model or "unknown"
    return f"model {resolved_model} is currently unavailable. [err_hint]: oom."


def _read_error_response_text(response: httpx.Response) -> str:
    try:
        body = response.read()
    except Exception:
        body = b""

    if body:
        try:
            return body.decode().strip()
        except UnicodeDecodeError:
            return body.decode(errors="replace").strip()

    try:
        return response.text.strip()
    except Exception:
        return ""

def _raise_for_status(response: httpx.Response, *, model: Optional[str] = None) -> None:
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        from nineth.client import NinethAPIError
        message = _read_error_response_text(response) or str(exc)
        message = _mask_model_unavailable_error(
            message,
            model=model,
            status_code=response.status_code,
        )
        raise NinethAPIError(message) from exc


def _raise_for_stream_event(event: Dict[str, Any], *, model: Optional[str] = None) -> None:
    if event.get("type") != "error":
        return
    from nineth.client import NinethAPIError
    data = event.get("data", {})
    if isinstance(data, dict):
        message = data.get("message") or data.get("error") or "Streaming request failed."
    else:
        message = str(data) or "Streaming request failed."
    message = _mask_model_unavailable_error(message, model=model)
    raise NinethAPIError(message)


# ---------------------------------------------------------------------------
# SSE parser
# ---------------------------------------------------------------------------

def _parse_sse_lines(lines: Iterator[str]) -> Iterator[Dict[str, Any]]:
    event_type = "message"
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line.rstrip("\r")
        if not line:
            if data_lines:
                payload = json.loads("\n".join(data_lines))
                payload.setdefault("type", event_type)
                yield payload
            event_type = "message"
            data_lines = []
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_type = line.split(":", 1)[1].strip()
            continue
        if line.startswith("data:"):
            data_lines.append(line.split(":", 1)[1].strip())

    if data_lines:
        payload = json.loads("\n".join(data_lines))
        payload.setdefault("type", event_type)
        yield payload


# ---------------------------------------------------------------------------
# Response trimming
# ---------------------------------------------------------------------------

_BUFFERED_KEEP = {
    "final_response", "iterations", "thinking",
    "service_calls", "service_responses", "artifacts", "usage", "events", "compute",
    "process_id",
}

_CALLBACK_KEEP = _BUFFERED_KEEP | {"status", "pending_client_calls"}

_CALLBACK_CONTROL_EVENTS = {"accepted", "awaiting_client_services", "result"}
_PUBLIC_STREAM_EVENT_TYPES = {"accepted", "awaiting_client_services", "error", "model_delta", "result", "service_call", "service_response"}
_RAW_CLIENT_STREAM_EVENT_TYPES = {"client_service_call", "model_raw_delta"}


def _trim_response(body: Dict[str, Any], *, cache_enabled: bool = False) -> Dict[str, Any]:
    trimmed = {k: v for k, v in body.items() if k in _BUFFERED_KEEP}
    process_id = trimmed.pop("process_id", None)
    if cache_enabled and process_id:
        trimmed["session_id"] = process_id
    return trimmed


def _trim_callback_response(body: Dict[str, Any], *, cache_enabled: bool = False) -> Dict[str, Any]:
    trimmed = {k: v for k, v in body.items() if k in _CALLBACK_KEEP}
    process_id = trimmed.pop("process_id", None)
    if cache_enabled and process_id:
        trimmed["session_id"] = process_id
    elif process_id and body.get("status") == "awaiting_client_services":
        trimmed["process_id"] = process_id
    return trimmed


def _trim_event(
    event: Dict[str, Any],
    *,
    cache_enabled: bool = False,
    allow_raw_client_services: bool = False,
) -> Optional[Dict[str, Any]]:
    event_type = event.get("type")
    if event_type not in _PUBLIC_STREAM_EVENT_TYPES:
        if not allow_raw_client_services or event_type not in _RAW_CLIENT_STREAM_EVENT_TYPES:
            return None

    trimmed = dict(event)
    if trimmed.get("type") in {"model_delta", "model_raw_delta"}:
        data = trimmed.get("data") if isinstance(trimmed.get("data"), dict) else {}
        text = data.get("text", "")
        if not isinstance(text, str) or not text:
            return None

    process_id = trimmed.pop("process_id", None)
    if process_id and event.get("type") in _CALLBACK_CONTROL_EVENTS:
        trimmed["process_id"] = process_id
        if cache_enabled:
            trimmed["session_id"] = process_id
    elif cache_enabled and process_id:
        trimmed["session_id"] = process_id
    return trimmed


def _coerce_requested_response_format(
    body: Dict[str, Any],
    *,
    response_format: str = "text",
) -> Dict[str, Any]:
    if str(response_format or "text").strip().lower() != "json":
        return body

    final_response = body.get("final_response")
    if not isinstance(final_response, str):
        return body

    stripped = final_response.strip()
    if not stripped:
        return body

    try:
        parsed = json.loads(stripped)
    except Exception:
        return body

    updated = dict(body)
    updated["raw_response"] = final_response
    updated["final_response"] = parsed
    return updated


def _coerce_requested_response_event(
    event: Dict[str, Any],
    *,
    response_format: str = "text",
) -> Dict[str, Any]:
    if event.get("type") != "result":
        return event

    data = event.get("data") if isinstance(event.get("data"), dict) else None
    if data is None:
        return event

    updated = dict(event)
    updated["data"] = _coerce_requested_response_format(
        data,
        response_format=response_format,
    )
    return updated
