"""Public SDK exports for the nineth client package.

This module intentionally exposes only the stable caller-facing surface:

- ``NinethClient`` for synchronous requests
- ``AsyncNinethClient`` for asyncio applications
- ``AVAILABLE_MODELS`` for discoverable model aliases
- ``NinethAPIError`` for request/stream failures
"""

from .client import AVAILABLE_MODELS, AsyncNinethClient, NinethAPIError, NinethClient

try:
    from importlib.metadata import PackageNotFoundError, version
except ImportError:
    from importlib_metadata import PackageNotFoundError, version

__all__ = [
    "AsyncNinethClient",
    "AVAILABLE_MODELS",
    "NinethAPIError",
    "NinethClient",
]

try:
    __version__ = version("nineth")
except PackageNotFoundError:
    __version__ = "0.0.0"
