from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

import pytest
import torch


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
OVERLAY = SCRIPTS / "overlay"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from track_d_sisl_qwen_rung12_transition_residual_payload import (  # noqa: E402
    _payload_byte_report,
    _rule_key,
    _transition_keys,
    _transition_residual_mlp_intermediate,
)
from uc_ir.sisl0 import (  # noqa: E402
    CapsuleGates,
    EffectivenessMetrics,
    EfficiencyMetrics,
    SislCapsule,
)
from uc_ir.sisl0_ccb2_materialize import CCB2PayloadSet  # noqa: E402
from uc_ir.sisl0_ccb2_transition_residual import (  # noqa: E402
    TRANSITION_RESIDUAL_KIND,
    TRANSITION_RESIDUAL_SCHEMA,
    _unpack_int2_per_row,
    _unpack_int3_per_row,
    _unpack_int4_per_row,
    build_transition_residual_payload,
    load_transition_residual_payload,
    parse_transition_residual_spec,
    write_transition_residual_payload,
)


def _payloads() -> CCB2PayloadSet:
    basis = torch.tensor(
        [
            [1.0, 0.0],
            [0.0, 1.0],
            [1.0, 1.0],
        ],
        dtype=torch.float32,
    )
    active_masks = torch.tensor(
        [
            [
                [True, True, False, False],
                [False, True, False, True],
            ]
        ],
        dtype=torch.bool,
    )
    codes = torch.zeros((2, 1, 2, 2, 2), dtype=torch.float32)
    codes[0, 0, 1] = torch.tensor([[0.5, 0.25], [1.0, -0.5]])
    codes[1, 0, 1] = torch.tensor([[0.25, 0.5], [-0.25, 0.75]])
    metadata = {
        "active_fraction": 0.5,
        "K": 2,
        "k_active_per_layer": 2,
        "n_classes": 2,
        "n_layers": 1,
        "d_ff": 4,
        "d_model": 3,
        "matrix_types": ("gate", "up"),
        "route_schema": "route.v0",
        "route_classifier": "unit",
        "route_requested_n_classes": 2,
        "route_calibration_token_sha256": "a" * 64,
        "route_token_to_class_sha256": "b" * 64,
        "route_centers_sha256": "c" * 64,
    }
    return CCB2PayloadSet(
        basis=basis,
        active_masks=active_masks,
        codes=codes,
        matrix_types=("gate", "up"),
        metadata=metadata,
    )


def _model() -> SimpleNamespace:
    gate_weight = torch.tensor(
        [
            [0.0, 0.0, 0.0],
            [1.0, 2.0, 3.0],
            [0.0, 0.0, 0.0],
            [4.0, 5.0, 6.0],
        ],
        dtype=torch.float32,
    )
    up_weight = torch.zeros_like(gate_weight)
    mlp = SimpleNamespace(
        gate_proj=SimpleNamespace(weight=gate_weight),
        up_proj=SimpleNamespace(weight=up_weight),
        act_fn=torch.nn.Identity(),
    )
    return SimpleNamespace(model=SimpleNamespace(layers=[SimpleNamespace(mlp=mlp)]))


def test_parse_transition_residual_spec_validates_shape() -> None:
    spec = parse_transition_residual_spec("0:14:gate:11229:518")

    assert spec.layer_idx == 0
    assert spec.class_idx == 14
    assert spec.matrix_type == "gate"
    assert spec.prefix_token_id == 11229
    assert spec.target_token_id == 518
    with pytest.raises(ValueError, match="LAYER:CLASS:MATRIX:PREFIX:TARGET"):
        parse_transition_residual_spec("0:14:gate")


def test_build_and_load_transition_residual_payload_roundtrip(tmp_path: Path) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_dtype=torch.float32,
    )
    payload_path = tmp_path / "transition_residual.pt"

    write_transition_residual_payload(payload_path, payload)
    loaded = load_transition_residual_payload(
        payload_path,
        payloads,
        expected_model_id="unit-model",
        expected_base_capsule_sha256="d" * 64,
    )

    assert payload["schema"] == TRANSITION_RESIDUAL_SCHEMA
    assert payload["kind"] == TRANSITION_RESIDUAL_KIND
    assert len(loaded.rules) == 1
    rule = loaded.rules[0]
    assert rule.layer_idx == 0
    assert rule.class_idx == 1
    assert rule.matrix_type == "gate"
    assert rule.transition == (11229, 518)
    assert torch.equal(rule.row_indices, torch.tensor([1, 3]))
    expected_reconstructed = torch.tensor([[0.5, 0.25, 0.75], [1.0, -0.5, 0.5]])
    expected_source = torch.tensor([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
    assert torch.allclose(rule.residual, expected_source - expected_reconstructed)


def test_build_and_load_int8_transition_residual_payload_roundtrip(tmp_path: Path) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int8_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload_path = tmp_path / "transition_residual_int8.pt"

    write_transition_residual_payload(payload_path, payload)
    loaded = load_transition_residual_payload(
        payload_path,
        payloads,
        expected_model_id="unit-model",
        expected_base_capsule_sha256="d" * 64,
    )

    raw_rule = payload["rules"][0]
    assert payload["metadata"]["residual_encoding"] == "int8_per_row"
    assert payload["metadata"]["residual_dtype"] == "int8"
    assert raw_rule["residual_q"].dtype == torch.int8
    assert "residual" not in raw_rule
    rule = loaded.rules[0]
    expected_reconstructed = torch.tensor([[0.5, 0.25, 0.75], [1.0, -0.5, 0.5]])
    expected_source = torch.tensor([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
    assert rule.residual_encoding == "int8_per_row"
    assert rule.stored_residual_dtype == "int8"
    assert rule.residual_scale_dtype == "float16"
    assert torch.allclose(rule.residual, expected_source - expected_reconstructed, atol=0.03)


def test_build_and_load_int4_transition_residual_payload_roundtrip(tmp_path: Path) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int4_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload_path = tmp_path / "transition_residual_int4.pt"

    write_transition_residual_payload(payload_path, payload)
    loaded = load_transition_residual_payload(
        payload_path,
        payloads,
        expected_model_id="unit-model",
        expected_base_capsule_sha256="d" * 64,
    )

    raw_rule = payload["rules"][0]
    assert payload["metadata"]["residual_encoding"] == "int4_per_row"
    assert payload["metadata"]["residual_dtype"] == "int4_packed"
    assert raw_rule["residual_q_packed"].dtype == torch.uint8
    assert raw_rule["residual_q_packed"].shape == (2, 2)
    assert "residual" not in raw_rule
    assert "residual_q" not in raw_rule
    rule = loaded.rules[0]
    expected_reconstructed = torch.tensor([[0.5, 0.25, 0.75], [1.0, -0.5, 0.5]])
    expected_source = torch.tensor([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
    assert rule.residual_encoding == "int4_per_row"
    assert rule.stored_residual_dtype == "int4_packed"
    assert rule.residual_scale_dtype == "float16"
    assert torch.allclose(rule.residual, expected_source - expected_reconstructed, atol=0.16)


def test_build_and_load_int2_transition_residual_payload_roundtrip(tmp_path: Path) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int2_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload_path = tmp_path / "transition_residual_int2.pt"

    write_transition_residual_payload(payload_path, payload)
    loaded = load_transition_residual_payload(
        payload_path,
        payloads,
        expected_model_id="unit-model",
        expected_base_capsule_sha256="d" * 64,
    )

    raw_rule = payload["rules"][0]
    assert payload["metadata"]["residual_encoding"] == "int2_per_row"
    assert payload["metadata"]["residual_dtype"] == "int2_packed"
    assert raw_rule["residual_q_packed"].dtype == torch.uint8
    assert raw_rule["residual_q_packed"].shape == (2, 1)
    assert "residual" not in raw_rule
    assert "residual_q" not in raw_rule
    rule = loaded.rules[0]
    expected_reconstructed = torch.tensor([[0.5, 0.25, 0.75], [1.0, -0.5, 0.5]])
    expected_source = torch.tensor([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
    assert rule.residual_encoding == "int2_per_row"
    assert rule.stored_residual_dtype == "int2_packed"
    assert rule.residual_scale_dtype == "float16"
    assert torch.allclose(rule.residual, expected_source - expected_reconstructed, atol=2.6)


def test_build_and_load_int3_transition_residual_payload_roundtrip(tmp_path: Path) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int3_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload_path = tmp_path / "transition_residual_int3.pt"

    write_transition_residual_payload(payload_path, payload)
    loaded = load_transition_residual_payload(
        payload_path,
        payloads,
        expected_model_id="unit-model",
        expected_base_capsule_sha256="d" * 64,
    )

    raw_rule = payload["rules"][0]
    assert payload["metadata"]["residual_encoding"] == "int3_per_row"
    assert payload["metadata"]["residual_dtype"] == "int3_packed"
    assert raw_rule["residual_q_packed"].dtype == torch.uint8
    assert raw_rule["residual_q_packed"].shape == (2, 3)
    assert "residual" not in raw_rule
    assert "residual_q" not in raw_rule
    rule = loaded.rules[0]
    expected_reconstructed = torch.tensor([[0.5, 0.25, 0.75], [1.0, -0.5, 0.5]])
    expected_source = torch.tensor([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
    assert rule.residual_encoding == "int3_per_row"
    assert rule.stored_residual_dtype == "int3_packed"
    assert rule.residual_scale_dtype == "float16"
    assert torch.allclose(rule.residual, expected_source - expected_reconstructed, atol=0.67)


def test_residual_scale_multiplier_is_serialized_and_changes_scale() -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    base_payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int3_per_row",
        residual_scale_dtype=torch.float32,
    )
    scaled_payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int3_per_row",
        residual_scale_dtype=torch.float32,
        residual_scale_multiplier=1.5,
    )

    base_scale = base_payload["rules"][0]["residual_scale"]
    scaled_scale = scaled_payload["rules"][0]["residual_scale"]

    assert scaled_payload["metadata"]["residual_scale_multiplier"] == 1.5
    assert torch.allclose(scaled_scale, base_scale * 1.5)


def test_load_transition_residual_payload_rejects_non_integer_rows(tmp_path: Path) -> None:
    payloads = _payloads()
    raw = {
        "schema": TRANSITION_RESIDUAL_SCHEMA,
        "kind": TRANSITION_RESIDUAL_KIND,
        "metadata": {
            **payloads.metadata,
            "model_id": "unit-model",
            "base_capsule_sha256": "d" * 64,
            "residual_encoding": "dense_float",
            "residual_dtype": "float32",
        },
        "rules": [
            {
                "layer_idx": 0,
                "class_idx": 1,
                "matrix_type": "gate",
                "prefix_token_id": 11229,
                "target_token_id": 518,
                "row_indices": torch.tensor([1.0, 3.0]),
                "residual": torch.zeros((2, 3), dtype=torch.float32),
            }
        ],
    }
    payload_path = tmp_path / "bad_transition_residual.pt"
    torch.save(raw, payload_path)

    with pytest.raises(ValueError, match="integer tensor"):
        load_transition_residual_payload(payload_path, payloads)


def test_load_transition_residual_payload_rejects_dtype_metadata_mismatch(
    tmp_path: Path,
) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_dtype=torch.float32,
    )
    payload["metadata"]["residual_dtype"] = "float16"
    payload_path = tmp_path / "bad_dtype_transition_residual.pt"
    torch.save(payload, payload_path)

    with pytest.raises(ValueError, match="dtype does not match metadata"):
        load_transition_residual_payload(payload_path, payloads)


def test_load_int8_transition_residual_payload_rejects_scale_dtype_mismatch(
    tmp_path: Path,
) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int8_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload["metadata"]["residual_scale_dtype"] = "float32"
    payload_path = tmp_path / "bad_int8_scale_dtype_transition_residual.pt"
    torch.save(payload, payload_path)

    with pytest.raises(ValueError, match="scale dtype does not match metadata"):
        load_transition_residual_payload(payload_path, payloads)


def test_load_transition_residual_payload_rejects_missing_encoding_metadata(
    tmp_path: Path,
) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_dtype=torch.float32,
    )
    del payload["metadata"]["residual_encoding"]
    payload_path = tmp_path / "missing_encoding_transition_residual.pt"
    torch.save(payload, payload_path)

    with pytest.raises(ValueError, match="residual_encoding is missing or unsupported"):
        load_transition_residual_payload(payload_path, payloads)


def test_load_int8_transition_residual_payload_rejects_negative_128_code(
    tmp_path: Path,
) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int8_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload["rules"][0]["residual_q"][0, 0] = -128
    payload_path = tmp_path / "bad_int8_code_transition_residual.pt"
    torch.save(payload, payload_path)

    with pytest.raises(ValueError, match="unsupported -128 code"):
        load_transition_residual_payload(payload_path, payloads)


def test_load_int4_transition_residual_payload_rejects_negative_8_code(
    tmp_path: Path,
) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int4_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload["rules"][0]["residual_q_packed"][0, 0] &= 0xF0
    payload_path = tmp_path / "bad_int4_code_transition_residual.pt"
    torch.save(payload, payload_path)

    with pytest.raises(ValueError, match="unsupported -8 code"):
        load_transition_residual_payload(payload_path, payloads)


def test_load_int2_transition_residual_payload_rejects_negative_2_code(
    tmp_path: Path,
) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int2_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload["rules"][0]["residual_q_packed"][0, 0] &= 0xFC
    payload_path = tmp_path / "bad_int2_code_transition_residual.pt"
    torch.save(payload, payload_path)

    with pytest.raises(ValueError, match="unsupported -2 code"):
        load_transition_residual_payload(payload_path, payloads)


def test_load_int3_transition_residual_payload_rejects_negative_4_code(
    tmp_path: Path,
) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:11229:518")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_encoding="int3_per_row",
        residual_scale_dtype=torch.float16,
    )
    payload["rules"][0]["residual_q_packed"][0, 0] &= 0xF8
    payload_path = tmp_path / "bad_int3_code_transition_residual.pt"
    torch.save(payload, payload_path)

    with pytest.raises(ValueError, match="unsupported -4 code"):
        load_transition_residual_payload(payload_path, payloads)


def test_unpack_int3_per_row_decodes_known_even_width_wire_format() -> None:
    packed = torch.tensor([[0xF9, 0x58, 0x8B]], dtype=torch.uint8)

    unpacked = _unpack_int3_per_row(packed, (1, 8))

    assert torch.equal(unpacked, torch.tensor([[-3, 3, -1, 0, 1, 2, -2, 0]], dtype=torch.int8))


def test_unpack_int3_per_row_rejects_high_data_code_negative_4() -> None:
    packed = torch.tensor([[0x00, 0x00, 0x00]], dtype=torch.uint8)

    with pytest.raises(ValueError, match="unsupported -4 code"):
        _unpack_int3_per_row(packed, (1, 8))


def test_unpack_int3_per_row_rejects_invalid_padding_code() -> None:
    packed = torch.tensor([[0xF9, 0x58, 0xAB]], dtype=torch.uint8)

    with pytest.raises(ValueError, match="padding code"):
        _unpack_int3_per_row(packed, (1, 7))


def test_unpack_int2_per_row_decodes_known_even_width_wire_format() -> None:
    packed = torch.tensor([[0x9D]], dtype=torch.uint8)

    unpacked = _unpack_int2_per_row(packed, (1, 4))

    assert torch.equal(unpacked, torch.tensor([[-1, 1, -1, 0]], dtype=torch.int8))


def test_unpack_int2_per_row_rejects_high_data_code_negative_2() -> None:
    packed = torch.tensor([[0xC0]], dtype=torch.uint8)

    with pytest.raises(ValueError, match="unsupported -2 code"):
        _unpack_int2_per_row(packed, (1, 4))


def test_unpack_int2_per_row_rejects_invalid_padding_code() -> None:
    packed = torch.tensor([[0x2D]], dtype=torch.uint8)

    with pytest.raises(ValueError, match="padding code"):
        _unpack_int2_per_row(packed, (1, 3))


def test_unpack_int4_per_row_decodes_known_even_width_wire_format() -> None:
    packed = torch.tensor([[0xF1, 0x87]], dtype=torch.uint8)

    unpacked = _unpack_int4_per_row(packed, (1, 4))

    assert torch.equal(unpacked, torch.tensor([[-7, 7, -1, 0]], dtype=torch.int8))


def test_unpack_int4_per_row_rejects_high_data_nibble_negative_8() -> None:
    packed = torch.tensor([[0x01]], dtype=torch.uint8)

    with pytest.raises(ValueError, match="unsupported -8 code"):
        _unpack_int4_per_row(packed, (1, 2))


def test_unpack_int4_per_row_rejects_invalid_odd_padding_nibble() -> None:
    packed = torch.tensor([[0x98, 0x9A]], dtype=torch.uint8)

    with pytest.raises(ValueError, match="padding nibble"):
        _unpack_int4_per_row(packed, (1, 3))


def test_transition_residual_runner_preserves_batch_boundaries(tmp_path: Path) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:20:30")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_dtype=torch.float32,
    )
    payload_path = tmp_path / "transition_residual_boundary.pt"
    write_transition_residual_payload(payload_path, payload)
    loaded = load_transition_residual_payload(
        payload_path,
        payloads,
        expected_model_id="unit-model",
        expected_base_capsule_sha256="d" * 64,
    )
    token_ids = torch.tensor([[10, 20], [30, 40]], dtype=torch.long)
    class_ids = torch.ones_like(token_ids)
    hidden_states = torch.ones((2, 2, 3), dtype=torch.float32)
    hit_counts = {_rule_key(loaded.rules[0]): 0}

    routed = _transition_residual_mlp_intermediate(
        _model(),
        payloads,
        loaded,
        0,
        hidden_states,
        class_ids,
        token_ids,
        hit_counts,
    )

    assert routed.shape == (2, 2, 4)
    assert hit_counts[_rule_key(loaded.rules[0])] == 0


def test_transition_keys_preserve_batch_boundaries() -> None:
    token_ids = torch.tensor([[1, 2, 3], [4, 5, 6]], dtype=torch.long)

    assert _transition_keys(token_ids) == [(1, 2), (2, 3), None, (4, 5), (5, 6), None]


def test_transition_keys_reject_float_token_ids() -> None:
    token_ids = torch.tensor([[1.0, 2.0]], dtype=torch.float32)

    with pytest.raises(ValueError, match="integer dtype"):
        _transition_keys(token_ids)


def test_transition_keys_reject_negative_token_ids() -> None:
    token_ids = torch.tensor([[1, -2]], dtype=torch.long)

    with pytest.raises(ValueError, match="non-negative"):
        _transition_keys(token_ids)


def test_transition_residual_runner_rejects_float_token_ids(tmp_path: Path) -> None:
    payloads = _payloads()
    spec = parse_transition_residual_spec("0:1:gate:20:30")
    payload = build_transition_residual_payload(
        _model(),
        payloads,
        [spec],
        model_id="unit-model",
        base_capsule_sha256="d" * 64,
        residual_dtype=torch.float32,
    )
    payload_path = tmp_path / "transition_residual_float_tokens.pt"
    write_transition_residual_payload(payload_path, payload)
    loaded = load_transition_residual_payload(
        payload_path,
        payloads,
        expected_model_id="unit-model",
        expected_base_capsule_sha256="d" * 64,
    )
    token_ids = torch.tensor([[10.0, 20.0]], dtype=torch.float32)
    class_ids = torch.ones((1, 2), dtype=torch.long)
    hidden_states = torch.ones((1, 2, 3), dtype=torch.float32)
    hit_counts = {_rule_key(loaded.rules[0]): 0}

    with pytest.raises(ValueError, match="integer dtype"):
        _transition_residual_mlp_intermediate(
            _model(),
            payloads,
            loaded,
            0,
            hidden_states,
            class_ids,
            token_ids,
            hit_counts,
        )


def test_payload_byte_report_gates_max_artifact_bytes(tmp_path: Path) -> None:
    residual_path = tmp_path / "residual.pt"
    residual_path.write_bytes(b"x" * 20)
    capsule = SislCapsule(
        name="unit",
        source="unit",
        substrate="unit",
        sections=[],
        efficiency=EfficiencyMetrics(
            effective_bpw=2.0,
            source_bpw=4.0,
            artifact_bytes=100,
        ),
        effectiveness=EffectivenessMetrics(ppl_ratio=1.0),
        gates=CapsuleGates(
            max_effective_bpw=10.0,
            min_bit_advantage=0.0,
            max_artifact_bytes=110,
            max_ppl_ratio=2.0,
        ),
    )

    report = _payload_byte_report(tmp_path / "capsule.json", capsule, tmp_path, residual_path)

    assert report["total_artifact_bytes"] == 120
    assert report["artifact_bytes_passed"] is False