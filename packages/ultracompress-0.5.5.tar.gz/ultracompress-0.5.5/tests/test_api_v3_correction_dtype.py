"""Smoke test for task #327: V/U bf16 storage with fp32 inline cast.

Verifies that CorrectionLinearV18C (api_v3 customer path) stores V and U
weights as bf16, produces finite output matching input dtype, and that the
fp32 inner matmul precision path is exercised correctly.
"""
from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from ultracompress.api_v3 import CorrectionLinearV18C, _wrap_with_v18c


@pytest.fixture
def linear_256() -> nn.Linear:
    """A small 256x256 Linear in bf16 on CPU."""
    lin = nn.Linear(256, 256, bias=True)
    return lin.to(dtype=torch.bfloat16)


class TestCorrectionDtype:
    """Verify V/U bf16 storage and fp32 inline cast."""

    def test_v_weight_dtype_is_bf16(self, linear_256: nn.Linear) -> None:
        """V.weight must be stored as bf16, not fp32."""
        w = linear_256.weight.data
        b = linear_256.bias.data
        mod = CorrectionLinearV18C(w, b, rank=16)
        # Simulate _wrap_with_v18c's post-construction fixups
        mod = mod.to(device=w.device, dtype=w.dtype)
        mod.alpha.data = mod.alpha.data.float()
        mod.V.weight.data = mod.V.weight.data.to(torch.bfloat16)
        mod.U.weight.data = mod.U.weight.data.to(torch.bfloat16)

        assert mod.V.weight.dtype == torch.bfloat16, (
            f"V.weight should be bf16, got {mod.V.weight.dtype}"
        )

    def test_u_weight_dtype_is_bf16(self, linear_256: nn.Linear) -> None:
        """U.weight must be stored as bf16, not fp32."""
        w = linear_256.weight.data
        b = linear_256.bias.data
        mod = CorrectionLinearV18C(w, b, rank=16)
        mod = mod.to(device=w.device, dtype=w.dtype)
        mod.alpha.data = mod.alpha.data.float()
        mod.V.weight.data = mod.V.weight.data.to(torch.bfloat16)
        mod.U.weight.data = mod.U.weight.data.to(torch.bfloat16)

        assert mod.U.weight.dtype == torch.bfloat16, (
            f"U.weight should be bf16, got {mod.U.weight.dtype}"
        )

    def test_forward_output_dtype_matches_input(
        self, linear_256: nn.Linear
    ) -> None:
        """Forward output dtype must match input dtype (bf16 in, bf16 out)."""
        w = linear_256.weight.data
        b = linear_256.bias.data
        mod = CorrectionLinearV18C(w, b, rank=16)
        mod = mod.to(device=w.device, dtype=w.dtype)
        mod.alpha.data = mod.alpha.data.float()
        mod.V.weight.data = mod.V.weight.data.to(torch.bfloat16)
        mod.U.weight.data = mod.U.weight.data.to(torch.bfloat16)
        mod.train(False)

        x = torch.randn(2, 8, 256, dtype=torch.bfloat16)
        with torch.no_grad():
            y = mod(x)

        assert y.dtype == torch.bfloat16, (
            f"output dtype should be bf16, got {y.dtype}"
        )

    def test_forward_output_is_finite(self, linear_256: nn.Linear) -> None:
        """Forward output must contain no NaN or Inf values."""
        w = linear_256.weight.data
        b = linear_256.bias.data
        mod = CorrectionLinearV18C(w, b, rank=16)
        mod = mod.to(device=w.device, dtype=w.dtype)
        mod.alpha.data = mod.alpha.data.float()
        mod.V.weight.data = mod.V.weight.data.to(torch.bfloat16)
        mod.U.weight.data = mod.U.weight.data.to(torch.bfloat16)
        mod.train(False)

        x = torch.randn(2, 8, 256, dtype=torch.bfloat16)
        with torch.no_grad():
            y = mod(x)

        assert torch.isfinite(y).all(), "output contains NaN or Inf"

    def test_wrap_with_v18c_sets_bf16(self) -> None:
        """_wrap_with_v18c must produce V/U as bf16 on the wrapped modules."""

        class TinyModel(nn.Module):
            def __init__(self) -> None:
                super().__init__()
                self.q_proj = nn.Linear(256, 256, bias=False)

        model = TinyModel().to(dtype=torch.bfloat16)
        n = _wrap_with_v18c(model, rank=16, targets=("q_proj",))
        assert n == 1, f"expected 1 wrap, got {n}"

        wrapped = model.q_proj
        assert isinstance(wrapped, CorrectionLinearV18C)
        assert wrapped.V.weight.dtype == torch.bfloat16, (
            f"V.weight should be bf16 after _wrap_with_v18c, got {wrapped.V.weight.dtype}"
        )
        assert wrapped.U.weight.dtype == torch.bfloat16, (
            f"U.weight should be bf16 after _wrap_with_v18c, got {wrapped.U.weight.dtype}"
        )
        assert wrapped.alpha.dtype == torch.float32, (
            f"alpha should stay fp32, got {wrapped.alpha.dtype}"
        )

    def test_wrap_with_v18c_fp16_host_still_bf16_vu(self) -> None:
        """Even with fp16 host model, V/U must be bf16 (not fp16 or fp32)."""

        class TinyModel(nn.Module):
            def __init__(self) -> None:
                super().__init__()
                self.q_proj = nn.Linear(256, 256, bias=False)

        model = TinyModel().to(dtype=torch.float16)
        _wrap_with_v18c(model, rank=16, targets=("q_proj",))

        wrapped = model.q_proj
        assert wrapped.V.weight.dtype == torch.bfloat16, (
            f"V.weight should be bf16 even on fp16 host, got {wrapped.V.weight.dtype}"
        )
        assert wrapped.U.weight.dtype == torch.bfloat16, (
            f"U.weight should be bf16 even on fp16 host, got {wrapped.U.weight.dtype}"
        )

    def test_forward_with_fp16_input(self) -> None:
        """Forward must work with fp16 input and still produce fp16 output."""

        class TinyModel(nn.Module):
            def __init__(self) -> None:
                super().__init__()
                self.q_proj = nn.Linear(256, 256, bias=False)

        model = TinyModel().to(dtype=torch.float16)
        _wrap_with_v18c(model, rank=16, targets=("q_proj",))
        model.train(False)

        x = torch.randn(1, 4, 256, dtype=torch.float16)
        with torch.no_grad():
            y = model.q_proj(x)

        assert y.dtype == torch.float16, f"expected fp16 output, got {y.dtype}"
        assert torch.isfinite(y).all(), "fp16 forward produced NaN/Inf"
