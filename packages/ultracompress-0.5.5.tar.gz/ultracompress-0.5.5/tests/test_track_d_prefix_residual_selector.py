from __future__ import annotations

import sys
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
OVERLAY = SCRIPTS / "overlay"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))
if str(OVERLAY) not in sys.path:
    sys.path.insert(0, str(OVERLAY))

from track_d_sisl_qwen_rung12_prefix_residual_selector import (  # noqa: E402
    CaseTokenSequence,
    FailureSpike,
    RuleCandidate,
    load_sequence_json,
    main,
    rules_from_report,
    rules_for_spike,
    select_rules,
    spikes_from_case,
    validate_reports,
    write_sequence_json,
)


def _case_report(*, passed: bool = False) -> dict:
    return {
        "name": "case_a",
        "config": {
            "start_layer_idx": 0,
            "layer_count": 1,
        },
        "report": {
            "passed": passed,
            "nll_delta_passed": False,
            "kl_passed": True,
            "max_nll_delta_flat_index": 3,
            "max_nll_delta_class_idx": 8,
            "max_nll_delta_prefix_token_id": 40,
            "max_nll_delta_target_token_id": 50,
            "max_nll_delta": 7.0,
            "max_nll_delta_threshold": 2.0,
            "max_kl_flat_index": 1,
            "max_kl_class_idx": 4,
            "max_kl_token_id": 20,
            "max_kl": 0.1,
            "max_kl_threshold": 1.5,
        },
    }


def _sequence() -> CaseTokenSequence:
    return CaseTokenSequence(
        name="case_a",
        token_ids=(10, 20, 30, 40, 50, 60),
        class_ids=(2, 4, 6, 8, 10, 12),
    )


def test_spikes_from_case_uses_failed_nll_gate() -> None:
    spikes = spikes_from_case(_case_report(), include_failed_case_maxima=False)

    assert spikes == [
        FailureSpike(
            case_name="case_a",
            metric="max_nll_delta",
            reason="metric_gate_failed",
            flat_index=3,
            class_idx=8,
            prefix_token_id=40,
            target_token_id=50,
            value=7.0,
            threshold=2.0,
        )
    ]


def test_rules_for_spike_adds_prefix_window_for_each_matrix() -> None:
    spike = spikes_from_case(_case_report(), include_failed_case_maxima=False)[0]
    rules = rules_for_spike(
        spike,
        _sequence(),
        layer_indices=range(0, 1),
        matrix_types=("gate", "up"),
        prefix_window=2,
        suffix_window=0,
    )

    assert [rule.cli_rule() for rule in rules] == [
        "0:4:gate:20:30",
        "0:4:up:20:30",
        "0:6:gate:30:40",
        "0:6:up:30:40",
        "0:8:gate:40:50",
        "0:8:up:40:50",
    ]


def test_select_rules_keeps_existing_and_adds_only_new_candidates() -> None:
    report = {
        "transition_residual_payload": {
            "rules": [
                {
                    "layer_idx": 0,
                    "class_idx": 6,
                    "matrix_type": "gate",
                    "prefix_token_id": 30,
                    "target_token_id": 40,
                }
            ]
        },
        "cases": [_case_report()],
    }

    selection = select_rules(
        [report],
        {"case_a": _sequence()},
        matrix_types=("gate", "up"),
        prefix_window=1,
        suffix_window=0,
        include_existing_rules=True,
        include_passed_cases=False,
        include_failed_case_maxima=False,
    )

    assert selection["existing_rule_count"] == 1
    assert selection["new_rule_count"] == 3
    assert [item["cli_rule"] for item in selection["selected_rules"]] == [
        "0:6:gate:30:40",
        "0:6:up:30:40",
        "0:8:gate:40:50",
        "0:8:up:40:50",
    ]


def test_select_rules_can_cap_new_candidates() -> None:
    report = {"transition_residual_payload": {"rules": []}, "cases": [_case_report()]}

    selection = select_rules(
        [report],
        {"case_a": _sequence()},
        matrix_types=("gate", "up"),
        prefix_window=2,
        suffix_window=0,
        include_existing_rules=True,
        include_passed_cases=False,
        include_failed_case_maxima=False,
        max_new_rules=2,
    )

    assert selection["new_rule_count"] == 2
    assert [item["cli_rule"] for item in selection["new_rules"]] == [
        "0:4:gate:20:30",
        "0:4:up:20:30",
    ]
    assert selection["truncated"] is True
    assert selection["omitted_new_rule_count"] == 4


def test_rules_for_spike_fails_closed_on_sequence_mismatch() -> None:
    spike = FailureSpike(
        case_name="case_a",
        metric="max_nll_delta",
        reason="metric_gate_failed",
        flat_index=3,
        class_idx=999,
        prefix_token_id=40,
        target_token_id=50,
    )

    with pytest.raises(ValueError, match="class mismatch"):
        rules_for_spike(
            spike,
            _sequence(),
            layer_indices=range(0, 1),
            matrix_types=("gate",),
            prefix_window=0,
            suffix_window=0,
        )


def test_rules_for_spike_rejects_last_token_without_target() -> None:
    spike = FailureSpike(
        case_name="case_a",
        metric="max_kl",
        reason="metric_gate_failed",
        flat_index=5,
        class_idx=12,
        prefix_token_id=60,
    )

    with pytest.raises(ValueError, match="has no target transition"):
        rules_for_spike(
            spike,
            _sequence(),
            layer_indices=range(0, 1),
            matrix_types=("gate",),
            prefix_window=0,
            suffix_window=0,
        )


def test_select_rules_can_include_failed_case_kl_maximum() -> None:
    case = _case_report()
    case["report"]["nll_delta_passed"] = True
    case["report"]["kl_passed"] = True
    case["report"]["passed"] = False
    report = {"transition_residual_payload": {"rules": []}, "cases": [case]}

    selection = select_rules(
        [report],
        {"case_a": _sequence()},
        matrix_types=("gate",),
        prefix_window=0,
        suffix_window=0,
        include_existing_rules=True,
        include_passed_cases=False,
        include_failed_case_maxima=True,
    )

    assert [item["cli_rule"] for item in selection["new_rules"]] == [
        "0:8:gate:40:50",
        "0:4:gate:20:30",
    ]


def test_select_rules_default_does_not_seed_passed_metric_maxima() -> None:
    case = _case_report()
    case["report"]["nll_delta_passed"] = True
    case["report"]["kl_passed"] = True
    case["report"]["passed"] = False
    report = {"transition_residual_payload": {"rules": []}, "cases": [case]}

    selection = select_rules(
        [report],
        {"case_a": _sequence()},
        matrix_types=("gate",),
        prefix_window=0,
        suffix_window=0,
        include_existing_rules=True,
        include_passed_cases=False,
        include_failed_case_maxima=False,
    )

    assert selection["new_rules"] == []


def test_rule_candidate_cli_rule_is_stable() -> None:
    rule = RuleCandidate(
        layer_idx=0,
        class_idx=14,
        matrix_type="gate",
        prefix_token_id=11229,
        target_token_id=518,
    )

    assert rule.cli_rule() == "0:14:gate:11229:518"


def test_spikes_from_case_rejects_string_boolean() -> None:
    case = _case_report()
    case["report"]["nll_delta_passed"] = "false"

    with pytest.raises(ValueError, match="nll_delta_passed must be a boolean"):
        spikes_from_case(case, include_failed_case_maxima=False)


def test_spikes_from_case_requires_failed_metric_above_threshold() -> None:
    case = _case_report()
    case["report"]["max_nll_delta"] = 1.0

    with pytest.raises(ValueError, match="must exceed"):
        spikes_from_case(case, include_failed_case_maxima=False)


def _valid_transition_report() -> dict:
    return {
        "schema": "track_d.sisl.rung12.transition_residual_payload.v0",
        "model_id": "unit-model",
        "capsule": {"root": "capsules/k1", "sha256": "a" * 64},
        "transition_residual_payload": {"rules": []},
        "cases": [
            {
                "name": "case_a",
                "config": {"start_layer_idx": 0, "layer_count": 1},
                "report": {"passed": True},
            }
        ],
    }


def test_validate_reports_accepts_consistent_provenance() -> None:
    context = validate_reports([_valid_transition_report(), _valid_transition_report()])

    assert context["model_id"] == "unit-model"
    assert context["capsule_sha256"] == "a" * 64


def test_validate_reports_rejects_mixed_capsule_sha() -> None:
    second = _valid_transition_report()
    second["capsule"] = {"root": "capsules/k1", "sha256": "b" * 64}

    with pytest.raises(ValueError, match="provenance mismatch"):
        validate_reports([_valid_transition_report(), second])


def test_validate_reports_rejects_wrong_schema() -> None:
    report = _valid_transition_report()
    report["schema"] = "wrong"

    with pytest.raises(ValueError, match="schema mismatch"):
        validate_reports([report])


def test_rules_from_report_requires_payload_rules() -> None:
    report = _valid_transition_report()
    report.pop("transition_residual_payload")

    with pytest.raises(ValueError, match="missing transition_residual_payload"):
        rules_from_report(report)

    report = _valid_transition_report()
    report["transition_residual_payload"] = {}

    with pytest.raises(ValueError, match="missing rules"):
        rules_from_report(report)


def test_rules_from_report_rejects_negative_rule_values() -> None:
    report = _valid_transition_report()
    report["transition_residual_payload"]["rules"] = [
        {
            "layer_idx": 0,
            "class_idx": -1,
            "matrix_type": "gate",
            "prefix_token_id": 30,
            "target_token_id": 40,
        }
    ]

    with pytest.raises(ValueError, match="non-negative"):
        rules_from_report(report)


def test_select_rules_requires_explicit_case_layer_config() -> None:
    case = _case_report()
    case["config"].pop("start_layer_idx")
    report = {"transition_residual_payload": {"rules": []}, "cases": [case]}

    with pytest.raises(ValueError, match="start_layer_idx"):
        select_rules(
            [report],
            {"case_a": _sequence()},
            matrix_types=("gate",),
            prefix_window=0,
            suffix_window=0,
            include_existing_rules=True,
            include_passed_cases=False,
            include_failed_case_maxima=False,
        )


def test_sequence_cache_requires_cases_hash_metadata(tmp_path: Path) -> None:
    sequence_path = tmp_path / "sequence.json"
    metadata = {
        "model_id": "unit-model",
        "capsule_root": "capsules/k1",
        "capsule_sha256": "a" * 64,
        "case_configs": {"case_a": {"start_layer_idx": 0, "layer_count": 1}},
    }
    write_sequence_json(sequence_path, metadata=metadata, sequences={"case_a": _sequence()})

    with pytest.raises(ValueError, match="cases_json_sha256"):
        load_sequence_json(
            sequence_path,
            expected_metadata={**metadata, "cases_json_sha256": "b" * 64},
        )


def test_main_requires_cases_json_with_sequence_json(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "selector",
            "--report-path",
            "missing-report.json",
            "--sequence-json",
            "missing-sequence.json",
            "--output-rules-path",
            "rules.txt",
            "--selector-report-path",
            "selector-report.json",
        ],
    )

    with pytest.raises(ValueError, match="--cases-json is required with --sequence-json"):
        main()


def test_main_rejects_negative_windows_before_selection(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "selector",
            "--report-path",
            "missing-report.json",
            "--output-rules-path",
            "rules.txt",
            "--selector-report-path",
            "selector-report.json",
            "--prefix-window",
            "-1",
        ],
    )

    with pytest.raises(ValueError, match="--prefix-window must be non-negative"):
        main()