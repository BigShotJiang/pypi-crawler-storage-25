"""Regression test suite for the 3 critical bug fixes from 2026-05-01.

Run via:
    pytest tests/test_regression_suite.py -v

Tests:
1. V18-C bf16 forward pass produces correct output (no dtype mismatch)
2. customer_demo's sys.path bootstrap finds in-tree v3 API
3. CHBR forward pass doesn't allocate fp32 embedding cast on every call

These tests guard against the specific regressions that bit us today.
Future-Sip: when CI is set up, run these on every commit to scaling_curve_runner,
api_v3, customer_demo, or run_frr_content_banks.
"""
from __future__ import annotations
import importlib.util
import sys
import unittest
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

# Path bootstrap so this test runs from anywhere
ROOT = Path(__file__).resolve().parents[1]
SCALING_CURVE = ROOT / "scripts" / "overlay" / "scaling_curve_runner.py"
API_V3 = ROOT / "ultracompress" / "api_v3.py"
RUN_FRR = ROOT / "scripts" / "frr" / "run_frr_content_banks.py"


def _load_module(name: str, path: Path):
    """Load a module from a file path."""
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load {path}")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


# ---------------------------------------------------------------------------
# Bug #1: V18-C bf16 forward pass dtype mismatch
# ---------------------------------------------------------------------------

class V18CBf16Forward(unittest.TestCase):
    """Guard the V18-C correction-layer forward against dtype-mismatch regression.

    The original cap-killed agent's patch did:
        self.U(v_out.float())
    which crashed because U.weight was bf16. The fix is:
        F.linear(v_out.float(), self.U.weight.float())
    This test reproduces the original failure mode and verifies the fix holds.
    """

    def test_api_v3_correction_runs_bf16_input(self) -> None:
        """api_v3.py's CorrectionLinearV18C must accept bf16 input without crashing."""
        if not API_V3.exists():
            self.skipTest("api_v3.py not present")

        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))

        try:
            from ultracompress.api_v3 import CorrectionLinearV18C
        except ImportError as e:
            self.skipTest(f"Could not import CorrectionLinearV18C: {e}")

        # Build a minimal correction layer (signature: weight, bias, rank, has_bias)
        weight = torch.randn(64, 32, dtype=torch.bfloat16)
        bias = torch.zeros(64, dtype=torch.bfloat16)
        try:
            correction = CorrectionLinearV18C(weight, bias, rank=8)
        except TypeError:
            # Maybe constructor doesn't take bias positionally; try kwarg
            correction = CorrectionLinearV18C(weight, bias=bias, rank=8)

        # Cast trainable params to bf16 to mimic production
        for p in correction.parameters():
            p.data = p.data.to(torch.bfloat16)

        # Forward pass with bf16 input — this is the test that would have caught
        # the dtype mismatch bug.
        x = torch.randn(2, 4, 32, dtype=torch.bfloat16)
        try:
            y = correction(x)
        except RuntimeError as e:
            self.fail(f"V18-C bf16 forward crashed (dtype regression): {e}")

        self.assertEqual(y.dtype, torch.bfloat16, "Output dtype should match input bf16")
        self.assertEqual(y.shape, (2, 4, 64), "Output shape mismatch")

    def test_scaling_curve_runner_correction_runs_bf16(self) -> None:
        """scaling_curve_runner.py's CorrectionMatrixC must accept bf16 input."""
        if not SCALING_CURVE.exists():
            self.skipTest("scaling_curve_runner.py not present")

        # The runner has top-level argparse code that would fire on import.
        # We need to inspect just the class definition. Easiest: read the file
        # and check the forward pass for the broken pattern.
        text = SCALING_CURVE.read_text()
        broken = "self.U(v_out.float())"
        fixed = "F.linear(v_out.float(), self.U.weight.float())"
        self.assertNotIn(broken, text, "Broken V18-C dtype pattern reintroduced")
        self.assertIn(fixed, text, "V18-C dtype fix missing")


# ---------------------------------------------------------------------------
# Bug #2: customer_demo sys.path bootstrap
# ---------------------------------------------------------------------------

class CustomerDemoBootstrap(unittest.TestCase):
    """Guard customer_demo against ModuleNotFoundError when older pip 0.1.2 lurks."""

    def test_customer_demo_has_sys_path_bootstrap(self) -> None:
        """customer_demo.py must contain the dev-mode sys.path bootstrap block."""
        path = ROOT / "scripts" / "demo" / "customer_demo.py"
        if not path.exists():
            self.skipTest("customer_demo.py not present")

        text = path.read_text()
        # Verify the bootstrap signature is present
        self.assertIn("sys.path.insert(0, str(_repo_root))", text,
                      "customer_demo.py is missing the sys.path bootstrap")
        self.assertIn("api_v3.py", text,
                      "customer_demo.py bootstrap should check for api_v3.py existence")


# ---------------------------------------------------------------------------
# Bug #3: CHBR fp32 embedding cast OOM
# ---------------------------------------------------------------------------

class CHBREmbeddingFix(unittest.TestCase):
    """Guard CHBR forward pass against the fp32 embedding cast that OOMed v3/v4/v5.

    Previous broken pattern (lines 141, 160 of run_frr_content_banks.py):
        F.embedding(tokens, self.embed_w.to(tokens.device, dtype=torch.float32))
        F.linear(latent, self.lm_head_w.to(latent.device, dtype=torch.float32))

    Each call re-allocated 5GB fp32 copy of vocab*hidden tensor every forward
    pass, fragmenting GPU memory until OOM at training step ~75-100.
    """

    def test_run_frr_content_banks_no_fp32_embedding_in_forward(self) -> None:
        """run_frr_content_banks.py must NOT cast embed_w to fp32 inside forward()."""
        if not RUN_FRR.exists():
            self.skipTest("run_frr_content_banks.py not present")

        text = RUN_FRR.read_text()
        # Old broken patterns
        broken_embed = "F.embedding(tokens, self.embed_w.to(tokens.device, dtype=torch.float32))"
        broken_lmhead = "F.linear(latent, self.lm_head_w.to(latent.device, dtype=torch.float32))"
        self.assertNotIn(broken_embed, text,
                         "CHBR fp32 embedding cast (memory bug) reintroduced")
        self.assertNotIn(broken_lmhead, text,
                         "CHBR fp32 lm_head cast (memory bug) reintroduced")

        # New fixed patterns
        fixed_embed = "F.embedding(tokens, self.embed_w.to(tokens.device)).float()"
        self.assertIn(fixed_embed, text,
                      "CHBR fixed embedding pattern missing")

    def test_no_fp32_cast_in_forward_across_frr_dir(self) -> None:
        """The fp32-embedding-cast-in-forward bug fix must hold across ALL FRR scripts.

        Five files originally carried the same per-forward fp32 alloc pattern that
        OOM'd CHBR runs v3/v4/v5; this test guards against re-introduction in any of
        them: run_frr_content_banks, run_frr_72b_cached (2 forward methods),
        run_frr_72b_fp16stream, run_frr_ensemble, eval_frr_72b_banks.
        """
        frr_dir = ROOT / "scripts" / "frr"
        if not frr_dir.exists():
            self.skipTest("scripts/frr/ not present")

        broken_patterns = [
            "self.embed_w.to(tokens.device, dtype=torch.float32)",
            "self.lm_head_w.to(latent.device, dtype=torch.float32)",
        ]
        offenders = []
        for py_file in frr_dir.glob("*.py"):
            text = py_file.read_text(encoding="utf-8", errors="ignore")
            for pat in broken_patterns:
                if pat in text:
                    offenders.append(f"{py_file.name}: '{pat}'")
        self.assertEqual(offenders, [],
                         f"fp32-cast-in-forward bug pattern present in: {offenders}")


# ---------------------------------------------------------------------------
# Integration: numerics acceptance harness self-test
# ---------------------------------------------------------------------------

class NumericsHarnessSelfTest(unittest.TestCase):
    """Guard the Phase 0 numerics acceptance harness — Sipsa's day-1 customer deliverable."""

    def test_harness_self_test_passes(self) -> None:
        """Numerics acceptance harness --self-test must produce ACCEPTANCE VERDICT: PASS."""
        harness = ROOT / "scripts" / "varion" / "numerics_acceptance_harness.py"
        if not harness.exists():
            self.skipTest("numerics_acceptance_harness.py not present")

        # Try to import and call the self-test. Since the script uses argparse
        # we need to simulate the --self-test flag.
        import subprocess
        result = subprocess.run(
            [sys.executable, str(harness), "--self-test"],
            capture_output=True, text=True, timeout=60,
        )
        self.assertIn("ACCEPTANCE VERDICT:  PASS", result.stdout,
                      f"Self-test did not pass. Stdout: {result.stdout[-500:]}")


# ---------------------------------------------------------------------------
# Patent-discipline: customer-facing Friday docs are clean of internal vocab
# ---------------------------------------------------------------------------

class FridayDocsIPDiscipline(unittest.TestCase):
    """Guard customer-facing Friday docs against re-introduction of internal vocab."""

    LEAK_PATTERNS = ["V18-C", "V18C", "DSR-Q", "DSRQ", "CHBR", "PCR ", "SP-band"]
    CUSTOMER_DOCS = [
        "VARION_FRIDAY_DECK.md",
        "VARION_FRIDAY_QA_PREP.md",
        "VARION_FRIDAY_ONE_PAGER.md",
    ]

    def test_no_internal_vocab_in_customer_facing_docs(self) -> None:
        for fname in self.CUSTOMER_DOCS:
            path = ROOT / "docs" / fname
            if not path.exists():
                continue
            text = path.read_text()
            for pattern in self.LEAK_PATTERNS:
                self.assertNotIn(pattern, text,
                                 f"Internal vocab '{pattern}' leaked into {fname}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
