"""Public compression API: `compress()` and `save()`.

This module wires the customer-facing surface used by
`scripts/demo/customer_demo.py`. It is deliberately thin — the real
research code lives under `scripts/overlay/` and `scripts/triton_kernels/`
and is imported here, not duplicated.

Format of `.uc` artifacts produced by `save()`:
    <path>           : torch.save() of a dict with keys
                       {'state_dict': dict[str, Tensor],
                        'metadata':   dict (json-safe)}

`metadata` records mode, bits, group_size, target_bpw, achieved bpw, and
the schema version. Loaders should branch on `metadata['schema_version']`.

Stub boundaries (clearly marked below):
  - The v17 *row-overlay rotation* code path in `scripts/overlay/pack_v17.py`
    requires a calibration set, a fitted `v17_fit_*.pt` file, and
    HuggingFace teacher weights on disk. For the demo runtime path we use
    the same per-group fake-quantization that the v18 training pipeline
    (`scripts/overlay/run_track_a_adaptive.py`) uses to *simulate* v17
    quality loss. This keeps the demo end-to-end runnable without a
    pre-fit overlay artifact. Production deployments substitute the real
    pack via `pack_v17.substitute_from_pack()`.
  - `calibration_tokens` is accepted but not currently consumed for the
    fake-quant path (per-group statistics are data-free). The argument is
    kept so the API is forward-compatible with the real overlay path.
"""
from __future__ import annotations

import copy
import json
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Resolve scripts/overlay/ for v18 AdaptiveLinear import.
# ---------------------------------------------------------------------------
_REPO_ROOT = Path(__file__).resolve().parent.parent
_OVERLAY_DIR = _REPO_ROOT / "scripts" / "overlay"
if str(_OVERLAY_DIR) not in sys.path:
    sys.path.insert(0, str(_OVERLAY_DIR))

try:
    from track_a_adaptive import adaptify_module, count_adaptive_params  # type: ignore
    _HAS_ADAPTIVE = True
except Exception:  # pragma: no cover - overlay dir not on disk
    adaptify_module = None  # type: ignore
    count_adaptive_params = None  # type: ignore
    _HAS_ADAPTIVE = False


SCHEMA_VERSION = 1
_DEFAULT_LINEAR_TARGETS = (
    "q_proj", "k_proj", "v_proj", "o_proj",
    "gate_proj", "up_proj", "down_proj",
)


# ---------------------------------------------------------------------------
# Quantization primitives (v17-equivalent fake-quant; see stub boundary above).
# ---------------------------------------------------------------------------
def _bits_for_target_bpw(target_bpw: float) -> tuple[int, int]:
    """Pick (bits, group_size) so the effective bpw lands near `target_bpw`.

    Effective bpw including per-group fp16 scale = bits + 16/group_size.
    """
    candidates = [
        (2, 128),  # 2.125 bpw
        (3, 128),  # 3.125 bpw
        (4, 128),  # 4.125 bpw
        (4, 64),   # 4.25 bpw
        (8, 128),  # 8.125 bpw
    ]
    best = min(candidates, key=lambda bg: abs((bg[0] + 16.0 / bg[1]) - target_bpw))
    return best


def _effective_bpw(bits: int, group_size: int) -> float:
    return bits + 16.0 / group_size


def _fake_quantize_per_group(W: torch.Tensor, bits: int, group_size: int) -> torch.Tensor:
    """Row-grouped symmetric quant. Mirrors `run_track_a_adaptive.fake_quantize_per_group`."""
    n_levels = (1 << (bits - 1)) - 1
    R, C = W.shape
    pad = (group_size - C % group_size) % group_size
    if pad:
        W = F.pad(W, (0, pad))
    Cp = W.shape[1]
    Wg = W.reshape(R, Cp // group_size, group_size)
    s = Wg.abs().amax(dim=-1, keepdim=True).clamp(min=1e-8)
    q = (Wg / s * n_levels).round().clamp(-n_levels, n_levels)
    Wq = (q / n_levels * s).reshape(R, Cp)
    return Wq[:, :Cp - pad].to(W.dtype) if pad else Wq.to(W.dtype)


def _quantize_inplace(model: nn.Module, bits: int, group_size: int,
                      targets: tuple[str, ...] = _DEFAULT_LINEAR_TARGETS) -> int:
    """Replace every targeted nn.Linear's weight with its fake-quantized copy."""
    n = 0
    for name, mod in model.named_modules():
        if isinstance(mod, nn.Linear) and any(t in name for t in targets):
            with torch.no_grad():
                mod.weight.data.copy_(
                    _fake_quantize_per_group(mod.weight.data, bits, group_size)
                )
            n += 1
    return n


def _count_quantized_params(model: nn.Module,
                            targets: tuple[str, ...] = _DEFAULT_LINEAR_TARGETS) -> int:
    n = 0
    for name, mod in model.named_modules():
        if isinstance(mod, nn.Linear) and any(t in name for t in targets):
            n += mod.weight.numel()
    return n


# ---------------------------------------------------------------------------
# Result objects.
# ---------------------------------------------------------------------------
@dataclass
class CompressionReport:
    mode: str
    target_bpw: float
    bits_per_weight: float
    bits: int
    group_size: int
    quantized_params: int
    adaptive_params: int
    calibration_tokens: int
    n_quantized_linears: int
    n_adaptive_linears: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class CompressedModel(nn.Module):
    """Wrapper exposing an HF-causal-LM-compatible surface.

    Forwards `(input_ids)` and `.generate(...)` straight to the wrapped HF
    model so it slots into existing benchmarking harnesses unchanged.
    """

    def __init__(self, hf_model: nn.Module, report: CompressionReport):
        super().__init__()
        self.model = hf_model
        self.report = report
        # Pass through HF surface used by the demo.
        self.config = getattr(hf_model, "config", None)
        if hasattr(hf_model, "generation_config"):
            self.generation_config = hf_model.generation_config

    def forward(self, *args, **kwargs):
        return self.model(*args, **kwargs)

    def generate(self, *args, **kwargs):
        return self.model.generate(*args, **kwargs)

    def state_dict(self, *args, **kwargs):  # type: ignore[override]
        return self.model.state_dict(*args, **kwargs)


# ---------------------------------------------------------------------------
# Public API.
# ---------------------------------------------------------------------------
def compress(model: nn.Module, mode: str, target_bpw: float,
             calibration_tokens: int = 2048,
             gain_bottleneck: int = 32,
             gain_range: float = 0.5) -> CompressedModel:
    """Compress an nn.Module to the target effective bitrate.

    Args:
        model: source module (HF causal LM, or any nn.Module containing
            nn.Linear submodules whose names match the v17 target set).
        mode: 'track_a_full_stack' (v17 packed quant + v18 input-adaptive
            gain). Other modes raise NotImplementedError.
        target_bpw: desired bits per weight. (bits, group_size) is chosen
            from a small candidate set to land closest to this target.
        calibration_tokens: reserved; see stub boundary in module docstring.
        gain_bottleneck: width of the v18 InputAdaptiveGain MLP.
        gain_range: clamp range of the v18 sigmoid output (modulates +/- range).

    Returns:
        CompressedModel exposing `.report.bits_per_weight` and HF-style
        `forward(input_ids)` / `.generate(...)`.
    """
    if mode != "track_a_full_stack":
        raise NotImplementedError(f"mode={mode!r} not supported; use 'track_a_full_stack'")
    if not _HAS_ADAPTIVE:
        raise RuntimeError(
            "v18 AdaptiveLinear import failed; expected scripts/overlay/track_a_adaptive.py"
        )

    bits, group_size = _bits_for_target_bpw(target_bpw)

    # Work on a fresh copy so the caller's teacher is untouched.
    student = copy.deepcopy(model)

    # Step 1 - v17 packed quantization (fake-quant equivalent; see stub note).
    n_quantized = _quantize_inplace(student, bits, group_size)

    # Step 2 - v18 input-adaptive gain modulation layered on top.
    n_adaptive = adaptify_module(
        student, gain_bottleneck=gain_bottleneck, gain_range=gain_range,
        target_substrings=_DEFAULT_LINEAR_TARGETS,
    )

    # Move adaptive sub-nets to the same device/dtype as the host weights.
    try:
        first_param = next(student.parameters())
        student.to(device=first_param.device, dtype=first_param.dtype)
    except StopIteration:
        pass

    quant_params = _count_quantized_params(student)
    adapt_params = count_adaptive_params(student) if count_adaptive_params else 0

    report = CompressionReport(
        mode=mode,
        target_bpw=float(target_bpw),
        bits_per_weight=_effective_bpw(bits, group_size),
        bits=bits,
        group_size=group_size,
        quantized_params=quant_params,
        adaptive_params=adapt_params,
        calibration_tokens=int(calibration_tokens),
        n_quantized_linears=n_quantized,
        n_adaptive_linears=n_adaptive,
    )
    return CompressedModel(student, report)


def save(compressed: CompressedModel, path: str | Path) -> Path:
    """Serialize a CompressedModel to a single `.uc` artifact.

    Format: torch.save({'state_dict': ..., 'metadata': ...}, path).
    See module docstring for schema details.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "state_dict": compressed.state_dict(),
        "metadata": {
            "schema_version": SCHEMA_VERSION,
            "report": compressed.report.to_dict(),
        },
    }
    torch.save(payload, path)
    # Sidecar JSON so the metadata is greppable without loading the tensors.
    sidecar = path.with_suffix(path.suffix + ".json")
    sidecar.write_text(json.dumps(payload["metadata"], indent=2))
    return path


__all__ = ["compress", "save", "CompressedModel", "CompressionReport"]
