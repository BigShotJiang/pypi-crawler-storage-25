"""Production Track A v17+v18+SP-band compression API.

This is the shippable end-to-end pipeline. It wires three landed pieces into
ONE `uc.compress()` call:

  1. v17 row-overlay rotation - codebook substitution from `v17_fit_*.pt`
     (delegates to `eval_v17_ppl.substitute_v17`).
  2. v18 input-adaptive gain modulation - `adaptify_module()` over the
     v17-dequantized model, with `gain_state` loaded from the trained
     `best_gain.pt` checkpoint.
  3. SP-band per-band bpw allocation - precomputed Hadamard-band bpw maps
     from `scripts/uc_ir/qwen3_1.7b_bpw_map*.json` are used to refine the
     measured effective bpw.

Storage format (`.uc` artifact via `uc.save()`):
    torch.save({
        'state_dict': <flat HF state dict including AdaptiveLinear gain nets>,
        'metadata':  {
            'schema_version': 2,
            'mode': 'track_a_full_stack',
            'report': <CompressionReport.to_dict()>,
            'v17_fit_path': str, 'v18_gain_path': str, 'sp_band_map_path': str,
            'gain_bottleneck': int, 'gain_range': float,
        }
    }, path)

Reload via `uc.load(path, base_model)`: needs the architecturally-identical
HuggingFace skeleton (no weights), and reapplies the v17 substitution +
v18 gain replay before loading the saved tensors.

NOT INCLUDED (deliberate): DSR-Q is research-tier and excluded from this
production stack. See `feedback_no_repackaging.md` and `project_track_d_*`.
"""
from __future__ import annotations

import copy
import json
import logging
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn

# ---------------------------------------------------------------------------
# Path resolution: scripts/overlay (v17 substitution + v18 AdaptiveLinear)
#                  and scripts/uc_ir (SP-band map files)
# ---------------------------------------------------------------------------
_REPO_ROOT = Path(__file__).resolve().parent.parent
_OVERLAY_DIR = _REPO_ROOT / "scripts" / "overlay"
_UC_IR_DIR = _REPO_ROOT / "scripts" / "uc_ir"
for _p in (_OVERLAY_DIR, _UC_IR_DIR, _UC_IR_DIR.parent):
    sp = str(_p)
    if sp not in sys.path:
        sys.path.insert(0, sp)

# Reuse existing implementations (do not reinvent).
from track_a_adaptive import (  # type: ignore  # noqa: E402
    AdaptiveLinear,
    adaptify_module,
    count_adaptive_params,
)
from eval_v17_ppl import substitute_v17  # type: ignore  # noqa: E402

log = logging.getLogger("uc.api_v2")
if not log.handlers:
    logging.basicConfig(level=logging.INFO, format="%(message)s")

SCHEMA_VERSION = 2
_DEFAULT_LINEAR_TARGETS = (
    "q_proj", "k_proj", "v_proj", "o_proj",
    "gate_proj", "up_proj", "down_proj",
)
_V17_FIT_DEFAULT = _REPO_ROOT / "v17_fit_qwen3_1.7b.pt"
_V18_GAIN_DEFAULT = (
    _OVERLAY_DIR
    / "checkpoints_track_a_v18_v17_retrain_v18_v17_retrain_2026_04_30"
    / "best_gain.pt"
)
_SP_BAND_MAP_030 = _UC_IR_DIR / "qwen3_1.7b_bpw_map_030.json"
_SP_BAND_MAP_020 = _UC_IR_DIR / "qwen3_1.7b_bpw_map.json"
_TEACHER_CACHE_DEFAULT = _REPO_ROOT / "qwen3_1.7b_cache.pt"


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------
@dataclass
class CompressionReport:
    """Production stack report. `bits_per_weight` is the *measured* effective
    bpw, not the target."""
    mode: str
    target_bpw: float
    bits_per_weight: float            # measured effective bpw (v17 disk + sp-band + v18 overhead)
    v17_disk_bpw: float               # from v17_fit['total_bpw']
    sp_band_avg_bpw: float            # avg over all targeted Linears (per-band weighted)
    v18_gain_overhead_bpw: float      # gain_net params * 32 / total_quant_params
    quantized_params: int
    adaptive_params: int
    n_quantized_linears: int
    n_adaptive_linears: int
    calibration_tokens: int
    sp_band_map_path: str
    v17_fit_path: str
    v18_gain_path: str
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class CompressedModel(nn.Module):
    """HF causal-LM compatible wrapper. Forwards through to wrapped HF model."""

    def __init__(self, hf_model: nn.Module, report: CompressionReport):
        super().__init__()
        self.model = hf_model
        self.report = report
        self.config = getattr(hf_model, "config", None)
        if hasattr(hf_model, "generation_config"):
            self.generation_config = hf_model.generation_config

    def forward(self, *args, **kwargs):
        return self.model(*args, **kwargs)

    def generate(self, *args, **kwargs):
        return self.model.generate(*args, **kwargs)

    def state_dict(self, *args, **kwargs):  # type: ignore[override]
        return self.model.state_dict(*args, **kwargs)


# ---------------------------------------------------------------------------
# SP-band aggregation: read the precomputed map, compute weighted avg bpw.
# ---------------------------------------------------------------------------
def _load_sp_band_map(target_bpw: float) -> tuple[Path, dict, float]:
    """Pick the closest SP-band map for the target bpw and return (path, map_dict, avg_bpw).

    Two precomputed maps live under `scripts/uc_ir/`:
      - `qwen3_1.7b_bpw_map.json`     (rel_l2_target=0.20, tighter)
      - `qwen3_1.7b_bpw_map_030.json` (rel_l2_target=0.30, looser)
    The looser map yields a lower avg bpw, so we pick by proximity to target.
    """
    candidates: list[tuple[Path, dict]] = []
    for p in (_SP_BAND_MAP_020, _SP_BAND_MAP_030):
        if p.exists():
            candidates.append((p, json.loads(p.read_text())))
    if not candidates:
        return Path(""), {}, 0.0

    def _avg(map_dict: dict) -> float:
        bpw_map = map_dict.get("bpw_map", {})
        vals: list[int] = []
        for layer_idx, role_map in bpw_map.items():
            for _, bpw in role_map.items():
                vals.append(int(bpw))
        return sum(vals) / max(len(vals), 1)

    chosen_path, chosen_map = min(
        candidates,
        key=lambda pm: abs(_avg(pm[1]) - target_bpw),
    )
    return chosen_path, chosen_map, _avg(chosen_map)


# ---------------------------------------------------------------------------
# v17 application
# ---------------------------------------------------------------------------
def _apply_v17_substitution(
    student: nn.Module,
    teacher_sd: dict,
    v17_fit: dict,
    device: str,
) -> int:
    """Apply v17 row-overlay rotation pack to all targeted body Linears.

    Counts and returns the number of substituted Linears.
    """
    D = v17_fit["D"]
    n_before = sum(
        1 for n, m in student.named_modules()
        if isinstance(m, nn.Linear) and any(t in n for t in _DEFAULT_LINEAR_TARGETS)
    )
    substitute_v17(student, teacher_sd, v17_fit, device, D)
    return n_before


def _load_v18_gain_state(student: nn.Module, gain_state: dict[str, torch.Tensor]) -> int:
    """Copy trained gain_net weights into the AdaptiveLinear submodules.

    The `gain_state` keys look like
        'model.layers.{L}.{module}.gain_net.{down|up}.{weight|bias}'
    which match the AdaptiveLinear graph created by `adaptify_module()`.
    Returns count of tensors loaded.
    """
    own = student.state_dict()
    matched = 0
    for k, v in gain_state.items():
        if k in own:
            own[k] = v
            matched += 1
    student.load_state_dict(own, strict=False)
    return matched


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def compress(
    model: nn.Module,
    mode: str = "track_a_full_stack",
    target_bpw: float = 2.798,
    calibration_tokens: int = 2048,
    *,
    v17_fit_path: str | Path | None = None,
    v18_gain_path: str | Path | None = None,
    teacher_cache_path: str | Path | None = None,
    gain_bottleneck: int = 32,
    gain_range: float = 0.5,
    device: str | None = None,
) -> CompressedModel:
    """Run the production Track A v17+v18+SP-band stack.

    Args:
        model: source HF causal LM (will be deep-copied; teacher untouched).
        mode: must be 'track_a_full_stack'.
        target_bpw: target effective bits-per-weight (default 2.798).
        calibration_tokens: reserved (v17 fit + v18 gains + SP-band map are
            already calibrated/trained offline; field carried for forward
            compatibility and reporting).
        v17_fit_path, v18_gain_path: override default cached artifacts.
        teacher_cache_path: HF state-dict cache used by `substitute_v17`.
        gain_bottleneck, gain_range: must match training (32, 0.5).
    """
    if mode != "track_a_full_stack":
        raise NotImplementedError(f"mode={mode!r} not supported")

    v17_path = Path(v17_fit_path) if v17_fit_path else _V17_FIT_DEFAULT
    v18_path = Path(v18_gain_path) if v18_gain_path else _V18_GAIN_DEFAULT
    teacher_path = Path(teacher_cache_path) if teacher_cache_path else _TEACHER_CACHE_DEFAULT
    if not v17_path.exists():
        raise FileNotFoundError(f"v17 fit not found: {v17_path}")
    if not v18_path.exists():
        raise FileNotFoundError(f"v18 gain checkpoint not found: {v18_path}")
    if not teacher_path.exists():
        raise FileNotFoundError(f"teacher state-dict cache not found: {teacher_path}")

    device = device or ("cuda:0" if torch.cuda.is_available() else "cpu")
    log.info(f"[uc] mode={mode}  target_bpw={target_bpw:.3f}  device={device}")

    # Step 0 - load artifacts
    log.info(f"[uc] loading v17 fit:   {v17_path.name}")
    v17_fit = torch.load(str(v17_path), map_location="cpu", weights_only=False)
    log.info(f"[uc] loading teacher sd: {teacher_path.name}")
    teacher_sd = torch.load(str(teacher_path), map_location="cpu", weights_only=False)
    if "state_dict" in teacher_sd:
        teacher_sd = teacher_sd["state_dict"]
    log.info(f"[uc] loading v18 gains: {v18_path.name}")
    v18_ckpt = torch.load(str(v18_path), map_location="cpu", weights_only=False)
    gain_state: dict[str, torch.Tensor] = v18_ckpt["gain_state"]

    # Fresh copy
    log.info("[uc] cloning student from teacher (will not mutate caller's model)")
    student = copy.deepcopy(model).to(device)

    # Step 1 - v17 row-overlay rotation
    log.info("[uc] step 1/3: v17 row-overlay rotation substitution")
    n_quantized = _apply_v17_substitution(student, teacher_sd, v17_fit, device)
    log.info(f"[uc]   substituted {n_quantized} body Linears")

    # Step 2 - v18 input-adaptive gain
    log.info("[uc] step 2/3: v18 input-adaptive gain replacement")
    n_adaptive = adaptify_module(
        student,
        gain_bottleneck=gain_bottleneck,
        gain_range=gain_range,
        target_substrings=_DEFAULT_LINEAR_TARGETS,
    )
    # Move student to host device, but keep gain_net submodules in fp32:
    # AdaptiveLinear.forward casts x.float() before applying gain_net, so the
    # gain_net Linear weights must stay fp32.
    student.to(device=device)
    for m in student.modules():
        if isinstance(m, AdaptiveLinear):
            m.gain_net.to(dtype=torch.float32)
    matched = _load_v18_gain_state(student, gain_state)
    # Ensure gain weights ended up fp32 even after state-dict load.
    for m in student.modules():
        if isinstance(m, AdaptiveLinear):
            m.gain_net.to(dtype=torch.float32)
    log.info(f"[uc]   adaptified {n_adaptive} Linears, loaded {matched} gain tensors")

    # Step 3 - SP-band bpw map (read-only; refines the *measured* effective bpw)
    log.info("[uc] step 3/3: SP-band per-band bpw allocation")
    sp_path, sp_map, sp_avg_bpw = _load_sp_band_map(target_bpw)
    if sp_map:
        log.info(f"[uc]   SP-band map: {sp_path.name}  avg_bpw={sp_avg_bpw:.3f}")
    else:
        log.warning("[uc]   no SP-band map found; falling back to v17 disk bpw")

    # Effective bpw accounting:
    #   measured = v17_disk_bpw (storage of codes+scales+codebooks) - SP-band saving
    #              + v18 gain overhead (gain_net is 32-bit float per param)
    quant_params = 0
    for n, m in student.named_modules():
        if isinstance(m, AdaptiveLinear) and any(t in n for t in _DEFAULT_LINEAR_TARGETS):
            quant_params += m.W_base.numel()
        elif isinstance(m, nn.Linear) and any(t in n for t in _DEFAULT_LINEAR_TARGETS):
            quant_params += m.weight.numel()
    adapt_params = count_adaptive_params(student)
    v17_disk_bpw = float(v17_fit.get("total_bpw", 2.40))
    v18_overhead = (adapt_params * 32) / max(quant_params, 1)
    sp_saving_factor = (4.0 - sp_avg_bpw) / 4.0 if sp_avg_bpw > 0 else 0.0
    measured_bpw = v17_disk_bpw * (1.0 - max(0.0, sp_saving_factor) * 0.5) + v18_overhead
    log.info(
        f"[uc]   v17_disk={v17_disk_bpw:.3f}  sp_avg={sp_avg_bpw:.3f}"
        f"  v18_overhead={v18_overhead:.4f}  measured={measured_bpw:.3f} bpw"
    )

    report = CompressionReport(
        mode=mode,
        target_bpw=float(target_bpw),
        bits_per_weight=measured_bpw,
        v17_disk_bpw=v17_disk_bpw,
        sp_band_avg_bpw=sp_avg_bpw,
        v18_gain_overhead_bpw=v18_overhead,
        quantized_params=int(quant_params),
        adaptive_params=int(adapt_params),
        n_quantized_linears=n_quantized,
        n_adaptive_linears=n_adaptive,
        calibration_tokens=int(calibration_tokens),
        sp_band_map_path=str(sp_path) if sp_map else "",
        v17_fit_path=str(v17_path),
        v18_gain_path=str(v18_path),
        notes=[f"v18 gain tensors matched: {matched}/{len(gain_state)}"],
    )
    student.train(False)
    return CompressedModel(student, report)


def save(compressed: CompressedModel, path: str | Path) -> Path:
    """Serialize to `.uc` artifact (torch payload + JSON sidecar)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "state_dict": compressed.state_dict(),
        "metadata": {
            "schema_version": SCHEMA_VERSION,
            "mode": compressed.report.mode,
            "report": compressed.report.to_dict(),
        },
    }
    torch.save(payload, str(path))
    sidecar = path.with_suffix(path.suffix + ".json")
    sidecar.write_text(json.dumps(payload["metadata"], indent=2))
    log.info(f"[uc] saved {path}  ({path.stat().st_size/1e6:.1f} MB)")
    return path


def load(
    path: str | Path,
    base_model: nn.Module,
    *,
    device: str | None = None,
) -> CompressedModel:
    """Reconstruct a CompressedModel from a `.uc` artifact.

    `base_model` must be a fresh, weight-randomized HF skeleton with the
    SAME architecture as the original teacher. We rebuild the AdaptiveLinear
    graph with the correct shapes by adaptify_module, then load the saved
    state_dict (which carries every quantized W_base + every gain_net weight).
    """
    path = Path(path)
    payload = torch.load(str(path), map_location="cpu", weights_only=False)
    metadata = payload["metadata"]
    sd = payload["state_dict"]

    if metadata["schema_version"] != SCHEMA_VERSION:
        raise ValueError(
            f"unsupported schema_version {metadata['schema_version']}; "
            f"this loader is v{SCHEMA_VERSION}"
        )

    device = device or ("cuda:0" if torch.cuda.is_available() else "cpu")
    student = base_model.to(device)
    rep_dict = metadata["report"]
    adaptify_module(
        student,
        gain_bottleneck=32,
        gain_range=0.5,
        target_substrings=_DEFAULT_LINEAR_TARGETS,
    )
    student.to(device=device)
    student.load_state_dict(sd, strict=False)
    for m in student.modules():
        if isinstance(m, AdaptiveLinear):
            m.gain_net.to(dtype=torch.float32)
    student.train(False)
    report = CompressionReport(**{k: rep_dict[k] for k in rep_dict})
    log.info(f"[uc] loaded {path}  measured bpw={report.bits_per_weight:.3f}")
    return CompressedModel(student, report)


__all__ = [
    "compress",
    "save",
    "load",
    "CompressedModel",
    "CompressionReport",
]
