"""ultracompress.server — FastAPI inference server skeleton.

The FastAPI app lives in `ultracompress.server.main:app`; uvicorn loads it
directly. UC_MODEL_PATH is validated by the lifespan handler at process
start, not at import time.
"""
