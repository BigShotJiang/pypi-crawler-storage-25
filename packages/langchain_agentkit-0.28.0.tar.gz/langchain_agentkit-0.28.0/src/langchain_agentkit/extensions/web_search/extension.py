"""WebSearchExtension — fan-out web search across multiple providers.

Usage::

    from langchain_agentkit import WebSearchExtension, QwantSearchProvider

    mw = WebSearchExtension()  # defaults to built-in Qwant provider
    mw = WebSearchExtension(providers=[my_search_tool, another_search_fn])

    # Use QwantSearchProvider standalone as any other LangChain tool
    tool = QwantSearchProvider()
    result = tool.invoke("latest AI news")
    tools = mw.tools           # [WebSearch]
    prompt = mw.prompt(state, runtime)  # Search guidance with provider names
"""

from __future__ import annotations

import asyncio
import json
import platform
import urllib.parse
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING, Any, override

from langchain_core.prompts import PromptTemplate
from langchain_core.tools import BaseTool

from langchain_agentkit.extension import Extension
from langchain_agentkit.extensions.web_search.tools.web_search import _WebSearchTool

if TYPE_CHECKING:
    from collections.abc import Callable


_PROMPT_FILE = Path(__file__).parent / "prompt.md"

_web_search_system_prompt = PromptTemplate.from_file(_PROMPT_FILE)


def _default_user_agent() -> str:
    """Build a User-Agent string from the host machine's platform info."""
    system = platform.system()
    release = platform.release()
    machine = platform.machine()
    py = platform.python_version()
    return f"langchain-agentkit/Python {py} ({system} {release}; {machine})"


class DuckDuckGoSearchProvider(BaseTool):
    """Built-in web search using DuckDuckGo's instant answer API.

    No API key required. Returns abstracts, related topics, and
    direct answers from DuckDuckGo's public API.

    Args:
        max_results: Maximum number of related topics to return.
        headers: HTTP headers for requests. Defaults to a User-Agent
            derived from the host machine's platform info.
    """

    name: str = "DuckDuckGoSearch"
    description: str = "Search the web using DuckDuckGo."
    max_results: int = 5
    headers: dict[str, str] | None = None

    def __init__(self, **kwargs: Any) -> None:
        if "headers" not in kwargs or kwargs["headers"] is None:
            kwargs["headers"] = {"User-Agent": _default_user_agent()}
        super().__init__(**kwargs)

    @override
    def _run(self, query: str) -> str:
        """Sync search via DuckDuckGo instant answer API."""
        params = urllib.parse.urlencode(
            {"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
        )
        url = f"https://api.duckduckgo.com/?{params}"
        request = urllib.request.Request(url, headers=self.headers)  # type: ignore[arg-type]
        with urllib.request.urlopen(request, timeout=10) as response:
            data = json.loads(response.read().decode())

        results: list[str] = []

        # Abstract (main answer)
        abstract = data.get("Abstract", "")
        abstract_url = data.get("AbstractURL", "")
        if abstract:
            source = data.get("AbstractSource", "")
            results.append(f"**{source}**: {abstract}")
            if abstract_url:
                results.append(f"  Source: {abstract_url}")

        # Related topics
        for topic in data.get("RelatedTopics", [])[: self.max_results]:
            text = topic.get("Text", "")
            first_url = topic.get("FirstURL", "")
            if text:
                results.append(f"- {text}")
                if first_url:
                    results[-1] += f" ({first_url})"

        if not results:
            return "No results found."
        return "\n".join(results)

    @override
    async def _arun(self, query: str) -> str:
        """Async version — runs sync in executor (urllib has no async)."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._run, query)


class QwantSearchProvider(BaseTool):
    """Web search provider using Qwant's API. No API key required.

    Note: Qwant's API may block requests depending on region or rate
    limits. Use :class:`DuckDuckGoSearchProvider` as a more reliable
    alternative.

    Args:
        max_results: Maximum number of results to return.
        locale: Search locale (e.g., ``"en_US"``, ``"fr_FR"``).
        safesearch: Safe search level: 0=off, 1=moderate, 2=strict.
        headers: HTTP headers for requests.
    """

    name: str = "QwantSearch"
    description: str = "Search the web using Qwant."
    max_results: int = 5
    locale: str = "en_US"
    safesearch: int = 1
    headers: dict[str, str] | None = None

    def __init__(self, **kwargs: Any) -> None:
        if "headers" not in kwargs or kwargs["headers"] is None:
            kwargs["headers"] = {"User-Agent": _default_user_agent()}
        super().__init__(**kwargs)

    @override
    def _run(self, query: str) -> str:
        """Sync search via Qwant API."""
        params = urllib.parse.urlencode(
            {
                "q": query,
                "count": self.max_results,
                "locale": self.locale,
                "safesearch": self.safesearch,
            },
        )
        url = f"https://api.qwant.com/v3/search/web?{params}"
        request = urllib.request.Request(url, headers=self.headers)  # type: ignore[arg-type]
        with urllib.request.urlopen(request, timeout=10) as response:
            data = json.loads(response.read().decode())
        items = data.get("data", {}).get("result", {}).get("items", [])
        if not items:
            return "No results found."
        results = []
        for item in items[: self.max_results]:
            title = item.get("title", "")
            item_url = item.get("url", "")
            snippet = item.get("desc", "")
            results.append(f"- [{title}]({item_url}): {snippet}")
        return "\n".join(results)

    @override
    async def _arun(self, query: str) -> str:
        """Async version — runs sync in executor."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._run, query)


class WebSearchExtension(Extension):
    """Extension providing a single WebSearch tool that fans out to
    multiple configured search providers in parallel.

    Each provider is a BaseTool or callable supplied by the application.
    The extensions creates a single ``WebSearch`` tool that:
    1. Calls all providers concurrently via asyncio.gather
    2. Returns results attributed per provider

    Args:
        providers: List of search providers. Each is a BaseTool instance
            or a callable with signature ``(query: str) -> str``.
            Callables are auto-wrapped into BaseTool via @tool.
            When ``None`` or empty, defaults to the built-in Qwant provider.
        prompt_template: Optional custom prompt template path or string.
            Defaults to built-in search guidance.

    Example::

        mw = WebSearchExtension()  # uses built-in Qwant provider
        mw = WebSearchExtension(providers=[my_search_tool])
        mw.tools   # [WebSearch]
        mw.prompt(state, runtime)  # Search guidance with provider names
    """

    def __init__(
        self,
        *,
        providers: list[BaseTool | Callable[[str], str]] | None = None,
        prompt_template: str | Path | None = None,
    ) -> None:
        if providers is None or len(providers) == 0:
            providers = [QwantSearchProvider()]

        self._providers = [self._resolve_provider(p) for p in providers]
        self._prompt_template = self._load_prompt(prompt_template)
        self._tools: list[BaseTool] = [_WebSearchTool(providers=self._providers)]

    def _resolve_provider(self, provider: BaseTool | Callable[[str], str]) -> BaseTool:
        if isinstance(provider, BaseTool):
            return provider
        if callable(provider):
            from langchain_core.tools.structured import StructuredTool

            description = getattr(provider, "__doc__", None) or "Search provider."
            return StructuredTool.from_function(
                func=provider,
                description=description,
            )
        raise TypeError(
            f"Each provider must be a BaseTool or callable, got {type(provider).__name__!r}"
        )

    def _load_prompt(self, prompt_template: str | Path | None) -> PromptTemplate:
        if prompt_template is None:
            return _web_search_system_prompt
        path = Path(prompt_template)
        if path.exists():
            return PromptTemplate.from_file(path)
        return PromptTemplate.from_template(str(prompt_template))

    @property
    @override
    def state_schema(self) -> None:
        """No additional state keys."""
        return None

    @property
    @override
    def tools(self) -> list[BaseTool]:
        """Returns [WebSearch] — same list object on every access."""
        return self._tools

    @override
    def prompt(
        self,
        state: dict[str, Any],
        runtime: Any | None = None,
        *,
        tools: frozenset[str] = frozenset(),
    ) -> str | None:
        """No system-prompt contribution — all guidance lives on the
        ``WebSearch`` tool description.
        """
        return None
