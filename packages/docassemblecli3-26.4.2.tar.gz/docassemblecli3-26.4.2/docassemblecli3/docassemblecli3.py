import configparser
import datetime
import hashlib
import os
import re
import stat
import subprocess
import tempfile
import threading
import time
import zipfile
from functools import wraps
from urllib.parse import urlparse

import click
import gitmatch
import niquests as requests
import yaml
from packaging.licenses import LICENSES as SPDX_LICENSES
from packaging import version as packaging_version
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer
import tomllib

global DEFAULT_CONFIG
DEFAULT_CONFIG = os.path.join(os.path.expanduser("~"), ".docassemblecli")

global PROJECT_CONFIG
PROJECT_CONFIG = ".docassemblecli"

global LAST_MODIFIED
LAST_MODIFIED = {
    "time": 0,
    "files": {},
    "restart": False,
}

global FULL_INSTALL_DONE
FULL_INSTALL_DONE = False

global FILE_CHECKSUMS
FILE_CHECKSUMS = {}

global DEBUG
DEBUG = False

global BELL
BELL = "\a"

global EXCLUDED_DIRECTORIES
EXCLUDED_DIRECTORIES = [".git", "__pycache__", ".mypy_cache", ".venv", ".history", "build"]

global GITMATCH_COMPILED
GITMATCH_COMPILED = None

global GITMATCH_DIRECTORY
GITMATCH_DIRECTORY = None

global GITIGNORE_MTIME
GITIGNORE_MTIME = None

global WATCH_IGNORE_MTIME
WATCH_IGNORE_MTIME = None

global WATCH_SETTLE_DELAY
WATCH_SETTLE_DELAY = 0.6

global GITIGNORE
GITIGNORE = """\
__pycache__/
*.py[cod]
*$py.class
.mypy_cache/
.dmypy.json
dmypy.json
*.egg-info/
.installed.cfg
*.egg
.vscode
*~
~*
*.~lock.*
.#*
.coverage*
en
*/auto
.history/
.idea
.dir-locals.el
.flake8
*.swp
*.swx
*.tmp
*.tmp.*
.DS_Store
.envrc
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
share/python-wheels/
"""

global WATCH_IGNORE_FILE
WATCH_IGNORE_FILE = ".dawatchignore"


# -----------------------------------------------------------------------------
# click
# -----------------------------------------------------------------------------


CONTEXT_SETTINGS = dict(help_option_names=["--help", "-h"])


@click.group(context_settings=CONTEXT_SETTINGS)
@click.version_option()
@click.option(
    "--bell/--no-bell",
    default=True,
    show_default=True,
    help="Play bell sound notification.",
)
@click.option(
    "--color/--no-color",
    "-C/-N",
    default=None,
    show_default=True,
    help="Overrides color auto-detection in interactive terminals.",
)
@click.option("--debug/--no-debug", default=False, hidden=True)
def cli(bell, color, debug):
    """
    Commands for working with docassemble packages and servers.
    """
    if not bell:
        global BELL
        BELL = ""
    CONTEXT_SETTINGS["color"] = color
    if debug:
        global DEBUG
        DEBUG = True


@cli.group(context_settings=CONTEXT_SETTINGS)
def config():
    """
    Manage servers in a docassemblecli config file.
    """
    pass


def common_params_for_api(func):
    @click.option(
        "--api",
        "-a",
        type=(APIURLType(), str),
        default=(None, None),
        help="URL of the docassemble server and API key of the user (admin or developer)",
    )
    @click.option("--server", "-s", metavar="SERVER", default="", help="Specify a server from the config file")
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


def common_params_for_config(func):
    @click.option(
        "--config",
        "-c",
        default=DEFAULT_CONFIG,
        type=click.Path(),
        callback=validate_and_load_or_create_config,
        show_default=True,
        help="Specify the config file to use",
    )
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


def common_params_for_installation(func):
    @click.option(
        "--directory",
        "-d",
        default=os.getcwd(),
        type=click.Path(),
        callback=validate_package_directory,
        help="Specify package directory [default: current directory]",
    )
    @click.option(
        "--config",
        "-c",
        is_flag=False,
        flag_value="",
        default=DEFAULT_CONFIG,
        type=click.Path(),
        callback=validate_and_load_or_create_config,
        show_default=True,
        help="Specify the config file to use or leave it blank to skip using any config file",
    )
    @click.option(
        "--project-config/--no-project-config",
        default=True,
        show_default=True,
        help="Use .docassemblecli from the package directory first, then fall back to the selected config file",
    )
    @click.option(
        "--playground",
        "-p",
        metavar="(PROJECT)",
        is_flag=False,
        flag_value="default",
        help="Install into the default Playground or into the specified Playground project.",
    )
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


def common_params_for_runtime_config(func):
    @click.option(
        "--config",
        "-c",
        is_flag=False,
        flag_value="",
        default=DEFAULT_CONFIG,
        type=click.Path(),
        callback=validate_and_load_or_create_config,
        show_default=True,
        help="Specify the config file to use or leave it blank to skip using any config file",
    )
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


def common_params_for_directory_and_playground(func):
    @click.option(
        "--directory",
        "-d",
        default=os.getcwd(),
        type=click.Path(),
        callback=validate_package_directory,
        help="Specify package directory [default: current directory]",
    )
    @click.option(
        "--playground",
        "-p",
        metavar="(PROJECT)",
        is_flag=False,
        flag_value="default",
        help="Install into the default Playground or into the specified Playground project.",
    )
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


class APIURLType(click.ParamType):
    name = "url"

    def convert(self, value, param, ctx):
        parsed_url = urlparse(value)
        if all([re.search(r"""^https?://[^\s]+$""", value), parsed_url.scheme, parsed_url.netloc]):
            return f"""{parsed_url.scheme}://{parsed_url.netloc}"""
        else:
            self.fail(f""""{value}" is not a valid URL""", param, ctx)


def package_metadata_files_present(directory: str) -> bool:
    return any(
        os.path.isfile(os.path.join(directory, filename)) for filename in ("setup.py", "setup.cfg", "pyproject.toml")
    )


def parse_dependency_strings(dependency_strings) -> dict:
    dependencies = {}
    for dependency_string in dependency_strings:
        if not isinstance(dependency_string, str):
            continue
        dependency_string = dependency_string.strip().rstrip(",")
        if not dependency_string or dependency_string.startswith("#"):
            continue
        dependency_string = dependency_string.split(";", 1)[0].strip()
        mm = re.search(r"""(.*?)(<=|>=|==|<|>)(.*)""", dependency_string)
        if mm:
            dependencies[mm.group(1).strip()] = {
                "installed": False,
                "operator": mm.group(2),
                "version": mm.group(3).strip(),
            }
        else:
            dependencies[dependency_string] = {"installed": False, "operator": None, "version": None}
    return dependencies


def load_package_metadata(directory: str, files: list[str]) -> tuple[str | None, dict]:
    this_package_name = None
    dependencies = {}

    if "pyproject.toml" in files:
        with open(os.path.join(directory, "pyproject.toml"), "rb") as fp:
            data = tomllib.load(fp)
        project = data.get("project", {})
        if isinstance(project, dict):
            if isinstance(project.get("name"), str):
                this_package_name = project["name"].strip()
            dependencies.update(parse_dependency_strings(project.get("dependencies", [])))

    if "setup.cfg" in files:
        parser = configparser.ConfigParser()
        parser.read(os.path.join(directory, "setup.cfg"), encoding="utf-8")
        if not this_package_name and parser.has_option("metadata", "name"):
            this_package_name = parser.get("metadata", "name").strip()
        if parser.has_option("options", "install_requires"):
            dependencies.update(parse_dependency_strings(parser.get("options", "install_requires").splitlines()))

    if "setup.py" in files:
        with open(os.path.join(directory, "setup.py"), "r", encoding="utf-8") as fp:
            setup_text = fp.read()
        if not this_package_name:
            m = re.search(r"""setup\(.*\bname=(["\'])(.*?)(["\'])""", setup_text)
            if m and m.group(1) == m.group(3):
                this_package_name = m.group(2).strip()
        m = re.search(r"""setup\(.*install_requires=\[(.*?)\]""", setup_text, flags=re.DOTALL)
        if m:
            package_texts = [package_text.strip() for package_text in m.group(1).split(",")]
            install_requires = []
            for package_name in package_texts:
                if len(package_name) >= 3 and package_name[0] == package_name[-1] and package_name[0] in ("'", '"'):
                    install_requires.append(package_name[1:-1])
            dependencies.update(parse_dependency_strings(install_requires))

    return this_package_name, dependencies


def normalize_package_name(package: str) -> str:
    package_name = re.sub(r"^docassemble-", "docassemble.", package)
    if not package_name.startswith("docassemble."):
        package_name = "docassemble." + package_name
    return package_name


def normalize_license_string(license_name: str) -> str:
    normalized_license = license_name.strip()
    if not normalized_license:
        return ""
    spdx_license = SPDX_LICENSES.get(normalized_license.lower())
    if spdx_license:
        return spdx_license["id"]
    if re.search(r"^LicenseRef-[A-Za-z\-0-9]+$", normalized_license):
        return normalized_license
    return "LicenseRef-" + re.sub(r"[^A-Za-z\-0-9]", "", normalized_license)


def announce_installed() -> None:
    click.secho(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] Installed.{BELL}", fg="green")


def format_install_location(playground: str | None) -> str:
    if not playground:
        return "Package"
    return f'''Playground "{playground}"'''


def show_dry_run_file_hint(show_files: bool) -> None:
    if not show_files:
        click.echo("Use --show-files to list the files in the preview.")


def show_dry_run_package_install(
    playground: str | None, should_restart: bool, archived_files: list[str], show_files: bool = False
) -> None:
    click.secho("Dry run: no changes were sent.", fg="cyan")
    click.echo(f"Would upload {len(archived_files)} file(s) to {format_install_location(playground)}.")
    click.echo(f"Would restart server: {'yes' if should_restart else 'no'}")
    if show_files and archived_files:
        click.echo("Files to upload:")
        for archived_file in archived_files:
            click.echo("  " + archived_file)
    elif archived_files:
        show_dry_run_file_hint(show_files)


def show_dry_run_playground_upload(playground: str, uploads: dict[str, list[str]], show_files: bool = False) -> None:
    total_files = sum(len(files_to_upload) for files_to_upload in uploads.values())
    click.secho("Dry run: no changes were sent.", fg="cyan")
    click.echo(f"Would upload {total_files} changed file(s) to {format_install_location(playground)}.")
    click.echo(f"Would restart server: {'yes' if uploads['modules'] else 'no'}")
    click.echo("Folders to upload:")
    for folder in ("questions", "sources", "static", "templates", "modules"):
        if uploads[folder]:
            click.echo(f"  {folder}: {len(uploads[folder])}")
    if show_files:
        click.echo("Files to upload:")
        for folder in ("questions", "sources", "static", "templates", "modules"):
            for file_path in uploads[folder]:
                click.echo("  " + file_path)
    elif total_files:
        show_dry_run_file_hint(show_files)


def playground_project_exists(project_data, playground: str) -> bool:
    if isinstance(project_data, list):
        for item in project_data:
            if item == playground:
                return True
            if isinstance(item, dict) and playground in (item.get("name"), item.get("project")):
                return True
        return False
    if isinstance(project_data, dict):
        for key in ("projects", "items", "results"):
            if key in project_data:
                return playground_project_exists(project_data[key], playground)
    return False


def http_request(method_name: str, url: str, **kwargs):
    request_method = getattr(requests, method_name)
    if getattr(request_method, "__module__", "").startswith("niquests"):
        with requests.Session(disable_http3=True) as session:
            return getattr(session, method_name)(url, **kwargs)
    return request_method(url, **kwargs)


def http_get(url: str, **kwargs):
    return http_request("get", url, **kwargs)


def http_post(url: str, **kwargs):
    return http_request("post", url, **kwargs)


def deduplicate_watch_events(file_events: dict) -> dict[str, str]:
    deduplicated = {}
    for file_path, event_types in file_events.items():
        if "created" in event_types:
            deduplicated[file_path] = "created"
        elif "modified" in event_types:
            deduplicated[file_path] = "modified"
        elif "deleted" in event_types:
            deduplicated[file_path] = "deleted"
    return deduplicated


def classify_playground_paths(changed_files: dict[str, str]) -> dict[str, list[str]] | None:
    uploads = {"questions": [], "sources": [], "static": [], "templates": [], "modules": []}
    for file_path, event_type in changed_files.items():
        normalized_path = "/".join(os.path.normpath(file_path).split(os.sep))
        if event_type == "deleted":
            if normalized_path.endswith(".py"):
                return None
            continue
        match = re.search(r"/docassemble/([^/]+)/data/([^/]+)/", normalized_path)
        if match and match.group(2) in uploads and match.group(2) != "modules":
            uploads[match.group(2)].append(file_path)
            continue
        match = re.search(r"/docassemble/([^/]+)/([^/]+)\.py$", normalized_path)
        if match:
            uploads["modules"].append(file_path)
            continue
        return None
    return uploads


def upload_playground_files(
    apiurl: str,
    apikey: str,
    playground: str,
    changed_files: dict[str, str],
    dry_run: bool = False,
    show_files: bool = False,
) -> bool:
    uploads = classify_playground_paths(changed_files)
    if uploads is None:
        return False
    if dry_run:
        show_dry_run_playground_upload(playground, uploads, show_files=show_files)
        return True

    for folder in ("questions", "sources", "static", "templates", "modules"):
        files_to_upload = uploads[folder]
        if not files_to_upload:
            continue
        for index, file_path in enumerate(files_to_upload):
            post_data = {
                "folder": folder,
                "restart": "1" if folder == "modules" and index == len(files_to_upload) - 1 else "0",
            }
            if playground and playground != "default":
                post_data["project"] = playground
            try:
                with open(file_path, "rb") as fp:
                    response = http_post(
                        apiurl + "/api/playground",
                        data=post_data,
                        files={"file": fp},
                        headers={"X-API-Key": apikey},
                        timeout=600,
                    )
            except FileNotFoundError:
                continue
            except Exception as err:
                click.secho(f"""\n{err.__class__.__name__}""", fg="red")
                raise click.ClickException(f"""{err}\n""")
            if response.status_code == 200:
                info = response.json()
                if not wait_for_server(True, info["task_id"], apikey, apiurl):
                    return False
            elif response.status_code != 204:
                return False
    return True


def validate_package_directory(ctx, param, directory: str) -> str:
    directory = os.path.abspath(directory)
    if not os.path.exists(directory):
        raise click.BadParameter(f"""Directory "{directory}" does not exist.""")
    if not package_metadata_files_present(directory):
        raise click.BadParameter(
            f"""Directory "{directory}" does not contain a setup.py, setup.cfg, or pyproject.toml file, so it is not the directory of a valid Python package."""
        )
    else:
        return directory


def validate_and_load_or_create_config(ctx, param, config: str) -> tuple[str, list]:
    if not config:
        return (None, [])
    config = os.path.abspath(config)
    if not os.path.isfile(config):
        if config == DEFAULT_CONFIG:
            env = []
            with open(config, "w", encoding="utf-8") as fp:
                yaml.dump(env, fp)
            os.chmod(config, stat.S_IRUSR | stat.S_IWUSR)
        else:
            raise click.BadParameter(f"""{config} doesn't exist.""")
    try:
        with open(config, "r", encoding="utf-8") as fp:
            env = yaml.load(fp, Loader=yaml.FullLoader)
            if not isinstance(env, list):
                raise Exception
    except Exception:
        raise click.BadParameter("File is not a usable docassemblecli config.")
    return (config, env)


def parse_project_command_config(data) -> tuple[list, dict[str, dict]]:
    if isinstance(data, list):
        return data, {"install": {}, "watch": {}}
    if not isinstance(data, dict):
        raise ValueError

    servers = data.get("servers", [])
    if servers is None:
        servers = []
    if not isinstance(servers, list):
        raise ValueError

    sections = {}
    for command_name in ("install", "watch"):
        section = data.get(command_name, {})
        if section is None:
            section = {}
        if not isinstance(section, dict):
            raise ValueError
        sections[command_name] = section
    return servers, sections


def load_project_command_config(directory: str, command_name: str) -> tuple[str, list, dict]:
    config_path = os.path.abspath(os.path.join(directory, PROJECT_CONFIG))
    if not os.path.isfile(config_path):
        raise click.BadParameter(f'"{config_path}" does not exist.', param_hint="--project-config")
    try:
        with open(config_path, "r", encoding="utf-8") as fp:
            data = yaml.load(fp, Loader=yaml.FullLoader)
        servers, sections = parse_project_command_config(data)
    except click.BadParameter:
        raise
    except Exception:
        raise click.BadParameter("File is not a usable project config.", param_hint="--project-config")
    return config_path, servers, sections.get(command_name, {})


def merge_command_config(selected_server: dict, command_config: dict, api_provided: bool = False) -> dict:
    merged_server = dict(selected_server)
    for key, value in command_config.items():
        if key == "server":
            continue
        if api_provided and key in ("apiurl", "apikey", "name"):
            continue
        merged_server[key] = value
    if not merged_server.get("name") and merged_server.get("apiurl"):
        merged_server["name"] = name_from_url(merged_server["apiurl"])
    return merged_server


def combine_config_envs(
    primary_config: tuple[str | None, list], secondary_config: tuple[str | None, list]
) -> tuple[str | None, list]:
    primary_cfg, primary_env = primary_config
    secondary_cfg, secondary_env = secondary_config
    effective_cfg = primary_cfg or secondary_cfg
    combined_env = list(primary_env or []) + list(secondary_env or [])
    return effective_cfg, combined_env


def resolve_command_server(
    command_name: str,
    directory: str,
    config: tuple[str | None, list],
    api: tuple[str | None, str | None],
    server: str,
    project_config: bool,
) -> dict:
    command_config = {}
    if project_config:
        project_config_path = os.path.abspath(os.path.join(directory, PROJECT_CONFIG))
        if os.path.isfile(project_config_path):
            project_cfg, project_env, command_config = load_project_command_config(directory, command_name)
            config = combine_config_envs((project_cfg, project_env), config)
    configured_server = command_config.get("server", "")
    selected_server = select_server(*config, *api, server or configured_server, directory=directory)
    if project_config:
        selected_server = merge_command_config(selected_server, command_config, api_provided=bool(api[0] and api[1]))
    return selected_server


def remove_server_references_from_project_config(directory: str, server_name: str) -> tuple[bool, str]:
    config_path, env, sections = load_or_create_project_config(directory)
    updated_env = [item for item in env if item.get("name") != server_name]
    updated_sections = {
        "install": dict(sections.get("install", {})),
        "watch": dict(sections.get("watch", {})),
    }

    changed = len(updated_env) != len(env)
    for command_name in ("install", "watch"):
        if updated_sections[command_name].get("server") == server_name:
            updated_sections[command_name].pop("server", None)
            changed = True

    if not changed:
        return False, config_path
    return save_project_config(config_path, updated_env, updated_sections), config_path


def resolve_command_server_with_cleanup(
    command_name: str,
    directory: str,
    config: tuple[str | None, list],
    api: tuple[str | None, str | None],
    server: str,
    project_config: bool,
) -> dict:
    try:
        return resolve_command_server(command_name, directory, config, api, server, project_config)
    except click.BadParameter as err:
        if not project_config or server:
            raise
        project_config_path = os.path.abspath(os.path.join(directory, PROJECT_CONFIG))
        if not os.path.isfile(project_config_path):
            raise
        project_cfg, _, command_config = load_project_command_config(directory, command_name)
        configured_server = command_config.get("server", "")
        if getattr(err, "message", "") != f'Server "{configured_server}" was not found.':
            raise
        if not click.confirm(
            f'Server "{configured_server}" from the local project config was not found. Remove it from {project_cfg}?',
            default=False,
        ):
            raise
        removed, config_path = remove_server_references_from_project_config(directory, configured_server)
        if removed:
            click.echo(f'Server "{configured_server}" has been removed from {config_path}.')
            return resolve_command_server(command_name, directory, config, api, server, project_config)
        raise


# -----------------------------------------------------------------------------
# utility functions
# -----------------------------------------------------------------------------


def name_from_url(url: str) -> str:
    if not url:
        return ""
    return urlparse(url).netloc


def display_servers(env: list = None) -> list[str]:
    if not env:
        return ["No servers found."]
    servers = []
    for idx, item in enumerate(env):
        server_label = item.get("name") or item.get("apiurl", "")
        if idx:
            servers.append(server_label)
        else:
            servers.append(server_label + " (default)")
        if "apiurl" in item:
            servers.append(f"""  apiurl: {item["apiurl"]}""")
        if "playground" in item:
            servers.append(f"""  playground: {item["playground"]}""")
        if "directory" in item:
            servers.append(f"""  directory: {item["directory"]}""")
        if "startup" in item:
            servers.append(f"""  startup: {item["startup"]}""")
    return servers


def display_project_command_sections(sections: dict[str, dict] | None) -> list[str]:
    if not sections:
        return []
    lines = []
    for command_name in ("install", "watch"):
        section = sections.get(command_name, {}) or {}
        if not section:
            continue
        lines.append(f"{command_name}:")
        for key in ("server", "playground", "startup"):
            if key in section:
                lines.append(f"  {key}: {section[key]}")
    return lines


def select_server(
    cfg: str = None, env: list = None, apiurl: str = None, apikey: str = None, server: str = "", **kwargs
) -> dict:
    if apiurl and apikey:
        return add_server_to_env(cfg=cfg, env=env, apiurl=apiurl, apikey=apikey)[-1]
    if isinstance(env, list):
        if server:
            if not cfg:
                raise click.BadParameter("Cannot be used without a config file.", param_hint="--server")
            else:
                for item in env:
                    if item.get("name", None) == server:
                        return item
                raise click.BadParameter(f"""Server "{server}" was not found.""", param_hint="--server")
        if len(env) > 0:
            if "directory" in kwargs:
                for item in env:
                    if item.get("directory", None) == kwargs["directory"]:
                        return item
            return env[0]
    if "DOCASSEMBLEAPIURL" in os.environ and "DOCASSEMBLEAPIKEY" in os.environ:
        apiurl: str = os.environ["DOCASSEMBLEAPIURL"]
        apikey: str = os.environ["DOCASSEMBLEAPIKEY"]
        return add_or_update_env(apiurl=apiurl, apikey=apikey)[0]
    return add_server_to_env(cfg, env)[0]


def add_or_update_env(
    env: list = None, apiurl: str = "", apikey: str = "", directory: str = "", playground: str = ""
) -> list:
    if not env:
        env: list = []
    apiname: str = name_from_url(apiurl)
    found: bool = False
    for item in env:
        if item.get("name", None) == apiname:
            item["apiurl"] = apiurl
            item["apikey"] = apikey
            if directory:
                item["directory"] = directory
            if playground:
                item["playground"] = playground
            found = True
            click.echo(f"""Server "{apiname}" was found and updated.""")
            break
    if not found:
        new_server = {"apiurl": apiurl, "apikey": apikey, "name": apiname}
        if directory:
            new_server["directory"] = directory
        if playground:
            new_server["playground"] = playground
        env.append(new_server)
    return env


def save_config(cfg: str, env: list) -> bool:
    try:
        with open(cfg, "w", encoding="utf-8") as fp:
            yaml.dump(env, fp)
        os.chmod(cfg, stat.S_IRUSR | stat.S_IWUSR)
    except Exception as err:
        click.echo(f"Unable to save {cfg} file. {err.__class__.__name__}: {err}")
        return False
    return True


def load_or_create_project_config(directory: str) -> tuple[str, list, dict[str, dict]]:
    config_path = os.path.abspath(os.path.join(directory, PROJECT_CONFIG))
    if not os.path.isfile(config_path):
        return config_path, [], {"install": {}, "watch": {}}
    try:
        with open(config_path, "r", encoding="utf-8") as fp:
            data = yaml.load(fp, Loader=yaml.FullLoader)
        env, sections = parse_project_command_config(data)
    except Exception:
        raise click.BadParameter("File is not a usable project config.", param_hint="--project-config")
    return config_path, env, sections


def save_project_config(config_path: str, env: list, sections: dict[str, dict]) -> bool:
    try:
        with open(config_path, "w", encoding="utf-8") as fp:
            yaml.dump({"servers": env, "install": sections.get("install", {}), "watch": sections.get("watch", {})}, fp)
    except Exception as err:
        click.echo(f"Unable to save {config_path} file. {err.__class__.__name__}: {err}")
        return False
    return True


def prompt_for_config_scope() -> str:
    valid_choices = {
        "g": "global",
        "global": "global",
        "l": "local",
        "local": "local",
    }
    while True:
        choice = (
            click.prompt(
                "Use the global config file or the local project config? ([g]lobal, [l]ocal)",
                default="global",
                show_default=True,
            )
            .strip()
            .lower()
        )
        if choice in valid_choices:
            return valid_choices[choice]
        click.echo('Please enter "g", "global", "l", or "local".')


def prompt_for_optional_playground() -> str | None:
    playground = click.prompt(
        "Default Playground project for this server (leave blank to skip; use 'default' for the default Playground)",
        default="",
        show_default=False,
    ).strip()
    return playground or None


def prompt_for_optional_directory() -> str | None:
    while True:
        directory = click.prompt(
            "Package directory to associate with this server (leave blank to skip)",
            default="",
            show_default=False,
        ).strip()
        if not directory:
            return None
        try:
            return validate_package_directory(None, None, directory)
        except click.BadParameter as err:
            click.echo(err.message)


def prompt_for_command_default(command_name: str) -> bool:
    return click.confirm(
        f"Use this server as the default for {command_name} in the local project config?",
        default=False,
        show_default=True,
    )


def prompt_for_command_playground(command_name: str) -> str | None:
    playground = click.prompt(
        f"Default Playground project for {command_name} in this project (leave blank to skip; use 'default' for the default Playground)",
        default="",
        show_default=False,
    ).strip()
    return playground or None


def prompt_for_watch_startup() -> str | None:
    if click.confirm("Install once when watch starts for this project?", default=False, show_default=True):
        return "install"
    return None


def resolve_project_config_directory(directory: str | None) -> str:
    if directory is not None:
        return validate_package_directory(None, None, directory)
    suggested_directory = os.getcwd()
    try:
        return validate_package_directory(None, None, suggested_directory)
    except click.BadParameter:
        pass
    while True:
        chosen_directory = click.prompt(
            "Package directory that should contain the local project config",
            default=suggested_directory,
            show_default=True,
        ).strip()
        try:
            return validate_package_directory(None, None, chosen_directory)
        except click.BadParameter as err:
            click.echo(err.message)


def resolve_config_target(
    config_path: str | None,
    use_project_config: bool,
    use_global_config: bool,
    directory: str | None,
) -> tuple[str, str, list, dict[str, dict] | None]:
    if use_project_config and (use_global_config or config_path):
        raise click.BadParameter("Cannot be combined with global config options.", param_hint="--project-config")

    if use_project_config:
        target_scope = "local"
    elif use_global_config or config_path:
        target_scope = "global"
    else:
        target_scope = prompt_for_config_scope()

    if target_scope == "local":
        project_directory = resolve_project_config_directory(directory)
        cfg, env, sections = load_or_create_project_config(project_directory)
        return target_scope, cfg, env, sections

    cfg, env = validate_and_load_or_create_config(None, None, config_path or DEFAULT_CONFIG)
    return target_scope, cfg, env, None


def prompt_for_api(retry: str = False, previous_url: str = None, previous_key: str = None) -> tuple[str, str]:
    if retry:
        if not click.confirm("Do you want to try another URL and API key?", default=True):
            raise click.Abort()
    apiurl = click.prompt(
        """Base URL of your docassemble server (e.g., https://da.example.com)""",
        type=APIURLType(),
        default=previous_url,
    )
    apikey = click.prompt(f"""API key of admin or developer user on {apiurl}""", default=previous_key).strip()
    return apiurl, apikey


def ensure_api_credentials(apiurl: str = None, apikey: str = None) -> tuple[str, str]:
    if not apiurl or not apikey:
        apiurl, apikey = prompt_for_api()
    while not test_apiurl_apikey(apiurl=apiurl, apikey=apikey):
        apiurl, apikey = prompt_for_api(retry=True, previous_url=apiurl, previous_key=apikey)
    return apiurl, apikey


def test_apiurl_apikey(apiurl: str, apikey: str) -> bool:
    click.echo("Testing the URL and API key...")
    try:
        api_test = http_get(apiurl + "/api/package", headers={"X-API-Key": apikey})
        if api_test.status_code != 200:
            if api_test.status_code == 403:
                click.secho(
                    f"""\nThe API KEY is invalid. ({api_test.status_code} {api_test.text.strip()})\n{BELL}""", fg="red"
                )
            else:
                click.secho(
                    f"""\nThe API URL or KEY is invalid. ({api_test.status_code} {api_test.text.strip()})\n{BELL}""",
                    fg="red",
                )
            return False
    except Exception as err:
        click.secho(f"""\n{err.__class__.__name__}""", fg="red")
        click.echo(f"""{err}\n""")
        return False
    click.secho(f"Success!{BELL}", fg="green")
    return True


def add_server_to_env(
    cfg: str = None,
    env: list = None,
    apiurl: str = None,
    apikey: str = None,
    directory: str = None,
    playground: str = None,
    validate_api: bool = True,
):
    if validate_api:
        apiurl, apikey = ensure_api_credentials(apiurl=apiurl, apikey=apikey)
    env = add_or_update_env(env=env, apiurl=apiurl, apikey=apikey, directory=directory, playground=playground)
    if cfg:
        if save_config(cfg, env):
            click.echo(f"""Configuration saved: {cfg}""")
    return env


def apply_project_command_defaults(
    sections: dict[str, dict],
    server_name: str,
    configure_install: bool,
    install_playground: str | None,
    configure_watch: bool,
    watch_playground: str | None,
    watch_startup: str | None,
) -> dict[str, dict]:
    updated_sections = {
        "install": dict(sections.get("install", {})),
        "watch": dict(sections.get("watch", {})),
    }
    if configure_install:
        updated_sections["install"]["server"] = server_name
        if install_playground:
            updated_sections["install"]["playground"] = install_playground
        else:
            updated_sections["install"].pop("playground", None)
    if configure_watch:
        updated_sections["watch"]["server"] = server_name
        if watch_playground:
            updated_sections["watch"]["playground"] = watch_playground
        else:
            updated_sections["watch"].pop("playground", None)
        if watch_startup == "install":
            updated_sections["watch"]["startup"] = watch_startup
        else:
            updated_sections["watch"].pop("startup", None)
    return updated_sections


def wait_for_server(playground: bool, task_id: str, apikey: str, apiurl: str, server_version_da: str = "0"):
    def wait_for_server_response(
        playground: bool, task_id: str, apikey: str, apiurl: str, server_version_da: str = "0"
    ):
        tries = 0
        info = {}
        before_wait_for_server = time.time()
        while tries < 300:
            if playground:
                full_url = apiurl + "/api/restart_status"
            else:
                full_url = apiurl + "/api/package_update_status"
            try:
                r = http_get(full_url, params={"task_id": task_id}, headers={"X-API-Key": apikey}, timeout=600)
            except requests.exceptions.RequestException:
                time.sleep(1)
                tries += 1
                continue
            if r.status_code != 200:
                return "package_update_status returned " + str(r.status_code) + ": " + r.text
            info = r.json()
            if info["status"] == "completed" or info["status"] == "unknown":
                break
            time.sleep(1)
            tries += 1
        after_wait_for_server = time.time()
        success = False
        if playground:
            if info.get("status", None) == "completed":
                success = True
        elif info.get("ok", False):
            success = True
        if not (
            server_version_da == "norestart"
            or packaging_version.parse(server_version_da) >= packaging_version.parse("1.5.3")
        ):
            if DEBUG:
                click.echo(f"""\rPackage install duration: {(after_wait_for_server - before_wait_for_server):.2f}s""")
                click.echo("""\rManually waiting for background processes.""")
            time.sleep(after_wait_for_server - before_wait_for_server)
        if success:
            return True
        click.secho("\nUnable to install package.\n", fg="red")
        if not playground:
            if "error_message" in info and isinstance(info["error_message"], str):
                click.secho(info["error_message"], fg="red")
            else:
                click.echo(info)
        return False

    def format_time(seconds):
        """Format seconds as HH:MM:SS"""
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"

    click.secho("Waiting for package to install...", fg="cyan")

    result = [None]  # Use list to store result from thread
    exception = [None]  # Use list to store any exception

    def run_wait_for_server():
        try:
            result[0] = wait_for_server_response(
                playground=bool(playground),
                task_id=task_id,
                apikey=apikey,
                apiurl=apiurl,
                server_version_da=server_version_da,
            )
        except Exception as e:
            exception[0] = e

    # Start the installer in a separate thread
    installer_thread = threading.Thread(target=run_wait_for_server)
    installer_thread.daemon = True
    installer_thread.start()

    # Display timer while installer runs
    start_time = time.time()
    while installer_thread.is_alive():
        elapsed = int(time.time() - start_time)
        click.echo(f"""\rElapsed: {format_time(elapsed)}""", nl=False)
        time.sleep(1)

    # Wait for thread to complete
    installer_thread.join()

    click.echo()

    # Re-raise any exception that occurred
    if exception[0]:
        raise exception[0]

    return result[0]


# -----------------------------------------------------------------------------
# package_installer
# -----------------------------------------------------------------------------


def package_installer(directory, apiurl, apikey, playground, restart, dry_run=False, show_files=False):
    archive = tempfile.NamedTemporaryFile(suffix=".zip")
    zf = zipfile.ZipFile(archive, compression=zipfile.ZIP_DEFLATED, mode="w")
    archived_files = []
    try:
        ignore_process = subprocess.run(
            ["git", "ls-files", "-i", "--directory", "-o", "--exclude-standard"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            universal_newlines=True,
            cwd=directory,
            check=False,
        )
        ignore_process.check_returncode()
        raw_ignore = ignore_process.stdout.splitlines()
    except Exception:
        raw_ignore = []
    to_ignore = [path.rstrip("/") for path in raw_ignore]
    root_directory = None
    has_python_files = False
    this_package_name = None
    dependencies = {}
    for root, dirs, files in os.walk(directory, topdown=True):
        adjusted_root = os.path.relpath(root, directory)
        dirs[:] = [
            d
            for d in dirs
            if d not in EXCLUDED_DIRECTORIES
            and not d.endswith(".egg-info")
            and os.path.normpath(os.path.join(adjusted_root, d)) not in to_ignore
        ]
        if root_directory is None and package_metadata_files_present(root):
            root_directory = root
            this_package_name, dependencies = load_package_metadata(root, files)
        for the_file in files:
            if (
                the_file.endswith("~")
                or the_file.endswith(".pyc")
                or the_file.endswith(".swp")
                or the_file.startswith("#")
                or the_file.startswith(".#")
                or the_file.endswith(".tmp")
                or ".tmp." in the_file
                or the_file.endswith(".swx")
                or (the_file == ".gitignore" and root_directory == root)
                or os.path.normpath(os.path.join(adjusted_root, the_file)) in to_ignore
            ):
                continue
            if (
                not has_python_files
                and the_file.endswith(".py")
                and not (the_file in ("setup.py", "setup.cfg", "pyproject.toml") and root == root_directory)
                and the_file != "__init__.py"
            ):
                has_python_files = True
            archived_files.append(os.path.relpath(os.path.join(root, the_file), directory))
            zf.write(
                os.path.join(root, the_file),
                os.path.relpath(os.path.join(root, the_file), os.path.join(directory, "..")),
            )
    zf.close()
    archive.seek(0)
    archived_files.sort()
    if restart == "no":
        should_restart = False
    elif restart == "yes" or has_python_files:
        should_restart = True
    elif len(dependencies) > 0 or this_package_name:
        try:
            r = http_get(apiurl + "/api/package", headers={"X-API-Key": apikey}, timeout=600)
        except Exception as err:
            click.secho(f"""\n{err.__class__.__name__}""", fg="red")
            raise click.ClickException(f"""{err}\n""")
        if r.status_code != 200:
            return "/api/package returned " + str(r.status_code) + ": " + r.text
        installed_packages = r.json()
        already_installed = False
        for package_info in installed_packages:
            package_info["alt_name"] = re.sub(r"^docassemble\.", "docassemble-", package_info["name"])
            for dependency_name, dependency_info in dependencies.items():
                if dependency_name in (package_info["name"], package_info["alt_name"]):
                    condition = True
                    if dependency_info["operator"]:
                        if dependency_info["operator"] == "==":
                            condition = packaging_version.parse(package_info["version"]) == packaging_version.parse(
                                dependency_info["version"]
                            )
                        elif dependency_info["operator"] == "<=":
                            condition = packaging_version.parse(package_info["version"]) <= packaging_version.parse(
                                dependency_info["version"]
                            )
                        elif dependency_info["operator"] == ">=":
                            condition = packaging_version.parse(package_info["version"]) >= packaging_version.parse(
                                dependency_info["version"]
                            )
                        elif dependency_info["operator"] == "<":
                            condition = packaging_version.parse(package_info["version"]) < packaging_version.parse(
                                dependency_info["version"]
                            )
                        elif dependency_info["operator"] == ">":  # pragma: no branch
                            condition = packaging_version.parse(package_info["version"]) > packaging_version.parse(
                                dependency_info["version"]
                            )
                    if condition:  # pragma: no branch
                        dependency_info["installed"] = True
            if this_package_name and this_package_name in (package_info["name"], package_info["alt_name"]):
                already_installed = True
        should_restart = bool(
            (not already_installed and len(dependencies) > 0)
            or not all(item["installed"] for item in dependencies.values())
        )
    else:
        should_restart = True
    data = {}
    if should_restart:
        if not dry_run:
            try:
                server_packages = http_get(apiurl + "/api/package", headers={"X-API-Key": apikey}, timeout=600)
                if server_packages.status_code != 200:
                    if server_packages.status_code == 403:
                        click.secho("""\nThe API KEY is invalid.""", fg="red")
                    server_packages.raise_for_status()
                else:
                    installed_packages = server_packages.json()
                    for package in installed_packages:
                        if package.get("name", "") == "docassemble.base":
                            server_version_da = package.get("version", "0")
            except Exception as err:
                click.secho(f"""\n{err.__class__.__name__}""", fg="red")
                raise click.ClickException(f"""{err}\n""")
            click.secho("Server will restart.", fg="yellow")
    if not should_restart:
        server_version_da = "norestart"
        data["restart"] = "0"
    if DEBUG and not dry_run:
        click.echo(f"""Server version: {server_version_da}.""")
    if dry_run:
        show_dry_run_package_install(
            playground=playground,
            should_restart=should_restart,
            archived_files=archived_files,
            show_files=show_files,
        )
        return 0
    if playground:
        if playground != "default":
            data["project"] = playground
        project_endpoint = apiurl + "/api/playground/project"
        click.secho("Checking Playground project...", fg="cyan")
        project_list = http_get(project_endpoint, headers={"X-API-Key": apikey}, timeout=600)
        if project_list.status_code == 200:
            try:
                existing_projects = project_list.json()
            except Exception:
                return "playground list of projects GET returned invalid JSON: " + project_list.text
            if not playground_project_exists(existing_projects, playground):
                try:
                    click.secho(f'''Creating Playground project "{playground}"...''', fg="cyan")
                    http_post(
                        project_endpoint,
                        data={"project": playground},
                        headers={"X-API-Key": apikey},
                        timeout=600,
                    )
                except Exception:
                    return "create project POST returned " + project_list.text
        else:
            click.echo("\n")
            return (
                "playground list of projects GET returned " + str(project_list.status_code) + ": " + project_list.text
            )
        try:
            click.secho("Uploading package to Playground...", fg="cyan")
            r = http_post(
                apiurl + "/api/playground_install",
                data=data,
                files={"file": archive},
                headers={"X-API-Key": apikey},
                timeout=600,
            )
        except Exception as err:
            click.secho(f"""\n{err.__class__.__name__}""", fg="red")
            raise click.ClickException(f"""{err}\n""")
        if r.status_code == 400:
            try:
                error_message = r.json()
            except Exception:
                error_message = ""
            if "project" not in data or error_message != "Invalid project.":
                return "playground_install POST returned " + str(r.status_code) + ": " + r.text
            try:
                r = http_post(
                    apiurl + "/api/playground/project",
                    data={"project": data["project"]},
                    headers={"X-API-Key": apikey},
                    timeout=600,
                )
            except Exception as err:
                click.secho(f"""\n{err.__class__.__name__}""", fg="red")
                raise click.ClickException(f"""{err}\n""")
            if r.status_code != 204:
                return (
                    "needed to create playground project but POST to api/playground/project returned "
                    + str(r.status_code)
                    + ": "
                    + r.text
                )
            archive.seek(0)
            try:
                r = http_post(
                    apiurl + "/api/playground_install",
                    data=data,
                    files={"file": archive},
                    headers={"X-API-Key": apikey},
                    timeout=600,
                )
            except Exception as err:
                click.secho(f"""\n{err.__class__.__name__}""", fg="red")
                raise click.ClickException(f"""{err}\n""")
        if r.status_code == 200:
            try:
                info = r.json()
            except Exception:
                return r.text
            task_id = info["task_id"]
            success = wait_for_server(
                playground=bool(playground),
                task_id=task_id,
                apikey=apikey,
                apiurl=apiurl,
                server_version_da=server_version_da,
            )
        elif r.status_code == 204:
            success = True
        else:
            click.echo("\n")
            return "playground_install POST returned " + str(r.status_code) + ": " + r.text
        if success:
            announce_installed()
        else:
            click.secho(
                f"""\n[{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] Install failed!\n{BELL}""", fg="red"
            )
            return 1
    else:
        try:
            r = http_post(
                apiurl + "/api/package", data=data, files={"zip": archive}, headers={"X-API-Key": apikey}, timeout=600
            )
        except Exception as err:
            click.secho(f"""\n{err.__class__.__name__}""", fg="red")
            raise click.ClickException(f"""{err}\n""")
        if r.status_code != 200:
            return "package POST returned " + str(r.status_code) + ": " + r.text
        info = r.json()
        task_id = info["task_id"]
        if wait_for_server(
            playground=bool(playground),
            task_id=task_id,
            apikey=apikey,
            apiurl=apiurl,
            server_version_da=server_version_da,
        ):
            announce_installed()
        if not should_restart:
            try:
                r = http_post(apiurl + "/api/clear_cache", headers={"X-API-Key": apikey}, timeout=600)
            except Exception as err:
                click.secho(f"""\n{err.__class__.__name__}{BELL}""", fg="red")
                raise click.ClickException(f"""{err}\n""")
            if r.status_code != 204:
                return "clear_cache returned " + str(r.status_code) + ": " + r.text
    return 0


# =============================================================================
# install
# =============================================================================


@cli.command(context_settings=CONTEXT_SETTINGS)
@common_params_for_api
@common_params_for_installation
@click.option(
    "--restart",
    "-r",
    type=click.Choice(["yes", "no", "auto"]),
    default="auto",
    show_default=True,
    help="On package install: yes, force a restart | no, do not restart | auto, only restart if the package has any .py files or if there are dependencies to be installed",
)
@click.option("--dry-run", is_flag=True, help="Show what would be installed without uploading anything.")
@click.option("--show-files", is_flag=True, help="With --dry-run, list the files that would be uploaded.")
def install(directory, config, project_config, api, server, playground, restart, dry_run, show_files):
    """
    Install a docassemble package on a docassemble server.

    `install` tries to get API info from the --api option first (if used), then from the first server listed in the ~/.docassemblecli file if it exists (unless the --config option is used), then it tries to use environmental variables, and finally it prompts the user directly.
    """
    selected_server = resolve_command_server_with_cleanup("install", directory, config, api, server, project_config)
    if project_config and not playground and "playground" in selected_server:
        playground = selected_server["playground"]
    click.echo(f"""Server: {selected_server["name"]}""")
    if not playground:
        click.echo("Location: Package")
    else:
        click.echo(f"""Location: Playground "{playground}" """)
    if dry_run:
        click.secho(
            f"""[{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] Dry run: previewing install...""", fg="cyan"
        )
    else:
        click.secho(f"""[{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] Installing...""", fg="yellow")
    return package_installer(
        directory=directory,
        apiurl=selected_server["apiurl"],
        apikey=selected_server["apikey"],
        playground=playground,
        restart=restart,
        dry_run=dry_run,
        show_files=show_files,
    )


@cli.command(context_settings=CONTEXT_SETTINGS)
@common_params_for_api
@common_params_for_runtime_config
@click.option(
    "--playground",
    "-p",
    metavar="(PROJECT)",
    is_flag=False,
    flag_value="default",
    help="Download from the default Playground or from the specified Playground project.",
)
@click.option("--overwrite/--no-overwrite", default=False, show_default=True, help="Overwrite existing files.")
@click.argument("package")
def download(config, api, server, playground, overwrite, package):
    """
    Download a docassemble package from a docassemble server or Playground.
    """
    selected_server = select_server(*config, *api, server)
    package_name = normalize_package_name(package)
    package_file_name = re.sub(r"docassemble\.", "docassemble-", package_name)
    archive = tempfile.NamedTemporaryFile(suffix=".zip")

    try:
        if playground:
            params = {"folder": "packages", "filename": package_name}
            if playground != "default":
                params["project"] = playground
            response = requests.get(
                selected_server["apiurl"] + "/api/playground",
                params=params,
                stream=True,
                timeout=600,
                headers={"X-API-Key": selected_server["apikey"]},
            )
            if response.status_code == 404:
                return "Package not found."
            response.raise_for_status()
        else:
            response = requests.get(
                selected_server["apiurl"] + "/api/package",
                headers={"X-API-Key": selected_server["apikey"]},
                timeout=600,
            )
            if response.status_code != 200:
                return "Unable to connect to server."
            zip_file_number = None
            for item in response.json():
                if item["name"] == package_name:
                    zip_file_number = item.get("zip_file_number")
                    break
            if zip_file_number is None:
                return "Package installed but is not downloadable."
            response = requests.get(
                selected_server["apiurl"] + "/api/file/" + str(zip_file_number),
                stream=True,
                timeout=600,
                headers={"X-API-Key": selected_server["apikey"]},
            )
            response.raise_for_status()
    except requests.exceptions.HTTPError as err:
        return "Error downloading package: " + str(err)
    except Exception as err:
        click.secho(f"""\n{err.__class__.__name__}""", fg="red")
        raise click.ClickException(f"""{err}\n""")

    with open(archive.name, "wb") as fp:
        for chunk in response.iter_content(8192):
            fp.write(chunk)

    with zipfile.ZipFile(archive.name, mode="r") as zf:
        if not overwrite:
            for file_info in zf.infolist():
                if os.path.exists(file_info.filename):
                    return (
                        "Unpacking the package here would overwrite existing files "
                        + f"({file_info.filename}). Use --overwrite if you want to overwrite existing files."
                    )
        zf.extractall(path=os.getcwd())
    click.echo(f"Unpacked {package_file_name}.")
    return 0


@cli.command(context_settings=CONTEXT_SETTINGS)
@common_params_for_api
@common_params_for_runtime_config
@click.option(
    "--restart/--no-restart",
    default=True,
    show_default=True,
    help="Restart the docassemble server after uninstalling the package.",
)
@click.argument("package")
def uninstall(config, api, server, restart, package):
    """
    Uninstall a docassemble package from a docassemble server.
    """
    selected_server = select_server(*config, *api, server)
    package_name = normalize_package_name(package)
    data = {"package": package_name}
    if not restart:
        data["restart"] = "0"

    try:
        response = requests.delete(
            selected_server["apiurl"] + "/api/package",
            params=data,
            headers={"X-API-Key": selected_server["apikey"]},
            timeout=600,
        )
    except Exception as err:
        click.secho(f"""\n{err.__class__.__name__}""", fg="red")
        raise click.ClickException(f"""{err}\n""")
    if response.status_code != 200:
        return "package DELETE returned " + str(response.status_code) + ": " + response.text

    info = response.json()
    if wait_for_server(False, info["task_id"], selected_server["apikey"], selected_server["apiurl"]):
        click.secho(f"""[{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] Uninstalled.{BELL}""", fg="green")
        return 0
    return 1


# -----------------------------------------------------------------------------
# watchdog & hashlib
# -----------------------------------------------------------------------------


def calculate_checksum(filepath: str) -> str:
    hash_md5 = hashlib.md5()
    try:
        with open(filepath, "rb") as f:
            while chunk := f.read(4096):
                hash_md5.update(chunk)
    except FileNotFoundError:
        return ""
    except Exception as e:
        click.secho(f"""{e} while calculating checksum.""", fg="red")
        return ""
    return hash_md5.hexdigest()


def scan_directory(directory):
    if DEBUG:
        click.secho("Scanning files...", fg="cyan")
    global FILE_CHECKSUMS
    for current_directory, subdirectories, files in os.walk(directory):
        excluded_directories = EXCLUDED_DIRECTORIES
        subdirectories[:] = [d for d in subdirectories if d not in excluded_directories]
        for file in files:
            filepath = os.path.join(current_directory, file)
            if not matches_ignore_patterns(path=filepath, directory=directory):
                FILE_CHECKSUMS[filepath] = calculate_checksum(filepath)
    if DEBUG:
        click.secho("Scanning complete.", fg="green")


def read_ignore_file(path: str) -> list[str]:
    with open(path, encoding="utf-8") as file:
        return [line.rstrip("\r\n") for line in file]


def load_ignore_patterns(directory: str) -> list[str]:
    gitignore_path = os.path.join(directory, ".gitignore")
    if os.path.exists(gitignore_path):
        ignore_patterns = read_ignore_file(gitignore_path)
    else:
        ignore_patterns = GITIGNORE.split("\n")

    watch_ignore_path = os.path.join(directory, WATCH_IGNORE_FILE)
    if os.path.exists(watch_ignore_path):
        ignore_patterns.extend(read_ignore_file(watch_ignore_path))

    ignore_patterns.extend([".git/", ".gitignore", WATCH_IGNORE_FILE])
    return ignore_patterns


def matches_ignore_patterns(path: str, directory: str) -> bool:
    global WATCH_IGNORE_MTIME, GITIGNORE_MTIME, GITMATCH_COMPILED, GITMATCH_DIRECTORY
    gitignore_path = os.path.join(directory, ".gitignore")
    gitignore_mtime = os.path.getmtime(gitignore_path) if os.path.exists(gitignore_path) else None
    watch_ignore_path = os.path.join(directory, WATCH_IGNORE_FILE)
    watch_ignore_mtime = os.path.getmtime(watch_ignore_path) if os.path.exists(watch_ignore_path) else None
    if (
        not GITMATCH_COMPILED
        or GITMATCH_DIRECTORY != directory
        or GITIGNORE_MTIME != gitignore_mtime
        or WATCH_IGNORE_MTIME != watch_ignore_mtime
    ):
        if DEBUG:
            click.echo("GITMATCH_COMPILED")
        GITMATCH_COMPILED = gitmatch.compile(load_ignore_patterns(directory))
        GITMATCH_DIRECTORY = directory
        GITIGNORE_MTIME = gitignore_mtime
        WATCH_IGNORE_MTIME = watch_ignore_mtime
    # Convert the absolute path to a relative path for gitmatch to work
    path = os.path.relpath(path, directory)
    return GITMATCH_COMPILED.match(path=path)


class WatchHandler(FileSystemEventHandler):
    def __init__(self, *args, **kwargs):
        self.directory = kwargs.pop("directory")
        super(WatchHandler, self).__init__(*args, **kwargs)

    def on_any_event(self, event):
        global LAST_MODIFIED, FILE_CHECKSUMS
        event_type = getattr(event, "event_type", None)
        if event_type in ("opened", "closed") or (event.is_directory and event_type == "modified"):
            return None
        if event.is_directory:
            return None
        event_path = os.path.abspath(event.src_path)
        if matches_ignore_patterns(path=event_path.replace("\\", "/"), directory=self.directory):
            return None
        if event_type in ("created", "modified"):
            new_checksum = calculate_checksum(event_path)
            if not new_checksum or FILE_CHECKSUMS.get(event_path) == new_checksum:
                return None
            FILE_CHECKSUMS[event_path] = new_checksum
        elif event_type == "deleted":
            FILE_CHECKSUMS.pop(event_path, None)
        else:
            return None

        event_bucket = LAST_MODIFIED["files"].setdefault(event_path, {})
        if event_type == "deleted":
            LAST_MODIFIED["files"][event_path] = {"deleted": True}
        else:
            if "deleted" in event_bucket:
                event_bucket = {}
            event_bucket[event_type] = True
            LAST_MODIFIED["files"][event_path] = event_bucket
        LAST_MODIFIED["time"] = time.time()
        if event_path.endswith(".py"):
            LAST_MODIFIED["restart"] = True


# =============================================================================
# watch
# =============================================================================


@cli.command(context_settings=CONTEXT_SETTINGS)
@common_params_for_installation
@common_params_for_api
@click.option(
    "--restart",
    "-r",
    type=click.Choice(["yes", "no", "auto"]),
    default="auto",
    show_default=True,
    help="On package install: yes, force a restart | no, do not restart | auto, only restart if any .py files were changed",
)
@click.option(
    "--buffer",
    "-b",
    metavar="SECONDS",
    default=3,
    show_default=True,
    help="(On server restart only) Set the buffer (wait time) between a file change event and package installation. If you are experiencing multiple installs back-to-back, try increasing this value.",
)
@click.option("--dry-run", is_flag=True, help="Show what watch would install without uploading anything.")
@click.option("--show-files", is_flag=True, help="With --dry-run, list the files that would be uploaded.")
def watch(directory, config, project_config, api, server, playground, restart, buffer, dry_run, show_files):
    """
    Watch a package directory and `install` any changes. Press Ctrl + c to exit.

    If the --directory option is not specified, `watch` will look for a directory entry in the config file. The corresponding server entry will be selected automatically if the "directory" key in the config file matches the directory being watched. If a match is found, the "playground" key in the config file will be used if it exists and if no --playground option was specified.
    """
    selected_server = resolve_command_server_with_cleanup("watch", directory, config, api, server, project_config)
    restart_param = restart
    scan_directory(directory)
    global FULL_INSTALL_DONE, LAST_MODIFIED
    event_handler = WatchHandler(directory=directory)
    observer = Observer()
    observer.schedule(event_handler, directory, recursive=True)
    observer.start()
    click.echo()
    click.echo(f"""Server: {selected_server["name"]}""")

    if not playground:
        if project_config and "playground" in selected_server:
            playground = selected_server["playground"]
        elif (
            "directory" in selected_server
            and selected_server["directory"] == directory
            and "playground" in selected_server
        ):
            playground = selected_server["playground"]
        else:
            click.echo("Location: Package")
    if playground:
        click.echo(f"""Location: Playground "{playground}" """)

    if "startup" in selected_server and selected_server["startup"] == "install":
        if dry_run:
            click.secho("""Previewing startup install.""", fg="cyan")
        else:
            click.secho("""Installing on startup.""", fg="cyan")
        startup_result = package_installer(
            directory=directory,
            apiurl=selected_server["apiurl"],
            apikey=selected_server["apikey"],
            playground=playground,
            restart=restart,
            dry_run=dry_run,
            show_files=show_files,
        )
        FULL_INSTALL_DONE = startup_result == 0
        click.echo("")

    click.echo(f"""Watching: {directory}""")
    click.secho(f"""[{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] Started""", fg="green")
    stop_message = """\nStopping "docassemblecli3 watch"."""
    try:
        while True:
            if LAST_MODIFIED["time"] and time.time() - LAST_MODIFIED["time"] >= WATCH_SETTLE_DELAY:
                changed_files = deduplicate_watch_events(LAST_MODIFIED["files"])
                if not changed_files:
                    LAST_MODIFIED = {"time": 0, "files": {}, "restart": False}
                    time.sleep(0.2)
                    continue
                if dry_run:
                    click.secho(
                        f"""[{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] Dry run: previewing install...""",
                        fg="cyan",
                    )
                else:
                    click.secho(
                        f"""[{datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] Installing...""", fg="yellow"
                    )
                if restart_param == "yes" or (restart_param == "auto" and LAST_MODIFIED["restart"]):
                    effective_restart = "yes"
                    time.sleep(buffer)
                else:
                    effective_restart = "no"
                for item in changed_files.keys():
                    click.echo("  " + item.replace(directory, ""))
                LAST_MODIFIED = {"time": 0, "files": {}, "restart": False}

                install_result = None
                if playground and FULL_INSTALL_DONE:
                    uploaded = upload_playground_files(
                        apiurl=selected_server["apiurl"],
                        apikey=selected_server["apikey"],
                        playground=playground,
                        changed_files=changed_files,
                        dry_run=dry_run,
                        show_files=show_files,
                    )
                    if uploaded:
                        if dry_run:
                            click.secho("Dry run: incremental Playground upload preview complete.", fg="cyan")
                        else:
                            announce_installed()
                        install_result = 0

                if install_result is None:
                    install_result = package_installer(
                        directory=directory,
                        apiurl=selected_server["apiurl"],
                        apikey=selected_server["apikey"],
                        playground=playground,
                        restart=effective_restart,
                        dry_run=dry_run,
                        show_files=show_files,
                    )
                FULL_INSTALL_DONE = install_result == 0
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        click.echo(f"\nException occurred: {e}")
    finally:
        observer.stop()
        observer.join()
        FULL_INSTALL_DONE = False
    return stop_message


# =============================================================================
# create
# =============================================================================


@cli.command(context_settings=CONTEXT_SETTINGS)
@click.option("--package", metavar="PACKAGE", help="Name of the package you want to create")
@click.option("--developer-name", metavar="NAME", help="Name of the developer of the package")
@click.option("--developer-email", metavar="EMAIL", help="Email of the developer of the package")
@click.option("--description", metavar="DESCRIPTION", help="Description of package")
@click.option("--url", metavar="URL", help="URL of package")
@click.option("--license", metavar="LICENSE", help="License of package")
@click.option("--version", metavar="VERSION", help="Version number of package")
@click.option("--output", metavar="OUTPUT", help="Output directory in which to create the package")
def create(package, developer_name, developer_email, description, url, license, version, output):
    """
    Create an empty docassemble add-on package.
    """
    pkgname = package
    if not pkgname:
        pkgname = click.prompt("Name of the package you want to create (e.g., childsupport)")
    pkgname = re.sub(r"\s", "", pkgname)
    if not pkgname:
        return "The package name you entered is invalid."
    pkgname = re.sub(r"^docassemble[\-\.]", "", pkgname, flags=re.IGNORECASE)
    if output:
        packagedir = output
    else:
        packagedir = "docassemble-" + pkgname
    if os.path.exists(packagedir):
        if not os.path.isdir(packagedir):
            return "Cannot create the directory " + packagedir + " because the path already exists."
        dir_listing = list(os.listdir(packagedir))
        if "setup.py" in dir_listing or "setup.cfg" in dir_listing or "pyproject.toml" in dir_listing:
            return "The directory " + packagedir + " already has a package in it."
    else:
        os.makedirs(packagedir, exist_ok=True)
    if not developer_name:
        developer_name = click.prompt("Name of developer").strip()
        if not developer_name:
            developer_name = "Your Name Here"
    if not developer_email:
        developer_email = click.prompt("Email address of developer (e.g., developer@example.com)").strip()
        if not developer_email:
            developer_email = "developer@example.com"
    if not description:
        description = click.prompt("Description of package (e.g., A docassemble extension)").strip()
        if not description:
            description = "A docassemble extension."
    package_url = url
    if not package_url:
        package_url = click.prompt("URL of package (e.g., https://docassemble.org)").strip()
        if not package_url:
            package_url = "https://docassemble.org"
    if not license:
        license = click.prompt("License of package").strip()
    license = normalize_license_string(license)
    if not version:
        version = click.prompt("Version of package", default="0.0.1", show_default=True).strip()
    initpy = """\
__import__("pkg_resources").declare_namespace(__name__)

"""
    if "MIT" in license:
        licensetext = (
            "The MIT License (MIT)\n\nCopyright (c) "
            + str(datetime.datetime.now().year)
            + " "
            + developer_name
            + """

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""
        )
    else:
        licensetext = license + "\n"

    readme = (
        "# docassemble."
        + pkgname
        + "\n\n"
        + description
        + "\n\n## Author\n\n"
        + developer_name
        + ", "
        + developer_email
        + "\n"
    )
    manifestin = (
        """\
include README.md
graft docassemble/"""
        + pkgname
        + """/data
recursive-exclude * *.egg-info
recursive-exclude .git *
recursive-exclude venv *
recursive-exclude .github *
recursive-exclude .pytest_cache *
recursive-exclude .vscode *
recursive-exclude build *
recursive-exclude dist *
recursive-exclude * __pycache__
recursive-exclude * *.pyc
recursive-exclude * *.pyo
recursive-exclude * *.orig
recursive-exclude * *~
recursive-exclude * *.bak
recursive-exclude * *.swp
"""
    )
    setupcfg = """\
[metadata]
description_file = README.md
"""
    pyproject = f"""[build-system]
requires = ["setuptools==80.9.0"]
build-backend = "setuptools.build_meta"

[project]
name = "docassemble.{pkgname}"
version = "{version}"
description = {repr(description)}
readme = "README.md"
requires-python = ">=3.12"
authors = [
    {{ name = {repr(developer_name)}, email = {repr(developer_email)} }},
]
dependencies = []

[project.urls]
Homepage = {repr(package_url)}

[tool.setuptools.packages.find]
where = ["."]
"""
    if license:
        pyproject += f'\nlicense = {repr(license)}\nlicense-files = ["LICENSE"]\n'
    setuppy = """\
import os
import sys
from setuptools import setup, find_packages
from fnmatch import fnmatchcase
from distutils.util import convert_path

standard_exclude = ("*.pyc", "*~", ".*", "*.bak", "*.swp*")
standard_exclude_directories = (".*", "CVS", "_darcs", "./build", "./dist", "EGG-INFO", "*.egg-info")

def find_package_data(where=".", package="", exclude=standard_exclude, exclude_directories=standard_exclude_directories):
    out = {}
    stack = [(convert_path(where), "", package)]
    while stack:
        where, prefix, package = stack.pop(0)
        for name in os.listdir(where):
            fn = os.path.join(where, name)
            if os.path.isdir(fn):
                bad_name = False
                for pattern in exclude_directories:
                    if (fnmatchcase(name, pattern)
                        or fn.lower() == pattern.lower()):
                        bad_name = True
                        break
                if bad_name:
                    continue
                if os.path.isfile(os.path.join(fn, "__init__.py")):
                    if not package:
                        new_package = name
                    else:
                        new_package = package + "." + name
                        stack.append((fn, "", new_package))
                else:
                    stack.append((fn, prefix + name + "/", package))
            else:
                bad_name = False
                for pattern in exclude:
                    if (fnmatchcase(name, pattern)
                        or fn.lower() == pattern.lower()):
                        bad_name = True
                        break
                if bad_name:
                    continue
                out.setdefault(package, []).append(prefix+name)
    return out

"""
    setuppy += (
        "setup(name="
        + repr("docassemble." + pkgname)
        + """,
      version="""
        + repr(version)
        + """,
      description=("""
        + repr(description)
        + """),
      long_description="""
        + repr(readme)
        + """,
      long_description_content_type="text/markdown",
      author="""
        + repr(developer_name)
        + """,
      author_email="""
        + repr(developer_email)
        + """,
      license="""
        + repr(license)
        + """,
      url="""
        + repr(package_url)
        + """,
      packages=find_packages(),
      namespace_packages=["docassemble"],
      install_requires=[],
      zip_safe=False,
      package_data=find_package_data(where='docassemble/"""
        + pkgname
        + """/', package='docassemble."""
        + pkgname
        + """'),
     )
"""
    )
    # maindir = os.path.join(packagedir, "docassemble", pkgname)
    questionsdir = os.path.join(packagedir, "docassemble", pkgname, "data", "questions")
    templatesdir = os.path.join(packagedir, "docassemble", pkgname, "data", "templates")
    staticdir = os.path.join(packagedir, "docassemble", pkgname, "data", "static")
    sourcesdir = os.path.join(packagedir, "docassemble", pkgname, "data", "sources")
    if not os.path.isdir(questionsdir):
        os.makedirs(questionsdir, exist_ok=True)
    if not os.path.isdir(templatesdir):
        os.makedirs(templatesdir, exist_ok=True)
    if not os.path.isdir(staticdir):
        os.makedirs(staticdir, exist_ok=True)
    if not os.path.isdir(sourcesdir):
        os.makedirs(sourcesdir, exist_ok=True)
    with open(os.path.join(packagedir, ".gitignore"), "w", encoding="utf-8") as the_file:
        the_file.write(GITIGNORE)
    with open(os.path.join(packagedir, "README.md"), "w", encoding="utf-8") as the_file:
        the_file.write(readme)
    with open(os.path.join(packagedir, "LICENSE"), "w", encoding="utf-8") as the_file:
        the_file.write(licensetext)
    with open(os.path.join(packagedir, "setup.py"), "w", encoding="utf-8") as the_file:
        the_file.write(setuppy)
    with open(os.path.join(packagedir, "setup.cfg"), "w", encoding="utf-8") as the_file:
        the_file.write(setupcfg)
    with open(os.path.join(packagedir, "MANIFEST.in"), "w", encoding="utf-8") as the_file:
        the_file.write(manifestin)
    with open(os.path.join(packagedir, "pyproject.toml"), "w", encoding="utf-8") as the_file:
        the_file.write(pyproject)
    with open(os.path.join(packagedir, "docassemble", "__init__.py"), "w", encoding="utf-8") as the_file:
        the_file.write(initpy)
    with open(os.path.join(packagedir, "docassemble", pkgname, "__init__.py"), "w", encoding="utf-8") as the_file:
        the_file.write("__version__ = " + repr(version) + "\n")
    return 0


# =============================================================================
# config
# =============================================================================


@config.command(context_settings=CONTEXT_SETTINGS)
@click.option(
    "--api",
    "-a",
    type=(APIURLType(), str),
    default=(None, None),
    help="URL of the docassemble server and API key of the user (admin or developer)",
)
@click.option("--config", "config_path", "-c", type=click.Path(), help="Specify the global config file to use")
@click.option(
    "--project-config", "use_project_config", is_flag=True, help="Add to the package-local .docassemblecli file"
)
@click.option("--global-config", "use_global_config", is_flag=True, help="Add to the global config file")
@click.option("--directory", "-d", type=click.Path(), help="Associate the server with this package directory")
@click.option(
    "--playground",
    "-p",
    metavar="(PROJECT)",
    is_flag=False,
    flag_value="default",
    help="Set the default Playground or specify the default Playground project.",
)
@click.option(
    "--install-default/--no-install-default",
    default=None,
    help="In the local project config, set this server as the default for install.",
)
@click.option(
    "--install-playground",
    metavar="(PROJECT)",
    is_flag=False,
    flag_value="default",
    default=None,
    help="In the local project config, set the default Playground for install.",
)
@click.option(
    "--watch-default/--no-watch-default",
    default=None,
    help="In the local project config, set this server as the default for watch.",
)
@click.option(
    "--watch-playground",
    metavar="(PROJECT)",
    is_flag=False,
    flag_value="default",
    default=None,
    help="In the local project config, set the default Playground for watch.",
)
@click.option(
    "--watch-startup",
    type=click.Choice(["install", "none"], case_sensitive=False),
    default=None,
    help="In the local project config, control whether watch installs once on startup.",
)
def add(
    config_path,
    api,
    use_project_config,
    use_global_config,
    directory,
    playground,
    install_default,
    install_playground,
    watch_default,
    watch_playground,
    watch_startup,
):
    """
    Add a server to the config file.
    """
    apiurl, apikey = api
    local_command_options_used = any(
        value is not None
        for value in (install_default, install_playground, watch_default, watch_playground, watch_startup)
    )
    if local_command_options_used and not (use_project_config or use_global_config or config_path):
        use_project_config = True
    target_scope, cfg, env, sections = resolve_config_target(
        config_path=config_path,
        use_project_config=use_project_config,
        use_global_config=use_global_config,
        directory=directory,
    )
    if install_default is False and install_playground is not None:
        raise click.BadParameter(
            "Cannot be combined with --no-install-default.",
            param_hint="--install-playground",
        )
    if watch_default is False and (watch_playground is not None or watch_startup is not None):
        raise click.BadParameter(
            "Cannot be combined with --no-watch-default.",
            param_hint="--watch-playground",
        )
    if target_scope != "local" and local_command_options_used:
        raise click.BadParameter(
            "Install/watch defaults can only be set in the package-local project config.",
            param_hint="--project-config",
        )

    if target_scope == "local":
        stored_directory = validate_package_directory(None, None, directory) if directory is not None else None
    else:
        stored_directory = (
            validate_package_directory(None, None, directory)
            if directory is not None
            else prompt_for_optional_directory()
        )

    if playground is None:
        playground = prompt_for_optional_playground()

    if target_scope == "local":
        configure_install = install_default if install_default is not None else bool(install_playground is not None)
        if install_default is None and install_playground is None:
            configure_install = prompt_for_command_default("install")
        if configure_install and install_playground is None:
            install_playground = prompt_for_command_playground("install")

        configure_watch = (
            watch_default
            if watch_default is not None
            else bool(watch_playground is not None or watch_startup is not None)
        )
        if watch_default is None and watch_playground is None and watch_startup is None:
            configure_watch = prompt_for_command_default("watch")
        if configure_watch and watch_playground is None:
            watch_playground = prompt_for_command_playground("watch")
        if configure_watch and watch_startup is None:
            watch_startup = prompt_for_watch_startup()
        if watch_startup == "none":
            watch_startup = None

    apiurl, apikey = ensure_api_credentials(apiurl=apiurl, apikey=apikey)
    server_name = name_from_url(apiurl)

    if target_scope == "local":
        env = add_server_to_env(
            cfg=None,
            env=env,
            apiurl=apiurl,
            apikey=apikey,
            directory=stored_directory,
            playground=playground,
            validate_api=False,
        )
        sections = apply_project_command_defaults(
            sections=sections or {"install": {}, "watch": {}},
            server_name=server_name,
            configure_install=configure_install,
            install_playground=install_playground,
            configure_watch=configure_watch,
            watch_playground=watch_playground,
            watch_startup=watch_startup,
        )
        if save_project_config(cfg, env, sections):
            click.echo(f"Configuration saved: {cfg}")
    else:
        add_server_to_env(
            cfg=cfg,
            env=env,
            apiurl=apiurl,
            apikey=apikey,
            directory=stored_directory,
            playground=playground,
            validate_api=False,
        )


@config.command(context_settings=CONTEXT_SETTINGS)
@click.option("--config", "config_path", "-c", type=click.Path(), help="Specify the global config file to use")
@click.option("--project-config", "use_project_config", is_flag=True, help="Use the package-local .docassemblecli file")
@click.option("--global-config", "use_global_config", is_flag=True, help="Use the global config file")
@click.option("--directory", "-d", type=click.Path(), help="Package directory that contains the local project config")
@click.option("--server", "-s", metavar="SERVER", help="Specify a server to remove from the config file")
def remove(config_path, use_project_config, use_global_config, directory, server):
    """
    Remove a server from the config file.
    """
    target_scope, cfg, env, sections = resolve_config_target(
        config_path=config_path,
        use_project_config=use_project_config,
        use_global_config=use_global_config,
        directory=directory,
    )
    if not server:
        click.echo(f"""Servers in {cfg}:""")
        for item in display_servers(env=env):
            click.echo("  " + item)
        server = click.prompt("Remove which server?")
    selected_server = select_server(cfg=cfg, env=env, server=server)
    env.remove(selected_server)
    if target_scope == "local":
        save_project_config(cfg, env, sections or {"install": {}, "watch": {}})
    else:
        save_config(cfg=cfg, env=env)
    click.echo(f"""Server "{server}" has been removed from {cfg}.""")


@config.command(name="show", context_settings=CONTEXT_SETTINGS)
@click.option("--config", "config_path", "-c", type=click.Path(), help="Specify the global config file to use")
@click.option("--project-config", "use_project_config", is_flag=True, help="Use the package-local .docassemblecli file")
@click.option("--global-config", "use_global_config", is_flag=True, help="Use the global config file")
@click.option("--directory", "-d", type=click.Path(), help="Package directory that contains the local project config")
def show(config_path, use_project_config, use_global_config, directory):
    """
    Show the servers in the config file.
    """
    _, _, env, sections = resolve_config_target(
        config_path=config_path,
        use_project_config=use_project_config,
        use_global_config=use_global_config,
        directory=directory,
    )
    for item in display_servers(env=env):
        click.echo("  " + item)
    for item in display_project_command_sections(sections):
        click.echo("  " + item)


@config.command(context_settings=CONTEXT_SETTINGS)
@click.argument("config", type=click.File(mode="w", encoding="utf-8"))
def new(config):
    """
    Create a new config file.
    """
    if os.path.exists(config.name) and os.stat(config.name).st_size != 0:
        raise click.BadParameter("File exists and is not empty!")
    env = []
    try:
        yaml.dump(env, config)
        os.chmod(config.name, stat.S_IRUSR | stat.S_IWUSR)
    except Exception:
        raise click.BadParameter("File is not usable.")
    click.echo(f"""Config created successfully: {os.path.abspath(config.name)}""")
    if click.confirm("Do you want to add a server to this new config file?", default=True):
        apiurl, apikey = prompt_for_api()
        add_server_to_env(cfg=config.name, env=env, apiurl=apiurl, apikey=apikey)


@config.command(context_settings=CONTEXT_SETTINGS, hidden=True)
@common_params_for_config
@common_params_for_api
def server_version(config, api, server):
    selected_server = select_server(*config, *api, server)
    try:
        r = requests.get(
            selected_server["apiurl"] + "/api/package", headers={"X-API-Key": selected_server["apikey"]}, timeout=600
        )
        if DEBUG:
            click.echo(type(r.status_code))
            click.echo(r.status_code)
        if r.status_code != 200:
            if r.status_code == 403:
                click.secho("""\nThe API KEY is invalid.""", fg="red")
            r.raise_for_status()
        installed_packages = r.json()
        for package in installed_packages:
            if package.get("name", "") == "docassemble.base":
                click.echo(package["version"])
    except Exception as err:
        click.secho(f"""\n{err.__class__.__name__}""", fg="red")
        raise click.ClickException(f"""{err}\n""")


@config.command(context_settings=CONTEXT_SETTINGS)
@common_params_for_config
@common_params_for_api
def test(config, api, server):
    """
    Test the URL and API key.
    """
    selected_server = select_server(*config, *api, server)
    apiurl = selected_server["apiurl"]
    apikey = selected_server["apikey"]
    click.echo(apiurl)
    test_apiurl_apikey(apiurl=apiurl, apikey=apikey)
