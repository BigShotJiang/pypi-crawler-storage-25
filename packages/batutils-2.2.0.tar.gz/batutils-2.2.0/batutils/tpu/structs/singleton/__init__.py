from ._singleton import *
