__all__ = [
    'float_eval',
    'int_eval',
    'bool_eval',
    'enum_eval',

    'enum_value_lookup_map',

    'decode_bytes',
]

from batutils.tpu.structs import *
from batutils._common import decode_bytes  # noqa

_AFFIRMATIVE = {
    'active',
    'enable',
    'enabled',
    'on',
    'true',
    'yes',
    'y',
}

_T_ENUM_CLASS = TypeVar('T_ENUM_CLASS', bound=enum.Enum)


def float_eval(value: Any, default: Union[float, None] = 0.0, raise_on_fail: bool = False) -> Union[float, None]:
    """Safe evaluation of any type to a float value. The optional default value
    will be returned on any parsing or casting error. You can also pass None as
    the default to check for failures.

    Adding the raise_on_fail parameter and setting it to True will cause the
    method to raise TypeError or ValueError exceptions if it fails to evaluate a
    float value from the value given.

    Useful shortcut where you have a string that you're know is a float value
    in string form like prefs entries, DB entries from varchar fields or HTTP
    GET/POST arguments

    :type value: any
    :type default: float or None
    :type raise_on_fail: bool
    :rtype: float or None
    """
    if isinstance(value, float):
        return value  # Duh!
    elif isinstance(value, int):
        return float(value)
    elif isinstance(value, (str, bytes)):
        try:
            return float(value)
        except (TypeError, ValueError):
            if raise_on_fail:
                raise
            return default
    elif isinstance(value, datetime.timedelta):
        return value.total_seconds()
    elif isinstance(value, datetime.date):  # datetime.datetime extends datetime date
        return time.mktime(value.timetuple())
    elif isinstance(value, datetime.time):
        return float(value.hour * 3600 + value.minute * 60 + value.second + value.microsecond * 0.000001)
    else:
        try:
            # Let's just try and pass this through the float caster...?
            return float(value)
        except (TypeError, ValueError):
            pass

        if raise_on_fail:
            raise TypeError(f'Could not evaluate unknown type [{type(value)}] to a float value')
        return default


def int_eval(value: Any, default: Union[int, None] = 0, raise_on_fail: bool = False) -> Union[int, None]:
    """Safe evaluation of any type to an int value. The optional default value
    will be returned on any parsing or casting error. You can also pass None as
    the default to check for failures.

    Long values that contain values larger than ints can contain (or strings
    containing such values) will evaluate to a long.

    Useful shortcut where you have a string that you're know is an int value
    in string form like prefs entries, DB entries from varchar fields or HTTP
    GET/POST arguments

    :type value: any
    :type default: int or None
    :type raise_on_fail: bool
    :rtype: int or long or None
    """
    if isinstance(value, int):
        return value  # Duh!

    elif isinstance(value, float):
        return int(value)

    elif isinstance(value, (str, bytes)):
        try:
            return int(value, base=0)

        except (TypeError, ValueError):
            try:
                return int(float(value))

            except (TypeError, ValueError):
                if raise_on_fail:
                    raise

                return default

    elif isinstance(value, datetime.timedelta):
        return int(value.total_seconds())

    elif isinstance(value, datetime.date):  # datetime.datetime extends datetime date
        return int(time.mktime(value.timetuple()))

    elif isinstance(value, datetime.time):
        return int(value.hour * 3600 + value.minute * 60 + value.second)

    else:
        try:
            # Let's just try and pass this through the float caster...?
            return int(value)
        except (TypeError, ValueError):
            pass

    if raise_on_fail:
        raise TypeError(f'Could not evaluate unknown type [{type(value)}] to an int value')

    return default


def bool_eval(value: Any, raise_on_fail: bool = False) -> bool:
    """Evaluates if a value should be interpreted as a boolean True value.
    That means a string that is "True" (or other explicit affirmative words)
    regardless of case and whitespace characters as well as any numerical value
    other than 0 and of course a boolean type of true.

    Anything else returns False, including all objects.

    Boolean types are return their same value.

    Strings and bytes with the following values will (case insensitive) evaluate to True:
    - active
    - enable
    - enabled
    - on
    - true
    - yes
    - y

    Strings and unicode strings that are longs, integers or floats evaluate to
    the same as their "pure" types (int, float) would evaluate to.

    Longs, Integers and Floating number evaluate to False if they are 0L, 0 and
    0.0 respectively, anything else is True.

    Any other type or object yield a False return (the opposite of what Python
    does by default, because we're looking for explicit statements of "Yes!")

    Very useful for evaluating values read from prefs.ini that can use
    different formats.

    :type value: any
    :type raise_on_fail: bool
    :rtype: bool
    """
    if isinstance(value, bool):
        return value  # Duh!

    if isinstance(value, bytes):
        try:
            value = decode_bytes(value)
        except ValueError:
            if raise_on_fail:
                raise
            return False

    if isinstance(value, str):
        value = value.strip().lower()
        if value in _AFFIRMATIVE:
            return True

        elif value.isdigit():
            return bool(int(value))

        else:
            neg = False
            if value.startswith('-'):
                value = value[1:]
                neg = True
                if value.isdigit():
                    return bool(-int(value))
            parts = value.split('.')
            if len(parts) == 2:
                if parts[0].isdigit() and parts[1].isdigit():
                    if neg:
                        return bool(-float(value))
                    else:
                        return bool(float(value))
            return False
    elif isinstance(value, (int, float)):
        return bool(value)
    else:
        return False


def enum_eval(value: Any,
              enum_class: Type[_T_ENUM_CLASS],
              default: Union[_T_ENUM_CLASS, None] = None,
              raise_on_fail: bool = False) -> _T_ENUM_CLASS:
    if isinstance(value, enum_class):
        return value

    if isinstance(value, enum.Enum):
        value = value.value

    if isinstance(value, bytes):
        try:
            value = decode_bytes(value)
        except ValueError:
            if raise_on_fail:
                raise
            return default

    if isinstance(value, str):
        # First we check the member name (normalized)
        hit = {n.lower(): m for n, m in enum_class.__members__.items()}.get(value.strip().lower(), None)
        if hit is not None:
            return hit

    try:
        value_lookup = enum_value_lookup_map(enum_class, allow_collision=False)
    except KeyError:
        if raise_on_fail:
            raise
        return default

    # This covers just about everything, except where a numeric value was given as a string
    hit = value_lookup.get(value, None)
    if hit is not None:
        return hit

    if isinstance(value, str):
        try:
            value = int(value, base=0)
        except ValueError:
            if raise_on_fail:
                raise ValueError(f'{value!r} is not a valid {enum_class.__name__}')
            return default

        # Retry after casting
        hit = value_lookup.get(value, None)
        if hit is not None:
            return hit

    if raise_on_fail:
        raise ValueError(f'{value!r} is not a valid {enum_class.__name__}')

    return default


def enum_value_lookup_map(enum_class: Type[_T_ENUM_CLASS], allow_collision: bool = False) -> Dict[Any, _T_ENUM_CLASS]:
    """Returns a dict of all the values of an enum class as keys and their respective members as values for reverse
    value lookups.

    This also breaks down the individual values in the value tuple of a multi-value enum and includes each of those as
    a lookup key as well. By default, this will raise a `KeyError` if any individual value is repeated with a different
    member as its target but this can be suppressed by setting `allow_collision=True`

    Example:
    ```python
    import enum

    class MyGoodEnum(enum.Enum):
        FOO = ('one', 'one'),  # This is fine
        BAR = ('something', 'else'),

    class MyBadEnum(enum.Enum):
        FOO = ('one', 'something'),
        BAR = ('one', 'else'),  # This will result in a collision with FOO's 'one' and raise a KeyError by default
    ```
    """
    d = {}

    def _collision_free_add(value: Any, enum_member: _T_ENUM_CLASS):
        if allow_collision:
            d[value] = enum_member
        else:
            if value in d:
                if d[value] != enum_member:
                    raise KeyError(f'value lookup map for {enum_class.__name__} resulted in a collision between {d[value]} and {enum_member} for the value {value!r}')
            else:
                d[value] = enum_member

    for _, member in enum_class.__members__.items():
        _collision_free_add(member.value, member)
        if isinstance(member.value, tuple):
            for v in member.value:
                _collision_free_add(v, member)
    return d
