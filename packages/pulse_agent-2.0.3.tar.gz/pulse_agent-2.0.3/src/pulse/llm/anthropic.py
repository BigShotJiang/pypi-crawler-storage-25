import asyncio

import anthropic


class AnthropicProvider:
    def __init__(self, api_key: str, model: str = "claude-sonnet-4-6") -> None:
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model

    async def complete(
        self, prompt: str, *, system_prompt: str | None = None, model: str | None = None
    ) -> str:
        kwargs: dict = {
            "model": model or self._model,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": prompt}],
        }
        if system_prompt:
            kwargs["system"] = system_prompt

        # Cancellation stops awaiting the SDK call, but the worker thread keeps running.
        response = await asyncio.to_thread(self._client.messages.create, **kwargs)
        return response.content[0].text
