from typing import Protocol


class LLM(Protocol):
    async def complete(self, prompt: str, *, system_prompt: str | None = None, model: str | None = None) -> str: ...
