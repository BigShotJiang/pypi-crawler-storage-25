# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Common Decorator."""

from collections.abc import Callable
from datetime import UTC, datetime
from functools import wraps
import logging
from logging import getLogger
import threading
import time
from typing import Any, TypeVar

from cotality.core.utils.string import args_to_string


logger = getLogger(__name__)

T = TypeVar("T")


class SingletonMeta(type):
    """A thread-safe metaclass for creating singleton classes.

    This metaclass ensures that only one instance of any class that uses it
    is ever created. It is robust enough to handle:
    1.  Inheritance: Each subclass will be its own singleton.
    2.  Multiple Decorators: Works seamlessly when stacked with other decorators.

    Usages:
    1. Basic Singleton:
       class MyClass(metaclass=SingletonMeta):
           def __init__(self, *args, **kwargs):
               # Initialization code here
    2. More complicated usage with decorators:
       @decorator1
       @decorator2
       class MyClass(metaclass=SingletonMeta, ExtendsAnotherClass):
           def __init__(self, *args, **kwargs):
               # Initialization code here

    """


def singleton(cls: type[T]) -> Callable[..., T]:  # noqa: UP047
    """DO NOT use this decorator. Will be removed!

    This decorator will not work if your class extends another class!.
    Use the avove SingletonMeta metaclass instead.

    Ensures only one instance of the decorated class is created,
    even in a multi-threaded environment.
    """
    # Store instances in a class-level dictionary
    instances = {}
    # Lock for thread safety
    lock = threading.Lock()

    @wraps(cls)
    def wrapper(*args: Any, **kwargs: Any) -> T:  # noqa: ANN401
        # Use double-checked locking for efficiency
        if cls.__name__ not in instances:
            with lock:
                # Check again inside the lock to avoid race condition
                if cls.__name__ not in instances:
                    logger.info("***** Creating new instance of class %s.", cls.__name__)
                    instances[cls.__name__] = cls(*args, **kwargs)
        return instances[cls.__name__]

    return wrapper


def _handle_api_response(api_response: Any, api: str, attempt: int, success_codes: list[int]) -> Any:  # noqa: ANN401
    """Handle the API response, checking for success and logging errors.

    Args:
        api_response (Any): The response object returned by the API call.
        api (str): The name of the API being called, used for logging.
        attempt (int): The current attempt number for the API call.
        success_codes (list): List of HTTP status codes that indicate success.
    """
    if hasattr(api_response, "status_code") and api_response.status_code in success_codes:
        return api_response
    if hasattr(api_response, "status_code"):
        logger.error(
            "Failed to call API: %s. Attempts:%s, Status code: %s, Response: %s",
            api,
            attempt,
            api_response.status_code,
            api_response.text if hasattr(api_response, "text") else "",
        )
    return None


def api_retry(
    api: str, success_codes: list[int], max_retries: int = 3, delay: int = 60
) -> Callable[[Callable[..., T]], Callable[..., T | None]]:
    """A decorator to retry a function call if it raises an exception.

    Args:
        api (str): The name of the API being called, used for logging.
        success_codes (list): List of HTTP status codes that indicate success.
        max_retries (int): Maximum number of retries before giving up.
        delay (int): Delay in seconds between retries.

    """

    def decorator(func: Callable[..., T]) -> Callable[..., T | None]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T | None:  # noqa: ANN401
            for attempt in range(max_retries):
                try:
                    api_response = func(*args, **kwargs)
                    result = _handle_api_response(api_response, api, attempt, success_codes)
                    if result is not None:
                        return result
                    time.sleep(delay)
                except Exception as e:
                    logger.exception(
                        "Failed to call API: %s. Attempts:%s, Error: %s",
                        api,
                        attempt,
                        str(e),  # noqa: TRY401
                    )
                    time.sleep(delay)
            return None

        return wrapper

    return decorator


def log(level: int = logging.DEBUG) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Turn on logging for this function.

    Args:
        level (_type_, optional): Log level. Defaults to logging.DEBUG.
    """

    def decorator_func(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper_func(*args: Any, **kwargs: Any) -> T:  # noqa: ANN401
            start_dt__ = datetime.now(tz=UTC)
            msg = f"Calling {func.__name__}({args_to_string(*args, **kwargs)})"
            if level == logging.INFO:
                logger.info(msg)
            else:
                logger.debug(msg)
            value = func(*args, **kwargs)
            msg = f'Function "{func.__name__!r}" finished in {datetime.now(tz=UTC) - start_dt__!s}'
            if level == logging.INFO:
                logger.info(msg)
            else:
                logger.debug(msg)
            return value

        return wrapper_func

    return decorator_func
