# Copyright 2025 Cotality
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Databricks Platform."""

from __future__ import annotations

import logging

from databricks.sdk import WorkspaceClient
from pyspark.sql.connect.session import SparkSession

from ...core.clgxtyping import DigitalGatewayMode, Environment, Locale, PlatformType, UserContext
from ...core.logger import init_logger
from ...core.platform import Platform as PlatformAbstract
from .database import DatabaseClient
from .secret import SecretClient


class DatabricksPlatform(PlatformAbstract):
    """Databricks Platform implementation."""

    def __init__(
        self,
        spark: SparkSession,
        environment: Environment = Environment.PROD,
        locale: Locale = Locale.EN_US,
        has_access_to_external_integration: bool = False,
        inside_native_platform: bool = True,
        digital_gateway_mode: DigitalGatewayMode = DigitalGatewayMode.LEGACY,
    ) -> None:
        """Initialize the Databricks Platform.

        Args:
            spark: Databricks Spark adapter (local or remote)
            environment: Environment for the platform
            locale: Locale for the platform
            has_access_to_external_integration: Flag for external integration access
            inside_native_platform: Flag indicating if running inside Databricks
            digital_gateway_mode: Mode for Digital Gateway
        """
        init_logger(platform_type=PlatformType.DATABRICKS)
        logger = logging.getLogger(__name__)

        # Create database client from spark adapter
        workspace_client = WorkspaceClient()
        database_client = DatabaseClient(spark=spark, workspace_client=workspace_client)

        # Create secret client from dbutils
        secret_client = SecretClient(workspace_client=workspace_client)

        super().__init__(
            platform_type=PlatformType.DATABRICKS,
            database_client=database_client,
            secret_client=secret_client,
            env=environment,
            locale=locale,
            user_context=_get_user_context(spark=spark),
            has_access_to_external_integration=has_access_to_external_integration,
            inside_native_platform=inside_native_platform,
            digital_gateway_mode=digital_gateway_mode,
        )
        logger.info("Databricks Platform initialized. User Context: %s", self.user_context)


def _get_user_context(spark: SparkSession) -> UserContext:
    """Get the user context.

    Args:
        spark: Databricks Spark adapter

    Returns:
        UserContext: The user context
    """
    user_context = UserContext(platform_type=PlatformType.DATABRICKS)

    # Try to get current user info from Databricks
    try:
        result = spark.sql("SELECT current_user() as user")
        if len(result) > 0:
            user_context.user_name = result.iloc[0]["user"]
    except Exception as err:
        logging.getLogger(__name__).warning("Could not get current user: %s", err)

    return user_context
