from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from .. import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnLogGroupAuditLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogs",
):
    '''Builder for CfnLogGroupLogsMixin to generate AUDIT_LOGS for CfnLogGroup.

    :cloudformationResource: AWS::Logs::LogGroup
    :logType: AUDIT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_logs import mixins as logs_mixins
        
        cfn_log_group_audit_logs = logs_mixins.CfnLogGroupAuditLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLogGroupAuditLogsRecordFields"]] = None,
    ) -> "CfnLogGroupLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3ad0c78deb0d05e538d9baa60a5762af6d91c499ff961813b844a64b0dfb0d4b)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnLogGroupAuditLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnLogGroupLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnLogGroupAuditLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLogGroupAuditLogsRecordFields"]] = None,
    ) -> "CfnLogGroupLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b29bc534fcd8c4e9608cc871553ccf9f79cbd27da369bd00bd211cb0341f3192)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnLogGroupAuditLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLogGroupLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnLogGroupAuditLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLogGroupAuditLogsRecordFields"]] = None,
    ) -> "CfnLogGroupLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b2fb83fd8d91788ac799357ff51145b5e0c32348aae067c4fafe7e1304a33bf)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnLogGroupAuditLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLogGroupLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLogGroupAuditLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLogGroupAuditLogsRecordFields"]] = None,
    ) -> "CfnLogGroupLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e14c8fe1a866d259b18198e3c7ad47e69f6deb0e1da79c1b01adc4c438520a2)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnLogGroupAuditLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnLogGroupLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnLogGroupAuditLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLogGroupAuditLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_logs import mixins as logs_mixins
            
            cfn_log_group_audit_logs_dest_props = logs_mixins.CfnLogGroupAuditLogsDestProps(
                record_fields=[logs_mixins.CfnLogGroupAuditLogsRecordFields.POLICYNAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c1aaf8a9e29831e54d5b807e728d8628677c4a1459ea72e052c5473a90af1a71)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLogGroupAuditLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLogGroupAuditLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLogGroupAuditLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLogGroupAuditLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLogGroupAuditLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLogGroupAuditLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_logs import mixins as logs_mixins
            
            cfn_log_group_audit_logs_firehose_props = logs_mixins.CfnLogGroupAuditLogsFirehoseProps(
                output_format=logs_mixins.CfnLogGroupAuditLogsOutputFormat.Firehose.JSON,
                record_fields=[logs_mixins.CfnLogGroupAuditLogsRecordFields.POLICYNAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6e4d349fc66e872220c0531034eab5ffbb615c64d2d492dc82df39cc78e65ee0)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLogGroupAuditLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLogGroupAuditLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLogGroupAuditLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLogGroupAuditLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLogGroupAuditLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLogGroupAuditLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLogGroupAuditLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLogGroupAuditLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_logs import mixins as logs_mixins
            
            cfn_log_group_audit_logs_log_group_props = logs_mixins.CfnLogGroupAuditLogsLogGroupProps(
                output_format=logs_mixins.CfnLogGroupAuditLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[logs_mixins.CfnLogGroupAuditLogsRecordFields.POLICYNAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__206ca77d8b87dedeb01249770e5ed2fa181fccee361227fbc94ded34b8d20d97)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLogGroupAuditLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLogGroupAuditLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLogGroupAuditLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLogGroupAuditLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLogGroupAuditLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnLogGroupAuditLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnLogGroupAuditLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_logs import mixins as logs_mixins
        
        cfn_log_group_audit_logs_output_format = logs_mixins.CfnLogGroupAuditLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsRecordFields"
)
class CfnLogGroupAuditLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    POLICYNAME = "POLICYNAME"
    '''
    :stability: experimental
    '''
    CLOUDWATCHLOGS_EVENTTIMESTAMP = "CLOUDWATCHLOGS_EVENTTIMESTAMP"
    '''
    :stability: experimental
    '''
    CLOUDWATCHLOGS_LOGSTREAM = "CLOUDWATCHLOGS_LOGSTREAM"
    '''
    :stability: experimental
    '''
    AUDITTIMESTAMP = "AUDITTIMESTAMP"
    '''
    :stability: experimental
    '''
    RESOURCEARN = "RESOURCEARN"
    '''
    :stability: experimental
    '''
    DATAIDENTIFIERS = "DATAIDENTIFIERS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupAuditLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnLogGroupAuditLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLogGroupAuditLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLogGroupAuditLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_logs import mixins as logs_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_log_group_audit_logs_s3_props = logs_mixins.CfnLogGroupAuditLogsS3Props(
                encryption_key=key_ref,
                output_format=logs_mixins.CfnLogGroupAuditLogsOutputFormat.S3.JSON,
                record_fields=[logs_mixins.CfnLogGroupAuditLogsRecordFields.POLICYNAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2999b6b21216edbd21cba846e4784fa6cc3d6529eeffd9b943f67bf668c69cd1)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnLogGroupAuditLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLogGroupAuditLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLogGroupAuditLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLogGroupAuditLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLogGroupAuditLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnLogGroupLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.mixins.CfnLogGroupLogsMixin",
):
    '''The ``AWS::Logs::LogGroup`` resource specifies a log group.

    A log group defines common properties for log streams, such as their retention and access control rules. Each log stream must belong to one log group.

    You can create up to 1,000,000 log groups per Region per account. You must use the following guidelines when naming a log group:

    - Log group names must be unique within a Region for an AWS account.
    - Log group names can be between 1 and 512 characters long.
    - Log group names consist of the following characters: a-z, A-Z, 0-9, '_' (underscore), '-' (hyphen), '/' (forward slash), and '.' (period).

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-logs-loggroup.html
    :cloudformationResource: AWS::Logs::LogGroup
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_logs import mixins as logs_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_log_group_logs_mixin = logs_mixins.CfnLogGroupLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Logs::LogGroup``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a89c0dbe7fece9ab7087b215600fccaab6b4f05925cdfbeeb6a6e3f16e9f5aff)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__10595c459f558b5dfe1b6f3524b9d650549112445e21a353e8e665d2eb87c1c6)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b725d0108948a33aaa749d3fc83e98dd7623ec1643563a56f2a2b701781eca3e)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="AUDIT_LOGS")
    def AUDIT_LOGS(cls) -> "CfnLogGroupAuditLogs":
        return typing.cast("CfnLogGroupAuditLogs", jsii.sget(cls, "AUDIT_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnLogGroupAuditLogs",
    "CfnLogGroupAuditLogsDestProps",
    "CfnLogGroupAuditLogsFirehoseProps",
    "CfnLogGroupAuditLogsLogGroupProps",
    "CfnLogGroupAuditLogsOutputFormat",
    "CfnLogGroupAuditLogsRecordFields",
    "CfnLogGroupAuditLogsS3Props",
    "CfnLogGroupLogsMixin",
]

publication.publish()

def _typecheckingstub__3ad0c78deb0d05e538d9baa60a5762af6d91c499ff961813b844a64b0dfb0d4b(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLogGroupAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b29bc534fcd8c4e9608cc871553ccf9f79cbd27da369bd00bd211cb0341f3192(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnLogGroupAuditLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLogGroupAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b2fb83fd8d91788ac799357ff51145b5e0c32348aae067c4fafe7e1304a33bf(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnLogGroupAuditLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLogGroupAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e14c8fe1a866d259b18198e3c7ad47e69f6deb0e1da79c1b01adc4c438520a2(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLogGroupAuditLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLogGroupAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c1aaf8a9e29831e54d5b807e728d8628677c4a1459ea72e052c5473a90af1a71(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLogGroupAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6e4d349fc66e872220c0531034eab5ffbb615c64d2d492dc82df39cc78e65ee0(
    *,
    output_format: typing.Optional[CfnLogGroupAuditLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLogGroupAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__206ca77d8b87dedeb01249770e5ed2fa181fccee361227fbc94ded34b8d20d97(
    *,
    output_format: typing.Optional[CfnLogGroupAuditLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLogGroupAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2999b6b21216edbd21cba846e4784fa6cc3d6529eeffd9b943f67bf668c69cd1(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLogGroupAuditLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLogGroupAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a89c0dbe7fece9ab7087b215600fccaab6b4f05925cdfbeeb6a6e3f16e9f5aff(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__10595c459f558b5dfe1b6f3524b9d650549112445e21a353e8e665d2eb87c1c6(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b725d0108948a33aaa749d3fc83e98dd7623ec1643563a56f2a2b701781eca3e(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
