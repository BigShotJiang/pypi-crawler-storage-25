from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from .._jsii import *

import aws_cdk.aws_logs as _aws_cdk_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8


class CloudwatchDeliveryDestination(
    _aws_cdk_aws_logs_ceddda9d.CfnDeliveryDestination,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.CloudwatchDeliveryDestination",
):
    '''(experimental) CloudWatch delivery destination for CloudWatch Logs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.interfaces import aws_logs as interfaces_logs
        
        # log_group_ref: interfaces_logs.ILogGroupRef
        
        cloudwatch_delivery_destination = logs.CloudwatchDeliveryDestination(self, "MyCloudwatchDeliveryDestination",
            log_group=log_group_ref,
        
            # the properties below are optional
            output_format="outputFormat"
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        output_format: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param log_group: (experimental) Log group to deliver logs to.
        :param output_format: (experimental) Format of the logs that are sent to this delivery destination.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__380b1cbfaa39db14b4bb9c9e91edae6af6cc310dd309103ea84f327536035c5f)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = CloudwatchDeliveryDestinationProps(
            log_group=log_group, output_format=output_format
        )

        jsii.create(self.__class__, self, [scope, id, props])


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.CloudwatchDeliveryDestinationProps",
    jsii_struct_bases=[],
    name_mapping={"log_group": "logGroup", "output_format": "outputFormat"},
)
class CloudwatchDeliveryDestinationProps:
    def __init__(
        self,
        *,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        output_format: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Properties for Cloudwatch delivery destination.

        :param log_group: (experimental) Log group to deliver logs to.
        :param output_format: (experimental) Format of the logs that are sent to this delivery destination.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview import aws_logs as logs
            from aws_cdk.interfaces import aws_logs as interfaces_logs
            
            # log_group_ref: interfaces_logs.ILogGroupRef
            
            cloudwatch_delivery_destination_props = logs.CloudwatchDeliveryDestinationProps(
                log_group=log_group_ref,
            
                # the properties below are optional
                output_format="outputFormat"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__613065d3ca9a5b6e69352d777a3543fa64d13e435d843031413b5b025a304ef3)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "log_group": log_group,
        }
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def log_group(self) -> "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef":
        '''(experimental) Log group to deliver logs to.

        :stability: experimental
        '''
        result = self._values.get("log_group")
        assert result is not None, "Required property 'log_group' is missing"
        return typing.cast("_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef", result)

    @builtins.property
    def output_format(self) -> typing.Optional[builtins.str]:
        '''(experimental) Format of the logs that are sent to this delivery destination.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CloudwatchDeliveryDestinationProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class FirehoseDeliveryDestination(
    _aws_cdk_aws_logs_ceddda9d.CfnDeliveryDestination,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.FirehoseDeliveryDestination",
):
    '''(experimental) Firehose delivery destination for CloudWatch Logs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.interfaces import aws_kinesisfirehose as interfaces_kinesisfirehose
        
        # delivery_stream_ref: interfaces_kinesisfirehose.IDeliveryStreamRef
        
        firehose_delivery_destination = logs.FirehoseDeliveryDestination(self, "MyFirehoseDeliveryDestination",
            delivery_stream=delivery_stream_ref,
        
            # the properties below are optional
            output_format="outputFormat",
            source_account_id="sourceAccountId"
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        output_format: typing.Optional[builtins.str] = None,
        source_account_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param delivery_stream: (experimental) Delivery stream to delivery logs to.
        :param output_format: (experimental) Format of the logs that are sent to this delivery destination.
        :param source_account_id: (experimental) Optional acount id for account the delivery source is in for cross account Vended Logs.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0e762e86c18a9a5ff2ded83366c75883a868b9a55d1a5123d5bcac8ee390cea6)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = FirehoseDeliveryDestinationProps(
            delivery_stream=delivery_stream,
            output_format=output_format,
            source_account_id=source_account_id,
        )

        jsii.create(self.__class__, self, [scope, id, props])


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.FirehoseDeliveryDestinationProps",
    jsii_struct_bases=[],
    name_mapping={
        "delivery_stream": "deliveryStream",
        "output_format": "outputFormat",
        "source_account_id": "sourceAccountId",
    },
)
class FirehoseDeliveryDestinationProps:
    def __init__(
        self,
        *,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        output_format: typing.Optional[builtins.str] = None,
        source_account_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Properties for Firehose delivery destination.

        :param delivery_stream: (experimental) Delivery stream to delivery logs to.
        :param output_format: (experimental) Format of the logs that are sent to this delivery destination.
        :param source_account_id: (experimental) Optional acount id for account the delivery source is in for cross account Vended Logs.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview import aws_logs as logs
            from aws_cdk.interfaces import aws_kinesisfirehose as interfaces_kinesisfirehose
            
            # delivery_stream_ref: interfaces_kinesisfirehose.IDeliveryStreamRef
            
            firehose_delivery_destination_props = logs.FirehoseDeliveryDestinationProps(
                delivery_stream=delivery_stream_ref,
            
                # the properties below are optional
                output_format="outputFormat",
                source_account_id="sourceAccountId"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__58320ccd3b54f6c005043154f676db34d20bcdf3d2c5fc7c4dfa1a13036f25b5)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument source_account_id", value=source_account_id, expected_type=type_hints["source_account_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "delivery_stream": delivery_stream,
        }
        if output_format is not None:
            self._values["output_format"] = output_format
        if source_account_id is not None:
            self._values["source_account_id"] = source_account_id

    @builtins.property
    def delivery_stream(
        self,
    ) -> "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef":
        '''(experimental) Delivery stream to delivery logs to.

        :stability: experimental
        '''
        result = self._values.get("delivery_stream")
        assert result is not None, "Required property 'delivery_stream' is missing"
        return typing.cast("_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef", result)

    @builtins.property
    def output_format(self) -> typing.Optional[builtins.str]:
        '''(experimental) Format of the logs that are sent to this delivery destination.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def source_account_id(self) -> typing.Optional[builtins.str]:
        '''(experimental) Optional acount id for account the delivery source is in for cross account Vended Logs.

        :stability: experimental
        '''
        result = self._values.get("source_account_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "FirehoseDeliveryDestinationProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.interface(jsii_type="@aws-cdk/mixins-preview.aws_logs.ILogsDelivery")
class ILogsDelivery(typing_extensions.Protocol):
    '''(experimental) Represents the delivery of vended logs to a destination.

    :stability: experimental
    '''

    @jsii.member(jsii_name="bind")
    def bind(
        self,
        scope: "_constructs_77d1e7e8.IConstruct",
        log_type: builtins.str,
        source_resource_arn: builtins.str,
    ) -> "ILogsDeliveryConfig":
        '''(experimental) Binds the log delivery to a source resource and creates a delivery connection between the source and destination.

        :param scope: - The construct scope.
        :param log_type: - The type of logs that the delivery source will produce.
        :param source_resource_arn: - The Arn of the source resource.

        :return: The delivery reference

        :stability: experimental
        '''
        ...


class _ILogsDeliveryProxy:
    '''(experimental) Represents the delivery of vended logs to a destination.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@aws-cdk/mixins-preview.aws_logs.ILogsDelivery"

    @jsii.member(jsii_name="bind")
    def bind(
        self,
        scope: "_constructs_77d1e7e8.IConstruct",
        log_type: builtins.str,
        source_resource_arn: builtins.str,
    ) -> "ILogsDeliveryConfig":
        '''(experimental) Binds the log delivery to a source resource and creates a delivery connection between the source and destination.

        :param scope: - The construct scope.
        :param log_type: - The type of logs that the delivery source will produce.
        :param source_resource_arn: - The Arn of the source resource.

        :return: The delivery reference

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f40d3cac2e91f6aaddd07e548330430a47757a92baefe0e8435310cf7030c46b)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
        return typing.cast("ILogsDeliveryConfig", jsii.invoke(self, "bind", [scope, log_type, source_resource_arn]))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, ILogsDelivery).__jsii_proxy_class__ = lambda : _ILogsDeliveryProxy


@jsii.interface(jsii_type="@aws-cdk/mixins-preview.aws_logs.ILogsDeliveryConfig")
class ILogsDeliveryConfig(typing_extensions.Protocol):
    '''(experimental) The individual elements of a logs delivery integration.

    :stability: experimental
    '''

    @builtins.property
    @jsii.member(jsii_name="delivery")
    def delivery(self) -> "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryRef":
        '''(experimental) The logs delivery.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="deliveryDestination")
    def delivery_destination(
        self,
    ) -> "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef":
        '''(experimental) The logs delivery destination.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="deliverySource")
    def delivery_source(
        self,
    ) -> "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliverySourceRef":
        '''(experimental) The logs delivery source.

        :stability: experimental
        '''
        ...


class _ILogsDeliveryConfigProxy:
    '''(experimental) The individual elements of a logs delivery integration.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@aws-cdk/mixins-preview.aws_logs.ILogsDeliveryConfig"

    @builtins.property
    @jsii.member(jsii_name="delivery")
    def delivery(self) -> "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryRef":
        '''(experimental) The logs delivery.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryRef", jsii.get(self, "delivery"))

    @builtins.property
    @jsii.member(jsii_name="deliveryDestination")
    def delivery_destination(
        self,
    ) -> "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef":
        '''(experimental) The logs delivery destination.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef", jsii.get(self, "deliveryDestination"))

    @builtins.property
    @jsii.member(jsii_name="deliverySource")
    def delivery_source(
        self,
    ) -> "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliverySourceRef":
        '''(experimental) The logs delivery source.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliverySourceRef", jsii.get(self, "deliverySource"))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, ILogsDeliveryConfig).__jsii_proxy_class__ = lambda : _ILogsDeliveryConfigProxy


@jsii.implements(ILogsDelivery)
class LogGroupLogsDelivery(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.LogGroupLogsDelivery",
):
    '''(experimental) Delivers vended logs to a CloudWatch Log Group.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.interfaces import aws_logs as interfaces_logs
        
        # log_group_ref: interfaces_logs.ILogGroupRef
        
        log_group_logs_delivery = logs.LogGroupLogsDelivery(log_group_ref,
            mandatory_fields=["mandatoryFields"],
            output_format="outputFormat",
            provided_fields=["providedFields"]
        )
    '''

    def __init__(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional[builtins.str] = None,
        mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''(experimental) Creates a new log group delivery.

        :param log_group: - The CloudWatch Logs log group reference.
        :param output_format: (experimental) Format of the logs that are sent to the delivery destination specified.
        :param mandatory_fields: (experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type. Default: - log type has no mandatory fields
        :param provided_fields: (experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__94a309989d5d7187cf24683386068fad207515b2576eeb8c48e05d73bff1f48e)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = DeliveryProps(
            output_format=output_format,
            mandatory_fields=mandatory_fields,
            provided_fields=provided_fields,
        )

        jsii.create(self.__class__, self, [log_group, props])

    @jsii.member(jsii_name="bind")
    def bind(
        self,
        scope: "_constructs_77d1e7e8.IConstruct",
        log_type: builtins.str,
        source_resource_arn: builtins.str,
    ) -> "ILogsDeliveryConfig":
        '''(experimental) Binds Log Group to a source resource for the purposes of log delivery and creates a delivery source, a delivery destination, and a connection between them.

        :param scope: -
        :param log_type: -
        :param source_resource_arn: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e79469f5cbd3e4cbe225c0f77e8931bcbaa38f24a1dbedf8f27e8de6f2a1684)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
        return typing.cast("ILogsDeliveryConfig", jsii.invoke(self, "bind", [scope, log_type, source_resource_arn]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.RecordFieldDeliveryProps",
    jsii_struct_bases=[],
    name_mapping={
        "mandatory_fields": "mandatoryFields",
        "provided_fields": "providedFields",
    },
)
class RecordFieldDeliveryProps:
    def __init__(
        self,
        *,
        mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''(experimental) Props for RecordFields involved in log delivery.

        :param mandatory_fields: (experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type. Default: - log type has no mandatory fields
        :param provided_fields: (experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview import aws_logs as logs
            
            record_field_delivery_props = logs.RecordFieldDeliveryProps(
                mandatory_fields=["mandatoryFields"],
                provided_fields=["providedFields"]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__733d18ff4f438bfd89499f8c05facbb5a987748e231ba787f1055e39efda24a1)
            check_type(argname="argument mandatory_fields", value=mandatory_fields, expected_type=type_hints["mandatory_fields"])
            check_type(argname="argument provided_fields", value=provided_fields, expected_type=type_hints["provided_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if mandatory_fields is not None:
            self._values["mandatory_fields"] = mandatory_fields
        if provided_fields is not None:
            self._values["provided_fields"] = provided_fields

    @builtins.property
    def mandatory_fields(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type.

        :default: - log type has no mandatory fields

        :stability: experimental
        '''
        result = self._values.get("mandatory_fields")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def provided_fields(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        :defualt: - no fields were provided
        '''
        result = self._values.get("provided_fields")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "RecordFieldDeliveryProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class S3DeliveryDestination(
    _aws_cdk_aws_logs_ceddda9d.CfnDeliveryDestination,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.S3DeliveryDestination",
):
    '''(experimental) Creates an S3 delivery destination for CloudWatch Logs.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        from aws_cdk import Environment, Environment
        import aws_cdk.mixins_preview.aws_logs as log_destinations
        import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins
        
        # Create CloudFront distribution
        # origin: s3.IBucket
        
        
        destination_account = "123456789012"
        source_account = "234567890123"
        region = "us-east-1"
        
        app = App()
        
        dest_stack = Stack(app, "destination-stack",
            env=Environment(
                account=destination_account,
                region=region
            )
        )
        
        # Create destination bucket
        dest_bucket = s3.Bucket(dest_stack, "DeliveryBucket")
        log_destinations.S3DeliveryDestination(dest_stack, "Destination",
            bucket=dest_bucket,
            source_account_id=source_account
        )
        
        source_stack = Stack(app, "source-stack",
            env=Environment(
                account=source_account,
                region=region
            )
        )
        distribution = cloudfront.Distribution(source_stack, "Distribution",
            default_behavior=cloudfront.BehaviorOptions(
                origin=origins.S3BucketOrigin.with_origin_access_control(origin)
            )
        )
        
        destination = logs.CfnDeliveryDestination.from_delivery_destination_arn(source_stack, "Destination", "arn of Delivery Destination in destinationAccount")
        
        distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_destination(destination))
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional[builtins.str] = None,
        permissions_version: typing.Optional["S3LogsDeliveryPermissionsVersion"] = None,
        source_account_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param bucket: (experimental) The S3 bucket to deliver logs to.
        :param encryption_key: (experimental) KMS key to use for encrypting logs in the S3 bucket. When provided, grants the logs delivery service permissions to use the key. Default: - No encryption key is configured
        :param output_format: (experimental) Format of the logs that are sent to this delivery destination.
        :param permissions_version: (experimental) The permissions version ('V1' or 'V2') to be used for this delivery. Depending on the source of the logs, different permissions are required. Default: "V2"
        :param source_account_id: (experimental) Optional acount id for account the delivery source is in for cross account Vended Logs.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60cb82c1afc0fdcb575d1ede66a9e128a1a41953e071ada16d3ae7eab36bbc5b)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = S3DeliveryDestinationProps(
            bucket=bucket,
            encryption_key=encryption_key,
            output_format=output_format,
            permissions_version=permissions_version,
            source_account_id=source_account_id,
        )

        jsii.create(self.__class__, self, [scope, id, props])


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.S3DeliveryDestinationProps",
    jsii_struct_bases=[],
    name_mapping={
        "bucket": "bucket",
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "permissions_version": "permissionsVersion",
        "source_account_id": "sourceAccountId",
    },
)
class S3DeliveryDestinationProps:
    def __init__(
        self,
        *,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional[builtins.str] = None,
        permissions_version: typing.Optional["S3LogsDeliveryPermissionsVersion"] = None,
        source_account_id: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Properties for S3 delivery destination.

        :param bucket: (experimental) The S3 bucket to deliver logs to.
        :param encryption_key: (experimental) KMS key to use for encrypting logs in the S3 bucket. When provided, grants the logs delivery service permissions to use the key. Default: - No encryption key is configured
        :param output_format: (experimental) Format of the logs that are sent to this delivery destination.
        :param permissions_version: (experimental) The permissions version ('V1' or 'V2') to be used for this delivery. Depending on the source of the logs, different permissions are required. Default: "V2"
        :param source_account_id: (experimental) Optional acount id for account the delivery source is in for cross account Vended Logs.

        :stability: experimental
        :exampleMetadata: infused

        Example::

            from aws_cdk import Environment, Environment
            import aws_cdk.mixins_preview.aws_logs as log_destinations
            import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins
            
            # Create CloudFront distribution
            # origin: s3.IBucket
            
            
            destination_account = "123456789012"
            source_account = "234567890123"
            region = "us-east-1"
            
            app = App()
            
            dest_stack = Stack(app, "destination-stack",
                env=Environment(
                    account=destination_account,
                    region=region
                )
            )
            
            # Create destination bucket
            dest_bucket = s3.Bucket(dest_stack, "DeliveryBucket")
            log_destinations.S3DeliveryDestination(dest_stack, "Destination",
                bucket=dest_bucket,
                source_account_id=source_account
            )
            
            source_stack = Stack(app, "source-stack",
                env=Environment(
                    account=source_account,
                    region=region
                )
            )
            distribution = cloudfront.Distribution(source_stack, "Distribution",
                default_behavior=cloudfront.BehaviorOptions(
                    origin=origins.S3BucketOrigin.with_origin_access_control(origin)
                )
            )
            
            destination = logs.CfnDeliveryDestination.from_delivery_destination_arn(source_stack, "Destination", "arn of Delivery Destination in destinationAccount")
            
            distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_destination(destination))
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2858a18820d247e9ce7bbf550ebeabd400cd048d2d2c6fd02558cd0a0b64914a)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument permissions_version", value=permissions_version, expected_type=type_hints["permissions_version"])
            check_type(argname="argument source_account_id", value=source_account_id, expected_type=type_hints["source_account_id"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "bucket": bucket,
        }
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if permissions_version is not None:
            self._values["permissions_version"] = permissions_version
        if source_account_id is not None:
            self._values["source_account_id"] = source_account_id

    @builtins.property
    def bucket(self) -> "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef":
        '''(experimental) The S3 bucket to deliver logs to.

        :stability: experimental
        '''
        result = self._values.get("bucket")
        assert result is not None, "Required property 'bucket' is missing"
        return typing.cast("_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef", result)

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) KMS key to use for encrypting logs in the S3 bucket.

        When provided, grants the logs delivery service permissions to use the key.

        :default: - No encryption key is configured

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional[builtins.str]:
        '''(experimental) Format of the logs that are sent to this delivery destination.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def permissions_version(
        self,
    ) -> typing.Optional["S3LogsDeliveryPermissionsVersion"]:
        '''(experimental) The permissions version ('V1' or 'V2') to be used for this delivery.

        Depending on the source of the logs, different permissions are required.

        :default: "V2"

        :stability: experimental
        '''
        result = self._values.get("permissions_version")
        return typing.cast(typing.Optional["S3LogsDeliveryPermissionsVersion"], result)

    @builtins.property
    def source_account_id(self) -> typing.Optional[builtins.str]:
        '''(experimental) Optional acount id for account the delivery source is in for cross account Vended Logs.

        :stability: experimental
        '''
        result = self._values.get("source_account_id")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "S3DeliveryDestinationProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(ILogsDelivery)
class S3LogsDelivery(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.S3LogsDelivery",
):
    '''(experimental) Delivers vended logs to an S3 Bucket.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.interfaces import aws_kms as interfaces_kms
        from aws_cdk.interfaces import aws_s3 as interfaces_s3
        
        # bucket_ref: interfaces_s3.IBucketRef
        # key_ref: interfaces_kms.IKeyRef
        
        s3_logs_delivery = logs.S3LogsDelivery(bucket_ref,
            kms_key=key_ref,
            mandatory_fields=["mandatoryFields"],
            output_format="outputFormat",
            permissions_version=logs.S3LogsDeliveryPermissionsVersion.V1,
            provided_fields=["providedFields"]
        )
    '''

    def __init__(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        kms_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        permissions_version: typing.Optional["S3LogsDeliveryPermissionsVersion"] = None,
        output_format: typing.Optional[builtins.str] = None,
        mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''(experimental) Creates a new S3 Bucket delivery.

        :param bucket: -
        :param kms_key: (experimental) KMS key to use for encrypting logs in the S3 bucket. When provided, grants the logs delivery service permissions to use the key. Default: - No encryption key is configured
        :param permissions_version: (experimental) The permissions version ('V1' or 'V2') to be used for this delivery. Depending on the source of the logs, different permissions are required. Default: "V2"
        :param output_format: (experimental) Format of the logs that are sent to the delivery destination specified.
        :param mandatory_fields: (experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type. Default: - log type has no mandatory fields
        :param provided_fields: (experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a123400340e622550ee0692a1be65c353fc5d0686c01e30601595a4e7d6e91ed)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = S3LogsDeliveryProps(
            kms_key=kms_key,
            permissions_version=permissions_version,
            output_format=output_format,
            mandatory_fields=mandatory_fields,
            provided_fields=provided_fields,
        )

        jsii.create(self.__class__, self, [bucket, props])

    @jsii.member(jsii_name="bind")
    def bind(
        self,
        scope: "_constructs_77d1e7e8.IConstruct",
        log_type: builtins.str,
        source_resource_arn: builtins.str,
    ) -> "ILogsDeliveryConfig":
        '''(experimental) Binds S3 Bucket to a source resource for the purposes of log delivery and creates a delivery source, a delivery destination, and a connection between them.

        :param scope: -
        :param log_type: -
        :param source_resource_arn: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aef5b209cd95fb6ed852e9ae5b30d866d8c4d527a173a6acf38342d2ead7f3e0)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
        return typing.cast("ILogsDeliveryConfig", jsii.invoke(self, "bind", [scope, log_type, source_resource_arn]))


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.S3LogsDeliveryPermissionsVersion"
)
class S3LogsDeliveryPermissionsVersion(enum.Enum):
    '''(experimental) S3 Vended Logs Permissions version.

    :stability: experimental
    '''

    V1 = "V1"
    '''(experimental) V1.

    :stability: experimental
    '''
    V2 = "V2"
    '''(experimental) V2.

    :stability: experimental
    '''


class XRayDeliveryDestination(
    _aws_cdk_aws_logs_ceddda9d.CfnDeliveryDestination,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.XRayDeliveryDestination",
):
    '''(experimental) XRay delivery destination for XRay traces.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        
        x_ray_delivery_destination = logs.XRayDeliveryDestination(self, "MyXRayDeliveryDestination",
            source_resource="sourceResource"
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        source_resource: builtins.str,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param source_resource: (experimental) Arn of the source resource.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__253ae5c78144de8a4a825dc3f7a98ea95ba614c46eac3c25f4006fab0f9d3291)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = XRayDeliveryDestinationProps(source_resource=source_resource)

        jsii.create(self.__class__, self, [scope, id, props])


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.XRayDeliveryDestinationProps",
    jsii_struct_bases=[],
    name_mapping={"source_resource": "sourceResource"},
)
class XRayDeliveryDestinationProps:
    def __init__(self, *, source_resource: builtins.str) -> None:
        '''(experimental) Properties for XRay delivery destination.

        :param source_resource: (experimental) Arn of the source resource.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview import aws_logs as logs
            
            x_ray_delivery_destination_props = logs.XRayDeliveryDestinationProps(
                source_resource="sourceResource"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__962ea08ac7c20a4558a3e05a9e16ed9c53bd4c2ca6c2979e1f69a38f9ef4fed6)
            check_type(argname="argument source_resource", value=source_resource, expected_type=type_hints["source_resource"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "source_resource": source_resource,
        }

    @builtins.property
    def source_resource(self) -> builtins.str:
        '''(experimental) Arn of the source resource.

        :stability: experimental
        '''
        result = self._values.get("source_resource")
        assert result is not None, "Required property 'source_resource' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "XRayDeliveryDestinationProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(ILogsDelivery)
class XRayLogsDelivery(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.XRayLogsDelivery",
):
    '''(experimental) Delivers vended logs to AWS X-Ray.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        
        x_ray_logs_delivery = logs.XRayLogsDelivery(
            mandatory_fields=["mandatoryFields"],
            provided_fields=["providedFields"]
        )
    '''

    def __init__(
        self,
        *,
        mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''(experimental) Creates a new X-Ray delivery.

        :param mandatory_fields: (experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type. Default: - log type has no mandatory fields
        :param provided_fields: (experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        '''
        props = RecordFieldDeliveryProps(
            mandatory_fields=mandatory_fields, provided_fields=provided_fields
        )

        jsii.create(self.__class__, self, [props])

    @jsii.member(jsii_name="bind")
    def bind(
        self,
        scope: "_constructs_77d1e7e8.IConstruct",
        log_type: builtins.str,
        source_resource_arn: builtins.str,
    ) -> "ILogsDeliveryConfig":
        '''(experimental) Binds X-Ray Destination to a source resource for the purposes of log delivery and creates a delivery source, a delivery destination, and a connection between them.

        :param scope: -
        :param log_type: -
        :param source_resource_arn: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b1fe6c2c446c40af17ce3976872564b1c99e7609366cd6b223ac1075c26d73d)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
        return typing.cast("ILogsDeliveryConfig", jsii.invoke(self, "bind", [scope, log_type, source_resource_arn]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.DeliveryProps",
    jsii_struct_bases=[RecordFieldDeliveryProps],
    name_mapping={
        "mandatory_fields": "mandatoryFields",
        "provided_fields": "providedFields",
        "output_format": "outputFormat",
    },
)
class DeliveryProps(RecordFieldDeliveryProps):
    def __init__(
        self,
        *,
        mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_format: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Props for Log Deliveries.

        :param mandatory_fields: (experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type. Default: - log type has no mandatory fields
        :param provided_fields: (experimental) RecordFields the user has defined to be used in log delivery.
        :param output_format: (experimental) Format of the logs that are sent to the delivery destination specified.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview import aws_logs as logs
            
            delivery_props = logs.DeliveryProps(
                mandatory_fields=["mandatoryFields"],
                output_format="outputFormat",
                provided_fields=["providedFields"]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56e046af8f3ada5d46e99d90800d009e18d74c30078a6347a0423489f9c96bee)
            check_type(argname="argument mandatory_fields", value=mandatory_fields, expected_type=type_hints["mandatory_fields"])
            check_type(argname="argument provided_fields", value=provided_fields, expected_type=type_hints["provided_fields"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if mandatory_fields is not None:
            self._values["mandatory_fields"] = mandatory_fields
        if provided_fields is not None:
            self._values["provided_fields"] = provided_fields
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def mandatory_fields(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type.

        :default: - log type has no mandatory fields

        :stability: experimental
        '''
        result = self._values.get("mandatory_fields")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def provided_fields(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        :defualt: - no fields were provided
        '''
        result = self._values.get("provided_fields")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def output_format(self) -> typing.Optional[builtins.str]:
        '''(experimental) Format of the logs that are sent to the delivery destination specified.

        :stability: experimental
        :defualt: - undefined, use whatever default the delivery destination specifies
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DeliveryProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(ILogsDelivery)
class DestinationLogsDelivery(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.DestinationLogsDelivery",
):
    '''(experimental) Delivers vended logs to a CfnDeliveryDestination specified by an arn.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.interfaces import aws_logs as interfaces_logs
        
        # delivery_destination_ref: interfaces_logs.IDeliveryDestinationRef
        
        destination_logs_delivery = logs.DestinationLogsDelivery(delivery_destination_ref,
            mandatory_fields=["mandatoryFields"],
            provided_fields=["providedFields"]
        )
    '''

    def __init__(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''
        :param destination: -
        :param mandatory_fields: (experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type. Default: - log type has no mandatory fields
        :param provided_fields: (experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bde54cad5dace2792b854e2d0438acb1ae6ab2218abfe55687c21e88a658e6d3)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = RecordFieldDeliveryProps(
            mandatory_fields=mandatory_fields, provided_fields=provided_fields
        )

        jsii.create(self.__class__, self, [destination, props])

    @jsii.member(jsii_name="bind")
    def bind(
        self,
        scope: "_constructs_77d1e7e8.IConstruct",
        log_type: builtins.str,
        source_resource_arn: builtins.str,
    ) -> "ILogsDeliveryConfig":
        '''(experimental) Binds Delivery Destination to a source resource for the purposes of log delivery and creates a delivery source and a connection between the source and the destination.

        :param scope: -
        :param log_type: -
        :param source_resource_arn: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a199e71cc4a9ef5041c03e6f28ea1b83a2bce9adf9d60131dafe1cd62dfcb7cd)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
        return typing.cast("ILogsDeliveryConfig", jsii.invoke(self, "bind", [scope, log_type, source_resource_arn]))


@jsii.implements(ILogsDelivery)
class FirehoseLogsDelivery(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_logs.FirehoseLogsDelivery",
):
    '''(experimental) Delivers vended logs to a Firehose Delivery Stream.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.interfaces import aws_kinesisfirehose as interfaces_kinesisfirehose
        
        # delivery_stream_ref: interfaces_kinesisfirehose.IDeliveryStreamRef
        
        firehose_logs_delivery = logs.FirehoseLogsDelivery(delivery_stream_ref,
            mandatory_fields=["mandatoryFields"],
            output_format="outputFormat",
            provided_fields=["providedFields"]
        )
    '''

    def __init__(
        self,
        stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional[builtins.str] = None,
        mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> None:
        '''(experimental) Creates a new Firehose delivery.

        :param stream: - The Kinesis Data Firehose delivery stream.
        :param output_format: (experimental) Format of the logs that are sent to the delivery destination specified.
        :param mandatory_fields: (experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type. Default: - log type has no mandatory fields
        :param provided_fields: (experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b0b24d190fc62c060eef3e86d06686a87e03b4269c251da1b3a3cc7d20774d7)
            check_type(argname="argument stream", value=stream, expected_type=type_hints["stream"])
        props = DeliveryProps(
            output_format=output_format,
            mandatory_fields=mandatory_fields,
            provided_fields=provided_fields,
        )

        jsii.create(self.__class__, self, [stream, props])

    @jsii.member(jsii_name="bind")
    def bind(
        self,
        scope: "_constructs_77d1e7e8.IConstruct",
        log_type: builtins.str,
        source_resource_arn: builtins.str,
    ) -> "ILogsDeliveryConfig":
        '''(experimental) Binds Firehose Delivery Stream to a source resource for the purposes of log delivery and creates a delivery source, a delivery destination, and a connection between them.

        :param scope: -
        :param log_type: -
        :param source_resource_arn: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a64902ab0b4e9bc2c5da4e4e81c16d8d2c90b2bd79f4f0d8f5e95ddd4e909e65)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
        return typing.cast("ILogsDeliveryConfig", jsii.invoke(self, "bind", [scope, log_type, source_resource_arn]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_logs.S3LogsDeliveryProps",
    jsii_struct_bases=[DeliveryProps],
    name_mapping={
        "mandatory_fields": "mandatoryFields",
        "provided_fields": "providedFields",
        "output_format": "outputFormat",
        "kms_key": "kmsKey",
        "permissions_version": "permissionsVersion",
    },
)
class S3LogsDeliveryProps(DeliveryProps):
    def __init__(
        self,
        *,
        mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_format: typing.Optional[builtins.str] = None,
        kms_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        permissions_version: typing.Optional["S3LogsDeliveryPermissionsVersion"] = None,
    ) -> None:
        '''(experimental) Props for S3LogsDelivery.

        :param mandatory_fields: (experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type. Default: - log type has no mandatory fields
        :param provided_fields: (experimental) RecordFields the user has defined to be used in log delivery.
        :param output_format: (experimental) Format of the logs that are sent to the delivery destination specified.
        :param kms_key: (experimental) KMS key to use for encrypting logs in the S3 bucket. When provided, grants the logs delivery service permissions to use the key. Default: - No encryption key is configured
        :param permissions_version: (experimental) The permissions version ('V1' or 'V2') to be used for this delivery. Depending on the source of the logs, different permissions are required. Default: "V2"

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview import aws_logs as logs
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            s3_logs_delivery_props = logs.S3LogsDeliveryProps(
                kms_key=key_ref,
                mandatory_fields=["mandatoryFields"],
                output_format="outputFormat",
                permissions_version=logs.S3LogsDeliveryPermissionsVersion.V1,
                provided_fields=["providedFields"]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__965d6da0502509cc8b0a3bf4ed55be1a6e577c7cd78c674370ee559100584de5)
            check_type(argname="argument mandatory_fields", value=mandatory_fields, expected_type=type_hints["mandatory_fields"])
            check_type(argname="argument provided_fields", value=provided_fields, expected_type=type_hints["provided_fields"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument kms_key", value=kms_key, expected_type=type_hints["kms_key"])
            check_type(argname="argument permissions_version", value=permissions_version, expected_type=type_hints["permissions_version"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if mandatory_fields is not None:
            self._values["mandatory_fields"] = mandatory_fields
        if provided_fields is not None:
            self._values["provided_fields"] = provided_fields
        if output_format is not None:
            self._values["output_format"] = output_format
        if kms_key is not None:
            self._values["kms_key"] = kms_key
        if permissions_version is not None:
            self._values["permissions_version"] = permissions_version

    @builtins.property
    def mandatory_fields(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Any recordFields that a mandatory to be included in a log delivery of a certain log type.

        :default: - log type has no mandatory fields

        :stability: experimental
        '''
        result = self._values.get("mandatory_fields")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def provided_fields(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) RecordFields the user has defined to be used in log delivery.

        :stability: experimental
        :defualt: - no fields were provided
        '''
        result = self._values.get("provided_fields")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def output_format(self) -> typing.Optional[builtins.str]:
        '''(experimental) Format of the logs that are sent to the delivery destination specified.

        :stability: experimental
        :defualt: - undefined, use whatever default the delivery destination specifies
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def kms_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) KMS key to use for encrypting logs in the S3 bucket.

        When provided, grants the logs delivery service permissions to use the key.

        :default: - No encryption key is configured

        :stability: experimental
        '''
        result = self._values.get("kms_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def permissions_version(
        self,
    ) -> typing.Optional["S3LogsDeliveryPermissionsVersion"]:
        '''(experimental) The permissions version ('V1' or 'V2') to be used for this delivery.

        Depending on the source of the logs, different permissions are required.

        :default: "V2"

        :stability: experimental
        '''
        result = self._values.get("permissions_version")
        return typing.cast(typing.Optional["S3LogsDeliveryPermissionsVersion"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "S3LogsDeliveryProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CloudwatchDeliveryDestination",
    "CloudwatchDeliveryDestinationProps",
    "DeliveryProps",
    "DestinationLogsDelivery",
    "FirehoseDeliveryDestination",
    "FirehoseDeliveryDestinationProps",
    "FirehoseLogsDelivery",
    "ILogsDelivery",
    "ILogsDeliveryConfig",
    "LogGroupLogsDelivery",
    "RecordFieldDeliveryProps",
    "S3DeliveryDestination",
    "S3DeliveryDestinationProps",
    "S3LogsDelivery",
    "S3LogsDeliveryPermissionsVersion",
    "S3LogsDeliveryProps",
    "XRayDeliveryDestination",
    "XRayDeliveryDestinationProps",
    "XRayLogsDelivery",
    "events",
    "mixins",
]

publication.publish()

# Loading modules to ensure their types are registered with the jsii runtime library
from . import events
from . import mixins

def _typecheckingstub__380b1cbfaa39db14b4bb9c9e91edae6af6cc310dd309103ea84f327536035c5f(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    output_format: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__613065d3ca9a5b6e69352d777a3543fa64d13e435d843031413b5b025a304ef3(
    *,
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    output_format: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0e762e86c18a9a5ff2ded83366c75883a868b9a55d1a5123d5bcac8ee390cea6(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    output_format: typing.Optional[builtins.str] = None,
    source_account_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__58320ccd3b54f6c005043154f676db34d20bcdf3d2c5fc7c4dfa1a13036f25b5(
    *,
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    output_format: typing.Optional[builtins.str] = None,
    source_account_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f40d3cac2e91f6aaddd07e548330430a47757a92baefe0e8435310cf7030c46b(
    scope: _constructs_77d1e7e8.IConstruct,
    log_type: builtins.str,
    source_resource_arn: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94a309989d5d7187cf24683386068fad207515b2576eeb8c48e05d73bff1f48e(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[builtins.str] = None,
    mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e79469f5cbd3e4cbe225c0f77e8931bcbaa38f24a1dbedf8f27e8de6f2a1684(
    scope: _constructs_77d1e7e8.IConstruct,
    log_type: builtins.str,
    source_resource_arn: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__733d18ff4f438bfd89499f8c05facbb5a987748e231ba787f1055e39efda24a1(
    *,
    mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60cb82c1afc0fdcb575d1ede66a9e128a1a41953e071ada16d3ae7eab36bbc5b(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[builtins.str] = None,
    permissions_version: typing.Optional[S3LogsDeliveryPermissionsVersion] = None,
    source_account_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2858a18820d247e9ce7bbf550ebeabd400cd048d2d2c6fd02558cd0a0b64914a(
    *,
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[builtins.str] = None,
    permissions_version: typing.Optional[S3LogsDeliveryPermissionsVersion] = None,
    source_account_id: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a123400340e622550ee0692a1be65c353fc5d0686c01e30601595a4e7d6e91ed(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    kms_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    permissions_version: typing.Optional[S3LogsDeliveryPermissionsVersion] = None,
    output_format: typing.Optional[builtins.str] = None,
    mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aef5b209cd95fb6ed852e9ae5b30d866d8c4d527a173a6acf38342d2ead7f3e0(
    scope: _constructs_77d1e7e8.IConstruct,
    log_type: builtins.str,
    source_resource_arn: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__253ae5c78144de8a4a825dc3f7a98ea95ba614c46eac3c25f4006fab0f9d3291(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    source_resource: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__962ea08ac7c20a4558a3e05a9e16ed9c53bd4c2ca6c2979e1f69a38f9ef4fed6(
    *,
    source_resource: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b1fe6c2c446c40af17ce3976872564b1c99e7609366cd6b223ac1075c26d73d(
    scope: _constructs_77d1e7e8.IConstruct,
    log_type: builtins.str,
    source_resource_arn: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56e046af8f3ada5d46e99d90800d009e18d74c30078a6347a0423489f9c96bee(
    *,
    mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_format: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bde54cad5dace2792b854e2d0438acb1ae6ab2218abfe55687c21e88a658e6d3(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a199e71cc4a9ef5041c03e6f28ea1b83a2bce9adf9d60131dafe1cd62dfcb7cd(
    scope: _constructs_77d1e7e8.IConstruct,
    log_type: builtins.str,
    source_resource_arn: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b0b24d190fc62c060eef3e86d06686a87e03b4269c251da1b3a3cc7d20774d7(
    stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[builtins.str] = None,
    mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a64902ab0b4e9bc2c5da4e4e81c16d8d2c90b2bd79f4f0d8f5e95ddd4e909e65(
    scope: _constructs_77d1e7e8.IConstruct,
    log_type: builtins.str,
    source_resource_arn: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__965d6da0502509cc8b0a3bf4ed55be1a6e577c7cd78c674370ee559100584de5(
    *,
    mandatory_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    provided_fields: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_format: typing.Optional[builtins.str] = None,
    kms_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    permissions_version: typing.Optional[S3LogsDeliveryPermissionsVersion] = None,
) -> None:
    """Type checking stubs"""
    pass

for cls in [ILogsDelivery, ILogsDeliveryConfig]:
    typing.cast(typing.Any, cls).__protocol_attrs__ = typing.cast(typing.Any, cls).__protocol_attrs__ - set(['__jsii_proxy_class__', '__jsii_type__'])
