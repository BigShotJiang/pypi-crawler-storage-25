from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnEventBusErrorLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogs",
):
    '''Builder for CfnEventBusLogsMixin to generate ERROR_LOGS for CfnEventBus.

    :cloudformationResource: AWS::Events::EventBus
    :logType: ERROR_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
        
        cfn_event_bus_error_logs = events_mixins.CfnEventBusErrorLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusErrorLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__41a5ee3e08aaf530c74a472382f9efc9becad51132b845fd18b652397f95b704)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnEventBusErrorLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnEventBusErrorLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusErrorLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cfe0f2e5bed87e9cc3c3f29dc8ee093be5cb976c67bb81fee4a502eb757fa299)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnEventBusErrorLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnEventBusErrorLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusErrorLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__69de5bae1d8842f42f23797b0916e24d29c8f06a7eda727c27abbbae9208d89f)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnEventBusErrorLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnEventBusErrorLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusErrorLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a6f6406077eac7ecd5fc97d3a34beaf298e74f734bf27b50eeabed891e0482d7)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnEventBusErrorLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnEventBusErrorLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusErrorLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_error_logs_dest_props = events_mixins.CfnEventBusErrorLogsDestProps(
                record_fields=[events_mixins.CfnEventBusErrorLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c8978d4321943e398aaee76131f276822c7b09a5f0bb4b4620f7c425c620835)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusErrorLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusErrorLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusErrorLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnEventBusErrorLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnEventBusErrorLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusErrorLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_error_logs_firehose_props = events_mixins.CfnEventBusErrorLogsFirehoseProps(
                output_format=events_mixins.CfnEventBusErrorLogsOutputFormat.Firehose.JSON,
                record_fields=[events_mixins.CfnEventBusErrorLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0d7928eb5d25914e47343d57d5532eb66813b09a55dfc3ea1470881929e23a3b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnEventBusErrorLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusErrorLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusErrorLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusErrorLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusErrorLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnEventBusErrorLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnEventBusErrorLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusErrorLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_error_logs_log_group_props = events_mixins.CfnEventBusErrorLogsLogGroupProps(
                output_format=events_mixins.CfnEventBusErrorLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[events_mixins.CfnEventBusErrorLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a36096e59ce1605a9951bb87bbf9b812fe892741a6ea1662cc0084ee0f997cdf)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnEventBusErrorLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusErrorLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusErrorLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusErrorLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusErrorLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnEventBusErrorLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnEventBusErrorLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
        
        cfn_event_bus_error_logs_output_format = events_mixins.CfnEventBusErrorLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsRecordFields"
)
class CfnEventBusErrorLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    MESSAGE_TIMESTAMP_MS = "MESSAGE_TIMESTAMP_MS"
    '''
    :stability: experimental
    '''
    EVENT_BUS_NAME = "EVENT_BUS_NAME"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    EVENT_ID = "EVENT_ID"
    '''
    :stability: experimental
    '''
    INVOCATION_ID = "INVOCATION_ID"
    '''
    :stability: experimental
    '''
    MESSAGE_TYPE = "MESSAGE_TYPE"
    '''
    :stability: experimental
    '''
    LOG_LEVEL = "LOG_LEVEL"
    '''
    :stability: experimental
    '''
    DETAILS = "DETAILS"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusErrorLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnEventBusErrorLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnEventBusErrorLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusErrorLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_event_bus_error_logs_s3_props = events_mixins.CfnEventBusErrorLogsS3Props(
                encryption_key=key_ref,
                output_format=events_mixins.CfnEventBusErrorLogsOutputFormat.S3.JSON,
                record_fields=[events_mixins.CfnEventBusErrorLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40c25daefcf7538e3d8f9e168ae70d5a5947fc7e5377c88c4eed4f761cf754dd)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnEventBusErrorLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusErrorLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusErrorLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusErrorLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusErrorLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnEventBusInfoLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogs",
):
    '''Builder for CfnEventBusLogsMixin to generate INFO_LOGS for CfnEventBus.

    :cloudformationResource: AWS::Events::EventBus
    :logType: INFO_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
        
        cfn_event_bus_info_logs = events_mixins.CfnEventBusInfoLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusInfoLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b94566b27f0b9f15e0bf3066a827cd4be44445c393fd4c0a8c10345e1d1f1ea5)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnEventBusInfoLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnEventBusInfoLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusInfoLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bdcaf880d4809ed6d14c8ac945535ccc5ff743251118e260de3f579650b5cb71)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnEventBusInfoLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnEventBusInfoLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusInfoLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aa5ecd5b1fe61ac55ac014d181ca568998f1121b50f39848badfb38a34762b5e)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnEventBusInfoLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnEventBusInfoLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusInfoLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17128e8958ccec834fd5f9e39e50b50f506337c53a0a242c7178d3971186d1e3)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnEventBusInfoLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnEventBusInfoLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusInfoLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_info_logs_dest_props = events_mixins.CfnEventBusInfoLogsDestProps(
                record_fields=[events_mixins.CfnEventBusInfoLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__621e4455fa894ced171fdb9f983f60c1653b62d4154ce4c516a57dcf2dc00715)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusInfoLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusInfoLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusInfoLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnEventBusInfoLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnEventBusInfoLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusInfoLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_info_logs_firehose_props = events_mixins.CfnEventBusInfoLogsFirehoseProps(
                output_format=events_mixins.CfnEventBusInfoLogsOutputFormat.Firehose.JSON,
                record_fields=[events_mixins.CfnEventBusInfoLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2f759bf9aba573bd536db277dafee9b37e2652d367343f9daba959573773f191)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnEventBusInfoLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusInfoLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusInfoLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusInfoLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusInfoLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnEventBusInfoLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnEventBusInfoLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusInfoLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_info_logs_log_group_props = events_mixins.CfnEventBusInfoLogsLogGroupProps(
                output_format=events_mixins.CfnEventBusInfoLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[events_mixins.CfnEventBusInfoLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a20ff608d5692e67395d8bb46f1356111c452943fc6acd17f0b1d7877d5a20e3)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnEventBusInfoLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusInfoLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusInfoLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusInfoLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusInfoLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnEventBusInfoLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnEventBusInfoLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
        
        cfn_event_bus_info_logs_output_format = events_mixins.CfnEventBusInfoLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsRecordFields"
)
class CfnEventBusInfoLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    MESSAGE_TIMESTAMP_MS = "MESSAGE_TIMESTAMP_MS"
    '''
    :stability: experimental
    '''
    EVENT_BUS_NAME = "EVENT_BUS_NAME"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    EVENT_ID = "EVENT_ID"
    '''
    :stability: experimental
    '''
    INVOCATION_ID = "INVOCATION_ID"
    '''
    :stability: experimental
    '''
    MESSAGE_TYPE = "MESSAGE_TYPE"
    '''
    :stability: experimental
    '''
    LOG_LEVEL = "LOG_LEVEL"
    '''
    :stability: experimental
    '''
    DETAILS = "DETAILS"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusInfoLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnEventBusInfoLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnEventBusInfoLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusInfoLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_event_bus_info_logs_s3_props = events_mixins.CfnEventBusInfoLogsS3Props(
                encryption_key=key_ref,
                output_format=events_mixins.CfnEventBusInfoLogsOutputFormat.S3.JSON,
                record_fields=[events_mixins.CfnEventBusInfoLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2629bb4d872f33d6fcc71e40994a67d3b4cb2705cd1617fca547f8c02f99b4c3)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnEventBusInfoLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusInfoLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusInfoLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusInfoLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusInfoLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnEventBusLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusLogsMixin",
):
    '''Specifies an event bus within your account.

    This can be a custom event bus which you can use to receive events from your custom applications and services, or it can be a partner event bus which can be matched to a partner event source.
    .. epigraph::

       As an aid to help you jumpstart developing CloudFormation templates, the EventBridge console enables you to create templates from the existing event buses in your account. For more information, see `Generating CloudFormation templates from an EventBridge event bus <https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-generate-event-bus-template.html>`_ in the *Amazon EventBridge User Guide* .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-events-eventbus.html
    :cloudformationResource: AWS::Events::EventBus
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_event_bus_logs_mixin = events_mixins.CfnEventBusLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Events::EventBus``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ecf52cdfb2ea5f4b989c2624c8c60a8aa46fbeba1f61edd163358f5c95c3bb1)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e4b961fc3c6d4902f12f4f7c094ac003027b945f174add6f2c249a04924727e)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e2af320cc679c7718af4a06fb9fdf547f87933ab61dc31ecdcbe46701dc3122)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ERROR_LOGS")
    def ERROR_LOGS(cls) -> "CfnEventBusErrorLogs":
        return typing.cast("CfnEventBusErrorLogs", jsii.sget(cls, "ERROR_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="INFO_LOGS")
    def INFO_LOGS(cls) -> "CfnEventBusInfoLogs":
        return typing.cast("CfnEventBusInfoLogs", jsii.sget(cls, "INFO_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TRACE_LOGS")
    def TRACE_LOGS(cls) -> "CfnEventBusTraceLogs":
        return typing.cast("CfnEventBusTraceLogs", jsii.sget(cls, "TRACE_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnEventBusTraceLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogs",
):
    '''Builder for CfnEventBusLogsMixin to generate TRACE_LOGS for CfnEventBus.

    :cloudformationResource: AWS::Events::EventBus
    :logType: TRACE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
        
        cfn_event_bus_trace_logs = events_mixins.CfnEventBusTraceLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusTraceLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__78619bbb0797c21b2b5f15ed97d6b347c3387521827983e5c93bb8eb03a1d456)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnEventBusTraceLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnEventBusTraceLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusTraceLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1a63c71dc421da70bb5c2b78868942d18007fd94214701a525a93ad102bc88f7)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnEventBusTraceLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnEventBusTraceLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusTraceLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d7b755285003aa1a2cd33d63f1720ad43532b8535a53424fdf539367d76f3120)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnEventBusTraceLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnEventBusTraceLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusTraceLogsRecordFields"]] = None,
    ) -> "CfnEventBusLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c7f3c4abda436e3412c244526f382aa82c8af50a2a5d70af5feaaa29ab6e91a)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnEventBusTraceLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnEventBusLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnEventBusTraceLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusTraceLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_trace_logs_dest_props = events_mixins.CfnEventBusTraceLogsDestProps(
                record_fields=[events_mixins.CfnEventBusTraceLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__addea589dee4846e4d386eb1e05d9319e2720aa5f29e110a91dc0fb1b3031e2c)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusTraceLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusTraceLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusTraceLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnEventBusTraceLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnEventBusTraceLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusTraceLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_trace_logs_firehose_props = events_mixins.CfnEventBusTraceLogsFirehoseProps(
                output_format=events_mixins.CfnEventBusTraceLogsOutputFormat.Firehose.JSON,
                record_fields=[events_mixins.CfnEventBusTraceLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32dd6f779f180d277d0f29f293ac7865a6b1602599e3f18bdfb753cf75c53911)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnEventBusTraceLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusTraceLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusTraceLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusTraceLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusTraceLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnEventBusTraceLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnEventBusTraceLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusTraceLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            
            cfn_event_bus_trace_logs_log_group_props = events_mixins.CfnEventBusTraceLogsLogGroupProps(
                output_format=events_mixins.CfnEventBusTraceLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[events_mixins.CfnEventBusTraceLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bfb2ff79b504b41f50ad688776b9e2844245b544f3f40e55a8ed5ea8697cc0b6)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnEventBusTraceLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusTraceLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusTraceLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusTraceLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusTraceLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnEventBusTraceLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnEventBusTraceLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
        
        cfn_event_bus_trace_logs_output_format = events_mixins.CfnEventBusTraceLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsRecordFields"
)
class CfnEventBusTraceLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    MESSAGE_TIMESTAMP_MS = "MESSAGE_TIMESTAMP_MS"
    '''
    :stability: experimental
    '''
    EVENT_BUS_NAME = "EVENT_BUS_NAME"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    EVENT_ID = "EVENT_ID"
    '''
    :stability: experimental
    '''
    INVOCATION_ID = "INVOCATION_ID"
    '''
    :stability: experimental
    '''
    MESSAGE_TYPE = "MESSAGE_TYPE"
    '''
    :stability: experimental
    '''
    LOG_LEVEL = "LOG_LEVEL"
    '''
    :stability: experimental
    '''
    DETAILS = "DETAILS"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_events.mixins.CfnEventBusTraceLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnEventBusTraceLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnEventBusTraceLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnEventBusTraceLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_events import mixins as events_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_event_bus_trace_logs_s3_props = events_mixins.CfnEventBusTraceLogsS3Props(
                encryption_key=key_ref,
                output_format=events_mixins.CfnEventBusTraceLogsOutputFormat.S3.JSON,
                record_fields=[events_mixins.CfnEventBusTraceLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__84a0c68e08d0234bc65a5e70a112ce308713b2ea88e59fea52db4281c28de3ba)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnEventBusTraceLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnEventBusTraceLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnEventBusTraceLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnEventBusTraceLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnEventBusTraceLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnEventBusErrorLogs",
    "CfnEventBusErrorLogsDestProps",
    "CfnEventBusErrorLogsFirehoseProps",
    "CfnEventBusErrorLogsLogGroupProps",
    "CfnEventBusErrorLogsOutputFormat",
    "CfnEventBusErrorLogsRecordFields",
    "CfnEventBusErrorLogsS3Props",
    "CfnEventBusInfoLogs",
    "CfnEventBusInfoLogsDestProps",
    "CfnEventBusInfoLogsFirehoseProps",
    "CfnEventBusInfoLogsLogGroupProps",
    "CfnEventBusInfoLogsOutputFormat",
    "CfnEventBusInfoLogsRecordFields",
    "CfnEventBusInfoLogsS3Props",
    "CfnEventBusLogsMixin",
    "CfnEventBusTraceLogs",
    "CfnEventBusTraceLogsDestProps",
    "CfnEventBusTraceLogsFirehoseProps",
    "CfnEventBusTraceLogsLogGroupProps",
    "CfnEventBusTraceLogsOutputFormat",
    "CfnEventBusTraceLogsRecordFields",
    "CfnEventBusTraceLogsS3Props",
]

publication.publish()

def _typecheckingstub__41a5ee3e08aaf530c74a472382f9efc9becad51132b845fd18b652397f95b704(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusErrorLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cfe0f2e5bed87e9cc3c3f29dc8ee093be5cb976c67bb81fee4a502eb757fa299(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnEventBusErrorLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusErrorLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__69de5bae1d8842f42f23797b0916e24d29c8f06a7eda727c27abbbae9208d89f(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnEventBusErrorLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusErrorLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6f6406077eac7ecd5fc97d3a34beaf298e74f734bf27b50eeabed891e0482d7(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnEventBusErrorLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusErrorLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c8978d4321943e398aaee76131f276822c7b09a5f0bb4b4620f7c425c620835(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusErrorLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0d7928eb5d25914e47343d57d5532eb66813b09a55dfc3ea1470881929e23a3b(
    *,
    output_format: typing.Optional[CfnEventBusErrorLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusErrorLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a36096e59ce1605a9951bb87bbf9b812fe892741a6ea1662cc0084ee0f997cdf(
    *,
    output_format: typing.Optional[CfnEventBusErrorLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusErrorLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40c25daefcf7538e3d8f9e168ae70d5a5947fc7e5377c88c4eed4f761cf754dd(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnEventBusErrorLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusErrorLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b94566b27f0b9f15e0bf3066a827cd4be44445c393fd4c0a8c10345e1d1f1ea5(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusInfoLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bdcaf880d4809ed6d14c8ac945535ccc5ff743251118e260de3f579650b5cb71(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnEventBusInfoLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusInfoLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aa5ecd5b1fe61ac55ac014d181ca568998f1121b50f39848badfb38a34762b5e(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnEventBusInfoLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusInfoLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17128e8958ccec834fd5f9e39e50b50f506337c53a0a242c7178d3971186d1e3(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnEventBusInfoLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusInfoLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__621e4455fa894ced171fdb9f983f60c1653b62d4154ce4c516a57dcf2dc00715(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusInfoLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f759bf9aba573bd536db277dafee9b37e2652d367343f9daba959573773f191(
    *,
    output_format: typing.Optional[CfnEventBusInfoLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusInfoLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a20ff608d5692e67395d8bb46f1356111c452943fc6acd17f0b1d7877d5a20e3(
    *,
    output_format: typing.Optional[CfnEventBusInfoLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusInfoLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2629bb4d872f33d6fcc71e40994a67d3b4cb2705cd1617fca547f8c02f99b4c3(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnEventBusInfoLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusInfoLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ecf52cdfb2ea5f4b989c2624c8c60a8aa46fbeba1f61edd163358f5c95c3bb1(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e4b961fc3c6d4902f12f4f7c094ac003027b945f174add6f2c249a04924727e(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e2af320cc679c7718af4a06fb9fdf547f87933ab61dc31ecdcbe46701dc3122(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__78619bbb0797c21b2b5f15ed97d6b347c3387521827983e5c93bb8eb03a1d456(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusTraceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a63c71dc421da70bb5c2b78868942d18007fd94214701a525a93ad102bc88f7(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnEventBusTraceLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusTraceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7b755285003aa1a2cd33d63f1720ad43532b8535a53424fdf539367d76f3120(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnEventBusTraceLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusTraceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c7f3c4abda436e3412c244526f382aa82c8af50a2a5d70af5feaaa29ab6e91a(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnEventBusTraceLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusTraceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__addea589dee4846e4d386eb1e05d9319e2720aa5f29e110a91dc0fb1b3031e2c(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusTraceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32dd6f779f180d277d0f29f293ac7865a6b1602599e3f18bdfb753cf75c53911(
    *,
    output_format: typing.Optional[CfnEventBusTraceLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusTraceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bfb2ff79b504b41f50ad688776b9e2844245b544f3f40e55a8ed5ea8697cc0b6(
    *,
    output_format: typing.Optional[CfnEventBusTraceLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusTraceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__84a0c68e08d0234bc65a5e70a112ce308713b2ea88e59fea52db4281c28de3ba(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnEventBusTraceLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnEventBusTraceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
