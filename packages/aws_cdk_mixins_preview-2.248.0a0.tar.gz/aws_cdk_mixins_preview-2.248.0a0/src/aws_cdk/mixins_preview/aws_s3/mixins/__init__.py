from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnBucketLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketLogsMixin",
):
    '''The ``AWS::S3::Bucket`` resource creates an Amazon S3 bucket in the same AWS Region where you create the AWS CloudFormation stack.

    To control how AWS CloudFormation handles the bucket when the stack is deleted, you can set a deletion policy for your bucket. You can choose to *retain* the bucket or to *delete* the bucket. For more information, see `DeletionPolicy Attribute <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-deletionpolicy.html>`_ .
    .. epigraph::

       You can only delete empty buckets. Deletion fails for buckets that have contents.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3-bucket.html
    :cloudformationResource: AWS::S3::Bucket
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_s3 import mixins as s3_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_bucket_logs_mixin = s3_mixins.CfnBucketLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::S3::Bucket``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6fe1fe76cef8af9ac04baae03187f0e7b8cd1227b900c6f73f595434c6c6161)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__089abeef61e0562fb310db5bc441ecbf163ba00fbcbd2bdf01a74cabc938262e)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e2169c42f525d4d2285968128112841ea9224b75203c83d3c0bda59ee802b5c)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="S3_SERVER_ACCESS_LOGS")
    def S3_SERVER_ACCESS_LOGS(cls) -> "CfnBucketS3ServerAccessLogs":
        return typing.cast("CfnBucketS3ServerAccessLogs", jsii.sget(cls, "S3_SERVER_ACCESS_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnBucketS3ServerAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogs",
):
    '''Builder for CfnBucketLogsMixin to generate S3_SERVER_ACCESS_LOGS for CfnBucket.

    :cloudformationResource: AWS::S3::Bucket
    :logType: S3_SERVER_ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_s3 import mixins as s3_mixins
        
        cfn_bucket_s3_server_access_logs = s3_mixins.CfnBucketS3ServerAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnBucketS3ServerAccessLogsRecordFields"]] = None,
    ) -> "CfnBucketLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0c202ca5cfe6f223d811d12af44dc96aa98a134edbca625ecf830c21a35bcc77)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnBucketS3ServerAccessLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnBucketLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBucketS3ServerAccessLogsRecordFields"]] = None,
    ) -> "CfnBucketLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee90289ebff0d7985e62be698eee73cfd21e3e8ccea2ba557fa858088323363e)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnBucketS3ServerAccessLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnBucketLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBucketS3ServerAccessLogsRecordFields"]] = None,
    ) -> "CfnBucketLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2815602017af14f7047a8dbfad3e3ddb3479dbc531dfd9b16a44af28ccd906fb)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnBucketS3ServerAccessLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnBucketLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBucketS3ServerAccessLogsRecordFields"]] = None,
    ) -> "CfnBucketLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__58feeded689a9b4b08c466a2b8463555d4da0be65cf8e32f0393ac621d95b8ee)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnBucketS3ServerAccessLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnBucketLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnBucketS3ServerAccessLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnBucketS3ServerAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_s3 import mixins as s3_mixins
            
            cfn_bucket_s3_server_access_logs_dest_props = s3_mixins.CfnBucketS3ServerAccessLogsDestProps(
                record_fields=[s3_mixins.CfnBucketS3ServerAccessLogsRecordFields.BUCKET_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__517a82f28ebca15ad4fdbdf4dabfc119e386de268f66af0833b8a6c7c7ef97aa)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnBucketS3ServerAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnBucketS3ServerAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnBucketS3ServerAccessLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnBucketS3ServerAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBucketS3ServerAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_s3 import mixins as s3_mixins
            
            cfn_bucket_s3_server_access_logs_firehose_props = s3_mixins.CfnBucketS3ServerAccessLogsFirehoseProps(
                output_format=s3_mixins.CfnBucketS3ServerAccessLogsOutputFormat.Firehose.JSON,
                record_fields=[s3_mixins.CfnBucketS3ServerAccessLogsRecordFields.BUCKET_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76bf0f81780beb5a6496554fe22d3c731c2aff58b88a6e6b07f0179dc922549d)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnBucketS3ServerAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnBucketS3ServerAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnBucketS3ServerAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnBucketS3ServerAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBucketS3ServerAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_s3 import mixins as s3_mixins
            
            cfn_bucket_s3_server_access_logs_log_group_props = s3_mixins.CfnBucketS3ServerAccessLogsLogGroupProps(
                output_format=s3_mixins.CfnBucketS3ServerAccessLogsOutputFormat.LogGroup.JSON,
                record_fields=[s3_mixins.CfnBucketS3ServerAccessLogsRecordFields.BUCKET_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6258b1bc3bb010457ebf67e8bd901366b624e3a4d97b801b8f87c30939dec160)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnBucketS3ServerAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnBucketS3ServerAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnBucketS3ServerAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnBucketS3ServerAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnBucketS3ServerAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_s3 import mixins as s3_mixins
        
        cfn_bucket_s3_server_access_logs_output_format = s3_mixins.CfnBucketS3ServerAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsRecordFields"
)
class CfnBucketS3ServerAccessLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    BUCKET_NAME = "BUCKET_NAME"
    '''
    :stability: experimental
    '''
    SCHEMA_VERSION_ID = "SCHEMA_VERSION_ID"
    '''
    :stability: experimental
    '''
    BUCKET_ARN = "BUCKET_ARN"
    '''
    :stability: experimental
    '''
    REQUEST_TIME = "REQUEST_TIME"
    '''
    :stability: experimental
    '''
    BUCKET_OWNER_ID = "BUCKET_OWNER_ID"
    '''
    :stability: experimental
    '''
    REMOTE_IP = "REMOTE_IP"
    '''
    :stability: experimental
    '''
    REQUESTER = "REQUESTER"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    OPERATION = "OPERATION"
    '''
    :stability: experimental
    '''
    KEY_NAME = "KEY_NAME"
    '''
    :stability: experimental
    '''
    REQUEST_URI = "REQUEST_URI"
    '''
    :stability: experimental
    '''
    HTTP_STATUS = "HTTP_STATUS"
    '''
    :stability: experimental
    '''
    ERROR_CODE = "ERROR_CODE"
    '''
    :stability: experimental
    '''
    BYTES_SENT_SIZE = "BYTES_SENT_SIZE"
    '''
    :stability: experimental
    '''
    OBJECT_SIZE = "OBJECT_SIZE"
    '''
    :stability: experimental
    '''
    TOTAL_DURATION = "TOTAL_DURATION"
    '''
    :stability: experimental
    '''
    TURN_AROUND_DURATION = "TURN_AROUND_DURATION"
    '''
    :stability: experimental
    '''
    REFERER = "REFERER"
    '''
    :stability: experimental
    '''
    USER_AGENT = "USER_AGENT"
    '''
    :stability: experimental
    '''
    VERSION_ID = "VERSION_ID"
    '''
    :stability: experimental
    '''
    HOST_ID = "HOST_ID"
    '''
    :stability: experimental
    '''
    SIGNATURE_VERSION = "SIGNATURE_VERSION"
    '''
    :stability: experimental
    '''
    CIPHER_SUITE = "CIPHER_SUITE"
    '''
    :stability: experimental
    '''
    AUTHENTICATION_TYPE = "AUTHENTICATION_TYPE"
    '''
    :stability: experimental
    '''
    HOST_HEADER = "HOST_HEADER"
    '''
    :stability: experimental
    '''
    TLS_VERSION = "TLS_VERSION"
    '''
    :stability: experimental
    '''
    ACCESS_POINT_ARN = "ACCESS_POINT_ARN"
    '''
    :stability: experimental
    '''
    ACL_REQUIRED = "ACL_REQUIRED"
    '''
    :stability: experimental
    '''
    SOURCE_REGION = "SOURCE_REGION"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_s3.mixins.CfnBucketS3ServerAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnBucketS3ServerAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBucketS3ServerAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_s3 import mixins as s3_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_bucket_s3_server_access_logs_s3_props = s3_mixins.CfnBucketS3ServerAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=s3_mixins.CfnBucketS3ServerAccessLogsOutputFormat.S3.JSON,
                record_fields=[s3_mixins.CfnBucketS3ServerAccessLogsRecordFields.BUCKET_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__11ec190182b47bbbb88808d7b10675b1c53b8bde0a73d770eb565659c83b603f)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnBucketS3ServerAccessLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnBucketS3ServerAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnBucketS3ServerAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnBucketS3ServerAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnBucketLogsMixin",
    "CfnBucketS3ServerAccessLogs",
    "CfnBucketS3ServerAccessLogsDestProps",
    "CfnBucketS3ServerAccessLogsFirehoseProps",
    "CfnBucketS3ServerAccessLogsLogGroupProps",
    "CfnBucketS3ServerAccessLogsOutputFormat",
    "CfnBucketS3ServerAccessLogsRecordFields",
    "CfnBucketS3ServerAccessLogsS3Props",
]

publication.publish()

def _typecheckingstub__b6fe1fe76cef8af9ac04baae03187f0e7b8cd1227b900c6f73f595434c6c6161(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__089abeef61e0562fb310db5bc441ecbf163ba00fbcbd2bdf01a74cabc938262e(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e2169c42f525d4d2285968128112841ea9224b75203c83d3c0bda59ee802b5c(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0c202ca5cfe6f223d811d12af44dc96aa98a134edbca625ecf830c21a35bcc77(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnBucketS3ServerAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee90289ebff0d7985e62be698eee73cfd21e3e8ccea2ba557fa858088323363e(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnBucketS3ServerAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBucketS3ServerAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2815602017af14f7047a8dbfad3e3ddb3479dbc531dfd9b16a44af28ccd906fb(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnBucketS3ServerAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBucketS3ServerAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__58feeded689a9b4b08c466a2b8463555d4da0be65cf8e32f0393ac621d95b8ee(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnBucketS3ServerAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBucketS3ServerAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__517a82f28ebca15ad4fdbdf4dabfc119e386de268f66af0833b8a6c7c7ef97aa(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnBucketS3ServerAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76bf0f81780beb5a6496554fe22d3c731c2aff58b88a6e6b07f0179dc922549d(
    *,
    output_format: typing.Optional[CfnBucketS3ServerAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBucketS3ServerAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6258b1bc3bb010457ebf67e8bd901366b624e3a4d97b801b8f87c30939dec160(
    *,
    output_format: typing.Optional[CfnBucketS3ServerAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBucketS3ServerAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__11ec190182b47bbbb88808d7b10675b1c53b8bde0a73d770eb565659c83b603f(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnBucketS3ServerAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBucketS3ServerAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
