from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnFirewallAlertLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallAlertLogs",
):
    '''Builder for CfnFirewallLogsMixin to generate ALERT_LOGS for CfnFirewall.

    :cloudformationResource: AWS::NetworkFirewall::Firewall
    :logType: ALERT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
        
        cfn_firewall_alert_logs = networkfirewall_mixins.CfnFirewallAlertLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnFirewallLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__14ff14e0ce201229dd4e6a8d4b1e5fac6f124ab4e4e3e13a079d615dcc610666)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnFirewallAlertLogsOutputFormat.Firehose"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7328590b513805553dee64080b0a79efac3e8f24960e08b3147e3e1c0cd77569)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnFirewallAlertLogsFirehoseProps(output_format=output_format)

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnFirewallAlertLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e67a490929fffe050d352d6197630e45bb231048c2061069a1de90a533030013)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnFirewallAlertLogsLogGroupProps(output_format=output_format)

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnFirewallAlertLogsOutputFormat.S3"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f141909d9744c277aa229bebcd21ccdf011d035acd18dda3281db79ce95441e)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnFirewallAlertLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallAlertLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnFirewallAlertLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnFirewallAlertLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            
            cfn_firewall_alert_logs_firehose_props = networkfirewall_mixins.CfnFirewallAlertLogsFirehoseProps(
                output_format=networkfirewall_mixins.CfnFirewallAlertLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08130940b97c3fef96e5fc9802346c415c2a91a2bee6e3673caeeb5d938a6a41)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnFirewallAlertLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallAlertLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallAlertLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallAlertLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnFirewallAlertLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnFirewallAlertLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            
            cfn_firewall_alert_logs_log_group_props = networkfirewall_mixins.CfnFirewallAlertLogsLogGroupProps(
                output_format=networkfirewall_mixins.CfnFirewallAlertLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d55d8e7e480062b81d50329ddc5b4f07e2b7b6b6523ae5388814d2c0105b0832)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnFirewallAlertLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallAlertLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallAlertLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnFirewallAlertLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallAlertLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnFirewallAlertLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
        
        cfn_firewall_alert_logs_output_format = networkfirewall_mixins.CfnFirewallAlertLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallAlertLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallAlertLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallAlertLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallAlertLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnFirewallAlertLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnFirewallAlertLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_firewall_alert_logs_s3_props = networkfirewall_mixins.CfnFirewallAlertLogsS3Props(
                encryption_key=key_ref,
                output_format=networkfirewall_mixins.CfnFirewallAlertLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7d681e06a4da17744f148c95f6566b81107ccc792af01e57aa3360f33fe24192)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnFirewallAlertLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallAlertLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallAlertLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnFirewallFlowLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallFlowLogs",
):
    '''Builder for CfnFirewallLogsMixin to generate FLOW_LOGS for CfnFirewall.

    :cloudformationResource: AWS::NetworkFirewall::Firewall
    :logType: FLOW_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
        
        cfn_firewall_flow_logs = networkfirewall_mixins.CfnFirewallFlowLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnFirewallLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a6224300f27ca81da20cc7a309754d5a64291392effa5a2914ce8c80ae4048ee)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnFirewallFlowLogsOutputFormat.Firehose"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8d0c1095f2366a9586eb3f395a32504aad3308ecf9172d6fa5ad6412e69e1c70)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnFirewallFlowLogsFirehoseProps(output_format=output_format)

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnFirewallFlowLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd71c0b1f1d27a1812b9d05a137e96a538baa825c4553a6e08482e6090df99d3)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnFirewallFlowLogsLogGroupProps(output_format=output_format)

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnFirewallFlowLogsOutputFormat.S3"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4a3f58fb66ed021923fb17d2ddd81fb144af311cbc8109de9a34dcc4a9f7445)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnFirewallFlowLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallFlowLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnFirewallFlowLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnFirewallFlowLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            
            cfn_firewall_flow_logs_firehose_props = networkfirewall_mixins.CfnFirewallFlowLogsFirehoseProps(
                output_format=networkfirewall_mixins.CfnFirewallFlowLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62d5ab785ed1e6afd3292c79fa1cdd5daa5dbf1d23111acec435fec3c7f3ff73)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnFirewallFlowLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallFlowLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallFlowLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallFlowLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnFirewallFlowLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnFirewallFlowLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            
            cfn_firewall_flow_logs_log_group_props = networkfirewall_mixins.CfnFirewallFlowLogsLogGroupProps(
                output_format=networkfirewall_mixins.CfnFirewallFlowLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6b6246aca6aede41fd5e27b60a15f2247ee1bc0b469a4ba70c98d369ffd598e5)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnFirewallFlowLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallFlowLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallFlowLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnFirewallFlowLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallFlowLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnFirewallFlowLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
        
        cfn_firewall_flow_logs_output_format = networkfirewall_mixins.CfnFirewallFlowLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallFlowLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallFlowLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallFlowLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallFlowLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnFirewallFlowLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnFirewallFlowLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_firewall_flow_logs_s3_props = networkfirewall_mixins.CfnFirewallFlowLogsS3Props(
                encryption_key=key_ref,
                output_format=networkfirewall_mixins.CfnFirewallFlowLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bbbaa9714a42da4cd087d3ee29e1f5be2988e59483bd406552c6f013c4e23afb)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnFirewallFlowLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallFlowLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallFlowLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnFirewallLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallLogsMixin",
):
    '''Use the firewall to provide stateful, managed, network firewall and intrusion detection and prevention filtering for your VPCs in Amazon VPC .

    The firewall defines the configuration settings for an AWS Network Firewall firewall. The settings include the firewall policy, the subnets in your VPC to use for the firewall endpoints, and any tags that are attached to the firewall AWS resource.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-networkfirewall-firewall.html
    :cloudformationResource: AWS::NetworkFirewall::Firewall
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_firewall_logs_mixin = networkfirewall_mixins.CfnFirewallLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::NetworkFirewall::Firewall``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7849a0cb6670c4dec2ef0ae2b87258f087ebacd9f96978d6c1d6aa4fe089ec82)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__94742363755f8294f26cd606249ac9ba39736c6e737d707ea5c50a34d4ab9a70)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c49fe0c9d241623950091a3176bc672dd3ed72f003894ef6b14ad3a17df03ae5)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ALERT_LOGS")
    def ALERT_LOGS(cls) -> "CfnFirewallAlertLogs":
        return typing.cast("CfnFirewallAlertLogs", jsii.sget(cls, "ALERT_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="FLOW_LOGS")
    def FLOW_LOGS(cls) -> "CfnFirewallFlowLogs":
        return typing.cast("CfnFirewallFlowLogs", jsii.sget(cls, "FLOW_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TLS_LOGS")
    def TLS_LOGS(cls) -> "CfnFirewallTlsLogs":
        return typing.cast("CfnFirewallTlsLogs", jsii.sget(cls, "TLS_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnFirewallTlsLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallTlsLogs",
):
    '''Builder for CfnFirewallLogsMixin to generate TLS_LOGS for CfnFirewall.

    :cloudformationResource: AWS::NetworkFirewall::Firewall
    :logType: TLS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
        
        cfn_firewall_tls_logs = networkfirewall_mixins.CfnFirewallTlsLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnFirewallLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__559cc15b2725b3b5c5836a90d9ac535ad5b25fc5fc6d932e38b721487837ac01)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnFirewallTlsLogsOutputFormat.Firehose"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a082025e0f2623f1ac880cf67bb1925c5a1542f565f8340d4e62ccebee53575)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnFirewallTlsLogsFirehoseProps(output_format=output_format)

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnFirewallTlsLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e217b2015025276aebd37e7b6f40a7f50f1a44304dfbb4b57f8ab0f515a5da20)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnFirewallTlsLogsLogGroupProps(output_format=output_format)

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnFirewallTlsLogsOutputFormat.S3"] = None,
    ) -> "CfnFirewallLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92e9e0f4001a2d2095af2ca2822a04c06e661dbb403fc7b4b6edb3314f2d735b)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnFirewallTlsLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnFirewallLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallTlsLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnFirewallTlsLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnFirewallTlsLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            
            cfn_firewall_tls_logs_firehose_props = networkfirewall_mixins.CfnFirewallTlsLogsFirehoseProps(
                output_format=networkfirewall_mixins.CfnFirewallTlsLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__224a59ab80364554b855aedec24dcb265cc49a1aa472051944f289d241560719)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnFirewallTlsLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallTlsLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallTlsLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallTlsLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnFirewallTlsLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnFirewallTlsLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            
            cfn_firewall_tls_logs_log_group_props = networkfirewall_mixins.CfnFirewallTlsLogsLogGroupProps(
                output_format=networkfirewall_mixins.CfnFirewallTlsLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6354519ac80eb3448c4234bb859f67cdfbf04268ce6368bb15a810412c8d5aab)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnFirewallTlsLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallTlsLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallTlsLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnFirewallTlsLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallTlsLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnFirewallTlsLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
        
        cfn_firewall_tls_logs_output_format = networkfirewall_mixins.CfnFirewallTlsLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallTlsLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallTlsLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallTlsLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.mixins.CfnFirewallTlsLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnFirewallTlsLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnFirewallTlsLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_networkfirewall import mixins as networkfirewall_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_firewall_tls_logs_s3_props = networkfirewall_mixins.CfnFirewallTlsLogsS3Props(
                encryption_key=key_ref,
                output_format=networkfirewall_mixins.CfnFirewallTlsLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__758373e1521ee923d5f87247b5e4668984a7a6a5d02caad44ac8e4ef44ad0c60)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnFirewallTlsLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFirewallTlsLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFirewallTlsLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnFirewallAlertLogs",
    "CfnFirewallAlertLogsFirehoseProps",
    "CfnFirewallAlertLogsLogGroupProps",
    "CfnFirewallAlertLogsOutputFormat",
    "CfnFirewallAlertLogsS3Props",
    "CfnFirewallFlowLogs",
    "CfnFirewallFlowLogsFirehoseProps",
    "CfnFirewallFlowLogsLogGroupProps",
    "CfnFirewallFlowLogsOutputFormat",
    "CfnFirewallFlowLogsS3Props",
    "CfnFirewallLogsMixin",
    "CfnFirewallTlsLogs",
    "CfnFirewallTlsLogsFirehoseProps",
    "CfnFirewallTlsLogsLogGroupProps",
    "CfnFirewallTlsLogsOutputFormat",
    "CfnFirewallTlsLogsS3Props",
]

publication.publish()

def _typecheckingstub__14ff14e0ce201229dd4e6a8d4b1e5fac6f124ab4e4e3e13a079d615dcc610666(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7328590b513805553dee64080b0a79efac3e8f24960e08b3147e3e1c0cd77569(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnFirewallAlertLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e67a490929fffe050d352d6197630e45bb231048c2061069a1de90a533030013(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnFirewallAlertLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0f141909d9744c277aa229bebcd21ccdf011d035acd18dda3281db79ce95441e(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnFirewallAlertLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08130940b97c3fef96e5fc9802346c415c2a91a2bee6e3673caeeb5d938a6a41(
    *,
    output_format: typing.Optional[CfnFirewallAlertLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d55d8e7e480062b81d50329ddc5b4f07e2b7b6b6523ae5388814d2c0105b0832(
    *,
    output_format: typing.Optional[CfnFirewallAlertLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d681e06a4da17744f148c95f6566b81107ccc792af01e57aa3360f33fe24192(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnFirewallAlertLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6224300f27ca81da20cc7a309754d5a64291392effa5a2914ce8c80ae4048ee(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d0c1095f2366a9586eb3f395a32504aad3308ecf9172d6fa5ad6412e69e1c70(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnFirewallFlowLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd71c0b1f1d27a1812b9d05a137e96a538baa825c4553a6e08482e6090df99d3(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnFirewallFlowLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4a3f58fb66ed021923fb17d2ddd81fb144af311cbc8109de9a34dcc4a9f7445(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnFirewallFlowLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62d5ab785ed1e6afd3292c79fa1cdd5daa5dbf1d23111acec435fec3c7f3ff73(
    *,
    output_format: typing.Optional[CfnFirewallFlowLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b6246aca6aede41fd5e27b60a15f2247ee1bc0b469a4ba70c98d369ffd598e5(
    *,
    output_format: typing.Optional[CfnFirewallFlowLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bbbaa9714a42da4cd087d3ee29e1f5be2988e59483bd406552c6f013c4e23afb(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnFirewallFlowLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7849a0cb6670c4dec2ef0ae2b87258f087ebacd9f96978d6c1d6aa4fe089ec82(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94742363755f8294f26cd606249ac9ba39736c6e737d707ea5c50a34d4ab9a70(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c49fe0c9d241623950091a3176bc672dd3ed72f003894ef6b14ad3a17df03ae5(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__559cc15b2725b3b5c5836a90d9ac535ad5b25fc5fc6d932e38b721487837ac01(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a082025e0f2623f1ac880cf67bb1925c5a1542f565f8340d4e62ccebee53575(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnFirewallTlsLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e217b2015025276aebd37e7b6f40a7f50f1a44304dfbb4b57f8ab0f515a5da20(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnFirewallTlsLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92e9e0f4001a2d2095af2ca2822a04c06e661dbb403fc7b4b6edb3314f2d735b(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnFirewallTlsLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__224a59ab80364554b855aedec24dcb265cc49a1aa472051944f289d241560719(
    *,
    output_format: typing.Optional[CfnFirewallTlsLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6354519ac80eb3448c4234bb859f67cdfbf04268ce6368bb15a810412c8d5aab(
    *,
    output_format: typing.Optional[CfnFirewallTlsLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__758373e1521ee923d5f87247b5e4668984a7a6a5d02caad44ac8e4ef44ad0c60(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnFirewallTlsLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass
