from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class FirewallAttachmentStatusChanged(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallAttachmentStatusChanged",
):
    '''(experimental) EventBridge event pattern for aws.networkfirewall@FirewallAttachmentStatusChanged.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
        
        firewall_attachment_status_changed = networkfirewall_events.FirewallAttachmentStatusChanged()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="firewallAttachmentStatusChangedPattern")
    @builtins.classmethod
    def firewall_attachment_status_changed_pattern(
        cls,
        *,
        data: typing.Optional[typing.Sequence[typing.Union["FirewallAttachmentStatusChanged.DataItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        metadata: typing.Optional[typing.Union["FirewallAttachmentStatusChanged.Metadata", typing.Dict[builtins.str, typing.Any]]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Firewall Attachment Status Changed.

        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param metadata: (experimental) metadata property. Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = FirewallAttachmentStatusChanged.FirewallAttachmentStatusChangedProps(
            data=data,
            event_metadata=event_metadata,
            metadata=metadata,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "firewallAttachmentStatusChangedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallAttachmentStatusChanged.DataItem",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "current_attachment_status": "currentAttachmentStatus",
            "endpoint_id": "endpointId",
            "previous_attachment_status": "previousAttachmentStatus",
        },
    )
    class DataItem:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            current_attachment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_attachment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DataItem.

            :param availability_zone: (experimental) Availability Zone property. Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_attachment_status: (experimental) Current Attachment Status property. Specify an array of string values to match this event if the actual value of Current Attachment Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_id: (experimental) Endpoint ID property. Specify an array of string values to match this event if the actual value of Endpoint ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_attachment_status: (experimental) Previous Attachment Status property. Specify an array of string values to match this event if the actual value of Previous Attachment Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                data_item = networkfirewall_events.FirewallAttachmentStatusChanged.DataItem(
                    availability_zone=["availabilityZone"],
                    current_attachment_status=["currentAttachmentStatus"],
                    endpoint_id=["endpointId"],
                    previous_attachment_status=["previousAttachmentStatus"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5e11a5736844fe01eb8b2a72c8f3fe38367ce233d7dd46fbe3c9f5719fcd84ae)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument current_attachment_status", value=current_attachment_status, expected_type=type_hints["current_attachment_status"])
                check_type(argname="argument endpoint_id", value=endpoint_id, expected_type=type_hints["endpoint_id"])
                check_type(argname="argument previous_attachment_status", value=previous_attachment_status, expected_type=type_hints["previous_attachment_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if current_attachment_status is not None:
                self._values["current_attachment_status"] = current_attachment_status
            if endpoint_id is not None:
                self._values["endpoint_id"] = endpoint_id
            if previous_attachment_status is not None:
                self._values["previous_attachment_status"] = previous_attachment_status

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Availability Zone property.

            Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def current_attachment_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Current Attachment Status property.

            Specify an array of string values to match this event if the actual value of Current Attachment Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_attachment_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Endpoint ID property.

            Specify an array of string values to match this event if the actual value of Endpoint ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_attachment_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Previous Attachment Status property.

            Specify an array of string values to match this event if the actual value of Previous Attachment Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_attachment_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallAttachmentStatusChanged.FirewallAttachmentStatusChangedProps",
        jsii_struct_bases=[],
        name_mapping={
            "data": "data",
            "event_metadata": "eventMetadata",
            "metadata": "metadata",
            "version": "version",
        },
    )
    class FirewallAttachmentStatusChangedProps:
        def __init__(
            self,
            *,
            data: typing.Optional[typing.Sequence[typing.Union["FirewallAttachmentStatusChanged.DataItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            metadata: typing.Optional[typing.Union["FirewallAttachmentStatusChanged.Metadata", typing.Dict[builtins.str, typing.Any]]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.networkfirewall@FirewallAttachmentStatusChanged event.

            :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param metadata: (experimental) metadata property. Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                firewall_attachment_status_changed_props = networkfirewall_events.FirewallAttachmentStatusChanged.FirewallAttachmentStatusChangedProps(
                    data=[networkfirewall_events.FirewallAttachmentStatusChanged.DataItem(
                        availability_zone=["availabilityZone"],
                        current_attachment_status=["currentAttachmentStatus"],
                        endpoint_id=["endpointId"],
                        previous_attachment_status=["previousAttachmentStatus"]
                    )],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    metadata=networkfirewall_events.FirewallAttachmentStatusChanged.Metadata(
                        state_change_id=["stateChangeId"]
                    ),
                    version=["version"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(metadata, dict):
                metadata = FirewallAttachmentStatusChanged.Metadata(**metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__578af99f25b8a66782c66396a62292cd0f407ddc1f8c3f6292a2227dc6015abe)
                check_type(argname="argument data", value=data, expected_type=type_hints["data"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data is not None:
                self._values["data"] = data
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if metadata is not None:
                self._values["metadata"] = metadata
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def data(
            self,
        ) -> typing.Optional[typing.List["FirewallAttachmentStatusChanged.DataItem"]]:
            '''(experimental) data property.

            Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data")
            return typing.cast(typing.Optional[typing.List["FirewallAttachmentStatusChanged.DataItem"]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def metadata(
            self,
        ) -> typing.Optional["FirewallAttachmentStatusChanged.Metadata"]:
            '''(experimental) metadata property.

            Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metadata")
            return typing.cast(typing.Optional["FirewallAttachmentStatusChanged.Metadata"], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FirewallAttachmentStatusChangedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallAttachmentStatusChanged.Metadata",
        jsii_struct_bases=[],
        name_mapping={"state_change_id": "stateChangeId"},
    )
    class Metadata:
        def __init__(
            self,
            *,
            state_change_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Metadata.

            :param state_change_id: (experimental) State Change ID property. Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                metadata = networkfirewall_events.FirewallAttachmentStatusChanged.Metadata(
                    state_change_id=["stateChangeId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__92042ac9916da7a22c636b2bbb508e13f84880b34e67426736478d8efc6df5ad)
                check_type(argname="argument state_change_id", value=state_change_id, expected_type=type_hints["state_change_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if state_change_id is not None:
                self._values["state_change_id"] = state_change_id

        @builtins.property
        def state_change_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) State Change ID property.

            Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state_change_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Metadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class FirewallConfigurationChanged(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallConfigurationChanged",
):
    '''(experimental) EventBridge event pattern for aws.networkfirewall@FirewallConfigurationChanged.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
        
        firewall_configuration_changed = networkfirewall_events.FirewallConfigurationChanged()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="firewallConfigurationChangedPattern")
    @builtins.classmethod
    def firewall_configuration_changed_pattern(
        cls,
        *,
        data: typing.Optional[typing.Sequence[typing.Union["FirewallConfigurationChanged.DataItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        metadata: typing.Optional[typing.Union["FirewallConfigurationChanged.Metadata", typing.Dict[builtins.str, typing.Any]]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Firewall Configuration Changed.

        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param metadata: (experimental) metadata property. Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = FirewallConfigurationChanged.FirewallConfigurationChangedProps(
            data=data,
            event_metadata=event_metadata,
            metadata=metadata,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "firewallConfigurationChangedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallConfigurationChanged.DataItem",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "configuration_resource_arn": "configurationResourceArn",
            "current_configuration_sync_status": "currentConfigurationSyncStatus",
            "current_configuration_update_token": "currentConfigurationUpdateToken",
            "previous_configuration_sync_status": "previousConfigurationSyncStatus",
            "previous_configuration_update_token": "previousConfigurationUpdateToken",
        },
    )
    class DataItem:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            configuration_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            current_configuration_sync_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            current_configuration_update_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_configuration_sync_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_configuration_update_token: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DataItem.

            :param availability_zone: (experimental) Availability Zone property. Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param configuration_resource_arn: (experimental) Configuration Resource ARN property. Specify an array of string values to match this event if the actual value of Configuration Resource ARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_configuration_sync_status: (experimental) Current Configuration Sync Status property. Specify an array of string values to match this event if the actual value of Current Configuration Sync Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_configuration_update_token: (experimental) Current Configuration Update Token property. Specify an array of string values to match this event if the actual value of Current Configuration Update Token is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_configuration_sync_status: (experimental) Previous Configuration Sync Status property. Specify an array of string values to match this event if the actual value of Previous Configuration Sync Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_configuration_update_token: (experimental) Previous Configuration Update Token property. Specify an array of string values to match this event if the actual value of Previous Configuration Update Token is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                data_item = networkfirewall_events.FirewallConfigurationChanged.DataItem(
                    availability_zone=["availabilityZone"],
                    configuration_resource_arn=["configurationResourceArn"],
                    current_configuration_sync_status=["currentConfigurationSyncStatus"],
                    current_configuration_update_token=["currentConfigurationUpdateToken"],
                    previous_configuration_sync_status=["previousConfigurationSyncStatus"],
                    previous_configuration_update_token=["previousConfigurationUpdateToken"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__79ac7f53de8e51cb9b50c67badea6e58731739141066c744ed1ea4d64eb32d79)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument configuration_resource_arn", value=configuration_resource_arn, expected_type=type_hints["configuration_resource_arn"])
                check_type(argname="argument current_configuration_sync_status", value=current_configuration_sync_status, expected_type=type_hints["current_configuration_sync_status"])
                check_type(argname="argument current_configuration_update_token", value=current_configuration_update_token, expected_type=type_hints["current_configuration_update_token"])
                check_type(argname="argument previous_configuration_sync_status", value=previous_configuration_sync_status, expected_type=type_hints["previous_configuration_sync_status"])
                check_type(argname="argument previous_configuration_update_token", value=previous_configuration_update_token, expected_type=type_hints["previous_configuration_update_token"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if configuration_resource_arn is not None:
                self._values["configuration_resource_arn"] = configuration_resource_arn
            if current_configuration_sync_status is not None:
                self._values["current_configuration_sync_status"] = current_configuration_sync_status
            if current_configuration_update_token is not None:
                self._values["current_configuration_update_token"] = current_configuration_update_token
            if previous_configuration_sync_status is not None:
                self._values["previous_configuration_sync_status"] = previous_configuration_sync_status
            if previous_configuration_update_token is not None:
                self._values["previous_configuration_update_token"] = previous_configuration_update_token

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Availability Zone property.

            Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def configuration_resource_arn(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Configuration Resource ARN property.

            Specify an array of string values to match this event if the actual value of Configuration Resource ARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("configuration_resource_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def current_configuration_sync_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Current Configuration Sync Status property.

            Specify an array of string values to match this event if the actual value of Current Configuration Sync Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_configuration_sync_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def current_configuration_update_token(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Current Configuration Update Token property.

            Specify an array of string values to match this event if the actual value of Current Configuration Update Token is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_configuration_update_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_configuration_sync_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Previous Configuration Sync Status property.

            Specify an array of string values to match this event if the actual value of Previous Configuration Sync Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_configuration_sync_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_configuration_update_token(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Previous Configuration Update Token property.

            Specify an array of string values to match this event if the actual value of Previous Configuration Update Token is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_configuration_update_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallConfigurationChanged.FirewallConfigurationChangedProps",
        jsii_struct_bases=[],
        name_mapping={
            "data": "data",
            "event_metadata": "eventMetadata",
            "metadata": "metadata",
            "version": "version",
        },
    )
    class FirewallConfigurationChangedProps:
        def __init__(
            self,
            *,
            data: typing.Optional[typing.Sequence[typing.Union["FirewallConfigurationChanged.DataItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            metadata: typing.Optional[typing.Union["FirewallConfigurationChanged.Metadata", typing.Dict[builtins.str, typing.Any]]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.networkfirewall@FirewallConfigurationChanged event.

            :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param metadata: (experimental) metadata property. Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                firewall_configuration_changed_props = networkfirewall_events.FirewallConfigurationChanged.FirewallConfigurationChangedProps(
                    data=[networkfirewall_events.FirewallConfigurationChanged.DataItem(
                        availability_zone=["availabilityZone"],
                        configuration_resource_arn=["configurationResourceArn"],
                        current_configuration_sync_status=["currentConfigurationSyncStatus"],
                        current_configuration_update_token=["currentConfigurationUpdateToken"],
                        previous_configuration_sync_status=["previousConfigurationSyncStatus"],
                        previous_configuration_update_token=["previousConfigurationUpdateToken"]
                    )],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    metadata=networkfirewall_events.FirewallConfigurationChanged.Metadata(
                        state_change_id=["stateChangeId"]
                    ),
                    version=["version"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(metadata, dict):
                metadata = FirewallConfigurationChanged.Metadata(**metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__55bcfa41e38cab673fff1613b40aa31196f86ce42dad25e58d8bc9803876c717)
                check_type(argname="argument data", value=data, expected_type=type_hints["data"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data is not None:
                self._values["data"] = data
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if metadata is not None:
                self._values["metadata"] = metadata
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def data(
            self,
        ) -> typing.Optional[typing.List["FirewallConfigurationChanged.DataItem"]]:
            '''(experimental) data property.

            Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data")
            return typing.cast(typing.Optional[typing.List["FirewallConfigurationChanged.DataItem"]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def metadata(self) -> typing.Optional["FirewallConfigurationChanged.Metadata"]:
            '''(experimental) metadata property.

            Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metadata")
            return typing.cast(typing.Optional["FirewallConfigurationChanged.Metadata"], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FirewallConfigurationChangedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallConfigurationChanged.Metadata",
        jsii_struct_bases=[],
        name_mapping={"state_change_id": "stateChangeId"},
    )
    class Metadata:
        def __init__(
            self,
            *,
            state_change_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Metadata.

            :param state_change_id: (experimental) State Change ID property. Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                metadata = networkfirewall_events.FirewallConfigurationChanged.Metadata(
                    state_change_id=["stateChangeId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f98a3b39ba314b19b43c0a96feac42043c8fff93b2ed0a151e9f1a618e4a63c3)
                check_type(argname="argument state_change_id", value=state_change_id, expected_type=type_hints["state_change_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if state_change_id is not None:
                self._values["state_change_id"] = state_change_id

        @builtins.property
        def state_change_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) State Change ID property.

            Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state_change_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Metadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class FirewallTransitGatewayAttachmentStatusChanged(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallTransitGatewayAttachmentStatusChanged",
):
    '''(experimental) EventBridge event pattern for aws.networkfirewall@FirewallTransitGatewayAttachmentStatusChanged.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
        
        firewall_transit_gateway_attachment_status_changed = networkfirewall_events.FirewallTransitGatewayAttachmentStatusChanged()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="firewallTransitGatewayAttachmentStatusChangedPattern")
    @builtins.classmethod
    def firewall_transit_gateway_attachment_status_changed_pattern(
        cls,
        *,
        data: typing.Optional[typing.Union["FirewallTransitGatewayAttachmentStatusChanged.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        metadata: typing.Optional[typing.Union["FirewallTransitGatewayAttachmentStatusChanged.Metadata", typing.Dict[builtins.str, typing.Any]]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Firewall Transit Gateway Attachment Status Changed.

        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param metadata: (experimental) metadata property. Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = FirewallTransitGatewayAttachmentStatusChanged.FirewallTransitGatewayAttachmentStatusChangedProps(
            data=data,
            event_metadata=event_metadata,
            metadata=metadata,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "firewallTransitGatewayAttachmentStatusChangedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallTransitGatewayAttachmentStatusChanged.Data",
        jsii_struct_bases=[],
        name_mapping={
            "attachment_id": "attachmentId",
            "current_transit_gateway_attachment_status": "currentTransitGatewayAttachmentStatus",
            "previous_transit_gateway_attachment_status": "previousTransitGatewayAttachmentStatus",
        },
    )
    class Data:
        def __init__(
            self,
            *,
            attachment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            current_transit_gateway_attachment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_transit_gateway_attachment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Data.

            :param attachment_id: (experimental) Attachment ID property. Specify an array of string values to match this event if the actual value of Attachment ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_transit_gateway_attachment_status: (experimental) Current Transit Gateway Attachment Status property. Specify an array of string values to match this event if the actual value of Current Transit Gateway Attachment Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_transit_gateway_attachment_status: (experimental) Previous Transit Gateway Attachment Status property. Specify an array of string values to match this event if the actual value of Previous Transit Gateway Attachment Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                data = networkfirewall_events.FirewallTransitGatewayAttachmentStatusChanged.Data(
                    attachment_id=["attachmentId"],
                    current_transit_gateway_attachment_status=["currentTransitGatewayAttachmentStatus"],
                    previous_transit_gateway_attachment_status=["previousTransitGatewayAttachmentStatus"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ebeef1af83ab89311ccd455733be7dc1c6051156c804f7d28eabe592e0c50965)
                check_type(argname="argument attachment_id", value=attachment_id, expected_type=type_hints["attachment_id"])
                check_type(argname="argument current_transit_gateway_attachment_status", value=current_transit_gateway_attachment_status, expected_type=type_hints["current_transit_gateway_attachment_status"])
                check_type(argname="argument previous_transit_gateway_attachment_status", value=previous_transit_gateway_attachment_status, expected_type=type_hints["previous_transit_gateway_attachment_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attachment_id is not None:
                self._values["attachment_id"] = attachment_id
            if current_transit_gateway_attachment_status is not None:
                self._values["current_transit_gateway_attachment_status"] = current_transit_gateway_attachment_status
            if previous_transit_gateway_attachment_status is not None:
                self._values["previous_transit_gateway_attachment_status"] = previous_transit_gateway_attachment_status

        @builtins.property
        def attachment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Attachment ID property.

            Specify an array of string values to match this event if the actual value of Attachment ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attachment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def current_transit_gateway_attachment_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Current Transit Gateway Attachment Status property.

            Specify an array of string values to match this event if the actual value of Current Transit Gateway Attachment Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_transit_gateway_attachment_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_transit_gateway_attachment_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Previous Transit Gateway Attachment Status property.

            Specify an array of string values to match this event if the actual value of Previous Transit Gateway Attachment Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_transit_gateway_attachment_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Data(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallTransitGatewayAttachmentStatusChanged.FirewallTransitGatewayAttachmentStatusChangedProps",
        jsii_struct_bases=[],
        name_mapping={
            "data": "data",
            "event_metadata": "eventMetadata",
            "metadata": "metadata",
            "version": "version",
        },
    )
    class FirewallTransitGatewayAttachmentStatusChangedProps:
        def __init__(
            self,
            *,
            data: typing.Optional[typing.Union["FirewallTransitGatewayAttachmentStatusChanged.Data", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            metadata: typing.Optional[typing.Union["FirewallTransitGatewayAttachmentStatusChanged.Metadata", typing.Dict[builtins.str, typing.Any]]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.networkfirewall@FirewallTransitGatewayAttachmentStatusChanged event.

            :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param metadata: (experimental) metadata property. Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                firewall_transit_gateway_attachment_status_changed_props = networkfirewall_events.FirewallTransitGatewayAttachmentStatusChanged.FirewallTransitGatewayAttachmentStatusChangedProps(
                    data=networkfirewall_events.FirewallTransitGatewayAttachmentStatusChanged.Data(
                        attachment_id=["attachmentId"],
                        current_transit_gateway_attachment_status=["currentTransitGatewayAttachmentStatus"],
                        previous_transit_gateway_attachment_status=["previousTransitGatewayAttachmentStatus"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    metadata=networkfirewall_events.FirewallTransitGatewayAttachmentStatusChanged.Metadata(
                        state_change_id=["stateChangeId"]
                    ),
                    version=["version"]
                )
            '''
            if isinstance(data, dict):
                data = FirewallTransitGatewayAttachmentStatusChanged.Data(**data)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(metadata, dict):
                metadata = FirewallTransitGatewayAttachmentStatusChanged.Metadata(**metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c1160d1bf93c49f7dd17316f26f9cf02513f76f3a3ac7f0645cd42bf527006eb)
                check_type(argname="argument data", value=data, expected_type=type_hints["data"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data is not None:
                self._values["data"] = data
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if metadata is not None:
                self._values["metadata"] = metadata
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def data(
            self,
        ) -> typing.Optional["FirewallTransitGatewayAttachmentStatusChanged.Data"]:
            '''(experimental) data property.

            Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data")
            return typing.cast(typing.Optional["FirewallTransitGatewayAttachmentStatusChanged.Data"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def metadata(
            self,
        ) -> typing.Optional["FirewallTransitGatewayAttachmentStatusChanged.Metadata"]:
            '''(experimental) metadata property.

            Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metadata")
            return typing.cast(typing.Optional["FirewallTransitGatewayAttachmentStatusChanged.Metadata"], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FirewallTransitGatewayAttachmentStatusChangedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_networkfirewall.events.FirewallTransitGatewayAttachmentStatusChanged.Metadata",
        jsii_struct_bases=[],
        name_mapping={"state_change_id": "stateChangeId"},
    )
    class Metadata:
        def __init__(
            self,
            *,
            state_change_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Metadata.

            :param state_change_id: (experimental) State Change ID property. Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_networkfirewall import events as networkfirewall_events
                
                metadata = networkfirewall_events.FirewallTransitGatewayAttachmentStatusChanged.Metadata(
                    state_change_id=["stateChangeId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d02952a8c742d03a8393db8b702ba4f909ac85969065710f7eb0603b4979de5e)
                check_type(argname="argument state_change_id", value=state_change_id, expected_type=type_hints["state_change_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if state_change_id is not None:
                self._values["state_change_id"] = state_change_id

        @builtins.property
        def state_change_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) State Change ID property.

            Specify an array of string values to match this event if the actual value of State Change ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state_change_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Metadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "FirewallAttachmentStatusChanged",
    "FirewallConfigurationChanged",
    "FirewallTransitGatewayAttachmentStatusChanged",
]

publication.publish()

def _typecheckingstub__5e11a5736844fe01eb8b2a72c8f3fe38367ce233d7dd46fbe3c9f5719fcd84ae(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    current_attachment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_attachment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__578af99f25b8a66782c66396a62292cd0f407ddc1f8c3f6292a2227dc6015abe(
    *,
    data: typing.Optional[typing.Sequence[typing.Union[FirewallAttachmentStatusChanged.DataItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    metadata: typing.Optional[typing.Union[FirewallAttachmentStatusChanged.Metadata, typing.Dict[builtins.str, typing.Any]]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92042ac9916da7a22c636b2bbb508e13f84880b34e67426736478d8efc6df5ad(
    *,
    state_change_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79ac7f53de8e51cb9b50c67badea6e58731739141066c744ed1ea4d64eb32d79(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    configuration_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    current_configuration_sync_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    current_configuration_update_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_configuration_sync_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_configuration_update_token: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55bcfa41e38cab673fff1613b40aa31196f86ce42dad25e58d8bc9803876c717(
    *,
    data: typing.Optional[typing.Sequence[typing.Union[FirewallConfigurationChanged.DataItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    metadata: typing.Optional[typing.Union[FirewallConfigurationChanged.Metadata, typing.Dict[builtins.str, typing.Any]]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f98a3b39ba314b19b43c0a96feac42043c8fff93b2ed0a151e9f1a618e4a63c3(
    *,
    state_change_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebeef1af83ab89311ccd455733be7dc1c6051156c804f7d28eabe592e0c50965(
    *,
    attachment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    current_transit_gateway_attachment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_transit_gateway_attachment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c1160d1bf93c49f7dd17316f26f9cf02513f76f3a3ac7f0645cd42bf527006eb(
    *,
    data: typing.Optional[typing.Union[FirewallTransitGatewayAttachmentStatusChanged.Data, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    metadata: typing.Optional[typing.Union[FirewallTransitGatewayAttachmentStatusChanged.Metadata, typing.Dict[builtins.str, typing.Any]]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d02952a8c742d03a8393db8b702ba4f909ac85969065710f7eb0603b4979de5e(
    *,
    state_change_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
