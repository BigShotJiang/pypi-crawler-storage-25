from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnConnectorApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorApplicationLogs",
):
    '''Builder for CfnConnectorLogsMixin to generate APPLICATION_LOGS for CfnConnector.

    :cloudformationResource: AWS::KafkaConnect::Connector
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_kafkaconnect import mixins as kafkaconnect_mixins
        
        cfn_connector_application_logs = kafkaconnect_mixins.CfnConnectorApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnConnectorLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d48104dc256fb1a62ec702b4dc94edcb8d63a8fde27b266c6bc584712e118006)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnConnectorLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnConnectorApplicationLogsOutputFormat.Firehose"] = None,
    ) -> "CfnConnectorLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5e4e82d00e8301d3ca95decc4dded0c5975c7f6b31b31f09f521b5b4e2eccd7)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnConnectorApplicationLogsFirehoseProps(output_format=output_format)

        return typing.cast("CfnConnectorLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnConnectorApplicationLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnConnectorLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dea00e308f20b1d345663f6346b2c150fc0ee139d5065cbddd74f907a232d830)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnConnectorApplicationLogsLogGroupProps(output_format=output_format)

        return typing.cast("CfnConnectorLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnConnectorApplicationLogsOutputFormat.S3"] = None,
    ) -> "CfnConnectorLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96eeff00252c5f772cc28636f230c21e2cf6b7111885f5392d9a6ca8d951f333)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnConnectorApplicationLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnConnectorLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnConnectorApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnConnectorApplicationLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_kafkaconnect import mixins as kafkaconnect_mixins
            
            cfn_connector_application_logs_firehose_props = kafkaconnect_mixins.CfnConnectorApplicationLogsFirehoseProps(
                output_format=kafkaconnect_mixins.CfnConnectorApplicationLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__11a6b3928f1adc0cad2545aaafe22eaf102220ffc466068fef69c8ad89031bc2)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnConnectorApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnConnectorApplicationLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnConnectorApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnConnectorApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnConnectorApplicationLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_kafkaconnect import mixins as kafkaconnect_mixins
            
            cfn_connector_application_logs_log_group_props = kafkaconnect_mixins.CfnConnectorApplicationLogsLogGroupProps(
                output_format=kafkaconnect_mixins.CfnConnectorApplicationLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88b7656b5b4c33309c947cf73f2ad508568b1f9f1fa16aba4091be1d0ff752c3)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnConnectorApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnConnectorApplicationLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnConnectorApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnConnectorApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnConnectorApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_kafkaconnect import mixins as kafkaconnect_mixins
        
        cfn_connector_application_logs_output_format = kafkaconnect_mixins.CfnConnectorApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnConnectorApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnConnectorApplicationLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_kafkaconnect import mixins as kafkaconnect_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_connector_application_logs_s3_props = kafkaconnect_mixins.CfnConnectorApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=kafkaconnect_mixins.CfnConnectorApplicationLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a32a5e1b3f50d356feb5e79c7c561e156a4f874fa75bb5758628caeac3390fdd)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnConnectorApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnConnectorApplicationLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnConnectorApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnConnectorLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_kafkaconnect.mixins.CfnConnectorLogsMixin",
):
    '''Creates a connector using the specified properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-kafkaconnect-connector.html
    :cloudformationResource: AWS::KafkaConnect::Connector
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_kafkaconnect import mixins as kafkaconnect_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_connector_logs_mixin = kafkaconnect_mixins.CfnConnectorLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::KafkaConnect::Connector``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a48ba35271ed994e6d2f5db7f6ed3269b0a022b2895ce2ff8c792cf51e98b9f4)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5d27e4c612d1070bd185c899761853ac7c86e82596e57df636eb4ccbf81c47b5)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aaa68bdbe447c322f7f47d6ba3c125eadd960f21921a5fd5bda3db78c201b499)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnConnectorApplicationLogs":
        return typing.cast("CfnConnectorApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnConnectorApplicationLogs",
    "CfnConnectorApplicationLogsFirehoseProps",
    "CfnConnectorApplicationLogsLogGroupProps",
    "CfnConnectorApplicationLogsOutputFormat",
    "CfnConnectorApplicationLogsS3Props",
    "CfnConnectorLogsMixin",
]

publication.publish()

def _typecheckingstub__d48104dc256fb1a62ec702b4dc94edcb8d63a8fde27b266c6bc584712e118006(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5e4e82d00e8301d3ca95decc4dded0c5975c7f6b31b31f09f521b5b4e2eccd7(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnConnectorApplicationLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dea00e308f20b1d345663f6346b2c150fc0ee139d5065cbddd74f907a232d830(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnConnectorApplicationLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96eeff00252c5f772cc28636f230c21e2cf6b7111885f5392d9a6ca8d951f333(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnConnectorApplicationLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__11a6b3928f1adc0cad2545aaafe22eaf102220ffc466068fef69c8ad89031bc2(
    *,
    output_format: typing.Optional[CfnConnectorApplicationLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88b7656b5b4c33309c947cf73f2ad508568b1f9f1fa16aba4091be1d0ff752c3(
    *,
    output_format: typing.Optional[CfnConnectorApplicationLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a32a5e1b3f50d356feb5e79c7c561e156a4f874fa75bb5758628caeac3390fdd(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnConnectorApplicationLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a48ba35271ed994e6d2f5db7f6ed3269b0a022b2895ce2ff8c792cf51e98b9f4(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d27e4c612d1070bd185c899761853ac7c86e82596e57df636eb4ccbf81c47b5(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aaa68bdbe447c322f7f47d6ba3c125eadd960f21921a5fd5bda3db78c201b499(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
