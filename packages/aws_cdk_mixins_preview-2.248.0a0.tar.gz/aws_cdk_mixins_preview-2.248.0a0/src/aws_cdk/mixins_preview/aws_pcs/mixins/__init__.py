from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnClusterLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterLogsMixin",
):
    '''Creates an AWS PCS cluster resource.

    For more information, see `Creating a cluster in Parallel Computing Service <https://docs.aws.amazon.com/pcs/latest/userguide/working-with_clusters_create.html>`_ in the *AWS PCS User Guide* .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-pcs-cluster.html
    :cloudformationResource: AWS::PCS::Cluster
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_cluster_logs_mixin = pcs_mixins.CfnClusterLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::PCS::Cluster``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__895989435c64ce6ac8ba60f4839b019a11c9756f2dddd9df13d89ee185120eaf)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62ba0f970aaa3a35b0eea8e1d967c5d7b947370f9db7a78ac98b9a262357c37a)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e24685fe192db49a38fd71bcc95b607b3b231591f3ce0acb13d01583294d02ed)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PCS_JOBCOMP_LOGS")
    def PCS_JOBCOMP_LOGS(cls) -> "CfnClusterPcsJobcompLogs":
        return typing.cast("CfnClusterPcsJobcompLogs", jsii.sget(cls, "PCS_JOBCOMP_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PCS_SCHEDULER_AUDIT_LOGS")
    def PCS_SCHEDULER_AUDIT_LOGS(cls) -> "CfnClusterPcsSchedulerAuditLogs":
        return typing.cast("CfnClusterPcsSchedulerAuditLogs", jsii.sget(cls, "PCS_SCHEDULER_AUDIT_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PCS_SCHEDULER_LOGS")
    def PCS_SCHEDULER_LOGS(cls) -> "CfnClusterPcsSchedulerLogs":
        return typing.cast("CfnClusterPcsSchedulerLogs", jsii.sget(cls, "PCS_SCHEDULER_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnClusterPcsJobcompLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogs",
):
    '''Builder for CfnClusterLogsMixin to generate PCS_JOBCOMP_LOGS for CfnCluster.

    :cloudformationResource: AWS::PCS::Cluster
    :logType: PCS_JOBCOMP_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
        
        cfn_cluster_pcs_jobcomp_logs = pcs_mixins.CfnClusterPcsJobcompLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsJobcompLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40180a2bcf809bb18698e435548a7df3055e3fa4d5e790da7c7ef8188d3f2089)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnClusterPcsJobcompLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsJobcompLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40d3301a1e1650a5371b00fb7e336a84bbe09309bc87a173df1c8f487f161a15)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnClusterPcsJobcompLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsJobcompLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4e5fb6e94f05b3033e409179570a4b40f31ff4939491f63243173c259e4adbd0)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnClusterPcsJobcompLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsJobcompLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b00425dadad64c8a5d02f7361b03fb17f41cd92801e4ce5909e6a4d1a83cf667)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnClusterPcsJobcompLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnClusterPcsJobcompLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsJobcompLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_jobcomp_logs_dest_props = pcs_mixins.CfnClusterPcsJobcompLogsDestProps(
                record_fields=[pcs_mixins.CfnClusterPcsJobcompLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b764d7307490cafece2c43283af87a1420618c021ad73d4823769342bab701eb)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsJobcompLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsJobcompLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsJobcompLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterPcsJobcompLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsJobcompLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_jobcomp_logs_firehose_props = pcs_mixins.CfnClusterPcsJobcompLogsFirehoseProps(
                output_format=pcs_mixins.CfnClusterPcsJobcompLogsOutputFormat.Firehose.JSON,
                record_fields=[pcs_mixins.CfnClusterPcsJobcompLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c028e25e4c95558d20763c857a06d910f50a660ccb1b15cce5b2d300f563dd3)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsJobcompLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsJobcompLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsJobcompLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterPcsJobcompLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsJobcompLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_jobcomp_logs_log_group_props = pcs_mixins.CfnClusterPcsJobcompLogsLogGroupProps(
                output_format=pcs_mixins.CfnClusterPcsJobcompLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[pcs_mixins.CfnClusterPcsJobcompLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__71c6890aa082300de0fa214087d22c280d1a956961e27c9d90fb942b46987e06)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsJobcompLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsJobcompLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsJobcompLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterPcsJobcompLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnClusterPcsJobcompLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
        
        cfn_cluster_pcs_jobcomp_logs_output_format = pcs_mixins.CfnClusterPcsJobcompLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsRecordFields"
)
class CfnClusterPcsJobcompLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ID = "RESOURCE_ID"
    '''
    :stability: experimental
    '''
    RESOURCE_TYPE = "RESOURCE_TYPE"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    SCHEDULER_TYPE = "SCHEDULER_TYPE"
    '''
    :stability: experimental
    '''
    SCHEDULER_MAJOR_VERSION = "SCHEDULER_MAJOR_VERSION"
    '''
    :stability: experimental
    '''
    FIELDS = "FIELDS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsJobcompLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnClusterPcsJobcompLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsJobcompLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_cluster_pcs_jobcomp_logs_s3_props = pcs_mixins.CfnClusterPcsJobcompLogsS3Props(
                encryption_key=key_ref,
                output_format=pcs_mixins.CfnClusterPcsJobcompLogsOutputFormat.S3.JSON,
                record_fields=[pcs_mixins.CfnClusterPcsJobcompLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__773f33108d09e592379494345964bac07dae67d235bffb0b893560652ec2d76d)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsJobcompLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsJobcompLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsJobcompLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsJobcompLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterPcsSchedulerAuditLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogs",
):
    '''Builder for CfnClusterLogsMixin to generate PCS_SCHEDULER_AUDIT_LOGS for CfnCluster.

    :cloudformationResource: AWS::PCS::Cluster
    :logType: PCS_SCHEDULER_AUDIT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
        
        cfn_cluster_pcs_scheduler_audit_logs = pcs_mixins.CfnClusterPcsSchedulerAuditLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerAuditLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bdf12c49ae4f7b6d814d597d0a3573a9c466f0b0e8e3d495a7bcd2b0b4baf83)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnClusterPcsSchedulerAuditLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerAuditLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56be18c45fa988d068797a275de2a6763872b87046c06015f668d3397e2ce0fb)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnClusterPcsSchedulerAuditLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerAuditLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff29a8daa5d89ce6826f46da7f2d53f1b95086f733ccdb483aa2bfbf7981f998)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnClusterPcsSchedulerAuditLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerAuditLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b50b6062138b75ef006c1138183f8923b9b795379148c64744f8c73a32809e27)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnClusterPcsSchedulerAuditLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnClusterPcsSchedulerAuditLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerAuditLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_scheduler_audit_logs_dest_props = pcs_mixins.CfnClusterPcsSchedulerAuditLogsDestProps(
                record_fields=[pcs_mixins.CfnClusterPcsSchedulerAuditLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fed813f06ba9a78ac400526a7bbbab2f50c72aa0e7e52855b93a57f07e6624cd)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsSchedulerAuditLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsSchedulerAuditLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsSchedulerAuditLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterPcsSchedulerAuditLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerAuditLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_scheduler_audit_logs_firehose_props = pcs_mixins.CfnClusterPcsSchedulerAuditLogsFirehoseProps(
                output_format=pcs_mixins.CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose.JSON,
                record_fields=[pcs_mixins.CfnClusterPcsSchedulerAuditLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c53c61b7512e9ef96f18298bcf1fa4cfc78eeada1deb75f421c083c087e55e70)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsSchedulerAuditLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsSchedulerAuditLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsSchedulerAuditLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterPcsSchedulerAuditLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerAuditLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_scheduler_audit_logs_log_group_props = pcs_mixins.CfnClusterPcsSchedulerAuditLogsLogGroupProps(
                output_format=pcs_mixins.CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[pcs_mixins.CfnClusterPcsSchedulerAuditLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1bd3b371cc4a69397912c86f208fc18c8739b7b690c130a1f696b87beb71782d)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsSchedulerAuditLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsSchedulerAuditLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsSchedulerAuditLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterPcsSchedulerAuditLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnClusterPcsSchedulerAuditLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
        
        cfn_cluster_pcs_scheduler_audit_logs_output_format = pcs_mixins.CfnClusterPcsSchedulerAuditLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsRecordFields"
)
class CfnClusterPcsSchedulerAuditLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ID = "RESOURCE_ID"
    '''
    :stability: experimental
    '''
    RESOURCE_TYPE = "RESOURCE_TYPE"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    LOG_LEVEL = "LOG_LEVEL"
    '''
    :stability: experimental
    '''
    SCHEDULER_TYPE = "SCHEDULER_TYPE"
    '''
    :stability: experimental
    '''
    SCHEDULER_PATCH_VERSION = "SCHEDULER_PATCH_VERSION"
    '''
    :stability: experimental
    '''
    NODE_TYPE = "NODE_TYPE"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    LOG_NAME = "LOG_NAME"
    '''
    :stability: experimental
    '''
    SCHEDULER_MAJOR_VERSION = "SCHEDULER_MAJOR_VERSION"
    '''
    :stability: experimental
    '''
    LOG_TYPE = "LOG_TYPE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerAuditLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnClusterPcsSchedulerAuditLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerAuditLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_cluster_pcs_scheduler_audit_logs_s3_props = pcs_mixins.CfnClusterPcsSchedulerAuditLogsS3Props(
                encryption_key=key_ref,
                output_format=pcs_mixins.CfnClusterPcsSchedulerAuditLogsOutputFormat.S3.JSON,
                record_fields=[pcs_mixins.CfnClusterPcsSchedulerAuditLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d71ae33b3545f96ac3a539297bf18e422513a848b7a4331d8ba2db67ea545a69)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsSchedulerAuditLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsSchedulerAuditLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsSchedulerAuditLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsSchedulerAuditLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterPcsSchedulerLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogs",
):
    '''Builder for CfnClusterLogsMixin to generate PCS_SCHEDULER_LOGS for CfnCluster.

    :cloudformationResource: AWS::PCS::Cluster
    :logType: PCS_SCHEDULER_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
        
        cfn_cluster_pcs_scheduler_logs = pcs_mixins.CfnClusterPcsSchedulerLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5864b4efacf81f61da75982e41a5386c9e49e4e3ddce31ecd3e7215111aa6d29)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnClusterPcsSchedulerLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cbddd3f16d07d0b43d9bf79954fc54f49c77f115eec373bcb16bf9dd63effc1a)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnClusterPcsSchedulerLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f90c69aa8ef08fdb6d52d6de2cbd70db375fe9d1610fa3b7d867a296f95edab0)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnClusterPcsSchedulerLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b1da1c528da59bd7d286c57a9e7b1f29d79e506bb7c1c1987592b5db36e9aeef)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnClusterPcsSchedulerLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnClusterPcsSchedulerLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_scheduler_logs_dest_props = pcs_mixins.CfnClusterPcsSchedulerLogsDestProps(
                record_fields=[pcs_mixins.CfnClusterPcsSchedulerLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66673fe6c451a5d038e0168f30ee54a8af3fd1ac896c5338305a5519f24545f9)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsSchedulerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsSchedulerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsSchedulerLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterPcsSchedulerLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_scheduler_logs_firehose_props = pcs_mixins.CfnClusterPcsSchedulerLogsFirehoseProps(
                output_format=pcs_mixins.CfnClusterPcsSchedulerLogsOutputFormat.Firehose.JSON,
                record_fields=[pcs_mixins.CfnClusterPcsSchedulerLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__30e00649c25470b7bf82d610eaa3501823c3d7fbe7dc08b891e5670b981b7e17)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsSchedulerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsSchedulerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsSchedulerLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterPcsSchedulerLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            
            cfn_cluster_pcs_scheduler_logs_log_group_props = pcs_mixins.CfnClusterPcsSchedulerLogsLogGroupProps(
                output_format=pcs_mixins.CfnClusterPcsSchedulerLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[pcs_mixins.CfnClusterPcsSchedulerLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08f82e0c6b7eeadce6660cd96eca5dd204ad9501ad6f061d68219dbfc2bee69b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsSchedulerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsSchedulerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsSchedulerLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterPcsSchedulerLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnClusterPcsSchedulerLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
        
        cfn_cluster_pcs_scheduler_logs_output_format = pcs_mixins.CfnClusterPcsSchedulerLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsRecordFields"
)
class CfnClusterPcsSchedulerLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ID = "RESOURCE_ID"
    '''
    :stability: experimental
    '''
    RESOURCE_TYPE = "RESOURCE_TYPE"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    LOG_LEVEL = "LOG_LEVEL"
    '''
    :stability: experimental
    '''
    LOG_NAME = "LOG_NAME"
    '''
    :stability: experimental
    '''
    SCHEDULER_TYPE = "SCHEDULER_TYPE"
    '''
    :stability: experimental
    '''
    SCHEDULER_MAJOR_VERSION = "SCHEDULER_MAJOR_VERSION"
    '''
    :stability: experimental
    '''
    SCHEDULER_PATCH_VERSION = "SCHEDULER_PATCH_VERSION"
    '''
    :stability: experimental
    '''
    NODE_TYPE = "NODE_TYPE"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_pcs.mixins.CfnClusterPcsSchedulerLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnClusterPcsSchedulerLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterPcsSchedulerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_pcs import mixins as pcs_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_cluster_pcs_scheduler_logs_s3_props = pcs_mixins.CfnClusterPcsSchedulerLogsS3Props(
                encryption_key=key_ref,
                output_format=pcs_mixins.CfnClusterPcsSchedulerLogsOutputFormat.S3.JSON,
                record_fields=[pcs_mixins.CfnClusterPcsSchedulerLogsRecordFields.RESOURCE_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8bc36b1476963348ffc4c340aa92f895af18ad8ca4d381ebc99bd79ae5350f28)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterPcsSchedulerLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterPcsSchedulerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterPcsSchedulerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterPcsSchedulerLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnClusterLogsMixin",
    "CfnClusterPcsJobcompLogs",
    "CfnClusterPcsJobcompLogsDestProps",
    "CfnClusterPcsJobcompLogsFirehoseProps",
    "CfnClusterPcsJobcompLogsLogGroupProps",
    "CfnClusterPcsJobcompLogsOutputFormat",
    "CfnClusterPcsJobcompLogsRecordFields",
    "CfnClusterPcsJobcompLogsS3Props",
    "CfnClusterPcsSchedulerAuditLogs",
    "CfnClusterPcsSchedulerAuditLogsDestProps",
    "CfnClusterPcsSchedulerAuditLogsFirehoseProps",
    "CfnClusterPcsSchedulerAuditLogsLogGroupProps",
    "CfnClusterPcsSchedulerAuditLogsOutputFormat",
    "CfnClusterPcsSchedulerAuditLogsRecordFields",
    "CfnClusterPcsSchedulerAuditLogsS3Props",
    "CfnClusterPcsSchedulerLogs",
    "CfnClusterPcsSchedulerLogsDestProps",
    "CfnClusterPcsSchedulerLogsFirehoseProps",
    "CfnClusterPcsSchedulerLogsLogGroupProps",
    "CfnClusterPcsSchedulerLogsOutputFormat",
    "CfnClusterPcsSchedulerLogsRecordFields",
    "CfnClusterPcsSchedulerLogsS3Props",
]

publication.publish()

def _typecheckingstub__895989435c64ce6ac8ba60f4839b019a11c9756f2dddd9df13d89ee185120eaf(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62ba0f970aaa3a35b0eea8e1d967c5d7b947370f9db7a78ac98b9a262357c37a(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e24685fe192db49a38fd71bcc95b607b3b231591f3ce0acb13d01583294d02ed(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40180a2bcf809bb18698e435548a7df3055e3fa4d5e790da7c7ef8188d3f2089(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsJobcompLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40d3301a1e1650a5371b00fb7e336a84bbe09309bc87a173df1c8f487f161a15(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnClusterPcsJobcompLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsJobcompLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4e5fb6e94f05b3033e409179570a4b40f31ff4939491f63243173c259e4adbd0(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnClusterPcsJobcompLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsJobcompLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b00425dadad64c8a5d02f7361b03fb17f41cd92801e4ce5909e6a4d1a83cf667(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterPcsJobcompLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsJobcompLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b764d7307490cafece2c43283af87a1420618c021ad73d4823769342bab701eb(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsJobcompLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c028e25e4c95558d20763c857a06d910f50a660ccb1b15cce5b2d300f563dd3(
    *,
    output_format: typing.Optional[CfnClusterPcsJobcompLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsJobcompLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71c6890aa082300de0fa214087d22c280d1a956961e27c9d90fb942b46987e06(
    *,
    output_format: typing.Optional[CfnClusterPcsJobcompLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsJobcompLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__773f33108d09e592379494345964bac07dae67d235bffb0b893560652ec2d76d(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterPcsJobcompLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsJobcompLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bdf12c49ae4f7b6d814d597d0a3573a9c466f0b0e8e3d495a7bcd2b0b4baf83(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56be18c45fa988d068797a275de2a6763872b87046c06015f668d3397e2ce0fb(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff29a8daa5d89ce6826f46da7f2d53f1b95086f733ccdb483aa2bfbf7981f998(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b50b6062138b75ef006c1138183f8923b9b795379148c64744f8c73a32809e27(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterPcsSchedulerAuditLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fed813f06ba9a78ac400526a7bbbab2f50c72aa0e7e52855b93a57f07e6624cd(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c53c61b7512e9ef96f18298bcf1fa4cfc78eeada1deb75f421c083c087e55e70(
    *,
    output_format: typing.Optional[CfnClusterPcsSchedulerAuditLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1bd3b371cc4a69397912c86f208fc18c8739b7b690c130a1f696b87beb71782d(
    *,
    output_format: typing.Optional[CfnClusterPcsSchedulerAuditLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d71ae33b3545f96ac3a539297bf18e422513a848b7a4331d8ba2db67ea545a69(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterPcsSchedulerAuditLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerAuditLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5864b4efacf81f61da75982e41a5386c9e49e4e3ddce31ecd3e7215111aa6d29(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cbddd3f16d07d0b43d9bf79954fc54f49c77f115eec373bcb16bf9dd63effc1a(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnClusterPcsSchedulerLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f90c69aa8ef08fdb6d52d6de2cbd70db375fe9d1610fa3b7d867a296f95edab0(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnClusterPcsSchedulerLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b1da1c528da59bd7d286c57a9e7b1f29d79e506bb7c1c1987592b5db36e9aeef(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterPcsSchedulerLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66673fe6c451a5d038e0168f30ee54a8af3fd1ac896c5338305a5519f24545f9(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__30e00649c25470b7bf82d610eaa3501823c3d7fbe7dc08b891e5670b981b7e17(
    *,
    output_format: typing.Optional[CfnClusterPcsSchedulerLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08f82e0c6b7eeadce6660cd96eca5dd204ad9501ad6f061d68219dbfc2bee69b(
    *,
    output_format: typing.Optional[CfnClusterPcsSchedulerLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8bc36b1476963348ffc4c340aa92f895af18ad8ca4d381ebc99bd79ae5350f28(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterPcsSchedulerLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterPcsSchedulerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
