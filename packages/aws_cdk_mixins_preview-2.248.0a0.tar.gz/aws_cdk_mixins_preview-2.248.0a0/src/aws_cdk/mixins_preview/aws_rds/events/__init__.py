from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class RDSDBClusterEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBClusterEvent",
):
    '''(experimental) EventBridge event pattern for aws.rds@RDSDBClusterEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_rds import events as rds_events
        
        r_dSDBCluster_event = rds_events.RDSDBClusterEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="rdsDBClusterEventPattern")
    @builtins.classmethod
    def rds_db_cluster_event_pattern(
        cls,
        *,
        date: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for RDS DB Cluster Event.

        :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RDSDBClusterEvent.RDSDBClusterEventProps(
            date=date,
            event_categories=event_categories,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "rdsDBClusterEventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBClusterEvent.RDSDBClusterEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "date": "date",
            "event_categories": "eventCategories",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
            "tags": "tags",
        },
    )
    class RDSDBClusterEventProps:
        def __init__(
            self,
            *,
            date: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.rds@RDSDBClusterEvent event.

            :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_rds import events as rds_events
                
                r_dSDBCluster_event_props = rds_events.RDSDBClusterEvent.RDSDBClusterEventProps(
                    date=["date"],
                    event_categories=["eventCategories"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"],
                    tags={
                        "tags_key": "tags"
                    }
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d7ca6c374add0f710767767ba8a5d4423fce5fb97c6d25d88483b01514e3c250)
                check_type(argname="argument date", value=date, expected_type=type_hints["date"])
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if date is not None:
                self._values["date"] = date
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Date property.

            Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RDSDBClusterEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RDSDBClusterSnapshotEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBClusterSnapshotEvent",
):
    '''(experimental) EventBridge event pattern for aws.rds@RDSDBClusterSnapshotEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_rds import events as rds_events
        
        r_dSDBCluster_snapshot_event = rds_events.RDSDBClusterSnapshotEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="rdsDBClusterSnapshotEventPattern")
    @builtins.classmethod
    def rds_db_cluster_snapshot_event_pattern(
        cls,
        *,
        date: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for RDS DB Cluster Snapshot Event.

        :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RDSDBClusterSnapshotEvent.RDSDBClusterSnapshotEventProps(
            date=date,
            event_categories=event_categories,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "rdsDBClusterSnapshotEventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBClusterSnapshotEvent.RDSDBClusterSnapshotEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "date": "date",
            "event_categories": "eventCategories",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
            "tags": "tags",
        },
    )
    class RDSDBClusterSnapshotEventProps:
        def __init__(
            self,
            *,
            date: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.rds@RDSDBClusterSnapshotEvent event.

            :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_rds import events as rds_events
                
                r_dSDBCluster_snapshot_event_props = rds_events.RDSDBClusterSnapshotEvent.RDSDBClusterSnapshotEventProps(
                    date=["date"],
                    event_categories=["eventCategories"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"],
                    tags={
                        "tags_key": "tags"
                    }
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__82888656d694dd3a58eb659ed4f3919f7df9ac6f40e1a1fa9494551d286f535f)
                check_type(argname="argument date", value=date, expected_type=type_hints["date"])
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if date is not None:
                self._values["date"] = date
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Date property.

            Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RDSDBClusterSnapshotEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RDSDBInstanceEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBInstanceEvent",
):
    '''(experimental) EventBridge event pattern for aws.rds@RDSDBInstanceEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_rds import events as rds_events
        
        r_dSDBInstance_event = rds_events.RDSDBInstanceEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="rdsDBInstanceEventPattern")
    @builtins.classmethod
    def rds_db_instance_event_pattern(
        cls,
        *,
        date: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for RDS DB Instance Event.

        :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RDSDBInstanceEvent.RDSDBInstanceEventProps(
            date=date,
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "rdsDBInstanceEventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBInstanceEvent.RDSDBInstanceEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "date": "date",
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
            "tags": "tags",
        },
    )
    class RDSDBInstanceEventProps:
        def __init__(
            self,
            *,
            date: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.rds@RDSDBInstanceEvent event.

            :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_rds import events as rds_events
                
                r_dSDBInstance_event_props = rds_events.RDSDBInstanceEvent.RDSDBInstanceEventProps(
                    date=["date"],
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"],
                    tags={
                        "tags_key": "tags"
                    }
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8cae95d9a01a1134ef7896195dae5a69ab194f67fa6e6d0507c346c0d36105a1)
                check_type(argname="argument date", value=date, expected_type=type_hints["date"])
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if date is not None:
                self._values["date"] = date
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Date property.

            Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RDSDBInstanceEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RDSDBParameterGroupEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBParameterGroupEvent",
):
    '''(experimental) EventBridge event pattern for aws.rds@RDSDBParameterGroupEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_rds import events as rds_events
        
        r_dSDBParameter_group_event = rds_events.RDSDBParameterGroupEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="rdsDBParameterGroupEventPattern")
    @builtins.classmethod
    def rds_db_parameter_group_event_pattern(
        cls,
        *,
        date: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for RDS DB Parameter Group Event.

        :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RDSDBParameterGroupEvent.RDSDBParameterGroupEventProps(
            date=date,
            event_categories=event_categories,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "rdsDBParameterGroupEventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBParameterGroupEvent.RDSDBParameterGroupEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "date": "date",
            "event_categories": "eventCategories",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
            "tags": "tags",
        },
    )
    class RDSDBParameterGroupEventProps:
        def __init__(
            self,
            *,
            date: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.rds@RDSDBParameterGroupEvent event.

            :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_rds import events as rds_events
                
                r_dSDBParameter_group_event_props = rds_events.RDSDBParameterGroupEvent.RDSDBParameterGroupEventProps(
                    date=["date"],
                    event_categories=["eventCategories"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"],
                    tags={
                        "tags_key": "tags"
                    }
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5b566f9f35389f30b116a49e15cb1aac705592747ed38febd962a99b5706f8d4)
                check_type(argname="argument date", value=date, expected_type=type_hints["date"])
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if date is not None:
                self._values["date"] = date
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Date property.

            Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RDSDBParameterGroupEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RDSDBProxyEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBProxyEvent",
):
    '''(experimental) EventBridge event pattern for aws.rds@RDSDBProxyEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_rds import events as rds_events
        
        r_dSDBProxy_event = rds_events.RDSDBProxyEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="rdsDBProxyEventPattern")
    @builtins.classmethod
    def rds_db_proxy_event_pattern(
        cls,
        *,
        date: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for RDS DB Proxy Event.

        :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RDSDBProxyEvent.RDSDBProxyEventProps(
            date=date,
            event_categories=event_categories,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "rdsDBProxyEventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBProxyEvent.RDSDBProxyEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "date": "date",
            "event_categories": "eventCategories",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
            "tags": "tags",
        },
    )
    class RDSDBProxyEventProps:
        def __init__(
            self,
            *,
            date: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.rds@RDSDBProxyEvent event.

            :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_rds import events as rds_events
                
                r_dSDBProxy_event_props = rds_events.RDSDBProxyEvent.RDSDBProxyEventProps(
                    date=["date"],
                    event_categories=["eventCategories"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"],
                    tags={
                        "tags_key": "tags"
                    }
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__41d1cab4d46e7324756ef3e4f36f8dda4ec4541e3fe08fc3a4fa7da7de87821e)
                check_type(argname="argument date", value=date, expected_type=type_hints["date"])
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if date is not None:
                self._values["date"] = date
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Date property.

            Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RDSDBProxyEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RDSDBSecurityGroupEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBSecurityGroupEvent",
):
    '''(experimental) EventBridge event pattern for aws.rds@RDSDBSecurityGroupEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_rds import events as rds_events
        
        r_dSDBSecurity_group_event = rds_events.RDSDBSecurityGroupEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="rdsDBSecurityGroupEventPattern")
    @builtins.classmethod
    def rds_db_security_group_event_pattern(
        cls,
        *,
        date: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for RDS DB Security Group Event.

        :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RDSDBSecurityGroupEvent.RDSDBSecurityGroupEventProps(
            date=date,
            event_categories=event_categories,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "rdsDBSecurityGroupEventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBSecurityGroupEvent.RDSDBSecurityGroupEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "date": "date",
            "event_categories": "eventCategories",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
            "tags": "tags",
        },
    )
    class RDSDBSecurityGroupEventProps:
        def __init__(
            self,
            *,
            date: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.rds@RDSDBSecurityGroupEvent event.

            :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_rds import events as rds_events
                
                r_dSDBSecurity_group_event_props = rds_events.RDSDBSecurityGroupEvent.RDSDBSecurityGroupEventProps(
                    date=["date"],
                    event_categories=["eventCategories"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"],
                    tags={
                        "tags_key": "tags"
                    }
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6357b3c548d5c2b47979efe6dde7230383a730209ffb429f75e63ba95c4bb4a8)
                check_type(argname="argument date", value=date, expected_type=type_hints["date"])
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if date is not None:
                self._values["date"] = date
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Date property.

            Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RDSDBSecurityGroupEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RDSDBSnapshotEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBSnapshotEvent",
):
    '''(experimental) EventBridge event pattern for aws.rds@RDSDBSnapshotEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_rds import events as rds_events
        
        r_dSDBSnapshot_event = rds_events.RDSDBSnapshotEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="rdsDBSnapshotEventPattern")
    @builtins.classmethod
    def rds_db_snapshot_event_pattern(
        cls,
        *,
        date: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for RDS DB Snapshot Event.

        :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RDSDBSnapshotEvent.RDSDBSnapshotEventProps(
            date=date,
            event_categories=event_categories,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "rdsDBSnapshotEventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_rds.events.RDSDBSnapshotEvent.RDSDBSnapshotEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "date": "date",
            "event_categories": "eventCategories",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
            "tags": "tags",
        },
    )
    class RDSDBSnapshotEventProps:
        def __init__(
            self,
            *,
            date: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.rds@RDSDBSnapshotEvent event.

            :param date: (experimental) Date property. Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_rds import events as rds_events
                
                r_dSDBSnapshot_event_props = rds_events.RDSDBSnapshotEvent.RDSDBSnapshotEventProps(
                    date=["date"],
                    event_categories=["eventCategories"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"],
                    tags={
                        "tags_key": "tags"
                    }
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__bb525869bf1e32929eb71c0778252142460001b307c5de5a37390bcbad3f8ea0)
                check_type(argname="argument date", value=date, expected_type=type_hints["date"])
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if date is not None:
                self._values["date"] = date
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Date property.

            Specify an array of string values to match this event if the actual value of Date is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RDSDBSnapshotEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "RDSDBClusterEvent",
    "RDSDBClusterSnapshotEvent",
    "RDSDBInstanceEvent",
    "RDSDBParameterGroupEvent",
    "RDSDBProxyEvent",
    "RDSDBSecurityGroupEvent",
    "RDSDBSnapshotEvent",
]

publication.publish()

def _typecheckingstub__d7ca6c374add0f710767767ba8a5d4423fce5fb97c6d25d88483b01514e3c250(
    *,
    date: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82888656d694dd3a58eb659ed4f3919f7df9ac6f40e1a1fa9494551d286f535f(
    *,
    date: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8cae95d9a01a1134ef7896195dae5a69ab194f67fa6e6d0507c346c0d36105a1(
    *,
    date: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b566f9f35389f30b116a49e15cb1aac705592747ed38febd962a99b5706f8d4(
    *,
    date: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41d1cab4d46e7324756ef3e4f36f8dda4ec4541e3fe08fc3a4fa7da7de87821e(
    *,
    date: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6357b3c548d5c2b47979efe6dde7230383a730209ffb429f75e63ba95c4bb4a8(
    *,
    date: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb525869bf1e32929eb71c0778252142460001b307c5de5a37390bcbad3f8ea0(
    *,
    date: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
