from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnHypervisorBgwHypervisorLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorBgwHypervisorLogs",
):
    '''Builder for CfnHypervisorLogsMixin to generate BGW_HYPERVISOR_LOGS for CfnHypervisor.

    :cloudformationResource: AWS::BackupGateway::Hypervisor
    :logType: BGW_HYPERVISOR_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
        
        cfn_hypervisor_bgw_hypervisor_logs = backupgateway_mixins.CfnHypervisorBgwHypervisorLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnHypervisorLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8883d196ba9c0ff4deefcab6edba46938fc26a983b4159ffafcb34c344b0170b)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnHypervisorLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose"] = None,
    ) -> "CfnHypervisorLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__07ee99cbfcd93ae63b5eb93a349f3964e7b1b59c9cf188aac5863705d58ed179)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnHypervisorBgwHypervisorLogsFirehoseProps(
            output_format=output_format
        )

        return typing.cast("CfnHypervisorLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnHypervisorLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c6b58c21feb61da215c33508372a223dea5b336577144f62c3161e9ffa5c4d49)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnHypervisorBgwHypervisorLogsLogGroupProps(
            output_format=output_format
        )

        return typing.cast("CfnHypervisorLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.S3"] = None,
    ) -> "CfnHypervisorLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bdc169b68c91a6b1d528b70a63df186734212be61905f0f31dda391551039294)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnHypervisorBgwHypervisorLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnHypervisorLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorBgwHypervisorLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnHypervisorBgwHypervisorLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
            
            cfn_hypervisor_bgw_hypervisor_logs_firehose_props = backupgateway_mixins.CfnHypervisorBgwHypervisorLogsFirehoseProps(
                output_format=backupgateway_mixins.CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd1c3a61b619d1b2d67531d144f312f63b9ed295483d1bf9d2bd382745d19a6f)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnHypervisorBgwHypervisorLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorBgwHypervisorLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnHypervisorBgwHypervisorLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
            
            cfn_hypervisor_bgw_hypervisor_logs_log_group_props = backupgateway_mixins.CfnHypervisorBgwHypervisorLogsLogGroupProps(
                output_format=backupgateway_mixins.CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98eebff9e2783b57cb1834f5c38e6e2f277c60d0a1e35b94af5d7fde060d8665)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnHypervisorBgwHypervisorLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnHypervisorBgwHypervisorLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorBgwHypervisorLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnHypervisorBgwHypervisorLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
        
        cfn_hypervisor_bgw_hypervisor_logs_output_format = backupgateway_mixins.CfnHypervisorBgwHypervisorLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorBgwHypervisorLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorBgwHypervisorLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnHypervisorBgwHypervisorLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_hypervisor_bgw_hypervisor_logs_s3_props = backupgateway_mixins.CfnHypervisorBgwHypervisorLogsS3Props(
                encryption_key=key_ref,
                output_format=backupgateway_mixins.CfnHypervisorBgwHypervisorLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__44978ebe3a215a3fe7a66e6d1105090f2c6aca2e2fb4a1be42efa7b300199ae1)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnHypervisorBgwHypervisorLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnHypervisorBgwHypervisorLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnHypervisorDataAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorDataAccessLogs",
):
    '''Builder for CfnHypervisorLogsMixin to generate DATA_ACCESS_LOGS for CfnHypervisor.

    :cloudformationResource: AWS::BackupGateway::Hypervisor
    :logType: DATA_ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
        
        cfn_hypervisor_data_access_logs = backupgateway_mixins.CfnHypervisorDataAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnHypervisorLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4434a85b5f8d8a03a8d03789969d78c3af69a329e3bad90d10678079096e0b98)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnHypervisorLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.Firehose"] = None,
    ) -> "CfnHypervisorLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33f1bb356865a609ef23ea2c583f0239d8c177d1740ae09980a1bf9a3204ffd1)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnHypervisorDataAccessLogsFirehoseProps(output_format=output_format)

        return typing.cast("CfnHypervisorLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnHypervisorLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__63b8e57208141b6ed4abe5be0a4c9d77cbd2a733ffc5ca59b56cf11dfcf20365)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnHypervisorDataAccessLogsLogGroupProps(output_format=output_format)

        return typing.cast("CfnHypervisorLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.S3"] = None,
    ) -> "CfnHypervisorLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__90aa1f5cb54d8b5651e488a5e2497350ae8189552f49a9bad199c739554a2da4)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnHypervisorDataAccessLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnHypervisorLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorDataAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnHypervisorDataAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
            
            cfn_hypervisor_data_access_logs_firehose_props = backupgateway_mixins.CfnHypervisorDataAccessLogsFirehoseProps(
                output_format=backupgateway_mixins.CfnHypervisorDataAccessLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc4a9e337edab49b6ad1f12ec5e40862f89659560b9ee8ba24d21eb277610d21)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnHypervisorDataAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorDataAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnHypervisorDataAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
            
            cfn_hypervisor_data_access_logs_log_group_props = backupgateway_mixins.CfnHypervisorDataAccessLogsLogGroupProps(
                output_format=backupgateway_mixins.CfnHypervisorDataAccessLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__172bcf806d92f7fa36807a2b1978cdaece0e3d227c9d169e3ce06085e9e1b619)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnHypervisorDataAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnHypervisorDataAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorDataAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnHypervisorDataAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
        
        cfn_hypervisor_data_access_logs_output_format = backupgateway_mixins.CfnHypervisorDataAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorDataAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorDataAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorDataAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorDataAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnHypervisorDataAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_hypervisor_data_access_logs_s3_props = backupgateway_mixins.CfnHypervisorDataAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=backupgateway_mixins.CfnHypervisorDataAccessLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5315bec61ac9604aeead96e531929c7968c82e37934b33fa3bdb087f6c176524)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnHypervisorDataAccessLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnHypervisorDataAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnHypervisorLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_backupgateway.mixins.CfnHypervisorLogsMixin",
):
    '''Represents the hypervisor's permissions to which the gateway will connect.

    A hypervisor is hardware, software, or firmware that creates and manages virtual machines, and allocates resources to them.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-backupgateway-hypervisor.html
    :cloudformationResource: AWS::BackupGateway::Hypervisor
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_backupgateway import mixins as backupgateway_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_hypervisor_logs_mixin = backupgateway_mixins.CfnHypervisorLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::BackupGateway::Hypervisor``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a90eaeb98e70ecb0b6321647bd9bed82bb4bb97394f581b4dc806b476a3bcb67)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__021d7f853d568e0e42b308216cda7f951ef35b8cf24f725d672aada731975623)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4218a10056c4f26e4e567f73e753e85a9e39a558976ff36fbd03d84d683f11b4)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="BGW_HYPERVISOR_LOGS")
    def BGW_HYPERVISOR_LOGS(cls) -> "CfnHypervisorBgwHypervisorLogs":
        return typing.cast("CfnHypervisorBgwHypervisorLogs", jsii.sget(cls, "BGW_HYPERVISOR_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="DATA_ACCESS_LOGS")
    def DATA_ACCESS_LOGS(cls) -> "CfnHypervisorDataAccessLogs":
        return typing.cast("CfnHypervisorDataAccessLogs", jsii.sget(cls, "DATA_ACCESS_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnHypervisorBgwHypervisorLogs",
    "CfnHypervisorBgwHypervisorLogsFirehoseProps",
    "CfnHypervisorBgwHypervisorLogsLogGroupProps",
    "CfnHypervisorBgwHypervisorLogsOutputFormat",
    "CfnHypervisorBgwHypervisorLogsS3Props",
    "CfnHypervisorDataAccessLogs",
    "CfnHypervisorDataAccessLogsFirehoseProps",
    "CfnHypervisorDataAccessLogsLogGroupProps",
    "CfnHypervisorDataAccessLogsOutputFormat",
    "CfnHypervisorDataAccessLogsS3Props",
    "CfnHypervisorLogsMixin",
]

publication.publish()

def _typecheckingstub__8883d196ba9c0ff4deefcab6edba46938fc26a983b4159ffafcb34c344b0170b(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__07ee99cbfcd93ae63b5eb93a349f3964e7b1b59c9cf188aac5863705d58ed179(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c6b58c21feb61da215c33508372a223dea5b336577144f62c3161e9ffa5c4d49(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bdc169b68c91a6b1d528b70a63df186734212be61905f0f31dda391551039294(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnHypervisorBgwHypervisorLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd1c3a61b619d1b2d67531d144f312f63b9ed295483d1bf9d2bd382745d19a6f(
    *,
    output_format: typing.Optional[CfnHypervisorBgwHypervisorLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98eebff9e2783b57cb1834f5c38e6e2f277c60d0a1e35b94af5d7fde060d8665(
    *,
    output_format: typing.Optional[CfnHypervisorBgwHypervisorLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__44978ebe3a215a3fe7a66e6d1105090f2c6aca2e2fb4a1be42efa7b300199ae1(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnHypervisorBgwHypervisorLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4434a85b5f8d8a03a8d03789969d78c3af69a329e3bad90d10678079096e0b98(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33f1bb356865a609ef23ea2c583f0239d8c177d1740ae09980a1bf9a3204ffd1(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnHypervisorDataAccessLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63b8e57208141b6ed4abe5be0a4c9d77cbd2a733ffc5ca59b56cf11dfcf20365(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnHypervisorDataAccessLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__90aa1f5cb54d8b5651e488a5e2497350ae8189552f49a9bad199c739554a2da4(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnHypervisorDataAccessLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc4a9e337edab49b6ad1f12ec5e40862f89659560b9ee8ba24d21eb277610d21(
    *,
    output_format: typing.Optional[CfnHypervisorDataAccessLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__172bcf806d92f7fa36807a2b1978cdaece0e3d227c9d169e3ce06085e9e1b619(
    *,
    output_format: typing.Optional[CfnHypervisorDataAccessLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5315bec61ac9604aeead96e531929c7968c82e37934b33fa3bdb087f6c176524(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnHypervisorDataAccessLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a90eaeb98e70ecb0b6321647bd9bed82bb4bb97394f581b4dc806b476a3bcb67(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__021d7f853d568e0e42b308216cda7f951ef35b8cf24f725d672aada731975623(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4218a10056c4f26e4e567f73e753e85a9e39a558976ff36fbd03d84d683f11b4(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
