from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_voiceid as _aws_cdk_interfaces_aws_voiceid_ceddda9d


class DomainEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.DomainEvents",
):
    '''(experimental) EventBridge event patterns for Domain.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        from aws_cdk.interfaces import aws_voiceid as interfaces_voiceid
        
        # domain_ref: interfaces_voiceid.IDomainRef
        
        domain_events = voiceid_events.DomainEvents.from_domain(domain_ref)
    '''

    @jsii.member(jsii_name="fromDomain")
    @builtins.classmethod
    def from_domain(
        cls,
        domain_ref: "_aws_cdk_interfaces_aws_voiceid_ceddda9d.IDomainRef",
    ) -> "DomainEvents":
        '''(experimental) Create DomainEvents from a Domain reference.

        :param domain_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33f136a5b85b027f97dcce5d4bbabc0519a38dbb97bb11a589a536ecbfd7c0d4)
            check_type(argname="argument domain_ref", value=domain_ref, expected_type=type_hints["domain_ref"])
        return typing.cast("DomainEvents", jsii.sinvoke(cls, "fromDomain", [domain_ref]))

    @jsii.member(jsii_name="voiceIdBatchFraudsterRegistrationActionPattern")
    def voice_id_batch_fraudster_registration_action_pattern(
        self,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        batch_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        data: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Domain VoiceId Batch Fraudster Registration Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param batch_job_id: (experimental) batchJobId property. Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdBatchFraudsterRegistrationAction.VoiceIdBatchFraudsterRegistrationActionProps(
            action=action,
            batch_job_id=batch_job_id,
            data=data,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            source_id=source_id,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "voiceIdBatchFraudsterRegistrationActionPattern", [options]))

    @jsii.member(jsii_name="voiceIdBatchSpeakerEnrollmentActionPattern")
    def voice_id_batch_speaker_enrollment_action_pattern(
        self,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        batch_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        data: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Domain VoiceId Batch Speaker Enrollment Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param batch_job_id: (experimental) batchJobId property. Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdBatchSpeakerEnrollmentAction.VoiceIdBatchSpeakerEnrollmentActionProps(
            action=action,
            batch_job_id=batch_job_id,
            data=data,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            source_id=source_id,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "voiceIdBatchSpeakerEnrollmentActionPattern", [options]))

    @jsii.member(jsii_name="voiceIdEvaluateSessionActionPattern")
    def voice_id_evaluate_session_action_pattern(
        self,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        session: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        system_attributes: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Domain VoiceId Evaluate Session Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdEvaluateSessionAction.VoiceIdEvaluateSessionActionProps(
            action=action,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            session=session,
            source_id=source_id,
            status=status,
            system_attributes=system_attributes,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "voiceIdEvaluateSessionActionPattern", [options]))

    @jsii.member(jsii_name="voiceIdFraudsterActionPattern")
    def voice_id_fraudster_action_pattern(
        self,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        data: typing.Optional[typing.Union["VoiceIdFraudsterAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdFraudsterAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        generated_fraudster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        watchlist_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Domain VoiceId Fraudster Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param generated_fraudster_id: (experimental) generatedFraudsterId property. Specify an array of string values to match this event if the actual value of generatedFraudsterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param watchlist_ids: (experimental) watchlistIds property. Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdFraudsterAction.VoiceIdFraudsterActionProps(
            action=action,
            data=data,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            generated_fraudster_id=generated_fraudster_id,
            source_id=source_id,
            status=status,
            watchlist_ids=watchlist_ids,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "voiceIdFraudsterActionPattern", [options]))

    @jsii.member(jsii_name="voiceIdSessionSpeakerEnrollmentActionPattern")
    def voice_id_session_speaker_enrollment_action_pattern(
        self,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        system_attributes: typing.Optional[typing.Union["VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Domain VoiceId Session Speaker Enrollment Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param session_id: (experimental) sessionId property. Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param session_name: (experimental) sessionName property. Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdSessionSpeakerEnrollmentAction.VoiceIdSessionSpeakerEnrollmentActionProps(
            action=action,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            session_id=session_id,
            session_name=session_name,
            source_id=source_id,
            status=status,
            system_attributes=system_attributes,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "voiceIdSessionSpeakerEnrollmentActionPattern", [options]))

    @jsii.member(jsii_name="voiceIdSpeakerActionPattern")
    def voice_id_speaker_action_pattern(
        self,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        data: typing.Optional[typing.Union["VoiceIdSpeakerAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdSpeakerAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        system_attributes: typing.Optional[typing.Union["VoiceIdSpeakerAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Domain VoiceId Speaker Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param generated_speaker_id: (experimental) generatedSpeakerId property. Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdSpeakerAction.VoiceIdSpeakerActionProps(
            action=action,
            data=data,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            generated_speaker_id=generated_speaker_id,
            source_id=source_id,
            status=status,
            system_attributes=system_attributes,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "voiceIdSpeakerActionPattern", [options]))

    @jsii.member(jsii_name="voiceIdStartSessionActionPattern")
    def voice_id_start_session_action_pattern(
        self,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdStartSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        session: typing.Optional[typing.Union["VoiceIdStartSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        system_attributes: typing.Optional[typing.Union["VoiceIdStartSessionAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Domain VoiceId Start Session Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdStartSessionAction.VoiceIdStartSessionActionProps(
            action=action,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            session=session,
            source_id=source_id,
            status=status,
            system_attributes=system_attributes,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "voiceIdStartSessionActionPattern", [options]))

    @jsii.member(jsii_name="voiceIdUpdateSessionActionPattern")
    def voice_id_update_session_action_pattern(
        self,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdUpdateSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        session: typing.Optional[typing.Union["VoiceIdUpdateSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Domain VoiceId Update Session Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdUpdateSessionAction.VoiceIdUpdateSessionActionProps(
            action=action,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            session=session,
            source_id=source_id,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "voiceIdUpdateSessionActionPattern", [options]))


class VoiceIdBatchFraudsterRegistrationAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchFraudsterRegistrationAction",
):
    '''(experimental) EventBridge event pattern for aws.voiceid@VoiceIdBatchFraudsterRegistrationAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        
        voice_id_batch_fraudster_registration_action = voiceid_events.VoiceIdBatchFraudsterRegistrationAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="voiceIdBatchFraudsterRegistrationActionPattern")
    @builtins.classmethod
    def voice_id_batch_fraudster_registration_action_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        batch_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        data: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for VoiceId Batch Fraudster Registration Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param batch_job_id: (experimental) batchJobId property. Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdBatchFraudsterRegistrationAction.VoiceIdBatchFraudsterRegistrationActionProps(
            action=action,
            batch_job_id=batch_job_id,
            data=data,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            source_id=source_id,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "voiceIdBatchFraudsterRegistrationActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchFraudsterRegistrationAction.Data",
        jsii_struct_bases=[],
        name_mapping={
            "data_access_role_arn": "dataAccessRoleArn",
            "input_data_config": "inputDataConfig",
            "output_data_config": "outputDataConfig",
            "registration_config": "registrationConfig",
        },
    )
    class Data:
        def __init__(
            self,
            *,
            data_access_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_data_config: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            output_data_config: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            registration_config: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Data.

            :param data_access_role_arn: (experimental) dataAccessRoleArn property. Specify an array of string values to match this event if the actual value of dataAccessRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param registration_config: (experimental) registrationConfig property. Specify an array of string values to match this event if the actual value of registrationConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                data = voiceid_events.VoiceIdBatchFraudsterRegistrationAction.Data(
                    data_access_role_arn=["dataAccessRoleArn"],
                    input_data_config=voiceid_events.VoiceIdBatchFraudsterRegistrationAction.InputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    output_data_config=voiceid_events.VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig(
                        kms_key_id=["kmsKeyId"],
                        s3_uri=["s3Uri"]
                    ),
                    registration_config=voiceid_events.VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig(
                        duplicate_registration_action=["duplicateRegistrationAction"],
                        fraudster_similarity_threshold=["fraudsterSimilarityThreshold"],
                        watchlist_ids=["watchlistIds"]
                    )
                )
            '''
            if isinstance(input_data_config, dict):
                input_data_config = VoiceIdBatchFraudsterRegistrationAction.InputDataConfig(**input_data_config)
            if isinstance(output_data_config, dict):
                output_data_config = VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig(**output_data_config)
            if isinstance(registration_config, dict):
                registration_config = VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig(**registration_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ab8f0e5469cdef5e61dd62f12dc69aa1b25070e1053e729f02e32a28711c58da)
                check_type(argname="argument data_access_role_arn", value=data_access_role_arn, expected_type=type_hints["data_access_role_arn"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument registration_config", value=registration_config, expected_type=type_hints["registration_config"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data_access_role_arn is not None:
                self._values["data_access_role_arn"] = data_access_role_arn
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if registration_config is not None:
                self._values["registration_config"] = registration_config

        @builtins.property
        def data_access_role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataAccessRoleArn property.

            Specify an array of string values to match this event if the actual value of dataAccessRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_access_role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional["VoiceIdBatchFraudsterRegistrationAction.InputDataConfig"]:
            '''(experimental) inputDataConfig property.

            Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional["VoiceIdBatchFraudsterRegistrationAction.InputDataConfig"], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig"]:
            '''(experimental) outputDataConfig property.

            Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig"], result)

        @builtins.property
        def registration_config(
            self,
        ) -> typing.Optional["VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig"]:
            '''(experimental) registrationConfig property.

            Specify an array of string values to match this event if the actual value of registrationConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("registration_config")
            return typing.cast(typing.Optional["VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Data(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchFraudsterRegistrationAction.ErrorInfo",
        jsii_struct_bases=[],
        name_mapping={
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "error_type": "errorType",
        },
    )
    class ErrorInfo:
        def __init__(
            self,
            *,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ErrorInfo.

            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_type: (experimental) errorType property. Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                error_info = voiceid_events.VoiceIdBatchFraudsterRegistrationAction.ErrorInfo(
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    error_type=["errorType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__595cd00f3cf73fadc8d1175fe0957a4c189bb8ceb04899de5d2431d16138def9)
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument error_type", value=error_type, expected_type=type_hints["error_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if error_type is not None:
                self._values["error_type"] = error_type

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorType property.

            Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ErrorInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchFraudsterRegistrationAction.InputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class InputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                input_data_config = voiceid_events.VoiceIdBatchFraudsterRegistrationAction.InputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__983c6a572e9587219c23e6718e32a56dc3dd72e4adc2e33c2577a369412c53f1)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"kms_key_id": "kmsKeyId", "s3_uri": "s3Uri"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            kms_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param kms_key_id: (experimental) kmsKeyId property. Specify an array of string values to match this event if the actual value of kmsKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                output_data_config = voiceid_events.VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig(
                    kms_key_id=["kmsKeyId"],
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9fe7c458c0fb3589343d555ffb7eee89881505fbc1405337173b0999009e6bc8)
                check_type(argname="argument kms_key_id", value=kms_key_id, expected_type=type_hints["kms_key_id"])
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if kms_key_id is not None:
                self._values["kms_key_id"] = kms_key_id
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def kms_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) kmsKeyId property.

            Specify an array of string values to match this event if the actual value of kmsKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("kms_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig",
        jsii_struct_bases=[],
        name_mapping={
            "duplicate_registration_action": "duplicateRegistrationAction",
            "fraudster_similarity_threshold": "fraudsterSimilarityThreshold",
            "watchlist_ids": "watchlistIds",
        },
    )
    class RegistrationConfig:
        def __init__(
            self,
            *,
            duplicate_registration_action: typing.Optional[typing.Sequence[builtins.str]] = None,
            fraudster_similarity_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
            watchlist_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RegistrationConfig.

            :param duplicate_registration_action: (experimental) duplicateRegistrationAction property. Specify an array of string values to match this event if the actual value of duplicateRegistrationAction is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fraudster_similarity_threshold: (experimental) fraudsterSimilarityThreshold property. Specify an array of string values to match this event if the actual value of fraudsterSimilarityThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param watchlist_ids: (experimental) watchlistIds property. Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                registration_config = voiceid_events.VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig(
                    duplicate_registration_action=["duplicateRegistrationAction"],
                    fraudster_similarity_threshold=["fraudsterSimilarityThreshold"],
                    watchlist_ids=["watchlistIds"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__20614181e1a1b2167ee32fd80168f8422546098d9af525cad5eb87668754a0fc)
                check_type(argname="argument duplicate_registration_action", value=duplicate_registration_action, expected_type=type_hints["duplicate_registration_action"])
                check_type(argname="argument fraudster_similarity_threshold", value=fraudster_similarity_threshold, expected_type=type_hints["fraudster_similarity_threshold"])
                check_type(argname="argument watchlist_ids", value=watchlist_ids, expected_type=type_hints["watchlist_ids"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if duplicate_registration_action is not None:
                self._values["duplicate_registration_action"] = duplicate_registration_action
            if fraudster_similarity_threshold is not None:
                self._values["fraudster_similarity_threshold"] = fraudster_similarity_threshold
            if watchlist_ids is not None:
                self._values["watchlist_ids"] = watchlist_ids

        @builtins.property
        def duplicate_registration_action(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) duplicateRegistrationAction property.

            Specify an array of string values to match this event if the actual value of duplicateRegistrationAction is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("duplicate_registration_action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def fraudster_similarity_threshold(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fraudsterSimilarityThreshold property.

            Specify an array of string values to match this event if the actual value of fraudsterSimilarityThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraudster_similarity_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def watchlist_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) watchlistIds property.

            Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("watchlist_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RegistrationConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchFraudsterRegistrationAction.VoiceIdBatchFraudsterRegistrationActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "batch_job_id": "batchJobId",
            "data": "data",
            "domain_id": "domainId",
            "error_info": "errorInfo",
            "event_metadata": "eventMetadata",
            "source_id": "sourceId",
            "status": "status",
        },
    )
    class VoiceIdBatchFraudsterRegistrationActionProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            batch_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            data: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
            domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_info: typing.Optional[typing.Union["VoiceIdBatchFraudsterRegistrationAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.voiceid@VoiceIdBatchFraudsterRegistrationAction event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param batch_job_id: (experimental) batchJobId property. Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
            :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_id_batch_fraudster_registration_action_props = voiceid_events.VoiceIdBatchFraudsterRegistrationAction.VoiceIdBatchFraudsterRegistrationActionProps(
                    action=["action"],
                    batch_job_id=["batchJobId"],
                    data=voiceid_events.VoiceIdBatchFraudsterRegistrationAction.Data(
                        data_access_role_arn=["dataAccessRoleArn"],
                        input_data_config=voiceid_events.VoiceIdBatchFraudsterRegistrationAction.InputDataConfig(
                            s3_uri=["s3Uri"]
                        ),
                        output_data_config=voiceid_events.VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig(
                            kms_key_id=["kmsKeyId"],
                            s3_uri=["s3Uri"]
                        ),
                        registration_config=voiceid_events.VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig(
                            duplicate_registration_action=["duplicateRegistrationAction"],
                            fraudster_similarity_threshold=["fraudsterSimilarityThreshold"],
                            watchlist_ids=["watchlistIds"]
                        )
                    ),
                    domain_id=["domainId"],
                    error_info=voiceid_events.VoiceIdBatchFraudsterRegistrationAction.ErrorInfo(
                        error_code=["errorCode"],
                        error_message=["errorMessage"],
                        error_type=["errorType"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    source_id=["sourceId"],
                    status=["status"]
                )
            '''
            if isinstance(data, dict):
                data = VoiceIdBatchFraudsterRegistrationAction.Data(**data)
            if isinstance(error_info, dict):
                error_info = VoiceIdBatchFraudsterRegistrationAction.ErrorInfo(**error_info)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1fc8dbe4b50273de65690d98ca24cb738af2156de20e8a79f648579a6729a5fe)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument batch_job_id", value=batch_job_id, expected_type=type_hints["batch_job_id"])
                check_type(argname="argument data", value=data, expected_type=type_hints["data"])
                check_type(argname="argument domain_id", value=domain_id, expected_type=type_hints["domain_id"])
                check_type(argname="argument error_info", value=error_info, expected_type=type_hints["error_info"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument source_id", value=source_id, expected_type=type_hints["source_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if batch_job_id is not None:
                self._values["batch_job_id"] = batch_job_id
            if data is not None:
                self._values["data"] = data
            if domain_id is not None:
                self._values["domain_id"] = domain_id
            if error_info is not None:
                self._values["error_info"] = error_info
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if source_id is not None:
                self._values["source_id"] = source_id
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def batch_job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) batchJobId property.

            Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("batch_job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data(
            self,
        ) -> typing.Optional["VoiceIdBatchFraudsterRegistrationAction.Data"]:
            '''(experimental) data property.

            Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data")
            return typing.cast(typing.Optional["VoiceIdBatchFraudsterRegistrationAction.Data"], result)

        @builtins.property
        def domain_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) domainId property.

            Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Domain reference

            :stability: experimental
            '''
            result = self._values.get("domain_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_info(
            self,
        ) -> typing.Optional["VoiceIdBatchFraudsterRegistrationAction.ErrorInfo"]:
            '''(experimental) errorInfo property.

            Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_info")
            return typing.cast(typing.Optional["VoiceIdBatchFraudsterRegistrationAction.ErrorInfo"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceId property.

            Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceIdBatchFraudsterRegistrationActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VoiceIdBatchSpeakerEnrollmentAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchSpeakerEnrollmentAction",
):
    '''(experimental) EventBridge event pattern for aws.voiceid@VoiceIdBatchSpeakerEnrollmentAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        
        voice_id_batch_speaker_enrollment_action = voiceid_events.VoiceIdBatchSpeakerEnrollmentAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="voiceIdBatchSpeakerEnrollmentActionPattern")
    @builtins.classmethod
    def voice_id_batch_speaker_enrollment_action_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        batch_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        data: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for VoiceId Batch Speaker Enrollment Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param batch_job_id: (experimental) batchJobId property. Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdBatchSpeakerEnrollmentAction.VoiceIdBatchSpeakerEnrollmentActionProps(
            action=action,
            batch_job_id=batch_job_id,
            data=data,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            source_id=source_id,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "voiceIdBatchSpeakerEnrollmentActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchSpeakerEnrollmentAction.Data",
        jsii_struct_bases=[],
        name_mapping={
            "data_access_role_arn": "dataAccessRoleArn",
            "enrollment_config": "enrollmentConfig",
            "input_data_config": "inputDataConfig",
            "output_data_config": "outputDataConfig",
        },
    )
    class Data:
        def __init__(
            self,
            *,
            data_access_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            enrollment_config: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            input_data_config: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            output_data_config: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Data.

            :param data_access_role_arn: (experimental) dataAccessRoleArn property. Specify an array of string values to match this event if the actual value of dataAccessRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param enrollment_config: (experimental) enrollmentConfig property. Specify an array of string values to match this event if the actual value of enrollmentConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                data = voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.Data(
                    data_access_role_arn=["dataAccessRoleArn"],
                    enrollment_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig(
                        existing_enrollment_action=["existingEnrollmentAction"],
                        fraud_detection_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig(
                            fraud_detection_action=["fraudDetectionAction"],
                            fraud_detection_threshold=["fraudDetectionThreshold"],
                            watchlist_ids=["watchlistIds"]
                        )
                    ),
                    input_data_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    output_data_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig(
                        kms_key_id=["kmsKeyId"],
                        s3_uri=["s3Uri"]
                    )
                )
            '''
            if isinstance(enrollment_config, dict):
                enrollment_config = VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig(**enrollment_config)
            if isinstance(input_data_config, dict):
                input_data_config = VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig(**input_data_config)
            if isinstance(output_data_config, dict):
                output_data_config = VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig(**output_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c9f7a1ee2953b34ba1c6e16dbb0bd29d2f6e69c2a4f6b8836f4d89072a9823d7)
                check_type(argname="argument data_access_role_arn", value=data_access_role_arn, expected_type=type_hints["data_access_role_arn"])
                check_type(argname="argument enrollment_config", value=enrollment_config, expected_type=type_hints["enrollment_config"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data_access_role_arn is not None:
                self._values["data_access_role_arn"] = data_access_role_arn
            if enrollment_config is not None:
                self._values["enrollment_config"] = enrollment_config
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config

        @builtins.property
        def data_access_role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataAccessRoleArn property.

            Specify an array of string values to match this event if the actual value of dataAccessRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_access_role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def enrollment_config(
            self,
        ) -> typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig"]:
            '''(experimental) enrollmentConfig property.

            Specify an array of string values to match this event if the actual value of enrollmentConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enrollment_config")
            return typing.cast(typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig"], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig"]:
            '''(experimental) inputDataConfig property.

            Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig"], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig"]:
            '''(experimental) outputDataConfig property.

            Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Data(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig",
        jsii_struct_bases=[],
        name_mapping={
            "existing_enrollment_action": "existingEnrollmentAction",
            "fraud_detection_config": "fraudDetectionConfig",
        },
    )
    class EnrollmentConfig:
        def __init__(
            self,
            *,
            existing_enrollment_action: typing.Optional[typing.Sequence[builtins.str]] = None,
            fraud_detection_config: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for EnrollmentConfig.

            :param existing_enrollment_action: (experimental) existingEnrollmentAction property. Specify an array of string values to match this event if the actual value of existingEnrollmentAction is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fraud_detection_config: (experimental) fraudDetectionConfig property. Specify an array of string values to match this event if the actual value of fraudDetectionConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                enrollment_config = voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig(
                    existing_enrollment_action=["existingEnrollmentAction"],
                    fraud_detection_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig(
                        fraud_detection_action=["fraudDetectionAction"],
                        fraud_detection_threshold=["fraudDetectionThreshold"],
                        watchlist_ids=["watchlistIds"]
                    )
                )
            '''
            if isinstance(fraud_detection_config, dict):
                fraud_detection_config = VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig(**fraud_detection_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e4b857b815683eb7ebf4375db4b55193045a5183fb179d2d1b783c46a962f0a9)
                check_type(argname="argument existing_enrollment_action", value=existing_enrollment_action, expected_type=type_hints["existing_enrollment_action"])
                check_type(argname="argument fraud_detection_config", value=fraud_detection_config, expected_type=type_hints["fraud_detection_config"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if existing_enrollment_action is not None:
                self._values["existing_enrollment_action"] = existing_enrollment_action
            if fraud_detection_config is not None:
                self._values["fraud_detection_config"] = fraud_detection_config

        @builtins.property
        def existing_enrollment_action(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) existingEnrollmentAction property.

            Specify an array of string values to match this event if the actual value of existingEnrollmentAction is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("existing_enrollment_action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def fraud_detection_config(
            self,
        ) -> typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig"]:
            '''(experimental) fraudDetectionConfig property.

            Specify an array of string values to match this event if the actual value of fraudDetectionConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraud_detection_config")
            return typing.cast(typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EnrollmentConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo",
        jsii_struct_bases=[],
        name_mapping={
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "error_type": "errorType",
        },
    )
    class ErrorInfo:
        def __init__(
            self,
            *,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ErrorInfo.

            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_type: (experimental) errorType property. Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                error_info = voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo(
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    error_type=["errorType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6718a3440d9cc43c8fa26f7398b68ecc91189fa7c1d1c95aaadb912d91bb83d6)
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument error_type", value=error_type, expected_type=type_hints["error_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if error_type is not None:
                self._values["error_type"] = error_type

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorType property.

            Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ErrorInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig",
        jsii_struct_bases=[],
        name_mapping={
            "fraud_detection_action": "fraudDetectionAction",
            "fraud_detection_threshold": "fraudDetectionThreshold",
            "watchlist_ids": "watchlistIds",
        },
    )
    class FraudDetectionConfig:
        def __init__(
            self,
            *,
            fraud_detection_action: typing.Optional[typing.Sequence[builtins.str]] = None,
            fraud_detection_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
            watchlist_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for FraudDetectionConfig.

            :param fraud_detection_action: (experimental) fraudDetectionAction property. Specify an array of string values to match this event if the actual value of fraudDetectionAction is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fraud_detection_threshold: (experimental) fraudDetectionThreshold property. Specify an array of string values to match this event if the actual value of fraudDetectionThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param watchlist_ids: (experimental) watchlistIds property. Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                fraud_detection_config = voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig(
                    fraud_detection_action=["fraudDetectionAction"],
                    fraud_detection_threshold=["fraudDetectionThreshold"],
                    watchlist_ids=["watchlistIds"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ec15f88918eeb52d7a958052f0557c4b7de3abc0887e0efdbb6ae08daf75433e)
                check_type(argname="argument fraud_detection_action", value=fraud_detection_action, expected_type=type_hints["fraud_detection_action"])
                check_type(argname="argument fraud_detection_threshold", value=fraud_detection_threshold, expected_type=type_hints["fraud_detection_threshold"])
                check_type(argname="argument watchlist_ids", value=watchlist_ids, expected_type=type_hints["watchlist_ids"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if fraud_detection_action is not None:
                self._values["fraud_detection_action"] = fraud_detection_action
            if fraud_detection_threshold is not None:
                self._values["fraud_detection_threshold"] = fraud_detection_threshold
            if watchlist_ids is not None:
                self._values["watchlist_ids"] = watchlist_ids

        @builtins.property
        def fraud_detection_action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fraudDetectionAction property.

            Specify an array of string values to match this event if the actual value of fraudDetectionAction is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraud_detection_action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def fraud_detection_threshold(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fraudDetectionThreshold property.

            Specify an array of string values to match this event if the actual value of fraudDetectionThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraud_detection_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def watchlist_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) watchlistIds property.

            Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("watchlist_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FraudDetectionConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class InputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                input_data_config = voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8d3e517fb6fdc59875e07a9bdd0ffbe9a2e37b90c3444e441343f6f23dde9852)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"kms_key_id": "kmsKeyId", "s3_uri": "s3Uri"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            kms_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param kms_key_id: (experimental) kmsKeyId property. Specify an array of string values to match this event if the actual value of kmsKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                output_data_config = voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig(
                    kms_key_id=["kmsKeyId"],
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4ceaadd35e56845395e2c0674db19def6f1229e6ef8d35d6f845401f047f2ea5)
                check_type(argname="argument kms_key_id", value=kms_key_id, expected_type=type_hints["kms_key_id"])
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if kms_key_id is not None:
                self._values["kms_key_id"] = kms_key_id
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def kms_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) kmsKeyId property.

            Specify an array of string values to match this event if the actual value of kmsKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("kms_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdBatchSpeakerEnrollmentAction.VoiceIdBatchSpeakerEnrollmentActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "batch_job_id": "batchJobId",
            "data": "data",
            "domain_id": "domainId",
            "error_info": "errorInfo",
            "event_metadata": "eventMetadata",
            "source_id": "sourceId",
            "status": "status",
        },
    )
    class VoiceIdBatchSpeakerEnrollmentActionProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            batch_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            data: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
            domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_info: typing.Optional[typing.Union["VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.voiceid@VoiceIdBatchSpeakerEnrollmentAction event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param batch_job_id: (experimental) batchJobId property. Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
            :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_id_batch_speaker_enrollment_action_props = voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.VoiceIdBatchSpeakerEnrollmentActionProps(
                    action=["action"],
                    batch_job_id=["batchJobId"],
                    data=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.Data(
                        data_access_role_arn=["dataAccessRoleArn"],
                        enrollment_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig(
                            existing_enrollment_action=["existingEnrollmentAction"],
                            fraud_detection_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig(
                                fraud_detection_action=["fraudDetectionAction"],
                                fraud_detection_threshold=["fraudDetectionThreshold"],
                                watchlist_ids=["watchlistIds"]
                            )
                        ),
                        input_data_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig(
                            s3_uri=["s3Uri"]
                        ),
                        output_data_config=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig(
                            kms_key_id=["kmsKeyId"],
                            s3_uri=["s3Uri"]
                        )
                    ),
                    domain_id=["domainId"],
                    error_info=voiceid_events.VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo(
                        error_code=["errorCode"],
                        error_message=["errorMessage"],
                        error_type=["errorType"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    source_id=["sourceId"],
                    status=["status"]
                )
            '''
            if isinstance(data, dict):
                data = VoiceIdBatchSpeakerEnrollmentAction.Data(**data)
            if isinstance(error_info, dict):
                error_info = VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo(**error_info)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a466159d22bda01bed7e5b8863057c5b3ef0c5f193cdfa24ac3fe51a875487a7)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument batch_job_id", value=batch_job_id, expected_type=type_hints["batch_job_id"])
                check_type(argname="argument data", value=data, expected_type=type_hints["data"])
                check_type(argname="argument domain_id", value=domain_id, expected_type=type_hints["domain_id"])
                check_type(argname="argument error_info", value=error_info, expected_type=type_hints["error_info"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument source_id", value=source_id, expected_type=type_hints["source_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if batch_job_id is not None:
                self._values["batch_job_id"] = batch_job_id
            if data is not None:
                self._values["data"] = data
            if domain_id is not None:
                self._values["domain_id"] = domain_id
            if error_info is not None:
                self._values["error_info"] = error_info
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if source_id is not None:
                self._values["source_id"] = source_id
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def batch_job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) batchJobId property.

            Specify an array of string values to match this event if the actual value of batchJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("batch_job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data(self) -> typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.Data"]:
            '''(experimental) data property.

            Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data")
            return typing.cast(typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.Data"], result)

        @builtins.property
        def domain_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) domainId property.

            Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Domain reference

            :stability: experimental
            '''
            result = self._values.get("domain_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_info(
            self,
        ) -> typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo"]:
            '''(experimental) errorInfo property.

            Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_info")
            return typing.cast(typing.Optional["VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceId property.

            Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceIdBatchSpeakerEnrollmentActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VoiceIdEvaluateSessionAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction",
):
    '''(experimental) EventBridge event pattern for aws.voiceid@VoiceIdEvaluateSessionAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        
        voice_id_evaluate_session_action = voiceid_events.VoiceIdEvaluateSessionAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="voiceIdEvaluateSessionActionPattern")
    @builtins.classmethod
    def voice_id_evaluate_session_action_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        session: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        system_attributes: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for VoiceId Evaluate Session Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdEvaluateSessionAction.VoiceIdEvaluateSessionActionProps(
            action=action,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            session=session,
            source_id=source_id,
            status=status,
            system_attributes=system_attributes,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "voiceIdEvaluateSessionActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.AuthenticationResult",
        jsii_struct_bases=[],
        name_mapping={
            "audio_aggregation_ended_at": "audioAggregationEndedAt",
            "audio_aggregation_started_at": "audioAggregationStartedAt",
            "authentication_result_id": "authenticationResultId",
            "configuration": "configuration",
            "decision": "decision",
            "score": "score",
        },
    )
    class AuthenticationResult:
        def __init__(
            self,
            *,
            audio_aggregation_ended_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            audio_aggregation_started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            authentication_result_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            configuration: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.ConfigurationAuthentication", typing.Dict[builtins.str, typing.Any]]] = None,
            decision: typing.Optional[typing.Sequence[builtins.str]] = None,
            score: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AuthenticationResult.

            :param audio_aggregation_ended_at: (experimental) audioAggregationEndedAt property. Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param audio_aggregation_started_at: (experimental) audioAggregationStartedAt property. Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param authentication_result_id: (experimental) authenticationResultId property. Specify an array of string values to match this event if the actual value of authenticationResultId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param configuration: (experimental) configuration property. Specify an array of string values to match this event if the actual value of configuration is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param decision: (experimental) decision property. Specify an array of string values to match this event if the actual value of decision is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param score: (experimental) score property. Specify an array of string values to match this event if the actual value of score is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                authentication_result = voiceid_events.VoiceIdEvaluateSessionAction.AuthenticationResult(
                    audio_aggregation_ended_at=["audioAggregationEndedAt"],
                    audio_aggregation_started_at=["audioAggregationStartedAt"],
                    authentication_result_id=["authenticationResultId"],
                    configuration=voiceid_events.VoiceIdEvaluateSessionAction.ConfigurationAuthentication(
                        acceptance_threshold=["acceptanceThreshold"]
                    ),
                    decision=["decision"],
                    score=["score"]
                )
            '''
            if isinstance(configuration, dict):
                configuration = VoiceIdEvaluateSessionAction.ConfigurationAuthentication(**configuration)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6f57ec2eb4da94f6f0a6ed67b6080467a004e1ceae3b8350b58b77e9b9a0a55d)
                check_type(argname="argument audio_aggregation_ended_at", value=audio_aggregation_ended_at, expected_type=type_hints["audio_aggregation_ended_at"])
                check_type(argname="argument audio_aggregation_started_at", value=audio_aggregation_started_at, expected_type=type_hints["audio_aggregation_started_at"])
                check_type(argname="argument authentication_result_id", value=authentication_result_id, expected_type=type_hints["authentication_result_id"])
                check_type(argname="argument configuration", value=configuration, expected_type=type_hints["configuration"])
                check_type(argname="argument decision", value=decision, expected_type=type_hints["decision"])
                check_type(argname="argument score", value=score, expected_type=type_hints["score"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if audio_aggregation_ended_at is not None:
                self._values["audio_aggregation_ended_at"] = audio_aggregation_ended_at
            if audio_aggregation_started_at is not None:
                self._values["audio_aggregation_started_at"] = audio_aggregation_started_at
            if authentication_result_id is not None:
                self._values["authentication_result_id"] = authentication_result_id
            if configuration is not None:
                self._values["configuration"] = configuration
            if decision is not None:
                self._values["decision"] = decision
            if score is not None:
                self._values["score"] = score

        @builtins.property
        def audio_aggregation_ended_at(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationEndedAt property.

            Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_ended_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def audio_aggregation_started_at(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationStartedAt property.

            Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_started_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def authentication_result_id(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) authenticationResultId property.

            Specify an array of string values to match this event if the actual value of authenticationResultId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("authentication_result_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def configuration(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.ConfigurationAuthentication"]:
            '''(experimental) configuration property.

            Specify an array of string values to match this event if the actual value of configuration is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("configuration")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.ConfigurationAuthentication"], result)

        @builtins.property
        def decision(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) decision property.

            Specify an array of string values to match this event if the actual value of decision is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("decision")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def score(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) score property.

            Specify an array of string values to match this event if the actual value of score is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("score")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AuthenticationResult(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.ConfigurationAuthentication",
        jsii_struct_bases=[],
        name_mapping={"acceptance_threshold": "acceptanceThreshold"},
    )
    class ConfigurationAuthentication:
        def __init__(
            self,
            *,
            acceptance_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Configuration_Authentication.

            :param acceptance_threshold: (experimental) acceptanceThreshold property. Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                configuration_authentication = voiceid_events.VoiceIdEvaluateSessionAction.ConfigurationAuthentication(
                    acceptance_threshold=["acceptanceThreshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b6703d383a4c759b0d7ec5f95c29272027f6a91b6f3d38287147839e1f607369)
                check_type(argname="argument acceptance_threshold", value=acceptance_threshold, expected_type=type_hints["acceptance_threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if acceptance_threshold is not None:
                self._values["acceptance_threshold"] = acceptance_threshold

        @builtins.property
        def acceptance_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) acceptanceThreshold property.

            Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("acceptance_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ConfigurationAuthentication(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.ConfigurationFraud",
        jsii_struct_bases=[],
        name_mapping={
            "risk_threshold": "riskThreshold",
            "watchlist_id": "watchlistId",
        },
    )
    class ConfigurationFraud:
        def __init__(
            self,
            *,
            risk_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
            watchlist_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Configuration_Fraud.

            :param risk_threshold: (experimental) riskThreshold property. Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param watchlist_id: (experimental) watchlistId property. Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                configuration_fraud = voiceid_events.VoiceIdEvaluateSessionAction.ConfigurationFraud(
                    risk_threshold=["riskThreshold"],
                    watchlist_id=["watchlistId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9db8a847b994a9d73c863acea6f91d7cb9fab6c1bef5cba24575f44ab1f3e704)
                check_type(argname="argument risk_threshold", value=risk_threshold, expected_type=type_hints["risk_threshold"])
                check_type(argname="argument watchlist_id", value=watchlist_id, expected_type=type_hints["watchlist_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if risk_threshold is not None:
                self._values["risk_threshold"] = risk_threshold
            if watchlist_id is not None:
                self._values["watchlist_id"] = watchlist_id

        @builtins.property
        def risk_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) riskThreshold property.

            Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("risk_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def watchlist_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) watchlistId property.

            Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("watchlist_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ConfigurationFraud(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.ErrorInfo",
        jsii_struct_bases=[],
        name_mapping={
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "error_type": "errorType",
        },
    )
    class ErrorInfo:
        def __init__(
            self,
            *,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ErrorInfo.

            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_type: (experimental) errorType property. Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                error_info = voiceid_events.VoiceIdEvaluateSessionAction.ErrorInfo(
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    error_type=["errorType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__896d3992d0e438671b27d9c6bd24187215e6711d55166249d7274082ec91bcd0)
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument error_type", value=error_type, expected_type=type_hints["error_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if error_type is not None:
                self._values["error_type"] = error_type

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorType property.

            Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ErrorInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.FraudDetectionResult",
        jsii_struct_bases=[],
        name_mapping={
            "audio_aggregation_ended_at": "audioAggregationEndedAt",
            "audio_aggregation_started_at": "audioAggregationStartedAt",
            "configuration": "configuration",
            "decision": "decision",
            "fraud_detection_result_id": "fraudDetectionResultId",
            "reasons": "reasons",
            "risk_details": "riskDetails",
        },
    )
    class FraudDetectionResult:
        def __init__(
            self,
            *,
            audio_aggregation_ended_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            audio_aggregation_started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            configuration: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.ConfigurationFraud", typing.Dict[builtins.str, typing.Any]]] = None,
            decision: typing.Optional[typing.Sequence[builtins.str]] = None,
            fraud_detection_result_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            reasons: typing.Optional[typing.Sequence[builtins.str]] = None,
            risk_details: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.RiskDetails", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for FraudDetectionResult.

            :param audio_aggregation_ended_at: (experimental) audioAggregationEndedAt property. Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param audio_aggregation_started_at: (experimental) audioAggregationStartedAt property. Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param configuration: (experimental) configuration property. Specify an array of string values to match this event if the actual value of configuration is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param decision: (experimental) decision property. Specify an array of string values to match this event if the actual value of decision is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fraud_detection_result_id: (experimental) fraudDetectionResultId property. Specify an array of string values to match this event if the actual value of fraudDetectionResultId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reasons: (experimental) reasons property. Specify an array of string values to match this event if the actual value of reasons is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param risk_details: (experimental) riskDetails property. Specify an array of string values to match this event if the actual value of riskDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                fraud_detection_result = voiceid_events.VoiceIdEvaluateSessionAction.FraudDetectionResult(
                    audio_aggregation_ended_at=["audioAggregationEndedAt"],
                    audio_aggregation_started_at=["audioAggregationStartedAt"],
                    configuration=voiceid_events.VoiceIdEvaluateSessionAction.ConfigurationFraud(
                        risk_threshold=["riskThreshold"],
                        watchlist_id=["watchlistId"]
                    ),
                    decision=["decision"],
                    fraud_detection_result_id=["fraudDetectionResultId"],
                    reasons=["reasons"],
                    risk_details=voiceid_events.VoiceIdEvaluateSessionAction.RiskDetails(
                        known_fraudster_risk=voiceid_events.VoiceIdEvaluateSessionAction.KnownFraudsterRisk(
                            generated_fraudster_id=["generatedFraudsterId"],
                            risk_score=["riskScore"]
                        ),
                        voice_spoofing_risk=voiceid_events.VoiceIdEvaluateSessionAction.VoiceSpoofingRisk(
                            risk_score=["riskScore"]
                        )
                    )
                )
            '''
            if isinstance(configuration, dict):
                configuration = VoiceIdEvaluateSessionAction.ConfigurationFraud(**configuration)
            if isinstance(risk_details, dict):
                risk_details = VoiceIdEvaluateSessionAction.RiskDetails(**risk_details)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f20faaedd6e014a5705ec23a72b1fb12b5120887a7eeb8ca8d847bebc124b616)
                check_type(argname="argument audio_aggregation_ended_at", value=audio_aggregation_ended_at, expected_type=type_hints["audio_aggregation_ended_at"])
                check_type(argname="argument audio_aggregation_started_at", value=audio_aggregation_started_at, expected_type=type_hints["audio_aggregation_started_at"])
                check_type(argname="argument configuration", value=configuration, expected_type=type_hints["configuration"])
                check_type(argname="argument decision", value=decision, expected_type=type_hints["decision"])
                check_type(argname="argument fraud_detection_result_id", value=fraud_detection_result_id, expected_type=type_hints["fraud_detection_result_id"])
                check_type(argname="argument reasons", value=reasons, expected_type=type_hints["reasons"])
                check_type(argname="argument risk_details", value=risk_details, expected_type=type_hints["risk_details"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if audio_aggregation_ended_at is not None:
                self._values["audio_aggregation_ended_at"] = audio_aggregation_ended_at
            if audio_aggregation_started_at is not None:
                self._values["audio_aggregation_started_at"] = audio_aggregation_started_at
            if configuration is not None:
                self._values["configuration"] = configuration
            if decision is not None:
                self._values["decision"] = decision
            if fraud_detection_result_id is not None:
                self._values["fraud_detection_result_id"] = fraud_detection_result_id
            if reasons is not None:
                self._values["reasons"] = reasons
            if risk_details is not None:
                self._values["risk_details"] = risk_details

        @builtins.property
        def audio_aggregation_ended_at(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationEndedAt property.

            Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_ended_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def audio_aggregation_started_at(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationStartedAt property.

            Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_started_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def configuration(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.ConfigurationFraud"]:
            '''(experimental) configuration property.

            Specify an array of string values to match this event if the actual value of configuration is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("configuration")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.ConfigurationFraud"], result)

        @builtins.property
        def decision(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) decision property.

            Specify an array of string values to match this event if the actual value of decision is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("decision")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def fraud_detection_result_id(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fraudDetectionResultId property.

            Specify an array of string values to match this event if the actual value of fraudDetectionResultId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraud_detection_result_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reasons(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reasons property.

            Specify an array of string values to match this event if the actual value of reasons is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reasons")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def risk_details(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.RiskDetails"]:
            '''(experimental) riskDetails property.

            Specify an array of string values to match this event if the actual value of riskDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("risk_details")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.RiskDetails"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FraudDetectionResult(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.KnownFraudsterRisk",
        jsii_struct_bases=[],
        name_mapping={
            "generated_fraudster_id": "generatedFraudsterId",
            "risk_score": "riskScore",
        },
    )
    class KnownFraudsterRisk:
        def __init__(
            self,
            *,
            generated_fraudster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            risk_score: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for KnownFraudsterRisk.

            :param generated_fraudster_id: (experimental) generatedFraudsterId property. Specify an array of string values to match this event if the actual value of generatedFraudsterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param risk_score: (experimental) riskScore property. Specify an array of string values to match this event if the actual value of riskScore is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                known_fraudster_risk = voiceid_events.VoiceIdEvaluateSessionAction.KnownFraudsterRisk(
                    generated_fraudster_id=["generatedFraudsterId"],
                    risk_score=["riskScore"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__14acca7ab9e8966b00c2ba37e7748bd22b887df35e422e42a7366b57d878339e)
                check_type(argname="argument generated_fraudster_id", value=generated_fraudster_id, expected_type=type_hints["generated_fraudster_id"])
                check_type(argname="argument risk_score", value=risk_score, expected_type=type_hints["risk_score"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if generated_fraudster_id is not None:
                self._values["generated_fraudster_id"] = generated_fraudster_id
            if risk_score is not None:
                self._values["risk_score"] = risk_score

        @builtins.property
        def generated_fraudster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) generatedFraudsterId property.

            Specify an array of string values to match this event if the actual value of generatedFraudsterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("generated_fraudster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def risk_score(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) riskScore property.

            Specify an array of string values to match this event if the actual value of riskScore is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("risk_score")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "KnownFraudsterRisk(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.RiskDetails",
        jsii_struct_bases=[],
        name_mapping={
            "known_fraudster_risk": "knownFraudsterRisk",
            "voice_spoofing_risk": "voiceSpoofingRisk",
        },
    )
    class RiskDetails:
        def __init__(
            self,
            *,
            known_fraudster_risk: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.KnownFraudsterRisk", typing.Dict[builtins.str, typing.Any]]] = None,
            voice_spoofing_risk: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.VoiceSpoofingRisk", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for RiskDetails.

            :param known_fraudster_risk: (experimental) knownFraudsterRisk property. Specify an array of string values to match this event if the actual value of knownFraudsterRisk is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param voice_spoofing_risk: (experimental) voiceSpoofingRisk property. Specify an array of string values to match this event if the actual value of voiceSpoofingRisk is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                risk_details = voiceid_events.VoiceIdEvaluateSessionAction.RiskDetails(
                    known_fraudster_risk=voiceid_events.VoiceIdEvaluateSessionAction.KnownFraudsterRisk(
                        generated_fraudster_id=["generatedFraudsterId"],
                        risk_score=["riskScore"]
                    ),
                    voice_spoofing_risk=voiceid_events.VoiceIdEvaluateSessionAction.VoiceSpoofingRisk(
                        risk_score=["riskScore"]
                    )
                )
            '''
            if isinstance(known_fraudster_risk, dict):
                known_fraudster_risk = VoiceIdEvaluateSessionAction.KnownFraudsterRisk(**known_fraudster_risk)
            if isinstance(voice_spoofing_risk, dict):
                voice_spoofing_risk = VoiceIdEvaluateSessionAction.VoiceSpoofingRisk(**voice_spoofing_risk)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ffd9aa6a9198ea25ed52da627728a1acdf352d7b7cfd96ba05f6b772e108566d)
                check_type(argname="argument known_fraudster_risk", value=known_fraudster_risk, expected_type=type_hints["known_fraudster_risk"])
                check_type(argname="argument voice_spoofing_risk", value=voice_spoofing_risk, expected_type=type_hints["voice_spoofing_risk"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if known_fraudster_risk is not None:
                self._values["known_fraudster_risk"] = known_fraudster_risk
            if voice_spoofing_risk is not None:
                self._values["voice_spoofing_risk"] = voice_spoofing_risk

        @builtins.property
        def known_fraudster_risk(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.KnownFraudsterRisk"]:
            '''(experimental) knownFraudsterRisk property.

            Specify an array of string values to match this event if the actual value of knownFraudsterRisk is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("known_fraudster_risk")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.KnownFraudsterRisk"], result)

        @builtins.property
        def voice_spoofing_risk(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.VoiceSpoofingRisk"]:
            '''(experimental) voiceSpoofingRisk property.

            Specify an array of string values to match this event if the actual value of voiceSpoofingRisk is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("voice_spoofing_risk")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.VoiceSpoofingRisk"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RiskDetails(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.Session",
        jsii_struct_bases=[],
        name_mapping={
            "authentication_result": "authenticationResult",
            "fraud_detection_result": "fraudDetectionResult",
            "generated_speaker_id": "generatedSpeakerId",
            "session_id": "sessionId",
            "session_name": "sessionName",
            "streaming_status": "streamingStatus",
        },
    )
    class Session:
        def __init__(
            self,
            *,
            authentication_result: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.AuthenticationResult", typing.Dict[builtins.str, typing.Any]]] = None,
            fraud_detection_result: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.FraudDetectionResult", typing.Dict[builtins.str, typing.Any]]] = None,
            generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            streaming_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Session.

            :param authentication_result: (experimental) authenticationResult property. Specify an array of string values to match this event if the actual value of authenticationResult is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fraud_detection_result: (experimental) fraudDetectionResult property. Specify an array of string values to match this event if the actual value of fraudDetectionResult is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param generated_speaker_id: (experimental) generatedSpeakerId property. Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_id: (experimental) sessionId property. Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_name: (experimental) sessionName property. Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param streaming_status: (experimental) streamingStatus property. Specify an array of string values to match this event if the actual value of streamingStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                session = voiceid_events.VoiceIdEvaluateSessionAction.Session(
                    authentication_result=voiceid_events.VoiceIdEvaluateSessionAction.AuthenticationResult(
                        audio_aggregation_ended_at=["audioAggregationEndedAt"],
                        audio_aggregation_started_at=["audioAggregationStartedAt"],
                        authentication_result_id=["authenticationResultId"],
                        configuration=voiceid_events.VoiceIdEvaluateSessionAction.ConfigurationAuthentication(
                            acceptance_threshold=["acceptanceThreshold"]
                        ),
                        decision=["decision"],
                        score=["score"]
                    ),
                    fraud_detection_result=voiceid_events.VoiceIdEvaluateSessionAction.FraudDetectionResult(
                        audio_aggregation_ended_at=["audioAggregationEndedAt"],
                        audio_aggregation_started_at=["audioAggregationStartedAt"],
                        configuration=voiceid_events.VoiceIdEvaluateSessionAction.ConfigurationFraud(
                            risk_threshold=["riskThreshold"],
                            watchlist_id=["watchlistId"]
                        ),
                        decision=["decision"],
                        fraud_detection_result_id=["fraudDetectionResultId"],
                        reasons=["reasons"],
                        risk_details=voiceid_events.VoiceIdEvaluateSessionAction.RiskDetails(
                            known_fraudster_risk=voiceid_events.VoiceIdEvaluateSessionAction.KnownFraudsterRisk(
                                generated_fraudster_id=["generatedFraudsterId"],
                                risk_score=["riskScore"]
                            ),
                            voice_spoofing_risk=voiceid_events.VoiceIdEvaluateSessionAction.VoiceSpoofingRisk(
                                risk_score=["riskScore"]
                            )
                        )
                    ),
                    generated_speaker_id=["generatedSpeakerId"],
                    session_id=["sessionId"],
                    session_name=["sessionName"],
                    streaming_status=["streamingStatus"]
                )
            '''
            if isinstance(authentication_result, dict):
                authentication_result = VoiceIdEvaluateSessionAction.AuthenticationResult(**authentication_result)
            if isinstance(fraud_detection_result, dict):
                fraud_detection_result = VoiceIdEvaluateSessionAction.FraudDetectionResult(**fraud_detection_result)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d15f8b611975bf0b29ef948aeabba21bebd752be9fbd1d70453f2f95598f1157)
                check_type(argname="argument authentication_result", value=authentication_result, expected_type=type_hints["authentication_result"])
                check_type(argname="argument fraud_detection_result", value=fraud_detection_result, expected_type=type_hints["fraud_detection_result"])
                check_type(argname="argument generated_speaker_id", value=generated_speaker_id, expected_type=type_hints["generated_speaker_id"])
                check_type(argname="argument session_id", value=session_id, expected_type=type_hints["session_id"])
                check_type(argname="argument session_name", value=session_name, expected_type=type_hints["session_name"])
                check_type(argname="argument streaming_status", value=streaming_status, expected_type=type_hints["streaming_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if authentication_result is not None:
                self._values["authentication_result"] = authentication_result
            if fraud_detection_result is not None:
                self._values["fraud_detection_result"] = fraud_detection_result
            if generated_speaker_id is not None:
                self._values["generated_speaker_id"] = generated_speaker_id
            if session_id is not None:
                self._values["session_id"] = session_id
            if session_name is not None:
                self._values["session_name"] = session_name
            if streaming_status is not None:
                self._values["streaming_status"] = streaming_status

        @builtins.property
        def authentication_result(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.AuthenticationResult"]:
            '''(experimental) authenticationResult property.

            Specify an array of string values to match this event if the actual value of authenticationResult is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("authentication_result")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.AuthenticationResult"], result)

        @builtins.property
        def fraud_detection_result(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.FraudDetectionResult"]:
            '''(experimental) fraudDetectionResult property.

            Specify an array of string values to match this event if the actual value of fraudDetectionResult is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraud_detection_result")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.FraudDetectionResult"], result)

        @builtins.property
        def generated_speaker_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) generatedSpeakerId property.

            Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("generated_speaker_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sessionId property.

            Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sessionName property.

            Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def streaming_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) streamingStatus property.

            Specify an array of string values to match this event if the actual value of streamingStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("streaming_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Session(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.SystemAttributes",
        jsii_struct_bases=[],
        name_mapping={
            "aws_connect_original_contact_arn": "awsConnectOriginalContactArn",
        },
    )
    class SystemAttributes:
        def __init__(
            self,
            *,
            aws_connect_original_contact_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SystemAttributes.

            :param aws_connect_original_contact_arn: (experimental) aws-connect-OriginalContactArn property. Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                system_attributes = voiceid_events.VoiceIdEvaluateSessionAction.SystemAttributes(
                    aws_connect_original_contact_arn=["awsConnectOriginalContactArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2e00a1b319ffa8954c1d176357850c119666a382351547f2aa1677876f2de689)
                check_type(argname="argument aws_connect_original_contact_arn", value=aws_connect_original_contact_arn, expected_type=type_hints["aws_connect_original_contact_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_connect_original_contact_arn is not None:
                self._values["aws_connect_original_contact_arn"] = aws_connect_original_contact_arn

        @builtins.property
        def aws_connect_original_contact_arn(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) aws-connect-OriginalContactArn property.

            Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_connect_original_contact_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SystemAttributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.VoiceIdEvaluateSessionActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "domain_id": "domainId",
            "error_info": "errorInfo",
            "event_metadata": "eventMetadata",
            "session": "session",
            "source_id": "sourceId",
            "status": "status",
            "system_attributes": "systemAttributes",
        },
    )
    class VoiceIdEvaluateSessionActionProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_info: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            session: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
            source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            system_attributes: typing.Optional[typing.Union["VoiceIdEvaluateSessionAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.voiceid@VoiceIdEvaluateSessionAction event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
            :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_id_evaluate_session_action_props = voiceid_events.VoiceIdEvaluateSessionAction.VoiceIdEvaluateSessionActionProps(
                    action=["action"],
                    domain_id=["domainId"],
                    error_info=voiceid_events.VoiceIdEvaluateSessionAction.ErrorInfo(
                        error_code=["errorCode"],
                        error_message=["errorMessage"],
                        error_type=["errorType"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    session=voiceid_events.VoiceIdEvaluateSessionAction.Session(
                        authentication_result=voiceid_events.VoiceIdEvaluateSessionAction.AuthenticationResult(
                            audio_aggregation_ended_at=["audioAggregationEndedAt"],
                            audio_aggregation_started_at=["audioAggregationStartedAt"],
                            authentication_result_id=["authenticationResultId"],
                            configuration=voiceid_events.VoiceIdEvaluateSessionAction.ConfigurationAuthentication(
                                acceptance_threshold=["acceptanceThreshold"]
                            ),
                            decision=["decision"],
                            score=["score"]
                        ),
                        fraud_detection_result=voiceid_events.VoiceIdEvaluateSessionAction.FraudDetectionResult(
                            audio_aggregation_ended_at=["audioAggregationEndedAt"],
                            audio_aggregation_started_at=["audioAggregationStartedAt"],
                            configuration=voiceid_events.VoiceIdEvaluateSessionAction.ConfigurationFraud(
                                risk_threshold=["riskThreshold"],
                                watchlist_id=["watchlistId"]
                            ),
                            decision=["decision"],
                            fraud_detection_result_id=["fraudDetectionResultId"],
                            reasons=["reasons"],
                            risk_details=voiceid_events.VoiceIdEvaluateSessionAction.RiskDetails(
                                known_fraudster_risk=voiceid_events.VoiceIdEvaluateSessionAction.KnownFraudsterRisk(
                                    generated_fraudster_id=["generatedFraudsterId"],
                                    risk_score=["riskScore"]
                                ),
                                voice_spoofing_risk=voiceid_events.VoiceIdEvaluateSessionAction.VoiceSpoofingRisk(
                                    risk_score=["riskScore"]
                                )
                            )
                        ),
                        generated_speaker_id=["generatedSpeakerId"],
                        session_id=["sessionId"],
                        session_name=["sessionName"],
                        streaming_status=["streamingStatus"]
                    ),
                    source_id=["sourceId"],
                    status=["status"],
                    system_attributes=voiceid_events.VoiceIdEvaluateSessionAction.SystemAttributes(
                        aws_connect_original_contact_arn=["awsConnectOriginalContactArn"]
                    )
                )
            '''
            if isinstance(error_info, dict):
                error_info = VoiceIdEvaluateSessionAction.ErrorInfo(**error_info)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(session, dict):
                session = VoiceIdEvaluateSessionAction.Session(**session)
            if isinstance(system_attributes, dict):
                system_attributes = VoiceIdEvaluateSessionAction.SystemAttributes(**system_attributes)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b82a78695fc08941f2bfbb5beeb1da634d05bc96d41fa33b4753143edbc5a6dc)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument domain_id", value=domain_id, expected_type=type_hints["domain_id"])
                check_type(argname="argument error_info", value=error_info, expected_type=type_hints["error_info"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument session", value=session, expected_type=type_hints["session"])
                check_type(argname="argument source_id", value=source_id, expected_type=type_hints["source_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument system_attributes", value=system_attributes, expected_type=type_hints["system_attributes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if domain_id is not None:
                self._values["domain_id"] = domain_id
            if error_info is not None:
                self._values["error_info"] = error_info
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if session is not None:
                self._values["session"] = session
            if source_id is not None:
                self._values["source_id"] = source_id
            if status is not None:
                self._values["status"] = status
            if system_attributes is not None:
                self._values["system_attributes"] = system_attributes

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def domain_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) domainId property.

            Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Domain reference

            :stability: experimental
            '''
            result = self._values.get("domain_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_info(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.ErrorInfo"]:
            '''(experimental) errorInfo property.

            Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_info")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.ErrorInfo"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def session(self) -> typing.Optional["VoiceIdEvaluateSessionAction.Session"]:
            '''(experimental) session property.

            Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.Session"], result)

        @builtins.property
        def source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceId property.

            Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def system_attributes(
            self,
        ) -> typing.Optional["VoiceIdEvaluateSessionAction.SystemAttributes"]:
            '''(experimental) systemAttributes property.

            Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("system_attributes")
            return typing.cast(typing.Optional["VoiceIdEvaluateSessionAction.SystemAttributes"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceIdEvaluateSessionActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdEvaluateSessionAction.VoiceSpoofingRisk",
        jsii_struct_bases=[],
        name_mapping={"risk_score": "riskScore"},
    )
    class VoiceSpoofingRisk:
        def __init__(
            self,
            *,
            risk_score: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for VoiceSpoofingRisk.

            :param risk_score: (experimental) riskScore property. Specify an array of string values to match this event if the actual value of riskScore is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_spoofing_risk = voiceid_events.VoiceIdEvaluateSessionAction.VoiceSpoofingRisk(
                    risk_score=["riskScore"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c084610e6e978f091ecd25a38ef92c65a367b2756de7de053654f303e0080faa)
                check_type(argname="argument risk_score", value=risk_score, expected_type=type_hints["risk_score"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if risk_score is not None:
                self._values["risk_score"] = risk_score

        @builtins.property
        def risk_score(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) riskScore property.

            Specify an array of string values to match this event if the actual value of riskScore is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("risk_score")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceSpoofingRisk(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VoiceIdFraudsterAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdFraudsterAction",
):
    '''(experimental) EventBridge event pattern for aws.voiceid@VoiceIdFraudsterAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        
        voice_id_fraudster_action = voiceid_events.VoiceIdFraudsterAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="voiceIdFraudsterActionPattern")
    @builtins.classmethod
    def voice_id_fraudster_action_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        data: typing.Optional[typing.Union["VoiceIdFraudsterAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdFraudsterAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        generated_fraudster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        watchlist_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for VoiceId Fraudster Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param generated_fraudster_id: (experimental) generatedFraudsterId property. Specify an array of string values to match this event if the actual value of generatedFraudsterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param watchlist_ids: (experimental) watchlistIds property. Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdFraudsterAction.VoiceIdFraudsterActionProps(
            action=action,
            data=data,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            generated_fraudster_id=generated_fraudster_id,
            source_id=source_id,
            status=status,
            watchlist_ids=watchlist_ids,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "voiceIdFraudsterActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdFraudsterAction.Data",
        jsii_struct_bases=[],
        name_mapping={
            "registration_source": "registrationSource",
            "registration_source_id": "registrationSourceId",
            "registration_status": "registrationStatus",
        },
    )
    class Data:
        def __init__(
            self,
            *,
            registration_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            registration_source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            registration_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Data.

            :param registration_source: (experimental) registrationSource property. Specify an array of string values to match this event if the actual value of registrationSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param registration_source_id: (experimental) registrationSourceId property. Specify an array of string values to match this event if the actual value of registrationSourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param registration_status: (experimental) registrationStatus property. Specify an array of string values to match this event if the actual value of registrationStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                data = voiceid_events.VoiceIdFraudsterAction.Data(
                    registration_source=["registrationSource"],
                    registration_source_id=["registrationSourceId"],
                    registration_status=["registrationStatus"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b5750c95ac5ac939d9ad8642bd0e850198efa153c733fc3973a4038297e25d24)
                check_type(argname="argument registration_source", value=registration_source, expected_type=type_hints["registration_source"])
                check_type(argname="argument registration_source_id", value=registration_source_id, expected_type=type_hints["registration_source_id"])
                check_type(argname="argument registration_status", value=registration_status, expected_type=type_hints["registration_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if registration_source is not None:
                self._values["registration_source"] = registration_source
            if registration_source_id is not None:
                self._values["registration_source_id"] = registration_source_id
            if registration_status is not None:
                self._values["registration_status"] = registration_status

        @builtins.property
        def registration_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) registrationSource property.

            Specify an array of string values to match this event if the actual value of registrationSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("registration_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def registration_source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) registrationSourceId property.

            Specify an array of string values to match this event if the actual value of registrationSourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("registration_source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def registration_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) registrationStatus property.

            Specify an array of string values to match this event if the actual value of registrationStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("registration_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Data(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdFraudsterAction.ErrorInfo",
        jsii_struct_bases=[],
        name_mapping={
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "error_type": "errorType",
        },
    )
    class ErrorInfo:
        def __init__(
            self,
            *,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ErrorInfo.

            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_type: (experimental) errorType property. Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                error_info = voiceid_events.VoiceIdFraudsterAction.ErrorInfo(
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    error_type=["errorType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ebe682a1cb5a969258ba7cd95141764e4a8726beeacad9e6a14ac5d360cdd3f5)
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument error_type", value=error_type, expected_type=type_hints["error_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if error_type is not None:
                self._values["error_type"] = error_type

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorType property.

            Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ErrorInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdFraudsterAction.VoiceIdFraudsterActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "data": "data",
            "domain_id": "domainId",
            "error_info": "errorInfo",
            "event_metadata": "eventMetadata",
            "generated_fraudster_id": "generatedFraudsterId",
            "source_id": "sourceId",
            "status": "status",
            "watchlist_ids": "watchlistIds",
        },
    )
    class VoiceIdFraudsterActionProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            data: typing.Optional[typing.Union["VoiceIdFraudsterAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
            domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_info: typing.Optional[typing.Union["VoiceIdFraudsterAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            generated_fraudster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            watchlist_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.voiceid@VoiceIdFraudsterAction event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
            :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param generated_fraudster_id: (experimental) generatedFraudsterId property. Specify an array of string values to match this event if the actual value of generatedFraudsterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param watchlist_ids: (experimental) watchlistIds property. Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_id_fraudster_action_props = voiceid_events.VoiceIdFraudsterAction.VoiceIdFraudsterActionProps(
                    action=["action"],
                    data=voiceid_events.VoiceIdFraudsterAction.Data(
                        registration_source=["registrationSource"],
                        registration_source_id=["registrationSourceId"],
                        registration_status=["registrationStatus"]
                    ),
                    domain_id=["domainId"],
                    error_info=voiceid_events.VoiceIdFraudsterAction.ErrorInfo(
                        error_code=["errorCode"],
                        error_message=["errorMessage"],
                        error_type=["errorType"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    generated_fraudster_id=["generatedFraudsterId"],
                    source_id=["sourceId"],
                    status=["status"],
                    watchlist_ids=["watchlistIds"]
                )
            '''
            if isinstance(data, dict):
                data = VoiceIdFraudsterAction.Data(**data)
            if isinstance(error_info, dict):
                error_info = VoiceIdFraudsterAction.ErrorInfo(**error_info)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__754bace7db668eb810b6b0c981ebcee4cd0ea40ea20eb55d5fece7bcf7973a56)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument data", value=data, expected_type=type_hints["data"])
                check_type(argname="argument domain_id", value=domain_id, expected_type=type_hints["domain_id"])
                check_type(argname="argument error_info", value=error_info, expected_type=type_hints["error_info"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument generated_fraudster_id", value=generated_fraudster_id, expected_type=type_hints["generated_fraudster_id"])
                check_type(argname="argument source_id", value=source_id, expected_type=type_hints["source_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument watchlist_ids", value=watchlist_ids, expected_type=type_hints["watchlist_ids"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if data is not None:
                self._values["data"] = data
            if domain_id is not None:
                self._values["domain_id"] = domain_id
            if error_info is not None:
                self._values["error_info"] = error_info
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if generated_fraudster_id is not None:
                self._values["generated_fraudster_id"] = generated_fraudster_id
            if source_id is not None:
                self._values["source_id"] = source_id
            if status is not None:
                self._values["status"] = status
            if watchlist_ids is not None:
                self._values["watchlist_ids"] = watchlist_ids

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data(self) -> typing.Optional["VoiceIdFraudsterAction.Data"]:
            '''(experimental) data property.

            Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data")
            return typing.cast(typing.Optional["VoiceIdFraudsterAction.Data"], result)

        @builtins.property
        def domain_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) domainId property.

            Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Domain reference

            :stability: experimental
            '''
            result = self._values.get("domain_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_info(self) -> typing.Optional["VoiceIdFraudsterAction.ErrorInfo"]:
            '''(experimental) errorInfo property.

            Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_info")
            return typing.cast(typing.Optional["VoiceIdFraudsterAction.ErrorInfo"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def generated_fraudster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) generatedFraudsterId property.

            Specify an array of string values to match this event if the actual value of generatedFraudsterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("generated_fraudster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceId property.

            Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def watchlist_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) watchlistIds property.

            Specify an array of string values to match this event if the actual value of watchlistIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("watchlist_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceIdFraudsterActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VoiceIdSessionSpeakerEnrollmentAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSessionSpeakerEnrollmentAction",
):
    '''(experimental) EventBridge event pattern for aws.voiceid@VoiceIdSessionSpeakerEnrollmentAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        
        voice_id_session_speaker_enrollment_action = voiceid_events.VoiceIdSessionSpeakerEnrollmentAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="voiceIdSessionSpeakerEnrollmentActionPattern")
    @builtins.classmethod
    def voice_id_session_speaker_enrollment_action_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        system_attributes: typing.Optional[typing.Union["VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for VoiceId Session Speaker Enrollment Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param session_id: (experimental) sessionId property. Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param session_name: (experimental) sessionName property. Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdSessionSpeakerEnrollmentAction.VoiceIdSessionSpeakerEnrollmentActionProps(
            action=action,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            session_id=session_id,
            session_name=session_name,
            source_id=source_id,
            status=status,
            system_attributes=system_attributes,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "voiceIdSessionSpeakerEnrollmentActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo",
        jsii_struct_bases=[],
        name_mapping={
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "error_type": "errorType",
        },
    )
    class ErrorInfo:
        def __init__(
            self,
            *,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ErrorInfo.

            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_type: (experimental) errorType property. Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                error_info = voiceid_events.VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo(
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    error_type=["errorType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0a9fb50307d44e7d0f5116bd9b9bad5e80a41d1b36460d64cf415af1e797d315)
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument error_type", value=error_type, expected_type=type_hints["error_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if error_type is not None:
                self._values["error_type"] = error_type

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorType property.

            Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ErrorInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes",
        jsii_struct_bases=[],
        name_mapping={
            "aws_connect_original_contact_arn": "awsConnectOriginalContactArn",
        },
    )
    class SystemAttributes:
        def __init__(
            self,
            *,
            aws_connect_original_contact_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SystemAttributes.

            :param aws_connect_original_contact_arn: (experimental) aws-connect-OriginalContactArn property. Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                system_attributes = voiceid_events.VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes(
                    aws_connect_original_contact_arn=["awsConnectOriginalContactArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e0db977398f094cee5ad9bd44865db9e817fe88821b882c3ab06cd9cc4806ca5)
                check_type(argname="argument aws_connect_original_contact_arn", value=aws_connect_original_contact_arn, expected_type=type_hints["aws_connect_original_contact_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_connect_original_contact_arn is not None:
                self._values["aws_connect_original_contact_arn"] = aws_connect_original_contact_arn

        @builtins.property
        def aws_connect_original_contact_arn(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) aws-connect-OriginalContactArn property.

            Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_connect_original_contact_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SystemAttributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSessionSpeakerEnrollmentAction.VoiceIdSessionSpeakerEnrollmentActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "domain_id": "domainId",
            "error_info": "errorInfo",
            "event_metadata": "eventMetadata",
            "session_id": "sessionId",
            "session_name": "sessionName",
            "source_id": "sourceId",
            "status": "status",
            "system_attributes": "systemAttributes",
        },
    )
    class VoiceIdSessionSpeakerEnrollmentActionProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_info: typing.Optional[typing.Union["VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            system_attributes: typing.Optional[typing.Union["VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.voiceid@VoiceIdSessionSpeakerEnrollmentAction event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
            :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param session_id: (experimental) sessionId property. Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_name: (experimental) sessionName property. Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_id_session_speaker_enrollment_action_props = voiceid_events.VoiceIdSessionSpeakerEnrollmentAction.VoiceIdSessionSpeakerEnrollmentActionProps(
                    action=["action"],
                    domain_id=["domainId"],
                    error_info=voiceid_events.VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo(
                        error_code=["errorCode"],
                        error_message=["errorMessage"],
                        error_type=["errorType"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    session_id=["sessionId"],
                    session_name=["sessionName"],
                    source_id=["sourceId"],
                    status=["status"],
                    system_attributes=voiceid_events.VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes(
                        aws_connect_original_contact_arn=["awsConnectOriginalContactArn"]
                    )
                )
            '''
            if isinstance(error_info, dict):
                error_info = VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo(**error_info)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(system_attributes, dict):
                system_attributes = VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes(**system_attributes)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__aa76da471ea5c439052fbfe92d9dd71ce833c218ab6f1b06856894ff37c40a89)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument domain_id", value=domain_id, expected_type=type_hints["domain_id"])
                check_type(argname="argument error_info", value=error_info, expected_type=type_hints["error_info"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument session_id", value=session_id, expected_type=type_hints["session_id"])
                check_type(argname="argument session_name", value=session_name, expected_type=type_hints["session_name"])
                check_type(argname="argument source_id", value=source_id, expected_type=type_hints["source_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument system_attributes", value=system_attributes, expected_type=type_hints["system_attributes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if domain_id is not None:
                self._values["domain_id"] = domain_id
            if error_info is not None:
                self._values["error_info"] = error_info
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if session_id is not None:
                self._values["session_id"] = session_id
            if session_name is not None:
                self._values["session_name"] = session_name
            if source_id is not None:
                self._values["source_id"] = source_id
            if status is not None:
                self._values["status"] = status
            if system_attributes is not None:
                self._values["system_attributes"] = system_attributes

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def domain_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) domainId property.

            Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Domain reference

            :stability: experimental
            '''
            result = self._values.get("domain_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_info(
            self,
        ) -> typing.Optional["VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo"]:
            '''(experimental) errorInfo property.

            Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_info")
            return typing.cast(typing.Optional["VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def session_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sessionId property.

            Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sessionName property.

            Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceId property.

            Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def system_attributes(
            self,
        ) -> typing.Optional["VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes"]:
            '''(experimental) systemAttributes property.

            Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("system_attributes")
            return typing.cast(typing.Optional["VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceIdSessionSpeakerEnrollmentActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VoiceIdSpeakerAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSpeakerAction",
):
    '''(experimental) EventBridge event pattern for aws.voiceid@VoiceIdSpeakerAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        
        voice_id_speaker_action = voiceid_events.VoiceIdSpeakerAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="voiceIdSpeakerActionPattern")
    @builtins.classmethod
    def voice_id_speaker_action_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        data: typing.Optional[typing.Union["VoiceIdSpeakerAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdSpeakerAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        system_attributes: typing.Optional[typing.Union["VoiceIdSpeakerAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for VoiceId Speaker Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param generated_speaker_id: (experimental) generatedSpeakerId property. Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdSpeakerAction.VoiceIdSpeakerActionProps(
            action=action,
            data=data,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            generated_speaker_id=generated_speaker_id,
            source_id=source_id,
            status=status,
            system_attributes=system_attributes,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "voiceIdSpeakerActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSpeakerAction.Data",
        jsii_struct_bases=[],
        name_mapping={
            "enrollment_source": "enrollmentSource",
            "enrollment_source_id": "enrollmentSourceId",
            "enrollment_status": "enrollmentStatus",
        },
    )
    class Data:
        def __init__(
            self,
            *,
            enrollment_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            enrollment_source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            enrollment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Data.

            :param enrollment_source: (experimental) enrollmentSource property. Specify an array of string values to match this event if the actual value of enrollmentSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param enrollment_source_id: (experimental) enrollmentSourceId property. Specify an array of string values to match this event if the actual value of enrollmentSourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param enrollment_status: (experimental) enrollmentStatus property. Specify an array of string values to match this event if the actual value of enrollmentStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                data = voiceid_events.VoiceIdSpeakerAction.Data(
                    enrollment_source=["enrollmentSource"],
                    enrollment_source_id=["enrollmentSourceId"],
                    enrollment_status=["enrollmentStatus"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7ecbad5f53edac3eac10b75899e043811a49911592a152e2279c939b126d3d5d)
                check_type(argname="argument enrollment_source", value=enrollment_source, expected_type=type_hints["enrollment_source"])
                check_type(argname="argument enrollment_source_id", value=enrollment_source_id, expected_type=type_hints["enrollment_source_id"])
                check_type(argname="argument enrollment_status", value=enrollment_status, expected_type=type_hints["enrollment_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if enrollment_source is not None:
                self._values["enrollment_source"] = enrollment_source
            if enrollment_source_id is not None:
                self._values["enrollment_source_id"] = enrollment_source_id
            if enrollment_status is not None:
                self._values["enrollment_status"] = enrollment_status

        @builtins.property
        def enrollment_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enrollmentSource property.

            Specify an array of string values to match this event if the actual value of enrollmentSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enrollment_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def enrollment_source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enrollmentSourceId property.

            Specify an array of string values to match this event if the actual value of enrollmentSourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enrollment_source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def enrollment_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enrollmentStatus property.

            Specify an array of string values to match this event if the actual value of enrollmentStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enrollment_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Data(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSpeakerAction.ErrorInfo",
        jsii_struct_bases=[],
        name_mapping={
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "error_type": "errorType",
        },
    )
    class ErrorInfo:
        def __init__(
            self,
            *,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ErrorInfo.

            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_type: (experimental) errorType property. Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                error_info = voiceid_events.VoiceIdSpeakerAction.ErrorInfo(
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    error_type=["errorType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8163829e0b0e9748ecd16a75731dc7bdcf8c193a6146175ae98d58ec8b9a479c)
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument error_type", value=error_type, expected_type=type_hints["error_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if error_type is not None:
                self._values["error_type"] = error_type

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorType property.

            Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ErrorInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSpeakerAction.SystemAttributes",
        jsii_struct_bases=[],
        name_mapping={
            "aws_connect_original_contact_arn": "awsConnectOriginalContactArn",
        },
    )
    class SystemAttributes:
        def __init__(
            self,
            *,
            aws_connect_original_contact_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SystemAttributes.

            :param aws_connect_original_contact_arn: (experimental) aws-connect-OriginalContactArn property. Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                system_attributes = voiceid_events.VoiceIdSpeakerAction.SystemAttributes(
                    aws_connect_original_contact_arn=["awsConnectOriginalContactArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__60e5bf3e9b741df161004ce1efe353ee9bebd835f6b37f33770e782121044fd6)
                check_type(argname="argument aws_connect_original_contact_arn", value=aws_connect_original_contact_arn, expected_type=type_hints["aws_connect_original_contact_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_connect_original_contact_arn is not None:
                self._values["aws_connect_original_contact_arn"] = aws_connect_original_contact_arn

        @builtins.property
        def aws_connect_original_contact_arn(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) aws-connect-OriginalContactArn property.

            Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_connect_original_contact_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SystemAttributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdSpeakerAction.VoiceIdSpeakerActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "data": "data",
            "domain_id": "domainId",
            "error_info": "errorInfo",
            "event_metadata": "eventMetadata",
            "generated_speaker_id": "generatedSpeakerId",
            "source_id": "sourceId",
            "status": "status",
            "system_attributes": "systemAttributes",
        },
    )
    class VoiceIdSpeakerActionProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            data: typing.Optional[typing.Union["VoiceIdSpeakerAction.Data", typing.Dict[builtins.str, typing.Any]]] = None,
            domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_info: typing.Optional[typing.Union["VoiceIdSpeakerAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            system_attributes: typing.Optional[typing.Union["VoiceIdSpeakerAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.voiceid@VoiceIdSpeakerAction event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
            :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param generated_speaker_id: (experimental) generatedSpeakerId property. Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_id_speaker_action_props = voiceid_events.VoiceIdSpeakerAction.VoiceIdSpeakerActionProps(
                    action=["action"],
                    data=voiceid_events.VoiceIdSpeakerAction.Data(
                        enrollment_source=["enrollmentSource"],
                        enrollment_source_id=["enrollmentSourceId"],
                        enrollment_status=["enrollmentStatus"]
                    ),
                    domain_id=["domainId"],
                    error_info=voiceid_events.VoiceIdSpeakerAction.ErrorInfo(
                        error_code=["errorCode"],
                        error_message=["errorMessage"],
                        error_type=["errorType"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    generated_speaker_id=["generatedSpeakerId"],
                    source_id=["sourceId"],
                    status=["status"],
                    system_attributes=voiceid_events.VoiceIdSpeakerAction.SystemAttributes(
                        aws_connect_original_contact_arn=["awsConnectOriginalContactArn"]
                    )
                )
            '''
            if isinstance(data, dict):
                data = VoiceIdSpeakerAction.Data(**data)
            if isinstance(error_info, dict):
                error_info = VoiceIdSpeakerAction.ErrorInfo(**error_info)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(system_attributes, dict):
                system_attributes = VoiceIdSpeakerAction.SystemAttributes(**system_attributes)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9ab2a6d91005748d6d81ae80ad863f0727995d4ed8b4b9be83e4d495bda704e3)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument data", value=data, expected_type=type_hints["data"])
                check_type(argname="argument domain_id", value=domain_id, expected_type=type_hints["domain_id"])
                check_type(argname="argument error_info", value=error_info, expected_type=type_hints["error_info"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument generated_speaker_id", value=generated_speaker_id, expected_type=type_hints["generated_speaker_id"])
                check_type(argname="argument source_id", value=source_id, expected_type=type_hints["source_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument system_attributes", value=system_attributes, expected_type=type_hints["system_attributes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if data is not None:
                self._values["data"] = data
            if domain_id is not None:
                self._values["domain_id"] = domain_id
            if error_info is not None:
                self._values["error_info"] = error_info
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if generated_speaker_id is not None:
                self._values["generated_speaker_id"] = generated_speaker_id
            if source_id is not None:
                self._values["source_id"] = source_id
            if status is not None:
                self._values["status"] = status
            if system_attributes is not None:
                self._values["system_attributes"] = system_attributes

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data(self) -> typing.Optional["VoiceIdSpeakerAction.Data"]:
            '''(experimental) data property.

            Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data")
            return typing.cast(typing.Optional["VoiceIdSpeakerAction.Data"], result)

        @builtins.property
        def domain_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) domainId property.

            Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Domain reference

            :stability: experimental
            '''
            result = self._values.get("domain_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_info(self) -> typing.Optional["VoiceIdSpeakerAction.ErrorInfo"]:
            '''(experimental) errorInfo property.

            Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_info")
            return typing.cast(typing.Optional["VoiceIdSpeakerAction.ErrorInfo"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def generated_speaker_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) generatedSpeakerId property.

            Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("generated_speaker_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceId property.

            Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def system_attributes(
            self,
        ) -> typing.Optional["VoiceIdSpeakerAction.SystemAttributes"]:
            '''(experimental) systemAttributes property.

            Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("system_attributes")
            return typing.cast(typing.Optional["VoiceIdSpeakerAction.SystemAttributes"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceIdSpeakerActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VoiceIdStartSessionAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction",
):
    '''(experimental) EventBridge event pattern for aws.voiceid@VoiceIdStartSessionAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        
        voice_id_start_session_action = voiceid_events.VoiceIdStartSessionAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="voiceIdStartSessionActionPattern")
    @builtins.classmethod
    def voice_id_start_session_action_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdStartSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        session: typing.Optional[typing.Union["VoiceIdStartSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        system_attributes: typing.Optional[typing.Union["VoiceIdStartSessionAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for VoiceId Start Session Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdStartSessionAction.VoiceIdStartSessionActionProps(
            action=action,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            session=session,
            source_id=source_id,
            status=status,
            system_attributes=system_attributes,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "voiceIdStartSessionActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.AuthenticationAudioProgress",
        jsii_struct_bases=[],
        name_mapping={
            "audio_aggregation_ended_at": "audioAggregationEndedAt",
            "audio_aggregation_started_at": "audioAggregationStartedAt",
        },
    )
    class AuthenticationAudioProgress:
        def __init__(
            self,
            *,
            audio_aggregation_ended_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            audio_aggregation_started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AuthenticationAudioProgress.

            :param audio_aggregation_ended_at: (experimental) audioAggregationEndedAt property. Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param audio_aggregation_started_at: (experimental) audioAggregationStartedAt property. Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                authentication_audio_progress = voiceid_events.VoiceIdStartSessionAction.AuthenticationAudioProgress(
                    audio_aggregation_ended_at=["audioAggregationEndedAt"],
                    audio_aggregation_started_at=["audioAggregationStartedAt"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__17f7084d20bffc26f533c1727a12da6672f1ec8feff0382fc224b424824116cb)
                check_type(argname="argument audio_aggregation_ended_at", value=audio_aggregation_ended_at, expected_type=type_hints["audio_aggregation_ended_at"])
                check_type(argname="argument audio_aggregation_started_at", value=audio_aggregation_started_at, expected_type=type_hints["audio_aggregation_started_at"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if audio_aggregation_ended_at is not None:
                self._values["audio_aggregation_ended_at"] = audio_aggregation_ended_at
            if audio_aggregation_started_at is not None:
                self._values["audio_aggregation_started_at"] = audio_aggregation_started_at

        @builtins.property
        def audio_aggregation_ended_at(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationEndedAt property.

            Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_ended_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def audio_aggregation_started_at(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationStartedAt property.

            Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_started_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AuthenticationAudioProgress(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.AuthenticationConfiguration",
        jsii_struct_bases=[],
        name_mapping={"acceptance_threshold": "acceptanceThreshold"},
    )
    class AuthenticationConfiguration:
        def __init__(
            self,
            *,
            acceptance_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AuthenticationConfiguration.

            :param acceptance_threshold: (experimental) acceptanceThreshold property. Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                authentication_configuration = voiceid_events.VoiceIdStartSessionAction.AuthenticationConfiguration(
                    acceptance_threshold=["acceptanceThreshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9d78454ff4998f7ce1be5944cc5ca6d76342690f603c168dd1a3b7e77310cd7b)
                check_type(argname="argument acceptance_threshold", value=acceptance_threshold, expected_type=type_hints["acceptance_threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if acceptance_threshold is not None:
                self._values["acceptance_threshold"] = acceptance_threshold

        @builtins.property
        def acceptance_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) acceptanceThreshold property.

            Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("acceptance_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AuthenticationConfiguration(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.EnrollmentAudioProgress",
        jsii_struct_bases=[],
        name_mapping={
            "audio_aggregation_ended_at": "audioAggregationEndedAt",
            "audio_aggregation_started_at": "audioAggregationStartedAt",
            "audio_aggregation_status": "audioAggregationStatus",
        },
    )
    class EnrollmentAudioProgress:
        def __init__(
            self,
            *,
            audio_aggregation_ended_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            audio_aggregation_started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            audio_aggregation_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for EnrollmentAudioProgress.

            :param audio_aggregation_ended_at: (experimental) audioAggregationEndedAt property. Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param audio_aggregation_started_at: (experimental) audioAggregationStartedAt property. Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param audio_aggregation_status: (experimental) audioAggregationStatus property. Specify an array of string values to match this event if the actual value of audioAggregationStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                enrollment_audio_progress = voiceid_events.VoiceIdStartSessionAction.EnrollmentAudioProgress(
                    audio_aggregation_ended_at=["audioAggregationEndedAt"],
                    audio_aggregation_started_at=["audioAggregationStartedAt"],
                    audio_aggregation_status=["audioAggregationStatus"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__83162e76671ee8ba6ecf8c318eb59c5fd0593c9623e9abf31f2e959500849aac)
                check_type(argname="argument audio_aggregation_ended_at", value=audio_aggregation_ended_at, expected_type=type_hints["audio_aggregation_ended_at"])
                check_type(argname="argument audio_aggregation_started_at", value=audio_aggregation_started_at, expected_type=type_hints["audio_aggregation_started_at"])
                check_type(argname="argument audio_aggregation_status", value=audio_aggregation_status, expected_type=type_hints["audio_aggregation_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if audio_aggregation_ended_at is not None:
                self._values["audio_aggregation_ended_at"] = audio_aggregation_ended_at
            if audio_aggregation_started_at is not None:
                self._values["audio_aggregation_started_at"] = audio_aggregation_started_at
            if audio_aggregation_status is not None:
                self._values["audio_aggregation_status"] = audio_aggregation_status

        @builtins.property
        def audio_aggregation_ended_at(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationEndedAt property.

            Specify an array of string values to match this event if the actual value of audioAggregationEndedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_ended_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def audio_aggregation_started_at(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationStartedAt property.

            Specify an array of string values to match this event if the actual value of audioAggregationStartedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_started_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def audio_aggregation_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) audioAggregationStatus property.

            Specify an array of string values to match this event if the actual value of audioAggregationStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("audio_aggregation_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EnrollmentAudioProgress(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.ErrorInfo",
        jsii_struct_bases=[],
        name_mapping={
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "error_type": "errorType",
        },
    )
    class ErrorInfo:
        def __init__(
            self,
            *,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ErrorInfo.

            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_type: (experimental) errorType property. Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                error_info = voiceid_events.VoiceIdStartSessionAction.ErrorInfo(
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    error_type=["errorType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a9454d6e8ca3108537c8fdfd10c0b35b034cd9276102d16152c344ddd2aaf816)
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument error_type", value=error_type, expected_type=type_hints["error_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if error_type is not None:
                self._values["error_type"] = error_type

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorType property.

            Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ErrorInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.FraudDetectionConfiguration",
        jsii_struct_bases=[],
        name_mapping={
            "risk_threshold": "riskThreshold",
            "watchlist_id": "watchlistId",
        },
    )
    class FraudDetectionConfiguration:
        def __init__(
            self,
            *,
            risk_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
            watchlist_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for FraudDetectionConfiguration.

            :param risk_threshold: (experimental) riskThreshold property. Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param watchlist_id: (experimental) watchlistId property. Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                fraud_detection_configuration = voiceid_events.VoiceIdStartSessionAction.FraudDetectionConfiguration(
                    risk_threshold=["riskThreshold"],
                    watchlist_id=["watchlistId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__482fca6f2dae8cfa0541cdb8e2dd4b67a6f9e57801761a022d96ca2abce4ac74)
                check_type(argname="argument risk_threshold", value=risk_threshold, expected_type=type_hints["risk_threshold"])
                check_type(argname="argument watchlist_id", value=watchlist_id, expected_type=type_hints["watchlist_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if risk_threshold is not None:
                self._values["risk_threshold"] = risk_threshold
            if watchlist_id is not None:
                self._values["watchlist_id"] = watchlist_id

        @builtins.property
        def risk_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) riskThreshold property.

            Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("risk_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def watchlist_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) watchlistId property.

            Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("watchlist_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FraudDetectionConfiguration(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.Session",
        jsii_struct_bases=[],
        name_mapping={
            "authentication_audio_progress": "authenticationAudioProgress",
            "authentication_configuration": "authenticationConfiguration",
            "enrollment_audio_progress": "enrollmentAudioProgress",
            "fraud_detection_audio_progress": "fraudDetectionAudioProgress",
            "fraud_detection_configuration": "fraudDetectionConfiguration",
            "generated_speaker_id": "generatedSpeakerId",
            "session_id": "sessionId",
            "session_name": "sessionName",
            "streaming_configuration": "streamingConfiguration",
        },
    )
    class Session:
        def __init__(
            self,
            *,
            authentication_audio_progress: typing.Optional[typing.Union["VoiceIdStartSessionAction.AuthenticationAudioProgress", typing.Dict[builtins.str, typing.Any]]] = None,
            authentication_configuration: typing.Optional[typing.Union["VoiceIdStartSessionAction.AuthenticationConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
            enrollment_audio_progress: typing.Optional[typing.Union["VoiceIdStartSessionAction.EnrollmentAudioProgress", typing.Dict[builtins.str, typing.Any]]] = None,
            fraud_detection_audio_progress: typing.Optional[typing.Union["VoiceIdStartSessionAction.AuthenticationAudioProgress", typing.Dict[builtins.str, typing.Any]]] = None,
            fraud_detection_configuration: typing.Optional[typing.Union["VoiceIdStartSessionAction.FraudDetectionConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
            generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            streaming_configuration: typing.Optional[typing.Union["VoiceIdStartSessionAction.StreamingConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Session.

            :param authentication_audio_progress: (experimental) authenticationAudioProgress property. Specify an array of string values to match this event if the actual value of authenticationAudioProgress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param authentication_configuration: (experimental) authenticationConfiguration property. Specify an array of string values to match this event if the actual value of authenticationConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param enrollment_audio_progress: (experimental) enrollmentAudioProgress property. Specify an array of string values to match this event if the actual value of enrollmentAudioProgress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fraud_detection_audio_progress: (experimental) fraudDetectionAudioProgress property. Specify an array of string values to match this event if the actual value of fraudDetectionAudioProgress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fraud_detection_configuration: (experimental) fraudDetectionConfiguration property. Specify an array of string values to match this event if the actual value of fraudDetectionConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param generated_speaker_id: (experimental) generatedSpeakerId property. Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_id: (experimental) sessionId property. Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_name: (experimental) sessionName property. Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param streaming_configuration: (experimental) streamingConfiguration property. Specify an array of string values to match this event if the actual value of streamingConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                session = voiceid_events.VoiceIdStartSessionAction.Session(
                    authentication_audio_progress=voiceid_events.VoiceIdStartSessionAction.AuthenticationAudioProgress(
                        audio_aggregation_ended_at=["audioAggregationEndedAt"],
                        audio_aggregation_started_at=["audioAggregationStartedAt"]
                    ),
                    authentication_configuration=voiceid_events.VoiceIdStartSessionAction.AuthenticationConfiguration(
                        acceptance_threshold=["acceptanceThreshold"]
                    ),
                    enrollment_audio_progress=voiceid_events.VoiceIdStartSessionAction.EnrollmentAudioProgress(
                        audio_aggregation_ended_at=["audioAggregationEndedAt"],
                        audio_aggregation_started_at=["audioAggregationStartedAt"],
                        audio_aggregation_status=["audioAggregationStatus"]
                    ),
                    fraud_detection_audio_progress=voiceid_events.VoiceIdStartSessionAction.AuthenticationAudioProgress(
                        audio_aggregation_ended_at=["audioAggregationEndedAt"],
                        audio_aggregation_started_at=["audioAggregationStartedAt"]
                    ),
                    fraud_detection_configuration=voiceid_events.VoiceIdStartSessionAction.FraudDetectionConfiguration(
                        risk_threshold=["riskThreshold"],
                        watchlist_id=["watchlistId"]
                    ),
                    generated_speaker_id=["generatedSpeakerId"],
                    session_id=["sessionId"],
                    session_name=["sessionName"],
                    streaming_configuration=voiceid_events.VoiceIdStartSessionAction.StreamingConfiguration(
                        authentication_minimum_speech_in_seconds=["authenticationMinimumSpeechInSeconds"]
                    )
                )
            '''
            if isinstance(authentication_audio_progress, dict):
                authentication_audio_progress = VoiceIdStartSessionAction.AuthenticationAudioProgress(**authentication_audio_progress)
            if isinstance(authentication_configuration, dict):
                authentication_configuration = VoiceIdStartSessionAction.AuthenticationConfiguration(**authentication_configuration)
            if isinstance(enrollment_audio_progress, dict):
                enrollment_audio_progress = VoiceIdStartSessionAction.EnrollmentAudioProgress(**enrollment_audio_progress)
            if isinstance(fraud_detection_audio_progress, dict):
                fraud_detection_audio_progress = VoiceIdStartSessionAction.AuthenticationAudioProgress(**fraud_detection_audio_progress)
            if isinstance(fraud_detection_configuration, dict):
                fraud_detection_configuration = VoiceIdStartSessionAction.FraudDetectionConfiguration(**fraud_detection_configuration)
            if isinstance(streaming_configuration, dict):
                streaming_configuration = VoiceIdStartSessionAction.StreamingConfiguration(**streaming_configuration)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__72e570a439c60d0e46dca6b9de2da6badf300d7c2e4913a0dc448f39027979a9)
                check_type(argname="argument authentication_audio_progress", value=authentication_audio_progress, expected_type=type_hints["authentication_audio_progress"])
                check_type(argname="argument authentication_configuration", value=authentication_configuration, expected_type=type_hints["authentication_configuration"])
                check_type(argname="argument enrollment_audio_progress", value=enrollment_audio_progress, expected_type=type_hints["enrollment_audio_progress"])
                check_type(argname="argument fraud_detection_audio_progress", value=fraud_detection_audio_progress, expected_type=type_hints["fraud_detection_audio_progress"])
                check_type(argname="argument fraud_detection_configuration", value=fraud_detection_configuration, expected_type=type_hints["fraud_detection_configuration"])
                check_type(argname="argument generated_speaker_id", value=generated_speaker_id, expected_type=type_hints["generated_speaker_id"])
                check_type(argname="argument session_id", value=session_id, expected_type=type_hints["session_id"])
                check_type(argname="argument session_name", value=session_name, expected_type=type_hints["session_name"])
                check_type(argname="argument streaming_configuration", value=streaming_configuration, expected_type=type_hints["streaming_configuration"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if authentication_audio_progress is not None:
                self._values["authentication_audio_progress"] = authentication_audio_progress
            if authentication_configuration is not None:
                self._values["authentication_configuration"] = authentication_configuration
            if enrollment_audio_progress is not None:
                self._values["enrollment_audio_progress"] = enrollment_audio_progress
            if fraud_detection_audio_progress is not None:
                self._values["fraud_detection_audio_progress"] = fraud_detection_audio_progress
            if fraud_detection_configuration is not None:
                self._values["fraud_detection_configuration"] = fraud_detection_configuration
            if generated_speaker_id is not None:
                self._values["generated_speaker_id"] = generated_speaker_id
            if session_id is not None:
                self._values["session_id"] = session_id
            if session_name is not None:
                self._values["session_name"] = session_name
            if streaming_configuration is not None:
                self._values["streaming_configuration"] = streaming_configuration

        @builtins.property
        def authentication_audio_progress(
            self,
        ) -> typing.Optional["VoiceIdStartSessionAction.AuthenticationAudioProgress"]:
            '''(experimental) authenticationAudioProgress property.

            Specify an array of string values to match this event if the actual value of authenticationAudioProgress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("authentication_audio_progress")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.AuthenticationAudioProgress"], result)

        @builtins.property
        def authentication_configuration(
            self,
        ) -> typing.Optional["VoiceIdStartSessionAction.AuthenticationConfiguration"]:
            '''(experimental) authenticationConfiguration property.

            Specify an array of string values to match this event if the actual value of authenticationConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("authentication_configuration")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.AuthenticationConfiguration"], result)

        @builtins.property
        def enrollment_audio_progress(
            self,
        ) -> typing.Optional["VoiceIdStartSessionAction.EnrollmentAudioProgress"]:
            '''(experimental) enrollmentAudioProgress property.

            Specify an array of string values to match this event if the actual value of enrollmentAudioProgress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enrollment_audio_progress")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.EnrollmentAudioProgress"], result)

        @builtins.property
        def fraud_detection_audio_progress(
            self,
        ) -> typing.Optional["VoiceIdStartSessionAction.AuthenticationAudioProgress"]:
            '''(experimental) fraudDetectionAudioProgress property.

            Specify an array of string values to match this event if the actual value of fraudDetectionAudioProgress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraud_detection_audio_progress")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.AuthenticationAudioProgress"], result)

        @builtins.property
        def fraud_detection_configuration(
            self,
        ) -> typing.Optional["VoiceIdStartSessionAction.FraudDetectionConfiguration"]:
            '''(experimental) fraudDetectionConfiguration property.

            Specify an array of string values to match this event if the actual value of fraudDetectionConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraud_detection_configuration")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.FraudDetectionConfiguration"], result)

        @builtins.property
        def generated_speaker_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) generatedSpeakerId property.

            Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("generated_speaker_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sessionId property.

            Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sessionName property.

            Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def streaming_configuration(
            self,
        ) -> typing.Optional["VoiceIdStartSessionAction.StreamingConfiguration"]:
            '''(experimental) streamingConfiguration property.

            Specify an array of string values to match this event if the actual value of streamingConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("streaming_configuration")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.StreamingConfiguration"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Session(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.StreamingConfiguration",
        jsii_struct_bases=[],
        name_mapping={
            "authentication_minimum_speech_in_seconds": "authenticationMinimumSpeechInSeconds",
        },
    )
    class StreamingConfiguration:
        def __init__(
            self,
            *,
            authentication_minimum_speech_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for StreamingConfiguration.

            :param authentication_minimum_speech_in_seconds: (experimental) authenticationMinimumSpeechInSeconds property. Specify an array of string values to match this event if the actual value of authenticationMinimumSpeechInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                streaming_configuration = voiceid_events.VoiceIdStartSessionAction.StreamingConfiguration(
                    authentication_minimum_speech_in_seconds=["authenticationMinimumSpeechInSeconds"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__066ca5fc5755ad385196c3652197a6988081a157902d72b5424bf9648d4cfcfb)
                check_type(argname="argument authentication_minimum_speech_in_seconds", value=authentication_minimum_speech_in_seconds, expected_type=type_hints["authentication_minimum_speech_in_seconds"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if authentication_minimum_speech_in_seconds is not None:
                self._values["authentication_minimum_speech_in_seconds"] = authentication_minimum_speech_in_seconds

        @builtins.property
        def authentication_minimum_speech_in_seconds(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) authenticationMinimumSpeechInSeconds property.

            Specify an array of string values to match this event if the actual value of authenticationMinimumSpeechInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("authentication_minimum_speech_in_seconds")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "StreamingConfiguration(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.SystemAttributes",
        jsii_struct_bases=[],
        name_mapping={
            "aws_connect_original_contact_arn": "awsConnectOriginalContactArn",
        },
    )
    class SystemAttributes:
        def __init__(
            self,
            *,
            aws_connect_original_contact_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SystemAttributes.

            :param aws_connect_original_contact_arn: (experimental) aws-connect-OriginalContactArn property. Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                system_attributes = voiceid_events.VoiceIdStartSessionAction.SystemAttributes(
                    aws_connect_original_contact_arn=["awsConnectOriginalContactArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__235b9e2aea5678c492c2320919143eba448294458e80289a1d48c500b3ca160b)
                check_type(argname="argument aws_connect_original_contact_arn", value=aws_connect_original_contact_arn, expected_type=type_hints["aws_connect_original_contact_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_connect_original_contact_arn is not None:
                self._values["aws_connect_original_contact_arn"] = aws_connect_original_contact_arn

        @builtins.property
        def aws_connect_original_contact_arn(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) aws-connect-OriginalContactArn property.

            Specify an array of string values to match this event if the actual value of aws-connect-OriginalContactArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_connect_original_contact_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SystemAttributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdStartSessionAction.VoiceIdStartSessionActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "domain_id": "domainId",
            "error_info": "errorInfo",
            "event_metadata": "eventMetadata",
            "session": "session",
            "source_id": "sourceId",
            "status": "status",
            "system_attributes": "systemAttributes",
        },
    )
    class VoiceIdStartSessionActionProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_info: typing.Optional[typing.Union["VoiceIdStartSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            session: typing.Optional[typing.Union["VoiceIdStartSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
            source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            system_attributes: typing.Optional[typing.Union["VoiceIdStartSessionAction.SystemAttributes", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.voiceid@VoiceIdStartSessionAction event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
            :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param system_attributes: (experimental) systemAttributes property. Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_id_start_session_action_props = voiceid_events.VoiceIdStartSessionAction.VoiceIdStartSessionActionProps(
                    action=["action"],
                    domain_id=["domainId"],
                    error_info=voiceid_events.VoiceIdStartSessionAction.ErrorInfo(
                        error_code=["errorCode"],
                        error_message=["errorMessage"],
                        error_type=["errorType"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    session=voiceid_events.VoiceIdStartSessionAction.Session(
                        authentication_audio_progress=voiceid_events.VoiceIdStartSessionAction.AuthenticationAudioProgress(
                            audio_aggregation_ended_at=["audioAggregationEndedAt"],
                            audio_aggregation_started_at=["audioAggregationStartedAt"]
                        ),
                        authentication_configuration=voiceid_events.VoiceIdStartSessionAction.AuthenticationConfiguration(
                            acceptance_threshold=["acceptanceThreshold"]
                        ),
                        enrollment_audio_progress=voiceid_events.VoiceIdStartSessionAction.EnrollmentAudioProgress(
                            audio_aggregation_ended_at=["audioAggregationEndedAt"],
                            audio_aggregation_started_at=["audioAggregationStartedAt"],
                            audio_aggregation_status=["audioAggregationStatus"]
                        ),
                        fraud_detection_audio_progress=voiceid_events.VoiceIdStartSessionAction.AuthenticationAudioProgress(
                            audio_aggregation_ended_at=["audioAggregationEndedAt"],
                            audio_aggregation_started_at=["audioAggregationStartedAt"]
                        ),
                        fraud_detection_configuration=voiceid_events.VoiceIdStartSessionAction.FraudDetectionConfiguration(
                            risk_threshold=["riskThreshold"],
                            watchlist_id=["watchlistId"]
                        ),
                        generated_speaker_id=["generatedSpeakerId"],
                        session_id=["sessionId"],
                        session_name=["sessionName"],
                        streaming_configuration=voiceid_events.VoiceIdStartSessionAction.StreamingConfiguration(
                            authentication_minimum_speech_in_seconds=["authenticationMinimumSpeechInSeconds"]
                        )
                    ),
                    source_id=["sourceId"],
                    status=["status"],
                    system_attributes=voiceid_events.VoiceIdStartSessionAction.SystemAttributes(
                        aws_connect_original_contact_arn=["awsConnectOriginalContactArn"]
                    )
                )
            '''
            if isinstance(error_info, dict):
                error_info = VoiceIdStartSessionAction.ErrorInfo(**error_info)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(session, dict):
                session = VoiceIdStartSessionAction.Session(**session)
            if isinstance(system_attributes, dict):
                system_attributes = VoiceIdStartSessionAction.SystemAttributes(**system_attributes)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0f22142b34ed853d51e6721bbc767005847245dd3061c1546d8b604332ca07c1)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument domain_id", value=domain_id, expected_type=type_hints["domain_id"])
                check_type(argname="argument error_info", value=error_info, expected_type=type_hints["error_info"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument session", value=session, expected_type=type_hints["session"])
                check_type(argname="argument source_id", value=source_id, expected_type=type_hints["source_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument system_attributes", value=system_attributes, expected_type=type_hints["system_attributes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if domain_id is not None:
                self._values["domain_id"] = domain_id
            if error_info is not None:
                self._values["error_info"] = error_info
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if session is not None:
                self._values["session"] = session
            if source_id is not None:
                self._values["source_id"] = source_id
            if status is not None:
                self._values["status"] = status
            if system_attributes is not None:
                self._values["system_attributes"] = system_attributes

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def domain_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) domainId property.

            Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Domain reference

            :stability: experimental
            '''
            result = self._values.get("domain_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_info(self) -> typing.Optional["VoiceIdStartSessionAction.ErrorInfo"]:
            '''(experimental) errorInfo property.

            Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_info")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.ErrorInfo"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def session(self) -> typing.Optional["VoiceIdStartSessionAction.Session"]:
            '''(experimental) session property.

            Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.Session"], result)

        @builtins.property
        def source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceId property.

            Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def system_attributes(
            self,
        ) -> typing.Optional["VoiceIdStartSessionAction.SystemAttributes"]:
            '''(experimental) systemAttributes property.

            Specify an array of string values to match this event if the actual value of systemAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("system_attributes")
            return typing.cast(typing.Optional["VoiceIdStartSessionAction.SystemAttributes"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceIdStartSessionActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VoiceIdUpdateSessionAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdUpdateSessionAction",
):
    '''(experimental) EventBridge event pattern for aws.voiceid@VoiceIdUpdateSessionAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
        
        voice_id_update_session_action = voiceid_events.VoiceIdUpdateSessionAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="voiceIdUpdateSessionActionPattern")
    @builtins.classmethod
    def voice_id_update_session_action_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_info: typing.Optional[typing.Union["VoiceIdUpdateSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        session: typing.Optional[typing.Union["VoiceIdUpdateSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
        source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for VoiceId Update Session Action.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
        :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VoiceIdUpdateSessionAction.VoiceIdUpdateSessionActionProps(
            action=action,
            domain_id=domain_id,
            error_info=error_info,
            event_metadata=event_metadata,
            session=session,
            source_id=source_id,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "voiceIdUpdateSessionActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdUpdateSessionAction.AuthenticationConfiguration",
        jsii_struct_bases=[],
        name_mapping={"acceptance_threshold": "acceptanceThreshold"},
    )
    class AuthenticationConfiguration:
        def __init__(
            self,
            *,
            acceptance_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AuthenticationConfiguration.

            :param acceptance_threshold: (experimental) acceptanceThreshold property. Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                authentication_configuration = voiceid_events.VoiceIdUpdateSessionAction.AuthenticationConfiguration(
                    acceptance_threshold=["acceptanceThreshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6a1b22e6b7319eb07c67339ac794d467af8ebf6bf6905b34407ecc3ae1f89e5f)
                check_type(argname="argument acceptance_threshold", value=acceptance_threshold, expected_type=type_hints["acceptance_threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if acceptance_threshold is not None:
                self._values["acceptance_threshold"] = acceptance_threshold

        @builtins.property
        def acceptance_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) acceptanceThreshold property.

            Specify an array of string values to match this event if the actual value of acceptanceThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("acceptance_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AuthenticationConfiguration(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdUpdateSessionAction.ErrorInfo",
        jsii_struct_bases=[],
        name_mapping={
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "error_type": "errorType",
        },
    )
    class ErrorInfo:
        def __init__(
            self,
            *,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ErrorInfo.

            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_type: (experimental) errorType property. Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                error_info = voiceid_events.VoiceIdUpdateSessionAction.ErrorInfo(
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    error_type=["errorType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f1b9a445efc448d8b5e93f71d4d1f3b3b7b15460aac8253408f27d056e9e8ccc)
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument error_type", value=error_type, expected_type=type_hints["error_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if error_type is not None:
                self._values["error_type"] = error_type

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorType property.

            Specify an array of string values to match this event if the actual value of errorType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ErrorInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdUpdateSessionAction.FraudDetectionConfiguration",
        jsii_struct_bases=[],
        name_mapping={
            "risk_threshold": "riskThreshold",
            "watchlist_id": "watchlistId",
        },
    )
    class FraudDetectionConfiguration:
        def __init__(
            self,
            *,
            risk_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
            watchlist_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for FraudDetectionConfiguration.

            :param risk_threshold: (experimental) riskThreshold property. Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param watchlist_id: (experimental) watchlistId property. Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                fraud_detection_configuration = voiceid_events.VoiceIdUpdateSessionAction.FraudDetectionConfiguration(
                    risk_threshold=["riskThreshold"],
                    watchlist_id=["watchlistId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__228be573520c359982dbf3c689801e5284a127b6a6f4f7a43a09e5011e03ea4d)
                check_type(argname="argument risk_threshold", value=risk_threshold, expected_type=type_hints["risk_threshold"])
                check_type(argname="argument watchlist_id", value=watchlist_id, expected_type=type_hints["watchlist_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if risk_threshold is not None:
                self._values["risk_threshold"] = risk_threshold
            if watchlist_id is not None:
                self._values["watchlist_id"] = watchlist_id

        @builtins.property
        def risk_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) riskThreshold property.

            Specify an array of string values to match this event if the actual value of riskThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("risk_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def watchlist_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) watchlistId property.

            Specify an array of string values to match this event if the actual value of watchlistId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("watchlist_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FraudDetectionConfiguration(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdUpdateSessionAction.Session",
        jsii_struct_bases=[],
        name_mapping={
            "authentication_configuration": "authenticationConfiguration",
            "fraud_detection_configuration": "fraudDetectionConfiguration",
            "generated_speaker_id": "generatedSpeakerId",
            "session_id": "sessionId",
            "session_name": "sessionName",
        },
    )
    class Session:
        def __init__(
            self,
            *,
            authentication_configuration: typing.Optional[typing.Union["VoiceIdUpdateSessionAction.AuthenticationConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
            fraud_detection_configuration: typing.Optional[typing.Union["VoiceIdUpdateSessionAction.FraudDetectionConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
            generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Session.

            :param authentication_configuration: (experimental) authenticationConfiguration property. Specify an array of string values to match this event if the actual value of authenticationConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fraud_detection_configuration: (experimental) fraudDetectionConfiguration property. Specify an array of string values to match this event if the actual value of fraudDetectionConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param generated_speaker_id: (experimental) generatedSpeakerId property. Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_id: (experimental) sessionId property. Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_name: (experimental) sessionName property. Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                session = voiceid_events.VoiceIdUpdateSessionAction.Session(
                    authentication_configuration=voiceid_events.VoiceIdUpdateSessionAction.AuthenticationConfiguration(
                        acceptance_threshold=["acceptanceThreshold"]
                    ),
                    fraud_detection_configuration=voiceid_events.VoiceIdUpdateSessionAction.FraudDetectionConfiguration(
                        risk_threshold=["riskThreshold"],
                        watchlist_id=["watchlistId"]
                    ),
                    generated_speaker_id=["generatedSpeakerId"],
                    session_id=["sessionId"],
                    session_name=["sessionName"]
                )
            '''
            if isinstance(authentication_configuration, dict):
                authentication_configuration = VoiceIdUpdateSessionAction.AuthenticationConfiguration(**authentication_configuration)
            if isinstance(fraud_detection_configuration, dict):
                fraud_detection_configuration = VoiceIdUpdateSessionAction.FraudDetectionConfiguration(**fraud_detection_configuration)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__74826bea4f7c8456695a9fcc9458c439aaa8e548420ac91025f6add39e38469d)
                check_type(argname="argument authentication_configuration", value=authentication_configuration, expected_type=type_hints["authentication_configuration"])
                check_type(argname="argument fraud_detection_configuration", value=fraud_detection_configuration, expected_type=type_hints["fraud_detection_configuration"])
                check_type(argname="argument generated_speaker_id", value=generated_speaker_id, expected_type=type_hints["generated_speaker_id"])
                check_type(argname="argument session_id", value=session_id, expected_type=type_hints["session_id"])
                check_type(argname="argument session_name", value=session_name, expected_type=type_hints["session_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if authentication_configuration is not None:
                self._values["authentication_configuration"] = authentication_configuration
            if fraud_detection_configuration is not None:
                self._values["fraud_detection_configuration"] = fraud_detection_configuration
            if generated_speaker_id is not None:
                self._values["generated_speaker_id"] = generated_speaker_id
            if session_id is not None:
                self._values["session_id"] = session_id
            if session_name is not None:
                self._values["session_name"] = session_name

        @builtins.property
        def authentication_configuration(
            self,
        ) -> typing.Optional["VoiceIdUpdateSessionAction.AuthenticationConfiguration"]:
            '''(experimental) authenticationConfiguration property.

            Specify an array of string values to match this event if the actual value of authenticationConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("authentication_configuration")
            return typing.cast(typing.Optional["VoiceIdUpdateSessionAction.AuthenticationConfiguration"], result)

        @builtins.property
        def fraud_detection_configuration(
            self,
        ) -> typing.Optional["VoiceIdUpdateSessionAction.FraudDetectionConfiguration"]:
            '''(experimental) fraudDetectionConfiguration property.

            Specify an array of string values to match this event if the actual value of fraudDetectionConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fraud_detection_configuration")
            return typing.cast(typing.Optional["VoiceIdUpdateSessionAction.FraudDetectionConfiguration"], result)

        @builtins.property
        def generated_speaker_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) generatedSpeakerId property.

            Specify an array of string values to match this event if the actual value of generatedSpeakerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("generated_speaker_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sessionId property.

            Specify an array of string values to match this event if the actual value of sessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sessionName property.

            Specify an array of string values to match this event if the actual value of sessionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Session(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_voiceid.events.VoiceIdUpdateSessionAction.VoiceIdUpdateSessionActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "domain_id": "domainId",
            "error_info": "errorInfo",
            "event_metadata": "eventMetadata",
            "session": "session",
            "source_id": "sourceId",
            "status": "status",
        },
    )
    class VoiceIdUpdateSessionActionProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_info: typing.Optional[typing.Union["VoiceIdUpdateSessionAction.ErrorInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            session: typing.Optional[typing.Union["VoiceIdUpdateSessionAction.Session", typing.Dict[builtins.str, typing.Any]]] = None,
            source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.voiceid@VoiceIdUpdateSessionAction event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param domain_id: (experimental) domainId property. Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Domain reference
            :param error_info: (experimental) errorInfo property. Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param session: (experimental) session property. Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_id: (experimental) sourceId property. Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_voiceid import events as voiceid_events
                
                voice_id_update_session_action_props = voiceid_events.VoiceIdUpdateSessionAction.VoiceIdUpdateSessionActionProps(
                    action=["action"],
                    domain_id=["domainId"],
                    error_info=voiceid_events.VoiceIdUpdateSessionAction.ErrorInfo(
                        error_code=["errorCode"],
                        error_message=["errorMessage"],
                        error_type=["errorType"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    session=voiceid_events.VoiceIdUpdateSessionAction.Session(
                        authentication_configuration=voiceid_events.VoiceIdUpdateSessionAction.AuthenticationConfiguration(
                            acceptance_threshold=["acceptanceThreshold"]
                        ),
                        fraud_detection_configuration=voiceid_events.VoiceIdUpdateSessionAction.FraudDetectionConfiguration(
                            risk_threshold=["riskThreshold"],
                            watchlist_id=["watchlistId"]
                        ),
                        generated_speaker_id=["generatedSpeakerId"],
                        session_id=["sessionId"],
                        session_name=["sessionName"]
                    ),
                    source_id=["sourceId"],
                    status=["status"]
                )
            '''
            if isinstance(error_info, dict):
                error_info = VoiceIdUpdateSessionAction.ErrorInfo(**error_info)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(session, dict):
                session = VoiceIdUpdateSessionAction.Session(**session)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9bcb4b00195d34b79b21747a1eb7e9c294ff96496d49e30388763a9c60b6f9e1)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument domain_id", value=domain_id, expected_type=type_hints["domain_id"])
                check_type(argname="argument error_info", value=error_info, expected_type=type_hints["error_info"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument session", value=session, expected_type=type_hints["session"])
                check_type(argname="argument source_id", value=source_id, expected_type=type_hints["source_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if domain_id is not None:
                self._values["domain_id"] = domain_id
            if error_info is not None:
                self._values["error_info"] = error_info
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if session is not None:
                self._values["session"] = session
            if source_id is not None:
                self._values["source_id"] = source_id
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def domain_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) domainId property.

            Specify an array of string values to match this event if the actual value of domainId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Domain reference

            :stability: experimental
            '''
            result = self._values.get("domain_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_info(self) -> typing.Optional["VoiceIdUpdateSessionAction.ErrorInfo"]:
            '''(experimental) errorInfo property.

            Specify an array of string values to match this event if the actual value of errorInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_info")
            return typing.cast(typing.Optional["VoiceIdUpdateSessionAction.ErrorInfo"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def session(self) -> typing.Optional["VoiceIdUpdateSessionAction.Session"]:
            '''(experimental) session property.

            Specify an array of string values to match this event if the actual value of session is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session")
            return typing.cast(typing.Optional["VoiceIdUpdateSessionAction.Session"], result)

        @builtins.property
        def source_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceId property.

            Specify an array of string values to match this event if the actual value of sourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VoiceIdUpdateSessionActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "DomainEvents",
    "VoiceIdBatchFraudsterRegistrationAction",
    "VoiceIdBatchSpeakerEnrollmentAction",
    "VoiceIdEvaluateSessionAction",
    "VoiceIdFraudsterAction",
    "VoiceIdSessionSpeakerEnrollmentAction",
    "VoiceIdSpeakerAction",
    "VoiceIdStartSessionAction",
    "VoiceIdUpdateSessionAction",
]

publication.publish()

def _typecheckingstub__33f136a5b85b027f97dcce5d4bbabc0519a38dbb97bb11a589a536ecbfd7c0d4(
    domain_ref: _aws_cdk_interfaces_aws_voiceid_ceddda9d.IDomainRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ab8f0e5469cdef5e61dd62f12dc69aa1b25070e1053e729f02e32a28711c58da(
    *,
    data_access_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_data_config: typing.Optional[typing.Union[VoiceIdBatchFraudsterRegistrationAction.InputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    output_data_config: typing.Optional[typing.Union[VoiceIdBatchFraudsterRegistrationAction.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    registration_config: typing.Optional[typing.Union[VoiceIdBatchFraudsterRegistrationAction.RegistrationConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__595cd00f3cf73fadc8d1175fe0957a4c189bb8ceb04899de5d2431d16138def9(
    *,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__983c6a572e9587219c23e6718e32a56dc3dd72e4adc2e33c2577a369412c53f1(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9fe7c458c0fb3589343d555ffb7eee89881505fbc1405337173b0999009e6bc8(
    *,
    kms_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__20614181e1a1b2167ee32fd80168f8422546098d9af525cad5eb87668754a0fc(
    *,
    duplicate_registration_action: typing.Optional[typing.Sequence[builtins.str]] = None,
    fraudster_similarity_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
    watchlist_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1fc8dbe4b50273de65690d98ca24cb738af2156de20e8a79f648579a6729a5fe(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    batch_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    data: typing.Optional[typing.Union[VoiceIdBatchFraudsterRegistrationAction.Data, typing.Dict[builtins.str, typing.Any]]] = None,
    domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_info: typing.Optional[typing.Union[VoiceIdBatchFraudsterRegistrationAction.ErrorInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c9f7a1ee2953b34ba1c6e16dbb0bd29d2f6e69c2a4f6b8836f4d89072a9823d7(
    *,
    data_access_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    enrollment_config: typing.Optional[typing.Union[VoiceIdBatchSpeakerEnrollmentAction.EnrollmentConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    input_data_config: typing.Optional[typing.Union[VoiceIdBatchSpeakerEnrollmentAction.InputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    output_data_config: typing.Optional[typing.Union[VoiceIdBatchSpeakerEnrollmentAction.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4b857b815683eb7ebf4375db4b55193045a5183fb179d2d1b783c46a962f0a9(
    *,
    existing_enrollment_action: typing.Optional[typing.Sequence[builtins.str]] = None,
    fraud_detection_config: typing.Optional[typing.Union[VoiceIdBatchSpeakerEnrollmentAction.FraudDetectionConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6718a3440d9cc43c8fa26f7398b68ecc91189fa7c1d1c95aaadb912d91bb83d6(
    *,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec15f88918eeb52d7a958052f0557c4b7de3abc0887e0efdbb6ae08daf75433e(
    *,
    fraud_detection_action: typing.Optional[typing.Sequence[builtins.str]] = None,
    fraud_detection_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
    watchlist_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d3e517fb6fdc59875e07a9bdd0ffbe9a2e37b90c3444e441343f6f23dde9852(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ceaadd35e56845395e2c0674db19def6f1229e6ef8d35d6f845401f047f2ea5(
    *,
    kms_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a466159d22bda01bed7e5b8863057c5b3ef0c5f193cdfa24ac3fe51a875487a7(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    batch_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    data: typing.Optional[typing.Union[VoiceIdBatchSpeakerEnrollmentAction.Data, typing.Dict[builtins.str, typing.Any]]] = None,
    domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_info: typing.Optional[typing.Union[VoiceIdBatchSpeakerEnrollmentAction.ErrorInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f57ec2eb4da94f6f0a6ed67b6080467a004e1ceae3b8350b58b77e9b9a0a55d(
    *,
    audio_aggregation_ended_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    audio_aggregation_started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    authentication_result_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    configuration: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.ConfigurationAuthentication, typing.Dict[builtins.str, typing.Any]]] = None,
    decision: typing.Optional[typing.Sequence[builtins.str]] = None,
    score: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6703d383a4c759b0d7ec5f95c29272027f6a91b6f3d38287147839e1f607369(
    *,
    acceptance_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9db8a847b994a9d73c863acea6f91d7cb9fab6c1bef5cba24575f44ab1f3e704(
    *,
    risk_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
    watchlist_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__896d3992d0e438671b27d9c6bd24187215e6711d55166249d7274082ec91bcd0(
    *,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f20faaedd6e014a5705ec23a72b1fb12b5120887a7eeb8ca8d847bebc124b616(
    *,
    audio_aggregation_ended_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    audio_aggregation_started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    configuration: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.ConfigurationFraud, typing.Dict[builtins.str, typing.Any]]] = None,
    decision: typing.Optional[typing.Sequence[builtins.str]] = None,
    fraud_detection_result_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    reasons: typing.Optional[typing.Sequence[builtins.str]] = None,
    risk_details: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.RiskDetails, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__14acca7ab9e8966b00c2ba37e7748bd22b887df35e422e42a7366b57d878339e(
    *,
    generated_fraudster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    risk_score: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ffd9aa6a9198ea25ed52da627728a1acdf352d7b7cfd96ba05f6b772e108566d(
    *,
    known_fraudster_risk: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.KnownFraudsterRisk, typing.Dict[builtins.str, typing.Any]]] = None,
    voice_spoofing_risk: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.VoiceSpoofingRisk, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d15f8b611975bf0b29ef948aeabba21bebd752be9fbd1d70453f2f95598f1157(
    *,
    authentication_result: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.AuthenticationResult, typing.Dict[builtins.str, typing.Any]]] = None,
    fraud_detection_result: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.FraudDetectionResult, typing.Dict[builtins.str, typing.Any]]] = None,
    generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    streaming_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e00a1b319ffa8954c1d176357850c119666a382351547f2aa1677876f2de689(
    *,
    aws_connect_original_contact_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b82a78695fc08941f2bfbb5beeb1da634d05bc96d41fa33b4753143edbc5a6dc(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_info: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.ErrorInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    session: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.Session, typing.Dict[builtins.str, typing.Any]]] = None,
    source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    system_attributes: typing.Optional[typing.Union[VoiceIdEvaluateSessionAction.SystemAttributes, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c084610e6e978f091ecd25a38ef92c65a367b2756de7de053654f303e0080faa(
    *,
    risk_score: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b5750c95ac5ac939d9ad8642bd0e850198efa153c733fc3973a4038297e25d24(
    *,
    registration_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    registration_source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    registration_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebe682a1cb5a969258ba7cd95141764e4a8726beeacad9e6a14ac5d360cdd3f5(
    *,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__754bace7db668eb810b6b0c981ebcee4cd0ea40ea20eb55d5fece7bcf7973a56(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    data: typing.Optional[typing.Union[VoiceIdFraudsterAction.Data, typing.Dict[builtins.str, typing.Any]]] = None,
    domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_info: typing.Optional[typing.Union[VoiceIdFraudsterAction.ErrorInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    generated_fraudster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    watchlist_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a9fb50307d44e7d0f5116bd9b9bad5e80a41d1b36460d64cf415af1e797d315(
    *,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e0db977398f094cee5ad9bd44865db9e817fe88821b882c3ab06cd9cc4806ca5(
    *,
    aws_connect_original_contact_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aa76da471ea5c439052fbfe92d9dd71ce833c218ab6f1b06856894ff37c40a89(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_info: typing.Optional[typing.Union[VoiceIdSessionSpeakerEnrollmentAction.ErrorInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    system_attributes: typing.Optional[typing.Union[VoiceIdSessionSpeakerEnrollmentAction.SystemAttributes, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ecbad5f53edac3eac10b75899e043811a49911592a152e2279c939b126d3d5d(
    *,
    enrollment_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    enrollment_source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    enrollment_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8163829e0b0e9748ecd16a75731dc7bdcf8c193a6146175ae98d58ec8b9a479c(
    *,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60e5bf3e9b741df161004ce1efe353ee9bebd835f6b37f33770e782121044fd6(
    *,
    aws_connect_original_contact_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9ab2a6d91005748d6d81ae80ad863f0727995d4ed8b4b9be83e4d495bda704e3(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    data: typing.Optional[typing.Union[VoiceIdSpeakerAction.Data, typing.Dict[builtins.str, typing.Any]]] = None,
    domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_info: typing.Optional[typing.Union[VoiceIdSpeakerAction.ErrorInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    system_attributes: typing.Optional[typing.Union[VoiceIdSpeakerAction.SystemAttributes, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17f7084d20bffc26f533c1727a12da6672f1ec8feff0382fc224b424824116cb(
    *,
    audio_aggregation_ended_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    audio_aggregation_started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9d78454ff4998f7ce1be5944cc5ca6d76342690f603c168dd1a3b7e77310cd7b(
    *,
    acceptance_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83162e76671ee8ba6ecf8c318eb59c5fd0593c9623e9abf31f2e959500849aac(
    *,
    audio_aggregation_ended_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    audio_aggregation_started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    audio_aggregation_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a9454d6e8ca3108537c8fdfd10c0b35b034cd9276102d16152c344ddd2aaf816(
    *,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__482fca6f2dae8cfa0541cdb8e2dd4b67a6f9e57801761a022d96ca2abce4ac74(
    *,
    risk_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
    watchlist_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72e570a439c60d0e46dca6b9de2da6badf300d7c2e4913a0dc448f39027979a9(
    *,
    authentication_audio_progress: typing.Optional[typing.Union[VoiceIdStartSessionAction.AuthenticationAudioProgress, typing.Dict[builtins.str, typing.Any]]] = None,
    authentication_configuration: typing.Optional[typing.Union[VoiceIdStartSessionAction.AuthenticationConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    enrollment_audio_progress: typing.Optional[typing.Union[VoiceIdStartSessionAction.EnrollmentAudioProgress, typing.Dict[builtins.str, typing.Any]]] = None,
    fraud_detection_audio_progress: typing.Optional[typing.Union[VoiceIdStartSessionAction.AuthenticationAudioProgress, typing.Dict[builtins.str, typing.Any]]] = None,
    fraud_detection_configuration: typing.Optional[typing.Union[VoiceIdStartSessionAction.FraudDetectionConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    streaming_configuration: typing.Optional[typing.Union[VoiceIdStartSessionAction.StreamingConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__066ca5fc5755ad385196c3652197a6988081a157902d72b5424bf9648d4cfcfb(
    *,
    authentication_minimum_speech_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__235b9e2aea5678c492c2320919143eba448294458e80289a1d48c500b3ca160b(
    *,
    aws_connect_original_contact_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0f22142b34ed853d51e6721bbc767005847245dd3061c1546d8b604332ca07c1(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_info: typing.Optional[typing.Union[VoiceIdStartSessionAction.ErrorInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    session: typing.Optional[typing.Union[VoiceIdStartSessionAction.Session, typing.Dict[builtins.str, typing.Any]]] = None,
    source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    system_attributes: typing.Optional[typing.Union[VoiceIdStartSessionAction.SystemAttributes, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a1b22e6b7319eb07c67339ac794d467af8ebf6bf6905b34407ecc3ae1f89e5f(
    *,
    acceptance_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1b9a445efc448d8b5e93f71d4d1f3b3b7b15460aac8253408f27d056e9e8ccc(
    *,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__228be573520c359982dbf3c689801e5284a127b6a6f4f7a43a09e5011e03ea4d(
    *,
    risk_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
    watchlist_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74826bea4f7c8456695a9fcc9458c439aaa8e548420ac91025f6add39e38469d(
    *,
    authentication_configuration: typing.Optional[typing.Union[VoiceIdUpdateSessionAction.AuthenticationConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    fraud_detection_configuration: typing.Optional[typing.Union[VoiceIdUpdateSessionAction.FraudDetectionConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    generated_speaker_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bcb4b00195d34b79b21747a1eb7e9c294ff96496d49e30388763a9c60b6f9e1(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    domain_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_info: typing.Optional[typing.Union[VoiceIdUpdateSessionAction.ErrorInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    session: typing.Optional[typing.Union[VoiceIdUpdateSessionAction.Session, typing.Dict[builtins.str, typing.Any]]] = None,
    source_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
