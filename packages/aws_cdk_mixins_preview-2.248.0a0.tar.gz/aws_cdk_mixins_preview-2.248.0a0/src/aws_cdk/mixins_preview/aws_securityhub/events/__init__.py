from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class SecurityHubFindingsCustomAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_securityhub.events.SecurityHubFindingsCustomAction",
):
    '''(experimental) EventBridge event pattern for aws.securityhub@SecurityHubFindingsCustomAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_securityhub import events as securityhub_events
        
        security_hub_findings_custom_action = securityhub_events.SecurityHubFindingsCustomAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="securityHubFindingsCustomActionPattern")
    @builtins.classmethod
    def security_hub_findings_custom_action_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        findings: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Security Hub Findings - Custom Action.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param findings: (experimental) findings property. Specify an array of string values to match this event if the actual value of findings is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SecurityHubFindingsCustomAction.SecurityHubFindingsCustomActionProps(
            event_metadata=event_metadata, findings=findings
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "securityHubFindingsCustomActionPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_securityhub.events.SecurityHubFindingsCustomAction.SecurityHubFindingsCustomActionProps",
        jsii_struct_bases=[],
        name_mapping={"event_metadata": "eventMetadata", "findings": "findings"},
    )
    class SecurityHubFindingsCustomActionProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            findings: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.securityhub@SecurityHubFindingsCustomAction event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param findings: (experimental) findings property. Specify an array of string values to match this event if the actual value of findings is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_securityhub import events as securityhub_events
                
                security_hub_findings_custom_action_props = securityhub_events.SecurityHubFindingsCustomAction.SecurityHubFindingsCustomActionProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    findings=["findings"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6c4f6f218d1ee7f0d9a674915a63431b71852e2c900b9d6b4133b9a7110b4882)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument findings", value=findings, expected_type=type_hints["findings"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if findings is not None:
                self._values["findings"] = findings

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def findings(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) findings property.

            Specify an array of string values to match this event if the actual value of findings is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("findings")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SecurityHubFindingsCustomActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SecurityHubFindingsImported(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_securityhub.events.SecurityHubFindingsImported",
):
    '''(experimental) EventBridge event pattern for aws.securityhub@SecurityHubFindingsImported.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_securityhub import events as securityhub_events
        
        security_hub_findings_imported = securityhub_events.SecurityHubFindingsImported()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="securityHubFindingsImportedPattern")
    @builtins.classmethod
    def security_hub_findings_imported_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        findings: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Security Hub Findings - Imported.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param findings: (experimental) findings property. Specify an array of string values to match this event if the actual value of findings is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SecurityHubFindingsImported.SecurityHubFindingsImportedProps(
            event_metadata=event_metadata, findings=findings
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "securityHubFindingsImportedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_securityhub.events.SecurityHubFindingsImported.SecurityHubFindingsImportedProps",
        jsii_struct_bases=[],
        name_mapping={"event_metadata": "eventMetadata", "findings": "findings"},
    )
    class SecurityHubFindingsImportedProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            findings: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.securityhub@SecurityHubFindingsImported event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param findings: (experimental) findings property. Specify an array of string values to match this event if the actual value of findings is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_securityhub import events as securityhub_events
                
                security_hub_findings_imported_props = securityhub_events.SecurityHubFindingsImported.SecurityHubFindingsImportedProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    findings=["findings"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8a8b6deb7c1c0afe16eec3cb0dad8f870632d57cd2f9c544aca2753f3333019d)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument findings", value=findings, expected_type=type_hints["findings"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if findings is not None:
                self._values["findings"] = findings

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def findings(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) findings property.

            Specify an array of string values to match this event if the actual value of findings is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("findings")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SecurityHubFindingsImportedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SecurityHubInsightResults(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_securityhub.events.SecurityHubInsightResults",
):
    '''(experimental) EventBridge event pattern for aws.securityhub@SecurityHubInsightResults.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_securityhub import events as securityhub_events
        
        security_hub_insight_results = securityhub_events.SecurityHubInsightResults()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="securityHubInsightResultsPattern")
    @builtins.classmethod
    def security_hub_insight_results_pattern(
        cls,
        *,
        action_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        action_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        insight_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_results: typing.Optional[typing.Sequence[typing.Mapping[builtins.str, builtins.str]]] = None,
        result_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Security Hub Insight Results.

        :param action_description: (experimental) actionDescription property. Specify an array of string values to match this event if the actual value of actionDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param action_name: (experimental) actionName property. Specify an array of string values to match this event if the actual value of actionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param insight_arn: (experimental) insightArn property. Specify an array of string values to match this event if the actual value of insightArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_results: (experimental) insightResults property. Specify an array of string values to match this event if the actual value of insightResults is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param result_type: (experimental) resultType property. Specify an array of string values to match this event if the actual value of resultType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SecurityHubInsightResults.SecurityHubInsightResultsProps(
            action_description=action_description,
            action_name=action_name,
            event_metadata=event_metadata,
            insight_arn=insight_arn,
            insight_name=insight_name,
            insight_results=insight_results,
            result_type=result_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "securityHubInsightResultsPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_securityhub.events.SecurityHubInsightResults.SecurityHubInsightResultsProps",
        jsii_struct_bases=[],
        name_mapping={
            "action_description": "actionDescription",
            "action_name": "actionName",
            "event_metadata": "eventMetadata",
            "insight_arn": "insightArn",
            "insight_name": "insightName",
            "insight_results": "insightResults",
            "result_type": "resultType",
        },
    )
    class SecurityHubInsightResultsProps:
        def __init__(
            self,
            *,
            action_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            action_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            insight_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_results: typing.Optional[typing.Sequence[typing.Mapping[builtins.str, builtins.str]]] = None,
            result_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.securityhub@SecurityHubInsightResults event.

            :param action_description: (experimental) actionDescription property. Specify an array of string values to match this event if the actual value of actionDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param action_name: (experimental) actionName property. Specify an array of string values to match this event if the actual value of actionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param insight_arn: (experimental) insightArn property. Specify an array of string values to match this event if the actual value of insightArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_results: (experimental) insightResults property. Specify an array of string values to match this event if the actual value of insightResults is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param result_type: (experimental) resultType property. Specify an array of string values to match this event if the actual value of resultType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_securityhub import events as securityhub_events
                
                security_hub_insight_results_props = securityhub_events.SecurityHubInsightResults.SecurityHubInsightResultsProps(
                    action_description=["actionDescription"],
                    action_name=["actionName"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    insight_arn=["insightArn"],
                    insight_name=["insightName"],
                    insight_results=[{
                        "insight_results_key": "insightResults"
                    }],
                    result_type=["resultType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d506018ee9b61882047cb13d1e483133a7211cb8bef4d1c9c82d348af8f77eb6)
                check_type(argname="argument action_description", value=action_description, expected_type=type_hints["action_description"])
                check_type(argname="argument action_name", value=action_name, expected_type=type_hints["action_name"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument insight_arn", value=insight_arn, expected_type=type_hints["insight_arn"])
                check_type(argname="argument insight_name", value=insight_name, expected_type=type_hints["insight_name"])
                check_type(argname="argument insight_results", value=insight_results, expected_type=type_hints["insight_results"])
                check_type(argname="argument result_type", value=result_type, expected_type=type_hints["result_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action_description is not None:
                self._values["action_description"] = action_description
            if action_name is not None:
                self._values["action_name"] = action_name
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if insight_arn is not None:
                self._values["insight_arn"] = insight_arn
            if insight_name is not None:
                self._values["insight_name"] = insight_name
            if insight_results is not None:
                self._values["insight_results"] = insight_results
            if result_type is not None:
                self._values["result_type"] = result_type

        @builtins.property
        def action_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) actionDescription property.

            Specify an array of string values to match this event if the actual value of actionDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def action_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) actionName property.

            Specify an array of string values to match this event if the actual value of actionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def insight_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightArn property.

            Specify an array of string values to match this event if the actual value of insightArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightName property.

            Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_results(
            self,
        ) -> typing.Optional[typing.List[typing.Mapping[builtins.str, builtins.str]]]:
            '''(experimental) insightResults property.

            Specify an array of string values to match this event if the actual value of insightResults is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_results")
            return typing.cast(typing.Optional[typing.List[typing.Mapping[builtins.str, builtins.str]]], result)

        @builtins.property
        def result_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resultType property.

            Specify an array of string values to match this event if the actual value of resultType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("result_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SecurityHubInsightResultsProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "SecurityHubFindingsCustomAction",
    "SecurityHubFindingsImported",
    "SecurityHubInsightResults",
]

publication.publish()

def _typecheckingstub__6c4f6f218d1ee7f0d9a674915a63431b71852e2c900b9d6b4133b9a7110b4882(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    findings: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a8b6deb7c1c0afe16eec3cb0dad8f870632d57cd2f9c544aca2753f3333019d(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    findings: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d506018ee9b61882047cb13d1e483133a7211cb8bef4d1c9c82d348af8f77eb6(
    *,
    action_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    action_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    insight_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_results: typing.Optional[typing.Sequence[typing.Mapping[builtins.str, builtins.str]]] = None,
    result_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
