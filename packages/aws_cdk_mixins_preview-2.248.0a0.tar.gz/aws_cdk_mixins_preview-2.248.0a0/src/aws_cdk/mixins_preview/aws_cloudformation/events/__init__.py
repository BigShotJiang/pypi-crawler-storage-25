from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class CloudFormationHookInvocationProgress(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_cloudformation.events.CloudFormationHookInvocationProgress",
):
    '''(experimental) EventBridge event pattern for aws.cloudformation@CloudFormationHookInvocationProgress.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_cloudformation import events as cloudformation_events
        
        cloud_formation_hook_invocation_progress = cloudformation_events.CloudFormationHookInvocationProgress()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="cloudFormationHookInvocationProgressPattern")
    @builtins.classmethod
    def cloud_formation_hook_invocation_progress_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        hook_detail: typing.Optional[typing.Union["CloudFormationHookInvocationProgress.HookDetail", typing.Dict[builtins.str, typing.Any]]] = None,
        result: typing.Optional[typing.Union["CloudFormationHookInvocationProgress.Result", typing.Dict[builtins.str, typing.Any]]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        target_detail: typing.Optional[typing.Union["CloudFormationHookInvocationProgress.TargetDetail", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CloudFormation Hook Invocation Progress.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param hook_detail: (experimental) hook-detail property. Specify an array of string values to match this event if the actual value of hook-detail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param result: (experimental) result property. Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_reason: (experimental) status-reason property. Specify an array of string values to match this event if the actual value of status-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param target_detail: (experimental) target-detail property. Specify an array of string values to match this event if the actual value of target-detail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CloudFormationHookInvocationProgress.CloudFormationHookInvocationProgressProps(
            event_metadata=event_metadata,
            hook_detail=hook_detail,
            result=result,
            status=status,
            status_reason=status_reason,
            target_detail=target_detail,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "cloudFormationHookInvocationProgressPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudformation.events.CloudFormationHookInvocationProgress.CloudFormationHookInvocationProgressProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "hook_detail": "hookDetail",
            "result": "result",
            "status": "status",
            "status_reason": "statusReason",
            "target_detail": "targetDetail",
        },
    )
    class CloudFormationHookInvocationProgressProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            hook_detail: typing.Optional[typing.Union["CloudFormationHookInvocationProgress.HookDetail", typing.Dict[builtins.str, typing.Any]]] = None,
            result: typing.Optional[typing.Union["CloudFormationHookInvocationProgress.Result", typing.Dict[builtins.str, typing.Any]]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_detail: typing.Optional[typing.Union["CloudFormationHookInvocationProgress.TargetDetail", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.cloudformation@CloudFormationHookInvocationProgress event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param hook_detail: (experimental) hook-detail property. Specify an array of string values to match this event if the actual value of hook-detail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param result: (experimental) result property. Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_reason: (experimental) status-reason property. Specify an array of string values to match this event if the actual value of status-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_detail: (experimental) target-detail property. Specify an array of string values to match this event if the actual value of target-detail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_cloudformation import events as cloudformation_events
                
                cloud_formation_hook_invocation_progress_props = cloudformation_events.CloudFormationHookInvocationProgress.CloudFormationHookInvocationProgressProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    hook_detail=cloudformation_events.CloudFormationHookInvocationProgress.HookDetail(
                        description=["description"],
                        documentation_url=["documentationUrl"],
                        failure_mode=["failureMode"],
                        hook_type_arn=["hookTypeArn"],
                        hook_type_name=["hookTypeName"],
                        hook_version=["hookVersion"],
                        source_url=["sourceUrl"]
                    ),
                    result=cloudformation_events.CloudFormationHookInvocationProgress.Result(
                        data=["data"]
                    ),
                    status=["status"],
                    status_reason=["statusReason"],
                    target_detail=cloudformation_events.CloudFormationHookInvocationProgress.TargetDetail(
                        target_action=["targetAction"],
                        target_id=["targetId"],
                        target_invocation_point=["targetInvocationPoint"],
                        target_name=["targetName"],
                        target_type=["targetType"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(hook_detail, dict):
                hook_detail = CloudFormationHookInvocationProgress.HookDetail(**hook_detail)
            if isinstance(result, dict):
                result = CloudFormationHookInvocationProgress.Result(**result)
            if isinstance(target_detail, dict):
                target_detail = CloudFormationHookInvocationProgress.TargetDetail(**target_detail)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b28989df160a7689df578b09cb1a1e7e2ccb0a3e8871a65e64e367de304ddf48)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument hook_detail", value=hook_detail, expected_type=type_hints["hook_detail"])
                check_type(argname="argument result", value=result, expected_type=type_hints["result"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument status_reason", value=status_reason, expected_type=type_hints["status_reason"])
                check_type(argname="argument target_detail", value=target_detail, expected_type=type_hints["target_detail"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if hook_detail is not None:
                self._values["hook_detail"] = hook_detail
            if result is not None:
                self._values["result"] = result
            if status is not None:
                self._values["status"] = status
            if status_reason is not None:
                self._values["status_reason"] = status_reason
            if target_detail is not None:
                self._values["target_detail"] = target_detail

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def hook_detail(
            self,
        ) -> typing.Optional["CloudFormationHookInvocationProgress.HookDetail"]:
            '''(experimental) hook-detail property.

            Specify an array of string values to match this event if the actual value of hook-detail is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hook_detail")
            return typing.cast(typing.Optional["CloudFormationHookInvocationProgress.HookDetail"], result)

        @builtins.property
        def result(
            self,
        ) -> typing.Optional["CloudFormationHookInvocationProgress.Result"]:
            '''(experimental) result property.

            Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("result")
            return typing.cast(typing.Optional["CloudFormationHookInvocationProgress.Result"], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status-reason property.

            Specify an array of string values to match this event if the actual value of status-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_detail(
            self,
        ) -> typing.Optional["CloudFormationHookInvocationProgress.TargetDetail"]:
            '''(experimental) target-detail property.

            Specify an array of string values to match this event if the actual value of target-detail is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_detail")
            return typing.cast(typing.Optional["CloudFormationHookInvocationProgress.TargetDetail"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudFormationHookInvocationProgressProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudformation.events.CloudFormationHookInvocationProgress.HookDetail",
        jsii_struct_bases=[],
        name_mapping={
            "description": "description",
            "documentation_url": "documentationUrl",
            "failure_mode": "failureMode",
            "hook_type_arn": "hookTypeArn",
            "hook_type_name": "hookTypeName",
            "hook_version": "hookVersion",
            "source_url": "sourceUrl",
        },
    )
    class HookDetail:
        def __init__(
            self,
            *,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            documentation_url: typing.Optional[typing.Sequence[builtins.str]] = None,
            failure_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
            hook_type_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            hook_type_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            hook_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Hook-detail.

            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param documentation_url: (experimental) documentation-url property. Specify an array of string values to match this event if the actual value of documentation-url is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param failure_mode: (experimental) failure-mode property. Specify an array of string values to match this event if the actual value of failure-mode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param hook_type_arn: (experimental) hook-type-arn property. Specify an array of string values to match this event if the actual value of hook-type-arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param hook_type_name: (experimental) hook-type-name property. Specify an array of string values to match this event if the actual value of hook-type-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param hook_version: (experimental) hook-version property. Specify an array of string values to match this event if the actual value of hook-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_url: (experimental) source-url property. Specify an array of string values to match this event if the actual value of source-url is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_cloudformation import events as cloudformation_events
                
                hook_detail = cloudformation_events.CloudFormationHookInvocationProgress.HookDetail(
                    description=["description"],
                    documentation_url=["documentationUrl"],
                    failure_mode=["failureMode"],
                    hook_type_arn=["hookTypeArn"],
                    hook_type_name=["hookTypeName"],
                    hook_version=["hookVersion"],
                    source_url=["sourceUrl"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__81c58f9fb48615c870c268a5779706ac0b1a2b2462c03315f8db831b5d58150e)
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument documentation_url", value=documentation_url, expected_type=type_hints["documentation_url"])
                check_type(argname="argument failure_mode", value=failure_mode, expected_type=type_hints["failure_mode"])
                check_type(argname="argument hook_type_arn", value=hook_type_arn, expected_type=type_hints["hook_type_arn"])
                check_type(argname="argument hook_type_name", value=hook_type_name, expected_type=type_hints["hook_type_name"])
                check_type(argname="argument hook_version", value=hook_version, expected_type=type_hints["hook_version"])
                check_type(argname="argument source_url", value=source_url, expected_type=type_hints["source_url"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if description is not None:
                self._values["description"] = description
            if documentation_url is not None:
                self._values["documentation_url"] = documentation_url
            if failure_mode is not None:
                self._values["failure_mode"] = failure_mode
            if hook_type_arn is not None:
                self._values["hook_type_arn"] = hook_type_arn
            if hook_type_name is not None:
                self._values["hook_type_name"] = hook_type_name
            if hook_version is not None:
                self._values["hook_version"] = hook_version
            if source_url is not None:
                self._values["source_url"] = source_url

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def documentation_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) documentation-url property.

            Specify an array of string values to match this event if the actual value of documentation-url is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("documentation_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def failure_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) failure-mode property.

            Specify an array of string values to match this event if the actual value of failure-mode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failure_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def hook_type_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) hook-type-arn property.

            Specify an array of string values to match this event if the actual value of hook-type-arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hook_type_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def hook_type_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) hook-type-name property.

            Specify an array of string values to match this event if the actual value of hook-type-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hook_type_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def hook_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) hook-version property.

            Specify an array of string values to match this event if the actual value of hook-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hook_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source-url property.

            Specify an array of string values to match this event if the actual value of source-url is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "HookDetail(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudformation.events.CloudFormationHookInvocationProgress.Result",
        jsii_struct_bases=[],
        name_mapping={"data": "data"},
    )
    class Result:
        def __init__(
            self,
            *,
            data: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Result.

            :param data: (experimental) data property. Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_cloudformation import events as cloudformation_events
                
                result = cloudformation_events.CloudFormationHookInvocationProgress.Result(
                    data=["data"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1d4659402b4eed80a6cb6e858a094bbb3750443c7e9e4f6dd1e8a358135b740a)
                check_type(argname="argument data", value=data, expected_type=type_hints["data"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data is not None:
                self._values["data"] = data

        @builtins.property
        def data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) data property.

            Specify an array of string values to match this event if the actual value of data is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Result(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudformation.events.CloudFormationHookInvocationProgress.TargetDetail",
        jsii_struct_bases=[],
        name_mapping={
            "target_action": "targetAction",
            "target_id": "targetId",
            "target_invocation_point": "targetInvocationPoint",
            "target_name": "targetName",
            "target_type": "targetType",
        },
    )
    class TargetDetail:
        def __init__(
            self,
            *,
            target_action: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_invocation_point: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Target-detail.

            :param target_action: (experimental) target-action property. Specify an array of string values to match this event if the actual value of target-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_id: (experimental) target-id property. Specify an array of string values to match this event if the actual value of target-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_invocation_point: (experimental) target-invocation-point property. Specify an array of string values to match this event if the actual value of target-invocation-point is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_name: (experimental) target-name property. Specify an array of string values to match this event if the actual value of target-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_type: (experimental) target-type property. Specify an array of string values to match this event if the actual value of target-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_cloudformation import events as cloudformation_events
                
                target_detail = cloudformation_events.CloudFormationHookInvocationProgress.TargetDetail(
                    target_action=["targetAction"],
                    target_id=["targetId"],
                    target_invocation_point=["targetInvocationPoint"],
                    target_name=["targetName"],
                    target_type=["targetType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__44cb2299c5bed9cb932526ebbabafea42eb7ed41f31f53925b363f7c1e53d502)
                check_type(argname="argument target_action", value=target_action, expected_type=type_hints["target_action"])
                check_type(argname="argument target_id", value=target_id, expected_type=type_hints["target_id"])
                check_type(argname="argument target_invocation_point", value=target_invocation_point, expected_type=type_hints["target_invocation_point"])
                check_type(argname="argument target_name", value=target_name, expected_type=type_hints["target_name"])
                check_type(argname="argument target_type", value=target_type, expected_type=type_hints["target_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if target_action is not None:
                self._values["target_action"] = target_action
            if target_id is not None:
                self._values["target_id"] = target_id
            if target_invocation_point is not None:
                self._values["target_invocation_point"] = target_invocation_point
            if target_name is not None:
                self._values["target_name"] = target_name
            if target_type is not None:
                self._values["target_type"] = target_type

        @builtins.property
        def target_action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) target-action property.

            Specify an array of string values to match this event if the actual value of target-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) target-id property.

            Specify an array of string values to match this event if the actual value of target-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_invocation_point(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) target-invocation-point property.

            Specify an array of string values to match this event if the actual value of target-invocation-point is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_invocation_point")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) target-name property.

            Specify an array of string values to match this event if the actual value of target-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) target-type property.

            Specify an array of string values to match this event if the actual value of target-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TargetDetail(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "CloudFormationHookInvocationProgress",
]

publication.publish()

def _typecheckingstub__b28989df160a7689df578b09cb1a1e7e2ccb0a3e8871a65e64e367de304ddf48(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    hook_detail: typing.Optional[typing.Union[CloudFormationHookInvocationProgress.HookDetail, typing.Dict[builtins.str, typing.Any]]] = None,
    result: typing.Optional[typing.Union[CloudFormationHookInvocationProgress.Result, typing.Dict[builtins.str, typing.Any]]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_detail: typing.Optional[typing.Union[CloudFormationHookInvocationProgress.TargetDetail, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__81c58f9fb48615c870c268a5779706ac0b1a2b2462c03315f8db831b5d58150e(
    *,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    documentation_url: typing.Optional[typing.Sequence[builtins.str]] = None,
    failure_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
    hook_type_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    hook_type_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    hook_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_url: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d4659402b4eed80a6cb6e858a094bbb3750443c7e9e4f6dd1e8a358135b740a(
    *,
    data: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__44cb2299c5bed9cb932526ebbabafea42eb7ed41f31f53925b363f7c1e53d502(
    *,
    target_action: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_invocation_point: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
