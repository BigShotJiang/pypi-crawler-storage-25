from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnRoomIvsChatLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomIvsChatLogs",
):
    '''Builder for CfnRoomLogsMixin to generate IVS_CHAT_LOGS for CfnRoom.

    :cloudformationResource: AWS::IVSChat::Room
    :logType: IVS_CHAT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ivschat import mixins as ivschat_mixins
        
        cfn_room_ivs_chat_logs = ivschat_mixins.CfnRoomIvsChatLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnRoomLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e6acc76d4e12e0de8b73aa455619ad1db51502f62e91257d4fc0091dc55235d)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnRoomLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnRoomIvsChatLogsOutputFormat.Firehose"] = None,
    ) -> "CfnRoomLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__964fc065f8d788030bd87553c517f5dd179e29d5e920baba712a1b8d97e16cae)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnRoomIvsChatLogsFirehoseProps(output_format=output_format)

        return typing.cast("CfnRoomLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnRoomIvsChatLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnRoomLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf16885d07c2e2034c56d635f34c77e5c53eb26f133f46bf59faffdb9d93c258)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnRoomIvsChatLogsLogGroupProps(output_format=output_format)

        return typing.cast("CfnRoomLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRoomIvsChatLogsOutputFormat.S3"] = None,
    ) -> "CfnRoomLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__239334597e3950c1c8a4096b06b85d6e56488f7088b4dcfd0146b8be851664b5)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnRoomIvsChatLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnRoomLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomIvsChatLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnRoomIvsChatLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRoomIvsChatLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ivschat import mixins as ivschat_mixins
            
            cfn_room_ivs_chat_logs_firehose_props = ivschat_mixins.CfnRoomIvsChatLogsFirehoseProps(
                output_format=ivschat_mixins.CfnRoomIvsChatLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__610716c0de190361891dbcaf9a43bf6fc6aca64d670d98a37c4ee09251ef4a0b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRoomIvsChatLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRoomIvsChatLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRoomIvsChatLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomIvsChatLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnRoomIvsChatLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRoomIvsChatLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ivschat import mixins as ivschat_mixins
            
            cfn_room_ivs_chat_logs_log_group_props = ivschat_mixins.CfnRoomIvsChatLogsLogGroupProps(
                output_format=ivschat_mixins.CfnRoomIvsChatLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e743afd51436c48f75c989fc9254bb64554686958f705c0b97eb2f7f269d93b7)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRoomIvsChatLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRoomIvsChatLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRoomIvsChatLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRoomIvsChatLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomIvsChatLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnRoomIvsChatLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ivschat import mixins as ivschat_mixins
        
        cfn_room_ivs_chat_logs_output_format = ivschat_mixins.CfnRoomIvsChatLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomIvsChatLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomIvsChatLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomIvsChatLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomIvsChatLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnRoomIvsChatLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRoomIvsChatLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ivschat import mixins as ivschat_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_room_ivs_chat_logs_s3_props = ivschat_mixins.CfnRoomIvsChatLogsS3Props(
                encryption_key=key_ref,
                output_format=ivschat_mixins.CfnRoomIvsChatLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9fc1f44270dda36cfdd6949537297b91c5aef5429072b9fdc8471ed8b75df47)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnRoomIvsChatLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRoomIvsChatLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRoomIvsChatLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnRoomLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ivschat.mixins.CfnRoomLogsMixin",
):
    '''The ``AWS::IVSChat::Room`` resource specifies an  room that allows clients to connect and pass messages.

    For more information, see `CreateRoom <https://docs.aws.amazon.com/ivs/latest/ChatAPIReference/API_CreateRoom.html>`_ in the *Amazon Interactive Video Service Chat API Reference* .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html
    :cloudformationResource: AWS::IVSChat::Room
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_ivschat import mixins as ivschat_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_room_logs_mixin = ivschat_mixins.CfnRoomLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::IVSChat::Room``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d096f6313b36083a367b6f143d55894b9d3786e937e89b182804a65e438da8c1)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dbb9c982365bc47dcf9869ea5bb93bd2a69f8eb47c081ae008c189bcf47cbf17)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1ef08afd0dc0d163df2d4696463b9537ac8c720dd4224685f91b4fc956b4672)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="IVS_CHAT_LOGS")
    def IVS_CHAT_LOGS(cls) -> "CfnRoomIvsChatLogs":
        return typing.cast("CfnRoomIvsChatLogs", jsii.sget(cls, "IVS_CHAT_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnRoomIvsChatLogs",
    "CfnRoomIvsChatLogsFirehoseProps",
    "CfnRoomIvsChatLogsLogGroupProps",
    "CfnRoomIvsChatLogsOutputFormat",
    "CfnRoomIvsChatLogsS3Props",
    "CfnRoomLogsMixin",
]

publication.publish()

def _typecheckingstub__7e6acc76d4e12e0de8b73aa455619ad1db51502f62e91257d4fc0091dc55235d(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__964fc065f8d788030bd87553c517f5dd179e29d5e920baba712a1b8d97e16cae(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnRoomIvsChatLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf16885d07c2e2034c56d635f34c77e5c53eb26f133f46bf59faffdb9d93c258(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnRoomIvsChatLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__239334597e3950c1c8a4096b06b85d6e56488f7088b4dcfd0146b8be851664b5(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRoomIvsChatLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__610716c0de190361891dbcaf9a43bf6fc6aca64d670d98a37c4ee09251ef4a0b(
    *,
    output_format: typing.Optional[CfnRoomIvsChatLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e743afd51436c48f75c989fc9254bb64554686958f705c0b97eb2f7f269d93b7(
    *,
    output_format: typing.Optional[CfnRoomIvsChatLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9fc1f44270dda36cfdd6949537297b91c5aef5429072b9fdc8471ed8b75df47(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRoomIvsChatLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d096f6313b36083a367b6f143d55894b9d3786e937e89b182804a65e438da8c1(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dbb9c982365bc47dcf9869ea5bb93bd2a69f8eb47c081ae008c189bcf47cbf17(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1ef08afd0dc0d163df2d4696463b9537ac8c720dd4224685f91b4fc956b4672(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
