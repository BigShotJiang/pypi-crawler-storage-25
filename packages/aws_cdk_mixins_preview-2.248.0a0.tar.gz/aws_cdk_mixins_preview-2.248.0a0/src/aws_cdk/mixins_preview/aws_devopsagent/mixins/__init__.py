from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnAgentSpaceApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogs",
):
    '''Builder for CfnAgentSpaceLogsMixin to generate APPLICATION_LOGS for CfnAgentSpace.

    :cloudformationResource: AWS::DevOpsAgent::AgentSpace
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_devopsagent import mixins as devopsagent_mixins
        
        cfn_agent_space_application_logs = devopsagent_mixins.CfnAgentSpaceApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnAgentSpaceApplicationLogsRecordFields"]] = None,
    ) -> "CfnAgentSpaceLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ccee696fa09b7d5fd0bad428e7b4ac06c3f71b52a356816f9a56ce500430c1d)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnAgentSpaceApplicationLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnAgentSpaceLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentSpaceApplicationLogsRecordFields"]] = None,
    ) -> "CfnAgentSpaceLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1b2ef55e4d4a21743bb0f5c8ea757e597202ac61dd63a7bc25b5a7533fe50f2)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnAgentSpaceApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnAgentSpaceLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentSpaceApplicationLogsRecordFields"]] = None,
    ) -> "CfnAgentSpaceLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__259c7eb8f81b50789cbf6e056e05e00903e110c74a7eab202de71b30d15845da)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnAgentSpaceApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnAgentSpaceLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentSpaceApplicationLogsRecordFields"]] = None,
    ) -> "CfnAgentSpaceLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1f787d41b1104f540caf07e5df492565274ed2c0d20aeb7c7add470be209648)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnAgentSpaceApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnAgentSpaceLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnAgentSpaceApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnAgentSpaceApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_devopsagent import mixins as devopsagent_mixins
            
            cfn_agent_space_application_logs_dest_props = devopsagent_mixins.CfnAgentSpaceApplicationLogsDestProps(
                record_fields=[devopsagent_mixins.CfnAgentSpaceApplicationLogsRecordFields.OPTIONAL_ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e34b06d0cefaaf1a78f8fbcdace7fa2cb7283fa92e02803bf7d328f834297955)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentSpaceApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentSpaceApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentSpaceApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnAgentSpaceApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentSpaceApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_devopsagent import mixins as devopsagent_mixins
            
            cfn_agent_space_application_logs_firehose_props = devopsagent_mixins.CfnAgentSpaceApplicationLogsFirehoseProps(
                output_format=devopsagent_mixins.CfnAgentSpaceApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[devopsagent_mixins.CfnAgentSpaceApplicationLogsRecordFields.OPTIONAL_ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__210a2e3469c9f7d4b5681b181e62d1a60689852431492340d0f1ad6c5bde98b4)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentSpaceApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentSpaceApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentSpaceApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnAgentSpaceApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentSpaceApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_devopsagent import mixins as devopsagent_mixins
            
            cfn_agent_space_application_logs_log_group_props = devopsagent_mixins.CfnAgentSpaceApplicationLogsLogGroupProps(
                output_format=devopsagent_mixins.CfnAgentSpaceApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[devopsagent_mixins.CfnAgentSpaceApplicationLogsRecordFields.OPTIONAL_ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4665ea5eff066e24a1aafc8aabbbb14b40a77bebf12159d7ee6f564130117542)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentSpaceApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentSpaceApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentSpaceApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnAgentSpaceApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnAgentSpaceApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_devopsagent import mixins as devopsagent_mixins
        
        cfn_agent_space_application_logs_output_format = devopsagent_mixins.CfnAgentSpaceApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsRecordFields"
)
class CfnAgentSpaceApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    OPTIONAL_ACCOUNT_ID = "OPTIONAL_ACCOUNT_ID"
    '''
    :stability: experimental
    '''
    OPTIONAL_AGENT_SPACE_ID = "OPTIONAL_AGENT_SPACE_ID"
    '''
    :stability: experimental
    '''
    OPTIONAL_LEVEL = "OPTIONAL_LEVEL"
    '''
    :stability: experimental
    '''
    OPTIONAL_ASSOCIATION_ID = "OPTIONAL_ASSOCIATION_ID"
    '''
    :stability: experimental
    '''
    OPTIONAL_STATUS = "OPTIONAL_STATUS"
    '''
    :stability: experimental
    '''
    OPTIONAL_WEBHOOK_ID = "OPTIONAL_WEBHOOK_ID"
    '''
    :stability: experimental
    '''
    OPTIONAL_MCP_ENDPOINT_URL = "OPTIONAL_MCP_ENDPOINT_URL"
    '''
    :stability: experimental
    '''
    OPTIONAL_SERVICE_TYPE = "OPTIONAL_SERVICE_TYPE"
    '''
    :stability: experimental
    '''
    OPTIONAL_SERVICE_ENDPOINT_URL = "OPTIONAL_SERVICE_ENDPOINT_URL"
    '''
    :stability: experimental
    '''
    OPTIONAL_SERVICE_ID = "OPTIONAL_SERVICE_ID"
    '''
    :stability: experimental
    '''
    OPTIONAL_REQUEST_ID = "OPTIONAL_REQUEST_ID"
    '''
    :stability: experimental
    '''
    OPTIONAL_OPERATION = "OPTIONAL_OPERATION"
    '''
    :stability: experimental
    '''
    OPTIONAL_TASK_TYPE = "OPTIONAL_TASK_TYPE"
    '''
    :stability: experimental
    '''
    OPTIONAL_TASK_ID = "OPTIONAL_TASK_ID"
    '''
    :stability: experimental
    '''
    OPTIONAL_REFERENCE = "OPTIONAL_REFERENCE"
    '''
    :stability: experimental
    '''
    OPTIONAL_ERROR_TYPE = "OPTIONAL_ERROR_TYPE"
    '''
    :stability: experimental
    '''
    OPTIONAL_ERROR_MESSAGE = "OPTIONAL_ERROR_MESSAGE"
    '''
    :stability: experimental
    '''
    OPTIONAL_DETAILS = "OPTIONAL_DETAILS"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnAgentSpaceApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentSpaceApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_devopsagent import mixins as devopsagent_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_agent_space_application_logs_s3_props = devopsagent_mixins.CfnAgentSpaceApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=devopsagent_mixins.CfnAgentSpaceApplicationLogsOutputFormat.S3.JSON,
                record_fields=[devopsagent_mixins.CfnAgentSpaceApplicationLogsRecordFields.OPTIONAL_ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76b37fad9da745ee5f99a975ad75b36bfa7716de3e07c54520938202e4ce4875)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentSpaceApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentSpaceApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentSpaceApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentSpaceApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnAgentSpaceLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_devopsagent.mixins.CfnAgentSpaceLogsMixin",
):
    '''The ``AWS::DevOpsAgent::AgentSpace`` resource specifies an Agent Space for the AWS DevOps Agent Service.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html
    :cloudformationResource: AWS::DevOpsAgent::AgentSpace
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_devopsagent import mixins as devopsagent_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_agent_space_logs_mixin = devopsagent_mixins.CfnAgentSpaceLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::DevOpsAgent::AgentSpace``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__da326cc6387df2fd988e12b9ff35959c930e2794d29a110113cc1bdd0f305eb5)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9872be5f9be9f9db45c8964c8a0845e9610ffb0f0db71170df988e852d055ec)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__533dd9f1894496f2a0f695b099100e8ab2cc97ba2aabfd405c085370819ed270)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnAgentSpaceApplicationLogs":
        return typing.cast("CfnAgentSpaceApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnAgentSpaceApplicationLogs",
    "CfnAgentSpaceApplicationLogsDestProps",
    "CfnAgentSpaceApplicationLogsFirehoseProps",
    "CfnAgentSpaceApplicationLogsLogGroupProps",
    "CfnAgentSpaceApplicationLogsOutputFormat",
    "CfnAgentSpaceApplicationLogsRecordFields",
    "CfnAgentSpaceApplicationLogsS3Props",
    "CfnAgentSpaceLogsMixin",
]

publication.publish()

def _typecheckingstub__5ccee696fa09b7d5fd0bad428e7b4ac06c3f71b52a356816f9a56ce500430c1d(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnAgentSpaceApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1b2ef55e4d4a21743bb0f5c8ea757e597202ac61dd63a7bc25b5a7533fe50f2(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnAgentSpaceApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentSpaceApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__259c7eb8f81b50789cbf6e056e05e00903e110c74a7eab202de71b30d15845da(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnAgentSpaceApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentSpaceApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1f787d41b1104f540caf07e5df492565274ed2c0d20aeb7c7add470be209648(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnAgentSpaceApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentSpaceApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e34b06d0cefaaf1a78f8fbcdace7fa2cb7283fa92e02803bf7d328f834297955(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnAgentSpaceApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__210a2e3469c9f7d4b5681b181e62d1a60689852431492340d0f1ad6c5bde98b4(
    *,
    output_format: typing.Optional[CfnAgentSpaceApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentSpaceApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4665ea5eff066e24a1aafc8aabbbb14b40a77bebf12159d7ee6f564130117542(
    *,
    output_format: typing.Optional[CfnAgentSpaceApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentSpaceApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76b37fad9da745ee5f99a975ad75b36bfa7716de3e07c54520938202e4ce4875(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnAgentSpaceApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentSpaceApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da326cc6387df2fd988e12b9ff35959c930e2794d29a110113cc1bdd0f305eb5(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9872be5f9be9f9db45c8964c8a0845e9610ffb0f0db71170df988e852d055ec(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__533dd9f1894496f2a0f695b099100e8ab2cc97ba2aabfd405c085370819ed270(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
