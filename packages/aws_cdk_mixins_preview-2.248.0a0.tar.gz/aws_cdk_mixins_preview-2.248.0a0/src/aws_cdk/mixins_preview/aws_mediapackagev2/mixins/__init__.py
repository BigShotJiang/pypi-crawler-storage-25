from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnChannelGroupEgressAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogs",
):
    '''Builder for CfnChannelGroupLogsMixin to generate EGRESS_ACCESS_LOGS for CfnChannelGroup.

    :cloudformationResource: AWS::MediaPackageV2::ChannelGroup
    :logType: EGRESS_ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
        
        cfn_channel_group_egress_access_logs = mediapackagev2_mixins.CfnChannelGroupEgressAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupEgressAccessLogsRecordFields"]] = None,
    ) -> "CfnChannelGroupLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e4e16e9cd62f8a6ca7e1ccd4454fa6a6e8547b0209e1140ce7e19fd054a63acd)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnChannelGroupEgressAccessLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnChannelGroupLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupEgressAccessLogsRecordFields"]] = None,
    ) -> "CfnChannelGroupLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__696024da3bf568d08005e3641147133c17b2da51832cb4acac82fcd5bae720a5)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnChannelGroupEgressAccessLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnChannelGroupLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupEgressAccessLogsRecordFields"]] = None,
    ) -> "CfnChannelGroupLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b92e944d56a610a0d455ef72b8a50bff2e60ef061c4ad5f0c00e03a8b7bf316)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnChannelGroupEgressAccessLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnChannelGroupLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupEgressAccessLogsRecordFields"]] = None,
    ) -> "CfnChannelGroupLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5f61a6e590606f957cc1efc500e3aa79a3b15cad35d7735ef0a54d3f97343ee5)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnChannelGroupEgressAccessLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnChannelGroupLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnChannelGroupEgressAccessLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupEgressAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
            
            cfn_channel_group_egress_access_logs_dest_props = mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsDestProps(
                record_fields=[mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ac9729527eebcbc6de25c0c0c19d2c5d8c3a0dd5d449f7ba579493959847078d)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnChannelGroupEgressAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnChannelGroupEgressAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnChannelGroupEgressAccessLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnChannelGroupEgressAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupEgressAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
            
            cfn_channel_group_egress_access_logs_firehose_props = mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsFirehoseProps(
                output_format=mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsOutputFormat.Firehose.JSON,
                record_fields=[mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45b72812559a07a8db4b07e70e48f4d2ee59f75cd8ada0aab169ebd0c69c5a78)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnChannelGroupEgressAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnChannelGroupEgressAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnChannelGroupEgressAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnChannelGroupEgressAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupEgressAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
            
            cfn_channel_group_egress_access_logs_log_group_props = mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsLogGroupProps(
                output_format=mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e373ccee3bf13333b75b699d2d0bd8214485a1939e566e826ad51da891d22ee)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnChannelGroupEgressAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnChannelGroupEgressAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnChannelGroupEgressAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnChannelGroupEgressAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnChannelGroupEgressAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
        
        cfn_channel_group_egress_access_logs_output_format = mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsRecordFields"
)
class CfnChannelGroupEgressAccessLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    CLIENT_IP = "CLIENT_IP"
    '''
    :stability: experimental
    '''
    TIME_TO_FIRST_BYTE = "TIME_TO_FIRST_BYTE"
    '''
    :stability: experimental
    '''
    STATUS_CODE = "STATUS_CODE"
    '''
    :stability: experimental
    '''
    RECEIVED_BYTES = "RECEIVED_BYTES"
    '''
    :stability: experimental
    '''
    SENT_BYTES = "SENT_BYTES"
    '''
    :stability: experimental
    '''
    METHOD = "METHOD"
    '''
    :stability: experimental
    '''
    REQUEST_URI_BASE = "REQUEST_URI_BASE"
    '''
    :stability: experimental
    '''
    REQUEST_QUERY_PARAMS = "REQUEST_QUERY_PARAMS"
    '''
    :stability: experimental
    '''
    PROTOCOL = "PROTOCOL"
    '''
    :stability: experimental
    '''
    USER_AGENT = "USER_AGENT"
    '''
    :stability: experimental
    '''
    DOMAIN_NAME = "DOMAIN_NAME"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    ACCOUNT = "ACCOUNT"
    '''
    :stability: experimental
    '''
    CHANNEL_ID = "CHANNEL_ID"
    '''
    :stability: experimental
    '''
    CHANNEL_ARN = "CHANNEL_ARN"
    '''
    :stability: experimental
    '''
    ENDPOINT_ID = "ENDPOINT_ID"
    '''
    :stability: experimental
    '''
    ENDPOINT_ARN = "ENDPOINT_ARN"
    '''
    :stability: experimental
    '''
    CHANNEL_GROUP_ID = "CHANNEL_GROUP_ID"
    '''
    :stability: experimental
    '''
    MANIFEST_NAME = "MANIFEST_NAME"
    '''
    :stability: experimental
    '''
    MANIFEST_TYPE = "MANIFEST_TYPE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupEgressAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnChannelGroupEgressAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupEgressAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_channel_group_egress_access_logs_s3_props = mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsOutputFormat.S3.JSON,
                record_fields=[mediapackagev2_mixins.CfnChannelGroupEgressAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f562c74e2c89b7ebbd5251ceb08116f69a1992572066b2cbe983774c88899b92)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnChannelGroupEgressAccessLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnChannelGroupEgressAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnChannelGroupEgressAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnChannelGroupEgressAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnChannelGroupIngressAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogs",
):
    '''Builder for CfnChannelGroupLogsMixin to generate INGRESS_ACCESS_LOGS for CfnChannelGroup.

    :cloudformationResource: AWS::MediaPackageV2::ChannelGroup
    :logType: INGRESS_ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
        
        cfn_channel_group_ingress_access_logs = mediapackagev2_mixins.CfnChannelGroupIngressAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupIngressAccessLogsRecordFields"]] = None,
    ) -> "CfnChannelGroupLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4d6e949ae66f1a4aa497d47fde138190a63d310267092243d4a777db6286581)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnChannelGroupIngressAccessLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnChannelGroupLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupIngressAccessLogsRecordFields"]] = None,
    ) -> "CfnChannelGroupLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35378aa91fe75f7be0fc2b133055e0bf5037441cbb9b8d9388966ccaed7fe12d)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnChannelGroupIngressAccessLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnChannelGroupLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupIngressAccessLogsRecordFields"]] = None,
    ) -> "CfnChannelGroupLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__640f5546e33e0871f75939fe236d7c2d08969b8c1e5d5cc2d8f1eb6ff222b8df)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnChannelGroupIngressAccessLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnChannelGroupLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupIngressAccessLogsRecordFields"]] = None,
    ) -> "CfnChannelGroupLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4696583a30f96440821b1f840c1b2d5f8f911bb402718799a6be02b6a81d0491)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnChannelGroupIngressAccessLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnChannelGroupLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnChannelGroupIngressAccessLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupIngressAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
            
            cfn_channel_group_ingress_access_logs_dest_props = mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsDestProps(
                record_fields=[mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__604051adf99919954ac9962aa66704a45ecd53ee6c53e1feb73cf8495245f632)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnChannelGroupIngressAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnChannelGroupIngressAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnChannelGroupIngressAccessLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnChannelGroupIngressAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupIngressAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
            
            cfn_channel_group_ingress_access_logs_firehose_props = mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsFirehoseProps(
                output_format=mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsOutputFormat.Firehose.JSON,
                record_fields=[mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__423ae46ffa77228e55fa9a5cbd272a3b5f803252a8df9df73699539aec79147b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnChannelGroupIngressAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnChannelGroupIngressAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnChannelGroupIngressAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnChannelGroupIngressAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupIngressAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
            
            cfn_channel_group_ingress_access_logs_log_group_props = mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsLogGroupProps(
                output_format=mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b1ea4a22eb2fa7f6a827a53c2624426a450ae3c8998681ff90a9eb868e1e680)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnChannelGroupIngressAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnChannelGroupIngressAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnChannelGroupIngressAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnChannelGroupIngressAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnChannelGroupIngressAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
        
        cfn_channel_group_ingress_access_logs_output_format = mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsRecordFields"
)
class CfnChannelGroupIngressAccessLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    CLIENT_IP = "CLIENT_IP"
    '''
    :stability: experimental
    '''
    TIME_TO_FIRST_BYTE = "TIME_TO_FIRST_BYTE"
    '''
    :stability: experimental
    '''
    STATUS_CODE = "STATUS_CODE"
    '''
    :stability: experimental
    '''
    RECEIVED_BYTES = "RECEIVED_BYTES"
    '''
    :stability: experimental
    '''
    SENT_BYTES = "SENT_BYTES"
    '''
    :stability: experimental
    '''
    METHOD = "METHOD"
    '''
    :stability: experimental
    '''
    REQUEST = "REQUEST"
    '''
    :stability: experimental
    '''
    PROTOCOL = "PROTOCOL"
    '''
    :stability: experimental
    '''
    USER_AGENT = "USER_AGENT"
    '''
    :stability: experimental
    '''
    DOMAIN_NAME = "DOMAIN_NAME"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    ACCOUNT = "ACCOUNT"
    '''
    :stability: experimental
    '''
    CHANNEL_ID = "CHANNEL_ID"
    '''
    :stability: experimental
    '''
    CHANNEL_ARN = "CHANNEL_ARN"
    '''
    :stability: experimental
    '''
    CHANNEL_GROUP_ID = "CHANNEL_GROUP_ID"
    '''
    :stability: experimental
    '''
    INPUT_TYPE = "INPUT_TYPE"
    '''
    :stability: experimental
    '''
    INPUT_INDEX = "INPUT_INDEX"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupIngressAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnChannelGroupIngressAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnChannelGroupIngressAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_channel_group_ingress_access_logs_s3_props = mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsOutputFormat.S3.JSON,
                record_fields=[mediapackagev2_mixins.CfnChannelGroupIngressAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6510634b30e8943a1280b178bc2a6925d1ceca4e53477b3988c9662ae483570a)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnChannelGroupIngressAccessLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnChannelGroupIngressAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnChannelGroupIngressAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnChannelGroupIngressAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnChannelGroupLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediapackagev2.mixins.CfnChannelGroupLogsMixin",
):
    '''Specifies the configuration for a MediaPackage V2 channel group.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediapackagev2-channelgroup.html
    :cloudformationResource: AWS::MediaPackageV2::ChannelGroup
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_mediapackagev2 import mixins as mediapackagev2_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_channel_group_logs_mixin = mediapackagev2_mixins.CfnChannelGroupLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::MediaPackageV2::ChannelGroup``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b966161b6358e8d029275ec64e0c48271684c08346b9b4df34e09ea3e65891bc)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__388b2cbf1da1f4af7b079323a407e71471f82ebd06fbdf6de08065bf47dca3c5)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b0d042100ed9ef842d42eaee767403fb82d0b7ade41884205949a19f4b393dba)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EGRESS_ACCESS_LOGS")
    def EGRESS_ACCESS_LOGS(cls) -> "CfnChannelGroupEgressAccessLogs":
        return typing.cast("CfnChannelGroupEgressAccessLogs", jsii.sget(cls, "EGRESS_ACCESS_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="INGRESS_ACCESS_LOGS")
    def INGRESS_ACCESS_LOGS(cls) -> "CfnChannelGroupIngressAccessLogs":
        return typing.cast("CfnChannelGroupIngressAccessLogs", jsii.sget(cls, "INGRESS_ACCESS_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnChannelGroupEgressAccessLogs",
    "CfnChannelGroupEgressAccessLogsDestProps",
    "CfnChannelGroupEgressAccessLogsFirehoseProps",
    "CfnChannelGroupEgressAccessLogsLogGroupProps",
    "CfnChannelGroupEgressAccessLogsOutputFormat",
    "CfnChannelGroupEgressAccessLogsRecordFields",
    "CfnChannelGroupEgressAccessLogsS3Props",
    "CfnChannelGroupIngressAccessLogs",
    "CfnChannelGroupIngressAccessLogsDestProps",
    "CfnChannelGroupIngressAccessLogsFirehoseProps",
    "CfnChannelGroupIngressAccessLogsLogGroupProps",
    "CfnChannelGroupIngressAccessLogsOutputFormat",
    "CfnChannelGroupIngressAccessLogsRecordFields",
    "CfnChannelGroupIngressAccessLogsS3Props",
    "CfnChannelGroupLogsMixin",
]

publication.publish()

def _typecheckingstub__e4e16e9cd62f8a6ca7e1ccd4454fa6a6e8547b0209e1140ce7e19fd054a63acd(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupEgressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__696024da3bf568d08005e3641147133c17b2da51832cb4acac82fcd5bae720a5(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnChannelGroupEgressAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupEgressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b92e944d56a610a0d455ef72b8a50bff2e60ef061c4ad5f0c00e03a8b7bf316(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupEgressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f61a6e590606f957cc1efc500e3aa79a3b15cad35d7735ef0a54d3f97343ee5(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnChannelGroupEgressAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupEgressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ac9729527eebcbc6de25c0c0c19d2c5d8c3a0dd5d449f7ba579493959847078d(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupEgressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45b72812559a07a8db4b07e70e48f4d2ee59f75cd8ada0aab169ebd0c69c5a78(
    *,
    output_format: typing.Optional[CfnChannelGroupEgressAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupEgressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e373ccee3bf13333b75b699d2d0bd8214485a1939e566e826ad51da891d22ee(
    *,
    output_format: typing.Optional[CfnChannelGroupEgressAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupEgressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f562c74e2c89b7ebbd5251ceb08116f69a1992572066b2cbe983774c88899b92(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnChannelGroupEgressAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupEgressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4d6e949ae66f1a4aa497d47fde138190a63d310267092243d4a777db6286581(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupIngressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35378aa91fe75f7be0fc2b133055e0bf5037441cbb9b8d9388966ccaed7fe12d(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnChannelGroupIngressAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupIngressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__640f5546e33e0871f75939fe236d7c2d08969b8c1e5d5cc2d8f1eb6ff222b8df(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupIngressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4696583a30f96440821b1f840c1b2d5f8f911bb402718799a6be02b6a81d0491(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnChannelGroupIngressAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupIngressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__604051adf99919954ac9962aa66704a45ecd53ee6c53e1feb73cf8495245f632(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupIngressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__423ae46ffa77228e55fa9a5cbd272a3b5f803252a8df9df73699539aec79147b(
    *,
    output_format: typing.Optional[CfnChannelGroupIngressAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupIngressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b1ea4a22eb2fa7f6a827a53c2624426a450ae3c8998681ff90a9eb868e1e680(
    *,
    output_format: typing.Optional[CfnChannelGroupIngressAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupIngressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6510634b30e8943a1280b178bc2a6925d1ceca4e53477b3988c9662ae483570a(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnChannelGroupIngressAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnChannelGroupIngressAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b966161b6358e8d029275ec64e0c48271684c08346b9b4df34e09ea3e65891bc(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__388b2cbf1da1f4af7b079323a407e71471f82ebd06fbdf6de08065bf47dca3c5(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b0d042100ed9ef842d42eaee767403fb82d0b7ade41884205949a19f4b393dba(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
