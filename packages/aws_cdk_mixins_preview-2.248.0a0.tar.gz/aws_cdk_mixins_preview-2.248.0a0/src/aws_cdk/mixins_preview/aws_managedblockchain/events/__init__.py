from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class ManagedBlockchainInvitationStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_managedblockchain.events.ManagedBlockchainInvitationStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.managedblockchain@ManagedBlockchainInvitationStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_managedblockchain import events as managedblockchain_events
        
        managed_blockchain_invitation_status_change = managedblockchain_events.ManagedBlockchainInvitationStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="managedBlockchainInvitationStatusChangePattern")
    @builtins.classmethod
    def managed_blockchain_invitation_status_change_pattern(
        cls,
        *,
        accepted_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        created_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        expires_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        invitation_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        network_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        rejected_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Managed Blockchain Invitation Status Change.

        :param accepted_at: (experimental) acceptedAt property. Specify an array of string values to match this event if the actual value of acceptedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param created_at: (experimental) createdAt property. Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param expires_at: (experimental) expiresAt property. Specify an array of string values to match this event if the actual value of expiresAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param invitation_id: (experimental) invitationId property. Specify an array of string values to match this event if the actual value of invitationId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param network_id: (experimental) networkId property. Specify an array of string values to match this event if the actual value of networkId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param rejected_at: (experimental) rejectedAt property. Specify an array of string values to match this event if the actual value of rejectedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ManagedBlockchainInvitationStatusChange.ManagedBlockchainInvitationStatusChangeProps(
            accepted_at=accepted_at,
            created_at=created_at,
            event_metadata=event_metadata,
            expires_at=expires_at,
            invitation_id=invitation_id,
            message=message,
            network_id=network_id,
            rejected_at=rejected_at,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "managedBlockchainInvitationStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_managedblockchain.events.ManagedBlockchainInvitationStatusChange.ManagedBlockchainInvitationStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "accepted_at": "acceptedAt",
            "created_at": "createdAt",
            "event_metadata": "eventMetadata",
            "expires_at": "expiresAt",
            "invitation_id": "invitationId",
            "message": "message",
            "network_id": "networkId",
            "rejected_at": "rejectedAt",
            "status": "status",
        },
    )
    class ManagedBlockchainInvitationStatusChangeProps:
        def __init__(
            self,
            *,
            accepted_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            created_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            expires_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            invitation_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            network_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            rejected_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.managedblockchain@ManagedBlockchainInvitationStatusChange event.

            :param accepted_at: (experimental) acceptedAt property. Specify an array of string values to match this event if the actual value of acceptedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param created_at: (experimental) createdAt property. Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param expires_at: (experimental) expiresAt property. Specify an array of string values to match this event if the actual value of expiresAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param invitation_id: (experimental) invitationId property. Specify an array of string values to match this event if the actual value of invitationId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_id: (experimental) networkId property. Specify an array of string values to match this event if the actual value of networkId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param rejected_at: (experimental) rejectedAt property. Specify an array of string values to match this event if the actual value of rejectedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_managedblockchain import events as managedblockchain_events
                
                managed_blockchain_invitation_status_change_props = managedblockchain_events.ManagedBlockchainInvitationStatusChange.ManagedBlockchainInvitationStatusChangeProps(
                    accepted_at=["acceptedAt"],
                    created_at=["createdAt"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    expires_at=["expiresAt"],
                    invitation_id=["invitationId"],
                    message=["message"],
                    network_id=["networkId"],
                    rejected_at=["rejectedAt"],
                    status=["status"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__61c75f3e4873e763b789449ca7bbf2a382c5ac0704d52fd6f7f0652680792227)
                check_type(argname="argument accepted_at", value=accepted_at, expected_type=type_hints["accepted_at"])
                check_type(argname="argument created_at", value=created_at, expected_type=type_hints["created_at"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument expires_at", value=expires_at, expected_type=type_hints["expires_at"])
                check_type(argname="argument invitation_id", value=invitation_id, expected_type=type_hints["invitation_id"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument network_id", value=network_id, expected_type=type_hints["network_id"])
                check_type(argname="argument rejected_at", value=rejected_at, expected_type=type_hints["rejected_at"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if accepted_at is not None:
                self._values["accepted_at"] = accepted_at
            if created_at is not None:
                self._values["created_at"] = created_at
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if expires_at is not None:
                self._values["expires_at"] = expires_at
            if invitation_id is not None:
                self._values["invitation_id"] = invitation_id
            if message is not None:
                self._values["message"] = message
            if network_id is not None:
                self._values["network_id"] = network_id
            if rejected_at is not None:
                self._values["rejected_at"] = rejected_at
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def accepted_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) acceptedAt property.

            Specify an array of string values to match this event if the actual value of acceptedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("accepted_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def created_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) createdAt property.

            Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("created_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def expires_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) expiresAt property.

            Specify an array of string values to match this event if the actual value of expiresAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("expires_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def invitation_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) invitationId property.

            Specify an array of string values to match this event if the actual value of invitationId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invitation_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def network_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) networkId property.

            Specify an array of string values to match this event if the actual value of networkId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def rejected_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) rejectedAt property.

            Specify an array of string values to match this event if the actual value of rejectedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("rejected_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ManagedBlockchainInvitationStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ManagedBlockchainProposalStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_managedblockchain.events.ManagedBlockchainProposalStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.managedblockchain@ManagedBlockchainProposalStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_managedblockchain import events as managedblockchain_events
        
        managed_blockchain_proposal_status_change = managedblockchain_events.ManagedBlockchainProposalStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="managedBlockchainProposalStatusChangePattern")
    @builtins.classmethod
    def managed_blockchain_proposal_status_change_pattern(
        cls,
        *,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        expiration_date: typing.Optional[typing.Sequence[builtins.str]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        network_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        proposal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        proposed_by_member_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        proposed_by_member_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Managed Blockchain Proposal Status Change.

        :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param expiration_date: (experimental) expirationDate property. Specify an array of string values to match this event if the actual value of expirationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param network_id: (experimental) networkId property. Specify an array of string values to match this event if the actual value of networkId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param proposal_id: (experimental) proposalId property. Specify an array of string values to match this event if the actual value of proposalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param proposed_by_member_id: (experimental) proposedByMemberId property. Specify an array of string values to match this event if the actual value of proposedByMemberId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param proposed_by_member_name: (experimental) proposedByMemberName property. Specify an array of string values to match this event if the actual value of proposedByMemberName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ManagedBlockchainProposalStatusChange.ManagedBlockchainProposalStatusChangeProps(
            description=description,
            event_metadata=event_metadata,
            expiration_date=expiration_date,
            message=message,
            network_id=network_id,
            proposal_id=proposal_id,
            proposed_by_member_id=proposed_by_member_id,
            proposed_by_member_name=proposed_by_member_name,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "managedBlockchainProposalStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_managedblockchain.events.ManagedBlockchainProposalStatusChange.ManagedBlockchainProposalStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "description": "description",
            "event_metadata": "eventMetadata",
            "expiration_date": "expirationDate",
            "message": "message",
            "network_id": "networkId",
            "proposal_id": "proposalId",
            "proposed_by_member_id": "proposedByMemberId",
            "proposed_by_member_name": "proposedByMemberName",
            "status": "status",
        },
    )
    class ManagedBlockchainProposalStatusChangeProps:
        def __init__(
            self,
            *,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            expiration_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            network_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            proposal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            proposed_by_member_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            proposed_by_member_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.managedblockchain@ManagedBlockchainProposalStatusChange event.

            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param expiration_date: (experimental) expirationDate property. Specify an array of string values to match this event if the actual value of expirationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_id: (experimental) networkId property. Specify an array of string values to match this event if the actual value of networkId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param proposal_id: (experimental) proposalId property. Specify an array of string values to match this event if the actual value of proposalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param proposed_by_member_id: (experimental) proposedByMemberId property. Specify an array of string values to match this event if the actual value of proposedByMemberId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param proposed_by_member_name: (experimental) proposedByMemberName property. Specify an array of string values to match this event if the actual value of proposedByMemberName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_managedblockchain import events as managedblockchain_events
                
                managed_blockchain_proposal_status_change_props = managedblockchain_events.ManagedBlockchainProposalStatusChange.ManagedBlockchainProposalStatusChangeProps(
                    description=["description"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    expiration_date=["expirationDate"],
                    message=["message"],
                    network_id=["networkId"],
                    proposal_id=["proposalId"],
                    proposed_by_member_id=["proposedByMemberId"],
                    proposed_by_member_name=["proposedByMemberName"],
                    status=["status"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__72ab296cce7cd198568b16de4ec238d3329bbf17ea2b34d207eceaafe6c74156)
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument expiration_date", value=expiration_date, expected_type=type_hints["expiration_date"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument network_id", value=network_id, expected_type=type_hints["network_id"])
                check_type(argname="argument proposal_id", value=proposal_id, expected_type=type_hints["proposal_id"])
                check_type(argname="argument proposed_by_member_id", value=proposed_by_member_id, expected_type=type_hints["proposed_by_member_id"])
                check_type(argname="argument proposed_by_member_name", value=proposed_by_member_name, expected_type=type_hints["proposed_by_member_name"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if description is not None:
                self._values["description"] = description
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if expiration_date is not None:
                self._values["expiration_date"] = expiration_date
            if message is not None:
                self._values["message"] = message
            if network_id is not None:
                self._values["network_id"] = network_id
            if proposal_id is not None:
                self._values["proposal_id"] = proposal_id
            if proposed_by_member_id is not None:
                self._values["proposed_by_member_id"] = proposed_by_member_id
            if proposed_by_member_name is not None:
                self._values["proposed_by_member_name"] = proposed_by_member_name
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def expiration_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) expirationDate property.

            Specify an array of string values to match this event if the actual value of expirationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("expiration_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def network_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) networkId property.

            Specify an array of string values to match this event if the actual value of networkId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def proposal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) proposalId property.

            Specify an array of string values to match this event if the actual value of proposalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("proposal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def proposed_by_member_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) proposedByMemberId property.

            Specify an array of string values to match this event if the actual value of proposedByMemberId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("proposed_by_member_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def proposed_by_member_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) proposedByMemberName property.

            Specify an array of string values to match this event if the actual value of proposedByMemberName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("proposed_by_member_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ManagedBlockchainProposalStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "ManagedBlockchainInvitationStatusChange",
    "ManagedBlockchainProposalStatusChange",
]

publication.publish()

def _typecheckingstub__61c75f3e4873e763b789449ca7bbf2a382c5ac0704d52fd6f7f0652680792227(
    *,
    accepted_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    created_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    expires_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    invitation_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    network_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    rejected_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__72ab296cce7cd198568b16de4ec238d3329bbf17ea2b34d207eceaafe6c74156(
    *,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    expiration_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    network_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    proposal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    proposed_by_member_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    proposed_by_member_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
