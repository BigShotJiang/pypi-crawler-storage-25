from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class AWSAPICallViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.batch@AWSAPICallViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_batch import events as batch_events
        
        a_wSAPICall_via_cloud_trail = batch_events.AWSAPICallViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="awsAPICallViaCloudTrailPattern")
    @builtins.classmethod
    def aws_api_call_via_cloud_trail_pattern(
        cls,
        *,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS API Call via CloudTrail.

        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param read_only: (experimental) readOnly property. Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            aws_region=aws_region,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            read_only=read_only,
            request_id=request_id,
            request_parameters=request_parameters,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "awsAPICallViaCloudTrailPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "aws_region": "awsRegion",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "read_only": "readOnly",
            "request_id": "requestId",
            "request_parameters": "requestParameters",
            "response_elements": "responseElements",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSAPICallViaCloudTrailProps:
        def __init__(
            self,
            *,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.batch@AWSAPICallViaCloudTrail event.

            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param read_only: (experimental) readOnly property. Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                a_wSAPICall_via_cloud_trail_props = batch_events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
                    aws_region=["awsRegion"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    read_only=["readOnly"],
                    request_id=["requestId"],
                    request_parameters=batch_events.AWSAPICallViaCloudTrail.RequestParameters(
                        container_overrides=batch_events.AWSAPICallViaCloudTrail.ContainerOverrides(
                            environment=[batch_events.AWSAPICallViaCloudTrail.ContainerOverridesItem(
                                name=["name"],
                                value=["value"]
                            )]
                        ),
                        job_definition=["jobDefinition"],
                        job_name=["jobName"],
                        job_queue=["jobQueue"]
                    ),
                    response_elements=batch_events.AWSAPICallViaCloudTrail.ResponseElements(
                        job_id=["jobId"],
                        job_name=["jobName"]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=batch_events.AWSAPICallViaCloudTrail.UserIdentity(
                        access_key_id=["accessKeyId"],
                        account_id=["accountId"],
                        arn=["arn"],
                        invoked_by=["invokedBy"],
                        principal_id=["principalId"],
                        session_context=batch_events.AWSAPICallViaCloudTrail.SessionContext(
                            attributes=batch_events.AWSAPICallViaCloudTrail.Attributes(
                                creation_date=["creationDate"],
                                mfa_authenticated=["mfaAuthenticated"]
                            ),
                            session_issuer=batch_events.AWSAPICallViaCloudTrail.SessionIssuer(
                                account_id=["accountId"],
                                arn=["arn"],
                                principal_id=["principalId"],
                                type=["type"],
                                user_name=["userName"]
                            )
                        ),
                        type=["type"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(request_parameters, dict):
                request_parameters = AWSAPICallViaCloudTrail.RequestParameters(**request_parameters)
            if isinstance(response_elements, dict):
                response_elements = AWSAPICallViaCloudTrail.ResponseElements(**response_elements)
            if isinstance(user_identity, dict):
                user_identity = AWSAPICallViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c33ab51d3a9f2b58bad65dfe072d45c4b8681c8b63d9085c8880e83615960bce)
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument read_only", value=read_only, expected_type=type_hints["read_only"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument request_parameters", value=request_parameters, expected_type=type_hints["request_parameters"])
                check_type(argname="argument response_elements", value=response_elements, expected_type=type_hints["response_elements"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if read_only is not None:
                self._values["read_only"] = read_only
            if request_id is not None:
                self._values["request_id"] = request_id
            if request_parameters is not None:
                self._values["request_parameters"] = request_parameters
            if response_elements is not None:
                self._values["response_elements"] = response_elements
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def read_only(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) readOnly property.

            Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("read_only")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestID property.

            Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"]:
            '''(experimental) requestParameters property.

            Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"], result)

        @builtins.property
        def response_elements(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"]:
            '''(experimental) responseElements property.

            Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response_elements")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSAPICallViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "creation_date": "creationDate",
            "mfa_authenticated": "mfaAuthenticated",
        },
    )
    class Attributes:
        def __init__(
            self,
            *,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Attributes.

            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mfa_authenticated: (experimental) mfaAuthenticated property. Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                attributes = batch_events.AWSAPICallViaCloudTrail.Attributes(
                    creation_date=["creationDate"],
                    mfa_authenticated=["mfaAuthenticated"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fe2d76f67291c45a861f9c602dbecbce74758b6a51f3332d986d6a835d4483e4)
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument mfa_authenticated", value=mfa_authenticated, expected_type=type_hints["mfa_authenticated"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if mfa_authenticated is not None:
                self._values["mfa_authenticated"] = mfa_authenticated

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mfa_authenticated(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mfaAuthenticated property.

            Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mfa_authenticated")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.ContainerOverrides",
        jsii_struct_bases=[],
        name_mapping={"environment": "environment"},
    )
    class ContainerOverrides:
        def __init__(
            self,
            *,
            environment: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.ContainerOverridesItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for ContainerOverrides.

            :param environment: (experimental) environment property. Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                container_overrides = batch_events.AWSAPICallViaCloudTrail.ContainerOverrides(
                    environment=[batch_events.AWSAPICallViaCloudTrail.ContainerOverridesItem(
                        name=["name"],
                        value=["value"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__bee2a5239c4cb32707f1a25601914cd7f08c797fe8224dca78858614bfe5c18a)
                check_type(argname="argument environment", value=environment, expected_type=type_hints["environment"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if environment is not None:
                self._values["environment"] = environment

        @builtins.property
        def environment(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.ContainerOverridesItem"]]:
            '''(experimental) environment property.

            Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.ContainerOverridesItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ContainerOverrides(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.ContainerOverridesItem",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "value": "value"},
    )
    class ContainerOverridesItem:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ContainerOverridesItem.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                container_overrides_item = batch_events.AWSAPICallViaCloudTrail.ContainerOverridesItem(
                    name=["name"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9539d2300ceedcd262c982e2a4a7bb5a3111a55ca05afa0f999effe42d2fe5fe)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ContainerOverridesItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.RequestParameters",
        jsii_struct_bases=[],
        name_mapping={
            "container_overrides": "containerOverrides",
            "job_definition": "jobDefinition",
            "job_name": "jobName",
            "job_queue": "jobQueue",
        },
    )
    class RequestParameters:
        def __init__(
            self,
            *,
            container_overrides: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ContainerOverrides", typing.Dict[builtins.str, typing.Any]]] = None,
            job_definition: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_queue: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParameters.

            :param container_overrides: (experimental) containerOverrides property. Specify an array of string values to match this event if the actual value of containerOverrides is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_definition: (experimental) jobDefinition property. Specify an array of string values to match this event if the actual value of jobDefinition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_queue: (experimental) jobQueue property. Specify an array of string values to match this event if the actual value of jobQueue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                request_parameters = batch_events.AWSAPICallViaCloudTrail.RequestParameters(
                    container_overrides=batch_events.AWSAPICallViaCloudTrail.ContainerOverrides(
                        environment=[batch_events.AWSAPICallViaCloudTrail.ContainerOverridesItem(
                            name=["name"],
                            value=["value"]
                        )]
                    ),
                    job_definition=["jobDefinition"],
                    job_name=["jobName"],
                    job_queue=["jobQueue"]
                )
            '''
            if isinstance(container_overrides, dict):
                container_overrides = AWSAPICallViaCloudTrail.ContainerOverrides(**container_overrides)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6dc9d8283e2d259b67ae718deb95b9cc174f2810f7ad85aaaacaa177ba28c046)
                check_type(argname="argument container_overrides", value=container_overrides, expected_type=type_hints["container_overrides"])
                check_type(argname="argument job_definition", value=job_definition, expected_type=type_hints["job_definition"])
                check_type(argname="argument job_name", value=job_name, expected_type=type_hints["job_name"])
                check_type(argname="argument job_queue", value=job_queue, expected_type=type_hints["job_queue"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if container_overrides is not None:
                self._values["container_overrides"] = container_overrides
            if job_definition is not None:
                self._values["job_definition"] = job_definition
            if job_name is not None:
                self._values["job_name"] = job_name
            if job_queue is not None:
                self._values["job_queue"] = job_queue

        @builtins.property
        def container_overrides(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ContainerOverrides"]:
            '''(experimental) containerOverrides property.

            Specify an array of string values to match this event if the actual value of containerOverrides is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("container_overrides")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ContainerOverrides"], result)

        @builtins.property
        def job_definition(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobDefinition property.

            Specify an array of string values to match this event if the actual value of jobDefinition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_definition")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobName property.

            Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_queue(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobQueue property.

            Specify an array of string values to match this event if the actual value of jobQueue is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_queue")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.ResponseElements",
        jsii_struct_bases=[],
        name_mapping={"job_id": "jobId", "job_name": "jobName"},
    )
    class ResponseElements:
        def __init__(
            self,
            *,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElements.

            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                response_elements = batch_events.AWSAPICallViaCloudTrail.ResponseElements(
                    job_id=["jobId"],
                    job_name=["jobName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f6e65b18a662c11a81df8ff855c17f59caa83818f10922c2f054b1674c5b1dbb)
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument job_name", value=job_name, expected_type=type_hints["job_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if job_id is not None:
                self._values["job_id"] = job_id
            if job_name is not None:
                self._values["job_name"] = job_name

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobName property.

            Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElements(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.SessionContext",
        jsii_struct_bases=[],
        name_mapping={"attributes": "attributes", "session_issuer": "sessionIssuer"},
    )
    class SessionContext:
        def __init__(
            self,
            *,
            attributes: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            session_issuer: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionIssuer", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionContext.

            :param attributes: (experimental) attributes property. Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_issuer: (experimental) sessionIssuer property. Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                session_context = batch_events.AWSAPICallViaCloudTrail.SessionContext(
                    attributes=batch_events.AWSAPICallViaCloudTrail.Attributes(
                        creation_date=["creationDate"],
                        mfa_authenticated=["mfaAuthenticated"]
                    ),
                    session_issuer=batch_events.AWSAPICallViaCloudTrail.SessionIssuer(
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        type=["type"],
                        user_name=["userName"]
                    )
                )
            '''
            if isinstance(attributes, dict):
                attributes = AWSAPICallViaCloudTrail.Attributes(**attributes)
            if isinstance(session_issuer, dict):
                session_issuer = AWSAPICallViaCloudTrail.SessionIssuer(**session_issuer)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e56d2728565d441ea50206b4116eec9b25595a05b15f19d9fb70d28b750c0f58)
                check_type(argname="argument attributes", value=attributes, expected_type=type_hints["attributes"])
                check_type(argname="argument session_issuer", value=session_issuer, expected_type=type_hints["session_issuer"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attributes is not None:
                self._values["attributes"] = attributes
            if session_issuer is not None:
                self._values["session_issuer"] = session_issuer

        @builtins.property
        def attributes(self) -> typing.Optional["AWSAPICallViaCloudTrail.Attributes"]:
            '''(experimental) attributes property.

            Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attributes")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Attributes"], result)

        @builtins.property
        def session_issuer(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"]:
            '''(experimental) sessionIssuer property.

            Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_issuer")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionContext(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.SessionIssuer",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "type": "type",
            "user_name": "userName",
        },
    )
    class SessionIssuer:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionIssuer.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_name: (experimental) userName property. Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                session_issuer = batch_events.AWSAPICallViaCloudTrail.SessionIssuer(
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    type=["type"],
                    user_name=["userName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d530a338abc2ef51ca9b7ff7fcbcd2ea4dd18e838504697af56c4e424f3d7eea)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument user_name", value=user_name, expected_type=type_hints["user_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if type is not None:
                self._values["type"] = type
            if user_name is not None:
                self._values["user_name"] = user_name

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userName property.

            Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionIssuer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.AWSAPICallViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={
            "access_key_id": "accessKeyId",
            "account_id": "accountId",
            "arn": "arn",
            "invoked_by": "invokedBy",
            "principal_id": "principalId",
            "session_context": "sessionContext",
            "type": "type",
        },
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_context: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionContext", typing.Dict[builtins.str, typing.Any]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param access_key_id: (experimental) accessKeyId property. Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param invoked_by: (experimental) invokedBy property. Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_context: (experimental) sessionContext property. Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                user_identity = batch_events.AWSAPICallViaCloudTrail.UserIdentity(
                    access_key_id=["accessKeyId"],
                    account_id=["accountId"],
                    arn=["arn"],
                    invoked_by=["invokedBy"],
                    principal_id=["principalId"],
                    session_context=batch_events.AWSAPICallViaCloudTrail.SessionContext(
                        attributes=batch_events.AWSAPICallViaCloudTrail.Attributes(
                            creation_date=["creationDate"],
                            mfa_authenticated=["mfaAuthenticated"]
                        ),
                        session_issuer=batch_events.AWSAPICallViaCloudTrail.SessionIssuer(
                            account_id=["accountId"],
                            arn=["arn"],
                            principal_id=["principalId"],
                            type=["type"],
                            user_name=["userName"]
                        )
                    ),
                    type=["type"]
                )
            '''
            if isinstance(session_context, dict):
                session_context = AWSAPICallViaCloudTrail.SessionContext(**session_context)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e8fff506c6b4a487a35d07bf22250d3098962ae1155f2117cc7e59419ba76a7a)
                check_type(argname="argument access_key_id", value=access_key_id, expected_type=type_hints["access_key_id"])
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument invoked_by", value=invoked_by, expected_type=type_hints["invoked_by"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument session_context", value=session_context, expected_type=type_hints["session_context"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if access_key_id is not None:
                self._values["access_key_id"] = access_key_id
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if invoked_by is not None:
                self._values["invoked_by"] = invoked_by
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if session_context is not None:
                self._values["session_context"] = session_context
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def access_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accessKeyId property.

            Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("access_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def invoked_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) invokedBy property.

            Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invoked_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_context(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionContext"]:
            '''(experimental) sessionContext property.

            Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_context")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionContext"], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class BatchJobStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange",
):
    '''(experimental) EventBridge event pattern for aws.batch@BatchJobStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_batch import events as batch_events
        
        batch_job_state_change = batch_events.BatchJobStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="batchJobStateChangePattern")
    @builtins.classmethod
    def batch_job_state_change_pattern(
        cls,
        *,
        attempts: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.BatchJobStateChangeItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        container: typing.Optional[typing.Union["BatchJobStateChange.Container", typing.Dict[builtins.str, typing.Any]]] = None,
        created_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        depends_on: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.JobDependency", typing.Dict[builtins.str, typing.Any]]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        job_definition: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_queue: typing.Optional[typing.Sequence[builtins.str]] = None,
        parameters: typing.Optional[typing.Sequence[builtins.str]] = None,
        retry_strategy: typing.Optional[typing.Union["BatchJobStateChange.RetryStrategy", typing.Dict[builtins.str, typing.Any]]] = None,
        started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        stopped_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Batch Job State Change.

        :param attempts: (experimental) attempts property. Specify an array of string values to match this event if the actual value of attempts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param container: (experimental) container property. Specify an array of string values to match this event if the actual value of container is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param created_at: (experimental) createdAt property. Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param depends_on: (experimental) dependsOn property. Specify an array of string values to match this event if the actual value of dependsOn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param job_definition: (experimental) jobDefinition property. Specify an array of string values to match this event if the actual value of jobDefinition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_queue: (experimental) jobQueue property. Specify an array of string values to match this event if the actual value of jobQueue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param parameters: (experimental) parameters property. Specify an array of string values to match this event if the actual value of parameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param retry_strategy: (experimental) retryStrategy property. Specify an array of string values to match this event if the actual value of retryStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param started_at: (experimental) startedAt property. Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_reason: (experimental) statusReason property. Specify an array of string values to match this event if the actual value of statusReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param stopped_at: (experimental) stoppedAt property. Specify an array of string values to match this event if the actual value of stoppedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = BatchJobStateChange.BatchJobStateChangeProps(
            attempts=attempts,
            container=container,
            created_at=created_at,
            depends_on=depends_on,
            event_metadata=event_metadata,
            job_definition=job_definition,
            job_id=job_id,
            job_name=job_name,
            job_queue=job_queue,
            parameters=parameters,
            retry_strategy=retry_strategy,
            started_at=started_at,
            status=status,
            status_reason=status_reason,
            stopped_at=stopped_at,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "batchJobStateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.BatchJobStateChangeItem",
        jsii_struct_bases=[],
        name_mapping={
            "container": "container",
            "started_at": "startedAt",
            "status_reason": "statusReason",
            "stopped_at": "stoppedAt",
        },
    )
    class BatchJobStateChangeItem:
        def __init__(
            self,
            *,
            container: typing.Optional[typing.Union["BatchJobStateChange.Container1", typing.Dict[builtins.str, typing.Any]]] = None,
            started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            stopped_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for BatchJobStateChangeItem.

            :param container: (experimental) container property. Specify an array of string values to match this event if the actual value of container is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param started_at: (experimental) startedAt property. Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_reason: (experimental) statusReason property. Specify an array of string values to match this event if the actual value of statusReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stopped_at: (experimental) stoppedAt property. Specify an array of string values to match this event if the actual value of stoppedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                # network_interfaces: Any
                
                batch_job_state_change_item = batch_events.BatchJobStateChange.BatchJobStateChangeItem(
                    container=batch_events.BatchJobStateChange.Container1(
                        container_instance_arn=["containerInstanceArn"],
                        exit_code=["exitCode"],
                        log_stream_name=["logStreamName"],
                        network_interfaces=[network_interfaces],
                        task_arn=["taskArn"]
                    ),
                    started_at=["startedAt"],
                    status_reason=["statusReason"],
                    stopped_at=["stoppedAt"]
                )
            '''
            if isinstance(container, dict):
                container = BatchJobStateChange.Container1(**container)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__94b2ff319886b4b0197531b8a6cf1f27df3811aa62d4da21e4850cad6f132a25)
                check_type(argname="argument container", value=container, expected_type=type_hints["container"])
                check_type(argname="argument started_at", value=started_at, expected_type=type_hints["started_at"])
                check_type(argname="argument status_reason", value=status_reason, expected_type=type_hints["status_reason"])
                check_type(argname="argument stopped_at", value=stopped_at, expected_type=type_hints["stopped_at"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if container is not None:
                self._values["container"] = container
            if started_at is not None:
                self._values["started_at"] = started_at
            if status_reason is not None:
                self._values["status_reason"] = status_reason
            if stopped_at is not None:
                self._values["stopped_at"] = stopped_at

        @builtins.property
        def container(self) -> typing.Optional["BatchJobStateChange.Container1"]:
            '''(experimental) container property.

            Specify an array of string values to match this event if the actual value of container is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("container")
            return typing.cast(typing.Optional["BatchJobStateChange.Container1"], result)

        @builtins.property
        def started_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startedAt property.

            Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("started_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) statusReason property.

            Specify an array of string values to match this event if the actual value of statusReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stopped_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stoppedAt property.

            Specify an array of string values to match this event if the actual value of stoppedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stopped_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "BatchJobStateChangeItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.BatchJobStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "attempts": "attempts",
            "container": "container",
            "created_at": "createdAt",
            "depends_on": "dependsOn",
            "event_metadata": "eventMetadata",
            "job_definition": "jobDefinition",
            "job_id": "jobId",
            "job_name": "jobName",
            "job_queue": "jobQueue",
            "parameters": "parameters",
            "retry_strategy": "retryStrategy",
            "started_at": "startedAt",
            "status": "status",
            "status_reason": "statusReason",
            "stopped_at": "stoppedAt",
        },
    )
    class BatchJobStateChangeProps:
        def __init__(
            self,
            *,
            attempts: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.BatchJobStateChangeItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            container: typing.Optional[typing.Union["BatchJobStateChange.Container", typing.Dict[builtins.str, typing.Any]]] = None,
            created_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            depends_on: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.JobDependency", typing.Dict[builtins.str, typing.Any]]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            job_definition: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_queue: typing.Optional[typing.Sequence[builtins.str]] = None,
            parameters: typing.Optional[typing.Sequence[builtins.str]] = None,
            retry_strategy: typing.Optional[typing.Union["BatchJobStateChange.RetryStrategy", typing.Dict[builtins.str, typing.Any]]] = None,
            started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            stopped_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.batch@BatchJobStateChange event.

            :param attempts: (experimental) attempts property. Specify an array of string values to match this event if the actual value of attempts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param container: (experimental) container property. Specify an array of string values to match this event if the actual value of container is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param created_at: (experimental) createdAt property. Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param depends_on: (experimental) dependsOn property. Specify an array of string values to match this event if the actual value of dependsOn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param job_definition: (experimental) jobDefinition property. Specify an array of string values to match this event if the actual value of jobDefinition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_queue: (experimental) jobQueue property. Specify an array of string values to match this event if the actual value of jobQueue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param parameters: (experimental) parameters property. Specify an array of string values to match this event if the actual value of parameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param retry_strategy: (experimental) retryStrategy property. Specify an array of string values to match this event if the actual value of retryStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param started_at: (experimental) startedAt property. Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_reason: (experimental) statusReason property. Specify an array of string values to match this event if the actual value of statusReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stopped_at: (experimental) stoppedAt property. Specify an array of string values to match this event if the actual value of stoppedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                # network_interfaces: Any
                
                batch_job_state_change_props = batch_events.BatchJobStateChange.BatchJobStateChangeProps(
                    attempts=[batch_events.BatchJobStateChange.BatchJobStateChangeItem(
                        container=batch_events.BatchJobStateChange.Container1(
                            container_instance_arn=["containerInstanceArn"],
                            exit_code=["exitCode"],
                            log_stream_name=["logStreamName"],
                            network_interfaces=[network_interfaces],
                            task_arn=["taskArn"]
                        ),
                        started_at=["startedAt"],
                        status_reason=["statusReason"],
                        stopped_at=["stoppedAt"]
                    )],
                    container=batch_events.BatchJobStateChange.Container(
                        command=["command"],
                        container_instance_arn=["containerInstanceArn"],
                        environment=[batch_events.BatchJobStateChange.ContainerItem(
                            name=["name"],
                            value=["value"]
                        )],
                        exit_code=["exitCode"],
                        image=["image"],
                        log_stream_name=["logStreamName"],
                        memory=["memory"],
                        mount_points=[batch_events.BatchJobStateChange.MountPoint(
                            container_path=["containerPath"],
                            read_only=["readOnly"],
                            source_volume=["sourceVolume"]
                        )],
                        network_interfaces=[batch_events.BatchJobStateChange.NetworkInterface(
                            attachment_id=["attachmentId"],
                            ipv6_address=["ipv6Address"],
                            private_ipv4_address=["privateIpv4Address"]
                        )],
                        resource_requirements=[batch_events.BatchJobStateChange.ResourceRequirement(
                            type=["type"],
                            value=["value"]
                        )],
                        task_arn=["taskArn"],
                        ulimits=[batch_events.BatchJobStateChange.ULimit(
                            hard_limit=["hardLimit"],
                            name=["name"],
                            soft_limit=["softLimit"]
                        )],
                        vcpus=["vcpus"],
                        volumes=[batch_events.BatchJobStateChange.Volumes(
                            host=batch_events.BatchJobStateChange.Host(
                                source_path=["sourcePath"]
                            ),
                            name=["name"]
                        )]
                    ),
                    created_at=["createdAt"],
                    depends_on=[batch_events.BatchJobStateChange.JobDependency(
                        job_id=["jobId"],
                        type=["type"]
                    )],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    job_definition=["jobDefinition"],
                    job_id=["jobId"],
                    job_name=["jobName"],
                    job_queue=["jobQueue"],
                    parameters=["parameters"],
                    retry_strategy=batch_events.BatchJobStateChange.RetryStrategy(
                        attempts=["attempts"]
                    ),
                    started_at=["startedAt"],
                    status=["status"],
                    status_reason=["statusReason"],
                    stopped_at=["stoppedAt"]
                )
            '''
            if isinstance(container, dict):
                container = BatchJobStateChange.Container(**container)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(retry_strategy, dict):
                retry_strategy = BatchJobStateChange.RetryStrategy(**retry_strategy)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c8e715c466e9a583c5cc91ea3809fabcd4827ffe160b5cc6bea23c2bdbe49123)
                check_type(argname="argument attempts", value=attempts, expected_type=type_hints["attempts"])
                check_type(argname="argument container", value=container, expected_type=type_hints["container"])
                check_type(argname="argument created_at", value=created_at, expected_type=type_hints["created_at"])
                check_type(argname="argument depends_on", value=depends_on, expected_type=type_hints["depends_on"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument job_definition", value=job_definition, expected_type=type_hints["job_definition"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument job_name", value=job_name, expected_type=type_hints["job_name"])
                check_type(argname="argument job_queue", value=job_queue, expected_type=type_hints["job_queue"])
                check_type(argname="argument parameters", value=parameters, expected_type=type_hints["parameters"])
                check_type(argname="argument retry_strategy", value=retry_strategy, expected_type=type_hints["retry_strategy"])
                check_type(argname="argument started_at", value=started_at, expected_type=type_hints["started_at"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument status_reason", value=status_reason, expected_type=type_hints["status_reason"])
                check_type(argname="argument stopped_at", value=stopped_at, expected_type=type_hints["stopped_at"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attempts is not None:
                self._values["attempts"] = attempts
            if container is not None:
                self._values["container"] = container
            if created_at is not None:
                self._values["created_at"] = created_at
            if depends_on is not None:
                self._values["depends_on"] = depends_on
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if job_definition is not None:
                self._values["job_definition"] = job_definition
            if job_id is not None:
                self._values["job_id"] = job_id
            if job_name is not None:
                self._values["job_name"] = job_name
            if job_queue is not None:
                self._values["job_queue"] = job_queue
            if parameters is not None:
                self._values["parameters"] = parameters
            if retry_strategy is not None:
                self._values["retry_strategy"] = retry_strategy
            if started_at is not None:
                self._values["started_at"] = started_at
            if status is not None:
                self._values["status"] = status
            if status_reason is not None:
                self._values["status_reason"] = status_reason
            if stopped_at is not None:
                self._values["stopped_at"] = stopped_at

        @builtins.property
        def attempts(
            self,
        ) -> typing.Optional[typing.List["BatchJobStateChange.BatchJobStateChangeItem"]]:
            '''(experimental) attempts property.

            Specify an array of string values to match this event if the actual value of attempts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attempts")
            return typing.cast(typing.Optional[typing.List["BatchJobStateChange.BatchJobStateChangeItem"]], result)

        @builtins.property
        def container(self) -> typing.Optional["BatchJobStateChange.Container"]:
            '''(experimental) container property.

            Specify an array of string values to match this event if the actual value of container is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("container")
            return typing.cast(typing.Optional["BatchJobStateChange.Container"], result)

        @builtins.property
        def created_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) createdAt property.

            Specify an array of string values to match this event if the actual value of createdAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("created_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def depends_on(
            self,
        ) -> typing.Optional[typing.List["BatchJobStateChange.JobDependency"]]:
            '''(experimental) dependsOn property.

            Specify an array of string values to match this event if the actual value of dependsOn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("depends_on")
            return typing.cast(typing.Optional[typing.List["BatchJobStateChange.JobDependency"]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def job_definition(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobDefinition property.

            Specify an array of string values to match this event if the actual value of jobDefinition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_definition")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobName property.

            Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_queue(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobQueue property.

            Specify an array of string values to match this event if the actual value of jobQueue is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_queue")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def parameters(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) parameters property.

            Specify an array of string values to match this event if the actual value of parameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("parameters")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def retry_strategy(
            self,
        ) -> typing.Optional["BatchJobStateChange.RetryStrategy"]:
            '''(experimental) retryStrategy property.

            Specify an array of string values to match this event if the actual value of retryStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("retry_strategy")
            return typing.cast(typing.Optional["BatchJobStateChange.RetryStrategy"], result)

        @builtins.property
        def started_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startedAt property.

            Specify an array of string values to match this event if the actual value of startedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("started_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) statusReason property.

            Specify an array of string values to match this event if the actual value of statusReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stopped_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stoppedAt property.

            Specify an array of string values to match this event if the actual value of stoppedAt is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stopped_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "BatchJobStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.Container",
        jsii_struct_bases=[],
        name_mapping={
            "command": "command",
            "container_instance_arn": "containerInstanceArn",
            "environment": "environment",
            "exit_code": "exitCode",
            "image": "image",
            "log_stream_name": "logStreamName",
            "memory": "memory",
            "mount_points": "mountPoints",
            "network_interfaces": "networkInterfaces",
            "resource_requirements": "resourceRequirements",
            "task_arn": "taskArn",
            "ulimits": "ulimits",
            "vcpus": "vcpus",
            "volumes": "volumes",
        },
    )
    class Container:
        def __init__(
            self,
            *,
            command: typing.Optional[typing.Sequence[builtins.str]] = None,
            container_instance_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            environment: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.ContainerItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            exit_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            image: typing.Optional[typing.Sequence[builtins.str]] = None,
            log_stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            memory: typing.Optional[typing.Sequence[builtins.str]] = None,
            mount_points: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.MountPoint", typing.Dict[builtins.str, typing.Any]]]] = None,
            network_interfaces: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.NetworkInterface", typing.Dict[builtins.str, typing.Any]]]] = None,
            resource_requirements: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.ResourceRequirement", typing.Dict[builtins.str, typing.Any]]]] = None,
            task_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            ulimits: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.ULimit", typing.Dict[builtins.str, typing.Any]]]] = None,
            vcpus: typing.Optional[typing.Sequence[builtins.str]] = None,
            volumes: typing.Optional[typing.Sequence[typing.Union["BatchJobStateChange.Volumes", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for Container.

            :param command: (experimental) command property. Specify an array of string values to match this event if the actual value of command is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param container_instance_arn: (experimental) containerInstanceArn property. Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment: (experimental) environment property. Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param exit_code: (experimental) exitCode property. Specify an array of string values to match this event if the actual value of exitCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image: (experimental) image property. Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param log_stream_name: (experimental) logStreamName property. Specify an array of string values to match this event if the actual value of logStreamName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param memory: (experimental) memory property. Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mount_points: (experimental) mountPoints property. Specify an array of string values to match this event if the actual value of mountPoints is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interfaces: (experimental) networkInterfaces property. Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_requirements: (experimental) resourceRequirements property. Specify an array of string values to match this event if the actual value of resourceRequirements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param task_arn: (experimental) taskArn property. Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ulimits: (experimental) ulimits property. Specify an array of string values to match this event if the actual value of ulimits is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vcpus: (experimental) vcpus property. Specify an array of string values to match this event if the actual value of vcpus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param volumes: (experimental) volumes property. Specify an array of string values to match this event if the actual value of volumes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                container = batch_events.BatchJobStateChange.Container(
                    command=["command"],
                    container_instance_arn=["containerInstanceArn"],
                    environment=[batch_events.BatchJobStateChange.ContainerItem(
                        name=["name"],
                        value=["value"]
                    )],
                    exit_code=["exitCode"],
                    image=["image"],
                    log_stream_name=["logStreamName"],
                    memory=["memory"],
                    mount_points=[batch_events.BatchJobStateChange.MountPoint(
                        container_path=["containerPath"],
                        read_only=["readOnly"],
                        source_volume=["sourceVolume"]
                    )],
                    network_interfaces=[batch_events.BatchJobStateChange.NetworkInterface(
                        attachment_id=["attachmentId"],
                        ipv6_address=["ipv6Address"],
                        private_ipv4_address=["privateIpv4Address"]
                    )],
                    resource_requirements=[batch_events.BatchJobStateChange.ResourceRequirement(
                        type=["type"],
                        value=["value"]
                    )],
                    task_arn=["taskArn"],
                    ulimits=[batch_events.BatchJobStateChange.ULimit(
                        hard_limit=["hardLimit"],
                        name=["name"],
                        soft_limit=["softLimit"]
                    )],
                    vcpus=["vcpus"],
                    volumes=[batch_events.BatchJobStateChange.Volumes(
                        host=batch_events.BatchJobStateChange.Host(
                            source_path=["sourcePath"]
                        ),
                        name=["name"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1cd160f8850e3ef4de028eecf550ca23767667d312c16f7d11422f4c829b91aa)
                check_type(argname="argument command", value=command, expected_type=type_hints["command"])
                check_type(argname="argument container_instance_arn", value=container_instance_arn, expected_type=type_hints["container_instance_arn"])
                check_type(argname="argument environment", value=environment, expected_type=type_hints["environment"])
                check_type(argname="argument exit_code", value=exit_code, expected_type=type_hints["exit_code"])
                check_type(argname="argument image", value=image, expected_type=type_hints["image"])
                check_type(argname="argument log_stream_name", value=log_stream_name, expected_type=type_hints["log_stream_name"])
                check_type(argname="argument memory", value=memory, expected_type=type_hints["memory"])
                check_type(argname="argument mount_points", value=mount_points, expected_type=type_hints["mount_points"])
                check_type(argname="argument network_interfaces", value=network_interfaces, expected_type=type_hints["network_interfaces"])
                check_type(argname="argument resource_requirements", value=resource_requirements, expected_type=type_hints["resource_requirements"])
                check_type(argname="argument task_arn", value=task_arn, expected_type=type_hints["task_arn"])
                check_type(argname="argument ulimits", value=ulimits, expected_type=type_hints["ulimits"])
                check_type(argname="argument vcpus", value=vcpus, expected_type=type_hints["vcpus"])
                check_type(argname="argument volumes", value=volumes, expected_type=type_hints["volumes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if command is not None:
                self._values["command"] = command
            if container_instance_arn is not None:
                self._values["container_instance_arn"] = container_instance_arn
            if environment is not None:
                self._values["environment"] = environment
            if exit_code is not None:
                self._values["exit_code"] = exit_code
            if image is not None:
                self._values["image"] = image
            if log_stream_name is not None:
                self._values["log_stream_name"] = log_stream_name
            if memory is not None:
                self._values["memory"] = memory
            if mount_points is not None:
                self._values["mount_points"] = mount_points
            if network_interfaces is not None:
                self._values["network_interfaces"] = network_interfaces
            if resource_requirements is not None:
                self._values["resource_requirements"] = resource_requirements
            if task_arn is not None:
                self._values["task_arn"] = task_arn
            if ulimits is not None:
                self._values["ulimits"] = ulimits
            if vcpus is not None:
                self._values["vcpus"] = vcpus
            if volumes is not None:
                self._values["volumes"] = volumes

        @builtins.property
        def command(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) command property.

            Specify an array of string values to match this event if the actual value of command is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("command")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def container_instance_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) containerInstanceArn property.

            Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("container_instance_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def environment(
            self,
        ) -> typing.Optional[typing.List["BatchJobStateChange.ContainerItem"]]:
            '''(experimental) environment property.

            Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment")
            return typing.cast(typing.Optional[typing.List["BatchJobStateChange.ContainerItem"]], result)

        @builtins.property
        def exit_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) exitCode property.

            Specify an array of string values to match this event if the actual value of exitCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("exit_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) image property.

            Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def log_stream_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) logStreamName property.

            Specify an array of string values to match this event if the actual value of logStreamName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("log_stream_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def memory(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) memory property.

            Specify an array of string values to match this event if the actual value of memory is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("memory")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mount_points(
            self,
        ) -> typing.Optional[typing.List["BatchJobStateChange.MountPoint"]]:
            '''(experimental) mountPoints property.

            Specify an array of string values to match this event if the actual value of mountPoints is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mount_points")
            return typing.cast(typing.Optional[typing.List["BatchJobStateChange.MountPoint"]], result)

        @builtins.property
        def network_interfaces(
            self,
        ) -> typing.Optional[typing.List["BatchJobStateChange.NetworkInterface"]]:
            '''(experimental) networkInterfaces property.

            Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interfaces")
            return typing.cast(typing.Optional[typing.List["BatchJobStateChange.NetworkInterface"]], result)

        @builtins.property
        def resource_requirements(
            self,
        ) -> typing.Optional[typing.List["BatchJobStateChange.ResourceRequirement"]]:
            '''(experimental) resourceRequirements property.

            Specify an array of string values to match this event if the actual value of resourceRequirements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_requirements")
            return typing.cast(typing.Optional[typing.List["BatchJobStateChange.ResourceRequirement"]], result)

        @builtins.property
        def task_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) taskArn property.

            Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("task_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ulimits(self) -> typing.Optional[typing.List["BatchJobStateChange.ULimit"]]:
            '''(experimental) ulimits property.

            Specify an array of string values to match this event if the actual value of ulimits is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ulimits")
            return typing.cast(typing.Optional[typing.List["BatchJobStateChange.ULimit"]], result)

        @builtins.property
        def vcpus(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vcpus property.

            Specify an array of string values to match this event if the actual value of vcpus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vcpus")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def volumes(
            self,
        ) -> typing.Optional[typing.List["BatchJobStateChange.Volumes"]]:
            '''(experimental) volumes property.

            Specify an array of string values to match this event if the actual value of volumes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("volumes")
            return typing.cast(typing.Optional[typing.List["BatchJobStateChange.Volumes"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Container(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.Container1",
        jsii_struct_bases=[],
        name_mapping={
            "container_instance_arn": "containerInstanceArn",
            "exit_code": "exitCode",
            "log_stream_name": "logStreamName",
            "network_interfaces": "networkInterfaces",
            "task_arn": "taskArn",
        },
    )
    class Container1:
        def __init__(
            self,
            *,
            container_instance_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            exit_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            log_stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            network_interfaces: typing.Optional[typing.Sequence[typing.Any]] = None,
            task_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Container_1.

            :param container_instance_arn: (experimental) containerInstanceArn property. Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param exit_code: (experimental) exitCode property. Specify an array of string values to match this event if the actual value of exitCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param log_stream_name: (experimental) logStreamName property. Specify an array of string values to match this event if the actual value of logStreamName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interfaces: (experimental) networkInterfaces property. Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param task_arn: (experimental) taskArn property. Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                # network_interfaces: Any
                
                container1 = batch_events.BatchJobStateChange.Container1(
                    container_instance_arn=["containerInstanceArn"],
                    exit_code=["exitCode"],
                    log_stream_name=["logStreamName"],
                    network_interfaces=[network_interfaces],
                    task_arn=["taskArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f53562086744302dc492877fdf7f4075ab4a5d62b0694ab7c43ef67b7a4fe44b)
                check_type(argname="argument container_instance_arn", value=container_instance_arn, expected_type=type_hints["container_instance_arn"])
                check_type(argname="argument exit_code", value=exit_code, expected_type=type_hints["exit_code"])
                check_type(argname="argument log_stream_name", value=log_stream_name, expected_type=type_hints["log_stream_name"])
                check_type(argname="argument network_interfaces", value=network_interfaces, expected_type=type_hints["network_interfaces"])
                check_type(argname="argument task_arn", value=task_arn, expected_type=type_hints["task_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if container_instance_arn is not None:
                self._values["container_instance_arn"] = container_instance_arn
            if exit_code is not None:
                self._values["exit_code"] = exit_code
            if log_stream_name is not None:
                self._values["log_stream_name"] = log_stream_name
            if network_interfaces is not None:
                self._values["network_interfaces"] = network_interfaces
            if task_arn is not None:
                self._values["task_arn"] = task_arn

        @builtins.property
        def container_instance_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) containerInstanceArn property.

            Specify an array of string values to match this event if the actual value of containerInstanceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("container_instance_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def exit_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) exitCode property.

            Specify an array of string values to match this event if the actual value of exitCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("exit_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def log_stream_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) logStreamName property.

            Specify an array of string values to match this event if the actual value of logStreamName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("log_stream_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def network_interfaces(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) networkInterfaces property.

            Specify an array of string values to match this event if the actual value of networkInterfaces is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interfaces")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def task_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) taskArn property.

            Specify an array of string values to match this event if the actual value of taskArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("task_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Container1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.ContainerItem",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "value": "value"},
    )
    class ContainerItem:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ContainerItem.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                container_item = batch_events.BatchJobStateChange.ContainerItem(
                    name=["name"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ad90a22e15e60bf6c7a4707c0b9be7dcf7900401ea5d33f25bef937f4c51ff4a)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ContainerItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.Host",
        jsii_struct_bases=[],
        name_mapping={"source_path": "sourcePath"},
    )
    class Host:
        def __init__(
            self,
            *,
            source_path: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Host.

            :param source_path: (experimental) sourcePath property. Specify an array of string values to match this event if the actual value of sourcePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                host = batch_events.BatchJobStateChange.Host(
                    source_path=["sourcePath"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f9a8897caf251f7cd025ab6aa8ec721d602240e817d4f6d1e5c911c4627ffeeb)
                check_type(argname="argument source_path", value=source_path, expected_type=type_hints["source_path"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if source_path is not None:
                self._values["source_path"] = source_path

        @builtins.property
        def source_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourcePath property.

            Specify an array of string values to match this event if the actual value of sourcePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Host(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.JobDependency",
        jsii_struct_bases=[],
        name_mapping={"job_id": "jobId", "type": "type"},
    )
    class JobDependency:
        def __init__(
            self,
            *,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for JobDependency.

            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                job_dependency = batch_events.BatchJobStateChange.JobDependency(
                    job_id=["jobId"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__235a8e298e86103e727221619e52a4b812d81b764a65cfb9c0bdda83472a2c6f)
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if job_id is not None:
                self._values["job_id"] = job_id
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "JobDependency(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.MountPoint",
        jsii_struct_bases=[],
        name_mapping={
            "container_path": "containerPath",
            "read_only": "readOnly",
            "source_volume": "sourceVolume",
        },
    )
    class MountPoint:
        def __init__(
            self,
            *,
            container_path: typing.Optional[typing.Sequence[builtins.str]] = None,
            read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_volume: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for MountPoint.

            :param container_path: (experimental) containerPath property. Specify an array of string values to match this event if the actual value of containerPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param read_only: (experimental) readOnly property. Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_volume: (experimental) sourceVolume property. Specify an array of string values to match this event if the actual value of sourceVolume is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                mount_point = batch_events.BatchJobStateChange.MountPoint(
                    container_path=["containerPath"],
                    read_only=["readOnly"],
                    source_volume=["sourceVolume"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3dca93e802ae7b74af0a19e89646b4a9f80a25b1363647d003b755198112b05d)
                check_type(argname="argument container_path", value=container_path, expected_type=type_hints["container_path"])
                check_type(argname="argument read_only", value=read_only, expected_type=type_hints["read_only"])
                check_type(argname="argument source_volume", value=source_volume, expected_type=type_hints["source_volume"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if container_path is not None:
                self._values["container_path"] = container_path
            if read_only is not None:
                self._values["read_only"] = read_only
            if source_volume is not None:
                self._values["source_volume"] = source_volume

        @builtins.property
        def container_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) containerPath property.

            Specify an array of string values to match this event if the actual value of containerPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("container_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def read_only(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) readOnly property.

            Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("read_only")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_volume(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceVolume property.

            Specify an array of string values to match this event if the actual value of sourceVolume is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_volume")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "MountPoint(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.NetworkInterface",
        jsii_struct_bases=[],
        name_mapping={
            "attachment_id": "attachmentId",
            "ipv6_address": "ipv6Address",
            "private_ipv4_address": "privateIpv4Address",
        },
    )
    class NetworkInterface:
        def __init__(
            self,
            *,
            attachment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            ipv6_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            private_ipv4_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for NetworkInterface.

            :param attachment_id: (experimental) attachmentId property. Specify an array of string values to match this event if the actual value of attachmentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ipv6_address: (experimental) ipv6Address property. Specify an array of string values to match this event if the actual value of ipv6Address is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param private_ipv4_address: (experimental) privateIpv4Address property. Specify an array of string values to match this event if the actual value of privateIpv4Address is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                network_interface = batch_events.BatchJobStateChange.NetworkInterface(
                    attachment_id=["attachmentId"],
                    ipv6_address=["ipv6Address"],
                    private_ipv4_address=["privateIpv4Address"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9108185b5db477f200e6ebb31f9ca068ace9b29c563405e9f9de38ff2bc67bb0)
                check_type(argname="argument attachment_id", value=attachment_id, expected_type=type_hints["attachment_id"])
                check_type(argname="argument ipv6_address", value=ipv6_address, expected_type=type_hints["ipv6_address"])
                check_type(argname="argument private_ipv4_address", value=private_ipv4_address, expected_type=type_hints["private_ipv4_address"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attachment_id is not None:
                self._values["attachment_id"] = attachment_id
            if ipv6_address is not None:
                self._values["ipv6_address"] = ipv6_address
            if private_ipv4_address is not None:
                self._values["private_ipv4_address"] = private_ipv4_address

        @builtins.property
        def attachment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) attachmentId property.

            Specify an array of string values to match this event if the actual value of attachmentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attachment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ipv6_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ipv6Address property.

            Specify an array of string values to match this event if the actual value of ipv6Address is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ipv6_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def private_ipv4_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privateIpv4Address property.

            Specify an array of string values to match this event if the actual value of privateIpv4Address is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("private_ipv4_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterface(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.ResourceRequirement",
        jsii_struct_bases=[],
        name_mapping={"type": "type", "value": "value"},
    )
    class ResourceRequirement:
        def __init__(
            self,
            *,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceRequirement.

            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                resource_requirement = batch_events.BatchJobStateChange.ResourceRequirement(
                    type=["type"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f3c7f45f2b922dbc6d0c3c8829ea9ced4c7b80e1ec0db26219a29695d3e08087)
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if type is not None:
                self._values["type"] = type
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceRequirement(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.RetryStrategy",
        jsii_struct_bases=[],
        name_mapping={"attempts": "attempts"},
    )
    class RetryStrategy:
        def __init__(
            self,
            *,
            attempts: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RetryStrategy.

            :param attempts: (experimental) attempts property. Specify an array of string values to match this event if the actual value of attempts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                retry_strategy = batch_events.BatchJobStateChange.RetryStrategy(
                    attempts=["attempts"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f29bd16caa85a8458ae9d78e3fb6e464bb544829ceb600f1eebbe44e4d56e1db)
                check_type(argname="argument attempts", value=attempts, expected_type=type_hints["attempts"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attempts is not None:
                self._values["attempts"] = attempts

        @builtins.property
        def attempts(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) attempts property.

            Specify an array of string values to match this event if the actual value of attempts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attempts")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RetryStrategy(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.ULimit",
        jsii_struct_bases=[],
        name_mapping={
            "hard_limit": "hardLimit",
            "name": "name",
            "soft_limit": "softLimit",
        },
    )
    class ULimit:
        def __init__(
            self,
            *,
            hard_limit: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            soft_limit: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ULimit.

            :param hard_limit: (experimental) hardLimit property. Specify an array of string values to match this event if the actual value of hardLimit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param soft_limit: (experimental) softLimit property. Specify an array of string values to match this event if the actual value of softLimit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                u_limit = batch_events.BatchJobStateChange.ULimit(
                    hard_limit=["hardLimit"],
                    name=["name"],
                    soft_limit=["softLimit"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__258299732a28a3af5f7b59ec73050f8642b81eec70b81497b7d3b5a724dbf517)
                check_type(argname="argument hard_limit", value=hard_limit, expected_type=type_hints["hard_limit"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument soft_limit", value=soft_limit, expected_type=type_hints["soft_limit"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if hard_limit is not None:
                self._values["hard_limit"] = hard_limit
            if name is not None:
                self._values["name"] = name
            if soft_limit is not None:
                self._values["soft_limit"] = soft_limit

        @builtins.property
        def hard_limit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) hardLimit property.

            Specify an array of string values to match this event if the actual value of hardLimit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hard_limit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def soft_limit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) softLimit property.

            Specify an array of string values to match this event if the actual value of softLimit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("soft_limit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ULimit(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_batch.events.BatchJobStateChange.Volumes",
        jsii_struct_bases=[],
        name_mapping={"host": "host", "name": "name"},
    )
    class Volumes:
        def __init__(
            self,
            *,
            host: typing.Optional[typing.Union["BatchJobStateChange.Host", typing.Dict[builtins.str, typing.Any]]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Volumes.

            :param host: (experimental) host property. Specify an array of string values to match this event if the actual value of host is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_batch import events as batch_events
                
                volumes = batch_events.BatchJobStateChange.Volumes(
                    host=batch_events.BatchJobStateChange.Host(
                        source_path=["sourcePath"]
                    ),
                    name=["name"]
                )
            '''
            if isinstance(host, dict):
                host = BatchJobStateChange.Host(**host)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__97c6fd8fa7451f2775663342d945c7f6f2c018ecaf0d62d7ec3b30aed56d0909)
                check_type(argname="argument host", value=host, expected_type=type_hints["host"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if host is not None:
                self._values["host"] = host
            if name is not None:
                self._values["name"] = name

        @builtins.property
        def host(self) -> typing.Optional["BatchJobStateChange.Host"]:
            '''(experimental) host property.

            Specify an array of string values to match this event if the actual value of host is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("host")
            return typing.cast(typing.Optional["BatchJobStateChange.Host"], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Volumes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "AWSAPICallViaCloudTrail",
    "BatchJobStateChange",
]

publication.publish()

def _typecheckingstub__c33ab51d3a9f2b58bad65dfe072d45c4b8681c8b63d9085c8880e83615960bce(
    *,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RequestParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    response_elements: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResponseElements, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fe2d76f67291c45a861f9c602dbecbce74758b6a51f3332d986d6a835d4483e4(
    *,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bee2a5239c4cb32707f1a25601914cd7f08c797fe8224dca78858614bfe5c18a(
    *,
    environment: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.ContainerOverridesItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9539d2300ceedcd262c982e2a4a7bb5a3111a55ca05afa0f999effe42d2fe5fe(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6dc9d8283e2d259b67ae718deb95b9cc174f2810f7ad85aaaacaa177ba28c046(
    *,
    container_overrides: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ContainerOverrides, typing.Dict[builtins.str, typing.Any]]] = None,
    job_definition: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_queue: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6e65b18a662c11a81df8ff855c17f59caa83818f10922c2f054b1674c5b1dbb(
    *,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e56d2728565d441ea50206b4116eec9b25595a05b15f19d9fb70d28b750c0f58(
    *,
    attributes: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    session_issuer: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionIssuer, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d530a338abc2ef51ca9b7ff7fcbcd2ea4dd18e838504697af56c4e424f3d7eea(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e8fff506c6b4a487a35d07bf22250d3098962ae1155f2117cc7e59419ba76a7a(
    *,
    access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_context: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionContext, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__94b2ff319886b4b0197531b8a6cf1f27df3811aa62d4da21e4850cad6f132a25(
    *,
    container: typing.Optional[typing.Union[BatchJobStateChange.Container1, typing.Dict[builtins.str, typing.Any]]] = None,
    started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    stopped_at: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c8e715c466e9a583c5cc91ea3809fabcd4827ffe160b5cc6bea23c2bdbe49123(
    *,
    attempts: typing.Optional[typing.Sequence[typing.Union[BatchJobStateChange.BatchJobStateChangeItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    container: typing.Optional[typing.Union[BatchJobStateChange.Container, typing.Dict[builtins.str, typing.Any]]] = None,
    created_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    depends_on: typing.Optional[typing.Sequence[typing.Union[BatchJobStateChange.JobDependency, typing.Dict[builtins.str, typing.Any]]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    job_definition: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_queue: typing.Optional[typing.Sequence[builtins.str]] = None,
    parameters: typing.Optional[typing.Sequence[builtins.str]] = None,
    retry_strategy: typing.Optional[typing.Union[BatchJobStateChange.RetryStrategy, typing.Dict[builtins.str, typing.Any]]] = None,
    started_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    stopped_at: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1cd160f8850e3ef4de028eecf550ca23767667d312c16f7d11422f4c829b91aa(
    *,
    command: typing.Optional[typing.Sequence[builtins.str]] = None,
    container_instance_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    environment: typing.Optional[typing.Sequence[typing.Union[BatchJobStateChange.ContainerItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    exit_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    image: typing.Optional[typing.Sequence[builtins.str]] = None,
    log_stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    memory: typing.Optional[typing.Sequence[builtins.str]] = None,
    mount_points: typing.Optional[typing.Sequence[typing.Union[BatchJobStateChange.MountPoint, typing.Dict[builtins.str, typing.Any]]]] = None,
    network_interfaces: typing.Optional[typing.Sequence[typing.Union[BatchJobStateChange.NetworkInterface, typing.Dict[builtins.str, typing.Any]]]] = None,
    resource_requirements: typing.Optional[typing.Sequence[typing.Union[BatchJobStateChange.ResourceRequirement, typing.Dict[builtins.str, typing.Any]]]] = None,
    task_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    ulimits: typing.Optional[typing.Sequence[typing.Union[BatchJobStateChange.ULimit, typing.Dict[builtins.str, typing.Any]]]] = None,
    vcpus: typing.Optional[typing.Sequence[builtins.str]] = None,
    volumes: typing.Optional[typing.Sequence[typing.Union[BatchJobStateChange.Volumes, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f53562086744302dc492877fdf7f4075ab4a5d62b0694ab7c43ef67b7a4fe44b(
    *,
    container_instance_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    exit_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    log_stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    network_interfaces: typing.Optional[typing.Sequence[typing.Any]] = None,
    task_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad90a22e15e60bf6c7a4707c0b9be7dcf7900401ea5d33f25bef937f4c51ff4a(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9a8897caf251f7cd025ab6aa8ec721d602240e817d4f6d1e5c911c4627ffeeb(
    *,
    source_path: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__235a8e298e86103e727221619e52a4b812d81b764a65cfb9c0bdda83472a2c6f(
    *,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3dca93e802ae7b74af0a19e89646b4a9f80a25b1363647d003b755198112b05d(
    *,
    container_path: typing.Optional[typing.Sequence[builtins.str]] = None,
    read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_volume: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9108185b5db477f200e6ebb31f9ca068ace9b29c563405e9f9de38ff2bc67bb0(
    *,
    attachment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ipv6_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    private_ipv4_address: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f3c7f45f2b922dbc6d0c3c8829ea9ced4c7b80e1ec0db26219a29695d3e08087(
    *,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f29bd16caa85a8458ae9d78e3fb6e464bb544829ceb600f1eebbe44e4d56e1db(
    *,
    attempts: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__258299732a28a3af5f7b59ec73050f8642b81eec70b81497b7d3b5a724dbf517(
    *,
    hard_limit: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    soft_limit: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97c6fd8fa7451f2775663342d945c7f6f2c018ecaf0d62d7ec3b30aed56d0909(
    *,
    host: typing.Optional[typing.Union[BatchJobStateChange.Host, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
