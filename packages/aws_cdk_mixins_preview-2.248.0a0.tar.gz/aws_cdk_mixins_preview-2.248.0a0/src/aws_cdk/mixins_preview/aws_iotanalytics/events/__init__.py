from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_iotanalytics as _aws_cdk_interfaces_aws_iotanalytics_ceddda9d


class AWSAPICallViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.iotanalytics@AWSAPICallViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
        
        a_wSAPICall_via_cloud_trail = iotanalytics_events.AWSAPICallViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="awsAPICallViaCloudTrailPattern")
    @builtins.classmethod
    def aws_api_call_via_cloud_trail_pattern(
        cls,
        *,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS API Call via CloudTrail.

        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            aws_region=aws_region,
            error_code=error_code,
            error_message=error_message,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            request_id=request_id,
            request_parameters=request_parameters,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "awsAPICallViaCloudTrailPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "aws_region": "awsRegion",
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "request_id": "requestId",
            "request_parameters": "requestParameters",
            "response_elements": "responseElements",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSAPICallViaCloudTrailProps:
        def __init__(
            self,
            *,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.iotanalytics@AWSAPICallViaCloudTrail event.

            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                a_wSAPICall_via_cloud_trail_props = iotanalytics_events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
                    aws_region=["awsRegion"],
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    request_id=["requestId"],
                    request_parameters=iotanalytics_events.AWSAPICallViaCloudTrail.RequestParameters(
                        channel_name=["channelName"],
                        channel_storage=iotanalytics_events.AWSAPICallViaCloudTrail.ChannelStorage(
                            customer_managed_s3=iotanalytics_events.AWSAPICallViaCloudTrail.CustomerManagedS3(
                                bucket=["bucket"],
                                key_prefix=["keyPrefix"],
                                role_arn=["roleArn"]
                            )
                        ),
                        dataset_name=["datasetName"],
                        datastore_index_name=["datastoreIndexName"],
                        datastore_name=["datastoreName"],
                        datastore_storage=iotanalytics_events.AWSAPICallViaCloudTrail.ChannelStorage(
                            customer_managed_s3=iotanalytics_events.AWSAPICallViaCloudTrail.CustomerManagedS3(
                                bucket=["bucket"],
                                key_prefix=["keyPrefix"],
                                role_arn=["roleArn"]
                            )
                        ),
                        end_time=["endTime"],
                        logging_options=iotanalytics_events.AWSAPICallViaCloudTrail.LoggingOptions(
                            enabled=["enabled"]
                        ),
                        max_messages=["maxMessages"],
                        payloads=[iotanalytics_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                            address=["address"],
                            big_endian=["bigEndian"],
                            capacity=["capacity"],
                            hb=[123],
                            is_read_only=["isReadOnly"],
                            limit=["limit"],
                            mark=["mark"],
                            native_byte_order=["nativeByteOrder"],
                            offset=["offset"],
                            position=["position"]
                        )],
                        pipeline_activity=iotanalytics_events.AWSAPICallViaCloudTrail.PipelineActivity(
                            math=iotanalytics_events.AWSAPICallViaCloudTrail.MathType(
                                attribute=["attribute"],
                                math=["math"],
                                name=["name"]
                            )
                        ),
                        pipeline_name=["pipelineName"],
                        query_action=iotanalytics_events.AWSAPICallViaCloudTrail.QueryAction(
                            sql_query=["sqlQuery"]
                        ),
                        reprocessing_id=["reprocessingId"],
                        resource_arn=["resourceArn"],
                        retention_period=iotanalytics_events.AWSAPICallViaCloudTrail.RetentionPeriod(
                            number_of_days=["numberOfDays"],
                            unlimited=["unlimited"]
                        ),
                        settings=iotanalytics_events.AWSAPICallViaCloudTrail.Settings(
                            timeseries=iotanalytics_events.AWSAPICallViaCloudTrail.Timeseries(
                                dimension_attributes=[iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                                    attribute=["attribute"],
                                    name=["name"]
                                )],
                                measure_attributes=[iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                                    attribute=["attribute"],
                                    name=["name"]
                                )],
                                timestamp_attribute=["timestampAttribute"]
                            )
                        ),
                        start_time=["startTime"],
                        tag_keys=["tagKeys"],
                        tags=[iotanalytics_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                            key=["key"],
                            value=["value"]
                        )],
                        version_id=["versionId"]
                    ),
                    response_elements=iotanalytics_events.AWSAPICallViaCloudTrail.ResponseElements(
                        channel_arn=["channelArn"],
                        channel_name=["channelName"],
                        dataset_arn=["datasetArn"],
                        dataset_name=["datasetName"],
                        datastore_arn=["datastoreArn"],
                        datastore_index_arn=["datastoreIndexArn"],
                        datastore_index_name=["datastoreIndexName"],
                        datastore_name=["datastoreName"],
                        pipeline_arn=["pipelineArn"],
                        pipeline_name=["pipelineName"],
                        reprocessing_id=["reprocessingId"],
                        retention_period=iotanalytics_events.AWSAPICallViaCloudTrail.RetentionPeriod1(
                            number_of_days=["numberOfDays"],
                            unlimited=["unlimited"]
                        ),
                        version_id=["versionId"]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=iotanalytics_events.AWSAPICallViaCloudTrail.UserIdentity(
                        access_key_id=["accessKeyId"],
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        session_context=iotanalytics_events.AWSAPICallViaCloudTrail.SessionContext(
                            attributes=iotanalytics_events.AWSAPICallViaCloudTrail.Attributes(
                                creation_date=["creationDate"],
                                mfa_authenticated=["mfaAuthenticated"]
                            ),
                            session_issuer=iotanalytics_events.AWSAPICallViaCloudTrail.SessionIssuer(
                                account_id=["accountId"],
                                arn=["arn"],
                                principal_id=["principalId"],
                                type=["type"],
                                user_name=["userName"]
                            ),
                            web_id_federation_data=iotanalytics_events.AWSAPICallViaCloudTrail.WebIdFederationData(
                                attributes={
                                    "attributes_key": "attributes"
                                },
                                federated_provider=["federatedProvider"]
                            )
                        ),
                        type=["type"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(request_parameters, dict):
                request_parameters = AWSAPICallViaCloudTrail.RequestParameters(**request_parameters)
            if isinstance(response_elements, dict):
                response_elements = AWSAPICallViaCloudTrail.ResponseElements(**response_elements)
            if isinstance(user_identity, dict):
                user_identity = AWSAPICallViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__029abf1ccc22f3c1595cdf800cd4f4f0f9b89d21645079b9c36cc4516c783f3a)
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument request_parameters", value=request_parameters, expected_type=type_hints["request_parameters"])
                check_type(argname="argument response_elements", value=response_elements, expected_type=type_hints["response_elements"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if request_id is not None:
                self._values["request_id"] = request_id
            if request_parameters is not None:
                self._values["request_parameters"] = request_parameters
            if response_elements is not None:
                self._values["response_elements"] = response_elements
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestID property.

            Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"]:
            '''(experimental) requestParameters property.

            Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"], result)

        @builtins.property
        def response_elements(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"]:
            '''(experimental) responseElements property.

            Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response_elements")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSAPICallViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "creation_date": "creationDate",
            "mfa_authenticated": "mfaAuthenticated",
        },
    )
    class Attributes:
        def __init__(
            self,
            *,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Attributes.

            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mfa_authenticated: (experimental) mfaAuthenticated property. Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                attributes = iotanalytics_events.AWSAPICallViaCloudTrail.Attributes(
                    creation_date=["creationDate"],
                    mfa_authenticated=["mfaAuthenticated"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3bf903d3b439b48ab6a38403dc381fa98786a8756721efc16b905d44fdc7ebf6)
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument mfa_authenticated", value=mfa_authenticated, expected_type=type_hints["mfa_authenticated"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if mfa_authenticated is not None:
                self._values["mfa_authenticated"] = mfa_authenticated

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mfa_authenticated(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mfaAuthenticated property.

            Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mfa_authenticated")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.ChannelStorage",
        jsii_struct_bases=[],
        name_mapping={"customer_managed_s3": "customerManagedS3"},
    )
    class ChannelStorage:
        def __init__(
            self,
            *,
            customer_managed_s3: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.CustomerManagedS3", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for ChannelStorage.

            :param customer_managed_s3: (experimental) customerManagedS3 property. Specify an array of string values to match this event if the actual value of customerManagedS3 is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                channel_storage = iotanalytics_events.AWSAPICallViaCloudTrail.ChannelStorage(
                    customer_managed_s3=iotanalytics_events.AWSAPICallViaCloudTrail.CustomerManagedS3(
                        bucket=["bucket"],
                        key_prefix=["keyPrefix"],
                        role_arn=["roleArn"]
                    )
                )
            '''
            if isinstance(customer_managed_s3, dict):
                customer_managed_s3 = AWSAPICallViaCloudTrail.CustomerManagedS3(**customer_managed_s3)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__173c0ca8f9025672b3f02e987ddfc6e91c37704e16a0007e2dd92c2cd06c6e06)
                check_type(argname="argument customer_managed_s3", value=customer_managed_s3, expected_type=type_hints["customer_managed_s3"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if customer_managed_s3 is not None:
                self._values["customer_managed_s3"] = customer_managed_s3

        @builtins.property
        def customer_managed_s3(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.CustomerManagedS3"]:
            '''(experimental) customerManagedS3 property.

            Specify an array of string values to match this event if the actual value of customerManagedS3 is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("customer_managed_s3")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.CustomerManagedS3"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ChannelStorage(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.CustomerManagedS3",
        jsii_struct_bases=[],
        name_mapping={
            "bucket": "bucket",
            "key_prefix": "keyPrefix",
            "role_arn": "roleArn",
        },
    )
    class CustomerManagedS3:
        def __init__(
            self,
            *,
            bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            key_prefix: typing.Optional[typing.Sequence[builtins.str]] = None,
            role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CustomerManagedS3.

            :param bucket: (experimental) bucket property. Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param key_prefix: (experimental) keyPrefix property. Specify an array of string values to match this event if the actual value of keyPrefix is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param role_arn: (experimental) roleArn property. Specify an array of string values to match this event if the actual value of roleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                customer_managed_s3 = iotanalytics_events.AWSAPICallViaCloudTrail.CustomerManagedS3(
                    bucket=["bucket"],
                    key_prefix=["keyPrefix"],
                    role_arn=["roleArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c5da4ccc83cceeaf3f18988858e689c9c785e8b725da8229f66051417f9f2f13)
                check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
                check_type(argname="argument key_prefix", value=key_prefix, expected_type=type_hints["key_prefix"])
                check_type(argname="argument role_arn", value=role_arn, expected_type=type_hints["role_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bucket is not None:
                self._values["bucket"] = bucket
            if key_prefix is not None:
                self._values["key_prefix"] = key_prefix
            if role_arn is not None:
                self._values["role_arn"] = role_arn

        @builtins.property
        def bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bucket property.

            Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def key_prefix(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) keyPrefix property.

            Specify an array of string values to match this event if the actual value of keyPrefix is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key_prefix")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) roleArn property.

            Specify an array of string values to match this event if the actual value of roleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CustomerManagedS3(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.LoggingOptions",
        jsii_struct_bases=[],
        name_mapping={"enabled": "enabled"},
    )
    class LoggingOptions:
        def __init__(
            self,
            *,
            enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for LoggingOptions.

            :param enabled: (experimental) enabled property. Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                logging_options = iotanalytics_events.AWSAPICallViaCloudTrail.LoggingOptions(
                    enabled=["enabled"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__200a4654105b10d6c5b31fb21f6ddeee14e3cb7fdf6e3c1b81b8343001ea432c)
                check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if enabled is not None:
                self._values["enabled"] = enabled

        @builtins.property
        def enabled(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enabled property.

            Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enabled")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LoggingOptions(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.MathType",
        jsii_struct_bases=[],
        name_mapping={"attribute": "attribute", "math": "math", "name": "name"},
    )
    class MathType:
        def __init__(
            self,
            *,
            attribute: typing.Optional[typing.Sequence[builtins.str]] = None,
            math: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Math.

            :param attribute: (experimental) attribute property. Specify an array of string values to match this event if the actual value of attribute is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param math: (experimental) math property. Specify an array of string values to match this event if the actual value of math is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                math_type = iotanalytics_events.AWSAPICallViaCloudTrail.MathType(
                    attribute=["attribute"],
                    math=["math"],
                    name=["name"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9ed03e61c12e61456b1129d4c4387eb4db28a6ca55f1c2ab524b38f2b437777a)
                check_type(argname="argument attribute", value=attribute, expected_type=type_hints["attribute"])
                check_type(argname="argument math", value=math, expected_type=type_hints["math"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attribute is not None:
                self._values["attribute"] = attribute
            if math is not None:
                self._values["math"] = math
            if name is not None:
                self._values["name"] = name

        @builtins.property
        def attribute(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) attribute property.

            Specify an array of string values to match this event if the actual value of attribute is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attribute")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def math(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) math property.

            Specify an array of string values to match this event if the actual value of math is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("math")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "MathType(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.PipelineActivity",
        jsii_struct_bases=[],
        name_mapping={"math": "math"},
    )
    class PipelineActivity:
        def __init__(
            self,
            *,
            math: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.MathType", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for PipelineActivity.

            :param math: (experimental) math property. Specify an array of string values to match this event if the actual value of math is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                pipeline_activity = iotanalytics_events.AWSAPICallViaCloudTrail.PipelineActivity(
                    math=iotanalytics_events.AWSAPICallViaCloudTrail.MathType(
                        attribute=["attribute"],
                        math=["math"],
                        name=["name"]
                    )
                )
            '''
            if isinstance(math, dict):
                math = AWSAPICallViaCloudTrail.MathType(**math)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fde0c63931e24964596fb6c78d03944a766bdd0c64cb43c99f8986646c24db6e)
                check_type(argname="argument math", value=math, expected_type=type_hints["math"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if math is not None:
                self._values["math"] = math

        @builtins.property
        def math(self) -> typing.Optional["AWSAPICallViaCloudTrail.MathType"]:
            '''(experimental) math property.

            Specify an array of string values to match this event if the actual value of math is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("math")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.MathType"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PipelineActivity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.QueryAction",
        jsii_struct_bases=[],
        name_mapping={"sql_query": "sqlQuery"},
    )
    class QueryAction:
        def __init__(
            self,
            *,
            sql_query: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for QueryAction.

            :param sql_query: (experimental) sqlQuery property. Specify an array of string values to match this event if the actual value of sqlQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                query_action = iotanalytics_events.AWSAPICallViaCloudTrail.QueryAction(
                    sql_query=["sqlQuery"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3688d868b45627288ae8b9e4d3cd7088ba2b1766b873ba812dbbd0d0f49f00b7)
                check_type(argname="argument sql_query", value=sql_query, expected_type=type_hints["sql_query"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if sql_query is not None:
                self._values["sql_query"] = sql_query

        @builtins.property
        def sql_query(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sqlQuery property.

            Specify an array of string values to match this event if the actual value of sqlQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("sql_query")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "QueryAction(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.RequestParameters",
        jsii_struct_bases=[],
        name_mapping={
            "channel_name": "channelName",
            "channel_storage": "channelStorage",
            "dataset_name": "datasetName",
            "datastore_index_name": "datastoreIndexName",
            "datastore_name": "datastoreName",
            "datastore_storage": "datastoreStorage",
            "end_time": "endTime",
            "logging_options": "loggingOptions",
            "max_messages": "maxMessages",
            "payloads": "payloads",
            "pipeline_activity": "pipelineActivity",
            "pipeline_name": "pipelineName",
            "query_action": "queryAction",
            "reprocessing_id": "reprocessingId",
            "resource_arn": "resourceArn",
            "retention_period": "retentionPeriod",
            "settings": "settings",
            "start_time": "startTime",
            "tag_keys": "tagKeys",
            "tags": "tags",
            "version_id": "versionId",
        },
    )
    class RequestParameters:
        def __init__(
            self,
            *,
            channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            channel_storage: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ChannelStorage", typing.Dict[builtins.str, typing.Any]]] = None,
            dataset_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_index_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_storage: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ChannelStorage", typing.Dict[builtins.str, typing.Any]]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            logging_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LoggingOptions", typing.Dict[builtins.str, typing.Any]]] = None,
            max_messages: typing.Optional[typing.Sequence[builtins.str]] = None,
            payloads: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            pipeline_activity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.PipelineActivity", typing.Dict[builtins.str, typing.Any]]] = None,
            pipeline_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            query_action: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.QueryAction", typing.Dict[builtins.str, typing.Any]]] = None,
            reprocessing_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            retention_period: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RetentionPeriod", typing.Dict[builtins.str, typing.Any]]] = None,
            settings: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Settings", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem1", typing.Dict[builtins.str, typing.Any]]]] = None,
            version_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParameters.

            :param channel_name: (experimental) channelName property. Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param channel_storage: (experimental) channelStorage property. Specify an array of string values to match this event if the actual value of channelStorage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param dataset_name: (experimental) datasetName property. Specify an array of string values to match this event if the actual value of datasetName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_index_name: (experimental) datastoreIndexName property. Specify an array of string values to match this event if the actual value of datastoreIndexName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_storage: (experimental) datastoreStorage property. Specify an array of string values to match this event if the actual value of datastoreStorage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param logging_options: (experimental) loggingOptions property. Specify an array of string values to match this event if the actual value of loggingOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_messages: (experimental) maxMessages property. Specify an array of string values to match this event if the actual value of maxMessages is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param payloads: (experimental) payloads property. Specify an array of string values to match this event if the actual value of payloads is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_activity: (experimental) pipelineActivity property. Specify an array of string values to match this event if the actual value of pipelineActivity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_name: (experimental) pipelineName property. Specify an array of string values to match this event if the actual value of pipelineName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param query_action: (experimental) queryAction property. Specify an array of string values to match this event if the actual value of queryAction is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reprocessing_id: (experimental) reprocessingId property. Specify an array of string values to match this event if the actual value of reprocessingId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_arn: (experimental) resourceArn property. Specify an array of string values to match this event if the actual value of resourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param retention_period: (experimental) retentionPeriod property. Specify an array of string values to match this event if the actual value of retentionPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param settings: (experimental) settings property. Specify an array of string values to match this event if the actual value of settings is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_keys: (experimental) tagKeys property. Specify an array of string values to match this event if the actual value of tagKeys is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version_id: (experimental) versionId property. Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                request_parameters = iotanalytics_events.AWSAPICallViaCloudTrail.RequestParameters(
                    channel_name=["channelName"],
                    channel_storage=iotanalytics_events.AWSAPICallViaCloudTrail.ChannelStorage(
                        customer_managed_s3=iotanalytics_events.AWSAPICallViaCloudTrail.CustomerManagedS3(
                            bucket=["bucket"],
                            key_prefix=["keyPrefix"],
                            role_arn=["roleArn"]
                        )
                    ),
                    dataset_name=["datasetName"],
                    datastore_index_name=["datastoreIndexName"],
                    datastore_name=["datastoreName"],
                    datastore_storage=iotanalytics_events.AWSAPICallViaCloudTrail.ChannelStorage(
                        customer_managed_s3=iotanalytics_events.AWSAPICallViaCloudTrail.CustomerManagedS3(
                            bucket=["bucket"],
                            key_prefix=["keyPrefix"],
                            role_arn=["roleArn"]
                        )
                    ),
                    end_time=["endTime"],
                    logging_options=iotanalytics_events.AWSAPICallViaCloudTrail.LoggingOptions(
                        enabled=["enabled"]
                    ),
                    max_messages=["maxMessages"],
                    payloads=[iotanalytics_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                        address=["address"],
                        big_endian=["bigEndian"],
                        capacity=["capacity"],
                        hb=[123],
                        is_read_only=["isReadOnly"],
                        limit=["limit"],
                        mark=["mark"],
                        native_byte_order=["nativeByteOrder"],
                        offset=["offset"],
                        position=["position"]
                    )],
                    pipeline_activity=iotanalytics_events.AWSAPICallViaCloudTrail.PipelineActivity(
                        math=iotanalytics_events.AWSAPICallViaCloudTrail.MathType(
                            attribute=["attribute"],
                            math=["math"],
                            name=["name"]
                        )
                    ),
                    pipeline_name=["pipelineName"],
                    query_action=iotanalytics_events.AWSAPICallViaCloudTrail.QueryAction(
                        sql_query=["sqlQuery"]
                    ),
                    reprocessing_id=["reprocessingId"],
                    resource_arn=["resourceArn"],
                    retention_period=iotanalytics_events.AWSAPICallViaCloudTrail.RetentionPeriod(
                        number_of_days=["numberOfDays"],
                        unlimited=["unlimited"]
                    ),
                    settings=iotanalytics_events.AWSAPICallViaCloudTrail.Settings(
                        timeseries=iotanalytics_events.AWSAPICallViaCloudTrail.Timeseries(
                            dimension_attributes=[iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                                attribute=["attribute"],
                                name=["name"]
                            )],
                            measure_attributes=[iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                                attribute=["attribute"],
                                name=["name"]
                            )],
                            timestamp_attribute=["timestampAttribute"]
                        )
                    ),
                    start_time=["startTime"],
                    tag_keys=["tagKeys"],
                    tags=[iotanalytics_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                        key=["key"],
                        value=["value"]
                    )],
                    version_id=["versionId"]
                )
            '''
            if isinstance(channel_storage, dict):
                channel_storage = AWSAPICallViaCloudTrail.ChannelStorage(**channel_storage)
            if isinstance(datastore_storage, dict):
                datastore_storage = AWSAPICallViaCloudTrail.ChannelStorage(**datastore_storage)
            if isinstance(logging_options, dict):
                logging_options = AWSAPICallViaCloudTrail.LoggingOptions(**logging_options)
            if isinstance(pipeline_activity, dict):
                pipeline_activity = AWSAPICallViaCloudTrail.PipelineActivity(**pipeline_activity)
            if isinstance(query_action, dict):
                query_action = AWSAPICallViaCloudTrail.QueryAction(**query_action)
            if isinstance(retention_period, dict):
                retention_period = AWSAPICallViaCloudTrail.RetentionPeriod(**retention_period)
            if isinstance(settings, dict):
                settings = AWSAPICallViaCloudTrail.Settings(**settings)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__77dd7badf37ac724649e522b4826b8d07cd75547a145702aa5068fc2b162b3ce)
                check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
                check_type(argname="argument channel_storage", value=channel_storage, expected_type=type_hints["channel_storage"])
                check_type(argname="argument dataset_name", value=dataset_name, expected_type=type_hints["dataset_name"])
                check_type(argname="argument datastore_index_name", value=datastore_index_name, expected_type=type_hints["datastore_index_name"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_storage", value=datastore_storage, expected_type=type_hints["datastore_storage"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument logging_options", value=logging_options, expected_type=type_hints["logging_options"])
                check_type(argname="argument max_messages", value=max_messages, expected_type=type_hints["max_messages"])
                check_type(argname="argument payloads", value=payloads, expected_type=type_hints["payloads"])
                check_type(argname="argument pipeline_activity", value=pipeline_activity, expected_type=type_hints["pipeline_activity"])
                check_type(argname="argument pipeline_name", value=pipeline_name, expected_type=type_hints["pipeline_name"])
                check_type(argname="argument query_action", value=query_action, expected_type=type_hints["query_action"])
                check_type(argname="argument reprocessing_id", value=reprocessing_id, expected_type=type_hints["reprocessing_id"])
                check_type(argname="argument resource_arn", value=resource_arn, expected_type=type_hints["resource_arn"])
                check_type(argname="argument retention_period", value=retention_period, expected_type=type_hints["retention_period"])
                check_type(argname="argument settings", value=settings, expected_type=type_hints["settings"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument tag_keys", value=tag_keys, expected_type=type_hints["tag_keys"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
                check_type(argname="argument version_id", value=version_id, expected_type=type_hints["version_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if channel_name is not None:
                self._values["channel_name"] = channel_name
            if channel_storage is not None:
                self._values["channel_storage"] = channel_storage
            if dataset_name is not None:
                self._values["dataset_name"] = dataset_name
            if datastore_index_name is not None:
                self._values["datastore_index_name"] = datastore_index_name
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_storage is not None:
                self._values["datastore_storage"] = datastore_storage
            if end_time is not None:
                self._values["end_time"] = end_time
            if logging_options is not None:
                self._values["logging_options"] = logging_options
            if max_messages is not None:
                self._values["max_messages"] = max_messages
            if payloads is not None:
                self._values["payloads"] = payloads
            if pipeline_activity is not None:
                self._values["pipeline_activity"] = pipeline_activity
            if pipeline_name is not None:
                self._values["pipeline_name"] = pipeline_name
            if query_action is not None:
                self._values["query_action"] = query_action
            if reprocessing_id is not None:
                self._values["reprocessing_id"] = reprocessing_id
            if resource_arn is not None:
                self._values["resource_arn"] = resource_arn
            if retention_period is not None:
                self._values["retention_period"] = retention_period
            if settings is not None:
                self._values["settings"] = settings
            if start_time is not None:
                self._values["start_time"] = start_time
            if tag_keys is not None:
                self._values["tag_keys"] = tag_keys
            if tags is not None:
                self._values["tags"] = tags
            if version_id is not None:
                self._values["version_id"] = version_id

        @builtins.property
        def channel_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) channelName property.

            Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def channel_storage(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ChannelStorage"]:
            '''(experimental) channelStorage property.

            Specify an array of string values to match this event if the actual value of channelStorage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_storage")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ChannelStorage"], result)

        @builtins.property
        def dataset_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datasetName property.

            Specify an array of string values to match this event if the actual value of datasetName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dataset_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_index_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreIndexName property.

            Specify an array of string values to match this event if the actual value of datastoreIndexName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_index_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_storage(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ChannelStorage"]:
            '''(experimental) datastoreStorage property.

            Specify an array of string values to match this event if the actual value of datastoreStorage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_storage")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ChannelStorage"], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def logging_options(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LoggingOptions"]:
            '''(experimental) loggingOptions property.

            Specify an array of string values to match this event if the actual value of loggingOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("logging_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LoggingOptions"], result)

        @builtins.property
        def max_messages(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) maxMessages property.

            Specify an array of string values to match this event if the actual value of maxMessages is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_messages")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def payloads(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]]:
            '''(experimental) payloads property.

            Specify an array of string values to match this event if the actual value of payloads is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("payloads")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]], result)

        @builtins.property
        def pipeline_activity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.PipelineActivity"]:
            '''(experimental) pipelineActivity property.

            Specify an array of string values to match this event if the actual value of pipelineActivity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_activity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.PipelineActivity"], result)

        @builtins.property
        def pipeline_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineName property.

            Specify an array of string values to match this event if the actual value of pipelineName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def query_action(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.QueryAction"]:
            '''(experimental) queryAction property.

            Specify an array of string values to match this event if the actual value of queryAction is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("query_action")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.QueryAction"], result)

        @builtins.property
        def reprocessing_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reprocessingId property.

            Specify an array of string values to match this event if the actual value of reprocessingId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reprocessing_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resourceArn property.

            Specify an array of string values to match this event if the actual value of resourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def retention_period(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RetentionPeriod"]:
            '''(experimental) retentionPeriod property.

            Specify an array of string values to match this event if the actual value of retentionPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("retention_period")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RetentionPeriod"], result)

        @builtins.property
        def settings(self) -> typing.Optional["AWSAPICallViaCloudTrail.Settings"]:
            '''(experimental) settings property.

            Specify an array of string values to match this event if the actual value of settings is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("settings")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Settings"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_keys(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagKeys property.

            Specify an array of string values to match this event if the actual value of tagKeys is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_keys")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem1"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem1"]], result)

        @builtins.property
        def version_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) versionId property.

            Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.RequestParametersItem",
        jsii_struct_bases=[],
        name_mapping={
            "address": "address",
            "big_endian": "bigEndian",
            "capacity": "capacity",
            "hb": "hb",
            "is_read_only": "isReadOnly",
            "limit": "limit",
            "mark": "mark",
            "native_byte_order": "nativeByteOrder",
            "offset": "offset",
            "position": "position",
        },
    )
    class RequestParametersItem:
        def __init__(
            self,
            *,
            address: typing.Optional[typing.Sequence[builtins.str]] = None,
            big_endian: typing.Optional[typing.Sequence[builtins.str]] = None,
            capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            hb: typing.Optional[typing.Sequence[jsii.Number]] = None,
            is_read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
            limit: typing.Optional[typing.Sequence[builtins.str]] = None,
            mark: typing.Optional[typing.Sequence[builtins.str]] = None,
            native_byte_order: typing.Optional[typing.Sequence[builtins.str]] = None,
            offset: typing.Optional[typing.Sequence[builtins.str]] = None,
            position: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem.

            :param address: (experimental) address property. Specify an array of string values to match this event if the actual value of address is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param big_endian: (experimental) bigEndian property. Specify an array of string values to match this event if the actual value of bigEndian is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param capacity: (experimental) capacity property. Specify an array of string values to match this event if the actual value of capacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param hb: (experimental) hb property. Specify an array of string values to match this event if the actual value of hb is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param is_read_only: (experimental) isReadOnly property. Specify an array of string values to match this event if the actual value of isReadOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param limit: (experimental) limit property. Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mark: (experimental) mark property. Specify an array of string values to match this event if the actual value of mark is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param native_byte_order: (experimental) nativeByteOrder property. Specify an array of string values to match this event if the actual value of nativeByteOrder is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param offset: (experimental) offset property. Specify an array of string values to match this event if the actual value of offset is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param position: (experimental) position property. Specify an array of string values to match this event if the actual value of position is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                request_parameters_item = iotanalytics_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                    address=["address"],
                    big_endian=["bigEndian"],
                    capacity=["capacity"],
                    hb=[123],
                    is_read_only=["isReadOnly"],
                    limit=["limit"],
                    mark=["mark"],
                    native_byte_order=["nativeByteOrder"],
                    offset=["offset"],
                    position=["position"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5eb8fb0a9bdbf4722dfa429603c0d6f2ba0ac6feb87ee873873b928909ff1111)
                check_type(argname="argument address", value=address, expected_type=type_hints["address"])
                check_type(argname="argument big_endian", value=big_endian, expected_type=type_hints["big_endian"])
                check_type(argname="argument capacity", value=capacity, expected_type=type_hints["capacity"])
                check_type(argname="argument hb", value=hb, expected_type=type_hints["hb"])
                check_type(argname="argument is_read_only", value=is_read_only, expected_type=type_hints["is_read_only"])
                check_type(argname="argument limit", value=limit, expected_type=type_hints["limit"])
                check_type(argname="argument mark", value=mark, expected_type=type_hints["mark"])
                check_type(argname="argument native_byte_order", value=native_byte_order, expected_type=type_hints["native_byte_order"])
                check_type(argname="argument offset", value=offset, expected_type=type_hints["offset"])
                check_type(argname="argument position", value=position, expected_type=type_hints["position"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if address is not None:
                self._values["address"] = address
            if big_endian is not None:
                self._values["big_endian"] = big_endian
            if capacity is not None:
                self._values["capacity"] = capacity
            if hb is not None:
                self._values["hb"] = hb
            if is_read_only is not None:
                self._values["is_read_only"] = is_read_only
            if limit is not None:
                self._values["limit"] = limit
            if mark is not None:
                self._values["mark"] = mark
            if native_byte_order is not None:
                self._values["native_byte_order"] = native_byte_order
            if offset is not None:
                self._values["offset"] = offset
            if position is not None:
                self._values["position"] = position

        @builtins.property
        def address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) address property.

            Specify an array of string values to match this event if the actual value of address is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def big_endian(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bigEndian property.

            Specify an array of string values to match this event if the actual value of bigEndian is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("big_endian")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def capacity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) capacity property.

            Specify an array of string values to match this event if the actual value of capacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def hb(self) -> typing.Optional[typing.List[jsii.Number]]:
            '''(experimental) hb property.

            Specify an array of string values to match this event if the actual value of hb is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hb")
            return typing.cast(typing.Optional[typing.List[jsii.Number]], result)

        @builtins.property
        def is_read_only(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) isReadOnly property.

            Specify an array of string values to match this event if the actual value of isReadOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("is_read_only")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def limit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) limit property.

            Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("limit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mark(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mark property.

            Specify an array of string values to match this event if the actual value of mark is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mark")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def native_byte_order(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) nativeByteOrder property.

            Specify an array of string values to match this event if the actual value of nativeByteOrder is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("native_byte_order")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def offset(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) offset property.

            Specify an array of string values to match this event if the actual value of offset is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("offset")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def position(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) position property.

            Specify an array of string values to match this event if the actual value of position is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("position")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.RequestParametersItem1",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class RequestParametersItem1:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem_1.

            :param key: (experimental) key property. Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                request_parameters_item1 = iotanalytics_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__904a206f0d7a72ae076e72167ff1e7f83195473f5e990e8dab4c803ec3f532aa)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) key property.

            Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.ResponseElements",
        jsii_struct_bases=[],
        name_mapping={
            "channel_arn": "channelArn",
            "channel_name": "channelName",
            "dataset_arn": "datasetArn",
            "dataset_name": "datasetName",
            "datastore_arn": "datastoreArn",
            "datastore_index_arn": "datastoreIndexArn",
            "datastore_index_name": "datastoreIndexName",
            "datastore_name": "datastoreName",
            "pipeline_arn": "pipelineArn",
            "pipeline_name": "pipelineName",
            "reprocessing_id": "reprocessingId",
            "retention_period": "retentionPeriod",
            "version_id": "versionId",
        },
    )
    class ResponseElements:
        def __init__(
            self,
            *,
            channel_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            dataset_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            dataset_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_index_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_index_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            pipeline_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            pipeline_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            reprocessing_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            retention_period: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RetentionPeriod1", typing.Dict[builtins.str, typing.Any]]] = None,
            version_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElements.

            :param channel_arn: (experimental) channelArn property. Specify an array of string values to match this event if the actual value of channelArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param channel_name: (experimental) channelName property. Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param dataset_arn: (experimental) datasetArn property. Specify an array of string values to match this event if the actual value of datasetArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param dataset_name: (experimental) datasetName property. Specify an array of string values to match this event if the actual value of datasetName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_arn: (experimental) datastoreArn property. Specify an array of string values to match this event if the actual value of datastoreArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_index_arn: (experimental) datastoreIndexArn property. Specify an array of string values to match this event if the actual value of datastoreIndexArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_index_name: (experimental) datastoreIndexName property. Specify an array of string values to match this event if the actual value of datastoreIndexName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_arn: (experimental) pipelineArn property. Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_name: (experimental) pipelineName property. Specify an array of string values to match this event if the actual value of pipelineName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reprocessing_id: (experimental) reprocessingId property. Specify an array of string values to match this event if the actual value of reprocessingId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param retention_period: (experimental) retentionPeriod property. Specify an array of string values to match this event if the actual value of retentionPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version_id: (experimental) versionId property. Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                response_elements = iotanalytics_events.AWSAPICallViaCloudTrail.ResponseElements(
                    channel_arn=["channelArn"],
                    channel_name=["channelName"],
                    dataset_arn=["datasetArn"],
                    dataset_name=["datasetName"],
                    datastore_arn=["datastoreArn"],
                    datastore_index_arn=["datastoreIndexArn"],
                    datastore_index_name=["datastoreIndexName"],
                    datastore_name=["datastoreName"],
                    pipeline_arn=["pipelineArn"],
                    pipeline_name=["pipelineName"],
                    reprocessing_id=["reprocessingId"],
                    retention_period=iotanalytics_events.AWSAPICallViaCloudTrail.RetentionPeriod1(
                        number_of_days=["numberOfDays"],
                        unlimited=["unlimited"]
                    ),
                    version_id=["versionId"]
                )
            '''
            if isinstance(retention_period, dict):
                retention_period = AWSAPICallViaCloudTrail.RetentionPeriod1(**retention_period)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dc9ccf8d8c53850347c3ec5d82326a14d264448bfcadea4a27e768296d069a05)
                check_type(argname="argument channel_arn", value=channel_arn, expected_type=type_hints["channel_arn"])
                check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
                check_type(argname="argument dataset_arn", value=dataset_arn, expected_type=type_hints["dataset_arn"])
                check_type(argname="argument dataset_name", value=dataset_name, expected_type=type_hints["dataset_name"])
                check_type(argname="argument datastore_arn", value=datastore_arn, expected_type=type_hints["datastore_arn"])
                check_type(argname="argument datastore_index_arn", value=datastore_index_arn, expected_type=type_hints["datastore_index_arn"])
                check_type(argname="argument datastore_index_name", value=datastore_index_name, expected_type=type_hints["datastore_index_name"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument pipeline_arn", value=pipeline_arn, expected_type=type_hints["pipeline_arn"])
                check_type(argname="argument pipeline_name", value=pipeline_name, expected_type=type_hints["pipeline_name"])
                check_type(argname="argument reprocessing_id", value=reprocessing_id, expected_type=type_hints["reprocessing_id"])
                check_type(argname="argument retention_period", value=retention_period, expected_type=type_hints["retention_period"])
                check_type(argname="argument version_id", value=version_id, expected_type=type_hints["version_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if channel_arn is not None:
                self._values["channel_arn"] = channel_arn
            if channel_name is not None:
                self._values["channel_name"] = channel_name
            if dataset_arn is not None:
                self._values["dataset_arn"] = dataset_arn
            if dataset_name is not None:
                self._values["dataset_name"] = dataset_name
            if datastore_arn is not None:
                self._values["datastore_arn"] = datastore_arn
            if datastore_index_arn is not None:
                self._values["datastore_index_arn"] = datastore_index_arn
            if datastore_index_name is not None:
                self._values["datastore_index_name"] = datastore_index_name
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if pipeline_arn is not None:
                self._values["pipeline_arn"] = pipeline_arn
            if pipeline_name is not None:
                self._values["pipeline_name"] = pipeline_name
            if reprocessing_id is not None:
                self._values["reprocessing_id"] = reprocessing_id
            if retention_period is not None:
                self._values["retention_period"] = retention_period
            if version_id is not None:
                self._values["version_id"] = version_id

        @builtins.property
        def channel_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) channelArn property.

            Specify an array of string values to match this event if the actual value of channelArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def channel_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) channelName property.

            Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def dataset_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datasetArn property.

            Specify an array of string values to match this event if the actual value of datasetArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dataset_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def dataset_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datasetName property.

            Specify an array of string values to match this event if the actual value of datasetName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dataset_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreArn property.

            Specify an array of string values to match this event if the actual value of datastoreArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_index_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreIndexArn property.

            Specify an array of string values to match this event if the actual value of datastoreIndexArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_index_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_index_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreIndexName property.

            Specify an array of string values to match this event if the actual value of datastoreIndexName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_index_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pipeline_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineArn property.

            Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pipeline_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineName property.

            Specify an array of string values to match this event if the actual value of pipelineName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reprocessing_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reprocessingId property.

            Specify an array of string values to match this event if the actual value of reprocessingId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reprocessing_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def retention_period(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RetentionPeriod1"]:
            '''(experimental) retentionPeriod property.

            Specify an array of string values to match this event if the actual value of retentionPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("retention_period")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RetentionPeriod1"], result)

        @builtins.property
        def version_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) versionId property.

            Specify an array of string values to match this event if the actual value of versionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElements(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.RetentionPeriod",
        jsii_struct_bases=[],
        name_mapping={"number_of_days": "numberOfDays", "unlimited": "unlimited"},
    )
    class RetentionPeriod:
        def __init__(
            self,
            *,
            number_of_days: typing.Optional[typing.Sequence[builtins.str]] = None,
            unlimited: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RetentionPeriod.

            :param number_of_days: (experimental) numberOfDays property. Specify an array of string values to match this event if the actual value of numberOfDays is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unlimited: (experimental) unlimited property. Specify an array of string values to match this event if the actual value of unlimited is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                retention_period = iotanalytics_events.AWSAPICallViaCloudTrail.RetentionPeriod(
                    number_of_days=["numberOfDays"],
                    unlimited=["unlimited"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__bbdf4b3d24a847e228aed3d6ce9701ee552070fb77ac08eb955d451c3bb57528)
                check_type(argname="argument number_of_days", value=number_of_days, expected_type=type_hints["number_of_days"])
                check_type(argname="argument unlimited", value=unlimited, expected_type=type_hints["unlimited"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if number_of_days is not None:
                self._values["number_of_days"] = number_of_days
            if unlimited is not None:
                self._values["unlimited"] = unlimited

        @builtins.property
        def number_of_days(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) numberOfDays property.

            Specify an array of string values to match this event if the actual value of numberOfDays is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("number_of_days")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unlimited(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unlimited property.

            Specify an array of string values to match this event if the actual value of unlimited is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unlimited")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RetentionPeriod(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.RetentionPeriod1",
        jsii_struct_bases=[],
        name_mapping={"number_of_days": "numberOfDays", "unlimited": "unlimited"},
    )
    class RetentionPeriod1:
        def __init__(
            self,
            *,
            number_of_days: typing.Optional[typing.Sequence[builtins.str]] = None,
            unlimited: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RetentionPeriod_1.

            :param number_of_days: (experimental) numberOfDays property. Specify an array of string values to match this event if the actual value of numberOfDays is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unlimited: (experimental) unlimited property. Specify an array of string values to match this event if the actual value of unlimited is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                retention_period1 = iotanalytics_events.AWSAPICallViaCloudTrail.RetentionPeriod1(
                    number_of_days=["numberOfDays"],
                    unlimited=["unlimited"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4be4e21cdf464f7d59228b061a0e1bacae7cd281a6679aa7dd7928ccac860bac)
                check_type(argname="argument number_of_days", value=number_of_days, expected_type=type_hints["number_of_days"])
                check_type(argname="argument unlimited", value=unlimited, expected_type=type_hints["unlimited"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if number_of_days is not None:
                self._values["number_of_days"] = number_of_days
            if unlimited is not None:
                self._values["unlimited"] = unlimited

        @builtins.property
        def number_of_days(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) numberOfDays property.

            Specify an array of string values to match this event if the actual value of numberOfDays is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("number_of_days")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unlimited(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unlimited property.

            Specify an array of string values to match this event if the actual value of unlimited is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unlimited")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RetentionPeriod1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.SessionContext",
        jsii_struct_bases=[],
        name_mapping={
            "attributes": "attributes",
            "session_issuer": "sessionIssuer",
            "web_id_federation_data": "webIdFederationData",
        },
    )
    class SessionContext:
        def __init__(
            self,
            *,
            attributes: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            session_issuer: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionIssuer", typing.Dict[builtins.str, typing.Any]]] = None,
            web_id_federation_data: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.WebIdFederationData", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionContext.

            :param attributes: (experimental) attributes property. Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_issuer: (experimental) sessionIssuer property. Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param web_id_federation_data: (experimental) webIdFederationData property. Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                session_context = iotanalytics_events.AWSAPICallViaCloudTrail.SessionContext(
                    attributes=iotanalytics_events.AWSAPICallViaCloudTrail.Attributes(
                        creation_date=["creationDate"],
                        mfa_authenticated=["mfaAuthenticated"]
                    ),
                    session_issuer=iotanalytics_events.AWSAPICallViaCloudTrail.SessionIssuer(
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        type=["type"],
                        user_name=["userName"]
                    ),
                    web_id_federation_data=iotanalytics_events.AWSAPICallViaCloudTrail.WebIdFederationData(
                        attributes={
                            "attributes_key": "attributes"
                        },
                        federated_provider=["federatedProvider"]
                    )
                )
            '''
            if isinstance(attributes, dict):
                attributes = AWSAPICallViaCloudTrail.Attributes(**attributes)
            if isinstance(session_issuer, dict):
                session_issuer = AWSAPICallViaCloudTrail.SessionIssuer(**session_issuer)
            if isinstance(web_id_federation_data, dict):
                web_id_federation_data = AWSAPICallViaCloudTrail.WebIdFederationData(**web_id_federation_data)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c4b95a1247c0f09c27afc764f6c5e2bb83f63c1bef46a6b725ea80351d9b5bac)
                check_type(argname="argument attributes", value=attributes, expected_type=type_hints["attributes"])
                check_type(argname="argument session_issuer", value=session_issuer, expected_type=type_hints["session_issuer"])
                check_type(argname="argument web_id_federation_data", value=web_id_federation_data, expected_type=type_hints["web_id_federation_data"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attributes is not None:
                self._values["attributes"] = attributes
            if session_issuer is not None:
                self._values["session_issuer"] = session_issuer
            if web_id_federation_data is not None:
                self._values["web_id_federation_data"] = web_id_federation_data

        @builtins.property
        def attributes(self) -> typing.Optional["AWSAPICallViaCloudTrail.Attributes"]:
            '''(experimental) attributes property.

            Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attributes")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Attributes"], result)

        @builtins.property
        def session_issuer(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"]:
            '''(experimental) sessionIssuer property.

            Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_issuer")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"], result)

        @builtins.property
        def web_id_federation_data(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.WebIdFederationData"]:
            '''(experimental) webIdFederationData property.

            Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("web_id_federation_data")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.WebIdFederationData"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionContext(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.SessionIssuer",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "type": "type",
            "user_name": "userName",
        },
    )
    class SessionIssuer:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionIssuer.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_name: (experimental) userName property. Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                session_issuer = iotanalytics_events.AWSAPICallViaCloudTrail.SessionIssuer(
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    type=["type"],
                    user_name=["userName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__88cc758029540caf4276eda0640ef5de81b1352503e0167f5811dbcc1990c588)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument user_name", value=user_name, expected_type=type_hints["user_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if type is not None:
                self._values["type"] = type
            if user_name is not None:
                self._values["user_name"] = user_name

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userName property.

            Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionIssuer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.Settings",
        jsii_struct_bases=[],
        name_mapping={"timeseries": "timeseries"},
    )
    class Settings:
        def __init__(
            self,
            *,
            timeseries: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Timeseries", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Settings.

            :param timeseries: (experimental) timeseries property. Specify an array of string values to match this event if the actual value of timeseries is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                settings = iotanalytics_events.AWSAPICallViaCloudTrail.Settings(
                    timeseries=iotanalytics_events.AWSAPICallViaCloudTrail.Timeseries(
                        dimension_attributes=[iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                            attribute=["attribute"],
                            name=["name"]
                        )],
                        measure_attributes=[iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                            attribute=["attribute"],
                            name=["name"]
                        )],
                        timestamp_attribute=["timestampAttribute"]
                    )
                )
            '''
            if isinstance(timeseries, dict):
                timeseries = AWSAPICallViaCloudTrail.Timeseries(**timeseries)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2a2fa26f81cfa599dd371cc9f65c8c0beaaa012586a3a0cf5154fc395da0dc66)
                check_type(argname="argument timeseries", value=timeseries, expected_type=type_hints["timeseries"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if timeseries is not None:
                self._values["timeseries"] = timeseries

        @builtins.property
        def timeseries(self) -> typing.Optional["AWSAPICallViaCloudTrail.Timeseries"]:
            '''(experimental) timeseries property.

            Specify an array of string values to match this event if the actual value of timeseries is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("timeseries")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Timeseries"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Settings(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.Timeseries",
        jsii_struct_bases=[],
        name_mapping={
            "dimension_attributes": "dimensionAttributes",
            "measure_attributes": "measureAttributes",
            "timestamp_attribute": "timestampAttribute",
        },
    )
    class Timeseries:
        def __init__(
            self,
            *,
            dimension_attributes: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.TimeseriesItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            measure_attributes: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.TimeseriesItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            timestamp_attribute: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Timeseries.

            :param dimension_attributes: (experimental) dimensionAttributes property. Specify an array of string values to match this event if the actual value of dimensionAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param measure_attributes: (experimental) measureAttributes property. Specify an array of string values to match this event if the actual value of measureAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param timestamp_attribute: (experimental) timestampAttribute property. Specify an array of string values to match this event if the actual value of timestampAttribute is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                timeseries = iotanalytics_events.AWSAPICallViaCloudTrail.Timeseries(
                    dimension_attributes=[iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                        attribute=["attribute"],
                        name=["name"]
                    )],
                    measure_attributes=[iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                        attribute=["attribute"],
                        name=["name"]
                    )],
                    timestamp_attribute=["timestampAttribute"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ceee1abe6877f380568a6c4010775b991cc2e60f60801b4951899c0a3195c59b)
                check_type(argname="argument dimension_attributes", value=dimension_attributes, expected_type=type_hints["dimension_attributes"])
                check_type(argname="argument measure_attributes", value=measure_attributes, expected_type=type_hints["measure_attributes"])
                check_type(argname="argument timestamp_attribute", value=timestamp_attribute, expected_type=type_hints["timestamp_attribute"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if dimension_attributes is not None:
                self._values["dimension_attributes"] = dimension_attributes
            if measure_attributes is not None:
                self._values["measure_attributes"] = measure_attributes
            if timestamp_attribute is not None:
                self._values["timestamp_attribute"] = timestamp_attribute

        @builtins.property
        def dimension_attributes(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.TimeseriesItem"]]:
            '''(experimental) dimensionAttributes property.

            Specify an array of string values to match this event if the actual value of dimensionAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimension_attributes")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.TimeseriesItem"]], result)

        @builtins.property
        def measure_attributes(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.TimeseriesItem"]]:
            '''(experimental) measureAttributes property.

            Specify an array of string values to match this event if the actual value of measureAttributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("measure_attributes")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.TimeseriesItem"]], result)

        @builtins.property
        def timestamp_attribute(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) timestampAttribute property.

            Specify an array of string values to match this event if the actual value of timestampAttribute is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("timestamp_attribute")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Timeseries(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.TimeseriesItem",
        jsii_struct_bases=[],
        name_mapping={"attribute": "attribute", "name": "name"},
    )
    class TimeseriesItem:
        def __init__(
            self,
            *,
            attribute: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TimeseriesItem.

            :param attribute: (experimental) attribute property. Specify an array of string values to match this event if the actual value of attribute is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                timeseries_item = iotanalytics_events.AWSAPICallViaCloudTrail.TimeseriesItem(
                    attribute=["attribute"],
                    name=["name"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__aaea6a3abbe42b0db427f37f239a9ece4e2cdacec010dedff98457a74e621b72)
                check_type(argname="argument attribute", value=attribute, expected_type=type_hints["attribute"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attribute is not None:
                self._values["attribute"] = attribute
            if name is not None:
                self._values["name"] = name

        @builtins.property
        def attribute(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) attribute property.

            Specify an array of string values to match this event if the actual value of attribute is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attribute")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TimeseriesItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={
            "access_key_id": "accessKeyId",
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "session_context": "sessionContext",
            "type": "type",
        },
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_context: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionContext", typing.Dict[builtins.str, typing.Any]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param access_key_id: (experimental) accessKeyId property. Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_context: (experimental) sessionContext property. Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                user_identity = iotanalytics_events.AWSAPICallViaCloudTrail.UserIdentity(
                    access_key_id=["accessKeyId"],
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    session_context=iotanalytics_events.AWSAPICallViaCloudTrail.SessionContext(
                        attributes=iotanalytics_events.AWSAPICallViaCloudTrail.Attributes(
                            creation_date=["creationDate"],
                            mfa_authenticated=["mfaAuthenticated"]
                        ),
                        session_issuer=iotanalytics_events.AWSAPICallViaCloudTrail.SessionIssuer(
                            account_id=["accountId"],
                            arn=["arn"],
                            principal_id=["principalId"],
                            type=["type"],
                            user_name=["userName"]
                        ),
                        web_id_federation_data=iotanalytics_events.AWSAPICallViaCloudTrail.WebIdFederationData(
                            attributes={
                                "attributes_key": "attributes"
                            },
                            federated_provider=["federatedProvider"]
                        )
                    ),
                    type=["type"]
                )
            '''
            if isinstance(session_context, dict):
                session_context = AWSAPICallViaCloudTrail.SessionContext(**session_context)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__014f168b81dc8e76603a992d344596edbaff1de23d3b07b4ad7c3ac06716a605)
                check_type(argname="argument access_key_id", value=access_key_id, expected_type=type_hints["access_key_id"])
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument session_context", value=session_context, expected_type=type_hints["session_context"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if access_key_id is not None:
                self._values["access_key_id"] = access_key_id
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if session_context is not None:
                self._values["session_context"] = session_context
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def access_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accessKeyId property.

            Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("access_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_context(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionContext"]:
            '''(experimental) sessionContext property.

            Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_context")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionContext"], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.AWSAPICallViaCloudTrail.WebIdFederationData",
        jsii_struct_bases=[],
        name_mapping={
            "attributes": "attributes",
            "federated_provider": "federatedProvider",
        },
    )
    class WebIdFederationData:
        def __init__(
            self,
            *,
            attributes: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
            federated_provider: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for WebIdFederationData.

            :param attributes: (experimental) attributes property. Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param federated_provider: (experimental) federatedProvider property. Specify an array of string values to match this event if the actual value of federatedProvider is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                web_id_federation_data = iotanalytics_events.AWSAPICallViaCloudTrail.WebIdFederationData(
                    attributes={
                        "attributes_key": "attributes"
                    },
                    federated_provider=["federatedProvider"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__528ab197afc6852bd226b7e6470c8328823ace735e29111c69f643d43238c82a)
                check_type(argname="argument attributes", value=attributes, expected_type=type_hints["attributes"])
                check_type(argname="argument federated_provider", value=federated_provider, expected_type=type_hints["federated_provider"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attributes is not None:
                self._values["attributes"] = attributes
            if federated_provider is not None:
                self._values["federated_provider"] = federated_provider

        @builtins.property
        def attributes(
            self,
        ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) attributes property.

            Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attributes")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        @builtins.property
        def federated_provider(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) federatedProvider property.

            Specify an array of string values to match this event if the actual value of federatedProvider is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("federated_provider")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "WebIdFederationData(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DatasetEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.DatasetEvents",
):
    '''(experimental) EventBridge event patterns for Dataset.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
        from aws_cdk.interfaces import aws_iotanalytics as interfaces_iotanalytics
        
        # dataset_ref: interfaces_iotanalytics.IDatasetRef
        
        dataset_events = iotanalytics_events.DatasetEvents.from_dataset(dataset_ref)
    '''

    @jsii.member(jsii_name="fromDataset")
    @builtins.classmethod
    def from_dataset(
        cls,
        dataset_ref: "_aws_cdk_interfaces_aws_iotanalytics_ceddda9d.IDatasetRef",
    ) -> "DatasetEvents":
        '''(experimental) Create DatasetEvents from a Dataset reference.

        :param dataset_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d0888a757557b64940c14f06424ba81603a9a1b6e2c2701ce4d4636ce0eeffee)
            check_type(argname="argument dataset_ref", value=dataset_ref, expected_type=type_hints["dataset_ref"])
        return typing.cast("DatasetEvents", jsii.sinvoke(cls, "fromDataset", [dataset_ref]))

    @jsii.member(jsii_name="ioTAnalyticsDataSetLifeCycleNotificationPattern")
    def io_t_analytics_data_set_life_cycle_notification_pattern(
        self,
        *,
        content_delivery_rule_index: typing.Optional[typing.Sequence[builtins.str]] = None,
        dataset_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_detail_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        version_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Dataset IoT Analytics DataSet Lifecycle Notification.

        :param content_delivery_rule_index: (experimental) content-delivery-rule-index property. Specify an array of string values to match this event if the actual value of content-delivery-rule-index is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param dataset_name: (experimental) dataset-name property. Specify an array of string values to match this event if the actual value of dataset-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Dataset reference
        :param event_detail_version: (experimental) event-detail-version property. Specify an array of string values to match this event if the actual value of event-detail-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version_id: (experimental) version-id property. Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = IoTAnalyticsDataSetLifeCycleNotification.IoTAnalyticsDataSetLifeCycleNotificationProps(
            content_delivery_rule_index=content_delivery_rule_index,
            dataset_name=dataset_name,
            event_detail_version=event_detail_version,
            event_metadata=event_metadata,
            message=message,
            state=state,
            version_id=version_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ioTAnalyticsDataSetLifeCycleNotificationPattern", [options]))


class IoTAnalyticsDataSetLifeCycleNotification(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.IoTAnalyticsDataSetLifeCycleNotification",
):
    '''(experimental) EventBridge event pattern for aws.iotanalytics@IoTAnalyticsDataSetLifeCycleNotification.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
        
        io_tAnalytics_data_set_life_cycle_notification = iotanalytics_events.IoTAnalyticsDataSetLifeCycleNotification()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="ioTAnalyticsDataSetLifeCycleNotificationPattern")
    @builtins.classmethod
    def io_t_analytics_data_set_life_cycle_notification_pattern(
        cls,
        *,
        content_delivery_rule_index: typing.Optional[typing.Sequence[builtins.str]] = None,
        dataset_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_detail_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        version_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for IoT Analytics DataSet Lifecycle Notification.

        :param content_delivery_rule_index: (experimental) content-delivery-rule-index property. Specify an array of string values to match this event if the actual value of content-delivery-rule-index is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param dataset_name: (experimental) dataset-name property. Specify an array of string values to match this event if the actual value of dataset-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Dataset reference
        :param event_detail_version: (experimental) event-detail-version property. Specify an array of string values to match this event if the actual value of event-detail-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version_id: (experimental) version-id property. Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = IoTAnalyticsDataSetLifeCycleNotification.IoTAnalyticsDataSetLifeCycleNotificationProps(
            content_delivery_rule_index=content_delivery_rule_index,
            dataset_name=dataset_name,
            event_detail_version=event_detail_version,
            event_metadata=event_metadata,
            message=message,
            state=state,
            version_id=version_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "ioTAnalyticsDataSetLifeCycleNotificationPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_iotanalytics.events.IoTAnalyticsDataSetLifeCycleNotification.IoTAnalyticsDataSetLifeCycleNotificationProps",
        jsii_struct_bases=[],
        name_mapping={
            "content_delivery_rule_index": "contentDeliveryRuleIndex",
            "dataset_name": "datasetName",
            "event_detail_version": "eventDetailVersion",
            "event_metadata": "eventMetadata",
            "message": "message",
            "state": "state",
            "version_id": "versionId",
        },
    )
    class IoTAnalyticsDataSetLifeCycleNotificationProps:
        def __init__(
            self,
            *,
            content_delivery_rule_index: typing.Optional[typing.Sequence[builtins.str]] = None,
            dataset_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_detail_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            version_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.iotanalytics@IoTAnalyticsDataSetLifeCycleNotification event.

            :param content_delivery_rule_index: (experimental) content-delivery-rule-index property. Specify an array of string values to match this event if the actual value of content-delivery-rule-index is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param dataset_name: (experimental) dataset-name property. Specify an array of string values to match this event if the actual value of dataset-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Dataset reference
            :param event_detail_version: (experimental) event-detail-version property. Specify an array of string values to match this event if the actual value of event-detail-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version_id: (experimental) version-id property. Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_iotanalytics import events as iotanalytics_events
                
                io_tAnalytics_data_set_life_cycle_notification_props = iotanalytics_events.IoTAnalyticsDataSetLifeCycleNotification.IoTAnalyticsDataSetLifeCycleNotificationProps(
                    content_delivery_rule_index=["contentDeliveryRuleIndex"],
                    dataset_name=["datasetName"],
                    event_detail_version=["eventDetailVersion"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    state=["state"],
                    version_id=["versionId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6899de8c4ea3b44cd6fe34decc220013a510d9a7037b672416befca7ad96cba6)
                check_type(argname="argument content_delivery_rule_index", value=content_delivery_rule_index, expected_type=type_hints["content_delivery_rule_index"])
                check_type(argname="argument dataset_name", value=dataset_name, expected_type=type_hints["dataset_name"])
                check_type(argname="argument event_detail_version", value=event_detail_version, expected_type=type_hints["event_detail_version"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument version_id", value=version_id, expected_type=type_hints["version_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if content_delivery_rule_index is not None:
                self._values["content_delivery_rule_index"] = content_delivery_rule_index
            if dataset_name is not None:
                self._values["dataset_name"] = dataset_name
            if event_detail_version is not None:
                self._values["event_detail_version"] = event_detail_version
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if state is not None:
                self._values["state"] = state
            if version_id is not None:
                self._values["version_id"] = version_id

        @builtins.property
        def content_delivery_rule_index(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) content-delivery-rule-index property.

            Specify an array of string values to match this event if the actual value of content-delivery-rule-index is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content_delivery_rule_index")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def dataset_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataset-name property.

            Specify an array of string values to match this event if the actual value of dataset-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Dataset reference

            :stability: experimental
            '''
            result = self._values.get("dataset_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_detail_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event-detail-version property.

            Specify an array of string values to match this event if the actual value of event-detail-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_detail_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version-id property.

            Specify an array of string values to match this event if the actual value of version-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "IoTAnalyticsDataSetLifeCycleNotificationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "AWSAPICallViaCloudTrail",
    "DatasetEvents",
    "IoTAnalyticsDataSetLifeCycleNotification",
]

publication.publish()

def _typecheckingstub__029abf1ccc22f3c1595cdf800cd4f4f0f9b89d21645079b9c36cc4516c783f3a(
    *,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RequestParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    response_elements: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResponseElements, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3bf903d3b439b48ab6a38403dc381fa98786a8756721efc16b905d44fdc7ebf6(
    *,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__173c0ca8f9025672b3f02e987ddfc6e91c37704e16a0007e2dd92c2cd06c6e06(
    *,
    customer_managed_s3: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.CustomerManagedS3, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5da4ccc83cceeaf3f18988858e689c9c785e8b725da8229f66051417f9f2f13(
    *,
    bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    key_prefix: typing.Optional[typing.Sequence[builtins.str]] = None,
    role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__200a4654105b10d6c5b31fb21f6ddeee14e3cb7fdf6e3c1b81b8343001ea432c(
    *,
    enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9ed03e61c12e61456b1129d4c4387eb4db28a6ca55f1c2ab524b38f2b437777a(
    *,
    attribute: typing.Optional[typing.Sequence[builtins.str]] = None,
    math: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fde0c63931e24964596fb6c78d03944a766bdd0c64cb43c99f8986646c24db6e(
    *,
    math: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.MathType, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3688d868b45627288ae8b9e4d3cd7088ba2b1766b873ba812dbbd0d0f49f00b7(
    *,
    sql_query: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77dd7badf37ac724649e522b4826b8d07cd75547a145702aa5068fc2b162b3ce(
    *,
    channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    channel_storage: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ChannelStorage, typing.Dict[builtins.str, typing.Any]]] = None,
    dataset_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_index_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_storage: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ChannelStorage, typing.Dict[builtins.str, typing.Any]]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    logging_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LoggingOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    max_messages: typing.Optional[typing.Sequence[builtins.str]] = None,
    payloads: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    pipeline_activity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.PipelineActivity, typing.Dict[builtins.str, typing.Any]]] = None,
    pipeline_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    query_action: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.QueryAction, typing.Dict[builtins.str, typing.Any]]] = None,
    reprocessing_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    retention_period: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RetentionPeriod, typing.Dict[builtins.str, typing.Any]]] = None,
    settings: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Settings, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem1, typing.Dict[builtins.str, typing.Any]]]] = None,
    version_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5eb8fb0a9bdbf4722dfa429603c0d6f2ba0ac6feb87ee873873b928909ff1111(
    *,
    address: typing.Optional[typing.Sequence[builtins.str]] = None,
    big_endian: typing.Optional[typing.Sequence[builtins.str]] = None,
    capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    hb: typing.Optional[typing.Sequence[jsii.Number]] = None,
    is_read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
    limit: typing.Optional[typing.Sequence[builtins.str]] = None,
    mark: typing.Optional[typing.Sequence[builtins.str]] = None,
    native_byte_order: typing.Optional[typing.Sequence[builtins.str]] = None,
    offset: typing.Optional[typing.Sequence[builtins.str]] = None,
    position: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__904a206f0d7a72ae076e72167ff1e7f83195473f5e990e8dab4c803ec3f532aa(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dc9ccf8d8c53850347c3ec5d82326a14d264448bfcadea4a27e768296d069a05(
    *,
    channel_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    dataset_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    dataset_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_index_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_index_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    pipeline_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    pipeline_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    reprocessing_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    retention_period: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RetentionPeriod1, typing.Dict[builtins.str, typing.Any]]] = None,
    version_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bbdf4b3d24a847e228aed3d6ce9701ee552070fb77ac08eb955d451c3bb57528(
    *,
    number_of_days: typing.Optional[typing.Sequence[builtins.str]] = None,
    unlimited: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4be4e21cdf464f7d59228b061a0e1bacae7cd281a6679aa7dd7928ccac860bac(
    *,
    number_of_days: typing.Optional[typing.Sequence[builtins.str]] = None,
    unlimited: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4b95a1247c0f09c27afc764f6c5e2bb83f63c1bef46a6b725ea80351d9b5bac(
    *,
    attributes: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    session_issuer: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionIssuer, typing.Dict[builtins.str, typing.Any]]] = None,
    web_id_federation_data: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.WebIdFederationData, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88cc758029540caf4276eda0640ef5de81b1352503e0167f5811dbcc1990c588(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a2fa26f81cfa599dd371cc9f65c8c0beaaa012586a3a0cf5154fc395da0dc66(
    *,
    timeseries: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Timeseries, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ceee1abe6877f380568a6c4010775b991cc2e60f60801b4951899c0a3195c59b(
    *,
    dimension_attributes: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.TimeseriesItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    measure_attributes: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.TimeseriesItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    timestamp_attribute: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aaea6a3abbe42b0db427f37f239a9ece4e2cdacec010dedff98457a74e621b72(
    *,
    attribute: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__014f168b81dc8e76603a992d344596edbaff1de23d3b07b4ad7c3ac06716a605(
    *,
    access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_context: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionContext, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__528ab197afc6852bd226b7e6470c8328823ace735e29111c69f643d43238c82a(
    *,
    attributes: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    federated_provider: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d0888a757557b64940c14f06424ba81603a9a1b6e2c2701ce4d4636ce0eeffee(
    dataset_ref: _aws_cdk_interfaces_aws_iotanalytics_ceddda9d.IDatasetRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6899de8c4ea3b44cd6fe34decc220013a510d9a7037b672416befca7ad96cba6(
    *,
    content_delivery_rule_index: typing.Optional[typing.Sequence[builtins.str]] = None,
    dataset_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_detail_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    version_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
