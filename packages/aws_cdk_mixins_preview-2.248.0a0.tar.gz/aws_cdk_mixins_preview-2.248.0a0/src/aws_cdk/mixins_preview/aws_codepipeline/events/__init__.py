from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class CodePipelineActionExecutionStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineActionExecutionStateChange",
):
    '''(experimental) EventBridge event pattern for aws.codepipeline@CodePipelineActionExecutionStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
        
        code_pipeline_action_execution_state_change = codepipeline_events.CodePipelineActionExecutionStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codePipelineActionExecutionStateChangePattern")
    @builtins.classmethod
    def code_pipeline_action_execution_state_change_pattern(
        cls,
        *,
        action: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        execution_result: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.ExecutionResult", typing.Dict[builtins.str, typing.Any]]] = None,
        input_artifacts: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.InputArtifacts", typing.Dict[builtins.str, typing.Any]]] = None,
        output_artifacts: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.OutputArtifacts", typing.Dict[builtins.str, typing.Any]]] = None,
        pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
        region: typing.Optional[typing.Sequence[builtins.str]] = None,
        stage: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        type: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.Type", typing.Dict[builtins.str, typing.Any]]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodePipeline Action Execution State Change.

        :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param execution_id: (experimental) execution-id property. Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param execution_result: (experimental) execution-result property. Specify an array of string values to match this event if the actual value of execution-result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_artifacts: (experimental) input-artifacts property. Specify an array of string values to match this event if the actual value of input-artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_artifacts: (experimental) output-artifacts property. Specify an array of string values to match this event if the actual value of output-artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline: (experimental) pipeline property. Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param stage: (experimental) stage property. Specify an array of string values to match this event if the actual value of stage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodePipelineActionExecutionStateChange.CodePipelineActionExecutionStateChangeProps(
            action=action,
            event_metadata=event_metadata,
            execution_id=execution_id,
            execution_result=execution_result,
            input_artifacts=input_artifacts,
            output_artifacts=output_artifacts,
            pipeline=pipeline,
            region=region,
            stage=stage,
            state=state,
            type=type,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codePipelineActionExecutionStateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineActionExecutionStateChange.CodePipelineActionExecutionStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "action": "action",
            "event_metadata": "eventMetadata",
            "execution_id": "executionId",
            "execution_result": "executionResult",
            "input_artifacts": "inputArtifacts",
            "output_artifacts": "outputArtifacts",
            "pipeline": "pipeline",
            "region": "region",
            "stage": "stage",
            "state": "state",
            "type": "type",
            "version": "version",
        },
    )
    class CodePipelineActionExecutionStateChangeProps:
        def __init__(
            self,
            *,
            action: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            execution_result: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.ExecutionResult", typing.Dict[builtins.str, typing.Any]]] = None,
            input_artifacts: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.InputArtifacts", typing.Dict[builtins.str, typing.Any]]] = None,
            output_artifacts: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.OutputArtifacts", typing.Dict[builtins.str, typing.Any]]] = None,
            pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
            region: typing.Optional[typing.Sequence[builtins.str]] = None,
            stage: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.Type", typing.Dict[builtins.str, typing.Any]]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codepipeline@CodePipelineActionExecutionStateChange event.

            :param action: (experimental) action property. Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param execution_id: (experimental) execution-id property. Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param execution_result: (experimental) execution-result property. Specify an array of string values to match this event if the actual value of execution-result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_artifacts: (experimental) input-artifacts property. Specify an array of string values to match this event if the actual value of input-artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_artifacts: (experimental) output-artifacts property. Specify an array of string values to match this event if the actual value of output-artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline: (experimental) pipeline property. Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stage: (experimental) stage property. Specify an array of string values to match this event if the actual value of stage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                code_pipeline_action_execution_state_change_props = codepipeline_events.CodePipelineActionExecutionStateChange.CodePipelineActionExecutionStateChangeProps(
                    action=["action"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    execution_id=["executionId"],
                    execution_result=codepipeline_events.CodePipelineActionExecutionStateChange.ExecutionResult(
                        external_execution_id=["externalExecutionId"],
                        external_execution_summary=["externalExecutionSummary"],
                        external_execution_url=["externalExecutionUrl"]
                    ),
                    input_artifacts=codepipeline_events.CodePipelineActionExecutionStateChange.InputArtifacts(
                        name=["name"],
                        s3_location=codepipeline_events.CodePipelineActionExecutionStateChange.S3Location(
                            bucket=["bucket"],
                            key=["key"]
                        )
                    ),
                    output_artifacts=codepipeline_events.CodePipelineActionExecutionStateChange.OutputArtifacts(
                        name=["name"],
                        s3_location=codepipeline_events.CodePipelineActionExecutionStateChange.S3Location(
                            bucket=["bucket"],
                            key=["key"]
                        )
                    ),
                    pipeline=["pipeline"],
                    region=["region"],
                    stage=["stage"],
                    state=["state"],
                    type=codepipeline_events.CodePipelineActionExecutionStateChange.Type(
                        category=["category"],
                        owner=["owner"],
                        provider=["provider"],
                        version=["version"]
                    ),
                    version=["version"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(execution_result, dict):
                execution_result = CodePipelineActionExecutionStateChange.ExecutionResult(**execution_result)
            if isinstance(input_artifacts, dict):
                input_artifacts = CodePipelineActionExecutionStateChange.InputArtifacts(**input_artifacts)
            if isinstance(output_artifacts, dict):
                output_artifacts = CodePipelineActionExecutionStateChange.OutputArtifacts(**output_artifacts)
            if isinstance(type, dict):
                type = CodePipelineActionExecutionStateChange.Type(**type)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__63a47d9200fc7bbdafdf6f6402437507c731e4498ad9c806e9306c097e44ad90)
                check_type(argname="argument action", value=action, expected_type=type_hints["action"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument execution_id", value=execution_id, expected_type=type_hints["execution_id"])
                check_type(argname="argument execution_result", value=execution_result, expected_type=type_hints["execution_result"])
                check_type(argname="argument input_artifacts", value=input_artifacts, expected_type=type_hints["input_artifacts"])
                check_type(argname="argument output_artifacts", value=output_artifacts, expected_type=type_hints["output_artifacts"])
                check_type(argname="argument pipeline", value=pipeline, expected_type=type_hints["pipeline"])
                check_type(argname="argument region", value=region, expected_type=type_hints["region"])
                check_type(argname="argument stage", value=stage, expected_type=type_hints["stage"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action is not None:
                self._values["action"] = action
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if execution_id is not None:
                self._values["execution_id"] = execution_id
            if execution_result is not None:
                self._values["execution_result"] = execution_result
            if input_artifacts is not None:
                self._values["input_artifacts"] = input_artifacts
            if output_artifacts is not None:
                self._values["output_artifacts"] = output_artifacts
            if pipeline is not None:
                self._values["pipeline"] = pipeline
            if region is not None:
                self._values["region"] = region
            if stage is not None:
                self._values["stage"] = stage
            if state is not None:
                self._values["state"] = state
            if type is not None:
                self._values["type"] = type
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) action property.

            Specify an array of string values to match this event if the actual value of action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def execution_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) execution-id property.

            Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def execution_result(
            self,
        ) -> typing.Optional["CodePipelineActionExecutionStateChange.ExecutionResult"]:
            '''(experimental) execution-result property.

            Specify an array of string values to match this event if the actual value of execution-result is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_result")
            return typing.cast(typing.Optional["CodePipelineActionExecutionStateChange.ExecutionResult"], result)

        @builtins.property
        def input_artifacts(
            self,
        ) -> typing.Optional["CodePipelineActionExecutionStateChange.InputArtifacts"]:
            '''(experimental) input-artifacts property.

            Specify an array of string values to match this event if the actual value of input-artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_artifacts")
            return typing.cast(typing.Optional["CodePipelineActionExecutionStateChange.InputArtifacts"], result)

        @builtins.property
        def output_artifacts(
            self,
        ) -> typing.Optional["CodePipelineActionExecutionStateChange.OutputArtifacts"]:
            '''(experimental) output-artifacts property.

            Specify an array of string values to match this event if the actual value of output-artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_artifacts")
            return typing.cast(typing.Optional["CodePipelineActionExecutionStateChange.OutputArtifacts"], result)

        @builtins.property
        def pipeline(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipeline property.

            Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) region property.

            Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stage(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stage property.

            Specify an array of string values to match this event if the actual value of stage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stage")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(
            self,
        ) -> typing.Optional["CodePipelineActionExecutionStateChange.Type"]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional["CodePipelineActionExecutionStateChange.Type"], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodePipelineActionExecutionStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineActionExecutionStateChange.ExecutionResult",
        jsii_struct_bases=[],
        name_mapping={
            "external_execution_id": "externalExecutionId",
            "external_execution_summary": "externalExecutionSummary",
            "external_execution_url": "externalExecutionUrl",
        },
    )
    class ExecutionResult:
        def __init__(
            self,
            *,
            external_execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            external_execution_summary: typing.Optional[typing.Sequence[builtins.str]] = None,
            external_execution_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ExecutionResult.

            :param external_execution_id: (experimental) external-execution-id property. Specify an array of string values to match this event if the actual value of external-execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param external_execution_summary: (experimental) external-execution-summary property. Specify an array of string values to match this event if the actual value of external-execution-summary is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param external_execution_url: (experimental) external-execution-url property. Specify an array of string values to match this event if the actual value of external-execution-url is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                execution_result = codepipeline_events.CodePipelineActionExecutionStateChange.ExecutionResult(
                    external_execution_id=["externalExecutionId"],
                    external_execution_summary=["externalExecutionSummary"],
                    external_execution_url=["externalExecutionUrl"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5629db34b1175e80fb252a410b16a245fdb7d3ad110f5dedd4b61f9431803b89)
                check_type(argname="argument external_execution_id", value=external_execution_id, expected_type=type_hints["external_execution_id"])
                check_type(argname="argument external_execution_summary", value=external_execution_summary, expected_type=type_hints["external_execution_summary"])
                check_type(argname="argument external_execution_url", value=external_execution_url, expected_type=type_hints["external_execution_url"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if external_execution_id is not None:
                self._values["external_execution_id"] = external_execution_id
            if external_execution_summary is not None:
                self._values["external_execution_summary"] = external_execution_summary
            if external_execution_url is not None:
                self._values["external_execution_url"] = external_execution_url

        @builtins.property
        def external_execution_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) external-execution-id property.

            Specify an array of string values to match this event if the actual value of external-execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("external_execution_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def external_execution_summary(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) external-execution-summary property.

            Specify an array of string values to match this event if the actual value of external-execution-summary is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("external_execution_summary")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def external_execution_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) external-execution-url property.

            Specify an array of string values to match this event if the actual value of external-execution-url is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("external_execution_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExecutionResult(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineActionExecutionStateChange.InputArtifacts",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "s3_location": "s3Location"},
    )
    class InputArtifacts:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_location: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.S3Location", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for InputArtifacts.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_location: (experimental) s3location property. Specify an array of string values to match this event if the actual value of s3location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                input_artifacts = codepipeline_events.CodePipelineActionExecutionStateChange.InputArtifacts(
                    name=["name"],
                    s3_location=codepipeline_events.CodePipelineActionExecutionStateChange.S3Location(
                        bucket=["bucket"],
                        key=["key"]
                    )
                )
            '''
            if isinstance(s3_location, dict):
                s3_location = CodePipelineActionExecutionStateChange.S3Location(**s3_location)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0bc046981d2a886f816b99c436a12b74a30a03fea539aa1043312fc039297ca0)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument s3_location", value=s3_location, expected_type=type_hints["s3_location"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if s3_location is not None:
                self._values["s3_location"] = s3_location

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_location(
            self,
        ) -> typing.Optional["CodePipelineActionExecutionStateChange.S3Location"]:
            '''(experimental) s3location property.

            Specify an array of string values to match this event if the actual value of s3location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_location")
            return typing.cast(typing.Optional["CodePipelineActionExecutionStateChange.S3Location"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputArtifacts(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineActionExecutionStateChange.OutputArtifacts",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "s3_location": "s3Location"},
    )
    class OutputArtifacts:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_location: typing.Optional[typing.Union["CodePipelineActionExecutionStateChange.S3Location", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputArtifacts.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_location: (experimental) s3location property. Specify an array of string values to match this event if the actual value of s3location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                output_artifacts = codepipeline_events.CodePipelineActionExecutionStateChange.OutputArtifacts(
                    name=["name"],
                    s3_location=codepipeline_events.CodePipelineActionExecutionStateChange.S3Location(
                        bucket=["bucket"],
                        key=["key"]
                    )
                )
            '''
            if isinstance(s3_location, dict):
                s3_location = CodePipelineActionExecutionStateChange.S3Location(**s3_location)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7fd392642dbbdc59481cd7cfe80becef7a6d30b4af7820dde975f25e46ee1dc5)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument s3_location", value=s3_location, expected_type=type_hints["s3_location"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if s3_location is not None:
                self._values["s3_location"] = s3_location

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_location(
            self,
        ) -> typing.Optional["CodePipelineActionExecutionStateChange.S3Location"]:
            '''(experimental) s3location property.

            Specify an array of string values to match this event if the actual value of s3location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_location")
            return typing.cast(typing.Optional["CodePipelineActionExecutionStateChange.S3Location"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputArtifacts(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineActionExecutionStateChange.S3Location",
        jsii_struct_bases=[],
        name_mapping={"bucket": "bucket", "key": "key"},
    )
    class S3Location:
        def __init__(
            self,
            *,
            bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for S3Location.

            :param bucket: (experimental) bucket property. Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param key: (experimental) key property. Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                s3_location = codepipeline_events.CodePipelineActionExecutionStateChange.S3Location(
                    bucket=["bucket"],
                    key=["key"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__64cc870e87d836c2a2e872502910c9173b6e92cc1172a8e734798197cd0b88e4)
                check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bucket is not None:
                self._values["bucket"] = bucket
            if key is not None:
                self._values["key"] = key

        @builtins.property
        def bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bucket property.

            Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) key property.

            Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "S3Location(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineActionExecutionStateChange.Type",
        jsii_struct_bases=[],
        name_mapping={
            "category": "category",
            "owner": "owner",
            "provider": "provider",
            "version": "version",
        },
    )
    class Type:
        def __init__(
            self,
            *,
            category: typing.Optional[typing.Sequence[builtins.str]] = None,
            owner: typing.Optional[typing.Sequence[builtins.str]] = None,
            provider: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Type.

            :param category: (experimental) category property. Specify an array of string values to match this event if the actual value of category is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param owner: (experimental) owner property. Specify an array of string values to match this event if the actual value of owner is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param provider: (experimental) provider property. Specify an array of string values to match this event if the actual value of provider is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                type = codepipeline_events.CodePipelineActionExecutionStateChange.Type(
                    category=["category"],
                    owner=["owner"],
                    provider=["provider"],
                    version=["version"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7f526bab9dd5cf0908948de27f8585cffb007e6a953786b50c6a8241cdf43224)
                check_type(argname="argument category", value=category, expected_type=type_hints["category"])
                check_type(argname="argument owner", value=owner, expected_type=type_hints["owner"])
                check_type(argname="argument provider", value=provider, expected_type=type_hints["provider"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if category is not None:
                self._values["category"] = category
            if owner is not None:
                self._values["owner"] = owner
            if provider is not None:
                self._values["provider"] = provider
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def category(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) category property.

            Specify an array of string values to match this event if the actual value of category is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("category")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def owner(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) owner property.

            Specify an array of string values to match this event if the actual value of owner is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("owner")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def provider(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) provider property.

            Specify an array of string values to match this event if the actual value of provider is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("provider")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Type(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodePipelinePipelineExecutionStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelinePipelineExecutionStateChange",
):
    '''(experimental) EventBridge event pattern for aws.codepipeline@CodePipelinePipelineExecutionStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
        
        code_pipeline_pipeline_execution_state_change = codepipeline_events.CodePipelinePipelineExecutionStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codePipelinePipelineExecutionStateChangePattern")
    @builtins.classmethod
    def code_pipeline_pipeline_execution_state_change_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        execution_trigger: typing.Optional[typing.Union["CodePipelinePipelineExecutionStateChange.ExecutionTrigger", typing.Dict[builtins.str, typing.Any]]] = None,
        pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodePipeline Pipeline Execution State Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param execution_id: (experimental) execution-id property. Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param execution_trigger: (experimental) execution-trigger property. Specify an array of string values to match this event if the actual value of execution-trigger is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline: (experimental) pipeline property. Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodePipelinePipelineExecutionStateChange.CodePipelinePipelineExecutionStateChangeProps(
            event_metadata=event_metadata,
            execution_id=execution_id,
            execution_trigger=execution_trigger,
            pipeline=pipeline,
            state=state,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codePipelinePipelineExecutionStateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelinePipelineExecutionStateChange.CodePipelinePipelineExecutionStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "execution_id": "executionId",
            "execution_trigger": "executionTrigger",
            "pipeline": "pipeline",
            "state": "state",
            "version": "version",
        },
    )
    class CodePipelinePipelineExecutionStateChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            execution_trigger: typing.Optional[typing.Union["CodePipelinePipelineExecutionStateChange.ExecutionTrigger", typing.Dict[builtins.str, typing.Any]]] = None,
            pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codepipeline@CodePipelinePipelineExecutionStateChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param execution_id: (experimental) execution-id property. Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param execution_trigger: (experimental) execution-trigger property. Specify an array of string values to match this event if the actual value of execution-trigger is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline: (experimental) pipeline property. Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                code_pipeline_pipeline_execution_state_change_props = codepipeline_events.CodePipelinePipelineExecutionStateChange.CodePipelinePipelineExecutionStateChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    execution_id=["executionId"],
                    execution_trigger=codepipeline_events.CodePipelinePipelineExecutionStateChange.ExecutionTrigger(
                        trigger_detail=["triggerDetail"],
                        trigger_type=["triggerType"]
                    ),
                    pipeline=["pipeline"],
                    state=["state"],
                    version=["version"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(execution_trigger, dict):
                execution_trigger = CodePipelinePipelineExecutionStateChange.ExecutionTrigger(**execution_trigger)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5d0a18e1204861c9d7f844193073cd9dc2e0922d24f3daf4f8927d73847a1fc0)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument execution_id", value=execution_id, expected_type=type_hints["execution_id"])
                check_type(argname="argument execution_trigger", value=execution_trigger, expected_type=type_hints["execution_trigger"])
                check_type(argname="argument pipeline", value=pipeline, expected_type=type_hints["pipeline"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if execution_id is not None:
                self._values["execution_id"] = execution_id
            if execution_trigger is not None:
                self._values["execution_trigger"] = execution_trigger
            if pipeline is not None:
                self._values["pipeline"] = pipeline
            if state is not None:
                self._values["state"] = state
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def execution_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) execution-id property.

            Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def execution_trigger(
            self,
        ) -> typing.Optional["CodePipelinePipelineExecutionStateChange.ExecutionTrigger"]:
            '''(experimental) execution-trigger property.

            Specify an array of string values to match this event if the actual value of execution-trigger is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_trigger")
            return typing.cast(typing.Optional["CodePipelinePipelineExecutionStateChange.ExecutionTrigger"], result)

        @builtins.property
        def pipeline(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipeline property.

            Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodePipelinePipelineExecutionStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelinePipelineExecutionStateChange.ExecutionTrigger",
        jsii_struct_bases=[],
        name_mapping={
            "trigger_detail": "triggerDetail",
            "trigger_type": "triggerType",
        },
    )
    class ExecutionTrigger:
        def __init__(
            self,
            *,
            trigger_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
            trigger_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for execution-trigger.

            :param trigger_detail: (experimental) trigger-detail property. Specify an array of string values to match this event if the actual value of trigger-detail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param trigger_type: (experimental) trigger-type property. Specify an array of string values to match this event if the actual value of trigger-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                execution_trigger = codepipeline_events.CodePipelinePipelineExecutionStateChange.ExecutionTrigger(
                    trigger_detail=["triggerDetail"],
                    trigger_type=["triggerType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2db51c031159697ace924e8988fd1cf2dec338a73fdf98bf428a988d56d3b46f)
                check_type(argname="argument trigger_detail", value=trigger_detail, expected_type=type_hints["trigger_detail"])
                check_type(argname="argument trigger_type", value=trigger_type, expected_type=type_hints["trigger_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if trigger_detail is not None:
                self._values["trigger_detail"] = trigger_detail
            if trigger_type is not None:
                self._values["trigger_type"] = trigger_type

        @builtins.property
        def trigger_detail(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trigger-detail property.

            Specify an array of string values to match this event if the actual value of trigger-detail is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("trigger_detail")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def trigger_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trigger-type property.

            Specify an array of string values to match this event if the actual value of trigger-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("trigger_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExecutionTrigger(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodePipelineStageExecutionStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineStageExecutionStateChange",
):
    '''(experimental) EventBridge event pattern for aws.codepipeline@CodePipelineStageExecutionStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
        
        code_pipeline_stage_execution_state_change = codepipeline_events.CodePipelineStageExecutionStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codePipelineStageExecutionStateChangePattern")
    @builtins.classmethod
    def code_pipeline_stage_execution_state_change_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
        stage: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodePipeline Stage Execution State Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param execution_id: (experimental) execution-id property. Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline: (experimental) pipeline property. Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param stage: (experimental) stage property. Specify an array of string values to match this event if the actual value of stage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodePipelineStageExecutionStateChange.CodePipelineStageExecutionStateChangeProps(
            event_metadata=event_metadata,
            execution_id=execution_id,
            pipeline=pipeline,
            stage=stage,
            state=state,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codePipelineStageExecutionStateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codepipeline.events.CodePipelineStageExecutionStateChange.CodePipelineStageExecutionStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "execution_id": "executionId",
            "pipeline": "pipeline",
            "stage": "stage",
            "state": "state",
            "version": "version",
        },
    )
    class CodePipelineStageExecutionStateChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
            stage: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codepipeline@CodePipelineStageExecutionStateChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param execution_id: (experimental) execution-id property. Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline: (experimental) pipeline property. Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stage: (experimental) stage property. Specify an array of string values to match this event if the actual value of stage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codepipeline import events as codepipeline_events
                
                code_pipeline_stage_execution_state_change_props = codepipeline_events.CodePipelineStageExecutionStateChange.CodePipelineStageExecutionStateChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    execution_id=["executionId"],
                    pipeline=["pipeline"],
                    stage=["stage"],
                    state=["state"],
                    version=["version"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__15de6563768bd5fa253f94727ad93d11d75985f8906dc9adf813e9fa05767553)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument execution_id", value=execution_id, expected_type=type_hints["execution_id"])
                check_type(argname="argument pipeline", value=pipeline, expected_type=type_hints["pipeline"])
                check_type(argname="argument stage", value=stage, expected_type=type_hints["stage"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if execution_id is not None:
                self._values["execution_id"] = execution_id
            if pipeline is not None:
                self._values["pipeline"] = pipeline
            if stage is not None:
                self._values["stage"] = stage
            if state is not None:
                self._values["state"] = state
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def execution_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) execution-id property.

            Specify an array of string values to match this event if the actual value of execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pipeline(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipeline property.

            Specify an array of string values to match this event if the actual value of pipeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stage(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stage property.

            Specify an array of string values to match this event if the actual value of stage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stage")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodePipelineStageExecutionStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "CodePipelineActionExecutionStateChange",
    "CodePipelinePipelineExecutionStateChange",
    "CodePipelineStageExecutionStateChange",
]

publication.publish()

def _typecheckingstub__63a47d9200fc7bbdafdf6f6402437507c731e4498ad9c806e9306c097e44ad90(
    *,
    action: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    execution_result: typing.Optional[typing.Union[CodePipelineActionExecutionStateChange.ExecutionResult, typing.Dict[builtins.str, typing.Any]]] = None,
    input_artifacts: typing.Optional[typing.Union[CodePipelineActionExecutionStateChange.InputArtifacts, typing.Dict[builtins.str, typing.Any]]] = None,
    output_artifacts: typing.Optional[typing.Union[CodePipelineActionExecutionStateChange.OutputArtifacts, typing.Dict[builtins.str, typing.Any]]] = None,
    pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
    region: typing.Optional[typing.Sequence[builtins.str]] = None,
    stage: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Union[CodePipelineActionExecutionStateChange.Type, typing.Dict[builtins.str, typing.Any]]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5629db34b1175e80fb252a410b16a245fdb7d3ad110f5dedd4b61f9431803b89(
    *,
    external_execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    external_execution_summary: typing.Optional[typing.Sequence[builtins.str]] = None,
    external_execution_url: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bc046981d2a886f816b99c436a12b74a30a03fea539aa1043312fc039297ca0(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_location: typing.Optional[typing.Union[CodePipelineActionExecutionStateChange.S3Location, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fd392642dbbdc59481cd7cfe80becef7a6d30b4af7820dde975f25e46ee1dc5(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_location: typing.Optional[typing.Union[CodePipelineActionExecutionStateChange.S3Location, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__64cc870e87d836c2a2e872502910c9173b6e92cc1172a8e734798197cd0b88e4(
    *,
    bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f526bab9dd5cf0908948de27f8585cffb007e6a953786b50c6a8241cdf43224(
    *,
    category: typing.Optional[typing.Sequence[builtins.str]] = None,
    owner: typing.Optional[typing.Sequence[builtins.str]] = None,
    provider: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d0a18e1204861c9d7f844193073cd9dc2e0922d24f3daf4f8927d73847a1fc0(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    execution_trigger: typing.Optional[typing.Union[CodePipelinePipelineExecutionStateChange.ExecutionTrigger, typing.Dict[builtins.str, typing.Any]]] = None,
    pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2db51c031159697ace924e8988fd1cf2dec338a73fdf98bf428a988d56d3b46f(
    *,
    trigger_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
    trigger_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__15de6563768bd5fa253f94727ad93d11d75985f8906dc9adf813e9fa05767553(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    pipeline: typing.Optional[typing.Sequence[builtins.str]] = None,
    stage: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
