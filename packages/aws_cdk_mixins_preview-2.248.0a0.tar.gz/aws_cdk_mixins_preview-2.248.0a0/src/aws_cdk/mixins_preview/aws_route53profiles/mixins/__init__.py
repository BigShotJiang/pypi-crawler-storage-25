from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnProfileLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileLogsMixin",
):
    '''A complex type that includes settings for a Route 53 Profile.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-route53profiles-profile.html
    :cloudformationResource: AWS::Route53Profiles::Profile
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_route53profiles import mixins as route53profiles_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_profile_logs_mixin = route53profiles_mixins.CfnProfileLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Route53Profiles::Profile``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f85181d7e9f84aa6f3856334bbc4684836d3e226c75b7605b0eaab3feaa37787)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a47588515d1bc86703051f4350aec37bd298ea4547a9319f91f20f84050648a)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__791636e870a87ec306331a892182966b175d952af62813b468d9137a3e64adef)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ROUTE53_PROFILES_RESOLVER_QUERY_LOGS")
    def ROUTE53_PROFILES_RESOLVER_QUERY_LOGS(
        cls,
    ) -> "CfnProfileRoute53ProfilesResolverQueryLogs":
        return typing.cast("CfnProfileRoute53ProfilesResolverQueryLogs", jsii.sget(cls, "ROUTE53_PROFILES_RESOLVER_QUERY_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnProfileRoute53ProfilesResolverQueryLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileRoute53ProfilesResolverQueryLogs",
):
    '''Builder for CfnProfileLogsMixin to generate ROUTE53_PROFILES_RESOLVER_QUERY_LOGS for CfnProfile.

    :cloudformationResource: AWS::Route53Profiles::Profile
    :logType: ROUTE53_PROFILES_RESOLVER_QUERY_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_route53profiles import mixins as route53profiles_mixins
        
        cfn_profile_route53_profiles_resolver_query_logs = route53profiles_mixins.CfnProfileRoute53ProfilesResolverQueryLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnProfileLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a9effd0413fb9ceb806da4ec8cadbf50d1456fa0c9c00926a12904df3830303)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnProfileLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose"] = None,
    ) -> "CfnProfileLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e00fea6026c57d5c8eda3a6e7e1d4184be699edb54d33f3f92858f583ad866e4)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps(
            output_format=output_format
        )

        return typing.cast("CfnProfileLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnProfileLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f3b94b0e513f38d406452f7411a3ca5d9850da3a6b35c34f9cf4e5c7f2e1c39)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps(
            output_format=output_format
        )

        return typing.cast("CfnProfileLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3"] = None,
    ) -> "CfnProfileLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a26c19fef6f607e63ef7307388d3fa218c26ff21bd91f06868c8b2173486634)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnProfileRoute53ProfilesResolverQueryLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnProfileLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_route53profiles import mixins as route53profiles_mixins
            
            cfn_profile_route53_profiles_resolver_query_logs_firehose_props = route53profiles_mixins.CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps(
                output_format=route53profiles_mixins.CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f1d0440e4b79534d0cbe8e321f874f67674530bed50288167beb5a419e2bd8e)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_route53profiles import mixins as route53profiles_mixins
            
            cfn_profile_route53_profiles_resolver_query_logs_log_group_props = route53profiles_mixins.CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps(
                output_format=route53profiles_mixins.CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a31080dc8dbc93e57f89ed17f4d70e9fe1f1967be8d527bac0b1df49b6d11e7)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnProfileRoute53ProfilesResolverQueryLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_route53profiles import mixins as route53profiles_mixins
        
        cfn_profile_route53_profiles_resolver_query_logs_output_format = route53profiles_mixins.CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_route53profiles.mixins.CfnProfileRoute53ProfilesResolverQueryLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnProfileRoute53ProfilesResolverQueryLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_route53profiles import mixins as route53profiles_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_profile_route53_profiles_resolver_query_logs_s3_props = route53profiles_mixins.CfnProfileRoute53ProfilesResolverQueryLogsS3Props(
                encryption_key=key_ref,
                output_format=route53profiles_mixins.CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a0b7da954d9b674b400a726ee17a065375755849bf0d88b31617a52c51a7656)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnProfileRoute53ProfilesResolverQueryLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnProfileLogsMixin",
    "CfnProfileRoute53ProfilesResolverQueryLogs",
    "CfnProfileRoute53ProfilesResolverQueryLogsFirehoseProps",
    "CfnProfileRoute53ProfilesResolverQueryLogsLogGroupProps",
    "CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat",
    "CfnProfileRoute53ProfilesResolverQueryLogsS3Props",
]

publication.publish()

def _typecheckingstub__f85181d7e9f84aa6f3856334bbc4684836d3e226c75b7605b0eaab3feaa37787(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a47588515d1bc86703051f4350aec37bd298ea4547a9319f91f20f84050648a(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__791636e870a87ec306331a892182966b175d952af62813b468d9137a3e64adef(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a9effd0413fb9ceb806da4ec8cadbf50d1456fa0c9c00926a12904df3830303(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e00fea6026c57d5c8eda3a6e7e1d4184be699edb54d33f3f92858f583ad866e4(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0f3b94b0e513f38d406452f7411a3ca5d9850da3a6b35c34f9cf4e5c7f2e1c39(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a26c19fef6f607e63ef7307388d3fa218c26ff21bd91f06868c8b2173486634(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f1d0440e4b79534d0cbe8e321f874f67674530bed50288167beb5a419e2bd8e(
    *,
    output_format: typing.Optional[CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a31080dc8dbc93e57f89ed17f4d70e9fe1f1967be8d527bac0b1df49b6d11e7(
    *,
    output_format: typing.Optional[CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a0b7da954d9b674b400a726ee17a065375755849bf0d88b31617a52c51a7656(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnProfileRoute53ProfilesResolverQueryLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass
