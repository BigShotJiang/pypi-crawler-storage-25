from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class CodeDeployDeploymentStateChangeNotification(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codedeploy.events.CodeDeployDeploymentStateChangeNotification",
):
    '''(experimental) EventBridge event pattern for aws.codedeploy@CodeDeployDeploymentStateChangeNotification.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codedeploy import events as codedeploy_events
        
        code_deploy_deployment_state_change_notification = codedeploy_events.CodeDeployDeploymentStateChangeNotification()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codeDeployDeploymentStateChangeNotificationPattern")
    @builtins.classmethod
    def code_deploy_deployment_state_change_notification_pattern(
        cls,
        *,
        application: typing.Optional[typing.Sequence[builtins.str]] = None,
        deployment_group: typing.Optional[typing.Sequence[builtins.str]] = None,
        deployment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        region: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeDeploy Deployment State-change Notification.

        :param application: (experimental) application property. Specify an array of string values to match this event if the actual value of application is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param deployment_group: (experimental) deploymentGroup property. Specify an array of string values to match this event if the actual value of deploymentGroup is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param deployment_id: (experimental) deploymentId property. Specify an array of string values to match this event if the actual value of deploymentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_group_id: (experimental) instanceGroupId property. Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeDeployDeploymentStateChangeNotification.CodeDeployDeploymentStateChangeNotificationProps(
            application=application,
            deployment_group=deployment_group,
            deployment_id=deployment_id,
            event_metadata=event_metadata,
            instance_group_id=instance_group_id,
            region=region,
            state=state,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codeDeployDeploymentStateChangeNotificationPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codedeploy.events.CodeDeployDeploymentStateChangeNotification.CodeDeployDeploymentStateChangeNotificationProps",
        jsii_struct_bases=[],
        name_mapping={
            "application": "application",
            "deployment_group": "deploymentGroup",
            "deployment_id": "deploymentId",
            "event_metadata": "eventMetadata",
            "instance_group_id": "instanceGroupId",
            "region": "region",
            "state": "state",
        },
    )
    class CodeDeployDeploymentStateChangeNotificationProps:
        def __init__(
            self,
            *,
            application: typing.Optional[typing.Sequence[builtins.str]] = None,
            deployment_group: typing.Optional[typing.Sequence[builtins.str]] = None,
            deployment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            region: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codedeploy@CodeDeployDeploymentStateChangeNotification event.

            :param application: (experimental) application property. Specify an array of string values to match this event if the actual value of application is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param deployment_group: (experimental) deploymentGroup property. Specify an array of string values to match this event if the actual value of deploymentGroup is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param deployment_id: (experimental) deploymentId property. Specify an array of string values to match this event if the actual value of deploymentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param instance_group_id: (experimental) instanceGroupId property. Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codedeploy import events as codedeploy_events
                
                code_deploy_deployment_state_change_notification_props = codedeploy_events.CodeDeployDeploymentStateChangeNotification.CodeDeployDeploymentStateChangeNotificationProps(
                    application=["application"],
                    deployment_group=["deploymentGroup"],
                    deployment_id=["deploymentId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    instance_group_id=["instanceGroupId"],
                    region=["region"],
                    state=["state"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6c4a80eb3ef70054a64403404fcd1fd2eb76889ba92ab046cee14263073dd7f8)
                check_type(argname="argument application", value=application, expected_type=type_hints["application"])
                check_type(argname="argument deployment_group", value=deployment_group, expected_type=type_hints["deployment_group"])
                check_type(argname="argument deployment_id", value=deployment_id, expected_type=type_hints["deployment_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument instance_group_id", value=instance_group_id, expected_type=type_hints["instance_group_id"])
                check_type(argname="argument region", value=region, expected_type=type_hints["region"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if application is not None:
                self._values["application"] = application
            if deployment_group is not None:
                self._values["deployment_group"] = deployment_group
            if deployment_id is not None:
                self._values["deployment_id"] = deployment_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if instance_group_id is not None:
                self._values["instance_group_id"] = instance_group_id
            if region is not None:
                self._values["region"] = region
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def application(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) application property.

            Specify an array of string values to match this event if the actual value of application is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("application")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def deployment_group(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deploymentGroup property.

            Specify an array of string values to match this event if the actual value of deploymentGroup is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deployment_group")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def deployment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deploymentId property.

            Specify an array of string values to match this event if the actual value of deploymentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deployment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def instance_group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceGroupId property.

            Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) region property.

            Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeDeployDeploymentStateChangeNotificationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodeDeployInstanceStateChangeNotification(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codedeploy.events.CodeDeployInstanceStateChangeNotification",
):
    '''(experimental) EventBridge event pattern for aws.codedeploy@CodeDeployInstanceStateChangeNotification.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codedeploy import events as codedeploy_events
        
        code_deploy_instance_state_change_notification = codedeploy_events.CodeDeployInstanceStateChangeNotification()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codeDeployInstanceStateChangeNotificationPattern")
    @builtins.classmethod
    def code_deploy_instance_state_change_notification_pattern(
        cls,
        *,
        application: typing.Optional[typing.Sequence[builtins.str]] = None,
        deployment_group: typing.Optional[typing.Sequence[builtins.str]] = None,
        deployment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        region: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeDeploy Instance State-change Notification.

        :param application: (experimental) application property. Specify an array of string values to match this event if the actual value of application is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param deployment_group: (experimental) deploymentGroup property. Specify an array of string values to match this event if the actual value of deploymentGroup is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param deployment_id: (experimental) deploymentId property. Specify an array of string values to match this event if the actual value of deploymentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_group_id: (experimental) instanceGroupId property. Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param instance_id: (experimental) instanceId property. Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeDeployInstanceStateChangeNotification.CodeDeployInstanceStateChangeNotificationProps(
            application=application,
            deployment_group=deployment_group,
            deployment_id=deployment_id,
            event_metadata=event_metadata,
            instance_group_id=instance_group_id,
            instance_id=instance_id,
            region=region,
            state=state,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codeDeployInstanceStateChangeNotificationPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codedeploy.events.CodeDeployInstanceStateChangeNotification.CodeDeployInstanceStateChangeNotificationProps",
        jsii_struct_bases=[],
        name_mapping={
            "application": "application",
            "deployment_group": "deploymentGroup",
            "deployment_id": "deploymentId",
            "event_metadata": "eventMetadata",
            "instance_group_id": "instanceGroupId",
            "instance_id": "instanceId",
            "region": "region",
            "state": "state",
        },
    )
    class CodeDeployInstanceStateChangeNotificationProps:
        def __init__(
            self,
            *,
            application: typing.Optional[typing.Sequence[builtins.str]] = None,
            deployment_group: typing.Optional[typing.Sequence[builtins.str]] = None,
            deployment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            region: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codedeploy@CodeDeployInstanceStateChangeNotification event.

            :param application: (experimental) application property. Specify an array of string values to match this event if the actual value of application is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param deployment_group: (experimental) deploymentGroup property. Specify an array of string values to match this event if the actual value of deploymentGroup is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param deployment_id: (experimental) deploymentId property. Specify an array of string values to match this event if the actual value of deploymentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param instance_group_id: (experimental) instanceGroupId property. Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_id: (experimental) instanceId property. Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codedeploy import events as codedeploy_events
                
                code_deploy_instance_state_change_notification_props = codedeploy_events.CodeDeployInstanceStateChangeNotification.CodeDeployInstanceStateChangeNotificationProps(
                    application=["application"],
                    deployment_group=["deploymentGroup"],
                    deployment_id=["deploymentId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    instance_group_id=["instanceGroupId"],
                    instance_id=["instanceId"],
                    region=["region"],
                    state=["state"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__58bb269783364300246d80d3a427b4a2b6af9d4556680a4a924a329361ddffea)
                check_type(argname="argument application", value=application, expected_type=type_hints["application"])
                check_type(argname="argument deployment_group", value=deployment_group, expected_type=type_hints["deployment_group"])
                check_type(argname="argument deployment_id", value=deployment_id, expected_type=type_hints["deployment_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument instance_group_id", value=instance_group_id, expected_type=type_hints["instance_group_id"])
                check_type(argname="argument instance_id", value=instance_id, expected_type=type_hints["instance_id"])
                check_type(argname="argument region", value=region, expected_type=type_hints["region"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if application is not None:
                self._values["application"] = application
            if deployment_group is not None:
                self._values["deployment_group"] = deployment_group
            if deployment_id is not None:
                self._values["deployment_id"] = deployment_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if instance_group_id is not None:
                self._values["instance_group_id"] = instance_group_id
            if instance_id is not None:
                self._values["instance_id"] = instance_id
            if region is not None:
                self._values["region"] = region
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def application(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) application property.

            Specify an array of string values to match this event if the actual value of application is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("application")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def deployment_group(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deploymentGroup property.

            Specify an array of string values to match this event if the actual value of deploymentGroup is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deployment_group")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def deployment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deploymentId property.

            Specify an array of string values to match this event if the actual value of deploymentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deployment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def instance_group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceGroupId property.

            Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceId property.

            Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) region property.

            Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeDeployInstanceStateChangeNotificationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "CodeDeployDeploymentStateChangeNotification",
    "CodeDeployInstanceStateChangeNotification",
]

publication.publish()

def _typecheckingstub__6c4a80eb3ef70054a64403404fcd1fd2eb76889ba92ab046cee14263073dd7f8(
    *,
    application: typing.Optional[typing.Sequence[builtins.str]] = None,
    deployment_group: typing.Optional[typing.Sequence[builtins.str]] = None,
    deployment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    region: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__58bb269783364300246d80d3a427b4a2b6af9d4556680a4a924a329361ddffea(
    *,
    application: typing.Optional[typing.Sequence[builtins.str]] = None,
    deployment_group: typing.Optional[typing.Sequence[builtins.str]] = None,
    deployment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    region: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
