from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnProtectionFlowLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogs",
):
    '''Builder for CfnProtectionLogsMixin to generate FLOW_LOGS for CfnProtection.

    :cloudformationResource: AWS::Shield::Protection
    :logType: FLOW_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_shield import mixins as shield_mixins
        
        cfn_protection_flow_logs = shield_mixins.CfnProtectionFlowLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnProtectionFlowLogsRecordFields"]] = None,
    ) -> "CfnProtectionLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4aa6152ce11150db9176c46958b947082c9f14e1875a72e6fb64ba486ce8c6c9)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnProtectionFlowLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnProtectionLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnProtectionFlowLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnProtectionFlowLogsRecordFields"]] = None,
    ) -> "CfnProtectionLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__136d81442ac67a5f9da1b9dbb70ea6c15f06a3291690f5f1186661e6f7b40a02)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnProtectionFlowLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnProtectionLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnProtectionFlowLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnProtectionFlowLogsRecordFields"]] = None,
    ) -> "CfnProtectionLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8935061f26d8f172c9c7f882d4f671ca602e5547150852b5d8f035af7623aa51)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnProtectionFlowLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnProtectionLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnProtectionFlowLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnProtectionFlowLogsRecordFields"]] = None,
    ) -> "CfnProtectionLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8d5c168144cbe18d17705006808147b8ca024b10dcdeb900d9be370afcc0ee58)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnProtectionFlowLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnProtectionLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnProtectionFlowLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnProtectionFlowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_shield import mixins as shield_mixins
            
            cfn_protection_flow_logs_dest_props = shield_mixins.CfnProtectionFlowLogsDestProps(
                record_fields=[shield_mixins.CfnProtectionFlowLogsRecordFields.SRCADDR]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c1a7cf82bbd4aa7d18efa2ee199f7b15e6c00adf8e1bf3a8670086197854be5)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnProtectionFlowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnProtectionFlowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnProtectionFlowLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnProtectionFlowLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnProtectionFlowLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnProtectionFlowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_shield import mixins as shield_mixins
            
            cfn_protection_flow_logs_firehose_props = shield_mixins.CfnProtectionFlowLogsFirehoseProps(
                output_format=shield_mixins.CfnProtectionFlowLogsOutputFormat.Firehose.JSON,
                record_fields=[shield_mixins.CfnProtectionFlowLogsRecordFields.SRCADDR]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6669e597f60ff3e94b7fe55406f86028bba447d6c280397fae46fd35fce13469)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnProtectionFlowLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnProtectionFlowLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnProtectionFlowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnProtectionFlowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnProtectionFlowLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnProtectionFlowLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnProtectionFlowLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnProtectionFlowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_shield import mixins as shield_mixins
            
            cfn_protection_flow_logs_log_group_props = shield_mixins.CfnProtectionFlowLogsLogGroupProps(
                output_format=shield_mixins.CfnProtectionFlowLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[shield_mixins.CfnProtectionFlowLogsRecordFields.SRCADDR]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a4a3460fb73e238b0acf5b0b17260f2456fc597f29731a492d1f2aebf499c0e)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnProtectionFlowLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnProtectionFlowLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnProtectionFlowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnProtectionFlowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnProtectionFlowLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnProtectionFlowLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnProtectionFlowLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_shield import mixins as shield_mixins
        
        cfn_protection_flow_logs_output_format = shield_mixins.CfnProtectionFlowLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsRecordFields"
)
class CfnProtectionFlowLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    SRCADDR = "SRCADDR"
    '''
    :stability: experimental
    '''
    DSTADDR = "DSTADDR"
    '''
    :stability: experimental
    '''
    SRCPORT = "SRCPORT"
    '''
    :stability: experimental
    '''
    DSTPORT = "DSTPORT"
    '''
    :stability: experimental
    '''
    PROTOCOL = "PROTOCOL"
    '''
    :stability: experimental
    '''
    PACKETS = "PACKETS"
    '''
    :stability: experimental
    '''
    BYTES = "BYTES"
    '''
    :stability: experimental
    '''
    STARTTIME = "STARTTIME"
    '''
    :stability: experimental
    '''
    ENDTIME = "ENDTIME"
    '''
    :stability: experimental
    '''
    ACTION = "ACTION"
    '''
    :stability: experimental
    '''
    LOCATION = "LOCATION"
    '''
    :stability: experimental
    '''
    SAMPLING_RATE = "SAMPLING_RATE"
    '''
    :stability: experimental
    '''
    TCP_FLAGS = "TCP_FLAGS"
    '''
    :stability: experimental
    '''
    SRCCOUNTRY = "SRCCOUNTRY"
    '''
    :stability: experimental
    '''
    PROTECTION_ARN = "PROTECTION_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    VERSION = "VERSION"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionFlowLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnProtectionFlowLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnProtectionFlowLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnProtectionFlowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_shield import mixins as shield_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_protection_flow_logs_s3_props = shield_mixins.CfnProtectionFlowLogsS3Props(
                encryption_key=key_ref,
                output_format=shield_mixins.CfnProtectionFlowLogsOutputFormat.S3.JSON,
                record_fields=[shield_mixins.CfnProtectionFlowLogsRecordFields.SRCADDR]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fa805e98bc77b5300a445c42006f74e5fe8f87435d3151157047e4885c400778)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnProtectionFlowLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnProtectionFlowLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnProtectionFlowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnProtectionFlowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnProtectionFlowLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnProtectionLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_shield.mixins.CfnProtectionLogsMixin",
):
    '''Enables AWS Shield Advanced for a specific AWS resource.

    The resource can be an Amazon CloudFront distribution, Amazon Route 53 hosted zone, AWS Global Accelerator standard accelerator, Elastic IP Address, Application Load Balancer, or a Classic Load Balancer. You can protect Amazon EC2 instances and Network Load Balancers by association with protected Amazon EC2 Elastic IP addresses.

    *Configure a single ``AWS::Shield::Protection``*

    Use this protection to protect a single resource at a time.

    To configure this Shield Advanced protection through CloudFormation , you must be subscribed to Shield Advanced . You can subscribe through the `Shield Advanced console <https://docs.aws.amazon.com/wafv2/shieldv2#/>`_ and through the APIs. For more information, see `Subscribe to AWS Shield Advanced <https://docs.aws.amazon.com/waf/latest/developerguide/enable-ddos-prem.html>`_ .

    See example templates for Shield Advanced in CloudFormation at `aws-samples/aws-shield-advanced-examples <https://docs.aws.amazon.com/https://github.com/aws-samples/aws-shield-advanced-examples>`_ .

    *Configure Shield Advanced using AWS CloudFormation and AWS Firewall Manager*

    You might be able to use Firewall Manager with AWS CloudFormation to configure Shield Advanced across multiple accounts and protected resources. To do this, your accounts must be part of an organization in AWS Organizations . You can use Firewall Manager to configure Shield Advanced protections for any resource types except for Amazon Route 53 or AWS Global Accelerator .

    For an example of this, see the one-click configuration guidance published by the AWS technical community at `One-click deployment of Shield Advanced <https://docs.aws.amazon.com/https://youtu.be/LCA3FwMk_QE>`_ .

    *Configure multiple protections through the Shield Advanced console*

    You can add protection to multiple resources at once through the `Shield Advanced console <https://docs.aws.amazon.com/wafv2/shieldv2#/>`_ . For more information see `Getting Started with AWS Shield Advanced <https://docs.aws.amazon.com/waf/latest/developerguide/getting-started-ddos.html>`_ and `Managing resource protections in AWS Shield Advanced <https://docs.aws.amazon.com/waf/latest/developerguide/ddos-manage-protected-resources.html>`_ .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-shield-protection.html
    :cloudformationResource: AWS::Shield::Protection
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_shield import mixins as shield_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_protection_logs_mixin = shield_mixins.CfnProtectionLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Shield::Protection``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f853b84145ee8ae6c4a7164de1f2bf22b1c31bb2fea688a920cca0830d1e9b3c)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4246c8bdb5fabd43df75a738f8e585355249981b359428bc5f06dee728b0bdc4)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__88dc6e48eacd43b668d6c430163bb776930601f7ab80a68e391058191e0b8a07)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="FLOW_LOGS")
    def FLOW_LOGS(cls) -> "CfnProtectionFlowLogs":
        return typing.cast("CfnProtectionFlowLogs", jsii.sget(cls, "FLOW_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnProtectionFlowLogs",
    "CfnProtectionFlowLogsDestProps",
    "CfnProtectionFlowLogsFirehoseProps",
    "CfnProtectionFlowLogsLogGroupProps",
    "CfnProtectionFlowLogsOutputFormat",
    "CfnProtectionFlowLogsRecordFields",
    "CfnProtectionFlowLogsS3Props",
    "CfnProtectionLogsMixin",
]

publication.publish()

def _typecheckingstub__4aa6152ce11150db9176c46958b947082c9f14e1875a72e6fb64ba486ce8c6c9(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnProtectionFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__136d81442ac67a5f9da1b9dbb70ea6c15f06a3291690f5f1186661e6f7b40a02(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnProtectionFlowLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnProtectionFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8935061f26d8f172c9c7f882d4f671ca602e5547150852b5d8f035af7623aa51(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnProtectionFlowLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnProtectionFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d5c168144cbe18d17705006808147b8ca024b10dcdeb900d9be370afcc0ee58(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnProtectionFlowLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnProtectionFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c1a7cf82bbd4aa7d18efa2ee199f7b15e6c00adf8e1bf3a8670086197854be5(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnProtectionFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6669e597f60ff3e94b7fe55406f86028bba447d6c280397fae46fd35fce13469(
    *,
    output_format: typing.Optional[CfnProtectionFlowLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnProtectionFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a4a3460fb73e238b0acf5b0b17260f2456fc597f29731a492d1f2aebf499c0e(
    *,
    output_format: typing.Optional[CfnProtectionFlowLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnProtectionFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa805e98bc77b5300a445c42006f74e5fe8f87435d3151157047e4885c400778(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnProtectionFlowLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnProtectionFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f853b84145ee8ae6c4a7164de1f2bf22b1c31bb2fea688a920cca0830d1e9b3c(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4246c8bdb5fabd43df75a738f8e585355249981b359428bc5f06dee728b0bdc4(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__88dc6e48eacd43b668d6c430163bb776930601f7ab80a68e391058191e0b8a07(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
