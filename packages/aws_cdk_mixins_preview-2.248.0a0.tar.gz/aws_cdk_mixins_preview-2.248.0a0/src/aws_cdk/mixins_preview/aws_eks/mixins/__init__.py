from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnCapabilityEksCapabilityAckLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogs",
):
    '''Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ACK_LOGS for CfnCapability.

    :cloudformationResource: AWS::EKS::Capability
    :logType: EKS_CAPABILITY_ACK_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_ack_logs = eks_mixins.CfnCapabilityEksCapabilityAckLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityAckLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__38bfd717666a4fccff12416656d06a5576eca30717947187d6aec4093ba0cc6f)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCapabilityEksCapabilityAckLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityAckLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1143072a70f2672ab7e41ab23279e0250092a9433a8638c92cb3412fe07e7b3)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCapabilityEksCapabilityAckLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityAckLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d22e078ecd595a5dfe940eda72aa52001e81f76a980710b1618107c7e4a71a83)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCapabilityEksCapabilityAckLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityAckLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e73f4efa53850b6b9db51f3b7a978d772232274e75f717ac902059e4405d646b)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCapabilityEksCapabilityAckLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityAckLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityAckLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_ack_logs_dest_props = eks_mixins.CfnCapabilityEksCapabilityAckLogsDestProps(
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityAckLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37e5804a86951206d688d52aa04e83664b54924e2b902f4c21d7221084dc573b)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityAckLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityAckLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityAckLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityAckLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityAckLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_ack_logs_firehose_props = eks_mixins.CfnCapabilityEksCapabilityAckLogsFirehoseProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityAckLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e8addd24ca3046a93944ba4b4ae8fcde73315515941a0f0b044e36e11e903aed)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityAckLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityAckLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityAckLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityAckLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityAckLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_ack_logs_log_group_props = eks_mixins.CfnCapabilityEksCapabilityAckLogsLogGroupProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityAckLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5272c7df9e161227e35ff989080e98e4db2b0374a2c8fb007760b6da50aa67e2)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityAckLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityAckLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityAckLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityAckLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCapabilityEksCapabilityAckLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_ack_logs_output_format = eks_mixins.CfnCapabilityEksCapabilityAckLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsRecordFields"
)
class CfnCapabilityEksCapabilityAckLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERR = "ERR"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    CONTROLLER = "CONTROLLER"
    '''
    :stability: experimental
    '''
    CONTROLLERGROUP = "CONTROLLERGROUP"
    '''
    :stability: experimental
    '''
    CONTROLLERKIND = "CONTROLLERKIND"
    '''
    :stability: experimental
    '''
    RECONCILEID = "RECONCILEID"
    '''
    :stability: experimental
    '''
    WORKER_COUNT = "WORKER_COUNT"
    '''
    :stability: experimental
    '''
    KIND = "KIND"
    '''
    :stability: experimental
    '''
    RECONCILER_KIND = "RECONCILER_KIND"
    '''
    :stability: experimental
    '''
    NAME = "NAME"
    '''
    :stability: experimental
    '''
    NAMESPACE = "NAMESPACE"
    '''
    :stability: experimental
    '''
    AWS_SERVICE = "AWS_SERVICE"
    '''
    :stability: experimental
    '''
    VERSION = "VERSION"
    '''
    :stability: experimental
    '''
    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityAckLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCapabilityEksCapabilityAckLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityAckLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_capability_eks_capability_ack_logs_s3_props = eks_mixins.CfnCapabilityEksCapabilityAckLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnCapabilityEksCapabilityAckLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityAckLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c681ef395e68d1228289eb2fafc1920767c82bd7ed25fd7e88a9c0aad50daa67)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityAckLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityAckLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityAckLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityAckLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogs",
):
    '''Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_APPLICATION_LOGS for CfnCapability.

    :cloudformationResource: AWS::EKS::Capability
    :logType: EKS_CAPABILITY_ARGOCD_APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_application_logs = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf11e4f615b3b323c41895efb393f88b88ca7712c9020895ef3f8d2d45396108)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6d33200fa273de57ba8483ccdd10a5f6425c2f264104c22038266bff6815d17a)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bfc78ec99f43701e41427f126a6d7588df1f5c77275260cf579b2f4ac2fbe980)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96e15466f15d9e7c9f64b9e41270887d64871303b8ee09b978aeb47631d551bb)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_application_logs_dest_props = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps(
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__419c93ea9253c4f8863a95d2e952c667909a92b0d07e19880a87c4edd89b873b)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_application_logs_firehose_props = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__59a5542ef6ef8abe76ba73e7dadb2936ef0ac255014bb683613f2b518b447e3a)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_application_logs_log_group_props = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__725a44495cc772d28c6c0b7086272a6c15a0a4b33a7eba4818562615b1dbfdf3)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCapabilityEksCapabilityArgocdApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_application_logs_output_format = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"
)
class CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    APPLICATION = "APPLICATION"
    '''
    :stability: experimental
    '''
    APP_NAMESPACE = "APP_NAMESPACE"
    '''
    :stability: experimental
    '''
    PROJECT = "PROJECT"
    '''
    :stability: experimental
    '''
    DEST_SERVER = "DEST_SERVER"
    '''
    :stability: experimental
    '''
    DEST_NAMESPACE = "DEST_NAMESPACE"
    '''
    :stability: experimental
    '''
    DEST_NAME = "DEST_NAME"
    '''
    :stability: experimental
    '''
    COMPARISON_LEVEL = "COMPARISON_LEVEL"
    '''
    :stability: experimental
    '''
    TIME_MS = "TIME_MS"
    '''
    :stability: experimental
    '''
    PATCH_MS = "PATCH_MS"
    '''
    :stability: experimental
    '''
    SETOP_MS = "SETOP_MS"
    '''
    :stability: experimental
    '''
    COMPARE_APP_STATE_MS = "COMPARE_APP_STATE_MS"
    '''
    :stability: experimental
    '''
    REFRESH_APP_CONDITIONS_MS = "REFRESH_APP_CONDITIONS_MS"
    '''
    :stability: experimental
    '''
    PROCESS_REFRESH_APP_CONDITIONS_ERRORS_MS = "PROCESS_REFRESH_APP_CONDITIONS_ERRORS_MS"
    '''
    :stability: experimental
    '''
    COMPARISON_WITH_NOTHING_MS = "COMPARISON_WITH_NOTHING_MS"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_capability_eks_capability_argocd_application_logs_s3_props = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6e0274b790f7d323ffb802bba5bb59ab0bad4103ad8d167bb507717acd23cd0e)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdApplicationsetLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogs",
):
    '''Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_APPLICATIONSET_LOGS for CfnCapability.

    :cloudformationResource: AWS::EKS::Capability
    :logType: EKS_CAPABILITY_ARGOCD_APPLICATIONSET_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_applicationset_logs = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba492f1a6b9ad8bb581df5c420a141d4d0411be28207fd1ad1d3ef7995fe4076)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCapabilityEksCapabilityArgocdApplicationsetLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1aafb6a02cadb94870ef71d77a6d6ce4e456f48d14d8cede2322a9614755e61a)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCapabilityEksCapabilityArgocdApplicationsetLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__73c44a556d8aedeb93cb60c8985aa0db6e0309889154a74159743f554ac93afc)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCapabilityEksCapabilityArgocdApplicationsetLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bb2078f0b202f1426c0a2a35b1957c85f205de5c1a91aed74290f4cfa8d4030)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdApplicationsetLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_applicationset_logs_dest_props = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsDestProps(
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e63cbed8c88055ed804f9b962915e78b026a9b20dfdadf7f1127c631f8a24bbd)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdApplicationsetLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdApplicationsetLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_applicationset_logs_firehose_props = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsFirehoseProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd0c37af65b9efd529617069154e033ae693a02eac1bb64867e54d54b2e44363)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdApplicationsetLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdApplicationsetLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_applicationset_logs_log_group_props = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsLogGroupProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__588b8d3db225416e9b6610073e7042e818bc98ac44c0d0de5ddc308e13024771)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdApplicationsetLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCapabilityEksCapabilityArgocdApplicationsetLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_applicationset_logs_output_format = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"
)
class CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    CONTROLLER = "CONTROLLER"
    '''
    :stability: experimental
    '''
    CONTROLLERGROUP = "CONTROLLERGROUP"
    '''
    :stability: experimental
    '''
    CONTROLLERKIND = "CONTROLLERKIND"
    '''
    :stability: experimental
    '''
    RECONCILEID = "RECONCILEID"
    '''
    :stability: experimental
    '''
    WORKER_COUNT = "WORKER_COUNT"
    '''
    :stability: experimental
    '''
    NAME = "NAME"
    '''
    :stability: experimental
    '''
    NAMESPACE = "NAMESPACE"
    '''
    :stability: experimental
    '''
    APPLICATION = "APPLICATION"
    '''
    :stability: experimental
    '''
    APP_NAMESPACE = "APP_NAMESPACE"
    '''
    :stability: experimental
    '''
    PROJECT = "PROJECT"
    '''
    :stability: experimental
    '''
    APPLICATIONSET = "APPLICATIONSET"
    '''
    :stability: experimental
    '''
    ACTION = "ACTION"
    '''
    :stability: experimental
    '''
    COUNT = "COUNT"
    '''
    :stability: experimental
    '''
    REQUEUEAFTER = "REQUEUEAFTER"
    '''
    :stability: experimental
    '''
    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_capability_eks_capability_argocd_applicationset_logs_s3_props = eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66b0746491c7defac8400fd28407c0f3e8fadafa4f94feaa5d94c707ddea79ac)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdCommitserverLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogs",
):
    '''Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_COMMITSERVER_LOGS for CfnCapability.

    :cloudformationResource: AWS::EKS::Capability
    :logType: EKS_CAPABILITY_ARGOCD_COMMITSERVER_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_commitserver_logs = eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf4a05a14e1816ee96b4bb8c86b284b2405e7744d06e973ff89273b352f8eb45)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCapabilityEksCapabilityArgocdCommitserverLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a3f2a3998fe4a8750712b940f09ed6e98065fd9b7ed34a9ca7d9c273629b651e)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCapabilityEksCapabilityArgocdCommitserverLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b37efa0f53ef304d467e5bbe57c0ecdf28c643f9df1bde1288f9ef88167ca889)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCapabilityEksCapabilityArgocdCommitserverLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__74d2387e6c295c66b025bd203b5fcdf90f6314d769666a58452a4b703d72c722)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdCommitserverLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_commitserver_logs_dest_props = eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsDestProps(
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7c14137c99eca171d8a3d74f4e7ead51248541d700e371908cf66800eb3d8de)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdCommitserverLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdCommitserverLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_commitserver_logs_firehose_props = eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsFirehoseProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40c87c6a80a88a38d1fa506e5dd3fe26a9e353afb3f2800208220c8092cad518)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdCommitserverLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdCommitserverLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_commitserver_logs_log_group_props = eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsLogGroupProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__135c011e20e22ba1fb3134fbc4b1545315f90febe2ca9741d79fa7bc461ba2e0)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdCommitserverLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCapabilityEksCapabilityArgocdCommitserverLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_commitserver_logs_output_format = eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"
)
class CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_capability_eks_capability_argocd_commitserver_logs_s3_props = eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5e72f4f351b455f0575f5e62d8119d8e0ce1b81cb570423747360e45ac9d9d13)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdReposerverLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogs",
):
    '''Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_REPOSERVER_LOGS for CfnCapability.

    :cloudformationResource: AWS::EKS::Capability
    :logType: EKS_CAPABILITY_ARGOCD_REPOSERVER_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_reposerver_logs = eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d7a477e863fe108e472d9816eda6e7d72a471e1074ef0d112d24d0fdb3c470bd)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCapabilityEksCapabilityArgocdReposerverLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de1f342ba19a8a5ba2f168c6f780da7067049919d6ec1f5520921dbb30bce74c)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCapabilityEksCapabilityArgocdReposerverLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c4fcbaa32be76c9980a4a4d9459786288e509271c166f389a5fcc98d9ff32dc8)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCapabilityEksCapabilityArgocdReposerverLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6daa3335cd9812bb5560b2d24a8dc4379b6b2bad2dceb58a70e5edbe2915a5ca)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdReposerverLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_reposerver_logs_dest_props = eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsDestProps(
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1d890895221389482b18bf33c4d17e5fd36ef8b989f3511b00648419f9b01e27)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdReposerverLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdReposerverLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_reposerver_logs_firehose_props = eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsFirehoseProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c8a809755cc2acdd6ca64bf9bb10f55d014e242fc4fadb7cbc96b711969c9c88)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdReposerverLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdReposerverLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_reposerver_logs_log_group_props = eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsLogGroupProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__acf07b7ede8c95263b658d4d73d2192a0382804613741127ff0bbbba4eb011ed)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdReposerverLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCapabilityEksCapabilityArgocdReposerverLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_reposerver_logs_output_format = eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"
)
class CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_capability_eks_capability_argocd_reposerver_logs_s3_props = eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75a0ed5dd7f5a1898b3285d9d58a382291306f9b7afa6d80dab12767bd6d2362)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdServerLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogs",
):
    '''Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_ARGOCD_SERVER_LOGS for CfnCapability.

    :cloudformationResource: AWS::EKS::Capability
    :logType: EKS_CAPABILITY_ARGOCD_SERVER_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_server_logs = eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bcc0a2c0ff0b2d4bcecf75298e5ea2af4f7792408e1dbb5d8137ee5c90df2bcc)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCapabilityEksCapabilityArgocdServerLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77a8e9998fec30fe39470f4d950c275923ef692ea3138797d453854b63cb5688)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCapabilityEksCapabilityArgocdServerLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__caf9b600df5acdcc8e04489cf151b89fd9ef4d42a41dca888f6b7a10807ea080)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCapabilityEksCapabilityArgocdServerLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f8a4c01e132dd73e55dc12d85f09583b176b7f8eefc990abd2be91dfa02a6411)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCapabilityEksCapabilityArgocdServerLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdServerLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_server_logs_dest_props = eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsDestProps(
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6e0e18a0ebc71cbe25585e605528439660c5dd103c83812e256fe1223a2ee6b8)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdServerLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdServerLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_server_logs_firehose_props = eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsFirehoseProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60f6a1fd3398978873230b1387b55f0c254edd636c9cd7ab60ae23f65291c122)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdServerLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityArgocdServerLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_argocd_server_logs_log_group_props = eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsLogGroupProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__661896458ca3f15671e28ff18c57df3ee28eebc6850edd537dc162584e70f80c)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdServerLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCapabilityEksCapabilityArgocdServerLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_argocd_server_logs_output_format = eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"
)
class CfnCapabilityEksCapabilityArgocdServerLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    NAME = "NAME"
    '''
    :stability: experimental
    '''
    NAMESPACE = "NAMESPACE"
    '''
    :stability: experimental
    '''
    REASON = "REASON"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityArgocdServerLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCapabilityEksCapabilityArgocdServerLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_capability_eks_capability_argocd_server_logs_s3_props = eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityArgocdServerLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f6c34d91131cfbd3a6c7eb7991b47d2a1a994f8e64eed8feb265673822cb1ac4)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityArgocdServerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityArgocdServerLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityKroLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogs",
):
    '''Builder for CfnCapabilityLogsMixin to generate EKS_CAPABILITY_KRO_LOGS for CfnCapability.

    :cloudformationResource: AWS::EKS::Capability
    :logType: EKS_CAPABILITY_KRO_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_kro_logs = eks_mixins.CfnCapabilityEksCapabilityKroLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityKroLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4007147a04f437838ca29f3a98076421a4e443b3cf7e0bafcfb47c91dfab6074)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCapabilityEksCapabilityKroLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityKroLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__78b746956dcc6dfe28de74b60e05e3d3ab88096231cc7ce63f4226406c83037f)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCapabilityEksCapabilityKroLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityKroLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56d7d44a6cdb878685ef987268c92496f5d873fab0d2db418be23e715fdf13db)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCapabilityEksCapabilityKroLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityKroLogsRecordFields"]] = None,
    ) -> "CfnCapabilityLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c55d6a1e781e9c4df11736fda3910e689d743bd80fe52030e11d7eef73bb9243)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCapabilityEksCapabilityKroLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCapabilityLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityKroLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityKroLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_kro_logs_dest_props = eks_mixins.CfnCapabilityEksCapabilityKroLogsDestProps(
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityKroLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53043729b8bfa7980ca15af0f32b21cb1aad03bf0f2b5d609d2c1f6624440212)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityKroLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityKroLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityKroLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityKroLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityKroLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_kro_logs_firehose_props = eks_mixins.CfnCapabilityEksCapabilityKroLogsFirehoseProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityKroLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4e5b6a570ab2e34003e337b1856b7b02d65ee78ca25c84804616077663ef1636)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityKroLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityKroLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityKroLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCapabilityEksCapabilityKroLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityKroLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_capability_eks_capability_kro_logs_log_group_props = eks_mixins.CfnCapabilityEksCapabilityKroLogsLogGroupProps(
                output_format=eks_mixins.CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityKroLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__790f9ad5fc527fefd8fe4b6438ee2fce60d8f9ff5a40419a98969d6901a96546)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityKroLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityKroLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityKroLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCapabilityEksCapabilityKroLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCapabilityEksCapabilityKroLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_capability_eks_capability_kro_logs_output_format = eks_mixins.CfnCapabilityEksCapabilityKroLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsRecordFields"
)
class CfnCapabilityEksCapabilityKroLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERR = "ERR"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    CONTROLLER = "CONTROLLER"
    '''
    :stability: experimental
    '''
    CONTROLLERGROUP = "CONTROLLERGROUP"
    '''
    :stability: experimental
    '''
    CONTROLLERKIND = "CONTROLLERKIND"
    '''
    :stability: experimental
    '''
    RECONCILEID = "RECONCILEID"
    '''
    :stability: experimental
    '''
    WORKER_COUNT = "WORKER_COUNT"
    '''
    :stability: experimental
    '''
    GVR = "GVR"
    '''
    :stability: experimental
    '''
    CRD = "CRD"
    '''
    :stability: experimental
    '''
    NAME = "NAME"
    '''
    :stability: experimental
    '''
    NAMESPACE = "NAMESPACE"
    '''
    :stability: experimental
    '''
    ITEM = "ITEM"
    '''
    :stability: experimental
    '''
    RESOURCEGRAPHDEFINITION = "RESOURCEGRAPHDEFINITION"
    '''
    :stability: experimental
    '''
    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityEksCapabilityKroLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCapabilityEksCapabilityKroLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCapabilityEksCapabilityKroLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_capability_eks_capability_kro_logs_s3_props = eks_mixins.CfnCapabilityEksCapabilityKroLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnCapabilityEksCapabilityKroLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnCapabilityEksCapabilityKroLogsRecordFields.STREAM]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__55a721ea6f2ac4f25309b5ebfd8fdf4d82510468e0f6c63f7e21200d8fdbc6e9)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCapabilityEksCapabilityKroLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCapabilityEksCapabilityKroLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCapabilityEksCapabilityKroLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCapabilityEksCapabilityKroLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnCapabilityLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnCapabilityLogsMixin",
):
    '''An object representing a managed capability in an Amazon EKS cluster.

    This includes all configuration, status, and health information for the capability.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eks-capability.html
    :cloudformationResource: AWS::EKS::Capability
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_capability_logs_mixin = eks_mixins.CfnCapabilityLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EKS::Capability``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__60b4de2b6ee17f5342b0eb5a70b3ed87655200b273956346c66f7388182944b8)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7825b13df649efa9bf436ad09c0d8e98a70590965e8451b710a9aac724b4d33)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2506be6733b57db4b285318a2bcfcfec62dfa37f5422e6faf0b38d8daafdc277)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EKS_CAPABILITY_ACK_LOGS")
    def EKS_CAPABILITY_ACK_LOGS(cls) -> "CfnCapabilityEksCapabilityAckLogs":
        return typing.cast("CfnCapabilityEksCapabilityAckLogs", jsii.sget(cls, "EKS_CAPABILITY_ACK_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EKS_CAPABILITY_ARGOCD_APPLICATION_LOGS")
    def EKS_CAPABILITY_ARGOCD_APPLICATION_LOGS(
        cls,
    ) -> "CfnCapabilityEksCapabilityArgocdApplicationLogs":
        return typing.cast("CfnCapabilityEksCapabilityArgocdApplicationLogs", jsii.sget(cls, "EKS_CAPABILITY_ARGOCD_APPLICATION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EKS_CAPABILITY_ARGOCD_APPLICATIONSET_LOGS")
    def EKS_CAPABILITY_ARGOCD_APPLICATIONSET_LOGS(
        cls,
    ) -> "CfnCapabilityEksCapabilityArgocdApplicationsetLogs":
        return typing.cast("CfnCapabilityEksCapabilityArgocdApplicationsetLogs", jsii.sget(cls, "EKS_CAPABILITY_ARGOCD_APPLICATIONSET_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EKS_CAPABILITY_ARGOCD_COMMITSERVER_LOGS")
    def EKS_CAPABILITY_ARGOCD_COMMITSERVER_LOGS(
        cls,
    ) -> "CfnCapabilityEksCapabilityArgocdCommitserverLogs":
        return typing.cast("CfnCapabilityEksCapabilityArgocdCommitserverLogs", jsii.sget(cls, "EKS_CAPABILITY_ARGOCD_COMMITSERVER_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EKS_CAPABILITY_ARGOCD_REPOSERVER_LOGS")
    def EKS_CAPABILITY_ARGOCD_REPOSERVER_LOGS(
        cls,
    ) -> "CfnCapabilityEksCapabilityArgocdReposerverLogs":
        return typing.cast("CfnCapabilityEksCapabilityArgocdReposerverLogs", jsii.sget(cls, "EKS_CAPABILITY_ARGOCD_REPOSERVER_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EKS_CAPABILITY_ARGOCD_SERVER_LOGS")
    def EKS_CAPABILITY_ARGOCD_SERVER_LOGS(
        cls,
    ) -> "CfnCapabilityEksCapabilityArgocdServerLogs":
        return typing.cast("CfnCapabilityEksCapabilityArgocdServerLogs", jsii.sget(cls, "EKS_CAPABILITY_ARGOCD_SERVER_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EKS_CAPABILITY_KRO_LOGS")
    def EKS_CAPABILITY_KRO_LOGS(cls) -> "CfnCapabilityEksCapabilityKroLogs":
        return typing.cast("CfnCapabilityEksCapabilityKroLogs", jsii.sget(cls, "EKS_CAPABILITY_KRO_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnClusterAutoModeBlockStorageLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogs",
):
    '''Builder for CfnClusterLogsMixin to generate AUTO_MODE_BLOCK_STORAGE_LOGS for CfnCluster.

    :cloudformationResource: AWS::EKS::Cluster
    :logType: AUTO_MODE_BLOCK_STORAGE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_cluster_auto_mode_block_storage_logs = eks_mixins.CfnClusterAutoModeBlockStorageLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeBlockStorageLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6fb5efab3b868008b6128f85fc9bf551420c3904860f7979bb8aa9e304e58ecc)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnClusterAutoModeBlockStorageLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeBlockStorageLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aecdb0debcd07a97068a632ba35400026d2754a7df3e68d4f5dbf7e5026bf749)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnClusterAutoModeBlockStorageLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeBlockStorageLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7eec0074381fcadfacfde7bedc383fc9f44c33c1c62397dc0fe13a58f455c973)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnClusterAutoModeBlockStorageLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeBlockStorageLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f7b12ae579e035fede9e9de8239ea591e7bc334c56c39ab067d49debd6201328)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnClusterAutoModeBlockStorageLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnClusterAutoModeBlockStorageLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeBlockStorageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_block_storage_logs_dest_props = eks_mixins.CfnClusterAutoModeBlockStorageLogsDestProps(
                record_fields=[eks_mixins.CfnClusterAutoModeBlockStorageLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c674158488db04ac4b460ceaac945f56f3014501195d32a6c7c373accf636d17)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeBlockStorageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeBlockStorageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeBlockStorageLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterAutoModeBlockStorageLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeBlockStorageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_block_storage_logs_firehose_props = eks_mixins.CfnClusterAutoModeBlockStorageLogsFirehoseProps(
                output_format=eks_mixins.CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnClusterAutoModeBlockStorageLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d954f5f4aa7b450112aae9d9bd5887a382e5fe2919d721b9a2d8fa2043f9d7ef)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeBlockStorageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeBlockStorageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeBlockStorageLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterAutoModeBlockStorageLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeBlockStorageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_block_storage_logs_log_group_props = eks_mixins.CfnClusterAutoModeBlockStorageLogsLogGroupProps(
                output_format=eks_mixins.CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnClusterAutoModeBlockStorageLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ea39ff9f6d39687e32e3da9d3d01bcd8985b8afad9df983361e6439406de752a)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeBlockStorageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeBlockStorageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeBlockStorageLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterAutoModeBlockStorageLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnClusterAutoModeBlockStorageLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_cluster_auto_mode_block_storage_logs_output_format = eks_mixins.CfnClusterAutoModeBlockStorageLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsRecordFields"
)
class CfnClusterAutoModeBlockStorageLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERR = "ERR"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    ENABLED = "ENABLED"
    '''
    :stability: experimental
    '''
    FEATURE = "FEATURE"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeBlockStorageLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnClusterAutoModeBlockStorageLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeBlockStorageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_cluster_auto_mode_block_storage_logs_s3_props = eks_mixins.CfnClusterAutoModeBlockStorageLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnClusterAutoModeBlockStorageLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnClusterAutoModeBlockStorageLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dd56f454673b1313da446b11c88c3f95ea51c0b8391a128452f0094a269c8138)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeBlockStorageLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeBlockStorageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeBlockStorageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeBlockStorageLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterAutoModeComputeLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogs",
):
    '''Builder for CfnClusterLogsMixin to generate AUTO_MODE_COMPUTE_LOGS for CfnCluster.

    :cloudformationResource: AWS::EKS::Cluster
    :logType: AUTO_MODE_COMPUTE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_cluster_auto_mode_compute_logs = eks_mixins.CfnClusterAutoModeComputeLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeComputeLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40311e752ce2c779461dfae80f729e970a19639ae76d2dc26c8299ab1e84ccf6)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnClusterAutoModeComputeLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeComputeLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37c9a24d16d5427cd3848a5af518bbfe333b1db6f812ff8443aa0d839079052c)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnClusterAutoModeComputeLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeComputeLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__50a288934057859cc20cf92adbfd789937358a18ea3ae4d73ed37310c176e55d)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnClusterAutoModeComputeLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeComputeLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6b2932241cd1a057c81bfc0a6c89beb78d5f9d1a99794d17dfb833e64113c843)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnClusterAutoModeComputeLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnClusterAutoModeComputeLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeComputeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_compute_logs_dest_props = eks_mixins.CfnClusterAutoModeComputeLogsDestProps(
                record_fields=[eks_mixins.CfnClusterAutoModeComputeLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__11569a62676eb2d6620662ad8003523d65abfb231bf9a043537b3d1bdd92f8d2)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeComputeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeComputeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeComputeLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterAutoModeComputeLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeComputeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_compute_logs_firehose_props = eks_mixins.CfnClusterAutoModeComputeLogsFirehoseProps(
                output_format=eks_mixins.CfnClusterAutoModeComputeLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnClusterAutoModeComputeLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33b3b84ea0551943017e35a73cfa3f544cd6ace246534990c4cd51a431d8ef54)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeComputeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeComputeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeComputeLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterAutoModeComputeLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeComputeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_compute_logs_log_group_props = eks_mixins.CfnClusterAutoModeComputeLogsLogGroupProps(
                output_format=eks_mixins.CfnClusterAutoModeComputeLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnClusterAutoModeComputeLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4b17f8a5e16def55cca8ed610068ec254236de9bbf252774acf8a101b58bff5a)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeComputeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeComputeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeComputeLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterAutoModeComputeLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnClusterAutoModeComputeLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_cluster_auto_mode_compute_logs_output_format = eks_mixins.CfnClusterAutoModeComputeLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsRecordFields"
)
class CfnClusterAutoModeComputeLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERR = "ERR"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    CONTROLLER = "CONTROLLER"
    '''
    :stability: experimental
    '''
    CONTROLLERGROUP = "CONTROLLERGROUP"
    '''
    :stability: experimental
    '''
    CONTROLLERKIND = "CONTROLLERKIND"
    '''
    :stability: experimental
    '''
    RECONCILEID = "RECONCILEID"
    '''
    :stability: experimental
    '''
    WORKER_COUNT = "WORKER_COUNT"
    '''
    :stability: experimental
    '''
    COUNT = "COUNT"
    '''
    :stability: experimental
    '''
    INSTANCE_TYPE_COUNT = "INSTANCE_TYPE_COUNT"
    '''
    :stability: experimental
    '''
    MODE = "MODE"
    '''
    :stability: experimental
    '''
    OFFERING_COUNT = "OFFERING_COUNT"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeComputeLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnClusterAutoModeComputeLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeComputeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_cluster_auto_mode_compute_logs_s3_props = eks_mixins.CfnClusterAutoModeComputeLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnClusterAutoModeComputeLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnClusterAutoModeComputeLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a20477bc98a415a0bad3fdd6b608d69d5f684d6768af5b0ee24a09f2547f2c09)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeComputeLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeComputeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeComputeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeComputeLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterAutoModeIpamLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogs",
):
    '''Builder for CfnClusterLogsMixin to generate AUTO_MODE_IPAM_LOGS for CfnCluster.

    :cloudformationResource: AWS::EKS::Cluster
    :logType: AUTO_MODE_IPAM_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_cluster_auto_mode_ipam_logs = eks_mixins.CfnClusterAutoModeIpamLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeIpamLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0e0d79a6cc6e9bf6c7c5d85bfddb081fb0a879814e9f7272d9345c96364e1c12)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnClusterAutoModeIpamLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeIpamLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0e40f6ce14578d4d7e545d2bec39260439f2d6ecb8bf8ee7074a22534594eed9)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnClusterAutoModeIpamLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeIpamLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b0582fdfef130b417ce8f731492aad637555f45cb40977a735a2c0a7279f1136)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnClusterAutoModeIpamLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeIpamLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9ff225116c19cb7efcfb1e90dae8557fa0ae2445d614dc75be2727537c5411ac)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnClusterAutoModeIpamLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnClusterAutoModeIpamLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeIpamLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_ipam_logs_dest_props = eks_mixins.CfnClusterAutoModeIpamLogsDestProps(
                record_fields=[eks_mixins.CfnClusterAutoModeIpamLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8b42743af82b9531da65de9d56024055f045f566822caf6cde9904efbd2e77cd)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeIpamLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeIpamLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeIpamLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterAutoModeIpamLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeIpamLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_ipam_logs_firehose_props = eks_mixins.CfnClusterAutoModeIpamLogsFirehoseProps(
                output_format=eks_mixins.CfnClusterAutoModeIpamLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnClusterAutoModeIpamLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1334f9899fe88d2a3c9b4edb5382a2c0502348c8f1f9ba42d8afb18c799aaca)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeIpamLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeIpamLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeIpamLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterAutoModeIpamLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeIpamLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_ipam_logs_log_group_props = eks_mixins.CfnClusterAutoModeIpamLogsLogGroupProps(
                output_format=eks_mixins.CfnClusterAutoModeIpamLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnClusterAutoModeIpamLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__26d106af17cef7ed5bf19f75db377b6c168d1138ce09a39ea0e8abef628d0c22)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeIpamLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeIpamLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeIpamLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterAutoModeIpamLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnClusterAutoModeIpamLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_cluster_auto_mode_ipam_logs_output_format = eks_mixins.CfnClusterAutoModeIpamLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsRecordFields"
)
class CfnClusterAutoModeIpamLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERR = "ERR"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    CONTROLLER = "CONTROLLER"
    '''
    :stability: experimental
    '''
    CONTROLLERGROUP = "CONTROLLERGROUP"
    '''
    :stability: experimental
    '''
    CONTROLLERKIND = "CONTROLLERKIND"
    '''
    :stability: experimental
    '''
    RECONCILEID = "RECONCILEID"
    '''
    :stability: experimental
    '''
    WORKER_COUNT = "WORKER_COUNT"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeIpamLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnClusterAutoModeIpamLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeIpamLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_cluster_auto_mode_ipam_logs_s3_props = eks_mixins.CfnClusterAutoModeIpamLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnClusterAutoModeIpamLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnClusterAutoModeIpamLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f0abf50069b8061b68b8aab0faea50243cb98025308c83a6a102a1b327ecc81)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeIpamLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeIpamLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeIpamLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeIpamLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterAutoModeLoadBalancingLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogs",
):
    '''Builder for CfnClusterLogsMixin to generate AUTO_MODE_LOAD_BALANCING_LOGS for CfnCluster.

    :cloudformationResource: AWS::EKS::Cluster
    :logType: AUTO_MODE_LOAD_BALANCING_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_cluster_auto_mode_load_balancing_logs = eks_mixins.CfnClusterAutoModeLoadBalancingLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeLoadBalancingLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__080fc0bbbd6995a7ed24db96ce6eafe24f948bc7e76894afda348f265a27dd8a)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnClusterAutoModeLoadBalancingLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeLoadBalancingLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5e52d3a745ee872d211b863a8daa91da493e51e2eaad811818bbfb2c30b4253b)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnClusterAutoModeLoadBalancingLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeLoadBalancingLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b0dc46ca63c84c4d09de0a9c422860eab9a1040b651d2e4487e42962b083426e)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnClusterAutoModeLoadBalancingLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeLoadBalancingLogsRecordFields"]] = None,
    ) -> "CfnClusterLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__287d15fdf0dcfd50d1b16077d3ba322ecd4ecc450fa176ee06aee2f13bb2d811)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnClusterAutoModeLoadBalancingLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnClusterLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnClusterAutoModeLoadBalancingLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeLoadBalancingLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_load_balancing_logs_dest_props = eks_mixins.CfnClusterAutoModeLoadBalancingLogsDestProps(
                record_fields=[eks_mixins.CfnClusterAutoModeLoadBalancingLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f89da5ad8999c7da94d4d51c888d5db4d4d1f9ffd65b3925fc55caa0fbf1e2d)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeLoadBalancingLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeLoadBalancingLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeLoadBalancingLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterAutoModeLoadBalancingLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeLoadBalancingLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_load_balancing_logs_firehose_props = eks_mixins.CfnClusterAutoModeLoadBalancingLogsFirehoseProps(
                output_format=eks_mixins.CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose.JSON,
                record_fields=[eks_mixins.CfnClusterAutoModeLoadBalancingLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a47b7f1399f8252514ced642b13f94fb44989f36867863b514da1d61885c79a)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeLoadBalancingLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeLoadBalancingLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeLoadBalancingLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnClusterAutoModeLoadBalancingLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeLoadBalancingLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            
            cfn_cluster_auto_mode_load_balancing_logs_log_group_props = eks_mixins.CfnClusterAutoModeLoadBalancingLogsLogGroupProps(
                output_format=eks_mixins.CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[eks_mixins.CfnClusterAutoModeLoadBalancingLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e6a321333caf1aa8805bb4fbae4a8c279e53069c8dba491fff697546f6c2836)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeLoadBalancingLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeLoadBalancingLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeLoadBalancingLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnClusterAutoModeLoadBalancingLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnClusterAutoModeLoadBalancingLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        cfn_cluster_auto_mode_load_balancing_logs_output_format = eks_mixins.CfnClusterAutoModeLoadBalancingLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsRecordFields"
)
class CfnClusterAutoModeLoadBalancingLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    STREAM = "STREAM"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    ERR = "ERR"
    '''
    :stability: experimental
    '''
    ERROR = "ERROR"
    '''
    :stability: experimental
    '''
    CONTROLLER = "CONTROLLER"
    '''
    :stability: experimental
    '''
    CONTROLLERGROUP = "CONTROLLERGROUP"
    '''
    :stability: experimental
    '''
    CONTROLLERKIND = "CONTROLLERKIND"
    '''
    :stability: experimental
    '''
    RECONCILEID = "RECONCILEID"
    '''
    :stability: experimental
    '''
    WORKER_COUNT = "WORKER_COUNT"
    '''
    :stability: experimental
    '''
    ATTEMPT = "ATTEMPT"
    '''
    :stability: experimental
    '''
    DELAY = "DELAY"
    '''
    :stability: experimental
    '''
    TOTALITEMS = "TOTALITEMS"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterAutoModeLoadBalancingLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnClusterAutoModeLoadBalancingLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnClusterAutoModeLoadBalancingLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_cluster_auto_mode_load_balancing_logs_s3_props = eks_mixins.CfnClusterAutoModeLoadBalancingLogsS3Props(
                encryption_key=key_ref,
                output_format=eks_mixins.CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3.JSON,
                record_fields=[eks_mixins.CfnClusterAutoModeLoadBalancingLogsRecordFields.LEVEL]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2b8b71934c22f6551636fdc21e5b588f7c7f9d688eaf8877c3b0eeb2ff69a02d)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnClusterAutoModeLoadBalancingLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnClusterAutoModeLoadBalancingLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnClusterAutoModeLoadBalancingLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnClusterLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_eks.mixins.CfnClusterLogsMixin",
):
    '''Creates an Amazon EKS control plane.

    The Amazon EKS control plane consists of control plane instances that run the Kubernetes software, such as ``etcd`` and the API server. The control plane runs in an account managed by AWS , and the Kubernetes API is exposed by the Amazon EKS API server endpoint. Each Amazon EKS cluster control plane is single tenant and unique. It runs on its own set of Amazon EC2 instances.

    The cluster control plane is provisioned across multiple Availability Zones and fronted by an ELB Network Load Balancer. Amazon EKS also provisions elastic network interfaces in your VPC subnets to provide connectivity from the control plane instances to the nodes (for example, to support ``kubectl exec`` , ``logs`` , and ``proxy`` data flows).

    Amazon EKS nodes run in your AWS account and connect to your cluster's control plane over the Kubernetes API server endpoint and a certificate file that is created for your cluster.

    You can use the ``endpointPublicAccess`` and ``endpointPrivateAccess`` parameters to enable or disable public and private access to your cluster's Kubernetes API server endpoint. By default, public access is enabled, and private access is disabled. The endpoint domain name and IP address family depends on the value of the ``ipFamily`` for the cluster. For more information, see `Amazon EKS Cluster Endpoint Access Control <https://docs.aws.amazon.com/eks/latest/userguide/cluster-endpoint.html>`_ in the **Amazon EKS User Guide** .

    You can use the ``logging`` parameter to enable or disable exporting the Kubernetes control plane logs for your cluster to CloudWatch Logs. By default, cluster control plane logs aren't exported to CloudWatch Logs. For more information, see `Amazon EKS Cluster Control Plane Logs <https://docs.aws.amazon.com/eks/latest/userguide/control-plane-logs.html>`_ in the **Amazon EKS User Guide** .
    .. epigraph::

       CloudWatch Logs ingestion, archive storage, and data scanning rates apply to exported control plane logs. For more information, see `CloudWatch Pricing <https://docs.aws.amazon.com/cloudwatch/pricing/>`_ .

    In most cases, it takes several minutes to create a cluster. After you create an Amazon EKS cluster, you must configure your Kubernetes tooling to communicate with the API server and launch nodes into your cluster. For more information, see `Allowing users to access your cluster <https://docs.aws.amazon.com/eks/latest/userguide/cluster-auth.html>`_ and `Launching Amazon EKS nodes <https://docs.aws.amazon.com/eks/latest/userguide/launch-workers.html>`_ in the *Amazon EKS User Guide* .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eks-cluster.html
    :cloudformationResource: AWS::EKS::Cluster
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_eks import mixins as eks_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_cluster_logs_mixin = eks_mixins.CfnClusterLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EKS::Cluster``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53d54377ef74f8513cd0d834d49d8ffcbe02caa072dfb89bea1d46f40f056f74)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9d51028fbb5aacfbaf51b7c7834ba4699ede78ce14522f0639499cedaa98a6df)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82dc79894f0f72f4ce665ae05d23fd826cf1ac150e1cf0dca53780d2bdbbe6f9)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="AUTO_MODE_BLOCK_STORAGE_LOGS")
    def AUTO_MODE_BLOCK_STORAGE_LOGS(cls) -> "CfnClusterAutoModeBlockStorageLogs":
        return typing.cast("CfnClusterAutoModeBlockStorageLogs", jsii.sget(cls, "AUTO_MODE_BLOCK_STORAGE_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="AUTO_MODE_COMPUTE_LOGS")
    def AUTO_MODE_COMPUTE_LOGS(cls) -> "CfnClusterAutoModeComputeLogs":
        return typing.cast("CfnClusterAutoModeComputeLogs", jsii.sget(cls, "AUTO_MODE_COMPUTE_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="AUTO_MODE_IPAM_LOGS")
    def AUTO_MODE_IPAM_LOGS(cls) -> "CfnClusterAutoModeIpamLogs":
        return typing.cast("CfnClusterAutoModeIpamLogs", jsii.sget(cls, "AUTO_MODE_IPAM_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="AUTO_MODE_LOAD_BALANCING_LOGS")
    def AUTO_MODE_LOAD_BALANCING_LOGS(cls) -> "CfnClusterAutoModeLoadBalancingLogs":
        return typing.cast("CfnClusterAutoModeLoadBalancingLogs", jsii.sget(cls, "AUTO_MODE_LOAD_BALANCING_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnCapabilityEksCapabilityAckLogs",
    "CfnCapabilityEksCapabilityAckLogsDestProps",
    "CfnCapabilityEksCapabilityAckLogsFirehoseProps",
    "CfnCapabilityEksCapabilityAckLogsLogGroupProps",
    "CfnCapabilityEksCapabilityAckLogsOutputFormat",
    "CfnCapabilityEksCapabilityAckLogsRecordFields",
    "CfnCapabilityEksCapabilityAckLogsS3Props",
    "CfnCapabilityEksCapabilityArgocdApplicationLogs",
    "CfnCapabilityEksCapabilityArgocdApplicationLogsDestProps",
    "CfnCapabilityEksCapabilityArgocdApplicationLogsFirehoseProps",
    "CfnCapabilityEksCapabilityArgocdApplicationLogsLogGroupProps",
    "CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat",
    "CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields",
    "CfnCapabilityEksCapabilityArgocdApplicationLogsS3Props",
    "CfnCapabilityEksCapabilityArgocdApplicationsetLogs",
    "CfnCapabilityEksCapabilityArgocdApplicationsetLogsDestProps",
    "CfnCapabilityEksCapabilityArgocdApplicationsetLogsFirehoseProps",
    "CfnCapabilityEksCapabilityArgocdApplicationsetLogsLogGroupProps",
    "CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat",
    "CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields",
    "CfnCapabilityEksCapabilityArgocdApplicationsetLogsS3Props",
    "CfnCapabilityEksCapabilityArgocdCommitserverLogs",
    "CfnCapabilityEksCapabilityArgocdCommitserverLogsDestProps",
    "CfnCapabilityEksCapabilityArgocdCommitserverLogsFirehoseProps",
    "CfnCapabilityEksCapabilityArgocdCommitserverLogsLogGroupProps",
    "CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat",
    "CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields",
    "CfnCapabilityEksCapabilityArgocdCommitserverLogsS3Props",
    "CfnCapabilityEksCapabilityArgocdReposerverLogs",
    "CfnCapabilityEksCapabilityArgocdReposerverLogsDestProps",
    "CfnCapabilityEksCapabilityArgocdReposerverLogsFirehoseProps",
    "CfnCapabilityEksCapabilityArgocdReposerverLogsLogGroupProps",
    "CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat",
    "CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields",
    "CfnCapabilityEksCapabilityArgocdReposerverLogsS3Props",
    "CfnCapabilityEksCapabilityArgocdServerLogs",
    "CfnCapabilityEksCapabilityArgocdServerLogsDestProps",
    "CfnCapabilityEksCapabilityArgocdServerLogsFirehoseProps",
    "CfnCapabilityEksCapabilityArgocdServerLogsLogGroupProps",
    "CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat",
    "CfnCapabilityEksCapabilityArgocdServerLogsRecordFields",
    "CfnCapabilityEksCapabilityArgocdServerLogsS3Props",
    "CfnCapabilityEksCapabilityKroLogs",
    "CfnCapabilityEksCapabilityKroLogsDestProps",
    "CfnCapabilityEksCapabilityKroLogsFirehoseProps",
    "CfnCapabilityEksCapabilityKroLogsLogGroupProps",
    "CfnCapabilityEksCapabilityKroLogsOutputFormat",
    "CfnCapabilityEksCapabilityKroLogsRecordFields",
    "CfnCapabilityEksCapabilityKroLogsS3Props",
    "CfnCapabilityLogsMixin",
    "CfnClusterAutoModeBlockStorageLogs",
    "CfnClusterAutoModeBlockStorageLogsDestProps",
    "CfnClusterAutoModeBlockStorageLogsFirehoseProps",
    "CfnClusterAutoModeBlockStorageLogsLogGroupProps",
    "CfnClusterAutoModeBlockStorageLogsOutputFormat",
    "CfnClusterAutoModeBlockStorageLogsRecordFields",
    "CfnClusterAutoModeBlockStorageLogsS3Props",
    "CfnClusterAutoModeComputeLogs",
    "CfnClusterAutoModeComputeLogsDestProps",
    "CfnClusterAutoModeComputeLogsFirehoseProps",
    "CfnClusterAutoModeComputeLogsLogGroupProps",
    "CfnClusterAutoModeComputeLogsOutputFormat",
    "CfnClusterAutoModeComputeLogsRecordFields",
    "CfnClusterAutoModeComputeLogsS3Props",
    "CfnClusterAutoModeIpamLogs",
    "CfnClusterAutoModeIpamLogsDestProps",
    "CfnClusterAutoModeIpamLogsFirehoseProps",
    "CfnClusterAutoModeIpamLogsLogGroupProps",
    "CfnClusterAutoModeIpamLogsOutputFormat",
    "CfnClusterAutoModeIpamLogsRecordFields",
    "CfnClusterAutoModeIpamLogsS3Props",
    "CfnClusterAutoModeLoadBalancingLogs",
    "CfnClusterAutoModeLoadBalancingLogsDestProps",
    "CfnClusterAutoModeLoadBalancingLogsFirehoseProps",
    "CfnClusterAutoModeLoadBalancingLogsLogGroupProps",
    "CfnClusterAutoModeLoadBalancingLogsOutputFormat",
    "CfnClusterAutoModeLoadBalancingLogsRecordFields",
    "CfnClusterAutoModeLoadBalancingLogsS3Props",
    "CfnClusterLogsMixin",
]

publication.publish()

def _typecheckingstub__38bfd717666a4fccff12416656d06a5576eca30717947187d6aec4093ba0cc6f(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityAckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1143072a70f2672ab7e41ab23279e0250092a9433a8638c92cb3412fe07e7b3(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityAckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d22e078ecd595a5dfe940eda72aa52001e81f76a980710b1618107c7e4a71a83(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityAckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e73f4efa53850b6b9db51f3b7a978d772232274e75f717ac902059e4405d646b(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityAckLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityAckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37e5804a86951206d688d52aa04e83664b54924e2b902f4c21d7221084dc573b(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityAckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e8addd24ca3046a93944ba4b4ae8fcde73315515941a0f0b044e36e11e903aed(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityAckLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityAckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5272c7df9e161227e35ff989080e98e4db2b0374a2c8fb007760b6da50aa67e2(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityAckLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityAckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c681ef395e68d1228289eb2fafc1920767c82bd7ed25fd7e88a9c0aad50daa67(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityAckLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityAckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf11e4f615b3b323c41895efb393f88b88ca7712c9020895ef3f8d2d45396108(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6d33200fa273de57ba8483ccdd10a5f6425c2f264104c22038266bff6815d17a(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bfc78ec99f43701e41427f126a6d7588df1f5c77275260cf579b2f4ac2fbe980(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96e15466f15d9e7c9f64b9e41270887d64871303b8ee09b978aeb47631d551bb(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__419c93ea9253c4f8863a95d2e952c667909a92b0d07e19880a87c4edd89b873b(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59a5542ef6ef8abe76ba73e7dadb2936ef0ac255014bb683613f2b518b447e3a(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__725a44495cc772d28c6c0b7086272a6c15a0a4b33a7eba4818562615b1dbfdf3(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6e0274b790f7d323ffb802bba5bb59ab0bad4103ad8d167bb507717acd23cd0e(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba492f1a6b9ad8bb581df5c420a141d4d0411be28207fd1ad1d3ef7995fe4076(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1aafb6a02cadb94870ef71d77a6d6ce4e456f48d14d8cede2322a9614755e61a(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__73c44a556d8aedeb93cb60c8985aa0db6e0309889154a74159743f554ac93afc(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bb2078f0b202f1426c0a2a35b1957c85f205de5c1a91aed74290f4cfa8d4030(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e63cbed8c88055ed804f9b962915e78b026a9b20dfdadf7f1127c631f8a24bbd(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd0c37af65b9efd529617069154e033ae693a02eac1bb64867e54d54b2e44363(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__588b8d3db225416e9b6610073e7042e818bc98ac44c0d0de5ddc308e13024771(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66b0746491c7defac8400fd28407c0f3e8fadafa4f94feaa5d94c707ddea79ac(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdApplicationsetLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdApplicationsetLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf4a05a14e1816ee96b4bb8c86b284b2405e7744d06e973ff89273b352f8eb45(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3f2a3998fe4a8750712b940f09ed6e98065fd9b7ed34a9ca7d9c273629b651e(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b37efa0f53ef304d467e5bbe57c0ecdf28c643f9df1bde1288f9ef88167ca889(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74d2387e6c295c66b025bd203b5fcdf90f6314d769666a58452a4b703d72c722(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7c14137c99eca171d8a3d74f4e7ead51248541d700e371908cf66800eb3d8de(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40c87c6a80a88a38d1fa506e5dd3fe26a9e353afb3f2800208220c8092cad518(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__135c011e20e22ba1fb3134fbc4b1545315f90febe2ca9741d79fa7bc461ba2e0(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5e72f4f351b455f0575f5e62d8119d8e0ce1b81cb570423747360e45ac9d9d13(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdCommitserverLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdCommitserverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7a477e863fe108e472d9816eda6e7d72a471e1074ef0d112d24d0fdb3c470bd(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de1f342ba19a8a5ba2f168c6f780da7067049919d6ec1f5520921dbb30bce74c(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4fcbaa32be76c9980a4a4d9459786288e509271c166f389a5fcc98d9ff32dc8(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6daa3335cd9812bb5560b2d24a8dc4379b6b2bad2dceb58a70e5edbe2915a5ca(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d890895221389482b18bf33c4d17e5fd36ef8b989f3511b00648419f9b01e27(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c8a809755cc2acdd6ca64bf9bb10f55d014e242fc4fadb7cbc96b711969c9c88(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__acf07b7ede8c95263b658d4d73d2192a0382804613741127ff0bbbba4eb011ed(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75a0ed5dd7f5a1898b3285d9d58a382291306f9b7afa6d80dab12767bd6d2362(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdReposerverLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdReposerverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bcc0a2c0ff0b2d4bcecf75298e5ea2af4f7792408e1dbb5d8137ee5c90df2bcc(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77a8e9998fec30fe39470f4d950c275923ef692ea3138797d453854b63cb5688(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__caf9b600df5acdcc8e04489cf151b89fd9ef4d42a41dca888f6b7a10807ea080(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f8a4c01e132dd73e55dc12d85f09583b176b7f8eefc990abd2be91dfa02a6411(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6e0e18a0ebc71cbe25585e605528439660c5dd103c83812e256fe1223a2ee6b8(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60f6a1fd3398978873230b1387b55f0c254edd636c9cd7ab60ae23f65291c122(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__661896458ca3f15671e28ff18c57df3ee28eebc6850edd537dc162584e70f80c(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6c34d91131cfbd3a6c7eb7991b47d2a1a994f8e64eed8feb265673822cb1ac4(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityArgocdServerLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityArgocdServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4007147a04f437838ca29f3a98076421a4e443b3cf7e0bafcfb47c91dfab6074(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityKroLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__78b746956dcc6dfe28de74b60e05e3d3ab88096231cc7ce63f4226406c83037f(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityKroLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56d7d44a6cdb878685ef987268c92496f5d873fab0d2db418be23e715fdf13db(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityKroLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c55d6a1e781e9c4df11736fda3910e689d743bd80fe52030e11d7eef73bb9243(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityKroLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityKroLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53043729b8bfa7980ca15af0f32b21cb1aad03bf0f2b5d609d2c1f6624440212(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityKroLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4e5b6a570ab2e34003e337b1856b7b02d65ee78ca25c84804616077663ef1636(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityKroLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityKroLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__790f9ad5fc527fefd8fe4b6438ee2fce60d8f9ff5a40419a98969d6901a96546(
    *,
    output_format: typing.Optional[CfnCapabilityEksCapabilityKroLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityKroLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55a721ea6f2ac4f25309b5ebfd8fdf4d82510468e0f6c63f7e21200d8fdbc6e9(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCapabilityEksCapabilityKroLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCapabilityEksCapabilityKroLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60b4de2b6ee17f5342b0eb5a70b3ed87655200b273956346c66f7388182944b8(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7825b13df649efa9bf436ad09c0d8e98a70590965e8451b710a9aac724b4d33(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2506be6733b57db4b285318a2bcfcfec62dfa37f5422e6faf0b38d8daafdc277(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6fb5efab3b868008b6128f85fc9bf551420c3904860f7979bb8aa9e304e58ecc(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeBlockStorageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aecdb0debcd07a97068a632ba35400026d2754a7df3e68d4f5dbf7e5026bf749(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeBlockStorageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7eec0074381fcadfacfde7bedc383fc9f44c33c1c62397dc0fe13a58f455c973(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeBlockStorageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7b12ae579e035fede9e9de8239ea591e7bc334c56c39ab067d49debd6201328(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterAutoModeBlockStorageLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeBlockStorageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c674158488db04ac4b460ceaac945f56f3014501195d32a6c7c373accf636d17(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeBlockStorageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d954f5f4aa7b450112aae9d9bd5887a382e5fe2919d721b9a2d8fa2043f9d7ef(
    *,
    output_format: typing.Optional[CfnClusterAutoModeBlockStorageLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeBlockStorageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ea39ff9f6d39687e32e3da9d3d01bcd8985b8afad9df983361e6439406de752a(
    *,
    output_format: typing.Optional[CfnClusterAutoModeBlockStorageLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeBlockStorageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd56f454673b1313da446b11c88c3f95ea51c0b8391a128452f0094a269c8138(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterAutoModeBlockStorageLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeBlockStorageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40311e752ce2c779461dfae80f729e970a19639ae76d2dc26c8299ab1e84ccf6(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeComputeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37c9a24d16d5427cd3848a5af518bbfe333b1db6f812ff8443aa0d839079052c(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnClusterAutoModeComputeLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeComputeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50a288934057859cc20cf92adbfd789937358a18ea3ae4d73ed37310c176e55d(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnClusterAutoModeComputeLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeComputeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b2932241cd1a057c81bfc0a6c89beb78d5f9d1a99794d17dfb833e64113c843(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterAutoModeComputeLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeComputeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__11569a62676eb2d6620662ad8003523d65abfb231bf9a043537b3d1bdd92f8d2(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeComputeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33b3b84ea0551943017e35a73cfa3f544cd6ace246534990c4cd51a431d8ef54(
    *,
    output_format: typing.Optional[CfnClusterAutoModeComputeLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeComputeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b17f8a5e16def55cca8ed610068ec254236de9bbf252774acf8a101b58bff5a(
    *,
    output_format: typing.Optional[CfnClusterAutoModeComputeLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeComputeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a20477bc98a415a0bad3fdd6b608d69d5f684d6768af5b0ee24a09f2547f2c09(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterAutoModeComputeLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeComputeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0e0d79a6cc6e9bf6c7c5d85bfddb081fb0a879814e9f7272d9345c96364e1c12(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeIpamLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0e40f6ce14578d4d7e545d2bec39260439f2d6ecb8bf8ee7074a22534594eed9(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnClusterAutoModeIpamLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeIpamLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b0582fdfef130b417ce8f731492aad637555f45cb40977a735a2c0a7279f1136(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnClusterAutoModeIpamLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeIpamLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9ff225116c19cb7efcfb1e90dae8557fa0ae2445d614dc75be2727537c5411ac(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterAutoModeIpamLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeIpamLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b42743af82b9531da65de9d56024055f045f566822caf6cde9904efbd2e77cd(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeIpamLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1334f9899fe88d2a3c9b4edb5382a2c0502348c8f1f9ba42d8afb18c799aaca(
    *,
    output_format: typing.Optional[CfnClusterAutoModeIpamLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeIpamLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26d106af17cef7ed5bf19f75db377b6c168d1138ce09a39ea0e8abef628d0c22(
    *,
    output_format: typing.Optional[CfnClusterAutoModeIpamLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeIpamLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f0abf50069b8061b68b8aab0faea50243cb98025308c83a6a102a1b327ecc81(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterAutoModeIpamLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeIpamLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__080fc0bbbd6995a7ed24db96ce6eafe24f948bc7e76894afda348f265a27dd8a(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeLoadBalancingLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5e52d3a745ee872d211b863a8daa91da493e51e2eaad811818bbfb2c30b4253b(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeLoadBalancingLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b0dc46ca63c84c4d09de0a9c422860eab9a1040b651d2e4487e42962b083426e(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeLoadBalancingLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__287d15fdf0dcfd50d1b16077d3ba322ecd4ecc450fa176ee06aee2f13bb2d811(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeLoadBalancingLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f89da5ad8999c7da94d4d51c888d5db4d4d1f9ffd65b3925fc55caa0fbf1e2d(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeLoadBalancingLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a47b7f1399f8252514ced642b13f94fb44989f36867863b514da1d61885c79a(
    *,
    output_format: typing.Optional[CfnClusterAutoModeLoadBalancingLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeLoadBalancingLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e6a321333caf1aa8805bb4fbae4a8c279e53069c8dba491fff697546f6c2836(
    *,
    output_format: typing.Optional[CfnClusterAutoModeLoadBalancingLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeLoadBalancingLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b8b71934c22f6551636fdc21e5b588f7c7f9d688eaf8877c3b0eeb2ff69a02d(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnClusterAutoModeLoadBalancingLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnClusterAutoModeLoadBalancingLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53d54377ef74f8513cd0d834d49d8ffcbe02caa072dfb89bea1d46f40f056f74(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9d51028fbb5aacfbaf51b7c7834ba4699ede78ce14522f0639499cedaa98a6df(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82dc79894f0f72f4ce665ae05d23fd826cf1ac150e1cf0dca53780d2bdbbe6f9(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
