from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class DevOpsGuruInsightClosed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed",
):
    '''(experimental) EventBridge event pattern for aws.devopsguru@DevOpsGuruInsightClosed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
        
        dev_ops_guru_insight_closed = devopsguru_events.DevOpsGuruInsightClosed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="devOpsGuruInsightClosedPattern")
    @builtins.classmethod
    def dev_ops_guru_insight_closed_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightClosed.Anomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        region: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_collection: typing.Optional[typing.Union["DevOpsGuruInsightClosed.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for DevOps Guru Insight Closed.

        :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param anomalies: (experimental) anomalies property. Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time_iso: (experimental) endTimeISO property. Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_severity: (experimental) insightSeverity property. Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DevOpsGuruInsightClosed.DevOpsGuruInsightClosedProps(
            account_id=account_id,
            anomalies=anomalies,
            end_time=end_time,
            end_time_iso=end_time_iso,
            event_metadata=event_metadata,
            insight_description=insight_description,
            insight_id=insight_id,
            insight_name=insight_name,
            insight_severity=insight_severity,
            insight_type=insight_type,
            insight_url=insight_url,
            message_type=message_type,
            region=region,
            resource_collection=resource_collection,
            start_time=start_time,
            start_time_iso=start_time_iso,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "devOpsGuruInsightClosedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.AlarmCondition",
        jsii_struct_bases=[],
        name_mapping={
            "detection_band": "detectionBand",
            "reference_value": "referenceValue",
        },
    )
    class AlarmCondition:
        def __init__(
            self,
            *,
            detection_band: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_value: typing.Optional[typing.Union["DevOpsGuruInsightClosed.ReferenceValue", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for AlarmCondition.

            :param detection_band: (experimental) detectionBand property. Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_value: (experimental) referenceValue property. Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                alarm_condition = devopsguru_events.DevOpsGuruInsightClosed.AlarmCondition(
                    detection_band=["detectionBand"],
                    reference_value=devopsguru_events.DevOpsGuruInsightClosed.ReferenceValue(
                        comparison_operator=["comparisonOperator"],
                        datapoints_to_alarm=["datapointsToAlarm"],
                        evaluation_period=["evaluationPeriod"],
                        threshold=["threshold"]
                    )
                )
            '''
            if isinstance(reference_value, dict):
                reference_value = DevOpsGuruInsightClosed.ReferenceValue(**reference_value)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__cb4ebccfba3ebdec9ccabdf4506199db6df2320eb7b18d04209f5c5edb8014ed)
                check_type(argname="argument detection_band", value=detection_band, expected_type=type_hints["detection_band"])
                check_type(argname="argument reference_value", value=reference_value, expected_type=type_hints["reference_value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if detection_band is not None:
                self._values["detection_band"] = detection_band
            if reference_value is not None:
                self._values["reference_value"] = reference_value

        @builtins.property
        def detection_band(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) detectionBand property.

            Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("detection_band")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_value(
            self,
        ) -> typing.Optional["DevOpsGuruInsightClosed.ReferenceValue"]:
            '''(experimental) referenceValue property.

            Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reference_value")
            return typing.cast(typing.Optional["DevOpsGuruInsightClosed.ReferenceValue"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AlarmCondition(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.Anomaly",
        jsii_struct_bases=[],
        name_mapping={
            "anomaly_resources": "anomalyResources",
            "anomaly_severity": "anomalySeverity",
            "associated_resource_arns": "associatedResourceArns",
            "close_time": "closeTime",
            "close_time_iso": "closeTimeIso",
            "description": "description",
            "earliest_impact_time": "earliestImpactTime",
            "earliest_impact_time_iso": "earliestImpactTimeIso",
            "end_time": "endTime",
            "end_time_iso": "endTimeIso",
            "id": "id",
            "latest_impact_time": "latestImpactTime",
            "latest_impact_time_iso": "latestImpactTimeIso",
            "limit": "limit",
            "open_time": "openTime",
            "open_time_iso": "openTimeIso",
            "source_details": "sourceDetails",
            "source_metadata": "sourceMetadata",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
            "type": "type",
        },
    )
    class Anomaly:
        def __init__(
            self,
            *,
            anomaly_resources: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightClosed.AnomalyResource", typing.Dict[builtins.str, typing.Any]]]] = None,
            anomaly_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
            close_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            close_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            earliest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            earliest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            limit: typing.Optional[typing.Sequence[builtins.str]] = None,
            open_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            open_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_details: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightClosed.SourceDetail", typing.Dict[builtins.str, typing.Any]]]] = None,
            source_metadata: typing.Optional[typing.Union["DevOpsGuruInsightClosed.AnomalySourceMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Anomaly.

            :param anomaly_resources: (experimental) anomalyResources property. Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param anomaly_severity: (experimental) anomalySeverity property. Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param associated_resource_arns: (experimental) associatedResourceArns property. Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param close_time: (experimental) closeTime property. Specify an array of string values to match this event if the actual value of closeTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param close_time_iso: (experimental) closeTimeISO property. Specify an array of string values to match this event if the actual value of closeTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param earliest_impact_time: (experimental) earliestImpactTime property. Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param earliest_impact_time_iso: (experimental) earliestImpactTimeISO property. Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time_iso: (experimental) endTimeISO property. Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_impact_time: (experimental) latestImpactTime property. Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_impact_time_iso: (experimental) latestImpactTimeISO property. Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param limit: (experimental) limit property. Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param open_time: (experimental) openTime property. Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param open_time_iso: (experimental) openTimeISO property. Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_details: (experimental) sourceDetails property. Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_metadata: (experimental) sourceMetadata property. Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly = devopsguru_events.DevOpsGuruInsightClosed.Anomaly(
                    anomaly_resources=[devopsguru_events.DevOpsGuruInsightClosed.AnomalyResource(
                        name=["name"],
                        type=["type"]
                    )],
                    anomaly_severity=["anomalySeverity"],
                    associated_resource_arns=["associatedResourceArns"],
                    close_time=["closeTime"],
                    close_time_iso=["closeTimeIso"],
                    description=["description"],
                    earliest_impact_time=["earliestImpactTime"],
                    earliest_impact_time_iso=["earliestImpactTimeIso"],
                    end_time=["endTime"],
                    end_time_iso=["endTimeIso"],
                    id=["id"],
                    latest_impact_time=["latestImpactTime"],
                    latest_impact_time_iso=["latestImpactTimeIso"],
                    limit=["limit"],
                    open_time=["openTime"],
                    open_time_iso=["openTimeIso"],
                    source_details=[devopsguru_events.DevOpsGuruInsightClosed.SourceDetail(
                        data_identifiers=devopsguru_events.DevOpsGuruInsightClosed.DataIdentifiers(
                            alarm_condition=devopsguru_events.DevOpsGuruInsightClosed.AlarmCondition(
                                detection_band=["detectionBand"],
                                reference_value=devopsguru_events.DevOpsGuruInsightClosed.ReferenceValue(
                                    comparison_operator=["comparisonOperator"],
                                    datapoints_to_alarm=["datapointsToAlarm"],
                                    evaluation_period=["evaluationPeriod"],
                                    threshold=["threshold"]
                                )
                            ),
                            dimensions=[devopsguru_events.DevOpsGuruInsightClosed.CloudWatchDimension(
                                name=["name"],
                                value=["value"]
                            )],
                            metric_display_name=["metricDisplayName"],
                            metric_query=devopsguru_events.DevOpsGuruInsightClosed.MetricQuery(
                                group_by=devopsguru_events.DevOpsGuruInsightClosed.GroupBy(
                                    dimensions=["dimensions"],
                                    group=["group"]
                                ),
                                metric=["metric"]
                            ),
                            name=["name"],
                            namespace=["namespace"],
                            period=["period"],
                            resource_id=["resourceId"],
                            resource_type=["resourceType"],
                            stat=["stat"],
                            unit=["unit"]
                        ),
                        data_source=["dataSource"],
                        data_source_detail=["dataSourceDetail"]
                    )],
                    source_metadata=devopsguru_events.DevOpsGuruInsightClosed.AnomalySourceMetadata(
                        source=["source"],
                        source_resource_arn=["sourceResourceArn"],
                        source_resource_type=["sourceResourceType"]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"],
                    type=["type"]
                )
            '''
            if isinstance(source_metadata, dict):
                source_metadata = DevOpsGuruInsightClosed.AnomalySourceMetadata(**source_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__21f78e6c10eb0b32168f600c9513887e332d85ab4bd680093f4db7c5cafa5421)
                check_type(argname="argument anomaly_resources", value=anomaly_resources, expected_type=type_hints["anomaly_resources"])
                check_type(argname="argument anomaly_severity", value=anomaly_severity, expected_type=type_hints["anomaly_severity"])
                check_type(argname="argument associated_resource_arns", value=associated_resource_arns, expected_type=type_hints["associated_resource_arns"])
                check_type(argname="argument close_time", value=close_time, expected_type=type_hints["close_time"])
                check_type(argname="argument close_time_iso", value=close_time_iso, expected_type=type_hints["close_time_iso"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument earliest_impact_time", value=earliest_impact_time, expected_type=type_hints["earliest_impact_time"])
                check_type(argname="argument earliest_impact_time_iso", value=earliest_impact_time_iso, expected_type=type_hints["earliest_impact_time_iso"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument end_time_iso", value=end_time_iso, expected_type=type_hints["end_time_iso"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument latest_impact_time", value=latest_impact_time, expected_type=type_hints["latest_impact_time"])
                check_type(argname="argument latest_impact_time_iso", value=latest_impact_time_iso, expected_type=type_hints["latest_impact_time_iso"])
                check_type(argname="argument limit", value=limit, expected_type=type_hints["limit"])
                check_type(argname="argument open_time", value=open_time, expected_type=type_hints["open_time"])
                check_type(argname="argument open_time_iso", value=open_time_iso, expected_type=type_hints["open_time_iso"])
                check_type(argname="argument source_details", value=source_details, expected_type=type_hints["source_details"])
                check_type(argname="argument source_metadata", value=source_metadata, expected_type=type_hints["source_metadata"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if anomaly_resources is not None:
                self._values["anomaly_resources"] = anomaly_resources
            if anomaly_severity is not None:
                self._values["anomaly_severity"] = anomaly_severity
            if associated_resource_arns is not None:
                self._values["associated_resource_arns"] = associated_resource_arns
            if close_time is not None:
                self._values["close_time"] = close_time
            if close_time_iso is not None:
                self._values["close_time_iso"] = close_time_iso
            if description is not None:
                self._values["description"] = description
            if earliest_impact_time is not None:
                self._values["earliest_impact_time"] = earliest_impact_time
            if earliest_impact_time_iso is not None:
                self._values["earliest_impact_time_iso"] = earliest_impact_time_iso
            if end_time is not None:
                self._values["end_time"] = end_time
            if end_time_iso is not None:
                self._values["end_time_iso"] = end_time_iso
            if id is not None:
                self._values["id"] = id
            if latest_impact_time is not None:
                self._values["latest_impact_time"] = latest_impact_time
            if latest_impact_time_iso is not None:
                self._values["latest_impact_time_iso"] = latest_impact_time_iso
            if limit is not None:
                self._values["limit"] = limit
            if open_time is not None:
                self._values["open_time"] = open_time
            if open_time_iso is not None:
                self._values["open_time_iso"] = open_time_iso
            if source_details is not None:
                self._values["source_details"] = source_details
            if source_metadata is not None:
                self._values["source_metadata"] = source_metadata
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def anomaly_resources(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightClosed.AnomalyResource"]]:
            '''(experimental) anomalyResources property.

            Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomaly_resources")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightClosed.AnomalyResource"]], result)

        @builtins.property
        def anomaly_severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) anomalySeverity property.

            Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomaly_severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def associated_resource_arns(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) associatedResourceArns property.

            Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("associated_resource_arns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def close_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) closeTime property.

            Specify an array of string values to match this event if the actual value of closeTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("close_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def close_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) closeTimeISO property.

            Specify an array of string values to match this event if the actual value of closeTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("close_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def earliest_impact_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) earliestImpactTime property.

            Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("earliest_impact_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def earliest_impact_time_iso(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) earliestImpactTimeISO property.

            Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("earliest_impact_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTimeISO property.

            Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_impact_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestImpactTime property.

            Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_impact_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_impact_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestImpactTimeISO property.

            Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_impact_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def limit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) limit property.

            Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("limit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def open_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) openTime property.

            Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("open_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def open_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) openTimeISO property.

            Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("open_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_details(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightClosed.SourceDetail"]]:
            '''(experimental) sourceDetails property.

            Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_details")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightClosed.SourceDetail"]], result)

        @builtins.property
        def source_metadata(
            self,
        ) -> typing.Optional["DevOpsGuruInsightClosed.AnomalySourceMetadata"]:
            '''(experimental) sourceMetadata property.

            Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_metadata")
            return typing.cast(typing.Optional["DevOpsGuruInsightClosed.AnomalySourceMetadata"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Anomaly(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.AnomalyResource",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type"},
    )
    class AnomalyResource:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalyResource.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_resource = devopsguru_events.DevOpsGuruInsightClosed.AnomalyResource(
                    name=["name"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__761a1eb2a54ae9ca80c19e121cb4890ef099427bfb4e15d7dcb440006d91d7fd)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalyResource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.AnomalySourceMetadata",
        jsii_struct_bases=[],
        name_mapping={
            "source": "source",
            "source_resource_arn": "sourceResourceArn",
            "source_resource_type": "sourceResourceType",
        },
    )
    class AnomalySourceMetadata:
        def __init__(
            self,
            *,
            source: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalySourceMetadata.

            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_resource_arn: (experimental) sourceResourceArn property. Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_resource_type: (experimental) sourceResourceType property. Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_source_metadata = devopsguru_events.DevOpsGuruInsightClosed.AnomalySourceMetadata(
                    source=["source"],
                    source_resource_arn=["sourceResourceArn"],
                    source_resource_type=["sourceResourceType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8ad272b98ed33b3e7fc2afc49393c0f4d499213135e3a96a8e7c29a232e43af5)
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
                check_type(argname="argument source_resource_type", value=source_resource_type, expected_type=type_hints["source_resource_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if source is not None:
                self._values["source"] = source
            if source_resource_arn is not None:
                self._values["source_resource_arn"] = source_resource_arn
            if source_resource_type is not None:
                self._values["source_resource_type"] = source_resource_type

        @builtins.property
        def source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_resource_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceResourceArn property.

            Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_resource_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceResourceType property.

            Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalySourceMetadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.CloudFormation",
        jsii_struct_bases=[],
        name_mapping={"stack_names": "stackNames"},
    )
    class CloudFormation:
        def __init__(
            self,
            *,
            stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudFormation.

            :param stack_names: (experimental) stackNames property. Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_formation = devopsguru_events.DevOpsGuruInsightClosed.CloudFormation(
                    stack_names=["stackNames"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c7db278ff1a38c3af797d35811711778a325006ef8e8ba58a4bc8592fb4a0518)
                check_type(argname="argument stack_names", value=stack_names, expected_type=type_hints["stack_names"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if stack_names is not None:
                self._values["stack_names"] = stack_names

        @builtins.property
        def stack_names(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stackNames property.

            Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stack_names")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudFormation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.CloudWatchDimension",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "value": "value"},
    )
    class CloudWatchDimension:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudWatchDimension.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_watch_dimension = devopsguru_events.DevOpsGuruInsightClosed.CloudWatchDimension(
                    name=["name"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e88d72d2c07b952b078f785273a00c939e68777d5feb282bd87c65cfc28a4b78)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudWatchDimension(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.DataIdentifiers",
        jsii_struct_bases=[],
        name_mapping={
            "alarm_condition": "alarmCondition",
            "dimensions": "dimensions",
            "metric_display_name": "metricDisplayName",
            "metric_query": "metricQuery",
            "name": "name",
            "namespace": "namespace",
            "period": "period",
            "resource_id": "resourceId",
            "resource_type": "resourceType",
            "stat": "stat",
            "unit": "unit",
        },
    )
    class DataIdentifiers:
        def __init__(
            self,
            *,
            alarm_condition: typing.Optional[typing.Union["DevOpsGuruInsightClosed.AlarmCondition", typing.Dict[builtins.str, typing.Any]]] = None,
            dimensions: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightClosed.CloudWatchDimension", typing.Dict[builtins.str, typing.Any]]]] = None,
            metric_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            metric_query: typing.Optional[typing.Union["DevOpsGuruInsightClosed.MetricQuery", typing.Dict[builtins.str, typing.Any]]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
            period: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            stat: typing.Optional[typing.Sequence[builtins.str]] = None,
            unit: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DataIdentifiers.

            :param alarm_condition: (experimental) alarmCondition property. Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_display_name: (experimental) metricDisplayName property. Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_query: (experimental) metricQuery property. Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param namespace: (experimental) namespace property. Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param period: (experimental) period property. Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_id: (experimental) ResourceId property. Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_type: (experimental) ResourceType property. Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stat: (experimental) stat property. Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unit: (experimental) unit property. Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                data_identifiers = devopsguru_events.DevOpsGuruInsightClosed.DataIdentifiers(
                    alarm_condition=devopsguru_events.DevOpsGuruInsightClosed.AlarmCondition(
                        detection_band=["detectionBand"],
                        reference_value=devopsguru_events.DevOpsGuruInsightClosed.ReferenceValue(
                            comparison_operator=["comparisonOperator"],
                            datapoints_to_alarm=["datapointsToAlarm"],
                            evaluation_period=["evaluationPeriod"],
                            threshold=["threshold"]
                        )
                    ),
                    dimensions=[devopsguru_events.DevOpsGuruInsightClosed.CloudWatchDimension(
                        name=["name"],
                        value=["value"]
                    )],
                    metric_display_name=["metricDisplayName"],
                    metric_query=devopsguru_events.DevOpsGuruInsightClosed.MetricQuery(
                        group_by=devopsguru_events.DevOpsGuruInsightClosed.GroupBy(
                            dimensions=["dimensions"],
                            group=["group"]
                        ),
                        metric=["metric"]
                    ),
                    name=["name"],
                    namespace=["namespace"],
                    period=["period"],
                    resource_id=["resourceId"],
                    resource_type=["resourceType"],
                    stat=["stat"],
                    unit=["unit"]
                )
            '''
            if isinstance(alarm_condition, dict):
                alarm_condition = DevOpsGuruInsightClosed.AlarmCondition(**alarm_condition)
            if isinstance(metric_query, dict):
                metric_query = DevOpsGuruInsightClosed.MetricQuery(**metric_query)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9d7ad7b5943453201143a4a430367df3cf437576ae8081207d762eb94bb85734)
                check_type(argname="argument alarm_condition", value=alarm_condition, expected_type=type_hints["alarm_condition"])
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument metric_display_name", value=metric_display_name, expected_type=type_hints["metric_display_name"])
                check_type(argname="argument metric_query", value=metric_query, expected_type=type_hints["metric_query"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
                check_type(argname="argument period", value=period, expected_type=type_hints["period"])
                check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
                check_type(argname="argument stat", value=stat, expected_type=type_hints["stat"])
                check_type(argname="argument unit", value=unit, expected_type=type_hints["unit"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if alarm_condition is not None:
                self._values["alarm_condition"] = alarm_condition
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if metric_display_name is not None:
                self._values["metric_display_name"] = metric_display_name
            if metric_query is not None:
                self._values["metric_query"] = metric_query
            if name is not None:
                self._values["name"] = name
            if namespace is not None:
                self._values["namespace"] = namespace
            if period is not None:
                self._values["period"] = period
            if resource_id is not None:
                self._values["resource_id"] = resource_id
            if resource_type is not None:
                self._values["resource_type"] = resource_type
            if stat is not None:
                self._values["stat"] = stat
            if unit is not None:
                self._values["unit"] = unit

        @builtins.property
        def alarm_condition(
            self,
        ) -> typing.Optional["DevOpsGuruInsightClosed.AlarmCondition"]:
            '''(experimental) alarmCondition property.

            Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("alarm_condition")
            return typing.cast(typing.Optional["DevOpsGuruInsightClosed.AlarmCondition"], result)

        @builtins.property
        def dimensions(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightClosed.CloudWatchDimension"]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightClosed.CloudWatchDimension"]], result)

        @builtins.property
        def metric_display_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metricDisplayName property.

            Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_display_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def metric_query(
            self,
        ) -> typing.Optional["DevOpsGuruInsightClosed.MetricQuery"]:
            '''(experimental) metricQuery property.

            Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_query")
            return typing.cast(typing.Optional["DevOpsGuruInsightClosed.MetricQuery"], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def namespace(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) namespace property.

            Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("namespace")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def period(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) period property.

            Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceId property.

            Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceType property.

            Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stat(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stat property.

            Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stat")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unit property.

            Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataIdentifiers(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.DevOpsGuruInsightClosedProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "anomalies": "anomalies",
            "end_time": "endTime",
            "end_time_iso": "endTimeIso",
            "event_metadata": "eventMetadata",
            "insight_description": "insightDescription",
            "insight_id": "insightId",
            "insight_name": "insightName",
            "insight_severity": "insightSeverity",
            "insight_type": "insightType",
            "insight_url": "insightUrl",
            "message_type": "messageType",
            "region": "region",
            "resource_collection": "resourceCollection",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
        },
    )
    class DevOpsGuruInsightClosedProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightClosed.Anomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
            message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            region: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_collection: typing.Optional[typing.Union["DevOpsGuruInsightClosed.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.devopsguru@DevOpsGuruInsightClosed event.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param anomalies: (experimental) anomalies property. Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time_iso: (experimental) endTimeISO property. Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_severity: (experimental) insightSeverity property. Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                dev_ops_guru_insight_closed_props = devopsguru_events.DevOpsGuruInsightClosed.DevOpsGuruInsightClosedProps(
                    account_id=["accountId"],
                    anomalies=[devopsguru_events.DevOpsGuruInsightClosed.Anomaly(
                        anomaly_resources=[devopsguru_events.DevOpsGuruInsightClosed.AnomalyResource(
                            name=["name"],
                            type=["type"]
                        )],
                        anomaly_severity=["anomalySeverity"],
                        associated_resource_arns=["associatedResourceArns"],
                        close_time=["closeTime"],
                        close_time_iso=["closeTimeIso"],
                        description=["description"],
                        earliest_impact_time=["earliestImpactTime"],
                        earliest_impact_time_iso=["earliestImpactTimeIso"],
                        end_time=["endTime"],
                        end_time_iso=["endTimeIso"],
                        id=["id"],
                        latest_impact_time=["latestImpactTime"],
                        latest_impact_time_iso=["latestImpactTimeIso"],
                        limit=["limit"],
                        open_time=["openTime"],
                        open_time_iso=["openTimeIso"],
                        source_details=[devopsguru_events.DevOpsGuruInsightClosed.SourceDetail(
                            data_identifiers=devopsguru_events.DevOpsGuruInsightClosed.DataIdentifiers(
                                alarm_condition=devopsguru_events.DevOpsGuruInsightClosed.AlarmCondition(
                                    detection_band=["detectionBand"],
                                    reference_value=devopsguru_events.DevOpsGuruInsightClosed.ReferenceValue(
                                        comparison_operator=["comparisonOperator"],
                                        datapoints_to_alarm=["datapointsToAlarm"],
                                        evaluation_period=["evaluationPeriod"],
                                        threshold=["threshold"]
                                    )
                                ),
                                dimensions=[devopsguru_events.DevOpsGuruInsightClosed.CloudWatchDimension(
                                    name=["name"],
                                    value=["value"]
                                )],
                                metric_display_name=["metricDisplayName"],
                                metric_query=devopsguru_events.DevOpsGuruInsightClosed.MetricQuery(
                                    group_by=devopsguru_events.DevOpsGuruInsightClosed.GroupBy(
                                        dimensions=["dimensions"],
                                        group=["group"]
                                    ),
                                    metric=["metric"]
                                ),
                                name=["name"],
                                namespace=["namespace"],
                                period=["period"],
                                resource_id=["resourceId"],
                                resource_type=["resourceType"],
                                stat=["stat"],
                                unit=["unit"]
                            ),
                            data_source=["dataSource"],
                            data_source_detail=["dataSourceDetail"]
                        )],
                        source_metadata=devopsguru_events.DevOpsGuruInsightClosed.AnomalySourceMetadata(
                            source=["source"],
                            source_resource_arn=["sourceResourceArn"],
                            source_resource_type=["sourceResourceType"]
                        ),
                        start_time=["startTime"],
                        start_time_iso=["startTimeIso"],
                        type=["type"]
                    )],
                    end_time=["endTime"],
                    end_time_iso=["endTimeIso"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    insight_description=["insightDescription"],
                    insight_id=["insightId"],
                    insight_name=["insightName"],
                    insight_severity=["insightSeverity"],
                    insight_type=["insightType"],
                    insight_url=["insightUrl"],
                    message_type=["messageType"],
                    region=["region"],
                    resource_collection=devopsguru_events.DevOpsGuruInsightClosed.ResourceCollection(
                        cloud_formation=devopsguru_events.DevOpsGuruInsightClosed.CloudFormation(
                            stack_names=["stackNames"]
                        ),
                        tags=[devopsguru_events.DevOpsGuruInsightClosed.TagType(
                            app_boundary_key=["appBoundaryKey"],
                            tag_values=["tagValues"]
                        )]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(resource_collection, dict):
                resource_collection = DevOpsGuruInsightClosed.ResourceCollection(**resource_collection)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6abdbb250a44045137c4308b7b4a5d7eb630a82066e1976f712fd8bf08d9ec60)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument anomalies", value=anomalies, expected_type=type_hints["anomalies"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument end_time_iso", value=end_time_iso, expected_type=type_hints["end_time_iso"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument insight_description", value=insight_description, expected_type=type_hints["insight_description"])
                check_type(argname="argument insight_id", value=insight_id, expected_type=type_hints["insight_id"])
                check_type(argname="argument insight_name", value=insight_name, expected_type=type_hints["insight_name"])
                check_type(argname="argument insight_severity", value=insight_severity, expected_type=type_hints["insight_severity"])
                check_type(argname="argument insight_type", value=insight_type, expected_type=type_hints["insight_type"])
                check_type(argname="argument insight_url", value=insight_url, expected_type=type_hints["insight_url"])
                check_type(argname="argument message_type", value=message_type, expected_type=type_hints["message_type"])
                check_type(argname="argument region", value=region, expected_type=type_hints["region"])
                check_type(argname="argument resource_collection", value=resource_collection, expected_type=type_hints["resource_collection"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if anomalies is not None:
                self._values["anomalies"] = anomalies
            if end_time is not None:
                self._values["end_time"] = end_time
            if end_time_iso is not None:
                self._values["end_time_iso"] = end_time_iso
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if insight_description is not None:
                self._values["insight_description"] = insight_description
            if insight_id is not None:
                self._values["insight_id"] = insight_id
            if insight_name is not None:
                self._values["insight_name"] = insight_name
            if insight_severity is not None:
                self._values["insight_severity"] = insight_severity
            if insight_type is not None:
                self._values["insight_type"] = insight_type
            if insight_url is not None:
                self._values["insight_url"] = insight_url
            if message_type is not None:
                self._values["message_type"] = message_type
            if region is not None:
                self._values["region"] = region
            if resource_collection is not None:
                self._values["resource_collection"] = resource_collection
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def anomalies(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightClosed.Anomaly"]]:
            '''(experimental) anomalies property.

            Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomalies")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightClosed.Anomaly"]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTimeISO property.

            Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def insight_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightDescription property.

            Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightId property.

            Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightName property.

            Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightSeverity property.

            Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightType property.

            Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightUrl property.

            Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) messageType property.

            Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) region property.

            Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_collection(
            self,
        ) -> typing.Optional["DevOpsGuruInsightClosed.ResourceCollection"]:
            '''(experimental) resourceCollection property.

            Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_collection")
            return typing.cast(typing.Optional["DevOpsGuruInsightClosed.ResourceCollection"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DevOpsGuruInsightClosedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.GroupBy",
        jsii_struct_bases=[],
        name_mapping={"dimensions": "dimensions", "group": "group"},
    )
    class GroupBy:
        def __init__(
            self,
            *,
            dimensions: typing.Optional[typing.Sequence[builtins.str]] = None,
            group: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupBy.

            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group: (experimental) group property. Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                group_by = devopsguru_events.DevOpsGuruInsightClosed.GroupBy(
                    dimensions=["dimensions"],
                    group=["group"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__853c444a332dd25670582ca2ce061e648fdb54662273c0e0c67fe5094087ef89)
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument group", value=group, expected_type=type_hints["group"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if group is not None:
                self._values["group"] = group

        @builtins.property
        def dimensions(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) group property.

            Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupBy(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.MetricQuery",
        jsii_struct_bases=[],
        name_mapping={"group_by": "groupBy", "metric": "metric"},
    )
    class MetricQuery:
        def __init__(
            self,
            *,
            group_by: typing.Optional[typing.Union["DevOpsGuruInsightClosed.GroupBy", typing.Dict[builtins.str, typing.Any]]] = None,
            metric: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for MetricQuery.

            :param group_by: (experimental) groupBy property. Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric: (experimental) metric property. Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                metric_query = devopsguru_events.DevOpsGuruInsightClosed.MetricQuery(
                    group_by=devopsguru_events.DevOpsGuruInsightClosed.GroupBy(
                        dimensions=["dimensions"],
                        group=["group"]
                    ),
                    metric=["metric"]
                )
            '''
            if isinstance(group_by, dict):
                group_by = DevOpsGuruInsightClosed.GroupBy(**group_by)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9f342bfaaa440e88d8ccab29ba37648c5aa5c832b634236caf25f188094a62a6)
                check_type(argname="argument group_by", value=group_by, expected_type=type_hints["group_by"])
                check_type(argname="argument metric", value=metric, expected_type=type_hints["metric"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if group_by is not None:
                self._values["group_by"] = group_by
            if metric is not None:
                self._values["metric"] = metric

        @builtins.property
        def group_by(self) -> typing.Optional["DevOpsGuruInsightClosed.GroupBy"]:
            '''(experimental) groupBy property.

            Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_by")
            return typing.cast(typing.Optional["DevOpsGuruInsightClosed.GroupBy"], result)

        @builtins.property
        def metric(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metric property.

            Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "MetricQuery(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.ReferenceValue",
        jsii_struct_bases=[],
        name_mapping={
            "comparison_operator": "comparisonOperator",
            "datapoints_to_alarm": "datapointsToAlarm",
            "evaluation_period": "evaluationPeriod",
            "threshold": "threshold",
        },
    )
    class ReferenceValue:
        def __init__(
            self,
            *,
            comparison_operator: typing.Optional[typing.Sequence[builtins.str]] = None,
            datapoints_to_alarm: typing.Optional[typing.Sequence[builtins.str]] = None,
            evaluation_period: typing.Optional[typing.Sequence[builtins.str]] = None,
            threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ReferenceValue.

            :param comparison_operator: (experimental) comparisonOperator property. Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datapoints_to_alarm: (experimental) datapointsToAlarm property. Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param evaluation_period: (experimental) evaluationPeriod property. Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param threshold: (experimental) threshold property. Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                reference_value = devopsguru_events.DevOpsGuruInsightClosed.ReferenceValue(
                    comparison_operator=["comparisonOperator"],
                    datapoints_to_alarm=["datapointsToAlarm"],
                    evaluation_period=["evaluationPeriod"],
                    threshold=["threshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__571a1a574cec310f4999094fdad96edc556d398ce15c34be05fcc577bcf2ebab)
                check_type(argname="argument comparison_operator", value=comparison_operator, expected_type=type_hints["comparison_operator"])
                check_type(argname="argument datapoints_to_alarm", value=datapoints_to_alarm, expected_type=type_hints["datapoints_to_alarm"])
                check_type(argname="argument evaluation_period", value=evaluation_period, expected_type=type_hints["evaluation_period"])
                check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if comparison_operator is not None:
                self._values["comparison_operator"] = comparison_operator
            if datapoints_to_alarm is not None:
                self._values["datapoints_to_alarm"] = datapoints_to_alarm
            if evaluation_period is not None:
                self._values["evaluation_period"] = evaluation_period
            if threshold is not None:
                self._values["threshold"] = threshold

        @builtins.property
        def comparison_operator(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) comparisonOperator property.

            Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comparison_operator")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datapoints_to_alarm(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datapointsToAlarm property.

            Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datapoints_to_alarm")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def evaluation_period(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) evaluationPeriod property.

            Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("evaluation_period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) threshold property.

            Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReferenceValue(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.ResourceCollection",
        jsii_struct_bases=[],
        name_mapping={"cloud_formation": "cloudFormation", "tags": "tags"},
    )
    class ResourceCollection:
        def __init__(
            self,
            *,
            cloud_formation: typing.Optional[typing.Union["DevOpsGuruInsightClosed.CloudFormation", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightClosed.TagType", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceCollection.

            :param cloud_formation: (experimental) cloudFormation property. Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                resource_collection = devopsguru_events.DevOpsGuruInsightClosed.ResourceCollection(
                    cloud_formation=devopsguru_events.DevOpsGuruInsightClosed.CloudFormation(
                        stack_names=["stackNames"]
                    ),
                    tags=[devopsguru_events.DevOpsGuruInsightClosed.TagType(
                        app_boundary_key=["appBoundaryKey"],
                        tag_values=["tagValues"]
                    )]
                )
            '''
            if isinstance(cloud_formation, dict):
                cloud_formation = DevOpsGuruInsightClosed.CloudFormation(**cloud_formation)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0cf21082a870ee70430024bd50a4181ed8e0965872a9e08fb4a03054c88e6dae)
                check_type(argname="argument cloud_formation", value=cloud_formation, expected_type=type_hints["cloud_formation"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cloud_formation is not None:
                self._values["cloud_formation"] = cloud_formation
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def cloud_formation(
            self,
        ) -> typing.Optional["DevOpsGuruInsightClosed.CloudFormation"]:
            '''(experimental) cloudFormation property.

            Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cloud_formation")
            return typing.cast(typing.Optional["DevOpsGuruInsightClosed.CloudFormation"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightClosed.TagType"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightClosed.TagType"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceCollection(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.SourceDetail",
        jsii_struct_bases=[],
        name_mapping={
            "data_identifiers": "dataIdentifiers",
            "data_source": "dataSource",
            "data_source_detail": "dataSourceDetail",
        },
    )
    class SourceDetail:
        def __init__(
            self,
            *,
            data_identifiers: typing.Optional[typing.Union["DevOpsGuruInsightClosed.DataIdentifiers", typing.Dict[builtins.str, typing.Any]]] = None,
            data_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SourceDetail.

            :param data_identifiers: (experimental) dataIdentifiers property. Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) dataSource property. Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source_detail: (experimental) dataSourceDetail property. Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                source_detail = devopsguru_events.DevOpsGuruInsightClosed.SourceDetail(
                    data_identifiers=devopsguru_events.DevOpsGuruInsightClosed.DataIdentifiers(
                        alarm_condition=devopsguru_events.DevOpsGuruInsightClosed.AlarmCondition(
                            detection_band=["detectionBand"],
                            reference_value=devopsguru_events.DevOpsGuruInsightClosed.ReferenceValue(
                                comparison_operator=["comparisonOperator"],
                                datapoints_to_alarm=["datapointsToAlarm"],
                                evaluation_period=["evaluationPeriod"],
                                threshold=["threshold"]
                            )
                        ),
                        dimensions=[devopsguru_events.DevOpsGuruInsightClosed.CloudWatchDimension(
                            name=["name"],
                            value=["value"]
                        )],
                        metric_display_name=["metricDisplayName"],
                        metric_query=devopsguru_events.DevOpsGuruInsightClosed.MetricQuery(
                            group_by=devopsguru_events.DevOpsGuruInsightClosed.GroupBy(
                                dimensions=["dimensions"],
                                group=["group"]
                            ),
                            metric=["metric"]
                        ),
                        name=["name"],
                        namespace=["namespace"],
                        period=["period"],
                        resource_id=["resourceId"],
                        resource_type=["resourceType"],
                        stat=["stat"],
                        unit=["unit"]
                    ),
                    data_source=["dataSource"],
                    data_source_detail=["dataSourceDetail"]
                )
            '''
            if isinstance(data_identifiers, dict):
                data_identifiers = DevOpsGuruInsightClosed.DataIdentifiers(**data_identifiers)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9b2b25b8c5a110d3b9a2b521f9856f4ffac71373d8d987e48b5cee1f158a09da)
                check_type(argname="argument data_identifiers", value=data_identifiers, expected_type=type_hints["data_identifiers"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
                check_type(argname="argument data_source_detail", value=data_source_detail, expected_type=type_hints["data_source_detail"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data_identifiers is not None:
                self._values["data_identifiers"] = data_identifiers
            if data_source is not None:
                self._values["data_source"] = data_source
            if data_source_detail is not None:
                self._values["data_source_detail"] = data_source_detail

        @builtins.property
        def data_identifiers(
            self,
        ) -> typing.Optional["DevOpsGuruInsightClosed.DataIdentifiers"]:
            '''(experimental) dataIdentifiers property.

            Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_identifiers")
            return typing.cast(typing.Optional["DevOpsGuruInsightClosed.DataIdentifiers"], result)

        @builtins.property
        def data_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataSource property.

            Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source_detail(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataSourceDetail property.

            Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source_detail")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SourceDetail(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightClosed.TagType",
        jsii_struct_bases=[],
        name_mapping={"app_boundary_key": "appBoundaryKey", "tag_values": "tagValues"},
    )
    class TagType:
        def __init__(
            self,
            *,
            app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tag.

            :param app_boundary_key: (experimental) appBoundaryKey property. Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_values: (experimental) tagValues property. Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                tag_type = devopsguru_events.DevOpsGuruInsightClosed.TagType(
                    app_boundary_key=["appBoundaryKey"],
                    tag_values=["tagValues"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__05718688a555c4571a3300ca4b94d089b27dfa3d3267061678d95a4a641625cc)
                check_type(argname="argument app_boundary_key", value=app_boundary_key, expected_type=type_hints["app_boundary_key"])
                check_type(argname="argument tag_values", value=tag_values, expected_type=type_hints["tag_values"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if app_boundary_key is not None:
                self._values["app_boundary_key"] = app_boundary_key
            if tag_values is not None:
                self._values["tag_values"] = tag_values

        @builtins.property
        def app_boundary_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) appBoundaryKey property.

            Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("app_boundary_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_values(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagValues property.

            Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_values")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagType(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DevOpsGuruInsightSeverityUpgraded(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded",
):
    '''(experimental) EventBridge event pattern for aws.devopsguru@DevOpsGuruInsightSeverityUpgraded.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
        
        dev_ops_guru_insight_severity_upgraded = devopsguru_events.DevOpsGuruInsightSeverityUpgraded()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="devOpsGuruInsightSeverityUpgradedPattern")
    @builtins.classmethod
    def dev_ops_guru_insight_severity_upgraded_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightSeverityUpgraded.Anomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        region: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_collection: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for DevOps Guru Insight Severity Upgraded.

        :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param anomalies: (experimental) anomalies property. Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_severity: (experimental) insightSeverity property. Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DevOpsGuruInsightSeverityUpgraded.DevOpsGuruInsightSeverityUpgradedProps(
            account_id=account_id,
            anomalies=anomalies,
            event_metadata=event_metadata,
            insight_description=insight_description,
            insight_id=insight_id,
            insight_name=insight_name,
            insight_severity=insight_severity,
            insight_type=insight_type,
            insight_url=insight_url,
            message_type=message_type,
            region=region,
            resource_collection=resource_collection,
            start_time=start_time,
            start_time_iso=start_time_iso,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "devOpsGuruInsightSeverityUpgradedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.AlarmCondition",
        jsii_struct_bases=[],
        name_mapping={
            "detection_band": "detectionBand",
            "reference_value": "referenceValue",
        },
    )
    class AlarmCondition:
        def __init__(
            self,
            *,
            detection_band: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_value: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.ReferenceValue", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for AlarmCondition.

            :param detection_band: (experimental) detectionBand property. Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_value: (experimental) referenceValue property. Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                alarm_condition = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AlarmCondition(
                    detection_band=["detectionBand"],
                    reference_value=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.ReferenceValue(
                        comparison_operator=["comparisonOperator"],
                        datapoints_to_alarm=["datapointsToAlarm"],
                        evaluation_period=["evaluationPeriod"],
                        threshold=["threshold"]
                    )
                )
            '''
            if isinstance(reference_value, dict):
                reference_value = DevOpsGuruInsightSeverityUpgraded.ReferenceValue(**reference_value)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ba706a8829ef41a1abe88afea69457c9a14b9b73eda1e833b5d3c0645f651aff)
                check_type(argname="argument detection_band", value=detection_band, expected_type=type_hints["detection_band"])
                check_type(argname="argument reference_value", value=reference_value, expected_type=type_hints["reference_value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if detection_band is not None:
                self._values["detection_band"] = detection_band
            if reference_value is not None:
                self._values["reference_value"] = reference_value

        @builtins.property
        def detection_band(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) detectionBand property.

            Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("detection_band")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_value(
            self,
        ) -> typing.Optional["DevOpsGuruInsightSeverityUpgraded.ReferenceValue"]:
            '''(experimental) referenceValue property.

            Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reference_value")
            return typing.cast(typing.Optional["DevOpsGuruInsightSeverityUpgraded.ReferenceValue"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AlarmCondition(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.Anomaly",
        jsii_struct_bases=[],
        name_mapping={
            "anomaly_resources": "anomalyResources",
            "anomaly_severity": "anomalySeverity",
            "associated_resource_arns": "associatedResourceArns",
            "description": "description",
            "earliest_impact_time": "earliestImpactTime",
            "earliest_impact_time_iso": "earliestImpactTimeIso",
            "end_time": "endTime",
            "id": "id",
            "latest_impact_time": "latestImpactTime",
            "latest_impact_time_iso": "latestImpactTimeIso",
            "limit": "limit",
            "open_time": "openTime",
            "open_time_iso": "openTimeIso",
            "source_details": "sourceDetails",
            "source_metadata": "sourceMetadata",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
            "type": "type",
        },
    )
    class Anomaly:
        def __init__(
            self,
            *,
            anomaly_resources: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightSeverityUpgraded.AnomalyResource", typing.Dict[builtins.str, typing.Any]]]] = None,
            anomaly_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            earliest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            earliest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            limit: typing.Optional[typing.Sequence[builtins.str]] = None,
            open_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            open_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_details: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightSeverityUpgraded.SourceDetail", typing.Dict[builtins.str, typing.Any]]]] = None,
            source_metadata: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Anomaly.

            :param anomaly_resources: (experimental) anomalyResources property. Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param anomaly_severity: (experimental) anomalySeverity property. Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param associated_resource_arns: (experimental) associatedResourceArns property. Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param earliest_impact_time: (experimental) earliestImpactTime property. Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param earliest_impact_time_iso: (experimental) earliestImpactTimeISO property. Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_impact_time: (experimental) latestImpactTime property. Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_impact_time_iso: (experimental) latestImpactTimeISO property. Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param limit: (experimental) limit property. Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param open_time: (experimental) openTime property. Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param open_time_iso: (experimental) openTimeISO property. Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_details: (experimental) sourceDetails property. Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_metadata: (experimental) sourceMetadata property. Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.Anomaly(
                    anomaly_resources=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AnomalyResource(
                        name=["name"],
                        type=["type"]
                    )],
                    anomaly_severity=["anomalySeverity"],
                    associated_resource_arns=["associatedResourceArns"],
                    description=["description"],
                    earliest_impact_time=["earliestImpactTime"],
                    earliest_impact_time_iso=["earliestImpactTimeIso"],
                    end_time=["endTime"],
                    id=["id"],
                    latest_impact_time=["latestImpactTime"],
                    latest_impact_time_iso=["latestImpactTimeIso"],
                    limit=["limit"],
                    open_time=["openTime"],
                    open_time_iso=["openTimeIso"],
                    source_details=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.SourceDetail(
                        data_identifiers=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.DataIdentifiers(
                            alarm_condition=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AlarmCondition(
                                detection_band=["detectionBand"],
                                reference_value=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.ReferenceValue(
                                    comparison_operator=["comparisonOperator"],
                                    datapoints_to_alarm=["datapointsToAlarm"],
                                    evaluation_period=["evaluationPeriod"],
                                    threshold=["threshold"]
                                )
                            ),
                            dimensions=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension(
                                name=["name"],
                                value=["value"]
                            )],
                            metric_display_name=["metricDisplayName"],
                            metric_query=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.MetricQuery(
                                group_by=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.GroupBy(
                                    dimensions=["dimensions"],
                                    group=["group"]
                                ),
                                metric=["metric"]
                            ),
                            name=["name"],
                            namespace=["namespace"],
                            period=["period"],
                            resource_id=["resourceId"],
                            resource_type=["resourceType"],
                            stat=["stat"],
                            unit=["unit"]
                        ),
                        data_source=["dataSource"],
                        data_source_detail=["dataSourceDetail"]
                    )],
                    source_metadata=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata(
                        source=["source"],
                        source_resource_arn=["sourceResourceArn"],
                        source_resource_type=["sourceResourceType"]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"],
                    type=["type"]
                )
            '''
            if isinstance(source_metadata, dict):
                source_metadata = DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata(**source_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__020c3625e5c50bb12d53f0e736192664b638d831f75d6a011b109bbaf0e1c0f6)
                check_type(argname="argument anomaly_resources", value=anomaly_resources, expected_type=type_hints["anomaly_resources"])
                check_type(argname="argument anomaly_severity", value=anomaly_severity, expected_type=type_hints["anomaly_severity"])
                check_type(argname="argument associated_resource_arns", value=associated_resource_arns, expected_type=type_hints["associated_resource_arns"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument earliest_impact_time", value=earliest_impact_time, expected_type=type_hints["earliest_impact_time"])
                check_type(argname="argument earliest_impact_time_iso", value=earliest_impact_time_iso, expected_type=type_hints["earliest_impact_time_iso"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument latest_impact_time", value=latest_impact_time, expected_type=type_hints["latest_impact_time"])
                check_type(argname="argument latest_impact_time_iso", value=latest_impact_time_iso, expected_type=type_hints["latest_impact_time_iso"])
                check_type(argname="argument limit", value=limit, expected_type=type_hints["limit"])
                check_type(argname="argument open_time", value=open_time, expected_type=type_hints["open_time"])
                check_type(argname="argument open_time_iso", value=open_time_iso, expected_type=type_hints["open_time_iso"])
                check_type(argname="argument source_details", value=source_details, expected_type=type_hints["source_details"])
                check_type(argname="argument source_metadata", value=source_metadata, expected_type=type_hints["source_metadata"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if anomaly_resources is not None:
                self._values["anomaly_resources"] = anomaly_resources
            if anomaly_severity is not None:
                self._values["anomaly_severity"] = anomaly_severity
            if associated_resource_arns is not None:
                self._values["associated_resource_arns"] = associated_resource_arns
            if description is not None:
                self._values["description"] = description
            if earliest_impact_time is not None:
                self._values["earliest_impact_time"] = earliest_impact_time
            if earliest_impact_time_iso is not None:
                self._values["earliest_impact_time_iso"] = earliest_impact_time_iso
            if end_time is not None:
                self._values["end_time"] = end_time
            if id is not None:
                self._values["id"] = id
            if latest_impact_time is not None:
                self._values["latest_impact_time"] = latest_impact_time
            if latest_impact_time_iso is not None:
                self._values["latest_impact_time_iso"] = latest_impact_time_iso
            if limit is not None:
                self._values["limit"] = limit
            if open_time is not None:
                self._values["open_time"] = open_time
            if open_time_iso is not None:
                self._values["open_time_iso"] = open_time_iso
            if source_details is not None:
                self._values["source_details"] = source_details
            if source_metadata is not None:
                self._values["source_metadata"] = source_metadata
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def anomaly_resources(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.AnomalyResource"]]:
            '''(experimental) anomalyResources property.

            Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomaly_resources")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.AnomalyResource"]], result)

        @builtins.property
        def anomaly_severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) anomalySeverity property.

            Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomaly_severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def associated_resource_arns(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) associatedResourceArns property.

            Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("associated_resource_arns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def earliest_impact_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) earliestImpactTime property.

            Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("earliest_impact_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def earliest_impact_time_iso(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) earliestImpactTimeISO property.

            Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("earliest_impact_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_impact_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestImpactTime property.

            Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_impact_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_impact_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestImpactTimeISO property.

            Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_impact_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def limit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) limit property.

            Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("limit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def open_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) openTime property.

            Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("open_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def open_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) openTimeISO property.

            Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("open_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_details(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.SourceDetail"]]:
            '''(experimental) sourceDetails property.

            Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_details")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.SourceDetail"]], result)

        @builtins.property
        def source_metadata(
            self,
        ) -> typing.Optional["DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata"]:
            '''(experimental) sourceMetadata property.

            Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_metadata")
            return typing.cast(typing.Optional["DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Anomaly(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.AnomalyResource",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type"},
    )
    class AnomalyResource:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalyResource.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_resource = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AnomalyResource(
                    name=["name"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__bb65e336abf0100acf5618faeeac78db1bbb2c5278f29eae268b8bbf2a02a308)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalyResource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata",
        jsii_struct_bases=[],
        name_mapping={
            "source": "source",
            "source_resource_arn": "sourceResourceArn",
            "source_resource_type": "sourceResourceType",
        },
    )
    class AnomalySourceMetadata:
        def __init__(
            self,
            *,
            source: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalySourceMetadata.

            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_resource_arn: (experimental) sourceResourceArn property. Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_resource_type: (experimental) sourceResourceType property. Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_source_metadata = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata(
                    source=["source"],
                    source_resource_arn=["sourceResourceArn"],
                    source_resource_type=["sourceResourceType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c6eb939fd6b85cda4748540afe75dcf0e33389cb44522122ff8c8b7e27b7d5e5)
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
                check_type(argname="argument source_resource_type", value=source_resource_type, expected_type=type_hints["source_resource_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if source is not None:
                self._values["source"] = source
            if source_resource_arn is not None:
                self._values["source_resource_arn"] = source_resource_arn
            if source_resource_type is not None:
                self._values["source_resource_type"] = source_resource_type

        @builtins.property
        def source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_resource_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceResourceArn property.

            Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_resource_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceResourceType property.

            Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalySourceMetadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.CloudFormation",
        jsii_struct_bases=[],
        name_mapping={"stack_names": "stackNames"},
    )
    class CloudFormation:
        def __init__(
            self,
            *,
            stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudFormation.

            :param stack_names: (experimental) stackNames property. Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_formation = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.CloudFormation(
                    stack_names=["stackNames"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__453ea0b482897141b9487d0b535b38f13f21ad26276d6215545a1299ab7a0741)
                check_type(argname="argument stack_names", value=stack_names, expected_type=type_hints["stack_names"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if stack_names is not None:
                self._values["stack_names"] = stack_names

        @builtins.property
        def stack_names(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stackNames property.

            Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stack_names")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudFormation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "value": "value"},
    )
    class CloudWatchDimension:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudWatchDimension.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_watch_dimension = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension(
                    name=["name"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__436e753aa0eceb4b1b18c56ec2e9ad56beab3df19a8b6c244d4f6df4427c8cde)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudWatchDimension(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.DataIdentifiers",
        jsii_struct_bases=[],
        name_mapping={
            "alarm_condition": "alarmCondition",
            "dimensions": "dimensions",
            "metric_display_name": "metricDisplayName",
            "metric_query": "metricQuery",
            "name": "name",
            "namespace": "namespace",
            "period": "period",
            "resource_id": "resourceId",
            "resource_type": "resourceType",
            "stat": "stat",
            "unit": "unit",
        },
    )
    class DataIdentifiers:
        def __init__(
            self,
            *,
            alarm_condition: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.AlarmCondition", typing.Dict[builtins.str, typing.Any]]] = None,
            dimensions: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension", typing.Dict[builtins.str, typing.Any]]]] = None,
            metric_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            metric_query: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.MetricQuery", typing.Dict[builtins.str, typing.Any]]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
            period: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            stat: typing.Optional[typing.Sequence[builtins.str]] = None,
            unit: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DataIdentifiers.

            :param alarm_condition: (experimental) alarmCondition property. Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_display_name: (experimental) metricDisplayName property. Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_query: (experimental) metricQuery property. Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param namespace: (experimental) namespace property. Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param period: (experimental) period property. Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_id: (experimental) ResourceId property. Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_type: (experimental) ResourceType property. Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stat: (experimental) stat property. Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unit: (experimental) unit property. Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                data_identifiers = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.DataIdentifiers(
                    alarm_condition=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AlarmCondition(
                        detection_band=["detectionBand"],
                        reference_value=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.ReferenceValue(
                            comparison_operator=["comparisonOperator"],
                            datapoints_to_alarm=["datapointsToAlarm"],
                            evaluation_period=["evaluationPeriod"],
                            threshold=["threshold"]
                        )
                    ),
                    dimensions=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension(
                        name=["name"],
                        value=["value"]
                    )],
                    metric_display_name=["metricDisplayName"],
                    metric_query=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.MetricQuery(
                        group_by=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.GroupBy(
                            dimensions=["dimensions"],
                            group=["group"]
                        ),
                        metric=["metric"]
                    ),
                    name=["name"],
                    namespace=["namespace"],
                    period=["period"],
                    resource_id=["resourceId"],
                    resource_type=["resourceType"],
                    stat=["stat"],
                    unit=["unit"]
                )
            '''
            if isinstance(alarm_condition, dict):
                alarm_condition = DevOpsGuruInsightSeverityUpgraded.AlarmCondition(**alarm_condition)
            if isinstance(metric_query, dict):
                metric_query = DevOpsGuruInsightSeverityUpgraded.MetricQuery(**metric_query)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__801111867e4015519688c31df6ffb88a096c7190cfd1b5a64fbbf55c439f4bbe)
                check_type(argname="argument alarm_condition", value=alarm_condition, expected_type=type_hints["alarm_condition"])
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument metric_display_name", value=metric_display_name, expected_type=type_hints["metric_display_name"])
                check_type(argname="argument metric_query", value=metric_query, expected_type=type_hints["metric_query"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
                check_type(argname="argument period", value=period, expected_type=type_hints["period"])
                check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
                check_type(argname="argument stat", value=stat, expected_type=type_hints["stat"])
                check_type(argname="argument unit", value=unit, expected_type=type_hints["unit"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if alarm_condition is not None:
                self._values["alarm_condition"] = alarm_condition
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if metric_display_name is not None:
                self._values["metric_display_name"] = metric_display_name
            if metric_query is not None:
                self._values["metric_query"] = metric_query
            if name is not None:
                self._values["name"] = name
            if namespace is not None:
                self._values["namespace"] = namespace
            if period is not None:
                self._values["period"] = period
            if resource_id is not None:
                self._values["resource_id"] = resource_id
            if resource_type is not None:
                self._values["resource_type"] = resource_type
            if stat is not None:
                self._values["stat"] = stat
            if unit is not None:
                self._values["unit"] = unit

        @builtins.property
        def alarm_condition(
            self,
        ) -> typing.Optional["DevOpsGuruInsightSeverityUpgraded.AlarmCondition"]:
            '''(experimental) alarmCondition property.

            Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("alarm_condition")
            return typing.cast(typing.Optional["DevOpsGuruInsightSeverityUpgraded.AlarmCondition"], result)

        @builtins.property
        def dimensions(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension"]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension"]], result)

        @builtins.property
        def metric_display_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metricDisplayName property.

            Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_display_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def metric_query(
            self,
        ) -> typing.Optional["DevOpsGuruInsightSeverityUpgraded.MetricQuery"]:
            '''(experimental) metricQuery property.

            Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_query")
            return typing.cast(typing.Optional["DevOpsGuruInsightSeverityUpgraded.MetricQuery"], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def namespace(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) namespace property.

            Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("namespace")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def period(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) period property.

            Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceId property.

            Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceType property.

            Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stat(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stat property.

            Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stat")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unit property.

            Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataIdentifiers(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.DevOpsGuruInsightSeverityUpgradedProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "anomalies": "anomalies",
            "event_metadata": "eventMetadata",
            "insight_description": "insightDescription",
            "insight_id": "insightId",
            "insight_name": "insightName",
            "insight_severity": "insightSeverity",
            "insight_type": "insightType",
            "insight_url": "insightUrl",
            "message_type": "messageType",
            "region": "region",
            "resource_collection": "resourceCollection",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
        },
    )
    class DevOpsGuruInsightSeverityUpgradedProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightSeverityUpgraded.Anomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
            message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            region: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_collection: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.devopsguru@DevOpsGuruInsightSeverityUpgraded event.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param anomalies: (experimental) anomalies property. Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_severity: (experimental) insightSeverity property. Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                dev_ops_guru_insight_severity_upgraded_props = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.DevOpsGuruInsightSeverityUpgradedProps(
                    account_id=["accountId"],
                    anomalies=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.Anomaly(
                        anomaly_resources=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AnomalyResource(
                            name=["name"],
                            type=["type"]
                        )],
                        anomaly_severity=["anomalySeverity"],
                        associated_resource_arns=["associatedResourceArns"],
                        description=["description"],
                        earliest_impact_time=["earliestImpactTime"],
                        earliest_impact_time_iso=["earliestImpactTimeIso"],
                        end_time=["endTime"],
                        id=["id"],
                        latest_impact_time=["latestImpactTime"],
                        latest_impact_time_iso=["latestImpactTimeIso"],
                        limit=["limit"],
                        open_time=["openTime"],
                        open_time_iso=["openTimeIso"],
                        source_details=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.SourceDetail(
                            data_identifiers=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.DataIdentifiers(
                                alarm_condition=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AlarmCondition(
                                    detection_band=["detectionBand"],
                                    reference_value=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.ReferenceValue(
                                        comparison_operator=["comparisonOperator"],
                                        datapoints_to_alarm=["datapointsToAlarm"],
                                        evaluation_period=["evaluationPeriod"],
                                        threshold=["threshold"]
                                    )
                                ),
                                dimensions=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension(
                                    name=["name"],
                                    value=["value"]
                                )],
                                metric_display_name=["metricDisplayName"],
                                metric_query=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.MetricQuery(
                                    group_by=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.GroupBy(
                                        dimensions=["dimensions"],
                                        group=["group"]
                                    ),
                                    metric=["metric"]
                                ),
                                name=["name"],
                                namespace=["namespace"],
                                period=["period"],
                                resource_id=["resourceId"],
                                resource_type=["resourceType"],
                                stat=["stat"],
                                unit=["unit"]
                            ),
                            data_source=["dataSource"],
                            data_source_detail=["dataSourceDetail"]
                        )],
                        source_metadata=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata(
                            source=["source"],
                            source_resource_arn=["sourceResourceArn"],
                            source_resource_type=["sourceResourceType"]
                        ),
                        start_time=["startTime"],
                        start_time_iso=["startTimeIso"],
                        type=["type"]
                    )],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    insight_description=["insightDescription"],
                    insight_id=["insightId"],
                    insight_name=["insightName"],
                    insight_severity=["insightSeverity"],
                    insight_type=["insightType"],
                    insight_url=["insightUrl"],
                    message_type=["messageType"],
                    region=["region"],
                    resource_collection=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.ResourceCollection(
                        cloud_formation=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.CloudFormation(
                            stack_names=["stackNames"]
                        ),
                        tags=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.TagType(
                            app_boundary_key=["appBoundaryKey"],
                            tag_values=["tagValues"]
                        )]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(resource_collection, dict):
                resource_collection = DevOpsGuruInsightSeverityUpgraded.ResourceCollection(**resource_collection)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__679d5a75e9de46894f2716a26108a5bbdbf5e1ff5ef59d271d415942f3932dbc)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument anomalies", value=anomalies, expected_type=type_hints["anomalies"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument insight_description", value=insight_description, expected_type=type_hints["insight_description"])
                check_type(argname="argument insight_id", value=insight_id, expected_type=type_hints["insight_id"])
                check_type(argname="argument insight_name", value=insight_name, expected_type=type_hints["insight_name"])
                check_type(argname="argument insight_severity", value=insight_severity, expected_type=type_hints["insight_severity"])
                check_type(argname="argument insight_type", value=insight_type, expected_type=type_hints["insight_type"])
                check_type(argname="argument insight_url", value=insight_url, expected_type=type_hints["insight_url"])
                check_type(argname="argument message_type", value=message_type, expected_type=type_hints["message_type"])
                check_type(argname="argument region", value=region, expected_type=type_hints["region"])
                check_type(argname="argument resource_collection", value=resource_collection, expected_type=type_hints["resource_collection"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if anomalies is not None:
                self._values["anomalies"] = anomalies
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if insight_description is not None:
                self._values["insight_description"] = insight_description
            if insight_id is not None:
                self._values["insight_id"] = insight_id
            if insight_name is not None:
                self._values["insight_name"] = insight_name
            if insight_severity is not None:
                self._values["insight_severity"] = insight_severity
            if insight_type is not None:
                self._values["insight_type"] = insight_type
            if insight_url is not None:
                self._values["insight_url"] = insight_url
            if message_type is not None:
                self._values["message_type"] = message_type
            if region is not None:
                self._values["region"] = region
            if resource_collection is not None:
                self._values["resource_collection"] = resource_collection
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def anomalies(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.Anomaly"]]:
            '''(experimental) anomalies property.

            Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomalies")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.Anomaly"]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def insight_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightDescription property.

            Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightId property.

            Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightName property.

            Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightSeverity property.

            Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightType property.

            Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightUrl property.

            Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) messageType property.

            Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) region property.

            Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_collection(
            self,
        ) -> typing.Optional["DevOpsGuruInsightSeverityUpgraded.ResourceCollection"]:
            '''(experimental) resourceCollection property.

            Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_collection")
            return typing.cast(typing.Optional["DevOpsGuruInsightSeverityUpgraded.ResourceCollection"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DevOpsGuruInsightSeverityUpgradedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.GroupBy",
        jsii_struct_bases=[],
        name_mapping={"dimensions": "dimensions", "group": "group"},
    )
    class GroupBy:
        def __init__(
            self,
            *,
            dimensions: typing.Optional[typing.Sequence[builtins.str]] = None,
            group: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupBy.

            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group: (experimental) group property. Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                group_by = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.GroupBy(
                    dimensions=["dimensions"],
                    group=["group"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0a5bbaadf1926c8052a8c64dab9218b4dce89273da7ebbe5ae68125803981a9a)
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument group", value=group, expected_type=type_hints["group"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if group is not None:
                self._values["group"] = group

        @builtins.property
        def dimensions(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) group property.

            Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupBy(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.MetricQuery",
        jsii_struct_bases=[],
        name_mapping={"group_by": "groupBy", "metric": "metric"},
    )
    class MetricQuery:
        def __init__(
            self,
            *,
            group_by: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.GroupBy", typing.Dict[builtins.str, typing.Any]]] = None,
            metric: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for MetricQuery.

            :param group_by: (experimental) groupBy property. Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric: (experimental) metric property. Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                metric_query = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.MetricQuery(
                    group_by=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.GroupBy(
                        dimensions=["dimensions"],
                        group=["group"]
                    ),
                    metric=["metric"]
                )
            '''
            if isinstance(group_by, dict):
                group_by = DevOpsGuruInsightSeverityUpgraded.GroupBy(**group_by)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5fecfc6123878680d2fcfdd8a2c1e9be35c28c83da84eb19d6d3ec063d14093b)
                check_type(argname="argument group_by", value=group_by, expected_type=type_hints["group_by"])
                check_type(argname="argument metric", value=metric, expected_type=type_hints["metric"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if group_by is not None:
                self._values["group_by"] = group_by
            if metric is not None:
                self._values["metric"] = metric

        @builtins.property
        def group_by(
            self,
        ) -> typing.Optional["DevOpsGuruInsightSeverityUpgraded.GroupBy"]:
            '''(experimental) groupBy property.

            Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_by")
            return typing.cast(typing.Optional["DevOpsGuruInsightSeverityUpgraded.GroupBy"], result)

        @builtins.property
        def metric(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metric property.

            Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "MetricQuery(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.ReferenceValue",
        jsii_struct_bases=[],
        name_mapping={
            "comparison_operator": "comparisonOperator",
            "datapoints_to_alarm": "datapointsToAlarm",
            "evaluation_period": "evaluationPeriod",
            "threshold": "threshold",
        },
    )
    class ReferenceValue:
        def __init__(
            self,
            *,
            comparison_operator: typing.Optional[typing.Sequence[builtins.str]] = None,
            datapoints_to_alarm: typing.Optional[typing.Sequence[builtins.str]] = None,
            evaluation_period: typing.Optional[typing.Sequence[builtins.str]] = None,
            threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ReferenceValue.

            :param comparison_operator: (experimental) comparisonOperator property. Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datapoints_to_alarm: (experimental) datapointsToAlarm property. Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param evaluation_period: (experimental) evaluationPeriod property. Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param threshold: (experimental) threshold property. Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                reference_value = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.ReferenceValue(
                    comparison_operator=["comparisonOperator"],
                    datapoints_to_alarm=["datapointsToAlarm"],
                    evaluation_period=["evaluationPeriod"],
                    threshold=["threshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ed60a909c8f7a01810d11b39a690970ad128e0fb90524bff6fb8e3bc7b500dd8)
                check_type(argname="argument comparison_operator", value=comparison_operator, expected_type=type_hints["comparison_operator"])
                check_type(argname="argument datapoints_to_alarm", value=datapoints_to_alarm, expected_type=type_hints["datapoints_to_alarm"])
                check_type(argname="argument evaluation_period", value=evaluation_period, expected_type=type_hints["evaluation_period"])
                check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if comparison_operator is not None:
                self._values["comparison_operator"] = comparison_operator
            if datapoints_to_alarm is not None:
                self._values["datapoints_to_alarm"] = datapoints_to_alarm
            if evaluation_period is not None:
                self._values["evaluation_period"] = evaluation_period
            if threshold is not None:
                self._values["threshold"] = threshold

        @builtins.property
        def comparison_operator(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) comparisonOperator property.

            Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comparison_operator")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datapoints_to_alarm(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datapointsToAlarm property.

            Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datapoints_to_alarm")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def evaluation_period(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) evaluationPeriod property.

            Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("evaluation_period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) threshold property.

            Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReferenceValue(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.ResourceCollection",
        jsii_struct_bases=[],
        name_mapping={"cloud_formation": "cloudFormation", "tags": "tags"},
    )
    class ResourceCollection:
        def __init__(
            self,
            *,
            cloud_formation: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.CloudFormation", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruInsightSeverityUpgraded.TagType", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceCollection.

            :param cloud_formation: (experimental) cloudFormation property. Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                resource_collection = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.ResourceCollection(
                    cloud_formation=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.CloudFormation(
                        stack_names=["stackNames"]
                    ),
                    tags=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.TagType(
                        app_boundary_key=["appBoundaryKey"],
                        tag_values=["tagValues"]
                    )]
                )
            '''
            if isinstance(cloud_formation, dict):
                cloud_formation = DevOpsGuruInsightSeverityUpgraded.CloudFormation(**cloud_formation)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8c2fcd132a79ef3ff6d3710d855a98a4f7eea5f5ff08b477d20e83b795a8f387)
                check_type(argname="argument cloud_formation", value=cloud_formation, expected_type=type_hints["cloud_formation"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cloud_formation is not None:
                self._values["cloud_formation"] = cloud_formation
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def cloud_formation(
            self,
        ) -> typing.Optional["DevOpsGuruInsightSeverityUpgraded.CloudFormation"]:
            '''(experimental) cloudFormation property.

            Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cloud_formation")
            return typing.cast(typing.Optional["DevOpsGuruInsightSeverityUpgraded.CloudFormation"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.TagType"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruInsightSeverityUpgraded.TagType"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceCollection(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.SourceDetail",
        jsii_struct_bases=[],
        name_mapping={
            "data_identifiers": "dataIdentifiers",
            "data_source": "dataSource",
            "data_source_detail": "dataSourceDetail",
        },
    )
    class SourceDetail:
        def __init__(
            self,
            *,
            data_identifiers: typing.Optional[typing.Union["DevOpsGuruInsightSeverityUpgraded.DataIdentifiers", typing.Dict[builtins.str, typing.Any]]] = None,
            data_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SourceDetail.

            :param data_identifiers: (experimental) dataIdentifiers property. Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) dataSource property. Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source_detail: (experimental) dataSourceDetail property. Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                source_detail = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.SourceDetail(
                    data_identifiers=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.DataIdentifiers(
                        alarm_condition=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.AlarmCondition(
                            detection_band=["detectionBand"],
                            reference_value=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.ReferenceValue(
                                comparison_operator=["comparisonOperator"],
                                datapoints_to_alarm=["datapointsToAlarm"],
                                evaluation_period=["evaluationPeriod"],
                                threshold=["threshold"]
                            )
                        ),
                        dimensions=[devopsguru_events.DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension(
                            name=["name"],
                            value=["value"]
                        )],
                        metric_display_name=["metricDisplayName"],
                        metric_query=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.MetricQuery(
                            group_by=devopsguru_events.DevOpsGuruInsightSeverityUpgraded.GroupBy(
                                dimensions=["dimensions"],
                                group=["group"]
                            ),
                            metric=["metric"]
                        ),
                        name=["name"],
                        namespace=["namespace"],
                        period=["period"],
                        resource_id=["resourceId"],
                        resource_type=["resourceType"],
                        stat=["stat"],
                        unit=["unit"]
                    ),
                    data_source=["dataSource"],
                    data_source_detail=["dataSourceDetail"]
                )
            '''
            if isinstance(data_identifiers, dict):
                data_identifiers = DevOpsGuruInsightSeverityUpgraded.DataIdentifiers(**data_identifiers)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c097c9c8fe64575b3b8c8428aa460cc68c2659180c32cd338c641dd92024ac68)
                check_type(argname="argument data_identifiers", value=data_identifiers, expected_type=type_hints["data_identifiers"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
                check_type(argname="argument data_source_detail", value=data_source_detail, expected_type=type_hints["data_source_detail"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data_identifiers is not None:
                self._values["data_identifiers"] = data_identifiers
            if data_source is not None:
                self._values["data_source"] = data_source
            if data_source_detail is not None:
                self._values["data_source_detail"] = data_source_detail

        @builtins.property
        def data_identifiers(
            self,
        ) -> typing.Optional["DevOpsGuruInsightSeverityUpgraded.DataIdentifiers"]:
            '''(experimental) dataIdentifiers property.

            Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_identifiers")
            return typing.cast(typing.Optional["DevOpsGuruInsightSeverityUpgraded.DataIdentifiers"], result)

        @builtins.property
        def data_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataSource property.

            Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source_detail(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataSourceDetail property.

            Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source_detail")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SourceDetail(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruInsightSeverityUpgraded.TagType",
        jsii_struct_bases=[],
        name_mapping={"app_boundary_key": "appBoundaryKey", "tag_values": "tagValues"},
    )
    class TagType:
        def __init__(
            self,
            *,
            app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tag.

            :param app_boundary_key: (experimental) appBoundaryKey property. Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_values: (experimental) tagValues property. Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                tag_type = devopsguru_events.DevOpsGuruInsightSeverityUpgraded.TagType(
                    app_boundary_key=["appBoundaryKey"],
                    tag_values=["tagValues"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dcd9fbe902af6c3417a340db13ebeff17cfdf22e5d830c17b079d5e559d47033)
                check_type(argname="argument app_boundary_key", value=app_boundary_key, expected_type=type_hints["app_boundary_key"])
                check_type(argname="argument tag_values", value=tag_values, expected_type=type_hints["tag_values"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if app_boundary_key is not None:
                self._values["app_boundary_key"] = app_boundary_key
            if tag_values is not None:
                self._values["tag_values"] = tag_values

        @builtins.property
        def app_boundary_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) appBoundaryKey property.

            Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("app_boundary_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_values(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagValues property.

            Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_values")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagType(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DevOpsGuruNewAnomalyAssociation(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation",
):
    '''(experimental) EventBridge event pattern for aws.devopsguru@DevOpsGuruNewAnomalyAssociation.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
        
        dev_ops_guru_new_anomaly_association = devopsguru_events.DevOpsGuruNewAnomalyAssociation()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="devOpsGuruNewAnomalyAssociationPattern")
    @builtins.classmethod
    def dev_ops_guru_new_anomaly_association_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewAnomalyAssociation.Anomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        region: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_collection: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for DevOps Guru New Anomaly Association.

        :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param anomalies: (experimental) anomalies property. Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DevOpsGuruNewAnomalyAssociation.DevOpsGuruNewAnomalyAssociationProps(
            account_id=account_id,
            anomalies=anomalies,
            event_metadata=event_metadata,
            insight_description=insight_description,
            insight_id=insight_id,
            insight_name=insight_name,
            insight_type=insight_type,
            insight_url=insight_url,
            message_type=message_type,
            region=region,
            resource_collection=resource_collection,
            start_time=start_time,
            start_time_iso=start_time_iso,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "devOpsGuruNewAnomalyAssociationPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.AlarmCondition",
        jsii_struct_bases=[],
        name_mapping={
            "detection_band": "detectionBand",
            "reference_value": "referenceValue",
        },
    )
    class AlarmCondition:
        def __init__(
            self,
            *,
            detection_band: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_value: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.ReferenceValue", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for AlarmCondition.

            :param detection_band: (experimental) detectionBand property. Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_value: (experimental) referenceValue property. Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                alarm_condition = devopsguru_events.DevOpsGuruNewAnomalyAssociation.AlarmCondition(
                    detection_band=["detectionBand"],
                    reference_value=devopsguru_events.DevOpsGuruNewAnomalyAssociation.ReferenceValue(
                        comparison_operator=["comparisonOperator"],
                        datapoints_to_alarm=["datapointsToAlarm"],
                        evaluation_period=["evaluationPeriod"],
                        threshold=["threshold"]
                    )
                )
            '''
            if isinstance(reference_value, dict):
                reference_value = DevOpsGuruNewAnomalyAssociation.ReferenceValue(**reference_value)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__cf315b709effd01fc42d3c16d2ab98d5f1f861422beb98e92656eb165e5ff21a)
                check_type(argname="argument detection_band", value=detection_band, expected_type=type_hints["detection_band"])
                check_type(argname="argument reference_value", value=reference_value, expected_type=type_hints["reference_value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if detection_band is not None:
                self._values["detection_band"] = detection_band
            if reference_value is not None:
                self._values["reference_value"] = reference_value

        @builtins.property
        def detection_band(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) detectionBand property.

            Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("detection_band")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_value(
            self,
        ) -> typing.Optional["DevOpsGuruNewAnomalyAssociation.ReferenceValue"]:
            '''(experimental) referenceValue property.

            Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reference_value")
            return typing.cast(typing.Optional["DevOpsGuruNewAnomalyAssociation.ReferenceValue"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AlarmCondition(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.Anomaly",
        jsii_struct_bases=[],
        name_mapping={
            "anomaly_resources": "anomalyResources",
            "anomaly_severity": "anomalySeverity",
            "associated_resource_arns": "associatedResourceArns",
            "description": "description",
            "earliest_impact_time": "earliestImpactTime",
            "earliest_impact_time_iso": "earliestImpactTimeIso",
            "end_time": "endTime",
            "end_time_iso": "endTimeIso",
            "id": "id",
            "latest_impact_time": "latestImpactTime",
            "latest_impact_time_iso": "latestImpactTimeIso",
            "limit": "limit",
            "open_time": "openTime",
            "open_time_iso": "openTimeIso",
            "source_details": "sourceDetails",
            "source_metadata": "sourceMetadata",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
            "type": "type",
        },
    )
    class Anomaly:
        def __init__(
            self,
            *,
            anomaly_resources: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewAnomalyAssociation.AnomalyResource", typing.Dict[builtins.str, typing.Any]]]] = None,
            anomaly_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            earliest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            earliest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            limit: typing.Optional[typing.Sequence[builtins.str]] = None,
            open_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            open_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_details: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewAnomalyAssociation.SourceDetail", typing.Dict[builtins.str, typing.Any]]]] = None,
            source_metadata: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Anomaly.

            :param anomaly_resources: (experimental) anomalyResources property. Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param anomaly_severity: (experimental) anomalySeverity property. Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param associated_resource_arns: (experimental) associatedResourceArns property. Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param earliest_impact_time: (experimental) earliestImpactTime property. Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param earliest_impact_time_iso: (experimental) earliestImpactTimeISO property. Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time_iso: (experimental) endTimeISO property. Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_impact_time: (experimental) latestImpactTime property. Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_impact_time_iso: (experimental) latestImpactTimeISO property. Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param limit: (experimental) limit property. Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param open_time: (experimental) openTime property. Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param open_time_iso: (experimental) openTimeISO property. Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_details: (experimental) sourceDetails property. Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_metadata: (experimental) sourceMetadata property. Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly = devopsguru_events.DevOpsGuruNewAnomalyAssociation.Anomaly(
                    anomaly_resources=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.AnomalyResource(
                        name=["name"],
                        type=["type"]
                    )],
                    anomaly_severity=["anomalySeverity"],
                    associated_resource_arns=["associatedResourceArns"],
                    description=["description"],
                    earliest_impact_time=["earliestImpactTime"],
                    earliest_impact_time_iso=["earliestImpactTimeIso"],
                    end_time=["endTime"],
                    end_time_iso=["endTimeIso"],
                    id=["id"],
                    latest_impact_time=["latestImpactTime"],
                    latest_impact_time_iso=["latestImpactTimeIso"],
                    limit=["limit"],
                    open_time=["openTime"],
                    open_time_iso=["openTimeIso"],
                    source_details=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.SourceDetail(
                        data_identifiers=devopsguru_events.DevOpsGuruNewAnomalyAssociation.DataIdentifiers(
                            alarm_condition=devopsguru_events.DevOpsGuruNewAnomalyAssociation.AlarmCondition(
                                detection_band=["detectionBand"],
                                reference_value=devopsguru_events.DevOpsGuruNewAnomalyAssociation.ReferenceValue(
                                    comparison_operator=["comparisonOperator"],
                                    datapoints_to_alarm=["datapointsToAlarm"],
                                    evaluation_period=["evaluationPeriod"],
                                    threshold=["threshold"]
                                )
                            ),
                            dimensions=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.CloudWatchDimension(
                                name=["name"],
                                value=["value"]
                            )],
                            metric_display_name=["metricDisplayName"],
                            metric_query=devopsguru_events.DevOpsGuruNewAnomalyAssociation.MetricQuery(
                                group_by=devopsguru_events.DevOpsGuruNewAnomalyAssociation.GroupBy(
                                    dimensions=["dimensions"],
                                    group=["group"]
                                ),
                                metric=["metric"]
                            ),
                            name=["name"],
                            namespace=["namespace"],
                            period=["period"],
                            resource_id=["resourceId"],
                            resource_type=["resourceType"],
                            stat=["stat"],
                            unit=["unit"]
                        ),
                        data_source=["dataSource"],
                        data_source_detail=["dataSourceDetail"]
                    )],
                    source_metadata=devopsguru_events.DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata(
                        source=["source"],
                        source_resource_arn=["sourceResourceArn"],
                        source_resource_type=["sourceResourceType"]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"],
                    type=["type"]
                )
            '''
            if isinstance(source_metadata, dict):
                source_metadata = DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata(**source_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0ad5bafa563db6cf349abbf23a9c7729a221b604623d0e8d78f94e6999563dc5)
                check_type(argname="argument anomaly_resources", value=anomaly_resources, expected_type=type_hints["anomaly_resources"])
                check_type(argname="argument anomaly_severity", value=anomaly_severity, expected_type=type_hints["anomaly_severity"])
                check_type(argname="argument associated_resource_arns", value=associated_resource_arns, expected_type=type_hints["associated_resource_arns"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument earliest_impact_time", value=earliest_impact_time, expected_type=type_hints["earliest_impact_time"])
                check_type(argname="argument earliest_impact_time_iso", value=earliest_impact_time_iso, expected_type=type_hints["earliest_impact_time_iso"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument end_time_iso", value=end_time_iso, expected_type=type_hints["end_time_iso"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument latest_impact_time", value=latest_impact_time, expected_type=type_hints["latest_impact_time"])
                check_type(argname="argument latest_impact_time_iso", value=latest_impact_time_iso, expected_type=type_hints["latest_impact_time_iso"])
                check_type(argname="argument limit", value=limit, expected_type=type_hints["limit"])
                check_type(argname="argument open_time", value=open_time, expected_type=type_hints["open_time"])
                check_type(argname="argument open_time_iso", value=open_time_iso, expected_type=type_hints["open_time_iso"])
                check_type(argname="argument source_details", value=source_details, expected_type=type_hints["source_details"])
                check_type(argname="argument source_metadata", value=source_metadata, expected_type=type_hints["source_metadata"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if anomaly_resources is not None:
                self._values["anomaly_resources"] = anomaly_resources
            if anomaly_severity is not None:
                self._values["anomaly_severity"] = anomaly_severity
            if associated_resource_arns is not None:
                self._values["associated_resource_arns"] = associated_resource_arns
            if description is not None:
                self._values["description"] = description
            if earliest_impact_time is not None:
                self._values["earliest_impact_time"] = earliest_impact_time
            if earliest_impact_time_iso is not None:
                self._values["earliest_impact_time_iso"] = earliest_impact_time_iso
            if end_time is not None:
                self._values["end_time"] = end_time
            if end_time_iso is not None:
                self._values["end_time_iso"] = end_time_iso
            if id is not None:
                self._values["id"] = id
            if latest_impact_time is not None:
                self._values["latest_impact_time"] = latest_impact_time
            if latest_impact_time_iso is not None:
                self._values["latest_impact_time_iso"] = latest_impact_time_iso
            if limit is not None:
                self._values["limit"] = limit
            if open_time is not None:
                self._values["open_time"] = open_time
            if open_time_iso is not None:
                self._values["open_time_iso"] = open_time_iso
            if source_details is not None:
                self._values["source_details"] = source_details
            if source_metadata is not None:
                self._values["source_metadata"] = source_metadata
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def anomaly_resources(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.AnomalyResource"]]:
            '''(experimental) anomalyResources property.

            Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomaly_resources")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.AnomalyResource"]], result)

        @builtins.property
        def anomaly_severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) anomalySeverity property.

            Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomaly_severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def associated_resource_arns(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) associatedResourceArns property.

            Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("associated_resource_arns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def earliest_impact_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) earliestImpactTime property.

            Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("earliest_impact_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def earliest_impact_time_iso(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) earliestImpactTimeISO property.

            Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("earliest_impact_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTimeISO property.

            Specify an array of string values to match this event if the actual value of endTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_impact_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestImpactTime property.

            Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_impact_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_impact_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestImpactTimeISO property.

            Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_impact_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def limit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) limit property.

            Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("limit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def open_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) openTime property.

            Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("open_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def open_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) openTimeISO property.

            Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("open_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_details(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.SourceDetail"]]:
            '''(experimental) sourceDetails property.

            Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_details")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.SourceDetail"]], result)

        @builtins.property
        def source_metadata(
            self,
        ) -> typing.Optional["DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata"]:
            '''(experimental) sourceMetadata property.

            Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_metadata")
            return typing.cast(typing.Optional["DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Anomaly(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.AnomalyResource",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type"},
    )
    class AnomalyResource:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalyResource.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_resource = devopsguru_events.DevOpsGuruNewAnomalyAssociation.AnomalyResource(
                    name=["name"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5583afcbe2621ec39a0fc508d2ad8afb3634d6589b811166db989fe111e211b2)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalyResource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata",
        jsii_struct_bases=[],
        name_mapping={
            "source": "source",
            "source_resource_arn": "sourceResourceArn",
            "source_resource_type": "sourceResourceType",
        },
    )
    class AnomalySourceMetadata:
        def __init__(
            self,
            *,
            source: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalySourceMetadata.

            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_resource_arn: (experimental) sourceResourceArn property. Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_resource_type: (experimental) sourceResourceType property. Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_source_metadata = devopsguru_events.DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata(
                    source=["source"],
                    source_resource_arn=["sourceResourceArn"],
                    source_resource_type=["sourceResourceType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fc94e923848313ea05196decd149a3901a8d183db9ed19b853efc9f525a31236)
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
                check_type(argname="argument source_resource_type", value=source_resource_type, expected_type=type_hints["source_resource_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if source is not None:
                self._values["source"] = source
            if source_resource_arn is not None:
                self._values["source_resource_arn"] = source_resource_arn
            if source_resource_type is not None:
                self._values["source_resource_type"] = source_resource_type

        @builtins.property
        def source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_resource_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceResourceArn property.

            Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_resource_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceResourceType property.

            Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalySourceMetadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.CloudFormation",
        jsii_struct_bases=[],
        name_mapping={"stack_names": "stackNames"},
    )
    class CloudFormation:
        def __init__(
            self,
            *,
            stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudFormation.

            :param stack_names: (experimental) stackNames property. Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_formation = devopsguru_events.DevOpsGuruNewAnomalyAssociation.CloudFormation(
                    stack_names=["stackNames"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a81daf79235b62674f770dee3345020fd7b1042427a618e7fde0c911df24427d)
                check_type(argname="argument stack_names", value=stack_names, expected_type=type_hints["stack_names"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if stack_names is not None:
                self._values["stack_names"] = stack_names

        @builtins.property
        def stack_names(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stackNames property.

            Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stack_names")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudFormation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.CloudWatchDimension",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "value": "value"},
    )
    class CloudWatchDimension:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudWatchDimension.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_watch_dimension = devopsguru_events.DevOpsGuruNewAnomalyAssociation.CloudWatchDimension(
                    name=["name"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c6de68f3b49d6de194b323afc032a6274dc09eb3bdf54846f94aef4d53a05d5d)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudWatchDimension(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.DataIdentifiers",
        jsii_struct_bases=[],
        name_mapping={
            "alarm_condition": "alarmCondition",
            "dimensions": "dimensions",
            "metric_display_name": "metricDisplayName",
            "metric_query": "metricQuery",
            "name": "name",
            "namespace": "namespace",
            "period": "period",
            "resource_id": "resourceId",
            "resource_type": "resourceType",
            "stat": "stat",
            "unit": "unit",
        },
    )
    class DataIdentifiers:
        def __init__(
            self,
            *,
            alarm_condition: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.AlarmCondition", typing.Dict[builtins.str, typing.Any]]] = None,
            dimensions: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewAnomalyAssociation.CloudWatchDimension", typing.Dict[builtins.str, typing.Any]]]] = None,
            metric_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            metric_query: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.MetricQuery", typing.Dict[builtins.str, typing.Any]]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
            period: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            stat: typing.Optional[typing.Sequence[builtins.str]] = None,
            unit: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DataIdentifiers.

            :param alarm_condition: (experimental) alarmCondition property. Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_display_name: (experimental) metricDisplayName property. Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_query: (experimental) metricQuery property. Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param namespace: (experimental) namespace property. Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param period: (experimental) period property. Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_id: (experimental) ResourceId property. Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_type: (experimental) ResourceType property. Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stat: (experimental) stat property. Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unit: (experimental) unit property. Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                data_identifiers = devopsguru_events.DevOpsGuruNewAnomalyAssociation.DataIdentifiers(
                    alarm_condition=devopsguru_events.DevOpsGuruNewAnomalyAssociation.AlarmCondition(
                        detection_band=["detectionBand"],
                        reference_value=devopsguru_events.DevOpsGuruNewAnomalyAssociation.ReferenceValue(
                            comparison_operator=["comparisonOperator"],
                            datapoints_to_alarm=["datapointsToAlarm"],
                            evaluation_period=["evaluationPeriod"],
                            threshold=["threshold"]
                        )
                    ),
                    dimensions=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.CloudWatchDimension(
                        name=["name"],
                        value=["value"]
                    )],
                    metric_display_name=["metricDisplayName"],
                    metric_query=devopsguru_events.DevOpsGuruNewAnomalyAssociation.MetricQuery(
                        group_by=devopsguru_events.DevOpsGuruNewAnomalyAssociation.GroupBy(
                            dimensions=["dimensions"],
                            group=["group"]
                        ),
                        metric=["metric"]
                    ),
                    name=["name"],
                    namespace=["namespace"],
                    period=["period"],
                    resource_id=["resourceId"],
                    resource_type=["resourceType"],
                    stat=["stat"],
                    unit=["unit"]
                )
            '''
            if isinstance(alarm_condition, dict):
                alarm_condition = DevOpsGuruNewAnomalyAssociation.AlarmCondition(**alarm_condition)
            if isinstance(metric_query, dict):
                metric_query = DevOpsGuruNewAnomalyAssociation.MetricQuery(**metric_query)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__98581ae18966ba5291362328e9ba550ceb73be2e48f4a92214c617aedc2b2869)
                check_type(argname="argument alarm_condition", value=alarm_condition, expected_type=type_hints["alarm_condition"])
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument metric_display_name", value=metric_display_name, expected_type=type_hints["metric_display_name"])
                check_type(argname="argument metric_query", value=metric_query, expected_type=type_hints["metric_query"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
                check_type(argname="argument period", value=period, expected_type=type_hints["period"])
                check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
                check_type(argname="argument stat", value=stat, expected_type=type_hints["stat"])
                check_type(argname="argument unit", value=unit, expected_type=type_hints["unit"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if alarm_condition is not None:
                self._values["alarm_condition"] = alarm_condition
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if metric_display_name is not None:
                self._values["metric_display_name"] = metric_display_name
            if metric_query is not None:
                self._values["metric_query"] = metric_query
            if name is not None:
                self._values["name"] = name
            if namespace is not None:
                self._values["namespace"] = namespace
            if period is not None:
                self._values["period"] = period
            if resource_id is not None:
                self._values["resource_id"] = resource_id
            if resource_type is not None:
                self._values["resource_type"] = resource_type
            if stat is not None:
                self._values["stat"] = stat
            if unit is not None:
                self._values["unit"] = unit

        @builtins.property
        def alarm_condition(
            self,
        ) -> typing.Optional["DevOpsGuruNewAnomalyAssociation.AlarmCondition"]:
            '''(experimental) alarmCondition property.

            Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("alarm_condition")
            return typing.cast(typing.Optional["DevOpsGuruNewAnomalyAssociation.AlarmCondition"], result)

        @builtins.property
        def dimensions(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.CloudWatchDimension"]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.CloudWatchDimension"]], result)

        @builtins.property
        def metric_display_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metricDisplayName property.

            Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_display_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def metric_query(
            self,
        ) -> typing.Optional["DevOpsGuruNewAnomalyAssociation.MetricQuery"]:
            '''(experimental) metricQuery property.

            Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_query")
            return typing.cast(typing.Optional["DevOpsGuruNewAnomalyAssociation.MetricQuery"], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def namespace(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) namespace property.

            Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("namespace")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def period(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) period property.

            Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceId property.

            Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceType property.

            Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stat(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stat property.

            Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stat")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unit property.

            Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataIdentifiers(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.DevOpsGuruNewAnomalyAssociationProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "anomalies": "anomalies",
            "event_metadata": "eventMetadata",
            "insight_description": "insightDescription",
            "insight_id": "insightId",
            "insight_name": "insightName",
            "insight_type": "insightType",
            "insight_url": "insightUrl",
            "message_type": "messageType",
            "region": "region",
            "resource_collection": "resourceCollection",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
        },
    )
    class DevOpsGuruNewAnomalyAssociationProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewAnomalyAssociation.Anomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
            message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            region: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_collection: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.devopsguru@DevOpsGuruNewAnomalyAssociation event.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param anomalies: (experimental) anomalies property. Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                dev_ops_guru_new_anomaly_association_props = devopsguru_events.DevOpsGuruNewAnomalyAssociation.DevOpsGuruNewAnomalyAssociationProps(
                    account_id=["accountId"],
                    anomalies=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.Anomaly(
                        anomaly_resources=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.AnomalyResource(
                            name=["name"],
                            type=["type"]
                        )],
                        anomaly_severity=["anomalySeverity"],
                        associated_resource_arns=["associatedResourceArns"],
                        description=["description"],
                        earliest_impact_time=["earliestImpactTime"],
                        earliest_impact_time_iso=["earliestImpactTimeIso"],
                        end_time=["endTime"],
                        end_time_iso=["endTimeIso"],
                        id=["id"],
                        latest_impact_time=["latestImpactTime"],
                        latest_impact_time_iso=["latestImpactTimeIso"],
                        limit=["limit"],
                        open_time=["openTime"],
                        open_time_iso=["openTimeIso"],
                        source_details=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.SourceDetail(
                            data_identifiers=devopsguru_events.DevOpsGuruNewAnomalyAssociation.DataIdentifiers(
                                alarm_condition=devopsguru_events.DevOpsGuruNewAnomalyAssociation.AlarmCondition(
                                    detection_band=["detectionBand"],
                                    reference_value=devopsguru_events.DevOpsGuruNewAnomalyAssociation.ReferenceValue(
                                        comparison_operator=["comparisonOperator"],
                                        datapoints_to_alarm=["datapointsToAlarm"],
                                        evaluation_period=["evaluationPeriod"],
                                        threshold=["threshold"]
                                    )
                                ),
                                dimensions=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.CloudWatchDimension(
                                    name=["name"],
                                    value=["value"]
                                )],
                                metric_display_name=["metricDisplayName"],
                                metric_query=devopsguru_events.DevOpsGuruNewAnomalyAssociation.MetricQuery(
                                    group_by=devopsguru_events.DevOpsGuruNewAnomalyAssociation.GroupBy(
                                        dimensions=["dimensions"],
                                        group=["group"]
                                    ),
                                    metric=["metric"]
                                ),
                                name=["name"],
                                namespace=["namespace"],
                                period=["period"],
                                resource_id=["resourceId"],
                                resource_type=["resourceType"],
                                stat=["stat"],
                                unit=["unit"]
                            ),
                            data_source=["dataSource"],
                            data_source_detail=["dataSourceDetail"]
                        )],
                        source_metadata=devopsguru_events.DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata(
                            source=["source"],
                            source_resource_arn=["sourceResourceArn"],
                            source_resource_type=["sourceResourceType"]
                        ),
                        start_time=["startTime"],
                        start_time_iso=["startTimeIso"],
                        type=["type"]
                    )],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    insight_description=["insightDescription"],
                    insight_id=["insightId"],
                    insight_name=["insightName"],
                    insight_type=["insightType"],
                    insight_url=["insightUrl"],
                    message_type=["messageType"],
                    region=["region"],
                    resource_collection=devopsguru_events.DevOpsGuruNewAnomalyAssociation.ResourceCollection(
                        cloud_formation=devopsguru_events.DevOpsGuruNewAnomalyAssociation.CloudFormation(
                            stack_names=["stackNames"]
                        ),
                        tags=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.TagType(
                            app_boundary_key=["appBoundaryKey"],
                            tag_values=["tagValues"]
                        )]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(resource_collection, dict):
                resource_collection = DevOpsGuruNewAnomalyAssociation.ResourceCollection(**resource_collection)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b680ff2d439ed032e84d6cd60524b6f5fe5622e5a2ec679ba6de0cd053694071)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument anomalies", value=anomalies, expected_type=type_hints["anomalies"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument insight_description", value=insight_description, expected_type=type_hints["insight_description"])
                check_type(argname="argument insight_id", value=insight_id, expected_type=type_hints["insight_id"])
                check_type(argname="argument insight_name", value=insight_name, expected_type=type_hints["insight_name"])
                check_type(argname="argument insight_type", value=insight_type, expected_type=type_hints["insight_type"])
                check_type(argname="argument insight_url", value=insight_url, expected_type=type_hints["insight_url"])
                check_type(argname="argument message_type", value=message_type, expected_type=type_hints["message_type"])
                check_type(argname="argument region", value=region, expected_type=type_hints["region"])
                check_type(argname="argument resource_collection", value=resource_collection, expected_type=type_hints["resource_collection"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if anomalies is not None:
                self._values["anomalies"] = anomalies
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if insight_description is not None:
                self._values["insight_description"] = insight_description
            if insight_id is not None:
                self._values["insight_id"] = insight_id
            if insight_name is not None:
                self._values["insight_name"] = insight_name
            if insight_type is not None:
                self._values["insight_type"] = insight_type
            if insight_url is not None:
                self._values["insight_url"] = insight_url
            if message_type is not None:
                self._values["message_type"] = message_type
            if region is not None:
                self._values["region"] = region
            if resource_collection is not None:
                self._values["resource_collection"] = resource_collection
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def anomalies(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.Anomaly"]]:
            '''(experimental) anomalies property.

            Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomalies")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.Anomaly"]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def insight_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightDescription property.

            Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightId property.

            Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightName property.

            Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightType property.

            Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightUrl property.

            Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) messageType property.

            Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) region property.

            Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_collection(
            self,
        ) -> typing.Optional["DevOpsGuruNewAnomalyAssociation.ResourceCollection"]:
            '''(experimental) resourceCollection property.

            Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_collection")
            return typing.cast(typing.Optional["DevOpsGuruNewAnomalyAssociation.ResourceCollection"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DevOpsGuruNewAnomalyAssociationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.GroupBy",
        jsii_struct_bases=[],
        name_mapping={"dimensions": "dimensions", "group": "group"},
    )
    class GroupBy:
        def __init__(
            self,
            *,
            dimensions: typing.Optional[typing.Sequence[builtins.str]] = None,
            group: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupBy.

            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group: (experimental) group property. Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                group_by = devopsguru_events.DevOpsGuruNewAnomalyAssociation.GroupBy(
                    dimensions=["dimensions"],
                    group=["group"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2951cee78df3d76d1becc27388b2a607c3d3e0d3a39e72a7d7287608692147cb)
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument group", value=group, expected_type=type_hints["group"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if group is not None:
                self._values["group"] = group

        @builtins.property
        def dimensions(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) group property.

            Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupBy(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.MetricQuery",
        jsii_struct_bases=[],
        name_mapping={"group_by": "groupBy", "metric": "metric"},
    )
    class MetricQuery:
        def __init__(
            self,
            *,
            group_by: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.GroupBy", typing.Dict[builtins.str, typing.Any]]] = None,
            metric: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for MetricQuery.

            :param group_by: (experimental) groupBy property. Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric: (experimental) metric property. Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                metric_query = devopsguru_events.DevOpsGuruNewAnomalyAssociation.MetricQuery(
                    group_by=devopsguru_events.DevOpsGuruNewAnomalyAssociation.GroupBy(
                        dimensions=["dimensions"],
                        group=["group"]
                    ),
                    metric=["metric"]
                )
            '''
            if isinstance(group_by, dict):
                group_by = DevOpsGuruNewAnomalyAssociation.GroupBy(**group_by)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e81f99306890c6e1dfa6dab3bd1d50d548d2004ddebd15d21036f776c3b5f126)
                check_type(argname="argument group_by", value=group_by, expected_type=type_hints["group_by"])
                check_type(argname="argument metric", value=metric, expected_type=type_hints["metric"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if group_by is not None:
                self._values["group_by"] = group_by
            if metric is not None:
                self._values["metric"] = metric

        @builtins.property
        def group_by(
            self,
        ) -> typing.Optional["DevOpsGuruNewAnomalyAssociation.GroupBy"]:
            '''(experimental) groupBy property.

            Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_by")
            return typing.cast(typing.Optional["DevOpsGuruNewAnomalyAssociation.GroupBy"], result)

        @builtins.property
        def metric(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metric property.

            Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "MetricQuery(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.ReferenceValue",
        jsii_struct_bases=[],
        name_mapping={
            "comparison_operator": "comparisonOperator",
            "datapoints_to_alarm": "datapointsToAlarm",
            "evaluation_period": "evaluationPeriod",
            "threshold": "threshold",
        },
    )
    class ReferenceValue:
        def __init__(
            self,
            *,
            comparison_operator: typing.Optional[typing.Sequence[builtins.str]] = None,
            datapoints_to_alarm: typing.Optional[typing.Sequence[builtins.str]] = None,
            evaluation_period: typing.Optional[typing.Sequence[builtins.str]] = None,
            threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ReferenceValue.

            :param comparison_operator: (experimental) comparisonOperator property. Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datapoints_to_alarm: (experimental) datapointsToAlarm property. Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param evaluation_period: (experimental) evaluationPeriod property. Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param threshold: (experimental) threshold property. Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                reference_value = devopsguru_events.DevOpsGuruNewAnomalyAssociation.ReferenceValue(
                    comparison_operator=["comparisonOperator"],
                    datapoints_to_alarm=["datapointsToAlarm"],
                    evaluation_period=["evaluationPeriod"],
                    threshold=["threshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0aade5ef596227e85d7bbafb31aaad620edb402659c97b0cc305a120974cbaa3)
                check_type(argname="argument comparison_operator", value=comparison_operator, expected_type=type_hints["comparison_operator"])
                check_type(argname="argument datapoints_to_alarm", value=datapoints_to_alarm, expected_type=type_hints["datapoints_to_alarm"])
                check_type(argname="argument evaluation_period", value=evaluation_period, expected_type=type_hints["evaluation_period"])
                check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if comparison_operator is not None:
                self._values["comparison_operator"] = comparison_operator
            if datapoints_to_alarm is not None:
                self._values["datapoints_to_alarm"] = datapoints_to_alarm
            if evaluation_period is not None:
                self._values["evaluation_period"] = evaluation_period
            if threshold is not None:
                self._values["threshold"] = threshold

        @builtins.property
        def comparison_operator(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) comparisonOperator property.

            Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comparison_operator")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datapoints_to_alarm(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datapointsToAlarm property.

            Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datapoints_to_alarm")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def evaluation_period(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) evaluationPeriod property.

            Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("evaluation_period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) threshold property.

            Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReferenceValue(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.ResourceCollection",
        jsii_struct_bases=[],
        name_mapping={"cloud_formation": "cloudFormation", "tags": "tags"},
    )
    class ResourceCollection:
        def __init__(
            self,
            *,
            cloud_formation: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.CloudFormation", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewAnomalyAssociation.TagType", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceCollection.

            :param cloud_formation: (experimental) cloudFormation property. Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                resource_collection = devopsguru_events.DevOpsGuruNewAnomalyAssociation.ResourceCollection(
                    cloud_formation=devopsguru_events.DevOpsGuruNewAnomalyAssociation.CloudFormation(
                        stack_names=["stackNames"]
                    ),
                    tags=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.TagType(
                        app_boundary_key=["appBoundaryKey"],
                        tag_values=["tagValues"]
                    )]
                )
            '''
            if isinstance(cloud_formation, dict):
                cloud_formation = DevOpsGuruNewAnomalyAssociation.CloudFormation(**cloud_formation)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__20d0880854cd2ab1ed513cc18ceddedab0a6a4d3bfb769b808601c63b8153651)
                check_type(argname="argument cloud_formation", value=cloud_formation, expected_type=type_hints["cloud_formation"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cloud_formation is not None:
                self._values["cloud_formation"] = cloud_formation
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def cloud_formation(
            self,
        ) -> typing.Optional["DevOpsGuruNewAnomalyAssociation.CloudFormation"]:
            '''(experimental) cloudFormation property.

            Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cloud_formation")
            return typing.cast(typing.Optional["DevOpsGuruNewAnomalyAssociation.CloudFormation"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.TagType"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewAnomalyAssociation.TagType"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceCollection(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.SourceDetail",
        jsii_struct_bases=[],
        name_mapping={
            "data_identifiers": "dataIdentifiers",
            "data_source": "dataSource",
            "data_source_detail": "dataSourceDetail",
        },
    )
    class SourceDetail:
        def __init__(
            self,
            *,
            data_identifiers: typing.Optional[typing.Union["DevOpsGuruNewAnomalyAssociation.DataIdentifiers", typing.Dict[builtins.str, typing.Any]]] = None,
            data_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SourceDetail.

            :param data_identifiers: (experimental) dataIdentifiers property. Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) dataSource property. Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source_detail: (experimental) dataSourceDetail property. Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                source_detail = devopsguru_events.DevOpsGuruNewAnomalyAssociation.SourceDetail(
                    data_identifiers=devopsguru_events.DevOpsGuruNewAnomalyAssociation.DataIdentifiers(
                        alarm_condition=devopsguru_events.DevOpsGuruNewAnomalyAssociation.AlarmCondition(
                            detection_band=["detectionBand"],
                            reference_value=devopsguru_events.DevOpsGuruNewAnomalyAssociation.ReferenceValue(
                                comparison_operator=["comparisonOperator"],
                                datapoints_to_alarm=["datapointsToAlarm"],
                                evaluation_period=["evaluationPeriod"],
                                threshold=["threshold"]
                            )
                        ),
                        dimensions=[devopsguru_events.DevOpsGuruNewAnomalyAssociation.CloudWatchDimension(
                            name=["name"],
                            value=["value"]
                        )],
                        metric_display_name=["metricDisplayName"],
                        metric_query=devopsguru_events.DevOpsGuruNewAnomalyAssociation.MetricQuery(
                            group_by=devopsguru_events.DevOpsGuruNewAnomalyAssociation.GroupBy(
                                dimensions=["dimensions"],
                                group=["group"]
                            ),
                            metric=["metric"]
                        ),
                        name=["name"],
                        namespace=["namespace"],
                        period=["period"],
                        resource_id=["resourceId"],
                        resource_type=["resourceType"],
                        stat=["stat"],
                        unit=["unit"]
                    ),
                    data_source=["dataSource"],
                    data_source_detail=["dataSourceDetail"]
                )
            '''
            if isinstance(data_identifiers, dict):
                data_identifiers = DevOpsGuruNewAnomalyAssociation.DataIdentifiers(**data_identifiers)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__03b79aad2dc2dd565dc7e1274f8798ab89278c329771015aea7f8912c7bef076)
                check_type(argname="argument data_identifiers", value=data_identifiers, expected_type=type_hints["data_identifiers"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
                check_type(argname="argument data_source_detail", value=data_source_detail, expected_type=type_hints["data_source_detail"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data_identifiers is not None:
                self._values["data_identifiers"] = data_identifiers
            if data_source is not None:
                self._values["data_source"] = data_source
            if data_source_detail is not None:
                self._values["data_source_detail"] = data_source_detail

        @builtins.property
        def data_identifiers(
            self,
        ) -> typing.Optional["DevOpsGuruNewAnomalyAssociation.DataIdentifiers"]:
            '''(experimental) dataIdentifiers property.

            Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_identifiers")
            return typing.cast(typing.Optional["DevOpsGuruNewAnomalyAssociation.DataIdentifiers"], result)

        @builtins.property
        def data_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataSource property.

            Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source_detail(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataSourceDetail property.

            Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source_detail")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SourceDetail(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewAnomalyAssociation.TagType",
        jsii_struct_bases=[],
        name_mapping={"app_boundary_key": "appBoundaryKey", "tag_values": "tagValues"},
    )
    class TagType:
        def __init__(
            self,
            *,
            app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tag.

            :param app_boundary_key: (experimental) appBoundaryKey property. Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_values: (experimental) tagValues property. Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                tag_type = devopsguru_events.DevOpsGuruNewAnomalyAssociation.TagType(
                    app_boundary_key=["appBoundaryKey"],
                    tag_values=["tagValues"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__064970b18a6749de69aa84535acf149d3fe277b90f83468abf7776730bab3b0d)
                check_type(argname="argument app_boundary_key", value=app_boundary_key, expected_type=type_hints["app_boundary_key"])
                check_type(argname="argument tag_values", value=tag_values, expected_type=type_hints["tag_values"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if app_boundary_key is not None:
                self._values["app_boundary_key"] = app_boundary_key
            if tag_values is not None:
                self._values["tag_values"] = tag_values

        @builtins.property
        def app_boundary_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) appBoundaryKey property.

            Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("app_boundary_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_values(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagValues property.

            Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_values")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagType(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DevOpsGuruNewInsightOpen(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen",
):
    '''(experimental) EventBridge event pattern for aws.devopsguru@DevOpsGuruNewInsightOpen.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
        
        dev_ops_guru_new_insight_open = devopsguru_events.DevOpsGuruNewInsightOpen()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="devOpsGuruNewInsightOpenPattern")
    @builtins.classmethod
    def dev_ops_guru_new_insight_open_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewInsightOpen.Anomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        region: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_collection: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for DevOps Guru New Insight Open.

        :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param anomalies: (experimental) anomalies property. Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_severity: (experimental) insightSeverity property. Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DevOpsGuruNewInsightOpen.DevOpsGuruNewInsightOpenProps(
            account_id=account_id,
            anomalies=anomalies,
            event_metadata=event_metadata,
            insight_description=insight_description,
            insight_id=insight_id,
            insight_name=insight_name,
            insight_severity=insight_severity,
            insight_type=insight_type,
            insight_url=insight_url,
            message_type=message_type,
            region=region,
            resource_collection=resource_collection,
            start_time=start_time,
            start_time_iso=start_time_iso,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "devOpsGuruNewInsightOpenPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.AlarmCondition",
        jsii_struct_bases=[],
        name_mapping={
            "detection_band": "detectionBand",
            "reference_value": "referenceValue",
        },
    )
    class AlarmCondition:
        def __init__(
            self,
            *,
            detection_band: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_value: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.ReferenceValue", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for AlarmCondition.

            :param detection_band: (experimental) detectionBand property. Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_value: (experimental) referenceValue property. Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                alarm_condition = devopsguru_events.DevOpsGuruNewInsightOpen.AlarmCondition(
                    detection_band=["detectionBand"],
                    reference_value=devopsguru_events.DevOpsGuruNewInsightOpen.ReferenceValue(
                        comparison_operator=["comparisonOperator"],
                        datapoints_to_alarm=["datapointsToAlarm"],
                        evaluation_period=["evaluationPeriod"],
                        threshold=["threshold"]
                    )
                )
            '''
            if isinstance(reference_value, dict):
                reference_value = DevOpsGuruNewInsightOpen.ReferenceValue(**reference_value)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a9e6e8f261332f4ced308a7223be7e827a81ec6c2402d547a553b83c9245e3f6)
                check_type(argname="argument detection_band", value=detection_band, expected_type=type_hints["detection_band"])
                check_type(argname="argument reference_value", value=reference_value, expected_type=type_hints["reference_value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if detection_band is not None:
                self._values["detection_band"] = detection_band
            if reference_value is not None:
                self._values["reference_value"] = reference_value

        @builtins.property
        def detection_band(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) detectionBand property.

            Specify an array of string values to match this event if the actual value of detectionBand is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("detection_band")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_value(
            self,
        ) -> typing.Optional["DevOpsGuruNewInsightOpen.ReferenceValue"]:
            '''(experimental) referenceValue property.

            Specify an array of string values to match this event if the actual value of referenceValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reference_value")
            return typing.cast(typing.Optional["DevOpsGuruNewInsightOpen.ReferenceValue"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AlarmCondition(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.Anomaly",
        jsii_struct_bases=[],
        name_mapping={
            "anomaly_resources": "anomalyResources",
            "anomaly_severity": "anomalySeverity",
            "associated_resource_arns": "associatedResourceArns",
            "description": "description",
            "earliest_impact_time": "earliestImpactTime",
            "earliest_impact_time_iso": "earliestImpactTimeIso",
            "end_time": "endTime",
            "id": "id",
            "latest_impact_time": "latestImpactTime",
            "latest_impact_time_iso": "latestImpactTimeIso",
            "limit": "limit",
            "open_time": "openTime",
            "open_time_iso": "openTimeIso",
            "source_details": "sourceDetails",
            "source_metadata": "sourceMetadata",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
            "type": "type",
        },
    )
    class Anomaly:
        def __init__(
            self,
            *,
            anomaly_resources: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewInsightOpen.AnomalyResource", typing.Dict[builtins.str, typing.Any]]]] = None,
            anomaly_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            earliest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            earliest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            limit: typing.Optional[typing.Sequence[builtins.str]] = None,
            open_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            open_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_details: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewInsightOpen.SourceDetail", typing.Dict[builtins.str, typing.Any]]]] = None,
            source_metadata: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.AnomalySourceMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Anomaly.

            :param anomaly_resources: (experimental) anomalyResources property. Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param anomaly_severity: (experimental) anomalySeverity property. Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param associated_resource_arns: (experimental) associatedResourceArns property. Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param earliest_impact_time: (experimental) earliestImpactTime property. Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param earliest_impact_time_iso: (experimental) earliestImpactTimeISO property. Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_impact_time: (experimental) latestImpactTime property. Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_impact_time_iso: (experimental) latestImpactTimeISO property. Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param limit: (experimental) limit property. Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param open_time: (experimental) openTime property. Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param open_time_iso: (experimental) openTimeISO property. Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_details: (experimental) sourceDetails property. Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_metadata: (experimental) sourceMetadata property. Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly = devopsguru_events.DevOpsGuruNewInsightOpen.Anomaly(
                    anomaly_resources=[devopsguru_events.DevOpsGuruNewInsightOpen.AnomalyResource(
                        name=["name"],
                        type=["type"]
                    )],
                    anomaly_severity=["anomalySeverity"],
                    associated_resource_arns=["associatedResourceArns"],
                    description=["description"],
                    earliest_impact_time=["earliestImpactTime"],
                    earliest_impact_time_iso=["earliestImpactTimeIso"],
                    end_time=["endTime"],
                    id=["id"],
                    latest_impact_time=["latestImpactTime"],
                    latest_impact_time_iso=["latestImpactTimeIso"],
                    limit=["limit"],
                    open_time=["openTime"],
                    open_time_iso=["openTimeIso"],
                    source_details=[devopsguru_events.DevOpsGuruNewInsightOpen.SourceDetail(
                        data_identifiers=devopsguru_events.DevOpsGuruNewInsightOpen.DataIdentifiers(
                            alarm_condition=devopsguru_events.DevOpsGuruNewInsightOpen.AlarmCondition(
                                detection_band=["detectionBand"],
                                reference_value=devopsguru_events.DevOpsGuruNewInsightOpen.ReferenceValue(
                                    comparison_operator=["comparisonOperator"],
                                    datapoints_to_alarm=["datapointsToAlarm"],
                                    evaluation_period=["evaluationPeriod"],
                                    threshold=["threshold"]
                                )
                            ),
                            dimensions=[devopsguru_events.DevOpsGuruNewInsightOpen.CloudWatchDimension(
                                name=["name"],
                                value=["value"]
                            )],
                            metric_display_name=["metricDisplayName"],
                            metric_query=devopsguru_events.DevOpsGuruNewInsightOpen.MetricQuery(
                                group_by=devopsguru_events.DevOpsGuruNewInsightOpen.GroupBy(
                                    dimensions=["dimensions"],
                                    group=["group"]
                                ),
                                metric=["metric"]
                            ),
                            name=["name"],
                            namespace=["namespace"],
                            period=["period"],
                            resource_id=["resourceId"],
                            resource_type=["resourceType"],
                            stat=["stat"],
                            unit=["unit"]
                        ),
                        data_source=["dataSource"],
                        data_source_detail=["dataSourceDetail"]
                    )],
                    source_metadata=devopsguru_events.DevOpsGuruNewInsightOpen.AnomalySourceMetadata(
                        source=["source"],
                        source_resource_arn=["sourceResourceArn"],
                        source_resource_type=["sourceResourceType"]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"],
                    type=["type"]
                )
            '''
            if isinstance(source_metadata, dict):
                source_metadata = DevOpsGuruNewInsightOpen.AnomalySourceMetadata(**source_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8d61d3028c9661a414db4a5337edab210625e5ed864ad98e63f5ba18bb43e4bc)
                check_type(argname="argument anomaly_resources", value=anomaly_resources, expected_type=type_hints["anomaly_resources"])
                check_type(argname="argument anomaly_severity", value=anomaly_severity, expected_type=type_hints["anomaly_severity"])
                check_type(argname="argument associated_resource_arns", value=associated_resource_arns, expected_type=type_hints["associated_resource_arns"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument earliest_impact_time", value=earliest_impact_time, expected_type=type_hints["earliest_impact_time"])
                check_type(argname="argument earliest_impact_time_iso", value=earliest_impact_time_iso, expected_type=type_hints["earliest_impact_time_iso"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument latest_impact_time", value=latest_impact_time, expected_type=type_hints["latest_impact_time"])
                check_type(argname="argument latest_impact_time_iso", value=latest_impact_time_iso, expected_type=type_hints["latest_impact_time_iso"])
                check_type(argname="argument limit", value=limit, expected_type=type_hints["limit"])
                check_type(argname="argument open_time", value=open_time, expected_type=type_hints["open_time"])
                check_type(argname="argument open_time_iso", value=open_time_iso, expected_type=type_hints["open_time_iso"])
                check_type(argname="argument source_details", value=source_details, expected_type=type_hints["source_details"])
                check_type(argname="argument source_metadata", value=source_metadata, expected_type=type_hints["source_metadata"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if anomaly_resources is not None:
                self._values["anomaly_resources"] = anomaly_resources
            if anomaly_severity is not None:
                self._values["anomaly_severity"] = anomaly_severity
            if associated_resource_arns is not None:
                self._values["associated_resource_arns"] = associated_resource_arns
            if description is not None:
                self._values["description"] = description
            if earliest_impact_time is not None:
                self._values["earliest_impact_time"] = earliest_impact_time
            if earliest_impact_time_iso is not None:
                self._values["earliest_impact_time_iso"] = earliest_impact_time_iso
            if end_time is not None:
                self._values["end_time"] = end_time
            if id is not None:
                self._values["id"] = id
            if latest_impact_time is not None:
                self._values["latest_impact_time"] = latest_impact_time
            if latest_impact_time_iso is not None:
                self._values["latest_impact_time_iso"] = latest_impact_time_iso
            if limit is not None:
                self._values["limit"] = limit
            if open_time is not None:
                self._values["open_time"] = open_time
            if open_time_iso is not None:
                self._values["open_time_iso"] = open_time_iso
            if source_details is not None:
                self._values["source_details"] = source_details
            if source_metadata is not None:
                self._values["source_metadata"] = source_metadata
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def anomaly_resources(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewInsightOpen.AnomalyResource"]]:
            '''(experimental) anomalyResources property.

            Specify an array of string values to match this event if the actual value of anomalyResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomaly_resources")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewInsightOpen.AnomalyResource"]], result)

        @builtins.property
        def anomaly_severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) anomalySeverity property.

            Specify an array of string values to match this event if the actual value of anomalySeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomaly_severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def associated_resource_arns(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) associatedResourceArns property.

            Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("associated_resource_arns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def earliest_impact_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) earliestImpactTime property.

            Specify an array of string values to match this event if the actual value of earliestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("earliest_impact_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def earliest_impact_time_iso(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) earliestImpactTimeISO property.

            Specify an array of string values to match this event if the actual value of earliestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("earliest_impact_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_impact_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestImpactTime property.

            Specify an array of string values to match this event if the actual value of latestImpactTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_impact_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_impact_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestImpactTimeISO property.

            Specify an array of string values to match this event if the actual value of latestImpactTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_impact_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def limit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) limit property.

            Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("limit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def open_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) openTime property.

            Specify an array of string values to match this event if the actual value of openTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("open_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def open_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) openTimeISO property.

            Specify an array of string values to match this event if the actual value of openTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("open_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_details(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewInsightOpen.SourceDetail"]]:
            '''(experimental) sourceDetails property.

            Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_details")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewInsightOpen.SourceDetail"]], result)

        @builtins.property
        def source_metadata(
            self,
        ) -> typing.Optional["DevOpsGuruNewInsightOpen.AnomalySourceMetadata"]:
            '''(experimental) sourceMetadata property.

            Specify an array of string values to match this event if the actual value of sourceMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_metadata")
            return typing.cast(typing.Optional["DevOpsGuruNewInsightOpen.AnomalySourceMetadata"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Anomaly(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.AnomalyResource",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type"},
    )
    class AnomalyResource:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalyResource.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_resource = devopsguru_events.DevOpsGuruNewInsightOpen.AnomalyResource(
                    name=["name"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f7934fd5007b700356c3b50dd568e5cdb116d7d43cebb88ee6e265966c7b6b80)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalyResource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.AnomalySourceMetadata",
        jsii_struct_bases=[],
        name_mapping={
            "source": "source",
            "source_resource_arn": "sourceResourceArn",
            "source_resource_type": "sourceResourceType",
        },
    )
    class AnomalySourceMetadata:
        def __init__(
            self,
            *,
            source: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalySourceMetadata.

            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_resource_arn: (experimental) sourceResourceArn property. Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_resource_type: (experimental) sourceResourceType property. Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_source_metadata = devopsguru_events.DevOpsGuruNewInsightOpen.AnomalySourceMetadata(
                    source=["source"],
                    source_resource_arn=["sourceResourceArn"],
                    source_resource_type=["sourceResourceType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a282859cff8ce0d41cf250a739e2afe11d7e0350e5b9a0213528969f7e2adb95)
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument source_resource_arn", value=source_resource_arn, expected_type=type_hints["source_resource_arn"])
                check_type(argname="argument source_resource_type", value=source_resource_type, expected_type=type_hints["source_resource_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if source is not None:
                self._values["source"] = source
            if source_resource_arn is not None:
                self._values["source_resource_arn"] = source_resource_arn
            if source_resource_type is not None:
                self._values["source_resource_type"] = source_resource_type

        @builtins.property
        def source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_resource_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceResourceArn property.

            Specify an array of string values to match this event if the actual value of sourceResourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_resource_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceResourceType property.

            Specify an array of string values to match this event if the actual value of sourceResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalySourceMetadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.CloudFormation",
        jsii_struct_bases=[],
        name_mapping={"stack_names": "stackNames"},
    )
    class CloudFormation:
        def __init__(
            self,
            *,
            stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudFormation.

            :param stack_names: (experimental) stackNames property. Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_formation = devopsguru_events.DevOpsGuruNewInsightOpen.CloudFormation(
                    stack_names=["stackNames"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b814cff5f0f43d5b1fa49a640809178e00e6678654abbc34342310b902950c3b)
                check_type(argname="argument stack_names", value=stack_names, expected_type=type_hints["stack_names"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if stack_names is not None:
                self._values["stack_names"] = stack_names

        @builtins.property
        def stack_names(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stackNames property.

            Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stack_names")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudFormation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.CloudWatchDimension",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "value": "value"},
    )
    class CloudWatchDimension:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudWatchDimension.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_watch_dimension = devopsguru_events.DevOpsGuruNewInsightOpen.CloudWatchDimension(
                    name=["name"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__484460db8640eebb3676ddf1da87d39a13d29461dde914c7ae2dca3fd5c9e6f8)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudWatchDimension(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.DataIdentifiers",
        jsii_struct_bases=[],
        name_mapping={
            "alarm_condition": "alarmCondition",
            "dimensions": "dimensions",
            "metric_display_name": "metricDisplayName",
            "metric_query": "metricQuery",
            "name": "name",
            "namespace": "namespace",
            "period": "period",
            "resource_id": "resourceId",
            "resource_type": "resourceType",
            "stat": "stat",
            "unit": "unit",
        },
    )
    class DataIdentifiers:
        def __init__(
            self,
            *,
            alarm_condition: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.AlarmCondition", typing.Dict[builtins.str, typing.Any]]] = None,
            dimensions: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewInsightOpen.CloudWatchDimension", typing.Dict[builtins.str, typing.Any]]]] = None,
            metric_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            metric_query: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.MetricQuery", typing.Dict[builtins.str, typing.Any]]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
            period: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            stat: typing.Optional[typing.Sequence[builtins.str]] = None,
            unit: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DataIdentifiers.

            :param alarm_condition: (experimental) alarmCondition property. Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_display_name: (experimental) metricDisplayName property. Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_query: (experimental) metricQuery property. Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param namespace: (experimental) namespace property. Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param period: (experimental) period property. Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_id: (experimental) ResourceId property. Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_type: (experimental) ResourceType property. Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stat: (experimental) stat property. Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unit: (experimental) unit property. Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                data_identifiers = devopsguru_events.DevOpsGuruNewInsightOpen.DataIdentifiers(
                    alarm_condition=devopsguru_events.DevOpsGuruNewInsightOpen.AlarmCondition(
                        detection_band=["detectionBand"],
                        reference_value=devopsguru_events.DevOpsGuruNewInsightOpen.ReferenceValue(
                            comparison_operator=["comparisonOperator"],
                            datapoints_to_alarm=["datapointsToAlarm"],
                            evaluation_period=["evaluationPeriod"],
                            threshold=["threshold"]
                        )
                    ),
                    dimensions=[devopsguru_events.DevOpsGuruNewInsightOpen.CloudWatchDimension(
                        name=["name"],
                        value=["value"]
                    )],
                    metric_display_name=["metricDisplayName"],
                    metric_query=devopsguru_events.DevOpsGuruNewInsightOpen.MetricQuery(
                        group_by=devopsguru_events.DevOpsGuruNewInsightOpen.GroupBy(
                            dimensions=["dimensions"],
                            group=["group"]
                        ),
                        metric=["metric"]
                    ),
                    name=["name"],
                    namespace=["namespace"],
                    period=["period"],
                    resource_id=["resourceId"],
                    resource_type=["resourceType"],
                    stat=["stat"],
                    unit=["unit"]
                )
            '''
            if isinstance(alarm_condition, dict):
                alarm_condition = DevOpsGuruNewInsightOpen.AlarmCondition(**alarm_condition)
            if isinstance(metric_query, dict):
                metric_query = DevOpsGuruNewInsightOpen.MetricQuery(**metric_query)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__362b535971c1ed3d175c0b5ef944569ba6fcfe381827c5656f1c7cc211465beb)
                check_type(argname="argument alarm_condition", value=alarm_condition, expected_type=type_hints["alarm_condition"])
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument metric_display_name", value=metric_display_name, expected_type=type_hints["metric_display_name"])
                check_type(argname="argument metric_query", value=metric_query, expected_type=type_hints["metric_query"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
                check_type(argname="argument period", value=period, expected_type=type_hints["period"])
                check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
                check_type(argname="argument stat", value=stat, expected_type=type_hints["stat"])
                check_type(argname="argument unit", value=unit, expected_type=type_hints["unit"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if alarm_condition is not None:
                self._values["alarm_condition"] = alarm_condition
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if metric_display_name is not None:
                self._values["metric_display_name"] = metric_display_name
            if metric_query is not None:
                self._values["metric_query"] = metric_query
            if name is not None:
                self._values["name"] = name
            if namespace is not None:
                self._values["namespace"] = namespace
            if period is not None:
                self._values["period"] = period
            if resource_id is not None:
                self._values["resource_id"] = resource_id
            if resource_type is not None:
                self._values["resource_type"] = resource_type
            if stat is not None:
                self._values["stat"] = stat
            if unit is not None:
                self._values["unit"] = unit

        @builtins.property
        def alarm_condition(
            self,
        ) -> typing.Optional["DevOpsGuruNewInsightOpen.AlarmCondition"]:
            '''(experimental) alarmCondition property.

            Specify an array of string values to match this event if the actual value of alarmCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("alarm_condition")
            return typing.cast(typing.Optional["DevOpsGuruNewInsightOpen.AlarmCondition"], result)

        @builtins.property
        def dimensions(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewInsightOpen.CloudWatchDimension"]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewInsightOpen.CloudWatchDimension"]], result)

        @builtins.property
        def metric_display_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metricDisplayName property.

            Specify an array of string values to match this event if the actual value of metricDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_display_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def metric_query(
            self,
        ) -> typing.Optional["DevOpsGuruNewInsightOpen.MetricQuery"]:
            '''(experimental) metricQuery property.

            Specify an array of string values to match this event if the actual value of metricQuery is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_query")
            return typing.cast(typing.Optional["DevOpsGuruNewInsightOpen.MetricQuery"], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def namespace(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) namespace property.

            Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("namespace")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def period(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) period property.

            Specify an array of string values to match this event if the actual value of period is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceId property.

            Specify an array of string values to match this event if the actual value of ResourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceType property.

            Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stat(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stat property.

            Specify an array of string values to match this event if the actual value of stat is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stat")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unit property.

            Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataIdentifiers(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.DevOpsGuruNewInsightOpenProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "anomalies": "anomalies",
            "event_metadata": "eventMetadata",
            "insight_description": "insightDescription",
            "insight_id": "insightId",
            "insight_name": "insightName",
            "insight_severity": "insightSeverity",
            "insight_type": "insightType",
            "insight_url": "insightUrl",
            "message_type": "messageType",
            "region": "region",
            "resource_collection": "resourceCollection",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
        },
    )
    class DevOpsGuruNewInsightOpenProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewInsightOpen.Anomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
            message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            region: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_collection: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.devopsguru@DevOpsGuruNewInsightOpen event.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param anomalies: (experimental) anomalies property. Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_severity: (experimental) insightSeverity property. Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                dev_ops_guru_new_insight_open_props = devopsguru_events.DevOpsGuruNewInsightOpen.DevOpsGuruNewInsightOpenProps(
                    account_id=["accountId"],
                    anomalies=[devopsguru_events.DevOpsGuruNewInsightOpen.Anomaly(
                        anomaly_resources=[devopsguru_events.DevOpsGuruNewInsightOpen.AnomalyResource(
                            name=["name"],
                            type=["type"]
                        )],
                        anomaly_severity=["anomalySeverity"],
                        associated_resource_arns=["associatedResourceArns"],
                        description=["description"],
                        earliest_impact_time=["earliestImpactTime"],
                        earliest_impact_time_iso=["earliestImpactTimeIso"],
                        end_time=["endTime"],
                        id=["id"],
                        latest_impact_time=["latestImpactTime"],
                        latest_impact_time_iso=["latestImpactTimeIso"],
                        limit=["limit"],
                        open_time=["openTime"],
                        open_time_iso=["openTimeIso"],
                        source_details=[devopsguru_events.DevOpsGuruNewInsightOpen.SourceDetail(
                            data_identifiers=devopsguru_events.DevOpsGuruNewInsightOpen.DataIdentifiers(
                                alarm_condition=devopsguru_events.DevOpsGuruNewInsightOpen.AlarmCondition(
                                    detection_band=["detectionBand"],
                                    reference_value=devopsguru_events.DevOpsGuruNewInsightOpen.ReferenceValue(
                                        comparison_operator=["comparisonOperator"],
                                        datapoints_to_alarm=["datapointsToAlarm"],
                                        evaluation_period=["evaluationPeriod"],
                                        threshold=["threshold"]
                                    )
                                ),
                                dimensions=[devopsguru_events.DevOpsGuruNewInsightOpen.CloudWatchDimension(
                                    name=["name"],
                                    value=["value"]
                                )],
                                metric_display_name=["metricDisplayName"],
                                metric_query=devopsguru_events.DevOpsGuruNewInsightOpen.MetricQuery(
                                    group_by=devopsguru_events.DevOpsGuruNewInsightOpen.GroupBy(
                                        dimensions=["dimensions"],
                                        group=["group"]
                                    ),
                                    metric=["metric"]
                                ),
                                name=["name"],
                                namespace=["namespace"],
                                period=["period"],
                                resource_id=["resourceId"],
                                resource_type=["resourceType"],
                                stat=["stat"],
                                unit=["unit"]
                            ),
                            data_source=["dataSource"],
                            data_source_detail=["dataSourceDetail"]
                        )],
                        source_metadata=devopsguru_events.DevOpsGuruNewInsightOpen.AnomalySourceMetadata(
                            source=["source"],
                            source_resource_arn=["sourceResourceArn"],
                            source_resource_type=["sourceResourceType"]
                        ),
                        start_time=["startTime"],
                        start_time_iso=["startTimeIso"],
                        type=["type"]
                    )],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    insight_description=["insightDescription"],
                    insight_id=["insightId"],
                    insight_name=["insightName"],
                    insight_severity=["insightSeverity"],
                    insight_type=["insightType"],
                    insight_url=["insightUrl"],
                    message_type=["messageType"],
                    region=["region"],
                    resource_collection=devopsguru_events.DevOpsGuruNewInsightOpen.ResourceCollection(
                        cloud_formation=devopsguru_events.DevOpsGuruNewInsightOpen.CloudFormation(
                            stack_names=["stackNames"]
                        ),
                        tags=[devopsguru_events.DevOpsGuruNewInsightOpen.TagType(
                            app_boundary_key=["appBoundaryKey"],
                            tag_values=["tagValues"]
                        )]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(resource_collection, dict):
                resource_collection = DevOpsGuruNewInsightOpen.ResourceCollection(**resource_collection)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__db1098ded44db7591a31565140736b44d06d1abc4572f6ea860e2c7ef0677c6e)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument anomalies", value=anomalies, expected_type=type_hints["anomalies"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument insight_description", value=insight_description, expected_type=type_hints["insight_description"])
                check_type(argname="argument insight_id", value=insight_id, expected_type=type_hints["insight_id"])
                check_type(argname="argument insight_name", value=insight_name, expected_type=type_hints["insight_name"])
                check_type(argname="argument insight_severity", value=insight_severity, expected_type=type_hints["insight_severity"])
                check_type(argname="argument insight_type", value=insight_type, expected_type=type_hints["insight_type"])
                check_type(argname="argument insight_url", value=insight_url, expected_type=type_hints["insight_url"])
                check_type(argname="argument message_type", value=message_type, expected_type=type_hints["message_type"])
                check_type(argname="argument region", value=region, expected_type=type_hints["region"])
                check_type(argname="argument resource_collection", value=resource_collection, expected_type=type_hints["resource_collection"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if anomalies is not None:
                self._values["anomalies"] = anomalies
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if insight_description is not None:
                self._values["insight_description"] = insight_description
            if insight_id is not None:
                self._values["insight_id"] = insight_id
            if insight_name is not None:
                self._values["insight_name"] = insight_name
            if insight_severity is not None:
                self._values["insight_severity"] = insight_severity
            if insight_type is not None:
                self._values["insight_type"] = insight_type
            if insight_url is not None:
                self._values["insight_url"] = insight_url
            if message_type is not None:
                self._values["message_type"] = message_type
            if region is not None:
                self._values["region"] = region
            if resource_collection is not None:
                self._values["resource_collection"] = resource_collection
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def anomalies(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewInsightOpen.Anomaly"]]:
            '''(experimental) anomalies property.

            Specify an array of string values to match this event if the actual value of anomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("anomalies")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewInsightOpen.Anomaly"]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def insight_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightDescription property.

            Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightId property.

            Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightName property.

            Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightSeverity property.

            Specify an array of string values to match this event if the actual value of insightSeverity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightType property.

            Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightUrl property.

            Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) messageType property.

            Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) region property.

            Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_collection(
            self,
        ) -> typing.Optional["DevOpsGuruNewInsightOpen.ResourceCollection"]:
            '''(experimental) resourceCollection property.

            Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_collection")
            return typing.cast(typing.Optional["DevOpsGuruNewInsightOpen.ResourceCollection"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DevOpsGuruNewInsightOpenProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.GroupBy",
        jsii_struct_bases=[],
        name_mapping={"dimensions": "dimensions", "group": "group"},
    )
    class GroupBy:
        def __init__(
            self,
            *,
            dimensions: typing.Optional[typing.Sequence[builtins.str]] = None,
            group: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupBy.

            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group: (experimental) group property. Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                group_by = devopsguru_events.DevOpsGuruNewInsightOpen.GroupBy(
                    dimensions=["dimensions"],
                    group=["group"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4c3801d4a95ca44ec69f612c75f6595eb89fa8321f498b1ccc4f96be8723ca5a)
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument group", value=group, expected_type=type_hints["group"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if group is not None:
                self._values["group"] = group

        @builtins.property
        def dimensions(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) group property.

            Specify an array of string values to match this event if the actual value of group is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupBy(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.MetricQuery",
        jsii_struct_bases=[],
        name_mapping={"group_by": "groupBy", "metric": "metric"},
    )
    class MetricQuery:
        def __init__(
            self,
            *,
            group_by: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.GroupBy", typing.Dict[builtins.str, typing.Any]]] = None,
            metric: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for MetricQuery.

            :param group_by: (experimental) groupBy property. Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric: (experimental) metric property. Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                metric_query = devopsguru_events.DevOpsGuruNewInsightOpen.MetricQuery(
                    group_by=devopsguru_events.DevOpsGuruNewInsightOpen.GroupBy(
                        dimensions=["dimensions"],
                        group=["group"]
                    ),
                    metric=["metric"]
                )
            '''
            if isinstance(group_by, dict):
                group_by = DevOpsGuruNewInsightOpen.GroupBy(**group_by)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b76216f182b08b9dd6f2d1b58030d14b9ac7fff878732b050c172d28fb3afb90)
                check_type(argname="argument group_by", value=group_by, expected_type=type_hints["group_by"])
                check_type(argname="argument metric", value=metric, expected_type=type_hints["metric"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if group_by is not None:
                self._values["group_by"] = group_by
            if metric is not None:
                self._values["metric"] = metric

        @builtins.property
        def group_by(self) -> typing.Optional["DevOpsGuruNewInsightOpen.GroupBy"]:
            '''(experimental) groupBy property.

            Specify an array of string values to match this event if the actual value of groupBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_by")
            return typing.cast(typing.Optional["DevOpsGuruNewInsightOpen.GroupBy"], result)

        @builtins.property
        def metric(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metric property.

            Specify an array of string values to match this event if the actual value of metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "MetricQuery(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.ReferenceValue",
        jsii_struct_bases=[],
        name_mapping={
            "comparison_operator": "comparisonOperator",
            "datapoints_to_alarm": "datapointsToAlarm",
            "evaluation_period": "evaluationPeriod",
            "threshold": "threshold",
        },
    )
    class ReferenceValue:
        def __init__(
            self,
            *,
            comparison_operator: typing.Optional[typing.Sequence[builtins.str]] = None,
            datapoints_to_alarm: typing.Optional[typing.Sequence[builtins.str]] = None,
            evaluation_period: typing.Optional[typing.Sequence[builtins.str]] = None,
            threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ReferenceValue.

            :param comparison_operator: (experimental) comparisonOperator property. Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datapoints_to_alarm: (experimental) datapointsToAlarm property. Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param evaluation_period: (experimental) evaluationPeriod property. Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param threshold: (experimental) threshold property. Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                reference_value = devopsguru_events.DevOpsGuruNewInsightOpen.ReferenceValue(
                    comparison_operator=["comparisonOperator"],
                    datapoints_to_alarm=["datapointsToAlarm"],
                    evaluation_period=["evaluationPeriod"],
                    threshold=["threshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a27b42226195028672a3650b5a44fc9a1d789b43d5cbcf85a6339109b87af078)
                check_type(argname="argument comparison_operator", value=comparison_operator, expected_type=type_hints["comparison_operator"])
                check_type(argname="argument datapoints_to_alarm", value=datapoints_to_alarm, expected_type=type_hints["datapoints_to_alarm"])
                check_type(argname="argument evaluation_period", value=evaluation_period, expected_type=type_hints["evaluation_period"])
                check_type(argname="argument threshold", value=threshold, expected_type=type_hints["threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if comparison_operator is not None:
                self._values["comparison_operator"] = comparison_operator
            if datapoints_to_alarm is not None:
                self._values["datapoints_to_alarm"] = datapoints_to_alarm
            if evaluation_period is not None:
                self._values["evaluation_period"] = evaluation_period
            if threshold is not None:
                self._values["threshold"] = threshold

        @builtins.property
        def comparison_operator(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) comparisonOperator property.

            Specify an array of string values to match this event if the actual value of comparisonOperator is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comparison_operator")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datapoints_to_alarm(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datapointsToAlarm property.

            Specify an array of string values to match this event if the actual value of datapointsToAlarm is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datapoints_to_alarm")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def evaluation_period(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) evaluationPeriod property.

            Specify an array of string values to match this event if the actual value of evaluationPeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("evaluation_period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) threshold property.

            Specify an array of string values to match this event if the actual value of threshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReferenceValue(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.ResourceCollection",
        jsii_struct_bases=[],
        name_mapping={"cloud_formation": "cloudFormation", "tags": "tags"},
    )
    class ResourceCollection:
        def __init__(
            self,
            *,
            cloud_formation: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.CloudFormation", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewInsightOpen.TagType", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceCollection.

            :param cloud_formation: (experimental) cloudFormation property. Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                resource_collection = devopsguru_events.DevOpsGuruNewInsightOpen.ResourceCollection(
                    cloud_formation=devopsguru_events.DevOpsGuruNewInsightOpen.CloudFormation(
                        stack_names=["stackNames"]
                    ),
                    tags=[devopsguru_events.DevOpsGuruNewInsightOpen.TagType(
                        app_boundary_key=["appBoundaryKey"],
                        tag_values=["tagValues"]
                    )]
                )
            '''
            if isinstance(cloud_formation, dict):
                cloud_formation = DevOpsGuruNewInsightOpen.CloudFormation(**cloud_formation)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2e27b1b20ce602a9c2be9003f3f371891975122ca22cb6ccd5580113c5a01c02)
                check_type(argname="argument cloud_formation", value=cloud_formation, expected_type=type_hints["cloud_formation"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cloud_formation is not None:
                self._values["cloud_formation"] = cloud_formation
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def cloud_formation(
            self,
        ) -> typing.Optional["DevOpsGuruNewInsightOpen.CloudFormation"]:
            '''(experimental) cloudFormation property.

            Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cloud_formation")
            return typing.cast(typing.Optional["DevOpsGuruNewInsightOpen.CloudFormation"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewInsightOpen.TagType"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewInsightOpen.TagType"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceCollection(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.SourceDetail",
        jsii_struct_bases=[],
        name_mapping={
            "data_identifiers": "dataIdentifiers",
            "data_source": "dataSource",
            "data_source_detail": "dataSourceDetail",
        },
    )
    class SourceDetail:
        def __init__(
            self,
            *,
            data_identifiers: typing.Optional[typing.Union["DevOpsGuruNewInsightOpen.DataIdentifiers", typing.Dict[builtins.str, typing.Any]]] = None,
            data_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SourceDetail.

            :param data_identifiers: (experimental) dataIdentifiers property. Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) dataSource property. Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source_detail: (experimental) dataSourceDetail property. Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                source_detail = devopsguru_events.DevOpsGuruNewInsightOpen.SourceDetail(
                    data_identifiers=devopsguru_events.DevOpsGuruNewInsightOpen.DataIdentifiers(
                        alarm_condition=devopsguru_events.DevOpsGuruNewInsightOpen.AlarmCondition(
                            detection_band=["detectionBand"],
                            reference_value=devopsguru_events.DevOpsGuruNewInsightOpen.ReferenceValue(
                                comparison_operator=["comparisonOperator"],
                                datapoints_to_alarm=["datapointsToAlarm"],
                                evaluation_period=["evaluationPeriod"],
                                threshold=["threshold"]
                            )
                        ),
                        dimensions=[devopsguru_events.DevOpsGuruNewInsightOpen.CloudWatchDimension(
                            name=["name"],
                            value=["value"]
                        )],
                        metric_display_name=["metricDisplayName"],
                        metric_query=devopsguru_events.DevOpsGuruNewInsightOpen.MetricQuery(
                            group_by=devopsguru_events.DevOpsGuruNewInsightOpen.GroupBy(
                                dimensions=["dimensions"],
                                group=["group"]
                            ),
                            metric=["metric"]
                        ),
                        name=["name"],
                        namespace=["namespace"],
                        period=["period"],
                        resource_id=["resourceId"],
                        resource_type=["resourceType"],
                        stat=["stat"],
                        unit=["unit"]
                    ),
                    data_source=["dataSource"],
                    data_source_detail=["dataSourceDetail"]
                )
            '''
            if isinstance(data_identifiers, dict):
                data_identifiers = DevOpsGuruNewInsightOpen.DataIdentifiers(**data_identifiers)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__355a92694a21c97f86a463f0f9090ee9525acfd4fb5b2f62d003b4cb0134e496)
                check_type(argname="argument data_identifiers", value=data_identifiers, expected_type=type_hints["data_identifiers"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
                check_type(argname="argument data_source_detail", value=data_source_detail, expected_type=type_hints["data_source_detail"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if data_identifiers is not None:
                self._values["data_identifiers"] = data_identifiers
            if data_source is not None:
                self._values["data_source"] = data_source
            if data_source_detail is not None:
                self._values["data_source_detail"] = data_source_detail

        @builtins.property
        def data_identifiers(
            self,
        ) -> typing.Optional["DevOpsGuruNewInsightOpen.DataIdentifiers"]:
            '''(experimental) dataIdentifiers property.

            Specify an array of string values to match this event if the actual value of dataIdentifiers is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_identifiers")
            return typing.cast(typing.Optional["DevOpsGuruNewInsightOpen.DataIdentifiers"], result)

        @builtins.property
        def data_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataSource property.

            Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source_detail(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataSourceDetail property.

            Specify an array of string values to match this event if the actual value of dataSourceDetail is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source_detail")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SourceDetail(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewInsightOpen.TagType",
        jsii_struct_bases=[],
        name_mapping={"app_boundary_key": "appBoundaryKey", "tag_values": "tagValues"},
    )
    class TagType:
        def __init__(
            self,
            *,
            app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tag.

            :param app_boundary_key: (experimental) appBoundaryKey property. Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_values: (experimental) tagValues property. Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                tag_type = devopsguru_events.DevOpsGuruNewInsightOpen.TagType(
                    app_boundary_key=["appBoundaryKey"],
                    tag_values=["tagValues"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9386104d5365c4c0f1bb87adf14bc2b31f0cb1396d8bf95df9446a1cfe9bbae4)
                check_type(argname="argument app_boundary_key", value=app_boundary_key, expected_type=type_hints["app_boundary_key"])
                check_type(argname="argument tag_values", value=tag_values, expected_type=type_hints["tag_values"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if app_boundary_key is not None:
                self._values["app_boundary_key"] = app_boundary_key
            if tag_values is not None:
                self._values["tag_values"] = tag_values

        @builtins.property
        def app_boundary_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) appBoundaryKey property.

            Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("app_boundary_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_values(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagValues property.

            Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_values")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagType(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DevOpsGuruNewRecommendationCreated(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated",
):
    '''(experimental) EventBridge event pattern for aws.devopsguru@DevOpsGuruNewRecommendationCreated.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
        
        dev_ops_guru_new_recommendation_created = devopsguru_events.DevOpsGuruNewRecommendationCreated()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="devOpsGuruNewRecommendationCreatedPattern")
    @builtins.classmethod
    def dev_ops_guru_new_recommendation_created_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        recommendations: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.Recommendation", typing.Dict[builtins.str, typing.Any]]]] = None,
        region: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_collection: typing.Optional[typing.Union["DevOpsGuruNewRecommendationCreated.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for DevOps Guru New Recommendation Created.

        :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param recommendations: (experimental) recommendations property. Specify an array of string values to match this event if the actual value of recommendations is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DevOpsGuruNewRecommendationCreated.DevOpsGuruNewRecommendationCreatedProps(
            account_id=account_id,
            event_metadata=event_metadata,
            insight_description=insight_description,
            insight_id=insight_id,
            insight_name=insight_name,
            insight_type=insight_type,
            insight_url=insight_url,
            message_type=message_type,
            recommendations=recommendations,
            region=region,
            resource_collection=resource_collection,
            start_time=start_time,
            start_time_iso=start_time_iso,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "devOpsGuruNewRecommendationCreatedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.AnomalyResource",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type"},
    )
    class AnomalyResource:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AnomalyResource.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                anomaly_resource = devopsguru_events.DevOpsGuruNewRecommendationCreated.AnomalyResource(
                    name=["name"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__63c5af17c080d3e4263a5cbfac23f02672f4f823acd9110c2aaacd1993746a0c)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnomalyResource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.CloudFormation",
        jsii_struct_bases=[],
        name_mapping={"stack_names": "stackNames"},
    )
    class CloudFormation:
        def __init__(
            self,
            *,
            stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudFormation.

            :param stack_names: (experimental) stackNames property. Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_formation = devopsguru_events.DevOpsGuruNewRecommendationCreated.CloudFormation(
                    stack_names=["stackNames"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c1995894a690011ebdbdffa2554295a156f3f6917be2d0e093d300c06397e32a)
                check_type(argname="argument stack_names", value=stack_names, expected_type=type_hints["stack_names"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if stack_names is not None:
                self._values["stack_names"] = stack_names

        @builtins.property
        def stack_names(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stackNames property.

            Specify an array of string values to match this event if the actual value of stackNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stack_names")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudFormation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.CloudWatchDimension",
        jsii_struct_bases=[],
        name_mapping={"metric_name": "metricName", "namespace": "namespace"},
    )
    class CloudWatchDimension:
        def __init__(
            self,
            *,
            metric_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CloudWatchDimension.

            :param metric_name: (experimental) metricName property. Specify an array of string values to match this event if the actual value of metricName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param namespace: (experimental) namespace property. Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                cloud_watch_dimension = devopsguru_events.DevOpsGuruNewRecommendationCreated.CloudWatchDimension(
                    metric_name=["metricName"],
                    namespace=["namespace"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__06d4d99068afd0d03b1d1d7ca932c58816bac6b94d23a531d1854fffaed228e1)
                check_type(argname="argument metric_name", value=metric_name, expected_type=type_hints["metric_name"])
                check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if metric_name is not None:
                self._values["metric_name"] = metric_name
            if namespace is not None:
                self._values["namespace"] = namespace

        @builtins.property
        def metric_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metricName property.

            Specify an array of string values to match this event if the actual value of metricName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def namespace(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) namespace property.

            Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("namespace")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CloudWatchDimension(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.DevOpsGuruNewRecommendationCreatedProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "event_metadata": "eventMetadata",
            "insight_description": "insightDescription",
            "insight_id": "insightId",
            "insight_name": "insightName",
            "insight_type": "insightType",
            "insight_url": "insightUrl",
            "message_type": "messageType",
            "recommendations": "recommendations",
            "region": "region",
            "resource_collection": "resourceCollection",
            "start_time": "startTime",
            "start_time_iso": "startTimeIso",
        },
    )
    class DevOpsGuruNewRecommendationCreatedProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
            message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            recommendations: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.Recommendation", typing.Dict[builtins.str, typing.Any]]]] = None,
            region: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_collection: typing.Optional[typing.Union["DevOpsGuruNewRecommendationCreated.ResourceCollection", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.devopsguru@DevOpsGuruNewRecommendationCreated event.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param insight_description: (experimental) insightDescription property. Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_id: (experimental) insightId property. Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_name: (experimental) insightName property. Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_type: (experimental) insightType property. Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_url: (experimental) insightUrl property. Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message_type: (experimental) messageType property. Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param recommendations: (experimental) recommendations property. Specify an array of string values to match this event if the actual value of recommendations is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param region: (experimental) region property. Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_collection: (experimental) resourceCollection property. Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time_iso: (experimental) startTimeISO property. Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                dev_ops_guru_new_recommendation_created_props = devopsguru_events.DevOpsGuruNewRecommendationCreated.DevOpsGuruNewRecommendationCreatedProps(
                    account_id=["accountId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    insight_description=["insightDescription"],
                    insight_id=["insightId"],
                    insight_name=["insightName"],
                    insight_type=["insightType"],
                    insight_url=["insightUrl"],
                    message_type=["messageType"],
                    recommendations=[devopsguru_events.DevOpsGuruNewRecommendationCreated.Recommendation(
                        description=["description"],
                        link=["link"],
                        name=["name"],
                        reason=["reason"],
                        related_anomalies=[devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedAnomaly(
                            associated_resource_arns=["associatedResourceArns"],
                            resources=[devopsguru_events.DevOpsGuruNewRecommendationCreated.AnomalyResource(
                                name=["name"],
                                type=["type"]
                            )],
                            source_details=[devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail(
                                cloud_watch_metrics=[devopsguru_events.DevOpsGuruNewRecommendationCreated.CloudWatchDimension(
                                    metric_name=["metricName"],
                                    namespace=["namespace"]
                                )]
                            )]
                        )],
                        related_events=[devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedEvent(
                            name=["name"],
                            resources=[devopsguru_events.DevOpsGuruNewRecommendationCreated.EventResource(
                                name=["name"],
                                type=["type"]
                            )]
                        )]
                    )],
                    region=["region"],
                    resource_collection=devopsguru_events.DevOpsGuruNewRecommendationCreated.ResourceCollection(
                        cloud_formation=devopsguru_events.DevOpsGuruNewRecommendationCreated.CloudFormation(
                            stack_names=["stackNames"]
                        ),
                        tags=[devopsguru_events.DevOpsGuruNewRecommendationCreated.TagType(
                            app_boundary_key=["appBoundaryKey"],
                            tag_values=["tagValues"]
                        )]
                    ),
                    start_time=["startTime"],
                    start_time_iso=["startTimeIso"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(resource_collection, dict):
                resource_collection = DevOpsGuruNewRecommendationCreated.ResourceCollection(**resource_collection)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fb1705c0530e06157f114464a6a643c78b670e093c7db3f5ab76fa8727075f9d)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument insight_description", value=insight_description, expected_type=type_hints["insight_description"])
                check_type(argname="argument insight_id", value=insight_id, expected_type=type_hints["insight_id"])
                check_type(argname="argument insight_name", value=insight_name, expected_type=type_hints["insight_name"])
                check_type(argname="argument insight_type", value=insight_type, expected_type=type_hints["insight_type"])
                check_type(argname="argument insight_url", value=insight_url, expected_type=type_hints["insight_url"])
                check_type(argname="argument message_type", value=message_type, expected_type=type_hints["message_type"])
                check_type(argname="argument recommendations", value=recommendations, expected_type=type_hints["recommendations"])
                check_type(argname="argument region", value=region, expected_type=type_hints["region"])
                check_type(argname="argument resource_collection", value=resource_collection, expected_type=type_hints["resource_collection"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument start_time_iso", value=start_time_iso, expected_type=type_hints["start_time_iso"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if insight_description is not None:
                self._values["insight_description"] = insight_description
            if insight_id is not None:
                self._values["insight_id"] = insight_id
            if insight_name is not None:
                self._values["insight_name"] = insight_name
            if insight_type is not None:
                self._values["insight_type"] = insight_type
            if insight_url is not None:
                self._values["insight_url"] = insight_url
            if message_type is not None:
                self._values["message_type"] = message_type
            if recommendations is not None:
                self._values["recommendations"] = recommendations
            if region is not None:
                self._values["region"] = region
            if resource_collection is not None:
                self._values["resource_collection"] = resource_collection
            if start_time is not None:
                self._values["start_time"] = start_time
            if start_time_iso is not None:
                self._values["start_time_iso"] = start_time_iso

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def insight_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightDescription property.

            Specify an array of string values to match this event if the actual value of insightDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightId property.

            Specify an array of string values to match this event if the actual value of insightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightName property.

            Specify an array of string values to match this event if the actual value of insightName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightType property.

            Specify an array of string values to match this event if the actual value of insightType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insightUrl property.

            Specify an array of string values to match this event if the actual value of insightUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) messageType property.

            Specify an array of string values to match this event if the actual value of messageType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def recommendations(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.Recommendation"]]:
            '''(experimental) recommendations property.

            Specify an array of string values to match this event if the actual value of recommendations is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("recommendations")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.Recommendation"]], result)

        @builtins.property
        def region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) region property.

            Specify an array of string values to match this event if the actual value of region is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_collection(
            self,
        ) -> typing.Optional["DevOpsGuruNewRecommendationCreated.ResourceCollection"]:
            '''(experimental) resourceCollection property.

            Specify an array of string values to match this event if the actual value of resourceCollection is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_collection")
            return typing.cast(typing.Optional["DevOpsGuruNewRecommendationCreated.ResourceCollection"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time_iso(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTimeISO property.

            Specify an array of string values to match this event if the actual value of startTimeISO is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time_iso")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DevOpsGuruNewRecommendationCreatedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.EventResource",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type"},
    )
    class EventResource:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for EventResource.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                event_resource = devopsguru_events.DevOpsGuruNewRecommendationCreated.EventResource(
                    name=["name"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dd24ac711beaacc14e9fe136a86612fbb000911f84dfdda752228751dfdbc9bc)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EventResource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.Recommendation",
        jsii_struct_bases=[],
        name_mapping={
            "description": "description",
            "link": "link",
            "name": "name",
            "reason": "reason",
            "related_anomalies": "relatedAnomalies",
            "related_events": "relatedEvents",
        },
    )
    class Recommendation:
        def __init__(
            self,
            *,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            link: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            related_anomalies: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.RelatedAnomaly", typing.Dict[builtins.str, typing.Any]]]] = None,
            related_events: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.RelatedEvent", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for Recommendation.

            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param link: (experimental) link property. Specify an array of string values to match this event if the actual value of link is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reason: (experimental) reason property. Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param related_anomalies: (experimental) relatedAnomalies property. Specify an array of string values to match this event if the actual value of relatedAnomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param related_events: (experimental) relatedEvents property. Specify an array of string values to match this event if the actual value of relatedEvents is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                recommendation = devopsguru_events.DevOpsGuruNewRecommendationCreated.Recommendation(
                    description=["description"],
                    link=["link"],
                    name=["name"],
                    reason=["reason"],
                    related_anomalies=[devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedAnomaly(
                        associated_resource_arns=["associatedResourceArns"],
                        resources=[devopsguru_events.DevOpsGuruNewRecommendationCreated.AnomalyResource(
                            name=["name"],
                            type=["type"]
                        )],
                        source_details=[devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail(
                            cloud_watch_metrics=[devopsguru_events.DevOpsGuruNewRecommendationCreated.CloudWatchDimension(
                                metric_name=["metricName"],
                                namespace=["namespace"]
                            )]
                        )]
                    )],
                    related_events=[devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedEvent(
                        name=["name"],
                        resources=[devopsguru_events.DevOpsGuruNewRecommendationCreated.EventResource(
                            name=["name"],
                            type=["type"]
                        )]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1d2efe852bcda996899d356623e51fb241a6f161012ac4be16e04d81cf84371e)
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument link", value=link, expected_type=type_hints["link"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument reason", value=reason, expected_type=type_hints["reason"])
                check_type(argname="argument related_anomalies", value=related_anomalies, expected_type=type_hints["related_anomalies"])
                check_type(argname="argument related_events", value=related_events, expected_type=type_hints["related_events"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if description is not None:
                self._values["description"] = description
            if link is not None:
                self._values["link"] = link
            if name is not None:
                self._values["name"] = name
            if reason is not None:
                self._values["reason"] = reason
            if related_anomalies is not None:
                self._values["related_anomalies"] = related_anomalies
            if related_events is not None:
                self._values["related_events"] = related_events

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def link(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) link property.

            Specify an array of string values to match this event if the actual value of link is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("link")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reason property.

            Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def related_anomalies(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.RelatedAnomaly"]]:
            '''(experimental) relatedAnomalies property.

            Specify an array of string values to match this event if the actual value of relatedAnomalies is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("related_anomalies")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.RelatedAnomaly"]], result)

        @builtins.property
        def related_events(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.RelatedEvent"]]:
            '''(experimental) relatedEvents property.

            Specify an array of string values to match this event if the actual value of relatedEvents is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("related_events")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.RelatedEvent"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Recommendation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.RelatedAnomaly",
        jsii_struct_bases=[],
        name_mapping={
            "associated_resource_arns": "associatedResourceArns",
            "resources": "resources",
            "source_details": "sourceDetails",
        },
    )
    class RelatedAnomaly:
        def __init__(
            self,
            *,
            associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
            resources: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.AnomalyResource", typing.Dict[builtins.str, typing.Any]]]] = None,
            source_details: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for RelatedAnomaly.

            :param associated_resource_arns: (experimental) associatedResourceArns property. Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_details: (experimental) sourceDetails property. Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                related_anomaly = devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedAnomaly(
                    associated_resource_arns=["associatedResourceArns"],
                    resources=[devopsguru_events.DevOpsGuruNewRecommendationCreated.AnomalyResource(
                        name=["name"],
                        type=["type"]
                    )],
                    source_details=[devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail(
                        cloud_watch_metrics=[devopsguru_events.DevOpsGuruNewRecommendationCreated.CloudWatchDimension(
                            metric_name=["metricName"],
                            namespace=["namespace"]
                        )]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__919d8c16e350b14566432945d252f08b2bc80c3399faff4a9fdebaed5f1e5494)
                check_type(argname="argument associated_resource_arns", value=associated_resource_arns, expected_type=type_hints["associated_resource_arns"])
                check_type(argname="argument resources", value=resources, expected_type=type_hints["resources"])
                check_type(argname="argument source_details", value=source_details, expected_type=type_hints["source_details"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if associated_resource_arns is not None:
                self._values["associated_resource_arns"] = associated_resource_arns
            if resources is not None:
                self._values["resources"] = resources
            if source_details is not None:
                self._values["source_details"] = source_details

        @builtins.property
        def associated_resource_arns(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) associatedResourceArns property.

            Specify an array of string values to match this event if the actual value of associatedResourceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("associated_resource_arns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resources(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.AnomalyResource"]]:
            '''(experimental) resources property.

            Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resources")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.AnomalyResource"]], result)

        @builtins.property
        def source_details(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail"]]:
            '''(experimental) sourceDetails property.

            Specify an array of string values to match this event if the actual value of sourceDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_details")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RelatedAnomaly(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail",
        jsii_struct_bases=[],
        name_mapping={"cloud_watch_metrics": "cloudWatchMetrics"},
    )
    class RelatedAnomalySourceDetail:
        def __init__(
            self,
            *,
            cloud_watch_metrics: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.CloudWatchDimension", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for RelatedAnomalySourceDetail.

            :param cloud_watch_metrics: (experimental) cloudWatchMetrics property. Specify an array of string values to match this event if the actual value of cloudWatchMetrics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                related_anomaly_source_detail = devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail(
                    cloud_watch_metrics=[devopsguru_events.DevOpsGuruNewRecommendationCreated.CloudWatchDimension(
                        metric_name=["metricName"],
                        namespace=["namespace"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d645d63d496ef96eae53812321143619431427521e7e096af9e5b4f48caa02cd)
                check_type(argname="argument cloud_watch_metrics", value=cloud_watch_metrics, expected_type=type_hints["cloud_watch_metrics"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cloud_watch_metrics is not None:
                self._values["cloud_watch_metrics"] = cloud_watch_metrics

        @builtins.property
        def cloud_watch_metrics(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.CloudWatchDimension"]]:
            '''(experimental) cloudWatchMetrics property.

            Specify an array of string values to match this event if the actual value of cloudWatchMetrics is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cloud_watch_metrics")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.CloudWatchDimension"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RelatedAnomalySourceDetail(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.RelatedEvent",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "resources": "resources"},
    )
    class RelatedEvent:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            resources: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.EventResource", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for RelatedEvent.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                related_event = devopsguru_events.DevOpsGuruNewRecommendationCreated.RelatedEvent(
                    name=["name"],
                    resources=[devopsguru_events.DevOpsGuruNewRecommendationCreated.EventResource(
                        name=["name"],
                        type=["type"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3b3c52a17d5d31c7b9c398c49999e2845153ccfbd877bc219b9b7ba0b69d3282)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument resources", value=resources, expected_type=type_hints["resources"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if resources is not None:
                self._values["resources"] = resources

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resources(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.EventResource"]]:
            '''(experimental) resources property.

            Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resources")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.EventResource"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RelatedEvent(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.ResourceCollection",
        jsii_struct_bases=[],
        name_mapping={"cloud_formation": "cloudFormation", "tags": "tags"},
    )
    class ResourceCollection:
        def __init__(
            self,
            *,
            cloud_formation: typing.Optional[typing.Union["DevOpsGuruNewRecommendationCreated.CloudFormation", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["DevOpsGuruNewRecommendationCreated.TagType", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceCollection.

            :param cloud_formation: (experimental) cloudFormation property. Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                resource_collection = devopsguru_events.DevOpsGuruNewRecommendationCreated.ResourceCollection(
                    cloud_formation=devopsguru_events.DevOpsGuruNewRecommendationCreated.CloudFormation(
                        stack_names=["stackNames"]
                    ),
                    tags=[devopsguru_events.DevOpsGuruNewRecommendationCreated.TagType(
                        app_boundary_key=["appBoundaryKey"],
                        tag_values=["tagValues"]
                    )]
                )
            '''
            if isinstance(cloud_formation, dict):
                cloud_formation = DevOpsGuruNewRecommendationCreated.CloudFormation(**cloud_formation)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f3d65f756ab5a5b30717fe4dec82e057847c5a5fe19ccaf5602474dfd4faed89)
                check_type(argname="argument cloud_formation", value=cloud_formation, expected_type=type_hints["cloud_formation"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cloud_formation is not None:
                self._values["cloud_formation"] = cloud_formation
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def cloud_formation(
            self,
        ) -> typing.Optional["DevOpsGuruNewRecommendationCreated.CloudFormation"]:
            '''(experimental) cloudFormation property.

            Specify an array of string values to match this event if the actual value of cloudFormation is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cloud_formation")
            return typing.cast(typing.Optional["DevOpsGuruNewRecommendationCreated.CloudFormation"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.TagType"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["DevOpsGuruNewRecommendationCreated.TagType"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceCollection(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_devopsguru.events.DevOpsGuruNewRecommendationCreated.TagType",
        jsii_struct_bases=[],
        name_mapping={"app_boundary_key": "appBoundaryKey", "tag_values": "tagValues"},
    )
    class TagType:
        def __init__(
            self,
            *,
            app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tag.

            :param app_boundary_key: (experimental) appBoundaryKey property. Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_values: (experimental) tagValues property. Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_devopsguru import events as devopsguru_events
                
                tag_type = devopsguru_events.DevOpsGuruNewRecommendationCreated.TagType(
                    app_boundary_key=["appBoundaryKey"],
                    tag_values=["tagValues"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fabd7d0896ad884a5eb8505f1310962daf32b493572958953fb7d8da0f56cd0b)
                check_type(argname="argument app_boundary_key", value=app_boundary_key, expected_type=type_hints["app_boundary_key"])
                check_type(argname="argument tag_values", value=tag_values, expected_type=type_hints["tag_values"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if app_boundary_key is not None:
                self._values["app_boundary_key"] = app_boundary_key
            if tag_values is not None:
                self._values["tag_values"] = tag_values

        @builtins.property
        def app_boundary_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) appBoundaryKey property.

            Specify an array of string values to match this event if the actual value of appBoundaryKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("app_boundary_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_values(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagValues property.

            Specify an array of string values to match this event if the actual value of tagValues is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_values")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagType(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "DevOpsGuruInsightClosed",
    "DevOpsGuruInsightSeverityUpgraded",
    "DevOpsGuruNewAnomalyAssociation",
    "DevOpsGuruNewInsightOpen",
    "DevOpsGuruNewRecommendationCreated",
]

publication.publish()

def _typecheckingstub__cb4ebccfba3ebdec9ccabdf4506199db6df2320eb7b18d04209f5c5edb8014ed(
    *,
    detection_band: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_value: typing.Optional[typing.Union[DevOpsGuruInsightClosed.ReferenceValue, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__21f78e6c10eb0b32168f600c9513887e332d85ab4bd680093f4db7c5cafa5421(
    *,
    anomaly_resources: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightClosed.AnomalyResource, typing.Dict[builtins.str, typing.Any]]]] = None,
    anomaly_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
    close_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    close_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    earliest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    earliest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    limit: typing.Optional[typing.Sequence[builtins.str]] = None,
    open_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    open_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_details: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightClosed.SourceDetail, typing.Dict[builtins.str, typing.Any]]]] = None,
    source_metadata: typing.Optional[typing.Union[DevOpsGuruInsightClosed.AnomalySourceMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__761a1eb2a54ae9ca80c19e121cb4890ef099427bfb4e15d7dcb440006d91d7fd(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ad272b98ed33b3e7fc2afc49393c0f4d499213135e3a96a8e7c29a232e43af5(
    *,
    source: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c7db278ff1a38c3af797d35811711778a325006ef8e8ba58a4bc8592fb4a0518(
    *,
    stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e88d72d2c07b952b078f785273a00c939e68777d5feb282bd87c65cfc28a4b78(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9d7ad7b5943453201143a4a430367df3cf437576ae8081207d762eb94bb85734(
    *,
    alarm_condition: typing.Optional[typing.Union[DevOpsGuruInsightClosed.AlarmCondition, typing.Dict[builtins.str, typing.Any]]] = None,
    dimensions: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightClosed.CloudWatchDimension, typing.Dict[builtins.str, typing.Any]]]] = None,
    metric_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    metric_query: typing.Optional[typing.Union[DevOpsGuruInsightClosed.MetricQuery, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
    period: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    stat: typing.Optional[typing.Sequence[builtins.str]] = None,
    unit: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6abdbb250a44045137c4308b7b4a5d7eb630a82066e1976f712fd8bf08d9ec60(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    anomalies: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightClosed.Anomaly, typing.Dict[builtins.str, typing.Any]]]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
    message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    region: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_collection: typing.Optional[typing.Union[DevOpsGuruInsightClosed.ResourceCollection, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__853c444a332dd25670582ca2ce061e648fdb54662273c0e0c67fe5094087ef89(
    *,
    dimensions: typing.Optional[typing.Sequence[builtins.str]] = None,
    group: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f342bfaaa440e88d8ccab29ba37648c5aa5c832b634236caf25f188094a62a6(
    *,
    group_by: typing.Optional[typing.Union[DevOpsGuruInsightClosed.GroupBy, typing.Dict[builtins.str, typing.Any]]] = None,
    metric: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__571a1a574cec310f4999094fdad96edc556d398ce15c34be05fcc577bcf2ebab(
    *,
    comparison_operator: typing.Optional[typing.Sequence[builtins.str]] = None,
    datapoints_to_alarm: typing.Optional[typing.Sequence[builtins.str]] = None,
    evaluation_period: typing.Optional[typing.Sequence[builtins.str]] = None,
    threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0cf21082a870ee70430024bd50a4181ed8e0965872a9e08fb4a03054c88e6dae(
    *,
    cloud_formation: typing.Optional[typing.Union[DevOpsGuruInsightClosed.CloudFormation, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightClosed.TagType, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b2b25b8c5a110d3b9a2b521f9856f4ffac71373d8d987e48b5cee1f158a09da(
    *,
    data_identifiers: typing.Optional[typing.Union[DevOpsGuruInsightClosed.DataIdentifiers, typing.Dict[builtins.str, typing.Any]]] = None,
    data_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05718688a555c4571a3300ca4b94d089b27dfa3d3267061678d95a4a641625cc(
    *,
    app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba706a8829ef41a1abe88afea69457c9a14b9b73eda1e833b5d3c0645f651aff(
    *,
    detection_band: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_value: typing.Optional[typing.Union[DevOpsGuruInsightSeverityUpgraded.ReferenceValue, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__020c3625e5c50bb12d53f0e736192664b638d831f75d6a011b109bbaf0e1c0f6(
    *,
    anomaly_resources: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightSeverityUpgraded.AnomalyResource, typing.Dict[builtins.str, typing.Any]]]] = None,
    anomaly_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    earliest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    earliest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    limit: typing.Optional[typing.Sequence[builtins.str]] = None,
    open_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    open_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_details: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightSeverityUpgraded.SourceDetail, typing.Dict[builtins.str, typing.Any]]]] = None,
    source_metadata: typing.Optional[typing.Union[DevOpsGuruInsightSeverityUpgraded.AnomalySourceMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb65e336abf0100acf5618faeeac78db1bbb2c5278f29eae268b8bbf2a02a308(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c6eb939fd6b85cda4748540afe75dcf0e33389cb44522122ff8c8b7e27b7d5e5(
    *,
    source: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__453ea0b482897141b9487d0b535b38f13f21ad26276d6215545a1299ab7a0741(
    *,
    stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__436e753aa0eceb4b1b18c56ec2e9ad56beab3df19a8b6c244d4f6df4427c8cde(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__801111867e4015519688c31df6ffb88a096c7190cfd1b5a64fbbf55c439f4bbe(
    *,
    alarm_condition: typing.Optional[typing.Union[DevOpsGuruInsightSeverityUpgraded.AlarmCondition, typing.Dict[builtins.str, typing.Any]]] = None,
    dimensions: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightSeverityUpgraded.CloudWatchDimension, typing.Dict[builtins.str, typing.Any]]]] = None,
    metric_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    metric_query: typing.Optional[typing.Union[DevOpsGuruInsightSeverityUpgraded.MetricQuery, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
    period: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    stat: typing.Optional[typing.Sequence[builtins.str]] = None,
    unit: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__679d5a75e9de46894f2716a26108a5bbdbf5e1ff5ef59d271d415942f3932dbc(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    anomalies: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightSeverityUpgraded.Anomaly, typing.Dict[builtins.str, typing.Any]]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
    message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    region: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_collection: typing.Optional[typing.Union[DevOpsGuruInsightSeverityUpgraded.ResourceCollection, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a5bbaadf1926c8052a8c64dab9218b4dce89273da7ebbe5ae68125803981a9a(
    *,
    dimensions: typing.Optional[typing.Sequence[builtins.str]] = None,
    group: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5fecfc6123878680d2fcfdd8a2c1e9be35c28c83da84eb19d6d3ec063d14093b(
    *,
    group_by: typing.Optional[typing.Union[DevOpsGuruInsightSeverityUpgraded.GroupBy, typing.Dict[builtins.str, typing.Any]]] = None,
    metric: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed60a909c8f7a01810d11b39a690970ad128e0fb90524bff6fb8e3bc7b500dd8(
    *,
    comparison_operator: typing.Optional[typing.Sequence[builtins.str]] = None,
    datapoints_to_alarm: typing.Optional[typing.Sequence[builtins.str]] = None,
    evaluation_period: typing.Optional[typing.Sequence[builtins.str]] = None,
    threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c2fcd132a79ef3ff6d3710d855a98a4f7eea5f5ff08b477d20e83b795a8f387(
    *,
    cloud_formation: typing.Optional[typing.Union[DevOpsGuruInsightSeverityUpgraded.CloudFormation, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruInsightSeverityUpgraded.TagType, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c097c9c8fe64575b3b8c8428aa460cc68c2659180c32cd338c641dd92024ac68(
    *,
    data_identifiers: typing.Optional[typing.Union[DevOpsGuruInsightSeverityUpgraded.DataIdentifiers, typing.Dict[builtins.str, typing.Any]]] = None,
    data_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dcd9fbe902af6c3417a340db13ebeff17cfdf22e5d830c17b079d5e559d47033(
    *,
    app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf315b709effd01fc42d3c16d2ab98d5f1f861422beb98e92656eb165e5ff21a(
    *,
    detection_band: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_value: typing.Optional[typing.Union[DevOpsGuruNewAnomalyAssociation.ReferenceValue, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ad5bafa563db6cf349abbf23a9c7729a221b604623d0e8d78f94e6999563dc5(
    *,
    anomaly_resources: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewAnomalyAssociation.AnomalyResource, typing.Dict[builtins.str, typing.Any]]]] = None,
    anomaly_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    earliest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    earliest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    limit: typing.Optional[typing.Sequence[builtins.str]] = None,
    open_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    open_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_details: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewAnomalyAssociation.SourceDetail, typing.Dict[builtins.str, typing.Any]]]] = None,
    source_metadata: typing.Optional[typing.Union[DevOpsGuruNewAnomalyAssociation.AnomalySourceMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5583afcbe2621ec39a0fc508d2ad8afb3634d6589b811166db989fe111e211b2(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc94e923848313ea05196decd149a3901a8d183db9ed19b853efc9f525a31236(
    *,
    source: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a81daf79235b62674f770dee3345020fd7b1042427a618e7fde0c911df24427d(
    *,
    stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c6de68f3b49d6de194b323afc032a6274dc09eb3bdf54846f94aef4d53a05d5d(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98581ae18966ba5291362328e9ba550ceb73be2e48f4a92214c617aedc2b2869(
    *,
    alarm_condition: typing.Optional[typing.Union[DevOpsGuruNewAnomalyAssociation.AlarmCondition, typing.Dict[builtins.str, typing.Any]]] = None,
    dimensions: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewAnomalyAssociation.CloudWatchDimension, typing.Dict[builtins.str, typing.Any]]]] = None,
    metric_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    metric_query: typing.Optional[typing.Union[DevOpsGuruNewAnomalyAssociation.MetricQuery, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
    period: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    stat: typing.Optional[typing.Sequence[builtins.str]] = None,
    unit: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b680ff2d439ed032e84d6cd60524b6f5fe5622e5a2ec679ba6de0cd053694071(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    anomalies: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewAnomalyAssociation.Anomaly, typing.Dict[builtins.str, typing.Any]]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
    message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    region: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_collection: typing.Optional[typing.Union[DevOpsGuruNewAnomalyAssociation.ResourceCollection, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2951cee78df3d76d1becc27388b2a607c3d3e0d3a39e72a7d7287608692147cb(
    *,
    dimensions: typing.Optional[typing.Sequence[builtins.str]] = None,
    group: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e81f99306890c6e1dfa6dab3bd1d50d548d2004ddebd15d21036f776c3b5f126(
    *,
    group_by: typing.Optional[typing.Union[DevOpsGuruNewAnomalyAssociation.GroupBy, typing.Dict[builtins.str, typing.Any]]] = None,
    metric: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0aade5ef596227e85d7bbafb31aaad620edb402659c97b0cc305a120974cbaa3(
    *,
    comparison_operator: typing.Optional[typing.Sequence[builtins.str]] = None,
    datapoints_to_alarm: typing.Optional[typing.Sequence[builtins.str]] = None,
    evaluation_period: typing.Optional[typing.Sequence[builtins.str]] = None,
    threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__20d0880854cd2ab1ed513cc18ceddedab0a6a4d3bfb769b808601c63b8153651(
    *,
    cloud_formation: typing.Optional[typing.Union[DevOpsGuruNewAnomalyAssociation.CloudFormation, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewAnomalyAssociation.TagType, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03b79aad2dc2dd565dc7e1274f8798ab89278c329771015aea7f8912c7bef076(
    *,
    data_identifiers: typing.Optional[typing.Union[DevOpsGuruNewAnomalyAssociation.DataIdentifiers, typing.Dict[builtins.str, typing.Any]]] = None,
    data_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__064970b18a6749de69aa84535acf149d3fe277b90f83468abf7776730bab3b0d(
    *,
    app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a9e6e8f261332f4ced308a7223be7e827a81ec6c2402d547a553b83c9245e3f6(
    *,
    detection_band: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_value: typing.Optional[typing.Union[DevOpsGuruNewInsightOpen.ReferenceValue, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d61d3028c9661a414db4a5337edab210625e5ed864ad98e63f5ba18bb43e4bc(
    *,
    anomaly_resources: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewInsightOpen.AnomalyResource, typing.Dict[builtins.str, typing.Any]]]] = None,
    anomaly_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    earliest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    earliest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_impact_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_impact_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    limit: typing.Optional[typing.Sequence[builtins.str]] = None,
    open_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    open_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_details: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewInsightOpen.SourceDetail, typing.Dict[builtins.str, typing.Any]]]] = None,
    source_metadata: typing.Optional[typing.Union[DevOpsGuruNewInsightOpen.AnomalySourceMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7934fd5007b700356c3b50dd568e5cdb116d7d43cebb88ee6e265966c7b6b80(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a282859cff8ce0d41cf250a739e2afe11d7e0350e5b9a0213528969f7e2adb95(
    *,
    source: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b814cff5f0f43d5b1fa49a640809178e00e6678654abbc34342310b902950c3b(
    *,
    stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__484460db8640eebb3676ddf1da87d39a13d29461dde914c7ae2dca3fd5c9e6f8(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__362b535971c1ed3d175c0b5ef944569ba6fcfe381827c5656f1c7cc211465beb(
    *,
    alarm_condition: typing.Optional[typing.Union[DevOpsGuruNewInsightOpen.AlarmCondition, typing.Dict[builtins.str, typing.Any]]] = None,
    dimensions: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewInsightOpen.CloudWatchDimension, typing.Dict[builtins.str, typing.Any]]]] = None,
    metric_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    metric_query: typing.Optional[typing.Union[DevOpsGuruNewInsightOpen.MetricQuery, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
    period: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    stat: typing.Optional[typing.Sequence[builtins.str]] = None,
    unit: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db1098ded44db7591a31565140736b44d06d1abc4572f6ea860e2c7ef0677c6e(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    anomalies: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewInsightOpen.Anomaly, typing.Dict[builtins.str, typing.Any]]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
    message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    region: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_collection: typing.Optional[typing.Union[DevOpsGuruNewInsightOpen.ResourceCollection, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c3801d4a95ca44ec69f612c75f6595eb89fa8321f498b1ccc4f96be8723ca5a(
    *,
    dimensions: typing.Optional[typing.Sequence[builtins.str]] = None,
    group: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b76216f182b08b9dd6f2d1b58030d14b9ac7fff878732b050c172d28fb3afb90(
    *,
    group_by: typing.Optional[typing.Union[DevOpsGuruNewInsightOpen.GroupBy, typing.Dict[builtins.str, typing.Any]]] = None,
    metric: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a27b42226195028672a3650b5a44fc9a1d789b43d5cbcf85a6339109b87af078(
    *,
    comparison_operator: typing.Optional[typing.Sequence[builtins.str]] = None,
    datapoints_to_alarm: typing.Optional[typing.Sequence[builtins.str]] = None,
    evaluation_period: typing.Optional[typing.Sequence[builtins.str]] = None,
    threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e27b1b20ce602a9c2be9003f3f371891975122ca22cb6ccd5580113c5a01c02(
    *,
    cloud_formation: typing.Optional[typing.Union[DevOpsGuruNewInsightOpen.CloudFormation, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewInsightOpen.TagType, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__355a92694a21c97f86a463f0f9090ee9525acfd4fb5b2f62d003b4cb0134e496(
    *,
    data_identifiers: typing.Optional[typing.Union[DevOpsGuruNewInsightOpen.DataIdentifiers, typing.Dict[builtins.str, typing.Any]]] = None,
    data_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source_detail: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9386104d5365c4c0f1bb87adf14bc2b31f0cb1396d8bf95df9446a1cfe9bbae4(
    *,
    app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__63c5af17c080d3e4263a5cbfac23f02672f4f823acd9110c2aaacd1993746a0c(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c1995894a690011ebdbdffa2554295a156f3f6917be2d0e093d300c06397e32a(
    *,
    stack_names: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__06d4d99068afd0d03b1d1d7ca932c58816bac6b94d23a531d1854fffaed228e1(
    *,
    metric_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb1705c0530e06157f114464a6a643c78b670e093c7db3f5ab76fa8727075f9d(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    insight_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_url: typing.Optional[typing.Sequence[builtins.str]] = None,
    message_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    recommendations: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewRecommendationCreated.Recommendation, typing.Dict[builtins.str, typing.Any]]]] = None,
    region: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_collection: typing.Optional[typing.Union[DevOpsGuruNewRecommendationCreated.ResourceCollection, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time_iso: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd24ac711beaacc14e9fe136a86612fbb000911f84dfdda752228751dfdbc9bc(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d2efe852bcda996899d356623e51fb241a6f161012ac4be16e04d81cf84371e(
    *,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    link: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    related_anomalies: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewRecommendationCreated.RelatedAnomaly, typing.Dict[builtins.str, typing.Any]]]] = None,
    related_events: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewRecommendationCreated.RelatedEvent, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__919d8c16e350b14566432945d252f08b2bc80c3399faff4a9fdebaed5f1e5494(
    *,
    associated_resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
    resources: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewRecommendationCreated.AnomalyResource, typing.Dict[builtins.str, typing.Any]]]] = None,
    source_details: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewRecommendationCreated.RelatedAnomalySourceDetail, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d645d63d496ef96eae53812321143619431427521e7e096af9e5b4f48caa02cd(
    *,
    cloud_watch_metrics: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewRecommendationCreated.CloudWatchDimension, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b3c52a17d5d31c7b9c398c49999e2845153ccfbd877bc219b9b7ba0b69d3282(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    resources: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewRecommendationCreated.EventResource, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f3d65f756ab5a5b30717fe4dec82e057847c5a5fe19ccaf5602474dfd4faed89(
    *,
    cloud_formation: typing.Optional[typing.Union[DevOpsGuruNewRecommendationCreated.CloudFormation, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[DevOpsGuruNewRecommendationCreated.TagType, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fabd7d0896ad884a5eb8505f1310962daf32b493572958953fb7d8da0f56cd0b(
    *,
    app_boundary_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_values: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
