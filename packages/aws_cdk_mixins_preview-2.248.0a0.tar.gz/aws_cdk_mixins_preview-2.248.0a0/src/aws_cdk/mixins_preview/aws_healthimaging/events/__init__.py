from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_healthimaging as _aws_cdk_interfaces_aws_healthimaging_ceddda9d


class DataStoreCreated(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreCreated",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@DataStoreCreated.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        data_store_created = healthimaging_events.DataStoreCreated()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="dataStoreCreatedPattern")
    @builtins.classmethod
    def data_store_created_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Created.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreCreated.DataStoreCreatedProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "dataStoreCreatedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreCreated.DataStoreCreatedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_status": "datastoreStatus",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
        },
    )
    class DataStoreCreatedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@DataStoreCreated event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                data_store_created_props = healthimaging_events.DataStoreCreated.DataStoreCreatedProps(
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_status=["datastoreStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__13568f6b78d1e88f373e6d4a186f766897b4925387dfdffa1cae01bc2d20c635)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_status", value=datastore_status, expected_type=type_hints["datastore_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_status is not None:
                self._values["datastore_status"] = datastore_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreStatus property.

            Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreCreatedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DataStoreCreating(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreCreating",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@DataStoreCreating.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        data_store_creating = healthimaging_events.DataStoreCreating()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="dataStoreCreatingPattern")
    @builtins.classmethod
    def data_store_creating_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Creating.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreCreating.DataStoreCreatingProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "dataStoreCreatingPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreCreating.DataStoreCreatingProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_status": "datastoreStatus",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
        },
    )
    class DataStoreCreatingProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@DataStoreCreating event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                data_store_creating_props = healthimaging_events.DataStoreCreating.DataStoreCreatingProps(
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_status=["datastoreStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__96d700a0385096f0e6314b0f1ffc82de0bfa144496cb6303d147f82e91e4c4ac)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_status", value=datastore_status, expected_type=type_hints["datastore_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_status is not None:
                self._values["datastore_status"] = datastore_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreStatus property.

            Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreCreatingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DataStoreCreationFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreCreationFailed",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@DataStoreCreationFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        data_store_creation_failed = healthimaging_events.DataStoreCreationFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="dataStoreCreationFailedPattern")
    @builtins.classmethod
    def data_store_creation_failed_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Creation Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreCreationFailed.DataStoreCreationFailedProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "dataStoreCreationFailedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreCreationFailed.DataStoreCreationFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_status": "datastoreStatus",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
        },
    )
    class DataStoreCreationFailedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@DataStoreCreationFailed event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                data_store_creation_failed_props = healthimaging_events.DataStoreCreationFailed.DataStoreCreationFailedProps(
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_status=["datastoreStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__92932e4dda004e6359da9b85467f61b66d1292cc04d3953b7c799b3093d43dcc)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_status", value=datastore_status, expected_type=type_hints["datastore_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_status is not None:
                self._values["datastore_status"] = datastore_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreStatus property.

            Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreCreationFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DataStoreDeleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreDeleted",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@DataStoreDeleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        data_store_deleted = healthimaging_events.DataStoreDeleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="dataStoreDeletedPattern")
    @builtins.classmethod
    def data_store_deleted_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Deleted.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreDeleted.DataStoreDeletedProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "dataStoreDeletedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreDeleted.DataStoreDeletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_status": "datastoreStatus",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
        },
    )
    class DataStoreDeletedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@DataStoreDeleted event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                data_store_deleted_props = healthimaging_events.DataStoreDeleted.DataStoreDeletedProps(
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_status=["datastoreStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4ccf170253d436094de920e4f40fe01c9088ff5c88f15546098137880cae6841)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_status", value=datastore_status, expected_type=type_hints["datastore_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_status is not None:
                self._values["datastore_status"] = datastore_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreStatus property.

            Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreDeletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DataStoreDeleting(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreDeleting",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@DataStoreDeleting.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        data_store_deleting = healthimaging_events.DataStoreDeleting()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="dataStoreDeletingPattern")
    @builtins.classmethod
    def data_store_deleting_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Deleting.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreDeleting.DataStoreDeletingProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "dataStoreDeletingPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DataStoreDeleting.DataStoreDeletingProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_status": "datastoreStatus",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
        },
    )
    class DataStoreDeletingProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@DataStoreDeleting event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                data_store_deleting_props = healthimaging_events.DataStoreDeleting.DataStoreDeletingProps(
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_status=["datastoreStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9ee4b66083e8feeb3609abe7e84e077043642cdaeafb38343c80997200d24edd)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_status", value=datastore_status, expected_type=type_hints["datastore_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_status is not None:
                self._values["datastore_status"] = datastore_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreStatus property.

            Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreDeletingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DatastoreEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.DatastoreEvents",
):
    '''(experimental) EventBridge event patterns for Datastore.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        from aws_cdk.interfaces import aws_healthimaging as interfaces_healthimaging
        
        # datastore_ref: interfaces_healthimaging.IDatastoreRef
        
        datastore_events = healthimaging_events.DatastoreEvents.from_datastore(datastore_ref)
    '''

    @jsii.member(jsii_name="fromDatastore")
    @builtins.classmethod
    def from_datastore(
        cls,
        datastore_ref: "_aws_cdk_interfaces_aws_healthimaging_ceddda9d.IDatastoreRef",
    ) -> "DatastoreEvents":
        '''(experimental) Create DatastoreEvents from a Datastore reference.

        :param datastore_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3ca879ca9e80089c19b1c74410be72304e565fe5c3eb228c8d71887426e98d3d)
            check_type(argname="argument datastore_ref", value=datastore_ref, expected_type=type_hints["datastore_ref"])
        return typing.cast("DatastoreEvents", jsii.sinvoke(cls, "fromDatastore", [datastore_ref]))

    @jsii.member(jsii_name="dataStoreCreatedPattern")
    def data_store_created_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Data Store Created.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreCreated.DataStoreCreatedProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "dataStoreCreatedPattern", [options]))

    @jsii.member(jsii_name="dataStoreCreatingPattern")
    def data_store_creating_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Data Store Creating.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreCreating.DataStoreCreatingProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "dataStoreCreatingPattern", [options]))

    @jsii.member(jsii_name="dataStoreCreationFailedPattern")
    def data_store_creation_failed_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Data Store Creation Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreCreationFailed.DataStoreCreationFailedProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "dataStoreCreationFailedPattern", [options]))

    @jsii.member(jsii_name="dataStoreDeletedPattern")
    def data_store_deleted_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Data Store Deleted.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreDeleted.DataStoreDeletedProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "dataStoreDeletedPattern", [options]))

    @jsii.member(jsii_name="dataStoreDeletingPattern")
    def data_store_deleting_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Data Store Deleting.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_status: (experimental) datastoreStatus property. Specify an array of string values to match this event if the actual value of datastoreStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DataStoreDeleting.DataStoreDeletingProps(
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_status=datastore_status,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "dataStoreDeletingPattern", [options]))

    @jsii.member(jsii_name="imageSetCopiedPattern")
    def image_set_copied_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Copied.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCopied.ImageSetCopiedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetCopiedPattern", [options]))

    @jsii.member(jsii_name="imageSetCopyFailedPattern")
    def image_set_copy_failed_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Copy Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCopyFailed.ImageSetCopyFailedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetCopyFailedPattern", [options]))

    @jsii.member(jsii_name="imageSetCopyingPattern")
    def image_set_copying_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Copying.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCopying.ImageSetCopyingProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetCopyingPattern", [options]))

    @jsii.member(jsii_name="imageSetCopyingWithReadOnlyAccessPattern")
    def image_set_copying_with_read_only_access_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Copying With Read Only Access.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCopyingWithReadOnlyAccess.ImageSetCopyingWithReadOnlyAccessProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetCopyingWithReadOnlyAccessPattern", [options]))

    @jsii.member(jsii_name="imageSetCreatedPattern")
    def image_set_created_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Created.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCreated.ImageSetCreatedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetCreatedPattern", [options]))

    @jsii.member(jsii_name="imageSetDeletedPattern")
    def image_set_deleted_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Deleted.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetDeleted.ImageSetDeletedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetDeletedPattern", [options]))

    @jsii.member(jsii_name="imageSetDeletingPattern")
    def image_set_deleting_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Deleting.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetDeleting.ImageSetDeletingProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetDeletingPattern", [options]))

    @jsii.member(jsii_name="imageSetUpdatedPattern")
    def image_set_updated_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Updated.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetUpdated.ImageSetUpdatedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetUpdatedPattern", [options]))

    @jsii.member(jsii_name="imageSetUpdateFailedPattern")
    def image_set_update_failed_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Update Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetUpdateFailed.ImageSetUpdateFailedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetUpdateFailedPattern", [options]))

    @jsii.member(jsii_name="imageSetUpdatingPattern")
    def image_set_updating_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Image Set Updating.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetUpdating.ImageSetUpdatingProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "imageSetUpdatingPattern", [options]))

    @jsii.member(jsii_name="importJobCompletedPattern")
    def import_job_completed_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Import Job Completed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobCompleted.ImportJobCompletedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
            input_s3_uri=input_s3_uri,
            job_id=job_id,
            job_name=job_name,
            job_status=job_status,
            output_s3_uri=output_s3_uri,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "importJobCompletedPattern", [options]))

    @jsii.member(jsii_name="importJobFailedPattern")
    def import_job_failed_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Import Job Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobFailed.ImportJobFailedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
            input_s3_uri=input_s3_uri,
            job_id=job_id,
            job_name=job_name,
            job_status=job_status,
            output_s3_uri=output_s3_uri,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "importJobFailedPattern", [options]))

    @jsii.member(jsii_name="importJobInProgressPattern")
    def import_job_in_progress_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Import Job In Progress.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobInProgress.ImportJobInProgressProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
            input_s3_uri=input_s3_uri,
            job_id=job_id,
            job_name=job_name,
            job_status=job_status,
            output_s3_uri=output_s3_uri,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "importJobInProgressPattern", [options]))

    @jsii.member(jsii_name="importJobSubmittedPattern")
    def import_job_submitted_pattern(
        self,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Datastore Import Job Submitted.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobSubmitted.ImportJobSubmittedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
            input_s3_uri=input_s3_uri,
            job_id=job_id,
            job_name=job_name,
            job_status=job_status,
            output_s3_uri=output_s3_uri,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "importJobSubmittedPattern", [options]))


class ImageSetCopied(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCopied",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetCopied.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_copied = healthimaging_events.ImageSetCopied()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetCopiedPattern")
    @builtins.classmethod
    def image_set_copied_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Copied.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCopied.ImageSetCopiedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetCopiedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCopied.ImageSetCopiedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetCopiedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetCopied event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_copied_props = healthimaging_events.ImageSetCopied.ImageSetCopiedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d847d5c90d08a90e4d53875c2243c3e74a0de915290d184a8113da93e5d69671)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetCopiedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetCopyFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCopyFailed",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetCopyFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_copy_failed = healthimaging_events.ImageSetCopyFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetCopyFailedPattern")
    @builtins.classmethod
    def image_set_copy_failed_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Copy Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCopyFailed.ImageSetCopyFailedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetCopyFailedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCopyFailed.ImageSetCopyFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetCopyFailedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetCopyFailed event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_copy_failed_props = healthimaging_events.ImageSetCopyFailed.ImageSetCopyFailedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__362674fe5c2e158b4604854d73d9e7d6f5704575d5c107ef68881e6023ee64b4)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetCopyFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetCopying(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCopying",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetCopying.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_copying = healthimaging_events.ImageSetCopying()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetCopyingPattern")
    @builtins.classmethod
    def image_set_copying_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Copying.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCopying.ImageSetCopyingProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetCopyingPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCopying.ImageSetCopyingProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetCopyingProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetCopying event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_copying_props = healthimaging_events.ImageSetCopying.ImageSetCopyingProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ecd48396f8f6042bf591db79b09c586a68fd614a320839d49276f0d46fc470f9)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetCopyingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetCopyingWithReadOnlyAccess(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCopyingWithReadOnlyAccess",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetCopyingWithReadOnlyAccess.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_copying_with_read_only_access = healthimaging_events.ImageSetCopyingWithReadOnlyAccess()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetCopyingWithReadOnlyAccessPattern")
    @builtins.classmethod
    def image_set_copying_with_read_only_access_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Copying With Read Only Access.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCopyingWithReadOnlyAccess.ImageSetCopyingWithReadOnlyAccessProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetCopyingWithReadOnlyAccessPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCopyingWithReadOnlyAccess.ImageSetCopyingWithReadOnlyAccessProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetCopyingWithReadOnlyAccessProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetCopyingWithReadOnlyAccess event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_copying_with_read_only_access_props = healthimaging_events.ImageSetCopyingWithReadOnlyAccess.ImageSetCopyingWithReadOnlyAccessProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5d2da77b698282b4211ca938b3be3faa2f5dd7d2b2aef60bc78ef74898ff8f56)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetCopyingWithReadOnlyAccessProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetCreated(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCreated",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetCreated.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_created = healthimaging_events.ImageSetCreated()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetCreatedPattern")
    @builtins.classmethod
    def image_set_created_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Created.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetCreated.ImageSetCreatedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetCreatedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetCreated.ImageSetCreatedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetCreatedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetCreated event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_created_props = healthimaging_events.ImageSetCreated.ImageSetCreatedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4d48c6300090d2aa7dfc4409d5dbae51c7475cbe2b637006db4a0587a7e87b01)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetCreatedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetDeleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetDeleted",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetDeleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_deleted = healthimaging_events.ImageSetDeleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetDeletedPattern")
    @builtins.classmethod
    def image_set_deleted_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Deleted.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetDeleted.ImageSetDeletedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetDeletedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetDeleted.ImageSetDeletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetDeletedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetDeleted event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_deleted_props = healthimaging_events.ImageSetDeleted.ImageSetDeletedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5f604c504ee3dd2edb35ac48ce1cb2057a8eef778bccd1ce5eec390b56e46095)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetDeletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetDeleting(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetDeleting",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetDeleting.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_deleting = healthimaging_events.ImageSetDeleting()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetDeletingPattern")
    @builtins.classmethod
    def image_set_deleting_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Deleting.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetDeleting.ImageSetDeletingProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetDeletingPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetDeleting.ImageSetDeletingProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetDeletingProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetDeleting event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_deleting_props = healthimaging_events.ImageSetDeleting.ImageSetDeletingProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__26073c088219e68e78edcd8eb8f96684809a0862b851700ea9ad0e4f9723de51)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetDeletingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetUpdateFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetUpdateFailed",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetUpdateFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_update_failed = healthimaging_events.ImageSetUpdateFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetUpdateFailedPattern")
    @builtins.classmethod
    def image_set_update_failed_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Update Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetUpdateFailed.ImageSetUpdateFailedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetUpdateFailedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetUpdateFailed.ImageSetUpdateFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetUpdateFailedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetUpdateFailed event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_update_failed_props = healthimaging_events.ImageSetUpdateFailed.ImageSetUpdateFailedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8ed8a5d4b4c6c773e64152b9e73ef2eb55becc963cf12f6c438878bd09381b44)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetUpdateFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetUpdated(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetUpdated",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetUpdated.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_updated = healthimaging_events.ImageSetUpdated()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetUpdatedPattern")
    @builtins.classmethod
    def image_set_updated_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Updated.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetUpdated.ImageSetUpdatedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetUpdatedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetUpdated.ImageSetUpdatedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetUpdatedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetUpdated event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_updated_props = healthimaging_events.ImageSetUpdated.ImageSetUpdatedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__60628b3445764ebeb17c47a070e61e86945bef18bf2cd7c0bc0471f7b1e14bb5)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetUpdatedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImageSetUpdating(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetUpdating",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImageSetUpdating.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        image_set_updating = healthimaging_events.ImageSetUpdating()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="imageSetUpdatingPattern")
    @builtins.classmethod
    def image_set_updating_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Image Set Updating.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImageSetUpdating.ImageSetUpdatingProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            image_set_id=image_set_id,
            image_set_state=image_set_state,
            image_set_workflow_status=image_set_workflow_status,
            imaging_version=imaging_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "imageSetUpdatingPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImageSetUpdating.ImageSetUpdatingProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "image_set_id": "imageSetId",
            "image_set_state": "imageSetState",
            "image_set_workflow_status": "imageSetWorkflowStatus",
            "imaging_version": "imagingVersion",
        },
    )
    class ImageSetUpdatingProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImageSetUpdating event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_set_id: (experimental) imageSetId property. Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_state: (experimental) imageSetState property. Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_set_workflow_status: (experimental) imageSetWorkflowStatus property. Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                image_set_updating_props = healthimaging_events.ImageSetUpdating.ImageSetUpdatingProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_set_id=["imageSetId"],
                    image_set_state=["imageSetState"],
                    image_set_workflow_status=["imageSetWorkflowStatus"],
                    imaging_version=["imagingVersion"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e6c2e9e5d26d80eb26c889f4aa127e6b309a8d0d32cdb5e86807fe5dcba4f877)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_set_id", value=image_set_id, expected_type=type_hints["image_set_id"])
                check_type(argname="argument image_set_state", value=image_set_state, expected_type=type_hints["image_set_state"])
                check_type(argname="argument image_set_workflow_status", value=image_set_workflow_status, expected_type=type_hints["image_set_workflow_status"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_set_id is not None:
                self._values["image_set_id"] = image_set_id
            if image_set_state is not None:
                self._values["image_set_state"] = image_set_state
            if image_set_workflow_status is not None:
                self._values["image_set_workflow_status"] = image_set_workflow_status
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_set_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetId property.

            Specify an array of string values to match this event if the actual value of imageSetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetState property.

            Specify an array of string values to match this event if the actual value of imageSetState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_set_workflow_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageSetWorkflowStatus property.

            Specify an array of string values to match this event if the actual value of imageSetWorkflowStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_set_workflow_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageSetUpdatingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobCompleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImportJobCompleted",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImportJobCompleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        import_job_completed = healthimaging_events.ImportJobCompleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="importJobCompletedPattern")
    @builtins.classmethod
    def import_job_completed_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job Completed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobCompleted.ImportJobCompletedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
            input_s3_uri=input_s3_uri,
            job_id=job_id,
            job_name=job_name,
            job_status=job_status,
            output_s3_uri=output_s3_uri,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "importJobCompletedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImportJobCompleted.ImportJobCompletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
            "input_s3_uri": "inputS3Uri",
            "job_id": "jobId",
            "job_name": "jobName",
            "job_status": "jobStatus",
            "output_s3_uri": "outputS3Uri",
        },
    )
    class ImportJobCompletedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImportJobCompleted event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                import_job_completed_props = healthimaging_events.ImportJobCompleted.ImportJobCompletedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"],
                    input_s3_uri=["inputS3Uri"],
                    job_id=["jobId"],
                    job_name=["jobName"],
                    job_status=["jobStatus"],
                    output_s3_uri=["outputS3Uri"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4efd158796b6b9f0634330ff4c03f0a544f05bf652f66d3c117808f5ae9d8f59)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
                check_type(argname="argument input_s3_uri", value=input_s3_uri, expected_type=type_hints["input_s3_uri"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument job_name", value=job_name, expected_type=type_hints["job_name"])
                check_type(argname="argument job_status", value=job_status, expected_type=type_hints["job_status"])
                check_type(argname="argument output_s3_uri", value=output_s3_uri, expected_type=type_hints["output_s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version
            if input_s3_uri is not None:
                self._values["input_s3_uri"] = input_s3_uri
            if job_id is not None:
                self._values["job_id"] = job_id
            if job_name is not None:
                self._values["job_name"] = job_name
            if job_status is not None:
                self._values["job_status"] = job_status
            if output_s3_uri is not None:
                self._values["output_s3_uri"] = output_s3_uri

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) inputS3Uri property.

            Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobName property.

            Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobStatus property.

            Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) outputS3Uri property.

            Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobCompletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImportJobFailed",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImportJobFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        import_job_failed = healthimaging_events.ImportJobFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="importJobFailedPattern")
    @builtins.classmethod
    def import_job_failed_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobFailed.ImportJobFailedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
            input_s3_uri=input_s3_uri,
            job_id=job_id,
            job_name=job_name,
            job_status=job_status,
            output_s3_uri=output_s3_uri,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "importJobFailedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImportJobFailed.ImportJobFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
            "input_s3_uri": "inputS3Uri",
            "job_id": "jobId",
            "job_name": "jobName",
            "job_status": "jobStatus",
            "output_s3_uri": "outputS3Uri",
        },
    )
    class ImportJobFailedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImportJobFailed event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                import_job_failed_props = healthimaging_events.ImportJobFailed.ImportJobFailedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"],
                    input_s3_uri=["inputS3Uri"],
                    job_id=["jobId"],
                    job_name=["jobName"],
                    job_status=["jobStatus"],
                    output_s3_uri=["outputS3Uri"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__037600517bb694b287d7cfb5fd848ee09342ea8bb1bdb05be837e01a5081ac0d)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
                check_type(argname="argument input_s3_uri", value=input_s3_uri, expected_type=type_hints["input_s3_uri"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument job_name", value=job_name, expected_type=type_hints["job_name"])
                check_type(argname="argument job_status", value=job_status, expected_type=type_hints["job_status"])
                check_type(argname="argument output_s3_uri", value=output_s3_uri, expected_type=type_hints["output_s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version
            if input_s3_uri is not None:
                self._values["input_s3_uri"] = input_s3_uri
            if job_id is not None:
                self._values["job_id"] = job_id
            if job_name is not None:
                self._values["job_name"] = job_name
            if job_status is not None:
                self._values["job_status"] = job_status
            if output_s3_uri is not None:
                self._values["output_s3_uri"] = output_s3_uri

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) inputS3Uri property.

            Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobName property.

            Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobStatus property.

            Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) outputS3Uri property.

            Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobInProgress(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImportJobInProgress",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImportJobInProgress.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        import_job_in_progress = healthimaging_events.ImportJobInProgress()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="importJobInProgressPattern")
    @builtins.classmethod
    def import_job_in_progress_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job In Progress.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobInProgress.ImportJobInProgressProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
            input_s3_uri=input_s3_uri,
            job_id=job_id,
            job_name=job_name,
            job_status=job_status,
            output_s3_uri=output_s3_uri,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "importJobInProgressPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImportJobInProgress.ImportJobInProgressProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
            "input_s3_uri": "inputS3Uri",
            "job_id": "jobId",
            "job_name": "jobName",
            "job_status": "jobStatus",
            "output_s3_uri": "outputS3Uri",
        },
    )
    class ImportJobInProgressProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImportJobInProgress event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                import_job_in_progress_props = healthimaging_events.ImportJobInProgress.ImportJobInProgressProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"],
                    input_s3_uri=["inputS3Uri"],
                    job_id=["jobId"],
                    job_name=["jobName"],
                    job_status=["jobStatus"],
                    output_s3_uri=["outputS3Uri"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__400f9f016868fd87d6fba4d2f7b80bf285ea3f05dabef047d96589a551348299)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
                check_type(argname="argument input_s3_uri", value=input_s3_uri, expected_type=type_hints["input_s3_uri"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument job_name", value=job_name, expected_type=type_hints["job_name"])
                check_type(argname="argument job_status", value=job_status, expected_type=type_hints["job_status"])
                check_type(argname="argument output_s3_uri", value=output_s3_uri, expected_type=type_hints["output_s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version
            if input_s3_uri is not None:
                self._values["input_s3_uri"] = input_s3_uri
            if job_id is not None:
                self._values["job_id"] = job_id
            if job_name is not None:
                self._values["job_name"] = job_name
            if job_status is not None:
                self._values["job_status"] = job_status
            if output_s3_uri is not None:
                self._values["output_s3_uri"] = output_s3_uri

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) inputS3Uri property.

            Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobName property.

            Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobStatus property.

            Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) outputS3Uri property.

            Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobInProgressProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobSubmitted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImportJobSubmitted",
):
    '''(experimental) EventBridge event pattern for aws.healthimaging@ImportJobSubmitted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
        
        import_job_submitted = healthimaging_events.ImportJobSubmitted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="importJobSubmittedPattern")
    @builtins.classmethod
    def import_job_submitted_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job Submitted.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobSubmitted.ImportJobSubmittedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            imaging_version=imaging_version,
            input_s3_uri=input_s3_uri,
            job_id=job_id,
            job_name=job_name,
            job_status=job_status,
            output_s3_uri=output_s3_uri,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "importJobSubmittedPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthimaging.events.ImportJobSubmitted.ImportJobSubmittedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "imaging_version": "imagingVersion",
            "input_s3_uri": "inputS3Uri",
            "job_id": "jobId",
            "job_name": "jobName",
            "job_status": "jobStatus",
            "output_s3_uri": "outputS3Uri",
        },
    )
    class ImportJobSubmittedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthimaging@ImportJobSubmitted event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Datastore reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param imaging_version: (experimental) imagingVersion property. Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_s3_uri: (experimental) inputS3Uri property. Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_name: (experimental) jobName property. Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_status: (experimental) jobStatus property. Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_s3_uri: (experimental) outputS3Uri property. Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthimaging import events as healthimaging_events
                
                import_job_submitted_props = healthimaging_events.ImportJobSubmitted.ImportJobSubmittedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    imaging_version=["imagingVersion"],
                    input_s3_uri=["inputS3Uri"],
                    job_id=["jobId"],
                    job_name=["jobName"],
                    job_status=["jobStatus"],
                    output_s3_uri=["outputS3Uri"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__01312e84f99eced1df5716447ca28cc51e86021c7b8ee9a01145ae8e2e7700af)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument imaging_version", value=imaging_version, expected_type=type_hints["imaging_version"])
                check_type(argname="argument input_s3_uri", value=input_s3_uri, expected_type=type_hints["input_s3_uri"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument job_name", value=job_name, expected_type=type_hints["job_name"])
                check_type(argname="argument job_status", value=job_status, expected_type=type_hints["job_status"])
                check_type(argname="argument output_s3_uri", value=output_s3_uri, expected_type=type_hints["output_s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if imaging_version is not None:
                self._values["imaging_version"] = imaging_version
            if input_s3_uri is not None:
                self._values["input_s3_uri"] = input_s3_uri
            if job_id is not None:
                self._values["job_id"] = job_id
            if job_name is not None:
                self._values["job_name"] = job_name
            if job_status is not None:
                self._values["job_status"] = job_status
            if output_s3_uri is not None:
                self._values["output_s3_uri"] = output_s3_uri

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Datastore reference

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def imaging_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagingVersion property.

            Specify an array of string values to match this event if the actual value of imagingVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("imaging_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) inputS3Uri property.

            Specify an array of string values to match this event if the actual value of inputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobName property.

            Specify an array of string values to match this event if the actual value of jobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def job_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobStatus property.

            Specify an array of string values to match this event if the actual value of jobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) outputS3Uri property.

            Specify an array of string values to match this event if the actual value of outputS3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobSubmittedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "DataStoreCreated",
    "DataStoreCreating",
    "DataStoreCreationFailed",
    "DataStoreDeleted",
    "DataStoreDeleting",
    "DatastoreEvents",
    "ImageSetCopied",
    "ImageSetCopyFailed",
    "ImageSetCopying",
    "ImageSetCopyingWithReadOnlyAccess",
    "ImageSetCreated",
    "ImageSetDeleted",
    "ImageSetDeleting",
    "ImageSetUpdateFailed",
    "ImageSetUpdated",
    "ImageSetUpdating",
    "ImportJobCompleted",
    "ImportJobFailed",
    "ImportJobInProgress",
    "ImportJobSubmitted",
]

publication.publish()

def _typecheckingstub__13568f6b78d1e88f373e6d4a186f766897b4925387dfdffa1cae01bc2d20c635(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96d700a0385096f0e6314b0f1ffc82de0bfa144496cb6303d147f82e91e4c4ac(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92932e4dda004e6359da9b85467f61b66d1292cc04d3953b7c799b3093d43dcc(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ccf170253d436094de920e4f40fe01c9088ff5c88f15546098137880cae6841(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9ee4b66083e8feeb3609abe7e84e077043642cdaeafb38343c80997200d24edd(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3ca879ca9e80089c19b1c74410be72304e565fe5c3eb228c8d71887426e98d3d(
    datastore_ref: _aws_cdk_interfaces_aws_healthimaging_ceddda9d.IDatastoreRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d847d5c90d08a90e4d53875c2243c3e74a0de915290d184a8113da93e5d69671(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__362674fe5c2e158b4604854d73d9e7d6f5704575d5c107ef68881e6023ee64b4(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ecd48396f8f6042bf591db79b09c586a68fd614a320839d49276f0d46fc470f9(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d2da77b698282b4211ca938b3be3faa2f5dd7d2b2aef60bc78ef74898ff8f56(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4d48c6300090d2aa7dfc4409d5dbae51c7475cbe2b637006db4a0587a7e87b01(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f604c504ee3dd2edb35ac48ce1cb2057a8eef778bccd1ce5eec390b56e46095(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26073c088219e68e78edcd8eb8f96684809a0862b851700ea9ad0e4f9723de51(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ed8a5d4b4c6c773e64152b9e73ef2eb55becc963cf12f6c438878bd09381b44(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60628b3445764ebeb17c47a070e61e86945bef18bf2cd7c0bc0471f7b1e14bb5(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6c2e9e5d26d80eb26c889f4aa127e6b309a8d0d32cdb5e86807fe5dcba4f877(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_set_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_set_workflow_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4efd158796b6b9f0634330ff4c03f0a544f05bf652f66d3c117808f5ae9d8f59(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__037600517bb694b287d7cfb5fd848ee09342ea8bb1bdb05be837e01a5081ac0d(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__400f9f016868fd87d6fba4d2f7b80bf285ea3f05dabef047d96589a551348299(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__01312e84f99eced1df5716447ca28cc51e86021c7b8ee9a01145ae8e2e7700af(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    imaging_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
