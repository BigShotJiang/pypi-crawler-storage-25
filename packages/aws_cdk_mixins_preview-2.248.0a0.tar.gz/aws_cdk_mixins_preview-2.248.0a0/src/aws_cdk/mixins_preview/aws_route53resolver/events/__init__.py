from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_route53resolver as _aws_cdk_interfaces_aws_route53resolver_ceddda9d


class DNSFirewallAlert(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallAlert",
):
    '''(experimental) EventBridge event pattern for aws.route53resolver@DNSFirewallAlert.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
        
        d_nSFirewall_alert = route53resolver_events.DNSFirewallAlert()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="dnsFirewallAlertPattern")
    @builtins.classmethod
    def dns_firewall_alert_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        firewall_domain_list_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        firewall_rule_action: typing.Optional[typing.Sequence[builtins.str]] = None,
        firewall_rule_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        last_observed_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_class: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        resources: typing.Optional[typing.Sequence[typing.Union["DNSFirewallAlert.DnsFirewallAlertItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        src_addr: typing.Optional[typing.Sequence[builtins.str]] = None,
        src_port: typing.Optional[typing.Sequence[builtins.str]] = None,
        transport: typing.Optional[typing.Sequence[builtins.str]] = None,
        vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for DNS Firewall Alert.

        :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param firewall_domain_list_id: (experimental) firewall-domain-list-id property. Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the FirewallDomainList reference
        :param firewall_rule_action: (experimental) firewall-rule-action property. Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param firewall_rule_group_id: (experimental) firewall-rule-group-id property. Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param last_observed_at: (experimental) last-observed-at property. Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_class: (experimental) query-class property. Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_name: (experimental) query-name property. Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_type: (experimental) query-type property. Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param src_addr: (experimental) src-addr property. Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param src_port: (experimental) src-port property. Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transport: (experimental) transport property. Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param vpc_id: (experimental) vpc-id property. Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DNSFirewallAlert.DNSFirewallAlertProps(
            account_id=account_id,
            event_metadata=event_metadata,
            firewall_domain_list_id=firewall_domain_list_id,
            firewall_rule_action=firewall_rule_action,
            firewall_rule_group_id=firewall_rule_group_id,
            last_observed_at=last_observed_at,
            query_class=query_class,
            query_name=query_name,
            query_type=query_type,
            resources=resources,
            src_addr=src_addr,
            src_port=src_port,
            transport=transport,
            vpc_id=vpc_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "dnsFirewallAlertPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallAlert.DNSFirewallAlertProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "event_metadata": "eventMetadata",
            "firewall_domain_list_id": "firewallDomainListId",
            "firewall_rule_action": "firewallRuleAction",
            "firewall_rule_group_id": "firewallRuleGroupId",
            "last_observed_at": "lastObservedAt",
            "query_class": "queryClass",
            "query_name": "queryName",
            "query_type": "queryType",
            "resources": "resources",
            "src_addr": "srcAddr",
            "src_port": "srcPort",
            "transport": "transport",
            "vpc_id": "vpcId",
        },
    )
    class DNSFirewallAlertProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            firewall_domain_list_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            firewall_rule_action: typing.Optional[typing.Sequence[builtins.str]] = None,
            firewall_rule_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_observed_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            query_class: typing.Optional[typing.Sequence[builtins.str]] = None,
            query_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            query_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            resources: typing.Optional[typing.Sequence[typing.Union["DNSFirewallAlert.DnsFirewallAlertItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            src_addr: typing.Optional[typing.Sequence[builtins.str]] = None,
            src_port: typing.Optional[typing.Sequence[builtins.str]] = None,
            transport: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.route53resolver@DNSFirewallAlert event.

            :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param firewall_domain_list_id: (experimental) firewall-domain-list-id property. Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the FirewallDomainList reference
            :param firewall_rule_action: (experimental) firewall-rule-action property. Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param firewall_rule_group_id: (experimental) firewall-rule-group-id property. Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_observed_at: (experimental) last-observed-at property. Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param query_class: (experimental) query-class property. Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param query_name: (experimental) query-name property. Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param query_type: (experimental) query-type property. Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param src_addr: (experimental) src-addr property. Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param src_port: (experimental) src-port property. Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transport: (experimental) transport property. Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpc-id property. Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
                
                d_nSFirewall_alert_props = route53resolver_events.DNSFirewallAlert.DNSFirewallAlertProps(
                    account_id=["accountId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    firewall_domain_list_id=["firewallDomainListId"],
                    firewall_rule_action=["firewallRuleAction"],
                    firewall_rule_group_id=["firewallRuleGroupId"],
                    last_observed_at=["lastObservedAt"],
                    query_class=["queryClass"],
                    query_name=["queryName"],
                    query_type=["queryType"],
                    resources=[route53resolver_events.DNSFirewallAlert.DnsFirewallAlertItem(
                        resolver_endpoint_details=route53resolver_events.DNSFirewallAlert.ResolverEndpointDetails(
                            id=["id"]
                        ),
                        resolver_network_interface_details=route53resolver_events.DNSFirewallAlert.ResolverNetworkInterfaceDetails(
                            id=["id"]
                        ),
                        resource_type=["resourceType"]
                    )],
                    src_addr=["srcAddr"],
                    src_port=["srcPort"],
                    transport=["transport"],
                    vpc_id=["vpcId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__23f2f53eb699ea89ac3146f408835e5e0c4c177494e9b8ea6b0425beac31be7c)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument firewall_domain_list_id", value=firewall_domain_list_id, expected_type=type_hints["firewall_domain_list_id"])
                check_type(argname="argument firewall_rule_action", value=firewall_rule_action, expected_type=type_hints["firewall_rule_action"])
                check_type(argname="argument firewall_rule_group_id", value=firewall_rule_group_id, expected_type=type_hints["firewall_rule_group_id"])
                check_type(argname="argument last_observed_at", value=last_observed_at, expected_type=type_hints["last_observed_at"])
                check_type(argname="argument query_class", value=query_class, expected_type=type_hints["query_class"])
                check_type(argname="argument query_name", value=query_name, expected_type=type_hints["query_name"])
                check_type(argname="argument query_type", value=query_type, expected_type=type_hints["query_type"])
                check_type(argname="argument resources", value=resources, expected_type=type_hints["resources"])
                check_type(argname="argument src_addr", value=src_addr, expected_type=type_hints["src_addr"])
                check_type(argname="argument src_port", value=src_port, expected_type=type_hints["src_port"])
                check_type(argname="argument transport", value=transport, expected_type=type_hints["transport"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if firewall_domain_list_id is not None:
                self._values["firewall_domain_list_id"] = firewall_domain_list_id
            if firewall_rule_action is not None:
                self._values["firewall_rule_action"] = firewall_rule_action
            if firewall_rule_group_id is not None:
                self._values["firewall_rule_group_id"] = firewall_rule_group_id
            if last_observed_at is not None:
                self._values["last_observed_at"] = last_observed_at
            if query_class is not None:
                self._values["query_class"] = query_class
            if query_name is not None:
                self._values["query_name"] = query_name
            if query_type is not None:
                self._values["query_type"] = query_type
            if resources is not None:
                self._values["resources"] = resources
            if src_addr is not None:
                self._values["src_addr"] = src_addr
            if src_port is not None:
                self._values["src_port"] = src_port
            if transport is not None:
                self._values["transport"] = transport
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) account-id property.

            Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def firewall_domain_list_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) firewall-domain-list-id property.

            Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the FirewallDomainList reference

            :stability: experimental
            '''
            result = self._values.get("firewall_domain_list_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def firewall_rule_action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) firewall-rule-action property.

            Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("firewall_rule_action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def firewall_rule_group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) firewall-rule-group-id property.

            Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("firewall_rule_group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_observed_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) last-observed-at property.

            Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_observed_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def query_class(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) query-class property.

            Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("query_class")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def query_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) query-name property.

            Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("query_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def query_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) query-type property.

            Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("query_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resources(
            self,
        ) -> typing.Optional[typing.List["DNSFirewallAlert.DnsFirewallAlertItem"]]:
            '''(experimental) resources property.

            Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resources")
            return typing.cast(typing.Optional[typing.List["DNSFirewallAlert.DnsFirewallAlertItem"]], result)

        @builtins.property
        def src_addr(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) src-addr property.

            Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("src_addr")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def src_port(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) src-port property.

            Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("src_port")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transport(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) transport property.

            Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transport")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpc-id property.

            Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DNSFirewallAlertProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallAlert.DnsFirewallAlertItem",
        jsii_struct_bases=[],
        name_mapping={
            "resolver_endpoint_details": "resolverEndpointDetails",
            "resolver_network_interface_details": "resolverNetworkInterfaceDetails",
            "resource_type": "resourceType",
        },
    )
    class DnsFirewallAlertItem:
        def __init__(
            self,
            *,
            resolver_endpoint_details: typing.Optional[typing.Union["DNSFirewallAlert.ResolverEndpointDetails", typing.Dict[builtins.str, typing.Any]]] = None,
            resolver_network_interface_details: typing.Optional[typing.Union["DNSFirewallAlert.ResolverNetworkInterfaceDetails", typing.Dict[builtins.str, typing.Any]]] = None,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DNSFirewallAlertItem.

            :param resolver_endpoint_details: (experimental) resolver-endpoint-details property. Specify an array of string values to match this event if the actual value of resolver-endpoint-details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resolver_network_interface_details: (experimental) resolver-network-interface-details property. Specify an array of string values to match this event if the actual value of resolver-network-interface-details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_type: (experimental) resource-type property. Specify an array of string values to match this event if the actual value of resource-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
                
                dns_firewall_alert_item = route53resolver_events.DNSFirewallAlert.DnsFirewallAlertItem(
                    resolver_endpoint_details=route53resolver_events.DNSFirewallAlert.ResolverEndpointDetails(
                        id=["id"]
                    ),
                    resolver_network_interface_details=route53resolver_events.DNSFirewallAlert.ResolverNetworkInterfaceDetails(
                        id=["id"]
                    ),
                    resource_type=["resourceType"]
                )
            '''
            if isinstance(resolver_endpoint_details, dict):
                resolver_endpoint_details = DNSFirewallAlert.ResolverEndpointDetails(**resolver_endpoint_details)
            if isinstance(resolver_network_interface_details, dict):
                resolver_network_interface_details = DNSFirewallAlert.ResolverNetworkInterfaceDetails(**resolver_network_interface_details)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b6431c55a80727de8247c2d2ac3e4102a48f533523a1c31fc1b5fb33c4e90662)
                check_type(argname="argument resolver_endpoint_details", value=resolver_endpoint_details, expected_type=type_hints["resolver_endpoint_details"])
                check_type(argname="argument resolver_network_interface_details", value=resolver_network_interface_details, expected_type=type_hints["resolver_network_interface_details"])
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if resolver_endpoint_details is not None:
                self._values["resolver_endpoint_details"] = resolver_endpoint_details
            if resolver_network_interface_details is not None:
                self._values["resolver_network_interface_details"] = resolver_network_interface_details
            if resource_type is not None:
                self._values["resource_type"] = resource_type

        @builtins.property
        def resolver_endpoint_details(
            self,
        ) -> typing.Optional["DNSFirewallAlert.ResolverEndpointDetails"]:
            '''(experimental) resolver-endpoint-details property.

            Specify an array of string values to match this event if the actual value of resolver-endpoint-details is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resolver_endpoint_details")
            return typing.cast(typing.Optional["DNSFirewallAlert.ResolverEndpointDetails"], result)

        @builtins.property
        def resolver_network_interface_details(
            self,
        ) -> typing.Optional["DNSFirewallAlert.ResolverNetworkInterfaceDetails"]:
            '''(experimental) resolver-network-interface-details property.

            Specify an array of string values to match this event if the actual value of resolver-network-interface-details is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resolver_network_interface_details")
            return typing.cast(typing.Optional["DNSFirewallAlert.ResolverNetworkInterfaceDetails"], result)

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resource-type property.

            Specify an array of string values to match this event if the actual value of resource-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DnsFirewallAlertItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallAlert.ResolverEndpointDetails",
        jsii_struct_bases=[],
        name_mapping={"id": "id"},
    )
    class ResolverEndpointDetails:
        def __init__(
            self,
            *,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Resolver-endpoint-details.

            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
                
                resolver_endpoint_details = route53resolver_events.DNSFirewallAlert.ResolverEndpointDetails(
                    id=["id"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e506e2c59b19c89c853c460697b59e137f57e77db8228f8bca95ff5fcf6e5e5a)
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if id is not None:
                self._values["id"] = id

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResolverEndpointDetails(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallAlert.ResolverNetworkInterfaceDetails",
        jsii_struct_bases=[],
        name_mapping={"id": "id"},
    )
    class ResolverNetworkInterfaceDetails:
        def __init__(
            self,
            *,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Resolver-network-interface-details.

            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
                
                resolver_network_interface_details = route53resolver_events.DNSFirewallAlert.ResolverNetworkInterfaceDetails(
                    id=["id"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7572e3368fc8d38f9ead48efda20b177e9a445fd0a8c7cc601d9af2921270950)
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if id is not None:
                self._values["id"] = id

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResolverNetworkInterfaceDetails(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DNSFirewallBlock(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallBlock",
):
    '''(experimental) EventBridge event pattern for aws.route53resolver@DNSFirewallBlock.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
        
        d_nSFirewall_block = route53resolver_events.DNSFirewallBlock()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="dnsFirewallBlockPattern")
    @builtins.classmethod
    def dns_firewall_block_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        firewall_domain_list_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        firewall_rule_action: typing.Optional[typing.Sequence[builtins.str]] = None,
        firewall_rule_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        last_observed_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_class: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        resources: typing.Optional[typing.Sequence[typing.Union["DNSFirewallBlock.DnsFirewallBlockItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        src_addr: typing.Optional[typing.Sequence[builtins.str]] = None,
        src_port: typing.Optional[typing.Sequence[builtins.str]] = None,
        transport: typing.Optional[typing.Sequence[builtins.str]] = None,
        vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for DNS Firewall Block.

        :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param firewall_domain_list_id: (experimental) firewall-domain-list-id property. Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the FirewallDomainList reference
        :param firewall_rule_action: (experimental) firewall-rule-action property. Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param firewall_rule_group_id: (experimental) firewall-rule-group-id property. Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param last_observed_at: (experimental) last-observed-at property. Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_class: (experimental) query-class property. Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_name: (experimental) query-name property. Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_type: (experimental) query-type property. Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param src_addr: (experimental) src-addr property. Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param src_port: (experimental) src-port property. Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transport: (experimental) transport property. Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param vpc_id: (experimental) vpc-id property. Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DNSFirewallBlock.DNSFirewallBlockProps(
            account_id=account_id,
            event_metadata=event_metadata,
            firewall_domain_list_id=firewall_domain_list_id,
            firewall_rule_action=firewall_rule_action,
            firewall_rule_group_id=firewall_rule_group_id,
            last_observed_at=last_observed_at,
            query_class=query_class,
            query_name=query_name,
            query_type=query_type,
            resources=resources,
            src_addr=src_addr,
            src_port=src_port,
            transport=transport,
            vpc_id=vpc_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "dnsFirewallBlockPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallBlock.DNSFirewallBlockProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "event_metadata": "eventMetadata",
            "firewall_domain_list_id": "firewallDomainListId",
            "firewall_rule_action": "firewallRuleAction",
            "firewall_rule_group_id": "firewallRuleGroupId",
            "last_observed_at": "lastObservedAt",
            "query_class": "queryClass",
            "query_name": "queryName",
            "query_type": "queryType",
            "resources": "resources",
            "src_addr": "srcAddr",
            "src_port": "srcPort",
            "transport": "transport",
            "vpc_id": "vpcId",
        },
    )
    class DNSFirewallBlockProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            firewall_domain_list_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            firewall_rule_action: typing.Optional[typing.Sequence[builtins.str]] = None,
            firewall_rule_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_observed_at: typing.Optional[typing.Sequence[builtins.str]] = None,
            query_class: typing.Optional[typing.Sequence[builtins.str]] = None,
            query_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            query_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            resources: typing.Optional[typing.Sequence[typing.Union["DNSFirewallBlock.DnsFirewallBlockItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            src_addr: typing.Optional[typing.Sequence[builtins.str]] = None,
            src_port: typing.Optional[typing.Sequence[builtins.str]] = None,
            transport: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.route53resolver@DNSFirewallBlock event.

            :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param firewall_domain_list_id: (experimental) firewall-domain-list-id property. Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the FirewallDomainList reference
            :param firewall_rule_action: (experimental) firewall-rule-action property. Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param firewall_rule_group_id: (experimental) firewall-rule-group-id property. Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_observed_at: (experimental) last-observed-at property. Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param query_class: (experimental) query-class property. Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param query_name: (experimental) query-name property. Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param query_type: (experimental) query-type property. Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param src_addr: (experimental) src-addr property. Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param src_port: (experimental) src-port property. Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transport: (experimental) transport property. Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpc-id property. Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
                
                d_nSFirewall_block_props = route53resolver_events.DNSFirewallBlock.DNSFirewallBlockProps(
                    account_id=["accountId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    firewall_domain_list_id=["firewallDomainListId"],
                    firewall_rule_action=["firewallRuleAction"],
                    firewall_rule_group_id=["firewallRuleGroupId"],
                    last_observed_at=["lastObservedAt"],
                    query_class=["queryClass"],
                    query_name=["queryName"],
                    query_type=["queryType"],
                    resources=[route53resolver_events.DNSFirewallBlock.DnsFirewallBlockItem(
                        resolver_endpoint_details=route53resolver_events.DNSFirewallBlock.ResolverEndpointDetails(
                            id=["id"]
                        ),
                        resolver_network_interface_details=route53resolver_events.DNSFirewallBlock.ResolverNetworkInterfaceDetails(
                            id=["id"]
                        ),
                        resource_type=["resourceType"]
                    )],
                    src_addr=["srcAddr"],
                    src_port=["srcPort"],
                    transport=["transport"],
                    vpc_id=["vpcId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8b0ac0346b905aeb2d9ae85b9f3c0cf85bdcb62ff57cd3fa2a151855ae89e258)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument firewall_domain_list_id", value=firewall_domain_list_id, expected_type=type_hints["firewall_domain_list_id"])
                check_type(argname="argument firewall_rule_action", value=firewall_rule_action, expected_type=type_hints["firewall_rule_action"])
                check_type(argname="argument firewall_rule_group_id", value=firewall_rule_group_id, expected_type=type_hints["firewall_rule_group_id"])
                check_type(argname="argument last_observed_at", value=last_observed_at, expected_type=type_hints["last_observed_at"])
                check_type(argname="argument query_class", value=query_class, expected_type=type_hints["query_class"])
                check_type(argname="argument query_name", value=query_name, expected_type=type_hints["query_name"])
                check_type(argname="argument query_type", value=query_type, expected_type=type_hints["query_type"])
                check_type(argname="argument resources", value=resources, expected_type=type_hints["resources"])
                check_type(argname="argument src_addr", value=src_addr, expected_type=type_hints["src_addr"])
                check_type(argname="argument src_port", value=src_port, expected_type=type_hints["src_port"])
                check_type(argname="argument transport", value=transport, expected_type=type_hints["transport"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if firewall_domain_list_id is not None:
                self._values["firewall_domain_list_id"] = firewall_domain_list_id
            if firewall_rule_action is not None:
                self._values["firewall_rule_action"] = firewall_rule_action
            if firewall_rule_group_id is not None:
                self._values["firewall_rule_group_id"] = firewall_rule_group_id
            if last_observed_at is not None:
                self._values["last_observed_at"] = last_observed_at
            if query_class is not None:
                self._values["query_class"] = query_class
            if query_name is not None:
                self._values["query_name"] = query_name
            if query_type is not None:
                self._values["query_type"] = query_type
            if resources is not None:
                self._values["resources"] = resources
            if src_addr is not None:
                self._values["src_addr"] = src_addr
            if src_port is not None:
                self._values["src_port"] = src_port
            if transport is not None:
                self._values["transport"] = transport
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) account-id property.

            Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def firewall_domain_list_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) firewall-domain-list-id property.

            Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the FirewallDomainList reference

            :stability: experimental
            '''
            result = self._values.get("firewall_domain_list_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def firewall_rule_action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) firewall-rule-action property.

            Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("firewall_rule_action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def firewall_rule_group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) firewall-rule-group-id property.

            Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("firewall_rule_group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_observed_at(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) last-observed-at property.

            Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_observed_at")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def query_class(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) query-class property.

            Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("query_class")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def query_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) query-name property.

            Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("query_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def query_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) query-type property.

            Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("query_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resources(
            self,
        ) -> typing.Optional[typing.List["DNSFirewallBlock.DnsFirewallBlockItem"]]:
            '''(experimental) resources property.

            Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resources")
            return typing.cast(typing.Optional[typing.List["DNSFirewallBlock.DnsFirewallBlockItem"]], result)

        @builtins.property
        def src_addr(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) src-addr property.

            Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("src_addr")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def src_port(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) src-port property.

            Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("src_port")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transport(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) transport property.

            Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transport")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpc-id property.

            Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DNSFirewallBlockProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallBlock.DnsFirewallBlockItem",
        jsii_struct_bases=[],
        name_mapping={
            "resolver_endpoint_details": "resolverEndpointDetails",
            "resolver_network_interface_details": "resolverNetworkInterfaceDetails",
            "resource_type": "resourceType",
        },
    )
    class DnsFirewallBlockItem:
        def __init__(
            self,
            *,
            resolver_endpoint_details: typing.Optional[typing.Union["DNSFirewallBlock.ResolverEndpointDetails", typing.Dict[builtins.str, typing.Any]]] = None,
            resolver_network_interface_details: typing.Optional[typing.Union["DNSFirewallBlock.ResolverNetworkInterfaceDetails", typing.Dict[builtins.str, typing.Any]]] = None,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DNSFirewallBlockItem.

            :param resolver_endpoint_details: (experimental) resolver-endpoint-details property. Specify an array of string values to match this event if the actual value of resolver-endpoint-details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resolver_network_interface_details: (experimental) resolver-network-interface-details property. Specify an array of string values to match this event if the actual value of resolver-network-interface-details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_type: (experimental) resource-type property. Specify an array of string values to match this event if the actual value of resource-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
                
                dns_firewall_block_item = route53resolver_events.DNSFirewallBlock.DnsFirewallBlockItem(
                    resolver_endpoint_details=route53resolver_events.DNSFirewallBlock.ResolverEndpointDetails(
                        id=["id"]
                    ),
                    resolver_network_interface_details=route53resolver_events.DNSFirewallBlock.ResolverNetworkInterfaceDetails(
                        id=["id"]
                    ),
                    resource_type=["resourceType"]
                )
            '''
            if isinstance(resolver_endpoint_details, dict):
                resolver_endpoint_details = DNSFirewallBlock.ResolverEndpointDetails(**resolver_endpoint_details)
            if isinstance(resolver_network_interface_details, dict):
                resolver_network_interface_details = DNSFirewallBlock.ResolverNetworkInterfaceDetails(**resolver_network_interface_details)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dbf9c8b91f12398788f6e6c31750c9085ec3cffb1afd7800ed6266a8e1d3a418)
                check_type(argname="argument resolver_endpoint_details", value=resolver_endpoint_details, expected_type=type_hints["resolver_endpoint_details"])
                check_type(argname="argument resolver_network_interface_details", value=resolver_network_interface_details, expected_type=type_hints["resolver_network_interface_details"])
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if resolver_endpoint_details is not None:
                self._values["resolver_endpoint_details"] = resolver_endpoint_details
            if resolver_network_interface_details is not None:
                self._values["resolver_network_interface_details"] = resolver_network_interface_details
            if resource_type is not None:
                self._values["resource_type"] = resource_type

        @builtins.property
        def resolver_endpoint_details(
            self,
        ) -> typing.Optional["DNSFirewallBlock.ResolverEndpointDetails"]:
            '''(experimental) resolver-endpoint-details property.

            Specify an array of string values to match this event if the actual value of resolver-endpoint-details is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resolver_endpoint_details")
            return typing.cast(typing.Optional["DNSFirewallBlock.ResolverEndpointDetails"], result)

        @builtins.property
        def resolver_network_interface_details(
            self,
        ) -> typing.Optional["DNSFirewallBlock.ResolverNetworkInterfaceDetails"]:
            '''(experimental) resolver-network-interface-details property.

            Specify an array of string values to match this event if the actual value of resolver-network-interface-details is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resolver_network_interface_details")
            return typing.cast(typing.Optional["DNSFirewallBlock.ResolverNetworkInterfaceDetails"], result)

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resource-type property.

            Specify an array of string values to match this event if the actual value of resource-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DnsFirewallBlockItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallBlock.ResolverEndpointDetails",
        jsii_struct_bases=[],
        name_mapping={"id": "id"},
    )
    class ResolverEndpointDetails:
        def __init__(
            self,
            *,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Resolver-endpoint-details.

            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
                
                resolver_endpoint_details = route53resolver_events.DNSFirewallBlock.ResolverEndpointDetails(
                    id=["id"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7e291cc3f81ef202c114642a9276c4967f6a12a4b16d846d5bf785cb40ba7674)
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if id is not None:
                self._values["id"] = id

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResolverEndpointDetails(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.DNSFirewallBlock.ResolverNetworkInterfaceDetails",
        jsii_struct_bases=[],
        name_mapping={"id": "id"},
    )
    class ResolverNetworkInterfaceDetails:
        def __init__(
            self,
            *,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Resolver-network-interface-details.

            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
                
                resolver_network_interface_details = route53resolver_events.DNSFirewallBlock.ResolverNetworkInterfaceDetails(
                    id=["id"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9e5f3a8100dcccdd6c74667b42e0e5ac263cc9473147d3f0102fb55412c27950)
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if id is not None:
                self._values["id"] = id

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResolverNetworkInterfaceDetails(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class FirewallDomainListEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53resolver.events.FirewallDomainListEvents",
):
    '''(experimental) EventBridge event patterns for FirewallDomainList.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_route53resolver import events as route53resolver_events
        from aws_cdk.interfaces import aws_route53resolver as interfaces_route53resolver
        
        # firewall_domain_list_ref: interfaces_route53resolver.IFirewallDomainListRef
        
        firewall_domain_list_events = route53resolver_events.FirewallDomainListEvents.from_firewall_domain_list(firewall_domain_list_ref)
    '''

    @jsii.member(jsii_name="fromFirewallDomainList")
    @builtins.classmethod
    def from_firewall_domain_list(
        cls,
        firewall_domain_list_ref: "_aws_cdk_interfaces_aws_route53resolver_ceddda9d.IFirewallDomainListRef",
    ) -> "FirewallDomainListEvents":
        '''(experimental) Create FirewallDomainListEvents from a FirewallDomainList reference.

        :param firewall_domain_list_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d8f9333cd1abe443af66f332fb80ff4c96606a874572ac7aa4bd4d41552113fa)
            check_type(argname="argument firewall_domain_list_ref", value=firewall_domain_list_ref, expected_type=type_hints["firewall_domain_list_ref"])
        return typing.cast("FirewallDomainListEvents", jsii.sinvoke(cls, "fromFirewallDomainList", [firewall_domain_list_ref]))

    @jsii.member(jsii_name="dnsFirewallAlertPattern")
    def dns_firewall_alert_pattern(
        self,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        firewall_domain_list_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        firewall_rule_action: typing.Optional[typing.Sequence[builtins.str]] = None,
        firewall_rule_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        last_observed_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_class: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        resources: typing.Optional[typing.Sequence[typing.Union["DNSFirewallAlert.DnsFirewallAlertItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        src_addr: typing.Optional[typing.Sequence[builtins.str]] = None,
        src_port: typing.Optional[typing.Sequence[builtins.str]] = None,
        transport: typing.Optional[typing.Sequence[builtins.str]] = None,
        vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for FirewallDomainList DNS Firewall Alert.

        :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param firewall_domain_list_id: (experimental) firewall-domain-list-id property. Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the FirewallDomainList reference
        :param firewall_rule_action: (experimental) firewall-rule-action property. Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param firewall_rule_group_id: (experimental) firewall-rule-group-id property. Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param last_observed_at: (experimental) last-observed-at property. Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_class: (experimental) query-class property. Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_name: (experimental) query-name property. Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_type: (experimental) query-type property. Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param src_addr: (experimental) src-addr property. Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param src_port: (experimental) src-port property. Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transport: (experimental) transport property. Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param vpc_id: (experimental) vpc-id property. Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DNSFirewallAlert.DNSFirewallAlertProps(
            account_id=account_id,
            event_metadata=event_metadata,
            firewall_domain_list_id=firewall_domain_list_id,
            firewall_rule_action=firewall_rule_action,
            firewall_rule_group_id=firewall_rule_group_id,
            last_observed_at=last_observed_at,
            query_class=query_class,
            query_name=query_name,
            query_type=query_type,
            resources=resources,
            src_addr=src_addr,
            src_port=src_port,
            transport=transport,
            vpc_id=vpc_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "dnsFirewallAlertPattern", [options]))

    @jsii.member(jsii_name="dnsFirewallBlockPattern")
    def dns_firewall_block_pattern(
        self,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        firewall_domain_list_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        firewall_rule_action: typing.Optional[typing.Sequence[builtins.str]] = None,
        firewall_rule_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        last_observed_at: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_class: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        query_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        resources: typing.Optional[typing.Sequence[typing.Union["DNSFirewallBlock.DnsFirewallBlockItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        src_addr: typing.Optional[typing.Sequence[builtins.str]] = None,
        src_port: typing.Optional[typing.Sequence[builtins.str]] = None,
        transport: typing.Optional[typing.Sequence[builtins.str]] = None,
        vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for FirewallDomainList DNS Firewall Block.

        :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param firewall_domain_list_id: (experimental) firewall-domain-list-id property. Specify an array of string values to match this event if the actual value of firewall-domain-list-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the FirewallDomainList reference
        :param firewall_rule_action: (experimental) firewall-rule-action property. Specify an array of string values to match this event if the actual value of firewall-rule-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param firewall_rule_group_id: (experimental) firewall-rule-group-id property. Specify an array of string values to match this event if the actual value of firewall-rule-group-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param last_observed_at: (experimental) last-observed-at property. Specify an array of string values to match this event if the actual value of last-observed-at is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_class: (experimental) query-class property. Specify an array of string values to match this event if the actual value of query-class is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_name: (experimental) query-name property. Specify an array of string values to match this event if the actual value of query-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param query_type: (experimental) query-type property. Specify an array of string values to match this event if the actual value of query-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param src_addr: (experimental) src-addr property. Specify an array of string values to match this event if the actual value of src-addr is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param src_port: (experimental) src-port property. Specify an array of string values to match this event if the actual value of src-port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transport: (experimental) transport property. Specify an array of string values to match this event if the actual value of transport is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param vpc_id: (experimental) vpc-id property. Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = DNSFirewallBlock.DNSFirewallBlockProps(
            account_id=account_id,
            event_metadata=event_metadata,
            firewall_domain_list_id=firewall_domain_list_id,
            firewall_rule_action=firewall_rule_action,
            firewall_rule_group_id=firewall_rule_group_id,
            last_observed_at=last_observed_at,
            query_class=query_class,
            query_name=query_name,
            query_type=query_type,
            resources=resources,
            src_addr=src_addr,
            src_port=src_port,
            transport=transport,
            vpc_id=vpc_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "dnsFirewallBlockPattern", [options]))


__all__ = [
    "DNSFirewallAlert",
    "DNSFirewallBlock",
    "FirewallDomainListEvents",
]

publication.publish()

def _typecheckingstub__23f2f53eb699ea89ac3146f408835e5e0c4c177494e9b8ea6b0425beac31be7c(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    firewall_domain_list_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    firewall_rule_action: typing.Optional[typing.Sequence[builtins.str]] = None,
    firewall_rule_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_observed_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    query_class: typing.Optional[typing.Sequence[builtins.str]] = None,
    query_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    query_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    resources: typing.Optional[typing.Sequence[typing.Union[DNSFirewallAlert.DnsFirewallAlertItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    src_addr: typing.Optional[typing.Sequence[builtins.str]] = None,
    src_port: typing.Optional[typing.Sequence[builtins.str]] = None,
    transport: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6431c55a80727de8247c2d2ac3e4102a48f533523a1c31fc1b5fb33c4e90662(
    *,
    resolver_endpoint_details: typing.Optional[typing.Union[DNSFirewallAlert.ResolverEndpointDetails, typing.Dict[builtins.str, typing.Any]]] = None,
    resolver_network_interface_details: typing.Optional[typing.Union[DNSFirewallAlert.ResolverNetworkInterfaceDetails, typing.Dict[builtins.str, typing.Any]]] = None,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e506e2c59b19c89c853c460697b59e137f57e77db8228f8bca95ff5fcf6e5e5a(
    *,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7572e3368fc8d38f9ead48efda20b177e9a445fd0a8c7cc601d9af2921270950(
    *,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8b0ac0346b905aeb2d9ae85b9f3c0cf85bdcb62ff57cd3fa2a151855ae89e258(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    firewall_domain_list_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    firewall_rule_action: typing.Optional[typing.Sequence[builtins.str]] = None,
    firewall_rule_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_observed_at: typing.Optional[typing.Sequence[builtins.str]] = None,
    query_class: typing.Optional[typing.Sequence[builtins.str]] = None,
    query_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    query_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    resources: typing.Optional[typing.Sequence[typing.Union[DNSFirewallBlock.DnsFirewallBlockItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    src_addr: typing.Optional[typing.Sequence[builtins.str]] = None,
    src_port: typing.Optional[typing.Sequence[builtins.str]] = None,
    transport: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dbf9c8b91f12398788f6e6c31750c9085ec3cffb1afd7800ed6266a8e1d3a418(
    *,
    resolver_endpoint_details: typing.Optional[typing.Union[DNSFirewallBlock.ResolverEndpointDetails, typing.Dict[builtins.str, typing.Any]]] = None,
    resolver_network_interface_details: typing.Optional[typing.Union[DNSFirewallBlock.ResolverNetworkInterfaceDetails, typing.Dict[builtins.str, typing.Any]]] = None,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e291cc3f81ef202c114642a9276c4967f6a12a4b16d846d5bf785cb40ba7674(
    *,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e5f3a8100dcccdd6c74667b42e0e5ac263cc9473147d3f0102fb55412c27950(
    *,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8f9333cd1abe443af66f332fb80ff4c96606a874572ac7aa4bd4d41552113fa(
    firewall_domain_list_ref: _aws_cdk_interfaces_aws_route53resolver_ceddda9d.IFirewallDomainListRef,
) -> None:
    """Type checking stubs"""
    pass
