from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class FISExperimentStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_fis.events.FISExperimentStateChange",
):
    '''(experimental) EventBridge event pattern for aws.fis@FISExperimentStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_fis import events as fis_events
        
        f_iSExperiment_state_change = fis_events.FISExperimentStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="fisExperimentStateChangePattern")
    @builtins.classmethod
    def fis_experiment_state_change_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        experiment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        new_state: typing.Optional[typing.Union["FISExperimentStateChange.NewState", typing.Dict[builtins.str, typing.Any]]] = None,
        old_state: typing.Optional[typing.Union["FISExperimentStateChange.OldState", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for FIS Experiment State Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param experiment_id: (experimental) experiment-id property. Specify an array of string values to match this event if the actual value of experiment-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param new_state: (experimental) new-state property. Specify an array of string values to match this event if the actual value of new-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param old_state: (experimental) old-state property. Specify an array of string values to match this event if the actual value of old-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = FISExperimentStateChange.FISExperimentStateChangeProps(
            event_metadata=event_metadata,
            experiment_id=experiment_id,
            new_state=new_state,
            old_state=old_state,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "fisExperimentStateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_fis.events.FISExperimentStateChange.FISExperimentStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "experiment_id": "experimentId",
            "new_state": "newState",
            "old_state": "oldState",
        },
    )
    class FISExperimentStateChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            experiment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            new_state: typing.Optional[typing.Union["FISExperimentStateChange.NewState", typing.Dict[builtins.str, typing.Any]]] = None,
            old_state: typing.Optional[typing.Union["FISExperimentStateChange.OldState", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.fis@FISExperimentStateChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param experiment_id: (experimental) experiment-id property. Specify an array of string values to match this event if the actual value of experiment-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param new_state: (experimental) new-state property. Specify an array of string values to match this event if the actual value of new-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param old_state: (experimental) old-state property. Specify an array of string values to match this event if the actual value of old-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_fis import events as fis_events
                
                f_iSExperiment_state_change_props = fis_events.FISExperimentStateChange.FISExperimentStateChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    experiment_id=["experimentId"],
                    new_state=fis_events.FISExperimentStateChange.NewState(
                        reason=["reason"],
                        status=["status"]
                    ),
                    old_state=fis_events.FISExperimentStateChange.OldState(
                        reason=["reason"],
                        status=["status"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(new_state, dict):
                new_state = FISExperimentStateChange.NewState(**new_state)
            if isinstance(old_state, dict):
                old_state = FISExperimentStateChange.OldState(**old_state)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7d48447edae588457dc847b4c8698d29b03fb0dd33c7bcaec798422bcdea7f13)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument experiment_id", value=experiment_id, expected_type=type_hints["experiment_id"])
                check_type(argname="argument new_state", value=new_state, expected_type=type_hints["new_state"])
                check_type(argname="argument old_state", value=old_state, expected_type=type_hints["old_state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if experiment_id is not None:
                self._values["experiment_id"] = experiment_id
            if new_state is not None:
                self._values["new_state"] = new_state
            if old_state is not None:
                self._values["old_state"] = old_state

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def experiment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) experiment-id property.

            Specify an array of string values to match this event if the actual value of experiment-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("experiment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def new_state(self) -> typing.Optional["FISExperimentStateChange.NewState"]:
            '''(experimental) new-state property.

            Specify an array of string values to match this event if the actual value of new-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("new_state")
            return typing.cast(typing.Optional["FISExperimentStateChange.NewState"], result)

        @builtins.property
        def old_state(self) -> typing.Optional["FISExperimentStateChange.OldState"]:
            '''(experimental) old-state property.

            Specify an array of string values to match this event if the actual value of old-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("old_state")
            return typing.cast(typing.Optional["FISExperimentStateChange.OldState"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FISExperimentStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_fis.events.FISExperimentStateChange.NewState",
        jsii_struct_bases=[],
        name_mapping={"reason": "reason", "status": "status"},
    )
    class NewState:
        def __init__(
            self,
            *,
            reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for New-state.

            :param reason: (experimental) reason property. Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_fis import events as fis_events
                
                new_state = fis_events.FISExperimentStateChange.NewState(
                    reason=["reason"],
                    status=["status"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e2bb494d7553f25f8f3393fc49f3ae7674c52328b9b151c0f2e11d76f97d9f71)
                check_type(argname="argument reason", value=reason, expected_type=type_hints["reason"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if reason is not None:
                self._values["reason"] = reason
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reason property.

            Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NewState(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_fis.events.FISExperimentStateChange.OldState",
        jsii_struct_bases=[],
        name_mapping={"reason": "reason", "status": "status"},
    )
    class OldState:
        def __init__(
            self,
            *,
            reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Old-state.

            :param reason: (experimental) reason property. Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_fis import events as fis_events
                
                old_state = fis_events.FISExperimentStateChange.OldState(
                    reason=["reason"],
                    status=["status"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__55dc43bd4923cb329c3d42aa28c7cdc4bd5f8addd3bf31629c9fa156d39b5804)
                check_type(argname="argument reason", value=reason, expected_type=type_hints["reason"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if reason is not None:
                self._values["reason"] = reason
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reason property.

            Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OldState(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "FISExperimentStateChange",
]

publication.publish()

def _typecheckingstub__7d48447edae588457dc847b4c8698d29b03fb0dd33c7bcaec798422bcdea7f13(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    experiment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    new_state: typing.Optional[typing.Union[FISExperimentStateChange.NewState, typing.Dict[builtins.str, typing.Any]]] = None,
    old_state: typing.Optional[typing.Union[FISExperimentStateChange.OldState, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2bb494d7553f25f8f3393fc49f3ae7674c52328b9b151c0f2e11d76f97d9f71(
    *,
    reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__55dc43bd4923cb329c3d42aa28c7cdc4bd5f8addd3bf31629c9fa156d39b5804(
    *,
    reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
