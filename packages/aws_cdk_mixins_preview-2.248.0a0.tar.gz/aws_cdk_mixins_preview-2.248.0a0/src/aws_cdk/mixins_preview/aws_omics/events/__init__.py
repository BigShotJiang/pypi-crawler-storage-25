from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_omics as _aws_cdk_interfaces_aws_omics_ceddda9d


class AnnotationImportJobStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.AnnotationImportJobStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@AnnotationImportJobStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        annotation_import_job_status_change = omics_events.AnnotationImportJobStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="annotationImportJobStatusChangePattern")
    @builtins.classmethod
    def annotation_import_job_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Annotation Import Job Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_name: (experimental) storeName property. Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AnnotationImportJobStatusChange.AnnotationImportJobStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            job_id=job_id,
            omics_version=omics_version,
            status=status,
            store_id=store_id,
            store_name=store_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "annotationImportJobStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.AnnotationImportJobStatusChange.AnnotationImportJobStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "job_id": "jobId",
            "omics_version": "omicsVersion",
            "status": "status",
            "store_id": "storeId",
            "store_name": "storeName",
        },
    )
    class AnnotationImportJobStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@AnnotationImportJobStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_name: (experimental) storeName property. Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                annotation_import_job_status_change_props = omics_events.AnnotationImportJobStatusChange.AnnotationImportJobStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    job_id=["jobId"],
                    omics_version=["omicsVersion"],
                    status=["status"],
                    store_id=["storeId"],
                    store_name=["storeName"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c72b8d895d3595d05b5d55dd8d4df3cd3acf39db45a43791e2c2d92dae017287)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument store_id", value=store_id, expected_type=type_hints["store_id"])
                check_type(argname="argument store_name", value=store_name, expected_type=type_hints["store_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if job_id is not None:
                self._values["job_id"] = job_id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status
            if store_id is not None:
                self._values["store_id"] = store_id
            if store_name is not None:
                self._values["store_name"] = store_name

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeId property.

            Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeName property.

            Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnnotationImportJobStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class AnnotationStoreStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.AnnotationStoreStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@AnnotationStoreStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        annotation_store_status_change = omics_events.AnnotationStoreStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="annotationStoreStatusChangePattern")
    @builtins.classmethod
    def annotation_store_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Annotation Store Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_name: (experimental) storeName property. Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AnnotationStoreStatusChange.AnnotationStoreStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            omics_version=omics_version,
            status=status,
            store_id=store_id,
            store_name=store_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "annotationStoreStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.AnnotationStoreStatusChange.AnnotationStoreStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "omics_version": "omicsVersion",
            "status": "status",
            "store_id": "storeId",
            "store_name": "storeName",
        },
    )
    class AnnotationStoreStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@AnnotationStoreStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_name: (experimental) storeName property. Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                annotation_store_status_change_props = omics_events.AnnotationStoreStatusChange.AnnotationStoreStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    omics_version=["omicsVersion"],
                    status=["status"],
                    store_id=["storeId"],
                    store_name=["storeName"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__681393264779d1c805d71da13d4b885f62e8088bd778427635c1e90c833ff512)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument store_id", value=store_id, expected_type=type_hints["store_id"])
                check_type(argname="argument store_name", value=store_name, expected_type=type_hints["store_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status
            if store_id is not None:
                self._values["store_id"] = store_id
            if store_name is not None:
                self._values["store_name"] = store_name

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeId property.

            Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeName property.

            Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AnnotationStoreStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ReadSetActivationJobStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReadSetActivationJobStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@ReadSetActivationJobStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        read_set_activation_job_status_change = omics_events.ReadSetActivationJobStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="readSetActivationJobStatusChangePattern")
    @builtins.classmethod
    def read_set_activation_job_status_change_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Read Set Activation Job Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReadSetActivationJobStatusChange.ReadSetActivationJobStatusChangeProps(
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            sequence_store_id=sequence_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "readSetActivationJobStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReadSetActivationJobStatusChange.ReadSetActivationJobStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "id": "id",
            "omics_version": "omicsVersion",
            "sequence_store_id": "sequenceStoreId",
            "status": "status",
            "status_message": "statusMessage",
        },
    )
    class ReadSetActivationJobStatusChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@ReadSetActivationJobStatusChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                read_set_activation_job_status_change_props = omics_events.ReadSetActivationJobStatusChange.ReadSetActivationJobStatusChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    id=["id"],
                    omics_version=["omicsVersion"],
                    sequence_store_id=["sequenceStoreId"],
                    status=["status"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__713627e1b870a1d2c2adafa10ff21838f8fb0c03e38711dcd711bfd486244428)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument sequence_store_id", value=sequence_store_id, expected_type=type_hints["sequence_store_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if id is not None:
                self._values["id"] = id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if sequence_store_id is not None:
                self._values["sequence_store_id"] = sequence_store_id
            if status is not None:
                self._values["status"] = status
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def sequence_store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sequenceStoreId property.

            Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the SequenceStore reference

            :stability: experimental
            '''
            result = self._values.get("sequence_store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) statusMessage property.

            Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReadSetActivationJobStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ReadSetExportJobStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReadSetExportJobStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@ReadSetExportJobStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        read_set_export_job_status_change = omics_events.ReadSetExportJobStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="readSetExportJobStatusChangePattern")
    @builtins.classmethod
    def read_set_export_job_status_change_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Read Set Export Job Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReadSetExportJobStatusChange.ReadSetExportJobStatusChangeProps(
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            sequence_store_id=sequence_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "readSetExportJobStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReadSetExportJobStatusChange.ReadSetExportJobStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "id": "id",
            "omics_version": "omicsVersion",
            "sequence_store_id": "sequenceStoreId",
            "status": "status",
            "status_message": "statusMessage",
        },
    )
    class ReadSetExportJobStatusChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@ReadSetExportJobStatusChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                read_set_export_job_status_change_props = omics_events.ReadSetExportJobStatusChange.ReadSetExportJobStatusChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    id=["id"],
                    omics_version=["omicsVersion"],
                    sequence_store_id=["sequenceStoreId"],
                    status=["status"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__adce5dcb9e4b0023391d24b468d01cd2ca98bc9794d1633b9b11d8ddde3492e3)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument sequence_store_id", value=sequence_store_id, expected_type=type_hints["sequence_store_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if id is not None:
                self._values["id"] = id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if sequence_store_id is not None:
                self._values["sequence_store_id"] = sequence_store_id
            if status is not None:
                self._values["status"] = status
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def sequence_store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sequenceStoreId property.

            Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the SequenceStore reference

            :stability: experimental
            '''
            result = self._values.get("sequence_store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) statusMessage property.

            Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReadSetExportJobStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ReadSetImportJobStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReadSetImportJobStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@ReadSetImportJobStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        read_set_import_job_status_change = omics_events.ReadSetImportJobStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="readSetImportJobStatusChangePattern")
    @builtins.classmethod
    def read_set_import_job_status_change_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Read Set Import Job Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReadSetImportJobStatusChange.ReadSetImportJobStatusChangeProps(
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            sequence_store_id=sequence_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "readSetImportJobStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReadSetImportJobStatusChange.ReadSetImportJobStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "id": "id",
            "omics_version": "omicsVersion",
            "sequence_store_id": "sequenceStoreId",
            "status": "status",
            "status_message": "statusMessage",
        },
    )
    class ReadSetImportJobStatusChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@ReadSetImportJobStatusChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                read_set_import_job_status_change_props = omics_events.ReadSetImportJobStatusChange.ReadSetImportJobStatusChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    id=["id"],
                    omics_version=["omicsVersion"],
                    sequence_store_id=["sequenceStoreId"],
                    status=["status"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__519e90f2fa92d66055a86b0a8209cb77fed258dce133e558eab50bf873e90701)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument sequence_store_id", value=sequence_store_id, expected_type=type_hints["sequence_store_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if id is not None:
                self._values["id"] = id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if sequence_store_id is not None:
                self._values["sequence_store_id"] = sequence_store_id
            if status is not None:
                self._values["status"] = status
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def sequence_store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sequenceStoreId property.

            Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the SequenceStore reference

            :stability: experimental
            '''
            result = self._values.get("sequence_store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) statusMessage property.

            Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReadSetImportJobStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ReadSetStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReadSetStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@ReadSetStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        read_set_status_change = omics_events.ReadSetStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="readSetStatusChangePattern")
    @builtins.classmethod
    def read_set_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        creation_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Read Set Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param creation_job_id: (experimental) creationJobId property. Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReadSetStatusChange.ReadSetStatusChangeProps(
            arn=arn,
            creation_job_id=creation_job_id,
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            sequence_store_id=sequence_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "readSetStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReadSetStatusChange.ReadSetStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "creation_job_id": "creationJobId",
            "event_metadata": "eventMetadata",
            "id": "id",
            "omics_version": "omicsVersion",
            "sequence_store_id": "sequenceStoreId",
            "status": "status",
            "status_message": "statusMessage",
        },
    )
    class ReadSetStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            creation_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@ReadSetStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param creation_job_id: (experimental) creationJobId property. Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                read_set_status_change_props = omics_events.ReadSetStatusChange.ReadSetStatusChangeProps(
                    arn=["arn"],
                    creation_job_id=["creationJobId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    id=["id"],
                    omics_version=["omicsVersion"],
                    sequence_store_id=["sequenceStoreId"],
                    status=["status"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__cc0deb1970bccbc08259b6ec55d2a37a7e507742e9c413df961de2527ea39927)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument creation_job_id", value=creation_job_id, expected_type=type_hints["creation_job_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument sequence_store_id", value=sequence_store_id, expected_type=type_hints["sequence_store_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if creation_job_id is not None:
                self._values["creation_job_id"] = creation_job_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if id is not None:
                self._values["id"] = id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if sequence_store_id is not None:
                self._values["sequence_store_id"] = sequence_store_id
            if status is not None:
                self._values["status"] = status
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def creation_job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationJobId property.

            Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def sequence_store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sequenceStoreId property.

            Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the SequenceStore reference

            :stability: experimental
            '''
            result = self._values.get("sequence_store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) statusMessage property.

            Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReadSetStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ReferenceImportJobStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReferenceImportJobStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@ReferenceImportJobStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        reference_import_job_status_change = omics_events.ReferenceImportJobStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="referenceImportJobStatusChangePattern")
    @builtins.classmethod
    def reference_import_job_status_change_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Reference Import Job Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_store_id: (experimental) referenceStoreId property. Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the ReferenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReferenceImportJobStatusChange.ReferenceImportJobStatusChangeProps(
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            reference_store_id=reference_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "referenceImportJobStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReferenceImportJobStatusChange.ReferenceImportJobStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "id": "id",
            "omics_version": "omicsVersion",
            "reference_store_id": "referenceStoreId",
            "status": "status",
            "status_message": "statusMessage",
        },
    )
    class ReferenceImportJobStatusChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@ReferenceImportJobStatusChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_store_id: (experimental) referenceStoreId property. Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the ReferenceStore reference
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                reference_import_job_status_change_props = omics_events.ReferenceImportJobStatusChange.ReferenceImportJobStatusChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    id=["id"],
                    omics_version=["omicsVersion"],
                    reference_store_id=["referenceStoreId"],
                    status=["status"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f9802e626f28aa845fda89e01a5425d90c48ef000ca4ea9849c83aa5c0d1aa25)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument reference_store_id", value=reference_store_id, expected_type=type_hints["reference_store_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if id is not None:
                self._values["id"] = id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if reference_store_id is not None:
                self._values["reference_store_id"] = reference_store_id
            if status is not None:
                self._values["status"] = status
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) referenceStoreId property.

            Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the ReferenceStore reference

            :stability: experimental
            '''
            result = self._values.get("reference_store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) statusMessage property.

            Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReferenceImportJobStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ReferenceStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReferenceStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@ReferenceStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        reference_status_change = omics_events.ReferenceStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="referenceStatusChangePattern")
    @builtins.classmethod
    def reference_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        creation_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Reference Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param creation_job_id: (experimental) creationJobId property. Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_store_id: (experimental) referenceStoreId property. Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the ReferenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReferenceStatusChange.ReferenceStatusChangeProps(
            arn=arn,
            creation_job_id=creation_job_id,
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            reference_store_id=reference_store_id,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "referenceStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReferenceStatusChange.ReferenceStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "creation_job_id": "creationJobId",
            "event_metadata": "eventMetadata",
            "id": "id",
            "omics_version": "omicsVersion",
            "reference_store_id": "referenceStoreId",
            "status": "status",
        },
    )
    class ReferenceStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            creation_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@ReferenceStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param creation_job_id: (experimental) creationJobId property. Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_store_id: (experimental) referenceStoreId property. Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the ReferenceStore reference
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                reference_status_change_props = omics_events.ReferenceStatusChange.ReferenceStatusChangeProps(
                    arn=["arn"],
                    creation_job_id=["creationJobId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    id=["id"],
                    omics_version=["omicsVersion"],
                    reference_store_id=["referenceStoreId"],
                    status=["status"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__99a0da59d076d87b455a933f8797e1eb74f20356d7b354e589eb29a13c49c877)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument creation_job_id", value=creation_job_id, expected_type=type_hints["creation_job_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument reference_store_id", value=reference_store_id, expected_type=type_hints["reference_store_id"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if creation_job_id is not None:
                self._values["creation_job_id"] = creation_job_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if id is not None:
                self._values["id"] = id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if reference_store_id is not None:
                self._values["reference_store_id"] = reference_store_id
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def creation_job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationJobId property.

            Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) referenceStoreId property.

            Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the ReferenceStore reference

            :stability: experimental
            '''
            result = self._values.get("reference_store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReferenceStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ReferenceStoreEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReferenceStoreEvents",
):
    '''(experimental) EventBridge event patterns for ReferenceStore.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        from aws_cdk.interfaces import aws_omics as interfaces_omics
        
        # reference_store_ref: interfaces_omics.IReferenceStoreRef
        
        reference_store_events = omics_events.ReferenceStoreEvents.from_reference_store(reference_store_ref)
    '''

    @jsii.member(jsii_name="fromReferenceStore")
    @builtins.classmethod
    def from_reference_store(
        cls,
        reference_store_ref: "_aws_cdk_interfaces_aws_omics_ceddda9d.IReferenceStoreRef",
    ) -> "ReferenceStoreEvents":
        '''(experimental) Create ReferenceStoreEvents from a ReferenceStore reference.

        :param reference_store_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3525328e1da009f9db687f5649739881ec604ae1f81b03cb7050db2bbb055432)
            check_type(argname="argument reference_store_ref", value=reference_store_ref, expected_type=type_hints["reference_store_ref"])
        return typing.cast("ReferenceStoreEvents", jsii.sinvoke(cls, "fromReferenceStore", [reference_store_ref]))

    @jsii.member(jsii_name="referenceImportJobStatusChangePattern")
    def reference_import_job_status_change_pattern(
        self,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for ReferenceStore Reference Import Job Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_store_id: (experimental) referenceStoreId property. Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the ReferenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReferenceImportJobStatusChange.ReferenceImportJobStatusChangeProps(
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            reference_store_id=reference_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "referenceImportJobStatusChangePattern", [options]))

    @jsii.member(jsii_name="referenceStatusChangePattern")
    def reference_status_change_pattern(
        self,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        creation_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for ReferenceStore Reference Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param creation_job_id: (experimental) creationJobId property. Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_store_id: (experimental) referenceStoreId property. Specify an array of string values to match this event if the actual value of referenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the ReferenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReferenceStatusChange.ReferenceStatusChangeProps(
            arn=arn,
            creation_job_id=creation_job_id,
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            reference_store_id=reference_store_id,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "referenceStatusChangePattern", [options]))


class ReferenceStoreStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReferenceStoreStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@ReferenceStoreStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        reference_store_status_change = omics_events.ReferenceStoreStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="referenceStoreStatusChangePattern")
    @builtins.classmethod
    def reference_store_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Reference Store Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReferenceStoreStatusChange.ReferenceStoreStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "referenceStoreStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.ReferenceStoreStatusChange.ReferenceStoreStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "id": "id",
            "omics_version": "omicsVersion",
            "status": "status",
        },
    )
    class ReferenceStoreStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@ReferenceStoreStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                reference_store_status_change_props = omics_events.ReferenceStoreStatusChange.ReferenceStoreStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    id=["id"],
                    omics_version=["omicsVersion"],
                    status=["status"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__71dccdf589d4a9a045af274a7f61071c016d2a4fcda97c7a7e0b006576c84815)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if id is not None:
                self._values["id"] = id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ReferenceStoreStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RunStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.RunStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@RunStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        run_status_change = omics_events.RunStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="runStatusChangePattern")
    @builtins.classmethod
    def run_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Run Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RunStatusChange.RunStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            omics_version=omics_version,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "runStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.RunStatusChange.RunStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "omics_version": "omicsVersion",
            "status": "status",
        },
    )
    class RunStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@RunStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                run_status_change_props = omics_events.RunStatusChange.RunStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    omics_version=["omicsVersion"],
                    status=["status"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__cc8e1a9845fbf36450f246f7e9be0159cd41381a63bd9043bdd53c7c8a5e6669)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RunStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class S3AccessPolicyStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.S3AccessPolicyStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@S3AccessPolicyStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        s3_access_policy_status_change = omics_events.S3AccessPolicyStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="s3AccessPolicyStatusChangePattern")
    @builtins.classmethod
    def s3_access_policy_status_change_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        s3_access_point_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for S3 Access Policy Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param s3_access_point_arn: (experimental) s3AccessPointArn property. Specify an array of string values to match this event if the actual value of s3AccessPointArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_type: (experimental) storeType property. Specify an array of string values to match this event if the actual value of storeType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = S3AccessPolicyStatusChange.S3AccessPolicyStatusChangeProps(
            event_metadata=event_metadata,
            omics_version=omics_version,
            s3_access_point_arn=s3_access_point_arn,
            status=status,
            store_id=store_id,
            store_type=store_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "s3AccessPolicyStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.S3AccessPolicyStatusChange.S3AccessPolicyStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "omics_version": "omicsVersion",
            "s3_access_point_arn": "s3AccessPointArn",
            "status": "status",
            "store_id": "storeId",
            "store_type": "storeType",
        },
    )
    class S3AccessPolicyStatusChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_access_point_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@S3AccessPolicyStatusChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_access_point_arn: (experimental) s3AccessPointArn property. Specify an array of string values to match this event if the actual value of s3AccessPointArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_type: (experimental) storeType property. Specify an array of string values to match this event if the actual value of storeType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                s3_access_policy_status_change_props = omics_events.S3AccessPolicyStatusChange.S3AccessPolicyStatusChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    omics_version=["omicsVersion"],
                    s3_access_point_arn=["s3AccessPointArn"],
                    status=["status"],
                    store_id=["storeId"],
                    store_type=["storeType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f1da041bc6cc8a53bdc3fdf2b2699fd55805a6224bdd8458bff5085dc5f6f097)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument s3_access_point_arn", value=s3_access_point_arn, expected_type=type_hints["s3_access_point_arn"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument store_id", value=store_id, expected_type=type_hints["store_id"])
                check_type(argname="argument store_type", value=store_type, expected_type=type_hints["store_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if s3_access_point_arn is not None:
                self._values["s3_access_point_arn"] = s3_access_point_arn
            if status is not None:
                self._values["status"] = status
            if store_id is not None:
                self._values["store_id"] = store_id
            if store_type is not None:
                self._values["store_type"] = store_type

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_access_point_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3AccessPointArn property.

            Specify an array of string values to match this event if the actual value of s3AccessPointArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_access_point_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeId property.

            Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeType property.

            Specify an array of string values to match this event if the actual value of storeType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "S3AccessPolicyStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SequenceStoreEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.SequenceStoreEvents",
):
    '''(experimental) EventBridge event patterns for SequenceStore.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        from aws_cdk.interfaces import aws_omics as interfaces_omics
        
        # sequence_store_ref: interfaces_omics.ISequenceStoreRef
        
        sequence_store_events = omics_events.SequenceStoreEvents.from_sequence_store(sequence_store_ref)
    '''

    @jsii.member(jsii_name="fromSequenceStore")
    @builtins.classmethod
    def from_sequence_store(
        cls,
        sequence_store_ref: "_aws_cdk_interfaces_aws_omics_ceddda9d.ISequenceStoreRef",
    ) -> "SequenceStoreEvents":
        '''(experimental) Create SequenceStoreEvents from a SequenceStore reference.

        :param sequence_store_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7fdeb323027e6ff7c9a852433dc84cd9b3db351345a19ee02d41a5b219eb74b7)
            check_type(argname="argument sequence_store_ref", value=sequence_store_ref, expected_type=type_hints["sequence_store_ref"])
        return typing.cast("SequenceStoreEvents", jsii.sinvoke(cls, "fromSequenceStore", [sequence_store_ref]))

    @jsii.member(jsii_name="readSetActivationJobStatusChangePattern")
    def read_set_activation_job_status_change_pattern(
        self,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SequenceStore Read Set Activation Job Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReadSetActivationJobStatusChange.ReadSetActivationJobStatusChangeProps(
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            sequence_store_id=sequence_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "readSetActivationJobStatusChangePattern", [options]))

    @jsii.member(jsii_name="readSetExportJobStatusChangePattern")
    def read_set_export_job_status_change_pattern(
        self,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SequenceStore Read Set Export Job Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReadSetExportJobStatusChange.ReadSetExportJobStatusChangeProps(
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            sequence_store_id=sequence_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "readSetExportJobStatusChangePattern", [options]))

    @jsii.member(jsii_name="readSetImportJobStatusChangePattern")
    def read_set_import_job_status_change_pattern(
        self,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SequenceStore Read Set Import Job Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReadSetImportJobStatusChange.ReadSetImportJobStatusChangeProps(
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            sequence_store_id=sequence_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "readSetImportJobStatusChangePattern", [options]))

    @jsii.member(jsii_name="readSetStatusChangePattern")
    def read_set_status_change_pattern(
        self,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        creation_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SequenceStore Read Set Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param creation_job_id: (experimental) creationJobId property. Specify an array of string values to match this event if the actual value of creationJobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param sequence_store_id: (experimental) sequenceStoreId property. Specify an array of string values to match this event if the actual value of sequenceStoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the SequenceStore reference
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) statusMessage property. Specify an array of string values to match this event if the actual value of statusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ReadSetStatusChange.ReadSetStatusChangeProps(
            arn=arn,
            creation_job_id=creation_job_id,
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            sequence_store_id=sequence_store_id,
            status=status,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "readSetStatusChangePattern", [options]))


class SequenceStoreStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.SequenceStoreStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@SequenceStoreStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        sequence_store_status_change = omics_events.SequenceStoreStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="sequenceStoreStatusChangePattern")
    @builtins.classmethod
    def sequence_store_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Sequence Store Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SequenceStoreStatusChange.SequenceStoreStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            id=id,
            omics_version=omics_version,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "sequenceStoreStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.SequenceStoreStatusChange.SequenceStoreStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "id": "id",
            "omics_version": "omicsVersion",
            "status": "status",
        },
    )
    class SequenceStoreStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@SequenceStoreStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                sequence_store_status_change_props = omics_events.SequenceStoreStatusChange.SequenceStoreStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    id=["id"],
                    omics_version=["omicsVersion"],
                    status=["status"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5df2a2a4b85e35f2705e6024bb1fe9603844595d43f78228622e5049b33dd612)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if id is not None:
                self._values["id"] = id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SequenceStoreStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class TaskStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.TaskStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@TaskStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        task_status_change = omics_events.TaskStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="taskStatusChangePattern")
    @builtins.classmethod
    def task_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Task Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = TaskStatusChange.TaskStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            omics_version=omics_version,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "taskStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.TaskStatusChange.TaskStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "omics_version": "omicsVersion",
            "status": "status",
        },
    )
    class TaskStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@TaskStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                task_status_change_props = omics_events.TaskStatusChange.TaskStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    omics_version=["omicsVersion"],
                    status=["status"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__60bd91328f630f270e14165cf944b1811bced9ed3bdf350e8d162dda2ed713ff)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TaskStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VariantImportJobStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.VariantImportJobStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@VariantImportJobStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        variant_import_job_status_change = omics_events.VariantImportJobStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="variantImportJobStatusChangePattern")
    @builtins.classmethod
    def variant_import_job_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Variant Import Job Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_name: (experimental) storeName property. Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VariantImportJobStatusChange.VariantImportJobStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            job_id=job_id,
            omics_version=omics_version,
            status=status,
            store_id=store_id,
            store_name=store_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "variantImportJobStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.VariantImportJobStatusChange.VariantImportJobStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "job_id": "jobId",
            "omics_version": "omicsVersion",
            "status": "status",
            "store_id": "storeId",
            "store_name": "storeName",
        },
    )
    class VariantImportJobStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@VariantImportJobStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_name: (experimental) storeName property. Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                variant_import_job_status_change_props = omics_events.VariantImportJobStatusChange.VariantImportJobStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    job_id=["jobId"],
                    omics_version=["omicsVersion"],
                    status=["status"],
                    store_id=["storeId"],
                    store_name=["storeName"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__53ca7d41f5eed52b21e5abd32efbbf62f5afe64b14127e7f564cd6ac7b885630)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument store_id", value=store_id, expected_type=type_hints["store_id"])
                check_type(argname="argument store_name", value=store_name, expected_type=type_hints["store_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if job_id is not None:
                self._values["job_id"] = job_id
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status
            if store_id is not None:
                self._values["store_id"] = store_id
            if store_name is not None:
                self._values["store_name"] = store_name

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeId property.

            Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeName property.

            Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VariantImportJobStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class VariantStoreStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.VariantStoreStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@VariantStoreStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        variant_store_status_change = omics_events.VariantStoreStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="variantStoreStatusChangePattern")
    @builtins.classmethod
    def variant_store_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Variant Store Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param store_name: (experimental) storeName property. Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = VariantStoreStatusChange.VariantStoreStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            omics_version=omics_version,
            status=status,
            store_id=store_id,
            store_name=store_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "variantStoreStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.VariantStoreStatusChange.VariantStoreStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "omics_version": "omicsVersion",
            "status": "status",
            "store_id": "storeId",
            "store_name": "storeName",
        },
    )
    class VariantStoreStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@VariantStoreStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_id: (experimental) storeId property. Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param store_name: (experimental) storeName property. Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                variant_store_status_change_props = omics_events.VariantStoreStatusChange.VariantStoreStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    omics_version=["omicsVersion"],
                    status=["status"],
                    store_id=["storeId"],
                    store_name=["storeName"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e254c2b8b4a71eb7769c694db7fae980ec47e8ac3117a65d3197f4b4990db9b1)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument store_id", value=store_id, expected_type=type_hints["store_id"])
                check_type(argname="argument store_name", value=store_name, expected_type=type_hints["store_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status
            if store_id is not None:
                self._values["store_id"] = store_id
            if store_name is not None:
                self._values["store_name"] = store_name

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeId property.

            Specify an array of string values to match this event if the actual value of storeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def store_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) storeName property.

            Specify an array of string values to match this event if the actual value of storeName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("store_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VariantStoreStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class WorkflowStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_omics.events.WorkflowStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.omics@WorkflowStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_omics import events as omics_events
        
        workflow_status_change = omics_events.WorkflowStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="workflowStatusChangePattern")
    @builtins.classmethod
    def workflow_status_change_pattern(
        cls,
        *,
        arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Workflow Status Change.

        :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = WorkflowStatusChange.WorkflowStatusChangeProps(
            arn=arn,
            event_metadata=event_metadata,
            omics_version=omics_version,
            status=status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "workflowStatusChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_omics.events.WorkflowStatusChange.WorkflowStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "event_metadata": "eventMetadata",
            "omics_version": "omicsVersion",
            "status": "status",
        },
    )
    class WorkflowStatusChangeProps:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.omics@WorkflowStatusChange event.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param omics_version: (experimental) omicsVersion property. Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_omics import events as omics_events
                
                workflow_status_change_props = omics_events.WorkflowStatusChange.WorkflowStatusChangeProps(
                    arn=["arn"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    omics_version=["omicsVersion"],
                    status=["status"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ecdd8837dd66044d9e6f07e79c458f4df771b19ca94ff0a4aed194aee5963303)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument omics_version", value=omics_version, expected_type=type_hints["omics_version"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if omics_version is not None:
                self._values["omics_version"] = omics_version
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def omics_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) omicsVersion property.

            Specify an array of string values to match this event if the actual value of omicsVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("omics_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "WorkflowStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "AnnotationImportJobStatusChange",
    "AnnotationStoreStatusChange",
    "ReadSetActivationJobStatusChange",
    "ReadSetExportJobStatusChange",
    "ReadSetImportJobStatusChange",
    "ReadSetStatusChange",
    "ReferenceImportJobStatusChange",
    "ReferenceStatusChange",
    "ReferenceStoreEvents",
    "ReferenceStoreStatusChange",
    "RunStatusChange",
    "S3AccessPolicyStatusChange",
    "SequenceStoreEvents",
    "SequenceStoreStatusChange",
    "TaskStatusChange",
    "VariantImportJobStatusChange",
    "VariantStoreStatusChange",
    "WorkflowStatusChange",
]

publication.publish()

def _typecheckingstub__c72b8d895d3595d05b5d55dd8d4df3cd3acf39db45a43791e2c2d92dae017287(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__681393264779d1c805d71da13d4b885f62e8088bd778427635c1e90c833ff512(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__713627e1b870a1d2c2adafa10ff21838f8fb0c03e38711dcd711bfd486244428(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__adce5dcb9e4b0023391d24b468d01cd2ca98bc9794d1633b9b11d8ddde3492e3(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__519e90f2fa92d66055a86b0a8209cb77fed258dce133e558eab50bf873e90701(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc0deb1970bccbc08259b6ec55d2a37a7e507742e9c413df961de2527ea39927(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    creation_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    sequence_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9802e626f28aa845fda89e01a5425d90c48ef000ca4ea9849c83aa5c0d1aa25(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99a0da59d076d87b455a933f8797e1eb74f20356d7b354e589eb29a13c49c877(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    creation_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3525328e1da009f9db687f5649739881ec604ae1f81b03cb7050db2bbb055432(
    reference_store_ref: _aws_cdk_interfaces_aws_omics_ceddda9d.IReferenceStoreRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71dccdf589d4a9a045af274a7f61071c016d2a4fcda97c7a7e0b006576c84815(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cc8e1a9845fbf36450f246f7e9be0159cd41381a63bd9043bdd53c7c8a5e6669(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1da041bc6cc8a53bdc3fdf2b2699fd55805a6224bdd8458bff5085dc5f6f097(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_access_point_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fdeb323027e6ff7c9a852433dc84cd9b3db351345a19ee02d41a5b219eb74b7(
    sequence_store_ref: _aws_cdk_interfaces_aws_omics_ceddda9d.ISequenceStoreRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5df2a2a4b85e35f2705e6024bb1fe9603844595d43f78228622e5049b33dd612(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__60bd91328f630f270e14165cf944b1811bced9ed3bdf350e8d162dda2ed713ff(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53ca7d41f5eed52b21e5abd32efbbf62f5afe64b14127e7f564cd6ac7b885630(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e254c2b8b4a71eb7769c694db7fae980ec47e8ac3117a65d3197f4b4990db9b1(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    store_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ecdd8837dd66044d9e6f07e79c458f4df771b19ca94ff0a4aed194aee5963303(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    omics_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
