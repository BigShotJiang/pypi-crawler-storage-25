from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnStateMachineExpressLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineExpressLogs",
):
    '''Builder for CfnStateMachineLogsMixin to generate EXPRESS_LOGS for CfnStateMachine.

    :cloudformationResource: AWS::StepFunctions::StateMachine
    :logType: EXPRESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
        
        cfn_state_machine_express_logs = stepfunctions_mixins.CfnStateMachineExpressLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnStateMachineExpressLogsRecordFields"]] = None,
    ) -> "CfnStateMachineLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are CWL
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__47430628f4b9dc52817c13cf8cb83e1f9bb15cdd94ecdc2c55893df87b9e52e1)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnStateMachineExpressLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnStateMachineLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnStateMachineExpressLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnStateMachineExpressLogsRecordFields"]] = None,
    ) -> "CfnStateMachineLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a7c1718a2764a6832854b3071fef98f9d8e965ebd36a4f369a3cedaa953e7b0)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnStateMachineExpressLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnStateMachineLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineExpressLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnStateMachineExpressLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnStateMachineExpressLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
            
            cfn_state_machine_express_logs_dest_props = stepfunctions_mixins.CfnStateMachineExpressLogsDestProps(
                record_fields=[stepfunctions_mixins.CfnStateMachineExpressLogsRecordFields.DETAILS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5003576b5fc62480fecea09273ef799a505dd0d36b5a8357be9198ef6a62590d)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnStateMachineExpressLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnStateMachineExpressLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnStateMachineExpressLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineExpressLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnStateMachineExpressLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnStateMachineExpressLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnStateMachineExpressLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
            
            cfn_state_machine_express_logs_log_group_props = stepfunctions_mixins.CfnStateMachineExpressLogsLogGroupProps(
                output_format=stepfunctions_mixins.CfnStateMachineExpressLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[stepfunctions_mixins.CfnStateMachineExpressLogsRecordFields.DETAILS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__84c9ee4edda313b326d8c26e05d82e162ec07642807802a740d3461e225d8fdb)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnStateMachineExpressLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnStateMachineExpressLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnStateMachineExpressLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnStateMachineExpressLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnStateMachineExpressLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnStateMachineExpressLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineExpressLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnStateMachineExpressLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
        
        cfn_state_machine_express_logs_output_format = stepfunctions_mixins.CfnStateMachineExpressLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineExpressLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineExpressLogsRecordFields"
)
class CfnStateMachineExpressLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    DETAILS = "DETAILS"
    '''
    :stability: experimental
    '''
    MAP_RUN_ARN = "MAP_RUN_ARN"
    '''
    :stability: experimental
    '''
    PARENT_EXECUTION_ARN = "PARENT_EXECUTION_ARN"
    '''
    :stability: experimental
    '''
    REDRIVE_COUNT = "REDRIVE_COUNT"
    '''
    :stability: experimental
    '''
    ID = "ID"
    '''
    :stability: experimental
    '''
    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    PREVIOUS_EVENT_ID = "PREVIOUS_EVENT_ID"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    EXECUTION_ARN = "EXECUTION_ARN"
    '''
    :stability: experimental
    '''


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnStateMachineLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineLogsMixin",
):
    '''Provisions a state machine.

    A state machine consists of a collection of states that can do work ( ``Task`` states), determine to which states to transition next ( ``Choice`` states), stop an execution with an error ( ``Fail`` states), and so on. State machines are specified using a JSON-based, structured language.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-stepfunctions-statemachine.html
    :cloudformationResource: AWS::StepFunctions::StateMachine
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_state_machine_logs_mixin = stepfunctions_mixins.CfnStateMachineLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::StepFunctions::StateMachine``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7b3a34dcdb545059f78345b115ad4dfe2413a98ee45ea5393ff3cfaf2e8b513e)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e37c0611dd50ea0c45d059142de43141228e4fb18815146a81b766cd20b1fade)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb1f5c0ad06c62110858ede307dc71574289f36b2977d7855936e4928820909e)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EXPRESS_LOGS")
    def EXPRESS_LOGS(cls) -> "CfnStateMachineExpressLogs":
        return typing.cast("CfnStateMachineExpressLogs", jsii.sget(cls, "EXPRESS_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="STANDARD_LOGS")
    def STANDARD_LOGS(cls) -> "CfnStateMachineStandardLogs":
        return typing.cast("CfnStateMachineStandardLogs", jsii.sget(cls, "STANDARD_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnStateMachineStandardLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineStandardLogs",
):
    '''Builder for CfnStateMachineLogsMixin to generate STANDARD_LOGS for CfnStateMachine.

    :cloudformationResource: AWS::StepFunctions::StateMachine
    :logType: STANDARD_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
        
        cfn_state_machine_standard_logs = stepfunctions_mixins.CfnStateMachineStandardLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnStateMachineStandardLogsRecordFields"]] = None,
    ) -> "CfnStateMachineLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are CWL
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18b379c7084bf6595cba8c0d7e8dff92e7542e0bfe1ed8dfc6c7e6ef89e524f8)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnStateMachineStandardLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnStateMachineLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnStateMachineStandardLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnStateMachineStandardLogsRecordFields"]] = None,
    ) -> "CfnStateMachineLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dbca6b009d3838dabea6cbd5f7f76c1e346ade2d2a43f6858d0c46fa4d039a93)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnStateMachineStandardLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnStateMachineLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineStandardLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnStateMachineStandardLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnStateMachineStandardLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
            
            cfn_state_machine_standard_logs_dest_props = stepfunctions_mixins.CfnStateMachineStandardLogsDestProps(
                record_fields=[stepfunctions_mixins.CfnStateMachineStandardLogsRecordFields.DETAILS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3159c1dbb2183d8dec35a006cb4c51597c4a6eeae0b2242efbb5e0fe6de2a4a4)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnStateMachineStandardLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnStateMachineStandardLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnStateMachineStandardLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineStandardLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnStateMachineStandardLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnStateMachineStandardLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnStateMachineStandardLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
            
            cfn_state_machine_standard_logs_log_group_props = stepfunctions_mixins.CfnStateMachineStandardLogsLogGroupProps(
                output_format=stepfunctions_mixins.CfnStateMachineStandardLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[stepfunctions_mixins.CfnStateMachineStandardLogsRecordFields.DETAILS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c71c3367d5d84e40004b250d4b58688242f982c06c03335609c4e0a32249ed9)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnStateMachineStandardLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnStateMachineStandardLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnStateMachineStandardLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnStateMachineStandardLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnStateMachineStandardLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnStateMachineStandardLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineStandardLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnStateMachineStandardLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_stepfunctions import mixins as stepfunctions_mixins
        
        cfn_state_machine_standard_logs_output_format = stepfunctions_mixins.CfnStateMachineStandardLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineStandardLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_stepfunctions.mixins.CfnStateMachineStandardLogsRecordFields"
)
class CfnStateMachineStandardLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    DETAILS = "DETAILS"
    '''
    :stability: experimental
    '''
    MAP_RUN_ARN = "MAP_RUN_ARN"
    '''
    :stability: experimental
    '''
    PARENT_EXECUTION_ARN = "PARENT_EXECUTION_ARN"
    '''
    :stability: experimental
    '''
    REDRIVE_COUNT = "REDRIVE_COUNT"
    '''
    :stability: experimental
    '''
    ID = "ID"
    '''
    :stability: experimental
    '''
    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    PREVIOUS_EVENT_ID = "PREVIOUS_EVENT_ID"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    EXECUTION_ARN = "EXECUTION_ARN"
    '''
    :stability: experimental
    '''


__all__ = [
    "CfnStateMachineExpressLogs",
    "CfnStateMachineExpressLogsDestProps",
    "CfnStateMachineExpressLogsLogGroupProps",
    "CfnStateMachineExpressLogsOutputFormat",
    "CfnStateMachineExpressLogsRecordFields",
    "CfnStateMachineLogsMixin",
    "CfnStateMachineStandardLogs",
    "CfnStateMachineStandardLogsDestProps",
    "CfnStateMachineStandardLogsLogGroupProps",
    "CfnStateMachineStandardLogsOutputFormat",
    "CfnStateMachineStandardLogsRecordFields",
]

publication.publish()

def _typecheckingstub__47430628f4b9dc52817c13cf8cb83e1f9bb15cdd94ecdc2c55893df87b9e52e1(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnStateMachineExpressLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a7c1718a2764a6832854b3071fef98f9d8e965ebd36a4f369a3cedaa953e7b0(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnStateMachineExpressLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnStateMachineExpressLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5003576b5fc62480fecea09273ef799a505dd0d36b5a8357be9198ef6a62590d(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnStateMachineExpressLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__84c9ee4edda313b326d8c26e05d82e162ec07642807802a740d3461e225d8fdb(
    *,
    output_format: typing.Optional[CfnStateMachineExpressLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnStateMachineExpressLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b3a34dcdb545059f78345b115ad4dfe2413a98ee45ea5393ff3cfaf2e8b513e(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e37c0611dd50ea0c45d059142de43141228e4fb18815146a81b766cd20b1fade(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb1f5c0ad06c62110858ede307dc71574289f36b2977d7855936e4928820909e(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18b379c7084bf6595cba8c0d7e8dff92e7542e0bfe1ed8dfc6c7e6ef89e524f8(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnStateMachineStandardLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dbca6b009d3838dabea6cbd5f7f76c1e346ade2d2a43f6858d0c46fa4d039a93(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnStateMachineStandardLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnStateMachineStandardLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3159c1dbb2183d8dec35a006cb4c51597c4a6eeae0b2242efbb5e0fe6de2a4a4(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnStateMachineStandardLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c71c3367d5d84e40004b250d4b58688242f982c06c03335609c4e0a32249ed9(
    *,
    output_format: typing.Optional[CfnStateMachineStandardLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnStateMachineStandardLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
