from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnBrowserCustomLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomLogsMixin",
):
    '''AgentCore Browser tool provides a fast, secure, cloud-based browser runtime to enable AI agents to interact with websites at scale.

    For more information about using the custom browser, see `Interact with web applications using Amazon Bedrock AgentCore Browser <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/browser-tool.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-browsercustom.html
    :cloudformationResource: AWS::BedrockAgentCore::BrowserCustom
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_browser_custom_logs_mixin = bedrockagentcore_mixins.CfnBrowserCustomLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::BedrockAgentCore::BrowserCustom``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1204015ea5825ad1edf8da476379429e640773015e63cf3a0d886ad2986e5422)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd6c5d067697cdae53d3732ce41d3c017b37ccac14b1891e7c078bbe2be278e3)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5ae700cc3744a1f2a546f21c41d8742124ccfc03dd37fc8c426fdd69a9948d9)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="USAGE_LOGS")
    def USAGE_LOGS(cls) -> "CfnBrowserCustomUsageLogs":
        return typing.cast("CfnBrowserCustomUsageLogs", jsii.sget(cls, "USAGE_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnBrowserCustomUsageLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogs",
):
    '''Builder for CfnBrowserCustomLogsMixin to generate USAGE_LOGS for CfnBrowserCustom.

    :cloudformationResource: AWS::BedrockAgentCore::BrowserCustom
    :logType: USAGE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_browser_custom_usage_logs = bedrockagentcore_mixins.CfnBrowserCustomUsageLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnBrowserCustomUsageLogsRecordFields"]] = None,
    ) -> "CfnBrowserCustomLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b5557b6a2e4a15aead29043c5c59b15d261f21c7f15e9ca83d2b26b2745cefd1)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnBrowserCustomUsageLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnBrowserCustomLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBrowserCustomUsageLogsRecordFields"]] = None,
    ) -> "CfnBrowserCustomLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc33a2fb67e69b54c08eff634eacbb643fbde00ba0e6541e63395f93c9c49224)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnBrowserCustomUsageLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnBrowserCustomLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBrowserCustomUsageLogsRecordFields"]] = None,
    ) -> "CfnBrowserCustomLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__64dbd64426e5f3ab769711bebaca1f5e891bf41871180ae2f38795ca4cb93c74)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnBrowserCustomUsageLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnBrowserCustomLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBrowserCustomUsageLogsRecordFields"]] = None,
    ) -> "CfnBrowserCustomLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05930886aa141f479722ca8a7c90373158a5da565dd72a5bc911e70a64944fa2)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnBrowserCustomUsageLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnBrowserCustomLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnBrowserCustomUsageLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnBrowserCustomUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_browser_custom_usage_logs_dest_props = bedrockagentcore_mixins.CfnBrowserCustomUsageLogsDestProps(
                record_fields=[bedrockagentcore_mixins.CfnBrowserCustomUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__891f0dcd7722e9f1267e078dd92d0a24541ae7fe709bcaccb96034c8ef58fb29)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnBrowserCustomUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnBrowserCustomUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnBrowserCustomUsageLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnBrowserCustomUsageLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBrowserCustomUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_browser_custom_usage_logs_firehose_props = bedrockagentcore_mixins.CfnBrowserCustomUsageLogsFirehoseProps(
                output_format=bedrockagentcore_mixins.CfnBrowserCustomUsageLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrockagentcore_mixins.CfnBrowserCustomUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75161efd68f0dd1bcf6219be20d94a8d7b76aa72da686e8e8997c6e90026d7a6)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnBrowserCustomUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnBrowserCustomUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnBrowserCustomUsageLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnBrowserCustomUsageLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBrowserCustomUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_browser_custom_usage_logs_log_group_props = bedrockagentcore_mixins.CfnBrowserCustomUsageLogsLogGroupProps(
                output_format=bedrockagentcore_mixins.CfnBrowserCustomUsageLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrockagentcore_mixins.CfnBrowserCustomUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__559d87e9caf771c1ddc4a61dbac7177d53317224033996976d9adcf87da142b0)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnBrowserCustomUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnBrowserCustomUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnBrowserCustomUsageLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnBrowserCustomUsageLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnBrowserCustomUsageLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_browser_custom_usage_logs_output_format = bedrockagentcore_mixins.CfnBrowserCustomUsageLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsRecordFields"
)
class CfnBrowserCustomUsageLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    RESOURCE = "RESOURCE"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    METRICS = "METRICS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnBrowserCustomUsageLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnBrowserCustomUsageLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnBrowserCustomUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_browser_custom_usage_logs_s3_props = bedrockagentcore_mixins.CfnBrowserCustomUsageLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrockagentcore_mixins.CfnBrowserCustomUsageLogsOutputFormat.S3.JSON,
                record_fields=[bedrockagentcore_mixins.CfnBrowserCustomUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e06de47fd84117549d516f6f0fa4583dae0e4c0e02fa8096e99f0b0ddbb9edca)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnBrowserCustomUsageLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnBrowserCustomUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnBrowserCustomUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnBrowserCustomUsageLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCodeInterpreterCustomApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogs",
):
    '''Builder for CfnCodeInterpreterCustomLogsMixin to generate APPLICATION_LOGS for CfnCodeInterpreterCustom.

    :cloudformationResource: AWS::BedrockAgentCore::CodeInterpreterCustom
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_code_interpreter_custom_application_logs = bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomApplicationLogsRecordFields"]] = None,
    ) -> "CfnCodeInterpreterCustomLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__376aa4b0b7ebda55b3fdb25060adadd2daa14427edb76ca3764a7af3a648cc14)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCodeInterpreterCustomApplicationLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnCodeInterpreterCustomLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomApplicationLogsRecordFields"]] = None,
    ) -> "CfnCodeInterpreterCustomLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__235da9e09238b83e4ee03d2a385d9a67a4c089b94c6709c8be8db5004fb34d94)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCodeInterpreterCustomApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCodeInterpreterCustomLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomApplicationLogsRecordFields"]] = None,
    ) -> "CfnCodeInterpreterCustomLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9ad00b02c85d7534fda1e3c5f3efd178c9db7d0eca9fefe15daad8275e4eba1f)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCodeInterpreterCustomApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCodeInterpreterCustomLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomApplicationLogsRecordFields"]] = None,
    ) -> "CfnCodeInterpreterCustomLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e7101be0c4795e8e391d3a9619523aeecc6023b093a4e9e6616a93604e283e6)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCodeInterpreterCustomApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCodeInterpreterCustomLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCodeInterpreterCustomApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_code_interpreter_custom_application_logs_dest_props = bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsDestProps(
                record_fields=[bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsRecordFields.ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__635384dc8d0cea2199d2b5347178aa8a47af981d4e81bbbaf613790234ed4c9e)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCodeInterpreterCustomApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCodeInterpreterCustomApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCodeInterpreterCustomApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCodeInterpreterCustomApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_code_interpreter_custom_application_logs_firehose_props = bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsFirehoseProps(
                output_format=bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsRecordFields.ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d73dfdf6276c0ca1f6165f8187b1d5623ff385fe39e3c276ddc152f7bd84bd8c)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCodeInterpreterCustomApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCodeInterpreterCustomApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCodeInterpreterCustomApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCodeInterpreterCustomApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_code_interpreter_custom_application_logs_log_group_props = bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsLogGroupProps(
                output_format=bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsRecordFields.ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca50396a4eba8b6ad09e06600b56e6d429344829cb5f0864624fb460cf5ba40b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCodeInterpreterCustomApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCodeInterpreterCustomApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCodeInterpreterCustomApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCodeInterpreterCustomApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCodeInterpreterCustomApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_code_interpreter_custom_application_logs_output_format = bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsRecordFields"
)
class CfnCodeInterpreterCustomApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    ACCOUNT_ID = "ACCOUNT_ID"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    TOOL_SESSION_ID = "TOOL_SESSION_ID"
    '''
    :stability: experimental
    '''
    SPAN_ID = "SPAN_ID"
    '''
    :stability: experimental
    '''
    TRACE_ID = "TRACE_ID"
    '''
    :stability: experimental
    '''
    SERVICE_NAME = "SERVICE_NAME"
    '''
    :stability: experimental
    '''
    OPERATION = "OPERATION"
    '''
    :stability: experimental
    '''
    REQUEST_PAYLOAD = "REQUEST_PAYLOAD"
    '''
    :stability: experimental
    '''
    RESPONSE_PAYLOAD = "RESPONSE_PAYLOAD"
    '''
    :stability: experimental
    '''
    RESOURCE = "RESOURCE"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    TIMEUNIXNANO = "TIMEUNIXNANO"
    '''
    :stability: experimental
    '''
    SEVERITYNUMBER = "SEVERITYNUMBER"
    '''
    :stability: experimental
    '''
    SEVERITYTEXT = "SEVERITYTEXT"
    '''
    :stability: experimental
    '''
    BODY = "BODY"
    '''
    :stability: experimental
    '''
    TRACEID = "TRACEID"
    '''
    :stability: experimental
    '''
    SPANID = "SPANID"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCodeInterpreterCustomApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_code_interpreter_custom_application_logs_s3_props = bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3.JSON,
                record_fields=[bedrockagentcore_mixins.CfnCodeInterpreterCustomApplicationLogsRecordFields.ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9a7c9af5d32896d1457f645fce89ea7a28472a75d075e6c4b4ca854c56e4dff)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCodeInterpreterCustomApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCodeInterpreterCustomApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCodeInterpreterCustomApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnCodeInterpreterCustomLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomLogsMixin",
):
    '''The AgentCore Code Interpreter tool enables agents to securely execute code in isolated sandbox environments.

    It offers advanced configuration support and seamless integration with popular frameworks.

    For more information about using the custom code interpreter, see `Execute code and analyze data using Amazon Bedrock AgentCore Code Interpreter <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/code-interpreter-tool.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-codeinterpretercustom.html
    :cloudformationResource: AWS::BedrockAgentCore::CodeInterpreterCustom
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_code_interpreter_custom_logs_mixin = bedrockagentcore_mixins.CfnCodeInterpreterCustomLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::BedrockAgentCore::CodeInterpreterCustom``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__35590a55fa3de02073a91f3724c4c746bb5accef2020e70624bdaddd67c4cfd9)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__77d9002f6d549cf852bb62b298213dd56a96b27501e3bc412fa041fd058ee8ac)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__87fc8eea47962eb75dba0a4724a530e003264367e4289ed742847fcfcd075b35)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnCodeInterpreterCustomApplicationLogs":
        return typing.cast("CfnCodeInterpreterCustomApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="USAGE_LOGS")
    def USAGE_LOGS(cls) -> "CfnCodeInterpreterCustomUsageLogs":
        return typing.cast("CfnCodeInterpreterCustomUsageLogs", jsii.sget(cls, "USAGE_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnCodeInterpreterCustomUsageLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogs",
):
    '''Builder for CfnCodeInterpreterCustomLogsMixin to generate USAGE_LOGS for CfnCodeInterpreterCustom.

    :cloudformationResource: AWS::BedrockAgentCore::CodeInterpreterCustom
    :logType: USAGE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_code_interpreter_custom_usage_logs = bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomUsageLogsRecordFields"]] = None,
    ) -> "CfnCodeInterpreterCustomLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__533ec52807524b5d6b7f67139af1da13c19d48a7b8a08eee4a63db51667e225d)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnCodeInterpreterCustomUsageLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnCodeInterpreterCustomLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomUsageLogsRecordFields"]] = None,
    ) -> "CfnCodeInterpreterCustomLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c69e8fb84ecd9ab8ee95e57bc6b44127b2329ef1912ffeac3c74e7117d0a49b)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnCodeInterpreterCustomUsageLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCodeInterpreterCustomLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomUsageLogsRecordFields"]] = None,
    ) -> "CfnCodeInterpreterCustomLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83938dacb934234d9619aa38d8aea57fbb236466cf2d600deca3dce75f289add)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnCodeInterpreterCustomUsageLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnCodeInterpreterCustomLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomUsageLogsRecordFields"]] = None,
    ) -> "CfnCodeInterpreterCustomLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b311d9c0741c18eab724560ac46a9d809ade50e47676b082106ad313fc883a59)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnCodeInterpreterCustomUsageLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnCodeInterpreterCustomLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnCodeInterpreterCustomUsageLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_code_interpreter_custom_usage_logs_dest_props = bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsDestProps(
                record_fields=[bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__894e4f5d19e6b73cac842d1cafbe6db4f71b1d883b0dfb3ba15614f6bb1b0ce7)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCodeInterpreterCustomUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCodeInterpreterCustomUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCodeInterpreterCustomUsageLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCodeInterpreterCustomUsageLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_code_interpreter_custom_usage_logs_firehose_props = bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsFirehoseProps(
                output_format=bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a33cfd9fdf1ce28e8e670aed575ed1868f4bfb3a75acce1e51c8a6e2b088396)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCodeInterpreterCustomUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCodeInterpreterCustomUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCodeInterpreterCustomUsageLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnCodeInterpreterCustomUsageLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_code_interpreter_custom_usage_logs_log_group_props = bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsLogGroupProps(
                output_format=bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__17c8c958165d30b0799b7fab61fcc0c4ea430121cf47aa5e0cdfc39ae9c7f479)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCodeInterpreterCustomUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCodeInterpreterCustomUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCodeInterpreterCustomUsageLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnCodeInterpreterCustomUsageLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnCodeInterpreterCustomUsageLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_code_interpreter_custom_usage_logs_output_format = bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsRecordFields"
)
class CfnCodeInterpreterCustomUsageLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    RESOURCE = "RESOURCE"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    METRICS = "METRICS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnCodeInterpreterCustomUsageLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnCodeInterpreterCustomUsageLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnCodeInterpreterCustomUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_code_interpreter_custom_usage_logs_s3_props = bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsOutputFormat.S3.JSON,
                record_fields=[bedrockagentcore_mixins.CfnCodeInterpreterCustomUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e05a055727f391340802904b8adaa230f0d252ea987e0bae7ef834b32fe117c)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnCodeInterpreterCustomUsageLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnCodeInterpreterCustomUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnCodeInterpreterCustomUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnCodeInterpreterCustomUsageLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnGatewayApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogs",
):
    '''Builder for CfnGatewayLogsMixin to generate APPLICATION_LOGS for CfnGateway.

    :cloudformationResource: AWS::BedrockAgentCore::Gateway
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_gateway_application_logs = bedrockagentcore_mixins.CfnGatewayApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayApplicationLogsRecordFields"]] = None,
    ) -> "CfnGatewayLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__da4e88160f72aa29d550aab624d93a1c44ac95f840a4097602aec0568fbe0bed)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnGatewayApplicationLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnGatewayLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnGatewayApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayApplicationLogsRecordFields"]] = None,
    ) -> "CfnGatewayLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39848dbcff7bcfc40d1a54882028de18bd79f07358d575e2f766474c41432799)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnGatewayApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnGatewayLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnGatewayApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayApplicationLogsRecordFields"]] = None,
    ) -> "CfnGatewayLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a344d11427e4c8db554328e8e359728d32dff227185be0c431f0e06c8092f457)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnGatewayApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnGatewayLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnGatewayApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayApplicationLogsRecordFields"]] = None,
    ) -> "CfnGatewayLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__333af1943f4d576fe2f6f5471c064f69666be8e6d9f2a424aa8e4bbf0a6e6c26)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnGatewayApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnGatewayLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnGatewayApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_gateway_application_logs_dest_props = bedrockagentcore_mixins.CfnGatewayApplicationLogsDestProps(
                record_fields=[bedrockagentcore_mixins.CfnGatewayApplicationLogsRecordFields.BODY]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e609371a3535a03ddbce2fa82ec671e83e9d07556ff42c82a4aca5c79bc7093)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGatewayApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGatewayApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGatewayApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnGatewayApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnGatewayApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_gateway_application_logs_firehose_props = bedrockagentcore_mixins.CfnGatewayApplicationLogsFirehoseProps(
                output_format=bedrockagentcore_mixins.CfnGatewayApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrockagentcore_mixins.CfnGatewayApplicationLogsRecordFields.BODY]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9fdf7fa743f5ee4714ba9bed593c60ebd8f05fbe78635744f0001d405e741164)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnGatewayApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnGatewayApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGatewayApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGatewayApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGatewayApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnGatewayApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnGatewayApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_gateway_application_logs_log_group_props = bedrockagentcore_mixins.CfnGatewayApplicationLogsLogGroupProps(
                output_format=bedrockagentcore_mixins.CfnGatewayApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrockagentcore_mixins.CfnGatewayApplicationLogsRecordFields.BODY]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff6a2b641d368d196d163af7d94f2be9a8fc34683455d7eb64487f7c6260310d)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnGatewayApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnGatewayApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGatewayApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGatewayApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGatewayApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnGatewayApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnGatewayApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_gateway_application_logs_output_format = bedrockagentcore_mixins.CfnGatewayApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsRecordFields"
)
class CfnGatewayApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    BODY = "BODY"
    '''
    :stability: experimental
    '''
    ACCOUNT_ID = "ACCOUNT_ID"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    TRACE_ID = "TRACE_ID"
    '''
    :stability: experimental
    '''
    SPAN_ID = "SPAN_ID"
    '''
    :stability: experimental
    '''
    RESOURCE = "RESOURCE"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    TIMEUNIXNANO = "TIMEUNIXNANO"
    '''
    :stability: experimental
    '''
    SEVERITYNUMBER = "SEVERITYNUMBER"
    '''
    :stability: experimental
    '''
    SEVERITYTEXT = "SEVERITYTEXT"
    '''
    :stability: experimental
    '''
    TRACEID = "TRACEID"
    '''
    :stability: experimental
    '''
    SPANID = "SPANID"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnGatewayApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnGatewayApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_gateway_application_logs_s3_props = bedrockagentcore_mixins.CfnGatewayApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrockagentcore_mixins.CfnGatewayApplicationLogsOutputFormat.S3.JSON,
                record_fields=[bedrockagentcore_mixins.CfnGatewayApplicationLogsRecordFields.BODY]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d1278f1b07343ce019afe1086ef32d3ad0c4b153b7ada069b1c90fbd1e485c4b)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnGatewayApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnGatewayApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGatewayApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGatewayApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGatewayApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnGatewayLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayLogsMixin",
):
    '''Amazon Bedrock AgentCore Gateway provides a unified connectivity layer between agents and the tools and resources they need to interact with.

    For more information about creating a gateway, see `Set up an Amazon Bedrock AgentCore gateway <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/gateway-building.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-gateway.html
    :cloudformationResource: AWS::BedrockAgentCore::Gateway
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_gateway_logs_mixin = bedrockagentcore_mixins.CfnGatewayLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::BedrockAgentCore::Gateway``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4bd5d58e42dde39c0c9f95fa42cce3112291750c9c136a8a9cf2c91b01184db)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8707bee110c27b8a30232ab12f1dd6fa82318218289552523e2bef7e7d1124d5)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76cbea6936abcad9bd64780ec1b6cdaa37c3096acf1d0e0c8bb75ea40b400a88)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnGatewayApplicationLogs":
        return typing.cast("CfnGatewayApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TRACES")
    def TRACES(cls) -> "CfnGatewayTraces":
        return typing.cast("CfnGatewayTraces", jsii.sget(cls, "TRACES"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnGatewayTraces(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayTraces",
):
    '''Builder for CfnGatewayLogsMixin to generate TRACES for CfnGateway.

    :cloudformationResource: AWS::BedrockAgentCore::Gateway
    :logType: TRACES
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_gateway_traces = bedrockagentcore_mixins.CfnGatewayTraces()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayTracesRecordFields"]] = None,
    ) -> "CfnGatewayLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are XRAY
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0cca5996fe4eec1091f940c59169cf87cd409561ba2e1d62834c3d399e1683de)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnGatewayTracesDestProps(record_fields=record_fields)

        return typing.cast("CfnGatewayLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toXRay")
    def to_x_ray(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayTracesRecordFields"]] = None,
    ) -> "CfnGatewayLogsMixin":
        '''Send traces to X-Ray.

        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        props = CfnGatewayTracesXRayProps(record_fields=record_fields)

        return typing.cast("CfnGatewayLogsMixin", jsii.invoke(self, "toXRay", [props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayTracesDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnGatewayTracesDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayTracesRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_gateway_traces_dest_props = bedrockagentcore_mixins.CfnGatewayTracesDestProps(
                record_fields=[bedrockagentcore_mixins.CfnGatewayTracesRecordFields.TRACE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2b0e0f3aae257a78fa6ca850c8dce4b4faa4280f40bde76ffdbfa09f9176b3c0)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGatewayTracesRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGatewayTracesRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGatewayTracesDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnGatewayTracesOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayTracesOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnGatewayTraces.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_gateway_traces_output_format = bedrockagentcore_mixins.CfnGatewayTracesOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayTracesRecordFields"
)
class CfnGatewayTracesRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TRACE = "TRACE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnGatewayTracesXRayProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnGatewayTracesXRayProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnGatewayTracesRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_gateway_traces_xRay_props = bedrockagentcore_mixins.CfnGatewayTracesXRayProps(
                record_fields=[bedrockagentcore_mixins.CfnGatewayTracesRecordFields.TRACE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9687c40b7cc3bb1401504c7de6d623b2ab9afe61b6b914a3738f9e8a34bc0b33)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGatewayTracesRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGatewayTracesRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGatewayTracesXRayProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnMemoryApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogs",
):
    '''Builder for CfnMemoryLogsMixin to generate APPLICATION_LOGS for CfnMemory.

    :cloudformationResource: AWS::BedrockAgentCore::Memory
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_memory_application_logs = bedrockagentcore_mixins.CfnMemoryApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryApplicationLogsRecordFields"]] = None,
    ) -> "CfnMemoryLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de2cb3ef4efef7c88e74f01623620859c087826e14d26adb8d14eaaf486b3c1e)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnMemoryApplicationLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnMemoryLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnMemoryApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryApplicationLogsRecordFields"]] = None,
    ) -> "CfnMemoryLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__533a3d66a676933e8c35334e4a0fe72487242446cd039c1e22c95749f0aff244)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnMemoryApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMemoryLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnMemoryApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryApplicationLogsRecordFields"]] = None,
    ) -> "CfnMemoryLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d97379a3829ca32dd7989e0c3e7bf095ac6da663e9085d43b47ebfd720d90674)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnMemoryApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMemoryLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMemoryApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryApplicationLogsRecordFields"]] = None,
    ) -> "CfnMemoryLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bb93e3d5eba71dee2742932d989deb728d771b8572a33bd3b7ec42e99158f2e1)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnMemoryApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnMemoryLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnMemoryApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_memory_application_logs_dest_props = bedrockagentcore_mixins.CfnMemoryApplicationLogsDestProps(
                record_fields=[bedrockagentcore_mixins.CfnMemoryApplicationLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6dcb4fbfb91f69370ce435139a6d18af66915d62183db0cef556d187ba33399d)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMemoryApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMemoryApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMemoryApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMemoryApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMemoryApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_memory_application_logs_firehose_props = bedrockagentcore_mixins.CfnMemoryApplicationLogsFirehoseProps(
                output_format=bedrockagentcore_mixins.CfnMemoryApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrockagentcore_mixins.CfnMemoryApplicationLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5cd4d39d8e5574b4b2a7c66763391087e47556c73e9a67615c3226d71899e1c2)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMemoryApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMemoryApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMemoryApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMemoryApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMemoryApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMemoryApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMemoryApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_memory_application_logs_log_group_props = bedrockagentcore_mixins.CfnMemoryApplicationLogsLogGroupProps(
                output_format=bedrockagentcore_mixins.CfnMemoryApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrockagentcore_mixins.CfnMemoryApplicationLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3567128274696650471ed689f529ff6ee6e8a865d56dc47a34241148eebbdc62)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMemoryApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMemoryApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMemoryApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMemoryApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMemoryApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnMemoryApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnMemoryApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_memory_application_logs_output_format = bedrockagentcore_mixins.CfnMemoryApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsRecordFields"
)
class CfnMemoryApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    MEMORY_STRATEGY_ID = "MEMORY_STRATEGY_ID"
    '''
    :stability: experimental
    '''
    NAMESPACE = "NAMESPACE"
    '''
    :stability: experimental
    '''
    ACTOR_ID = "ACTOR_ID"
    '''
    :stability: experimental
    '''
    SESSION_ID = "SESSION_ID"
    '''
    :stability: experimental
    '''
    EVENT_ID = "EVENT_ID"
    '''
    :stability: experimental
    '''
    BODY = "BODY"
    '''
    :stability: experimental
    '''
    RESOURCE = "RESOURCE"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    TIMEUNIXNANO = "TIMEUNIXNANO"
    '''
    :stability: experimental
    '''
    SEVERITYNUMBER = "SEVERITYNUMBER"
    '''
    :stability: experimental
    '''
    SEVERITYTEXT = "SEVERITYTEXT"
    '''
    :stability: experimental
    '''
    TRACEID = "TRACEID"
    '''
    :stability: experimental
    '''
    SPANID = "SPANID"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnMemoryApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMemoryApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_memory_application_logs_s3_props = bedrockagentcore_mixins.CfnMemoryApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrockagentcore_mixins.CfnMemoryApplicationLogsOutputFormat.S3.JSON,
                record_fields=[bedrockagentcore_mixins.CfnMemoryApplicationLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d61fbf431ceb30e979876f2336bab4f677d3bea1eb7c29f889419a0cf9c3ec3a)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMemoryApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMemoryApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMemoryApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMemoryApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMemoryApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnMemoryLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryLogsMixin",
):
    '''Memory allows AI agents to maintain both immediate and long-term knowledge, enabling context-aware and personalized interactions.

    For more information about using Memory in Amazon Bedrock AgentCore, see `Host agent or tools with Amazon Bedrock AgentCore Memory <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/memory-getting-started.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-memory.html
    :cloudformationResource: AWS::BedrockAgentCore::Memory
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_memory_logs_mixin = bedrockagentcore_mixins.CfnMemoryLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::BedrockAgentCore::Memory``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6ba1ef598af5d274cde246f021cccd97f3f9bacd72ca55bd4a2a655c256ffc02)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__346aafd94719a39bcd1b7e03f2d1d1c815b572bfa39b9a1b179e7c078ed109d1)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eaa046b4cb4a127be4c06542eeae1311c588dd8afeba3af29448f52bdd1c24f3)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnMemoryApplicationLogs":
        return typing.cast("CfnMemoryApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TRACES")
    def TRACES(cls) -> "CfnMemoryTraces":
        return typing.cast("CfnMemoryTraces", jsii.sget(cls, "TRACES"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnMemoryTraces(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryTraces",
):
    '''Builder for CfnMemoryLogsMixin to generate TRACES for CfnMemory.

    :cloudformationResource: AWS::BedrockAgentCore::Memory
    :logType: TRACES
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_memory_traces = bedrockagentcore_mixins.CfnMemoryTraces()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryTracesRecordFields"]] = None,
    ) -> "CfnMemoryLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are XRAY
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d2d24689b631f5e4c9bc19130caf7837de589758f739258151e687ded026b6dc)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnMemoryTracesDestProps(record_fields=record_fields)

        return typing.cast("CfnMemoryLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toXRay")
    def to_x_ray(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryTracesRecordFields"]] = None,
    ) -> "CfnMemoryLogsMixin":
        '''Send traces to X-Ray.

        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        props = CfnMemoryTracesXRayProps(record_fields=record_fields)

        return typing.cast("CfnMemoryLogsMixin", jsii.invoke(self, "toXRay", [props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryTracesDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnMemoryTracesDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryTracesRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_memory_traces_dest_props = bedrockagentcore_mixins.CfnMemoryTracesDestProps(
                record_fields=[bedrockagentcore_mixins.CfnMemoryTracesRecordFields.TRACE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39d0ac2625e6e9ad0d259d1110e131d00beb68b48682cfbe49cf6ef6a7b97bea)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMemoryTracesRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMemoryTracesRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMemoryTracesDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnMemoryTracesOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryTracesOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnMemoryTraces.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_memory_traces_output_format = bedrockagentcore_mixins.CfnMemoryTracesOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryTracesRecordFields"
)
class CfnMemoryTracesRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TRACE = "TRACE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnMemoryTracesXRayProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnMemoryTracesXRayProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMemoryTracesRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_memory_traces_xRay_props = bedrockagentcore_mixins.CfnMemoryTracesXRayProps(
                record_fields=[bedrockagentcore_mixins.CfnMemoryTracesRecordFields.TRACE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b1cb5a96cddaf91d2fa526847c883d5e0eec43d47fd120408c3dc8a4af9f2883)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMemoryTracesRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMemoryTracesRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMemoryTracesXRayProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRuntimeApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogs",
):
    '''Builder for CfnRuntimeLogsMixin to generate APPLICATION_LOGS for CfnRuntime.

    :cloudformationResource: AWS::BedrockAgentCore::Runtime
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_runtime_application_logs = bedrockagentcore_mixins.CfnRuntimeApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeApplicationLogsRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3cdec0145b2777a946c7b562bfc340acddbdbbeddf22a4d454bb206e0cf95ef9)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnRuntimeApplicationLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnRuntimeApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeApplicationLogsRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e26d0a37462ec4cab91d61182b516d7706c94f20b05770494a7bf34f1f340405)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnRuntimeApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnRuntimeApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeApplicationLogsRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__baf26c8e9d08f77c0c132cfa2f9be98b4ced10acf2a9b28a07fd5fe2fdfda041)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnRuntimeApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRuntimeApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeApplicationLogsRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45fb75951d996e803562ee5390a56b8736cdafd348f8d8ff221fe415d7f18306)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnRuntimeApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnRuntimeApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_runtime_application_logs_dest_props = bedrockagentcore_mixins.CfnRuntimeApplicationLogsDestProps(
                record_fields=[bedrockagentcore_mixins.CfnRuntimeApplicationLogsRecordFields.ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ead461a803c54ca6dbec4113bf82526ea7f2d8278433867e441d13e735b0524)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRuntimeApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRuntimeApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_runtime_application_logs_firehose_props = bedrockagentcore_mixins.CfnRuntimeApplicationLogsFirehoseProps(
                output_format=bedrockagentcore_mixins.CfnRuntimeApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrockagentcore_mixins.CfnRuntimeApplicationLogsRecordFields.ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6da5801465b7d00167f4f199961ffff1f76c546d0056f42f064b55a3153a0779)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRuntimeApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRuntimeApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRuntimeApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRuntimeApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_runtime_application_logs_log_group_props = bedrockagentcore_mixins.CfnRuntimeApplicationLogsLogGroupProps(
                output_format=bedrockagentcore_mixins.CfnRuntimeApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrockagentcore_mixins.CfnRuntimeApplicationLogsRecordFields.ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__96dc87a4fc9b99383a9e722cec0b26a9a162ff5a915f22fab684d28d7c1ec771)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRuntimeApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRuntimeApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRuntimeApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnRuntimeApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_runtime_application_logs_output_format = bedrockagentcore_mixins.CfnRuntimeApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsRecordFields"
)
class CfnRuntimeApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    ACCOUNT_ID = "ACCOUNT_ID"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    SESSION_ID = "SESSION_ID"
    '''
    :stability: experimental
    '''
    SPAN_ID = "SPAN_ID"
    '''
    :stability: experimental
    '''
    TRACE_ID = "TRACE_ID"
    '''
    :stability: experimental
    '''
    SERVICE_NAME = "SERVICE_NAME"
    '''
    :stability: experimental
    '''
    OPERATION = "OPERATION"
    '''
    :stability: experimental
    '''
    REQUEST_PAYLOAD = "REQUEST_PAYLOAD"
    '''
    :stability: experimental
    '''
    RESPONSE_PAYLOAD = "RESPONSE_PAYLOAD"
    '''
    :stability: experimental
    '''
    RESOURCE = "RESOURCE"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    TIMEUNIXNANO = "TIMEUNIXNANO"
    '''
    :stability: experimental
    '''
    SEVERITYNUMBER = "SEVERITYNUMBER"
    '''
    :stability: experimental
    '''
    SEVERITYTEXT = "SEVERITYTEXT"
    '''
    :stability: experimental
    '''
    BODY = "BODY"
    '''
    :stability: experimental
    '''
    TRACEID = "TRACEID"
    '''
    :stability: experimental
    '''
    SPANID = "SPANID"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnRuntimeApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRuntimeApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_runtime_application_logs_s3_props = bedrockagentcore_mixins.CfnRuntimeApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrockagentcore_mixins.CfnRuntimeApplicationLogsOutputFormat.S3.JSON,
                record_fields=[bedrockagentcore_mixins.CfnRuntimeApplicationLogsRecordFields.ACCOUNT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb19f07d9048b44a949cabe9d492b826672784d827211ad61077ef4912c7a48f)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRuntimeApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRuntimeApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnRuntimeLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeLogsMixin",
):
    '''Contains information about an agent runtime. An agent runtime is the execution environment for a Amazon Bedrock Agent.

    AgentCore Runtime is a secure, serverless runtime purpose-built for deploying and scaling dynamic AI agents and tools using any open-source framework including LangGraph, CrewAI, and Strands Agents, any protocol, and any model.

    For more information about using agent runtime in Amazon Bedrock AgentCore, see `Host agent or tools with Amazon Bedrock AgentCore Runtime <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/agents-tools-runtime.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-runtime.html
    :cloudformationResource: AWS::BedrockAgentCore::Runtime
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_runtime_logs_mixin = bedrockagentcore_mixins.CfnRuntimeLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::BedrockAgentCore::Runtime``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c929ee957c38ecb0579f34f4b66f6b56ef3ba96be84b3225d26fa2d3e7e422dd)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82afd6c4585e501a1f1696467983696efc0e5d38c4e491ede9ec6c24ec33b354)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ffb1490e81fb92d5e598d8ba05358a0857f0478d107764d976388f3f5905d0d9)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnRuntimeApplicationLogs":
        return typing.cast("CfnRuntimeApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TRACES")
    def TRACES(cls) -> "CfnRuntimeTraces":
        return typing.cast("CfnRuntimeTraces", jsii.sget(cls, "TRACES"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="USAGE_LOGS")
    def USAGE_LOGS(cls) -> "CfnRuntimeUsageLogs":
        return typing.cast("CfnRuntimeUsageLogs", jsii.sget(cls, "USAGE_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnRuntimeTraces(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeTraces",
):
    '''Builder for CfnRuntimeLogsMixin to generate TRACES for CfnRuntime.

    :cloudformationResource: AWS::BedrockAgentCore::Runtime
    :logType: TRACES
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_runtime_traces = bedrockagentcore_mixins.CfnRuntimeTraces()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeTracesRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are XRAY
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5c1d5c513d1a1e343f52c791a1fe97a35a2283c6faa1a805d22b0db5a29b5143)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnRuntimeTracesDestProps(record_fields=record_fields)

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toXRay")
    def to_x_ray(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeTracesRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Send traces to X-Ray.

        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        props = CfnRuntimeTracesXRayProps(record_fields=record_fields)

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toXRay", [props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeTracesDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnRuntimeTracesDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeTracesRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_runtime_traces_dest_props = bedrockagentcore_mixins.CfnRuntimeTracesDestProps(
                record_fields=[bedrockagentcore_mixins.CfnRuntimeTracesRecordFields.TRACE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3fc8d09756c3007d7572e8bdd2a142e1ade2d2ce65028d5099d4751ece73c783)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeTracesRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeTracesRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeTracesDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRuntimeTracesOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeTracesOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnRuntimeTraces.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_runtime_traces_output_format = bedrockagentcore_mixins.CfnRuntimeTracesOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeTracesRecordFields"
)
class CfnRuntimeTracesRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TRACE = "TRACE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeTracesXRayProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnRuntimeTracesXRayProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeTracesRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_runtime_traces_xRay_props = bedrockagentcore_mixins.CfnRuntimeTracesXRayProps(
                record_fields=[bedrockagentcore_mixins.CfnRuntimeTracesRecordFields.TRACE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54b2eb017df886fa4e49c3cf4cb2797d4d1dd755f65dbe35a071527425faa3f0)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeTracesRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeTracesRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeTracesXRayProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRuntimeUsageLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogs",
):
    '''Builder for CfnRuntimeLogsMixin to generate USAGE_LOGS for CfnRuntime.

    :cloudformationResource: AWS::BedrockAgentCore::Runtime
    :logType: USAGE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_runtime_usage_logs = bedrockagentcore_mixins.CfnRuntimeUsageLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeUsageLogsRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4b4c5f7c432c5edf290244c8e3a3b11c8c7ee733323f7bf6cdfbbabd8fe7bc30)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnRuntimeUsageLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnRuntimeUsageLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeUsageLogsRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f9772f153313ef784be338509999f9847a5e74a14a547e600eefb3d8f05c508)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnRuntimeUsageLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnRuntimeUsageLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeUsageLogsRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5ff06af738be9bad685e555eff2b1b2e5f3e0eb1c9d6d41b2567ba7313c4a57c)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnRuntimeUsageLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRuntimeUsageLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeUsageLogsRecordFields"]] = None,
    ) -> "CfnRuntimeLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__67485711a24f84880f1990d9936820beddf311a8e4376ddabb3a5fdc7b41ca88)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnRuntimeUsageLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnRuntimeLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnRuntimeUsageLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_runtime_usage_logs_dest_props = bedrockagentcore_mixins.CfnRuntimeUsageLogsDestProps(
                record_fields=[bedrockagentcore_mixins.CfnRuntimeUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bbafed332454a8cd18d3254120e3d44334016383b2edaa216bc6809a1ab7cd33)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeUsageLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRuntimeUsageLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRuntimeUsageLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_runtime_usage_logs_firehose_props = bedrockagentcore_mixins.CfnRuntimeUsageLogsFirehoseProps(
                output_format=bedrockagentcore_mixins.CfnRuntimeUsageLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrockagentcore_mixins.CfnRuntimeUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a43d9939d20bde45753adc73ad6ced6113ef6fb6f81cf3069aec3cd27a02f180)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRuntimeUsageLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRuntimeUsageLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeUsageLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRuntimeUsageLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRuntimeUsageLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_runtime_usage_logs_log_group_props = bedrockagentcore_mixins.CfnRuntimeUsageLogsLogGroupProps(
                output_format=bedrockagentcore_mixins.CfnRuntimeUsageLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrockagentcore_mixins.CfnRuntimeUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9f5bf3d936c9578a1522e9fbde0ee5befafb41789eb21854ca636020ca44684)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRuntimeUsageLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRuntimeUsageLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeUsageLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRuntimeUsageLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnRuntimeUsageLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_runtime_usage_logs_output_format = bedrockagentcore_mixins.CfnRuntimeUsageLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsRecordFields"
)
class CfnRuntimeUsageLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    RESOURCE = "RESOURCE"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    METRICS = "METRICS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnRuntimeUsageLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnRuntimeUsageLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRuntimeUsageLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRuntimeUsageLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_runtime_usage_logs_s3_props = bedrockagentcore_mixins.CfnRuntimeUsageLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrockagentcore_mixins.CfnRuntimeUsageLogsOutputFormat.S3.JSON,
                record_fields=[bedrockagentcore_mixins.CfnRuntimeUsageLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__34deaa734157af56ec7c06153b232af5a3d65152019d12087b4f5c77bf4eab5d)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnRuntimeUsageLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRuntimeUsageLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRuntimeUsageLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRuntimeUsageLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRuntimeUsageLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnWorkloadIdentityApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogs",
):
    '''Builder for CfnWorkloadIdentityLogsMixin to generate APPLICATION_LOGS for CfnWorkloadIdentity.

    :cloudformationResource: AWS::BedrockAgentCore::WorkloadIdentity
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_workload_identity_application_logs = bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnWorkloadIdentityApplicationLogsRecordFields"]] = None,
    ) -> "CfnWorkloadIdentityLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a8e48938e562b63a2e35fd09656b3828c552ff51d26d756be6081f33d52a1e5)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnWorkloadIdentityApplicationLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnWorkloadIdentityLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnWorkloadIdentityApplicationLogsRecordFields"]] = None,
    ) -> "CfnWorkloadIdentityLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97ae8fb4793e66f8cb88c04831f884f9fdbe8a71630f5979e774e0db6ece2087)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnWorkloadIdentityApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnWorkloadIdentityLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnWorkloadIdentityApplicationLogsRecordFields"]] = None,
    ) -> "CfnWorkloadIdentityLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a43e474b1fa9843cf727a68c220ef5ee1eacf5c7d7155cb66009bceeb6a636d)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnWorkloadIdentityApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnWorkloadIdentityLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnWorkloadIdentityApplicationLogsRecordFields"]] = None,
    ) -> "CfnWorkloadIdentityLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__457f2a2268d312bc1d8db275e1ecc70416d25a6ed924bdd7c526347f2e5bda86)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnWorkloadIdentityApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnWorkloadIdentityLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnWorkloadIdentityApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnWorkloadIdentityApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_workload_identity_application_logs_dest_props = bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsDestProps(
                record_fields=[bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsRecordFields.REQUEST_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c97547b6bfc089985c3e506074c1e730b21aac16c22aa63fcd5f339d01f0048)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnWorkloadIdentityApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnWorkloadIdentityApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnWorkloadIdentityApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnWorkloadIdentityApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnWorkloadIdentityApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_workload_identity_application_logs_firehose_props = bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsFirehoseProps(
                output_format=bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsRecordFields.REQUEST_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b997a0f11d19ac1231307c9518f3e849bb6d005fbd16a0c3316783923c35b353)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnWorkloadIdentityApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnWorkloadIdentityApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnWorkloadIdentityApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnWorkloadIdentityApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnWorkloadIdentityApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            
            cfn_workload_identity_application_logs_log_group_props = bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsLogGroupProps(
                output_format=bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsRecordFields.REQUEST_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca0828701068e632211078ba64d6151ec9205cd9ae9bb0c79b318564998b0851)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnWorkloadIdentityApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnWorkloadIdentityApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnWorkloadIdentityApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnWorkloadIdentityApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnWorkloadIdentityApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        cfn_workload_identity_application_logs_output_format = bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsRecordFields"
)
class CfnWorkloadIdentityApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    OPERATION_NAME = "OPERATION_NAME"
    '''
    :stability: experimental
    '''
    OPERATION_TYPE = "OPERATION_TYPE"
    '''
    :stability: experimental
    '''
    START_TIME = "START_TIME"
    '''
    :stability: experimental
    '''
    END_TIME = "END_TIME"
    '''
    :stability: experimental
    '''
    DURATION_MS = "DURATION_MS"
    '''
    :stability: experimental
    '''
    ACCOUNT_ID = "ACCOUNT_ID"
    '''
    :stability: experimental
    '''
    REQUEST = "REQUEST"
    '''
    :stability: experimental
    '''
    RESPONSE = "RESPONSE"
    '''
    :stability: experimental
    '''
    TRACE_ID = "TRACE_ID"
    '''
    :stability: experimental
    '''
    SPAN_ID = "SPAN_ID"
    '''
    :stability: experimental
    '''
    RESOURCE = "RESOURCE"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    TIMEUNIXNANO = "TIMEUNIXNANO"
    '''
    :stability: experimental
    '''
    SEVERITYNUMBER = "SEVERITYNUMBER"
    '''
    :stability: experimental
    '''
    SEVERITYTEXT = "SEVERITYTEXT"
    '''
    :stability: experimental
    '''
    BODY = "BODY"
    '''
    :stability: experimental
    '''
    TRACEID = "TRACEID"
    '''
    :stability: experimental
    '''
    SPANID = "SPANID"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnWorkloadIdentityApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnWorkloadIdentityApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_workload_identity_application_logs_s3_props = bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsOutputFormat.S3.JSON,
                record_fields=[bedrockagentcore_mixins.CfnWorkloadIdentityApplicationLogsRecordFields.REQUEST_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__202a3c20b16b8388da5dd00552d425889ede5995a5edf0b8b2dfe6bb7c54f8c7)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnWorkloadIdentityApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnWorkloadIdentityApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnWorkloadIdentityApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnWorkloadIdentityApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnWorkloadIdentityLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrockagentcore.mixins.CfnWorkloadIdentityLogsMixin",
):
    '''Creates a workload identity for Amazon Bedrock AgentCore.

    A workload identity provides OAuth2-based authentication for resources associated with agent runtimes.

    For more information about using workload identities in Amazon Bedrock AgentCore, see `Managing workload identities <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/workload-identity.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrockagentcore-workloadidentity.html
    :cloudformationResource: AWS::BedrockAgentCore::WorkloadIdentity
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrockagentcore import mixins as bedrockagentcore_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_workload_identity_logs_mixin = bedrockagentcore_mixins.CfnWorkloadIdentityLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::BedrockAgentCore::WorkloadIdentity``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54655373f86d52f2b313ded6d64e84ef254aa2569957b8c1e9fa0570608f3575)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c237fca51df336b3d54414af7adc6bdc5c0b3b78ea8db47a9f34448b8416364)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e8bd484d073359e8b0ae61f7081dcc2346c4a27d7928bdb50f220f8c6413037)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnWorkloadIdentityApplicationLogs":
        return typing.cast("CfnWorkloadIdentityApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnBrowserCustomLogsMixin",
    "CfnBrowserCustomUsageLogs",
    "CfnBrowserCustomUsageLogsDestProps",
    "CfnBrowserCustomUsageLogsFirehoseProps",
    "CfnBrowserCustomUsageLogsLogGroupProps",
    "CfnBrowserCustomUsageLogsOutputFormat",
    "CfnBrowserCustomUsageLogsRecordFields",
    "CfnBrowserCustomUsageLogsS3Props",
    "CfnCodeInterpreterCustomApplicationLogs",
    "CfnCodeInterpreterCustomApplicationLogsDestProps",
    "CfnCodeInterpreterCustomApplicationLogsFirehoseProps",
    "CfnCodeInterpreterCustomApplicationLogsLogGroupProps",
    "CfnCodeInterpreterCustomApplicationLogsOutputFormat",
    "CfnCodeInterpreterCustomApplicationLogsRecordFields",
    "CfnCodeInterpreterCustomApplicationLogsS3Props",
    "CfnCodeInterpreterCustomLogsMixin",
    "CfnCodeInterpreterCustomUsageLogs",
    "CfnCodeInterpreterCustomUsageLogsDestProps",
    "CfnCodeInterpreterCustomUsageLogsFirehoseProps",
    "CfnCodeInterpreterCustomUsageLogsLogGroupProps",
    "CfnCodeInterpreterCustomUsageLogsOutputFormat",
    "CfnCodeInterpreterCustomUsageLogsRecordFields",
    "CfnCodeInterpreterCustomUsageLogsS3Props",
    "CfnGatewayApplicationLogs",
    "CfnGatewayApplicationLogsDestProps",
    "CfnGatewayApplicationLogsFirehoseProps",
    "CfnGatewayApplicationLogsLogGroupProps",
    "CfnGatewayApplicationLogsOutputFormat",
    "CfnGatewayApplicationLogsRecordFields",
    "CfnGatewayApplicationLogsS3Props",
    "CfnGatewayLogsMixin",
    "CfnGatewayTraces",
    "CfnGatewayTracesDestProps",
    "CfnGatewayTracesOutputFormat",
    "CfnGatewayTracesRecordFields",
    "CfnGatewayTracesXRayProps",
    "CfnMemoryApplicationLogs",
    "CfnMemoryApplicationLogsDestProps",
    "CfnMemoryApplicationLogsFirehoseProps",
    "CfnMemoryApplicationLogsLogGroupProps",
    "CfnMemoryApplicationLogsOutputFormat",
    "CfnMemoryApplicationLogsRecordFields",
    "CfnMemoryApplicationLogsS3Props",
    "CfnMemoryLogsMixin",
    "CfnMemoryTraces",
    "CfnMemoryTracesDestProps",
    "CfnMemoryTracesOutputFormat",
    "CfnMemoryTracesRecordFields",
    "CfnMemoryTracesXRayProps",
    "CfnRuntimeApplicationLogs",
    "CfnRuntimeApplicationLogsDestProps",
    "CfnRuntimeApplicationLogsFirehoseProps",
    "CfnRuntimeApplicationLogsLogGroupProps",
    "CfnRuntimeApplicationLogsOutputFormat",
    "CfnRuntimeApplicationLogsRecordFields",
    "CfnRuntimeApplicationLogsS3Props",
    "CfnRuntimeLogsMixin",
    "CfnRuntimeTraces",
    "CfnRuntimeTracesDestProps",
    "CfnRuntimeTracesOutputFormat",
    "CfnRuntimeTracesRecordFields",
    "CfnRuntimeTracesXRayProps",
    "CfnRuntimeUsageLogs",
    "CfnRuntimeUsageLogsDestProps",
    "CfnRuntimeUsageLogsFirehoseProps",
    "CfnRuntimeUsageLogsLogGroupProps",
    "CfnRuntimeUsageLogsOutputFormat",
    "CfnRuntimeUsageLogsRecordFields",
    "CfnRuntimeUsageLogsS3Props",
    "CfnWorkloadIdentityApplicationLogs",
    "CfnWorkloadIdentityApplicationLogsDestProps",
    "CfnWorkloadIdentityApplicationLogsFirehoseProps",
    "CfnWorkloadIdentityApplicationLogsLogGroupProps",
    "CfnWorkloadIdentityApplicationLogsOutputFormat",
    "CfnWorkloadIdentityApplicationLogsRecordFields",
    "CfnWorkloadIdentityApplicationLogsS3Props",
    "CfnWorkloadIdentityLogsMixin",
]

publication.publish()

def _typecheckingstub__1204015ea5825ad1edf8da476379429e640773015e63cf3a0d886ad2986e5422(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd6c5d067697cdae53d3732ce41d3c017b37ccac14b1891e7c078bbe2be278e3(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5ae700cc3744a1f2a546f21c41d8742124ccfc03dd37fc8c426fdd69a9948d9(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b5557b6a2e4a15aead29043c5c59b15d261f21c7f15e9ca83d2b26b2745cefd1(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnBrowserCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc33a2fb67e69b54c08eff634eacbb643fbde00ba0e6541e63395f93c9c49224(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnBrowserCustomUsageLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBrowserCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__64dbd64426e5f3ab769711bebaca1f5e891bf41871180ae2f38795ca4cb93c74(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnBrowserCustomUsageLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBrowserCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05930886aa141f479722ca8a7c90373158a5da565dd72a5bc911e70a64944fa2(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnBrowserCustomUsageLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBrowserCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__891f0dcd7722e9f1267e078dd92d0a24541ae7fe709bcaccb96034c8ef58fb29(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnBrowserCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75161efd68f0dd1bcf6219be20d94a8d7b76aa72da686e8e8997c6e90026d7a6(
    *,
    output_format: typing.Optional[CfnBrowserCustomUsageLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBrowserCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__559d87e9caf771c1ddc4a61dbac7177d53317224033996976d9adcf87da142b0(
    *,
    output_format: typing.Optional[CfnBrowserCustomUsageLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBrowserCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e06de47fd84117549d516f6f0fa4583dae0e4c0e02fa8096e99f0b0ddbb9edca(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnBrowserCustomUsageLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnBrowserCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__376aa4b0b7ebda55b3fdb25060adadd2daa14427edb76ca3764a7af3a648cc14(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__235da9e09238b83e4ee03d2a385d9a67a4c089b94c6709c8be8db5004fb34d94(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9ad00b02c85d7534fda1e3c5f3efd178c9db7d0eca9fefe15daad8275e4eba1f(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e7101be0c4795e8e391d3a9619523aeecc6023b093a4e9e6616a93604e283e6(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__635384dc8d0cea2199d2b5347178aa8a47af981d4e81bbbaf613790234ed4c9e(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d73dfdf6276c0ca1f6165f8187b1d5623ff385fe39e3c276ddc152f7bd84bd8c(
    *,
    output_format: typing.Optional[CfnCodeInterpreterCustomApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca50396a4eba8b6ad09e06600b56e6d429344829cb5f0864624fb460cf5ba40b(
    *,
    output_format: typing.Optional[CfnCodeInterpreterCustomApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9a7c9af5d32896d1457f645fce89ea7a28472a75d075e6c4b4ca854c56e4dff(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCodeInterpreterCustomApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35590a55fa3de02073a91f3724c4c746bb5accef2020e70624bdaddd67c4cfd9(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__77d9002f6d549cf852bb62b298213dd56a96b27501e3bc412fa041fd058ee8ac(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__87fc8eea47962eb75dba0a4724a530e003264367e4289ed742847fcfcd075b35(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__533ec52807524b5d6b7f67139af1da13c19d48a7b8a08eee4a63db51667e225d(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c69e8fb84ecd9ab8ee95e57bc6b44127b2329ef1912ffeac3c74e7117d0a49b(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83938dacb934234d9619aa38d8aea57fbb236466cf2d600deca3dce75f289add(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b311d9c0741c18eab724560ac46a9d809ade50e47676b082106ad313fc883a59(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCodeInterpreterCustomUsageLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__894e4f5d19e6b73cac842d1cafbe6db4f71b1d883b0dfb3ba15614f6bb1b0ce7(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a33cfd9fdf1ce28e8e670aed575ed1868f4bfb3a75acce1e51c8a6e2b088396(
    *,
    output_format: typing.Optional[CfnCodeInterpreterCustomUsageLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17c8c958165d30b0799b7fab61fcc0c4ea430121cf47aa5e0cdfc39ae9c7f479(
    *,
    output_format: typing.Optional[CfnCodeInterpreterCustomUsageLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e05a055727f391340802904b8adaa230f0d252ea987e0bae7ef834b32fe117c(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnCodeInterpreterCustomUsageLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnCodeInterpreterCustomUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da4e88160f72aa29d550aab624d93a1c44ac95f840a4097602aec0568fbe0bed(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39848dbcff7bcfc40d1a54882028de18bd79f07358d575e2f766474c41432799(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnGatewayApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a344d11427e4c8db554328e8e359728d32dff227185be0c431f0e06c8092f457(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnGatewayApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__333af1943f4d576fe2f6f5471c064f69666be8e6d9f2a424aa8e4bbf0a6e6c26(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnGatewayApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e609371a3535a03ddbce2fa82ec671e83e9d07556ff42c82a4aca5c79bc7093(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9fdf7fa743f5ee4714ba9bed593c60ebd8f05fbe78635744f0001d405e741164(
    *,
    output_format: typing.Optional[CfnGatewayApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff6a2b641d368d196d163af7d94f2be9a8fc34683455d7eb64487f7c6260310d(
    *,
    output_format: typing.Optional[CfnGatewayApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1278f1b07343ce019afe1086ef32d3ad0c4b153b7ada069b1c90fbd1e485c4b(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnGatewayApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4bd5d58e42dde39c0c9f95fa42cce3112291750c9c136a8a9cf2c91b01184db(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8707bee110c27b8a30232ab12f1dd6fa82318218289552523e2bef7e7d1124d5(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76cbea6936abcad9bd64780ec1b6cdaa37c3096acf1d0e0c8bb75ea40b400a88(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0cca5996fe4eec1091f940c59169cf87cd409561ba2e1d62834c3d399e1683de(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b0e0f3aae257a78fa6ca850c8dce4b4faa4280f40bde76ffdbfa09f9176b3c0(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9687c40b7cc3bb1401504c7de6d623b2ab9afe61b6b914a3738f9e8a34bc0b33(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnGatewayTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de2cb3ef4efef7c88e74f01623620859c087826e14d26adb8d14eaaf486b3c1e(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__533a3d66a676933e8c35334e4a0fe72487242446cd039c1e22c95749f0aff244(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnMemoryApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d97379a3829ca32dd7989e0c3e7bf095ac6da663e9085d43b47ebfd720d90674(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnMemoryApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bb93e3d5eba71dee2742932d989deb728d771b8572a33bd3b7ec42e99158f2e1(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMemoryApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6dcb4fbfb91f69370ce435139a6d18af66915d62183db0cef556d187ba33399d(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5cd4d39d8e5574b4b2a7c66763391087e47556c73e9a67615c3226d71899e1c2(
    *,
    output_format: typing.Optional[CfnMemoryApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3567128274696650471ed689f529ff6ee6e8a865d56dc47a34241148eebbdc62(
    *,
    output_format: typing.Optional[CfnMemoryApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d61fbf431ceb30e979876f2336bab4f677d3bea1eb7c29f889419a0cf9c3ec3a(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMemoryApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ba1ef598af5d274cde246f021cccd97f3f9bacd72ca55bd4a2a655c256ffc02(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__346aafd94719a39bcd1b7e03f2d1d1c815b572bfa39b9a1b179e7c078ed109d1(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eaa046b4cb4a127be4c06542eeae1311c588dd8afeba3af29448f52bdd1c24f3(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d2d24689b631f5e4c9bc19130caf7837de589758f739258151e687ded026b6dc(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39d0ac2625e6e9ad0d259d1110e131d00beb68b48682cfbe49cf6ef6a7b97bea(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b1cb5a96cddaf91d2fa526847c883d5e0eec43d47fd120408c3dc8a4af9f2883(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMemoryTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3cdec0145b2777a946c7b562bfc340acddbdbbeddf22a4d454bb206e0cf95ef9(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e26d0a37462ec4cab91d61182b516d7706c94f20b05770494a7bf34f1f340405(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnRuntimeApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__baf26c8e9d08f77c0c132cfa2f9be98b4ced10acf2a9b28a07fd5fe2fdfda041(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnRuntimeApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__45fb75951d996e803562ee5390a56b8736cdafd348f8d8ff221fe415d7f18306(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRuntimeApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ead461a803c54ca6dbec4113bf82526ea7f2d8278433867e441d13e735b0524(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6da5801465b7d00167f4f199961ffff1f76c546d0056f42f064b55a3153a0779(
    *,
    output_format: typing.Optional[CfnRuntimeApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__96dc87a4fc9b99383a9e722cec0b26a9a162ff5a915f22fab684d28d7c1ec771(
    *,
    output_format: typing.Optional[CfnRuntimeApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb19f07d9048b44a949cabe9d492b826672784d827211ad61077ef4912c7a48f(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRuntimeApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c929ee957c38ecb0579f34f4b66f6b56ef3ba96be84b3225d26fa2d3e7e422dd(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82afd6c4585e501a1f1696467983696efc0e5d38c4e491ede9ec6c24ec33b354(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ffb1490e81fb92d5e598d8ba05358a0857f0478d107764d976388f3f5905d0d9(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5c1d5c513d1a1e343f52c791a1fe97a35a2283c6faa1a805d22b0db5a29b5143(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3fc8d09756c3007d7572e8bdd2a142e1ade2d2ce65028d5099d4751ece73c783(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54b2eb017df886fa4e49c3cf4cb2797d4d1dd755f65dbe35a071527425faa3f0(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b4c5f7c432c5edf290244c8e3a3b11c8c7ee733323f7bf6cdfbbabd8fe7bc30(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f9772f153313ef784be338509999f9847a5e74a14a547e600eefb3d8f05c508(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnRuntimeUsageLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5ff06af738be9bad685e555eff2b1b2e5f3e0eb1c9d6d41b2567ba7313c4a57c(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnRuntimeUsageLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__67485711a24f84880f1990d9936820beddf311a8e4376ddabb3a5fdc7b41ca88(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRuntimeUsageLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bbafed332454a8cd18d3254120e3d44334016383b2edaa216bc6809a1ab7cd33(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a43d9939d20bde45753adc73ad6ced6113ef6fb6f81cf3069aec3cd27a02f180(
    *,
    output_format: typing.Optional[CfnRuntimeUsageLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9f5bf3d936c9578a1522e9fbde0ee5befafb41789eb21854ca636020ca44684(
    *,
    output_format: typing.Optional[CfnRuntimeUsageLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__34deaa734157af56ec7c06153b232af5a3d65152019d12087b4f5c77bf4eab5d(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRuntimeUsageLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRuntimeUsageLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a8e48938e562b63a2e35fd09656b3828c552ff51d26d756be6081f33d52a1e5(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnWorkloadIdentityApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97ae8fb4793e66f8cb88c04831f884f9fdbe8a71630f5979e774e0db6ece2087(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnWorkloadIdentityApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a43e474b1fa9843cf727a68c220ef5ee1eacf5c7d7155cb66009bceeb6a636d(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnWorkloadIdentityApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__457f2a2268d312bc1d8db275e1ecc70416d25a6ed924bdd7c526347f2e5bda86(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnWorkloadIdentityApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnWorkloadIdentityApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c97547b6bfc089985c3e506074c1e730b21aac16c22aa63fcd5f339d01f0048(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnWorkloadIdentityApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b997a0f11d19ac1231307c9518f3e849bb6d005fbd16a0c3316783923c35b353(
    *,
    output_format: typing.Optional[CfnWorkloadIdentityApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnWorkloadIdentityApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca0828701068e632211078ba64d6151ec9205cd9ae9bb0c79b318564998b0851(
    *,
    output_format: typing.Optional[CfnWorkloadIdentityApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnWorkloadIdentityApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__202a3c20b16b8388da5dd00552d425889ede5995a5edf0b8b2dfe6bb7c54f8c7(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnWorkloadIdentityApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnWorkloadIdentityApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54655373f86d52f2b313ded6d64e84ef254aa2569957b8c1e9fa0570608f3575(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3c237fca51df336b3d54414af7adc6bdc5c0b3b78ea8db47a9f34448b8416364(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e8bd484d073359e8b0ae61f7081dcc2346c4a27d7928bdb50f220f8c6413037(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
