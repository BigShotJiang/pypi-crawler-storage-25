from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnWorkteamActivityLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.mixins.CfnWorkteamActivityLogs",
):
    '''Builder for CfnWorkteamLogsMixin to generate ACTIVITY_LOGS for CfnWorkteam.

    :cloudformationResource: AWS::SageMaker::Workteam
    :logType: ACTIVITY_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import mixins as sagemaker_mixins
        
        cfn_workteam_activity_logs = sagemaker_mixins.CfnWorkteamActivityLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnWorkteamLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c83b9068ef751ef412b7b245796d099cfa28e51ef5e9015c945eedb5b051af75)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnWorkteamLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnWorkteamActivityLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnWorkteamLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92228414cc89bed162fbb68f09e1163e9a895d2bf16d7723307512630c68f388)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnWorkteamActivityLogsLogGroupProps(output_format=output_format)

        return typing.cast("CfnWorkteamLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnWorkteamActivityLogsOutputFormat.S3"] = None,
    ) -> "CfnWorkteamLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__599dfafaef5039b810ff08f47856bbbf0d53640f59d78bee9a5883d825e3a570)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnWorkteamActivityLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnWorkteamLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.mixins.CfnWorkteamActivityLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnWorkteamActivityLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnWorkteamActivityLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_sagemaker import mixins as sagemaker_mixins
            
            cfn_workteam_activity_logs_log_group_props = sagemaker_mixins.CfnWorkteamActivityLogsLogGroupProps(
                output_format=sagemaker_mixins.CfnWorkteamActivityLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a55206da8061dbbc8b7961c7762b61eb4f1cbd4c2af4f805f4c9644cbca797c)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnWorkteamActivityLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnWorkteamActivityLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnWorkteamActivityLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnWorkteamActivityLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.mixins.CfnWorkteamActivityLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnWorkteamActivityLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import mixins as sagemaker_mixins
        
        cfn_workteam_activity_logs_output_format = sagemaker_mixins.CfnWorkteamActivityLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.mixins.CfnWorkteamActivityLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.mixins.CfnWorkteamActivityLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.mixins.CfnWorkteamActivityLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnWorkteamActivityLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnWorkteamActivityLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_sagemaker import mixins as sagemaker_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_workteam_activity_logs_s3_props = sagemaker_mixins.CfnWorkteamActivityLogsS3Props(
                encryption_key=key_ref,
                output_format=sagemaker_mixins.CfnWorkteamActivityLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5c236a67b511b7b649d1518ae56916fad5caf0fa3cdc3c0a5e7d3c770bf0108b)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnWorkteamActivityLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnWorkteamActivityLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnWorkteamActivityLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnWorkteamLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.mixins.CfnWorkteamLogsMixin",
):
    '''Creates a new work team for labeling your data.

    A work team is defined by one or more Amazon Cognito user pools. You must first create the user pools before you can create a work team.

    You cannot create more than 25 work teams in an account and region.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-sagemaker-workteam.html
    :cloudformationResource: AWS::SageMaker::Workteam
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_sagemaker import mixins as sagemaker_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_workteam_logs_mixin = sagemaker_mixins.CfnWorkteamLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::SageMaker::Workteam``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__163cac0f45f85a77b620b91158a730c770e8554effacd11fad4e09394f54421a)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f33dac0e3d734c107cd5cad06d616f0af24a1e8436eb50b6e2063c0dbe454ee)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e4f3786676a09299eeb3874bfc9bbbcfb87ccd4ffbd6d5e9b26841cb4a7c74ab)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ACTIVITY_LOGS")
    def ACTIVITY_LOGS(cls) -> "CfnWorkteamActivityLogs":
        return typing.cast("CfnWorkteamActivityLogs", jsii.sget(cls, "ACTIVITY_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnWorkteamActivityLogs",
    "CfnWorkteamActivityLogsLogGroupProps",
    "CfnWorkteamActivityLogsOutputFormat",
    "CfnWorkteamActivityLogsS3Props",
    "CfnWorkteamLogsMixin",
]

publication.publish()

def _typecheckingstub__c83b9068ef751ef412b7b245796d099cfa28e51ef5e9015c945eedb5b051af75(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92228414cc89bed162fbb68f09e1163e9a895d2bf16d7723307512630c68f388(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnWorkteamActivityLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__599dfafaef5039b810ff08f47856bbbf0d53640f59d78bee9a5883d825e3a570(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnWorkteamActivityLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a55206da8061dbbc8b7961c7762b61eb4f1cbd4c2af4f805f4c9644cbca797c(
    *,
    output_format: typing.Optional[CfnWorkteamActivityLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5c236a67b511b7b649d1518ae56916fad5caf0fa3cdc3c0a5e7d3c770bf0108b(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnWorkteamActivityLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__163cac0f45f85a77b620b91158a730c770e8554effacd11fad4e09394f54421a(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f33dac0e3d734c107cd5cad06d616f0af24a1e8436eb50b6e2063c0dbe454ee(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4f3786676a09299eeb3874bfc9bbbcfb87ccd4ffbd6d5e9b26841cb4a7c74ab(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
