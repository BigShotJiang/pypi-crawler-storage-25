from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnDistributionAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogs",
):
    '''Builder for CfnDistributionLogsMixin to generate ACCESS_LOGS for CfnDistribution.

    :cloudformationResource: AWS::CloudFront::Distribution
    :logType: ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
        
        cfn_distribution_access_logs = cloudfront_mixins.CfnDistributionAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionAccessLogsRecordFields"]] = None,
    ) -> "CfnDistributionLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ac54580bae98885bd5345269e313637856f94974ed3bae6ce51a2504f77c623c)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnDistributionAccessLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnDistributionLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnDistributionAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionAccessLogsRecordFields"]] = None,
    ) -> "CfnDistributionLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__30a287ea3890e0702dfc46de04436310bd5a6c7f7e1eee95c2167f10f227f61f)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnDistributionAccessLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnDistributionLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnDistributionAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionAccessLogsRecordFields"]] = None,
    ) -> "CfnDistributionLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80e849c2f3203d26169c75845fa57f80a06ec47683a301d711e4a5cfe68911c2)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnDistributionAccessLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnDistributionLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnDistributionAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionAccessLogsRecordFields"]] = None,
    ) -> "CfnDistributionLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__890794489b8f4bc70009d25ef061f5698a0693d86dd444fbf791b0fc67d02226)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnDistributionAccessLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnDistributionLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnDistributionAccessLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
            
            cfn_distribution_access_logs_dest_props = cloudfront_mixins.CfnDistributionAccessLogsDestProps(
                record_fields=[cloudfront_mixins.CfnDistributionAccessLogsRecordFields.DATE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4d68a32014eae6039e1a2580131603e3a3b70cf8486d8645cb1809d2f84bc1f8)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnDistributionAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnDistributionAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnDistributionAccessLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnDistributionAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnDistributionAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
            
            cfn_distribution_access_logs_firehose_props = cloudfront_mixins.CfnDistributionAccessLogsFirehoseProps(
                output_format=cloudfront_mixins.CfnDistributionAccessLogsOutputFormat.Firehose.JSON,
                record_fields=[cloudfront_mixins.CfnDistributionAccessLogsRecordFields.DATE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ece39eeca48d31d6f5f0e7b9f737de809992a56721d251889b06a6584036cc22)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnDistributionAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnDistributionAccessLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnDistributionAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnDistributionAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnDistributionAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnDistributionAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnDistributionAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
            
            cfn_distribution_access_logs_log_group_props = cloudfront_mixins.CfnDistributionAccessLogsLogGroupProps(
                output_format=cloudfront_mixins.CfnDistributionAccessLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[cloudfront_mixins.CfnDistributionAccessLogsRecordFields.DATE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__823d8ddfa84f4522f41e3d8b371d2bec59cd003a0aa0e9d5d9a2b626ec701c11)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnDistributionAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnDistributionAccessLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnDistributionAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnDistributionAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnDistributionAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnDistributionAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnDistributionAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
        
        cfn_distribution_access_logs_output_format = cloudfront_mixins.CfnDistributionAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsRecordFields"
)
class CfnDistributionAccessLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    DATE = "DATE"
    '''
    :stability: experimental
    '''
    TIME = "TIME"
    '''
    :stability: experimental
    '''
    X_EDGE_LOCATION = "X_EDGE_LOCATION"
    '''
    :stability: experimental
    '''
    SC_BYTES = "SC_BYTES"
    '''
    :stability: experimental
    '''
    C_IP = "C_IP"
    '''
    :stability: experimental
    '''
    CS_METHOD = "CS_METHOD"
    '''
    :stability: experimental
    '''
    CS_HOST_ = "CS_HOST_"
    '''
    :stability: experimental
    '''
    CS_URI_STEM = "CS_URI_STEM"
    '''
    :stability: experimental
    '''
    SC_STATUS = "SC_STATUS"
    '''
    :stability: experimental
    '''
    CS_REFERER_ = "CS_REFERER_"
    '''
    :stability: experimental
    '''
    CS_USER_AGENT_ = "CS_USER_AGENT_"
    '''
    :stability: experimental
    '''
    CS_URI_QUERY = "CS_URI_QUERY"
    '''
    :stability: experimental
    '''
    CS_COOKIE_ = "CS_COOKIE_"
    '''
    :stability: experimental
    '''
    X_EDGE_RESULT_TYPE = "X_EDGE_RESULT_TYPE"
    '''
    :stability: experimental
    '''
    X_EDGE_REQUEST_ID = "X_EDGE_REQUEST_ID"
    '''
    :stability: experimental
    '''
    X_HOST_HEADER = "X_HOST_HEADER"
    '''
    :stability: experimental
    '''
    CS_PROTOCOL = "CS_PROTOCOL"
    '''
    :stability: experimental
    '''
    CS_BYTES = "CS_BYTES"
    '''
    :stability: experimental
    '''
    TIME_TAKEN = "TIME_TAKEN"
    '''
    :stability: experimental
    '''
    X_FORWARDED_FOR = "X_FORWARDED_FOR"
    '''
    :stability: experimental
    '''
    SSL_PROTOCOL = "SSL_PROTOCOL"
    '''
    :stability: experimental
    '''
    SSL_CIPHER = "SSL_CIPHER"
    '''
    :stability: experimental
    '''
    X_EDGE_RESPONSE_RESULT_TYPE = "X_EDGE_RESPONSE_RESULT_TYPE"
    '''
    :stability: experimental
    '''
    CS_PROTOCOL_VERSION = "CS_PROTOCOL_VERSION"
    '''
    :stability: experimental
    '''
    FLE_STATUS = "FLE_STATUS"
    '''
    :stability: experimental
    '''
    FLE_ENCRYPTED_FIELDS = "FLE_ENCRYPTED_FIELDS"
    '''
    :stability: experimental
    '''
    C_PORT = "C_PORT"
    '''
    :stability: experimental
    '''
    TIME_TO_FIRST_BYTE = "TIME_TO_FIRST_BYTE"
    '''
    :stability: experimental
    '''
    X_EDGE_DETAILED_RESULT_TYPE = "X_EDGE_DETAILED_RESULT_TYPE"
    '''
    :stability: experimental
    '''
    SC_CONTENT_TYPE = "SC_CONTENT_TYPE"
    '''
    :stability: experimental
    '''
    SC_CONTENT_LEN = "SC_CONTENT_LEN"
    '''
    :stability: experimental
    '''
    SC_RANGE_START = "SC_RANGE_START"
    '''
    :stability: experimental
    '''
    SC_RANGE_END = "SC_RANGE_END"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnDistributionAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnDistributionAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_distribution_access_logs_s3_props = cloudfront_mixins.CfnDistributionAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=cloudfront_mixins.CfnDistributionAccessLogsOutputFormat.S3.JSON,
                record_fields=[cloudfront_mixins.CfnDistributionAccessLogsRecordFields.DATE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0c6fa5f7077d863ef48626fab44cc2ec41a38da300d828a227e50a38b8beb641)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnDistributionAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnDistributionAccessLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnDistributionAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnDistributionAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnDistributionAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnDistributionConnectionLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogs",
):
    '''Builder for CfnDistributionLogsMixin to generate CONNECTION_LOGS for CfnDistribution.

    :cloudformationResource: AWS::CloudFront::Distribution
    :logType: CONNECTION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
        
        cfn_distribution_connection_logs = cloudfront_mixins.CfnDistributionConnectionLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionConnectionLogsRecordFields"]] = None,
    ) -> "CfnDistributionLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e44b793b9a883e3e6f698d70dafef3049375231772f58f58af6485cdb814717)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnDistributionConnectionLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnDistributionLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnDistributionConnectionLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionConnectionLogsRecordFields"]] = None,
    ) -> "CfnDistributionLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba4dd34cfc59c0b0040ade1ba8949e75765e759f8b9903bc6f91feaea2b65314)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnDistributionConnectionLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnDistributionLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnDistributionConnectionLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionConnectionLogsRecordFields"]] = None,
    ) -> "CfnDistributionLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__faad6c8b947ecfc90b1f48921e9aff6c38fcba268b8ed9d1e155d00804cd9797)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnDistributionConnectionLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnDistributionLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnDistributionConnectionLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionConnectionLogsRecordFields"]] = None,
    ) -> "CfnDistributionLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb1d04ccaecdd267c4b1639299852817299f687795a66bab5a172d58ed9ed6b5)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnDistributionConnectionLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnDistributionLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnDistributionConnectionLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
            
            cfn_distribution_connection_logs_dest_props = cloudfront_mixins.CfnDistributionConnectionLogsDestProps(
                record_fields=[cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CONNECTIONSTATUS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b7f3648031fadc74db6b7452e93e392705ffb47030b20b76827b468c7cbc5ca)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnDistributionConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnDistributionConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnDistributionConnectionLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnDistributionConnectionLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnDistributionConnectionLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
            
            cfn_distribution_connection_logs_firehose_props = cloudfront_mixins.CfnDistributionConnectionLogsFirehoseProps(
                output_format=cloudfront_mixins.CfnDistributionConnectionLogsOutputFormat.Firehose.JSON,
                record_fields=[cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CONNECTIONSTATUS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__10b0ebf26b6c729984c752a5b753b54421ccc987b07939aa482164c052509983)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnDistributionConnectionLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnDistributionConnectionLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnDistributionConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnDistributionConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnDistributionConnectionLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnDistributionConnectionLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnDistributionConnectionLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: infused

        Example::

            import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins
            
            # Create CloudFront distribution
            # origin: s3.IBucket
            
            distribution = cloudfront.Distribution(scope, "Distribution",
                default_behavior=cloudfront.BehaviorOptions(
                    origin=origins.S3BucketOrigin.with_origin_access_control(origin)
                )
            )
            
            # Create log destination
            log_group = logs.LogGroup(scope, "DeliveryLogGroup")
            
            # Configure log delivery using the mixin
            distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_log_group(log_group,
                output_format=cloudfront_mixins.CfnDistributionConnectionLogsOutputFormat.LogGroup.JSON,
                record_fields=[cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CONNECTIONSTATUS, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CLIENTIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.SERVERIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.TLSPROTOCOL
                ]
            ))
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0d0cab0dd953f89f774885ddfa0f15c0be22ac4ddc110028d61c8bc148c12109)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnDistributionConnectionLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnDistributionConnectionLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnDistributionConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnDistributionConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnDistributionConnectionLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnDistributionConnectionLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnDistributionConnectionLogs.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins
        
        # Create CloudFront distribution
        # origin: s3.IBucket
        
        distribution = cloudfront.Distribution(scope, "Distribution",
            default_behavior=cloudfront.BehaviorOptions(
                origin=origins.S3BucketOrigin.with_origin_access_control(origin)
            )
        )
        
        # Create log destination
        log_group = logs.LogGroup(scope, "DeliveryLogGroup")
        
        # Configure log delivery using the mixin
        distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_log_group(log_group,
            output_format=cloudfront_mixins.CfnDistributionConnectionLogsOutputFormat.LogGroup.JSON,
            record_fields=[cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CONNECTIONSTATUS, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CLIENTIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.SERVERIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.TLSPROTOCOL
            ]
        ))
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        :exampleMetadata: infused

        Example::

            import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins
            
            # Create CloudFront distribution
            # origin: s3.IBucket
            
            distribution = cloudfront.Distribution(scope, "Distribution",
                default_behavior=cloudfront.BehaviorOptions(
                    origin=origins.S3BucketOrigin.with_origin_access_control(origin)
                )
            )
            
            # Create log destination
            log_group = logs.LogGroup(scope, "DeliveryLogGroup")
            
            # Configure log delivery using the mixin
            distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_log_group(log_group,
                output_format=cloudfront_mixins.CfnDistributionConnectionLogsOutputFormat.LogGroup.JSON,
                record_fields=[cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CONNECTIONSTATUS, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CLIENTIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.SERVERIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.TLSPROTOCOL
                ]
            ))
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsRecordFields"
)
class CfnDistributionConnectionLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    :exampleMetadata: infused

    Example::

        import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins
        
        # Create CloudFront distribution
        # origin: s3.IBucket
        
        distribution = cloudfront.Distribution(scope, "Distribution",
            default_behavior=cloudfront.BehaviorOptions(
                origin=origins.S3BucketOrigin.with_origin_access_control(origin)
            )
        )
        
        # Create log destination
        log_group = logs.LogGroup(scope, "DeliveryLogGroup")
        
        # Configure log delivery using the mixin
        distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_log_group(log_group,
            output_format=cloudfront_mixins.CfnDistributionConnectionLogsOutputFormat.LogGroup.JSON,
            record_fields=[cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CONNECTIONSTATUS, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CLIENTIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.SERVERIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.TLSPROTOCOL
            ]
        ))
    '''

    CONNECTIONSTATUS = "CONNECTIONSTATUS"
    '''
    :stability: experimental
    '''
    CLIENTIP = "CLIENTIP"
    '''
    :stability: experimental
    '''
    CLIENTPORT = "CLIENTPORT"
    '''
    :stability: experimental
    '''
    SERVERIP = "SERVERIP"
    '''
    :stability: experimental
    '''
    DISTRIBUTIONTENANTID = "DISTRIBUTIONTENANTID"
    '''
    :stability: experimental
    '''
    TLSPROTOCOL = "TLSPROTOCOL"
    '''
    :stability: experimental
    '''
    TLSCIPHER = "TLSCIPHER"
    '''
    :stability: experimental
    '''
    TLSHANDSHAKEDURATION = "TLSHANDSHAKEDURATION"
    '''
    :stability: experimental
    '''
    TLSSNI = "TLSSNI"
    '''
    :stability: experimental
    '''
    CLIENTLEAFCERTSERIALNUMBER = "CLIENTLEAFCERTSERIALNUMBER"
    '''
    :stability: experimental
    '''
    CLIENTLEAFCERTSUBJECT = "CLIENTLEAFCERTSUBJECT"
    '''
    :stability: experimental
    '''
    CLIENTLEAFCERTISSUER = "CLIENTLEAFCERTISSUER"
    '''
    :stability: experimental
    '''
    CLIENTLEAFCERTVALIDITY = "CLIENTLEAFCERTVALIDITY"
    '''
    :stability: experimental
    '''
    CONNECTIONLOGCUSTOMDATA = "CONNECTIONLOGCUSTOMDATA"
    '''
    :stability: experimental
    '''
    EVENTTIMESTAMP = "EVENTTIMESTAMP"
    '''
    :stability: experimental
    '''
    CONNECTIONID = "CONNECTIONID"
    '''
    :stability: experimental
    '''
    DISTRIBUTIONID = "DISTRIBUTIONID"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionConnectionLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnDistributionConnectionLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnDistributionConnectionLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnDistributionConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_cloudfront import mixins as cloudfront_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_distribution_connection_logs_s3_props = cloudfront_mixins.CfnDistributionConnectionLogsS3Props(
                encryption_key=key_ref,
                output_format=cloudfront_mixins.CfnDistributionConnectionLogsOutputFormat.S3.JSON,
                record_fields=[cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CONNECTIONSTATUS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3fdf42823665b674021a8386975841d5b479c4a6237eb8801731766a955867e2)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnDistributionConnectionLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnDistributionConnectionLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnDistributionConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnDistributionConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnDistributionConnectionLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnDistributionLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_cloudfront.mixins.CfnDistributionLogsMixin",
):
    '''A distribution tells CloudFront where you want content to be delivered from, and the details about how to track and manage content delivery.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudfront-distribution.html
    :cloudformationResource: AWS::CloudFront::Distribution
    :mixin: true
    :exampleMetadata: infused

    Example::

        import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins
        
        # Create CloudFront distribution
        # origin: s3.IBucket
        
        distribution = cloudfront.Distribution(scope, "Distribution",
            default_behavior=cloudfront.BehaviorOptions(
                origin=origins.S3BucketOrigin.with_origin_access_control(origin)
            )
        )
        
        # Create destination bucket
        dest_bucket = s3.Bucket(scope, "DeliveryBucket")
        # Add permissions to bucket to facilitate log delivery
        bucket_policy = s3.BucketPolicy(scope, "DeliveryBucketPolicy",
            bucket=dest_bucket,
            document=iam.PolicyDocument()
        )
        # Create S3 delivery destination for logs
        destination = logs.CfnDeliveryDestination(scope, "Destination",
            destination_resource_arn=dest_bucket.bucket_arn,
            name="unique-destination-name",
            delivery_destination_type="S3"
        )
        
        distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_destination(destination))
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::CloudFront::Distribution``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__666250e708c234080be300a7271a80fff24de64d9bdadb9e6cb7114566802e94)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__290389a676a802761adba44fa7bf130b98116df76cbc10423840b8dd427e5541)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e74a820d23df897cd6588836ffaadfb9775dca2154d0526771da06df05d9536a)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ACCESS_LOGS")
    def ACCESS_LOGS(cls) -> "CfnDistributionAccessLogs":
        return typing.cast("CfnDistributionAccessLogs", jsii.sget(cls, "ACCESS_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="CONNECTION_LOGS")
    def CONNECTION_LOGS(cls) -> "CfnDistributionConnectionLogs":
        return typing.cast("CfnDistributionConnectionLogs", jsii.sget(cls, "CONNECTION_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnDistributionAccessLogs",
    "CfnDistributionAccessLogsDestProps",
    "CfnDistributionAccessLogsFirehoseProps",
    "CfnDistributionAccessLogsLogGroupProps",
    "CfnDistributionAccessLogsOutputFormat",
    "CfnDistributionAccessLogsRecordFields",
    "CfnDistributionAccessLogsS3Props",
    "CfnDistributionConnectionLogs",
    "CfnDistributionConnectionLogsDestProps",
    "CfnDistributionConnectionLogsFirehoseProps",
    "CfnDistributionConnectionLogsLogGroupProps",
    "CfnDistributionConnectionLogsOutputFormat",
    "CfnDistributionConnectionLogsRecordFields",
    "CfnDistributionConnectionLogsS3Props",
    "CfnDistributionLogsMixin",
]

publication.publish()

def _typecheckingstub__ac54580bae98885bd5345269e313637856f94974ed3bae6ce51a2504f77c623c(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__30a287ea3890e0702dfc46de04436310bd5a6c7f7e1eee95c2167f10f227f61f(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnDistributionAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80e849c2f3203d26169c75845fa57f80a06ec47683a301d711e4a5cfe68911c2(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnDistributionAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__890794489b8f4bc70009d25ef061f5698a0693d86dd444fbf791b0fc67d02226(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnDistributionAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4d68a32014eae6039e1a2580131603e3a3b70cf8486d8645cb1809d2f84bc1f8(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ece39eeca48d31d6f5f0e7b9f737de809992a56721d251889b06a6584036cc22(
    *,
    output_format: typing.Optional[CfnDistributionAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__823d8ddfa84f4522f41e3d8b371d2bec59cd003a0aa0e9d5d9a2b626ec701c11(
    *,
    output_format: typing.Optional[CfnDistributionAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0c6fa5f7077d863ef48626fab44cc2ec41a38da300d828a227e50a38b8beb641(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnDistributionAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e44b793b9a883e3e6f698d70dafef3049375231772f58f58af6485cdb814717(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba4dd34cfc59c0b0040ade1ba8949e75765e759f8b9903bc6f91feaea2b65314(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnDistributionConnectionLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__faad6c8b947ecfc90b1f48921e9aff6c38fcba268b8ed9d1e155d00804cd9797(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnDistributionConnectionLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb1d04ccaecdd267c4b1639299852817299f687795a66bab5a172d58ed9ed6b5(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnDistributionConnectionLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b7f3648031fadc74db6b7452e93e392705ffb47030b20b76827b468c7cbc5ca(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__10b0ebf26b6c729984c752a5b753b54421ccc987b07939aa482164c052509983(
    *,
    output_format: typing.Optional[CfnDistributionConnectionLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0d0cab0dd953f89f774885ddfa0f15c0be22ac4ddc110028d61c8bc148c12109(
    *,
    output_format: typing.Optional[CfnDistributionConnectionLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3fdf42823665b674021a8386975841d5b479c4a6237eb8801731766a955867e2(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnDistributionConnectionLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnDistributionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__666250e708c234080be300a7271a80fff24de64d9bdadb9e6cb7114566802e94(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__290389a676a802761adba44fa7bf130b98116df76cbc10423840b8dd427e5541(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e74a820d23df897cd6588836ffaadfb9775dca2154d0526771da06df05d9536a(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
