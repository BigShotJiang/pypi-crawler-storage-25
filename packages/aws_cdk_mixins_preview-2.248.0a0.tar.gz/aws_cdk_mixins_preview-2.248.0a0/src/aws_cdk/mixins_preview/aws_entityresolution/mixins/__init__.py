from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnIdMappingWorkflowLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowLogsMixin",
):
    '''Creates an ``IdMappingWorkflow`` object which stores the configuration of the data processing job to be run.

    Each ``IdMappingWorkflow`` must have a unique workflow name. To modify an existing workflow, use the UpdateIdMappingWorkflow API.
    .. epigraph::

       Incremental processing is not supported for ID mapping workflows.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html
    :cloudformationResource: AWS::EntityResolution::IdMappingWorkflow
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_id_mapping_workflow_logs_mixin = entityresolution_mixins.CfnIdMappingWorkflowLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EntityResolution::IdMappingWorkflow``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f8319c797870fa92349f44077970fe8648468e2795b9542d5ca9411c4ed149e9)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5d87cdbf6f8b09b8206a9ba5b3013799b7cf869f2fa739acaf9ee868341cf8c4)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e558b8ce6c2ccef5e30fb2c16ebf9979785916fa1ff01f6dcec2603fb764fba8)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="WORKFLOW_LOGS")
    def WORKFLOW_LOGS(cls) -> "CfnIdMappingWorkflowWorkflowLogs":
        return typing.cast("CfnIdMappingWorkflowWorkflowLogs", jsii.sget(cls, "WORKFLOW_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnIdMappingWorkflowWorkflowLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogs",
):
    '''Builder for CfnIdMappingWorkflowLogsMixin to generate WORKFLOW_LOGS for CfnIdMappingWorkflow.

    :cloudformationResource: AWS::EntityResolution::IdMappingWorkflow
    :logType: WORKFLOW_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
        
        cfn_id_mapping_workflow_workflow_logs = entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnIdMappingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> "CfnIdMappingWorkflowLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a225f8f5893e951cb382273f6c8d394d2fd0b7b866670ac55f83de1d9a36861b)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnIdMappingWorkflowWorkflowLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnIdMappingWorkflowLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnIdMappingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> "CfnIdMappingWorkflowLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3efe0cff0ff4600833c55d1c985fc32b7d8dcad347cda41b6079e3485e5e6e2c)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnIdMappingWorkflowWorkflowLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnIdMappingWorkflowLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnIdMappingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> "CfnIdMappingWorkflowLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4ab79b7040061e1d0b085b12c2f3432fc871a7d4338f602047fec39483a97cba)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnIdMappingWorkflowWorkflowLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnIdMappingWorkflowLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnIdMappingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> "CfnIdMappingWorkflowLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a0c221bcb56c45f3dbd005ebee24ed401a32efcfff33a39a56e20c1442bc844e)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnIdMappingWorkflowWorkflowLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnIdMappingWorkflowLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnIdMappingWorkflowWorkflowLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnIdMappingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
            
            cfn_id_mapping_workflow_workflow_logs_dest_props = entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsDestProps(
                record_fields=[entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8dc31777e3b084edc0c8048024da10732698afa84d3b00b1f91a575776d73129)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnIdMappingWorkflowWorkflowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnIdMappingWorkflowWorkflowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnIdMappingWorkflowWorkflowLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnIdMappingWorkflowWorkflowLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnIdMappingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
            
            cfn_id_mapping_workflow_workflow_logs_firehose_props = entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsFirehoseProps(
                output_format=entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose.JSON,
                record_fields=[entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__07ffcca0dcdb9600a7e38e1061db388da802e7f577ec8134f940322832be618e)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnIdMappingWorkflowWorkflowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnIdMappingWorkflowWorkflowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnIdMappingWorkflowWorkflowLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnIdMappingWorkflowWorkflowLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnIdMappingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
            
            cfn_id_mapping_workflow_workflow_logs_log_group_props = entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsLogGroupProps(
                output_format=entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d2cca7aaf3e9bb14836f11bd4f08f3395dfbff7b77f8128d7af71d5d04abd1d)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnIdMappingWorkflowWorkflowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnIdMappingWorkflowWorkflowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnIdMappingWorkflowWorkflowLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnIdMappingWorkflowWorkflowLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnIdMappingWorkflowWorkflowLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
        
        cfn_id_mapping_workflow_workflow_logs_output_format = entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsRecordFields"
)
class CfnIdMappingWorkflowWorkflowLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TYPE = "EVENT_TYPE"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    JOB_ID = "JOB_ID"
    '''
    :stability: experimental
    '''
    WORKFLOW_NAME = "WORKFLOW_NAME"
    '''
    :stability: experimental
    '''
    WORKFLOW_START_TIME = "WORKFLOW_START_TIME"
    '''
    :stability: experimental
    '''
    WORKFLOW_COMPLETE_TIME = "WORKFLOW_COMPLETE_TIME"
    '''
    :stability: experimental
    '''
    DATA_PROCESSING_PROGRESSION = "DATA_PROCESSING_PROGRESSION"
    '''
    :stability: experimental
    '''
    ERROR_MESSAGE = "ERROR_MESSAGE"
    '''
    :stability: experimental
    '''
    MATCH_RULE = "MATCH_RULE"
    '''
    :stability: experimental
    '''
    MATCH_COUNT = "MATCH_COUNT"
    '''
    :stability: experimental
    '''
    TOTAL_RECORDS_PROCESSED = "TOTAL_RECORDS_PROCESSED"
    '''
    :stability: experimental
    '''
    TOTAL_RECORDS_UNPROCESSED = "TOTAL_RECORDS_UNPROCESSED"
    '''
    :stability: experimental
    '''
    INCREMENTAL_RECORDS_PROCESSED = "INCREMENTAL_RECORDS_PROCESSED"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnIdMappingWorkflowWorkflowLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnIdMappingWorkflowWorkflowLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnIdMappingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_id_mapping_workflow_workflow_logs_s3_props = entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsS3Props(
                encryption_key=key_ref,
                output_format=entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3.JSON,
                record_fields=[entityresolution_mixins.CfnIdMappingWorkflowWorkflowLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a6d90ceb7afb2ce49fdf224eeda355af9db9042e2347e8b6343809b5e4475086)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnIdMappingWorkflowWorkflowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnIdMappingWorkflowWorkflowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnIdMappingWorkflowWorkflowLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnMatchingWorkflowLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowLogsMixin",
):
    '''Creates a matching workflow that defines the configuration for a data processing job.

    The workflow name must be unique. To modify an existing workflow, use ``UpdateMatchingWorkflow`` .
    .. epigraph::

       For workflows where ``resolutionType`` is ``ML_MATCHING`` or ``PROVIDER`` , incremental processing is not supported.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html
    :cloudformationResource: AWS::EntityResolution::MatchingWorkflow
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_matching_workflow_logs_mixin = entityresolution_mixins.CfnMatchingWorkflowLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EntityResolution::MatchingWorkflow``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a2a2f8f41e56803947feeac063141099a92bd03d48742c1294fd888e5c86f3f)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__32fe9df30012d7ee5ff8ad68526b3ca56aa553a067d710540e6da25435985e55)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37f0125aaab9fb5c7fe239c86824ba8eb20303f55113b06eb498ed52aeef2cca)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="WORKFLOW_LOGS")
    def WORKFLOW_LOGS(cls) -> "CfnMatchingWorkflowWorkflowLogs":
        return typing.cast("CfnMatchingWorkflowWorkflowLogs", jsii.sget(cls, "WORKFLOW_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnMatchingWorkflowWorkflowLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogs",
):
    '''Builder for CfnMatchingWorkflowLogsMixin to generate WORKFLOW_LOGS for CfnMatchingWorkflow.

    :cloudformationResource: AWS::EntityResolution::MatchingWorkflow
    :logType: WORKFLOW_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
        
        cfn_matching_workflow_workflow_logs = entityresolution_mixins.CfnMatchingWorkflowWorkflowLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMatchingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> "CfnMatchingWorkflowLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__19acaba924125cb703d3c987439d4f5e14c35bbf6a97ab4ec96157ad80e0cf17)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnMatchingWorkflowWorkflowLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnMatchingWorkflowLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMatchingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> "CfnMatchingWorkflowLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2257f60341f3ac0ce4bb5c2d9279eff2a4cf56696f4e3747e11be5ba9717ea2f)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnMatchingWorkflowWorkflowLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMatchingWorkflowLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMatchingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> "CfnMatchingWorkflowLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62f4c04076cf2ec5388c7ed48d97ed740d99f753b91b46a39a157d76af5d3144)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnMatchingWorkflowWorkflowLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMatchingWorkflowLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMatchingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> "CfnMatchingWorkflowLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__36a646188826501c408843de84a3831e589b86d9928f3ac9573807567fc8e379)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnMatchingWorkflowWorkflowLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnMatchingWorkflowLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnMatchingWorkflowWorkflowLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMatchingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
            
            cfn_matching_workflow_workflow_logs_dest_props = entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsDestProps(
                record_fields=[entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6a6400b777772f02f956b72d509737a8a1733239d54e8e77070e6037930cf0c6)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMatchingWorkflowWorkflowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMatchingWorkflowWorkflowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMatchingWorkflowWorkflowLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMatchingWorkflowWorkflowLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMatchingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
            
            cfn_matching_workflow_workflow_logs_firehose_props = entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsFirehoseProps(
                output_format=entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose.JSON,
                record_fields=[entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4a4ff1d165c954cef780d8e93bf67b90df279bccbc04edf93481dc334d15d95b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMatchingWorkflowWorkflowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMatchingWorkflowWorkflowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMatchingWorkflowWorkflowLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMatchingWorkflowWorkflowLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMatchingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
            
            cfn_matching_workflow_workflow_logs_log_group_props = entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsLogGroupProps(
                output_format=entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__20f85dc4645a7ea2f0e3ea8d43ebe4c1f2e2783588e368dbb01f78258855b6cb)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMatchingWorkflowWorkflowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMatchingWorkflowWorkflowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMatchingWorkflowWorkflowLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnMatchingWorkflowWorkflowLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnMatchingWorkflowWorkflowLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
        
        cfn_matching_workflow_workflow_logs_output_format = entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsRecordFields"
)
class CfnMatchingWorkflowWorkflowLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TYPE = "EVENT_TYPE"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    JOB_ID = "JOB_ID"
    '''
    :stability: experimental
    '''
    WORKFLOW_NAME = "WORKFLOW_NAME"
    '''
    :stability: experimental
    '''
    WORKFLOW_START_TIME = "WORKFLOW_START_TIME"
    '''
    :stability: experimental
    '''
    WORKFLOW_COMPLETE_TIME = "WORKFLOW_COMPLETE_TIME"
    '''
    :stability: experimental
    '''
    DATA_PROCESSING_PROGRESSION = "DATA_PROCESSING_PROGRESSION"
    '''
    :stability: experimental
    '''
    ERROR_MESSAGE = "ERROR_MESSAGE"
    '''
    :stability: experimental
    '''
    MATCH_RULE = "MATCH_RULE"
    '''
    :stability: experimental
    '''
    MATCH_COUNT = "MATCH_COUNT"
    '''
    :stability: experimental
    '''
    TOTAL_RECORDS_PROCESSED = "TOTAL_RECORDS_PROCESSED"
    '''
    :stability: experimental
    '''
    TOTAL_RECORDS_UNPROCESSED = "TOTAL_RECORDS_UNPROCESSED"
    '''
    :stability: experimental
    '''
    INCREMENTAL_RECORDS_PROCESSED = "INCREMENTAL_RECORDS_PROCESSED"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_entityresolution.mixins.CfnMatchingWorkflowWorkflowLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnMatchingWorkflowWorkflowLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMatchingWorkflowWorkflowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_entityresolution import mixins as entityresolution_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_matching_workflow_workflow_logs_s3_props = entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsS3Props(
                encryption_key=key_ref,
                output_format=entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsOutputFormat.S3.JSON,
                record_fields=[entityresolution_mixins.CfnMatchingWorkflowWorkflowLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1d0ca35e4d27da2c5e5e9a31ea0eca18b3470a43635b1aa7a299bb54edddc37e)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMatchingWorkflowWorkflowLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMatchingWorkflowWorkflowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMatchingWorkflowWorkflowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMatchingWorkflowWorkflowLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnIdMappingWorkflowLogsMixin",
    "CfnIdMappingWorkflowWorkflowLogs",
    "CfnIdMappingWorkflowWorkflowLogsDestProps",
    "CfnIdMappingWorkflowWorkflowLogsFirehoseProps",
    "CfnIdMappingWorkflowWorkflowLogsLogGroupProps",
    "CfnIdMappingWorkflowWorkflowLogsOutputFormat",
    "CfnIdMappingWorkflowWorkflowLogsRecordFields",
    "CfnIdMappingWorkflowWorkflowLogsS3Props",
    "CfnMatchingWorkflowLogsMixin",
    "CfnMatchingWorkflowWorkflowLogs",
    "CfnMatchingWorkflowWorkflowLogsDestProps",
    "CfnMatchingWorkflowWorkflowLogsFirehoseProps",
    "CfnMatchingWorkflowWorkflowLogsLogGroupProps",
    "CfnMatchingWorkflowWorkflowLogsOutputFormat",
    "CfnMatchingWorkflowWorkflowLogsRecordFields",
    "CfnMatchingWorkflowWorkflowLogsS3Props",
]

publication.publish()

def _typecheckingstub__f8319c797870fa92349f44077970fe8648468e2795b9542d5ca9411c4ed149e9(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d87cdbf6f8b09b8206a9ba5b3013799b7cf869f2fa739acaf9ee868341cf8c4(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e558b8ce6c2ccef5e30fb2c16ebf9979785916fa1ff01f6dcec2603fb764fba8(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a225f8f5893e951cb382273f6c8d394d2fd0b7b866670ac55f83de1d9a36861b(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnIdMappingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3efe0cff0ff4600833c55d1c985fc32b7d8dcad347cda41b6079e3485e5e6e2c(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnIdMappingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ab79b7040061e1d0b085b12c2f3432fc871a7d4338f602047fec39483a97cba(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnIdMappingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a0c221bcb56c45f3dbd005ebee24ed401a32efcfff33a39a56e20c1442bc844e(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnIdMappingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8dc31777e3b084edc0c8048024da10732698afa84d3b00b1f91a575776d73129(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnIdMappingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__07ffcca0dcdb9600a7e38e1061db388da802e7f577ec8134f940322832be618e(
    *,
    output_format: typing.Optional[CfnIdMappingWorkflowWorkflowLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnIdMappingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d2cca7aaf3e9bb14836f11bd4f08f3395dfbff7b77f8128d7af71d5d04abd1d(
    *,
    output_format: typing.Optional[CfnIdMappingWorkflowWorkflowLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnIdMappingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6d90ceb7afb2ce49fdf224eeda355af9db9042e2347e8b6343809b5e4475086(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnIdMappingWorkflowWorkflowLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnIdMappingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a2a2f8f41e56803947feeac063141099a92bd03d48742c1294fd888e5c86f3f(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__32fe9df30012d7ee5ff8ad68526b3ca56aa553a067d710540e6da25435985e55(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37f0125aaab9fb5c7fe239c86824ba8eb20303f55113b06eb498ed52aeef2cca(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__19acaba924125cb703d3c987439d4f5e14c35bbf6a97ab4ec96157ad80e0cf17(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMatchingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2257f60341f3ac0ce4bb5c2d9279eff2a4cf56696f4e3747e11be5ba9717ea2f(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMatchingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62f4c04076cf2ec5388c7ed48d97ed740d99f753b91b46a39a157d76af5d3144(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMatchingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__36a646188826501c408843de84a3831e589b86d9928f3ac9573807567fc8e379(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMatchingWorkflowWorkflowLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMatchingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a6400b777772f02f956b72d509737a8a1733239d54e8e77070e6037930cf0c6(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMatchingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a4ff1d165c954cef780d8e93bf67b90df279bccbc04edf93481dc334d15d95b(
    *,
    output_format: typing.Optional[CfnMatchingWorkflowWorkflowLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMatchingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__20f85dc4645a7ea2f0e3ea8d43ebe4c1f2e2783588e368dbb01f78258855b6cb(
    *,
    output_format: typing.Optional[CfnMatchingWorkflowWorkflowLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMatchingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d0ca35e4d27da2c5e5e9a31ea0eca18b3470a43635b1aa7a299bb54edddc37e(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMatchingWorkflowWorkflowLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMatchingWorkflowWorkflowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
