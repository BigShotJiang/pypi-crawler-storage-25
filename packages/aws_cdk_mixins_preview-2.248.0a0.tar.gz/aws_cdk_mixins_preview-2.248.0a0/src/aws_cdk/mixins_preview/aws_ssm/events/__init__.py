from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class CalendarStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ssm.events.CalendarStateChange",
):
    '''(experimental) EventBridge event pattern for aws.ssm@CalendarStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ssm import events as ssm_events
        
        calendar_state_change = ssm_events.CalendarStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="calendarStateChangePattern")
    @builtins.classmethod
    def calendar_state_change_pattern(
        cls,
        *,
        at_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        next_transition_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Calendar State Change.

        :param at_time: (experimental) atTime property. Specify an array of string values to match this event if the actual value of atTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param next_transition_time: (experimental) nextTransitionTime property. Specify an array of string values to match this event if the actual value of nextTransitionTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CalendarStateChange.CalendarStateChangeProps(
            at_time=at_time,
            event_metadata=event_metadata,
            next_transition_time=next_transition_time,
            state=state,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "calendarStateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ssm.events.CalendarStateChange.CalendarStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "at_time": "atTime",
            "event_metadata": "eventMetadata",
            "next_transition_time": "nextTransitionTime",
            "state": "state",
        },
    )
    class CalendarStateChangeProps:
        def __init__(
            self,
            *,
            at_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            next_transition_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ssm@CalendarStateChange event.

            :param at_time: (experimental) atTime property. Specify an array of string values to match this event if the actual value of atTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param next_transition_time: (experimental) nextTransitionTime property. Specify an array of string values to match this event if the actual value of nextTransitionTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ssm import events as ssm_events
                
                calendar_state_change_props = ssm_events.CalendarStateChange.CalendarStateChangeProps(
                    at_time=["atTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    next_transition_time=["nextTransitionTime"],
                    state=["state"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4b082a261b92e8cb9359fd57147c0edeeb1e403ff6b104c2c79075ee26de63c8)
                check_type(argname="argument at_time", value=at_time, expected_type=type_hints["at_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument next_transition_time", value=next_transition_time, expected_type=type_hints["next_transition_time"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if at_time is not None:
                self._values["at_time"] = at_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if next_transition_time is not None:
                self._values["next_transition_time"] = next_transition_time
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def at_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) atTime property.

            Specify an array of string values to match this event if the actual value of atTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("at_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def next_transition_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) nextTransitionTime property.

            Specify an array of string values to match this event if the actual value of nextTransitionTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("next_transition_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CalendarStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "CalendarStateChange",
]

publication.publish()

def _typecheckingstub__4b082a261b92e8cb9359fd57147c0edeeb1e403ff6b104c2c79075ee26de63c8(
    *,
    at_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    next_transition_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
