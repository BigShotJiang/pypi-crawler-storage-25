from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_ec2 as _aws_cdk_interfaces_aws_ec2_ceddda9d


class AWSAPICallViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.ec2@AWSAPICallViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
        
        a_wSAPICall_via_cloud_trail = ec2_events.AWSAPICallViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="awsAPICallViaCloudTrailPattern")
    @builtins.classmethod
    def aws_api_call_via_cloud_trail_pattern(
        cls,
        *,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS API Call via CloudTrail.

        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            aws_region=aws_region,
            error_code=error_code,
            error_message=error_message,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            request_id=request_id,
            request_parameters=request_parameters,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "awsAPICallViaCloudTrailPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "aws_region": "awsRegion",
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "request_id": "requestId",
            "request_parameters": "requestParameters",
            "response_elements": "responseElements",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSAPICallViaCloudTrailProps:
        def __init__(
            self,
            *,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ec2@AWSAPICallViaCloudTrail event.

            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                # overrides: Any
                
                a_wSAPICall_via_cloud_trail_props = ec2_events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
                    aws_region=["awsRegion"],
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    request_id=["requestId"],
                    request_parameters=ec2_events.AWSAPICallViaCloudTrail.RequestParameters(
                        availability_zone=["availabilityZone"],
                        block_device_mapping=["blockDeviceMapping"],
                        client_token=["clientToken"],
                        create_fleet_request=ec2_events.AWSAPICallViaCloudTrail.CreateFleetRequest(
                            client_token=["clientToken"],
                            existing_instances=ec2_events.AWSAPICallViaCloudTrail.ExistingInstances(
                                availability_zone=["availabilityZone"],
                                count=["count"],
                                instance_type=["instanceType"],
                                market_option=["marketOption"],
                                operating_system=["operatingSystem"],
                                tag=["tag"]
                            ),
                            launch_template_configs=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateConfigs(
                                launch_template_specification=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                                    launch_template_id=["launchTemplateId"],
                                    version=["version"]
                                ),
                                overrides=[overrides],
                                tag=["tag"]
                            ),
                            on_demand_options=ec2_events.AWSAPICallViaCloudTrail.OnDemandOptions(
                                allocation_strategy=["allocationStrategy"],
                                instance_pool_constraint_filter_disabled=["instancePoolConstraintFilterDisabled"],
                                max_instance_count=["maxInstanceCount"],
                                max_target_capacity=["maxTargetCapacity"]
                            ),
                            spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions(
                                allocation_strategy=["allocationStrategy"],
                                instance_pool_constraint_filter_disabled=["instancePoolConstraintFilterDisabled"],
                                instance_pools_to_use_count=["instancePoolsToUseCount"],
                                max_instance_count=["maxInstanceCount"],
                                max_target_capacity=["maxTargetCapacity"]
                            ),
                            tag_specification=ec2_events.AWSAPICallViaCloudTrail.TagSpecification(
                                resource_type=["resourceType"],
                                tag=ec2_events.AWSAPICallViaCloudTrail.TagType(
                                    key=["key"],
                                    tag=["tag"],
                                    value=["value"]
                                )
                            ),
                            target_capacity_specification=ec2_events.AWSAPICallViaCloudTrail.TargetCapacitySpecification(
                                default_target_capacity_type=["defaultTargetCapacityType"],
                                on_demand_target_capacity=["onDemandTargetCapacity"],
                                spot_target_capacity=["spotTargetCapacity"],
                                total_target_capacity=["totalTargetCapacity"]
                            ),
                            type=["type"]
                        ),
                        create_launch_template_request=ec2_events.AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest(
                            launch_template_data=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateData(
                                image_id=["imageId"],
                                instance_market_options=ec2_events.AWSAPICallViaCloudTrail.InstanceMarketOptions1(
                                    market_type=["marketType"],
                                    spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions2(
                                        max_price=["maxPrice"],
                                        spot_instance_type=["spotInstanceType"]
                                    )
                                ),
                                instance_type=["instanceType"],
                                network_interface=ec2_events.AWSAPICallViaCloudTrail.NetworkInterface1(
                                    device_index=["deviceIndex"],
                                    security_group_id=ec2_events.AWSAPICallViaCloudTrail.SecurityGroupId(
                                        content=["content"],
                                        tag=["tag"]
                                    ),
                                    subnet_id=["subnetId"],
                                    tag=["tag"]
                                ),
                                user_data=["userData"]
                            ),
                            launch_template_name=["launchTemplateName"]
                        ),
                        delete_launch_template_request=ec2_events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest(
                            launch_template_name=["launchTemplateName"]
                        ),
                        description=["description"],
                        disable_api_termination=["disableApiTermination"],
                        group_description=["groupDescription"],
                        group_id=["groupId"],
                        group_name=["groupName"],
                        group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet1(
                            items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet1Item(
                                group_id=["groupId"]
                            )]
                        ),
                        instance_market_options=ec2_events.AWSAPICallViaCloudTrail.InstanceMarketOptions(
                            market_type=["marketType"],
                            spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions1(
                                max_price=["maxPrice"],
                                spot_instance_type=["spotInstanceType"]
                            )
                        ),
                        instances_set=ec2_events.AWSAPICallViaCloudTrail.InstancesSet1(
                            items=[ec2_events.AWSAPICallViaCloudTrail.InstancesSet1Item(
                                image_id=["imageId"],
                                instance_id=["instanceId"],
                                max_count=["maxCount"],
                                min_count=["minCount"]
                            )]
                        ),
                        instance_type=["instanceType"],
                        ipv6_address_count=["ipv6AddressCount"],
                        launch_template=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate(
                            launch_template_id=["launchTemplateId"],
                            version=["version"]
                        ),
                        monitoring=ec2_events.AWSAPICallViaCloudTrail.Monitoring(
                            enabled=["enabled"]
                        ),
                        network_interface_id=["networkInterfaceId"],
                        network_interface_set=ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet(
                            items=[ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSetItem(
                                device_index=["deviceIndex"],
                                subnet_id=["subnetId"]
                            )]
                        ),
                        private_ip_addresses_set=["privateIpAddressesSet"],
                        subnet_id=["subnetId"],
                        tag_specification_set=ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSet(
                            items=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItem(
                                resource_type=["resourceType"],
                                tags=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                                    key=["key"],
                                    value=["value"]
                                )]
                            )]
                        ),
                        user_data=["userData"],
                        vpc_id=["vpcId"]
                    ),
                    response_elements=ec2_events.AWSAPICallViaCloudTrail.ResponseElements(
                        create_fleet_response=ec2_events.AWSAPICallViaCloudTrail.CreateFleetResponse(
                            error_set=["errorSet"],
                            fleet_id=["fleetId"],
                            fleet_instance_set=["fleetInstanceSet"],
                            request_id=["requestId"],
                            xmlns=["xmlns"]
                        ),
                        create_launch_template_response=ec2_events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse(
                            launch_template=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                                created_by=["createdBy"],
                                create_time=["createTime"],
                                default_version_number=["defaultVersionNumber"],
                                latest_version_number=["latestVersionNumber"],
                                launch_template_id=["launchTemplateId"],
                                launch_template_name=["launchTemplateName"]
                            ),
                            request_id=["requestId"],
                            xmlns=["xmlns"]
                        ),
                        delete_launch_template_response=ec2_events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse(
                            launch_template=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                                created_by=["createdBy"],
                                create_time=["createTime"],
                                default_version_number=["defaultVersionNumber"],
                                latest_version_number=["latestVersionNumber"],
                                launch_template_id=["launchTemplateId"],
                                launch_template_name=["launchTemplateName"]
                            ),
                            request_id=["requestId"],
                            xmlns=["xmlns"]
                        ),
                        group_id=["groupId"],
                        group_set=["groupSet"],
                        instances_set=ec2_events.AWSAPICallViaCloudTrail.InstancesSet(
                            items=[ec2_events.AWSAPICallViaCloudTrail.InstancesSetItem(
                                ami_launch_index=["amiLaunchIndex"],
                                architecture=["architecture"],
                                block_device_mapping=["blockDeviceMapping"],
                                capacity_reservation_specification=ec2_events.AWSAPICallViaCloudTrail.CapacityReservationSpecification(
                                    capacity_reservation_preference=["capacityReservationPreference"]
                                ),
                                client_token=["clientToken"],
                                cpu_options=ec2_events.AWSAPICallViaCloudTrail.CpuOptions(
                                    core_count=["coreCount"],
                                    threads_per_core=["threadsPerCore"]
                                ),
                                current_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                                    code=["code"],
                                    name=["name"]
                                ),
                                ebs_optimized=["ebsOptimized"],
                                enclave_options=ec2_events.AWSAPICallViaCloudTrail.EnclaveOptions(
                                    enabled=["enabled"]
                                ),
                                group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet2(
                                    items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                        group_id=["groupId"],
                                        group_name=["groupName"]
                                    )]
                                ),
                                hypervisor=["hypervisor"],
                                image_id=["imageId"],
                                instance_id=["instanceId"],
                                instance_lifecycle=["instanceLifecycle"],
                                instance_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                                    code=["code"],
                                    name=["name"]
                                ),
                                instance_type=["instanceType"],
                                launch_time=["launchTime"],
                                monitoring=ec2_events.AWSAPICallViaCloudTrail.Monitoring1(
                                    state=["state"]
                                ),
                                network_interface_set=ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1(
                                    items=[ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item(
                                        attachment=ec2_events.AWSAPICallViaCloudTrail.Attachment(
                                            attachment_id=["attachmentId"],
                                            attach_time=["attachTime"],
                                            delete_on_termination=["deleteOnTermination"],
                                            device_index=["deviceIndex"],
                                            status=["status"]
                                        ),
                                        group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet3(
                                            items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                                group_id=["groupId"],
                                                group_name=["groupName"]
                                            )]
                                        ),
                                        interface_type=["interfaceType"],
                                        ipv6_addresses_set=["ipv6AddressesSet"],
                                        mac_address=["macAddress"],
                                        network_interface_id=["networkInterfaceId"],
                                        owner_id=["ownerId"],
                                        private_ip_address=["privateIpAddress"],
                                        private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet2(
                                            item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                                                primary=["primary"],
                                                private_ip_address=["privateIpAddress"]
                                            )]
                                        ),
                                        source_dest_check=["sourceDestCheck"],
                                        status=["status"],
                                        subnet_id=["subnetId"],
                                        tag_set=["tagSet"],
                                        vpc_id=["vpcId"]
                                    )]
                                ),
                                placement=ec2_events.AWSAPICallViaCloudTrail.Placement(
                                    availability_zone=["availabilityZone"],
                                    tenancy=["tenancy"]
                                ),
                                previous_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                                    code=["code"],
                                    name=["name"]
                                ),
                                private_ip_address=["privateIpAddress"],
                                product_codes=["productCodes"],
                                root_device_name=["rootDeviceName"],
                                root_device_type=["rootDeviceType"],
                                source_dest_check=["sourceDestCheck"],
                                spot_instance_request_id=["spotInstanceRequestId"],
                                state_reason=ec2_events.AWSAPICallViaCloudTrail.StateReason(
                                    code=["code"],
                                    message=["message"]
                                ),
                                subnet_id=["subnetId"],
                                tag_set=ec2_events.AWSAPICallViaCloudTrail.TagSet(
                                    items=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                                        key=["key"],
                                        value=["value"]
                                    )]
                                ),
                                virtualization_type=["virtualizationType"],
                                vpc_id=["vpcId"]
                            )]
                        ),
                        network_interface=ec2_events.AWSAPICallViaCloudTrail.NetworkInterface(
                            availability_zone=["availabilityZone"],
                            description=["description"],
                            group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet2(
                                items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                    group_id=["groupId"],
                                    group_name=["groupName"]
                                )]
                            ),
                            interface_type=["interfaceType"],
                            ipv6_addresses_set=["ipv6AddressesSet"],
                            mac_address=["macAddress"],
                            network_interface_id=["networkInterfaceId"],
                            owner_id=["ownerId"],
                            private_ip_address=["privateIpAddress"],
                            private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1(
                                item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                                    primary=["primary"],
                                    private_ip_address=["privateIpAddress"]
                                )]
                            ),
                            requester_id=["requesterId"],
                            requester_managed=["requesterManaged"],
                            source_dest_check=["sourceDestCheck"],
                            status=["status"],
                            subnet_id=["subnetId"],
                            tag_set=["tagSet"],
                            vpc_id=["vpcId"]
                        ),
                        owner_id=["ownerId"],
                        requester_id=["requesterId"],
                        request_id=["requestId"],
                        reservation_id=["reservationId"],
                        return=["return"]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=ec2_events.AWSAPICallViaCloudTrail.UserIdentity(
                        access_key_id=["accessKeyId"],
                        account_id=["accountId"],
                        arn=["arn"],
                        invoked_by=["invokedBy"],
                        principal_id=["principalId"],
                        session_context=ec2_events.AWSAPICallViaCloudTrail.SessionContext(
                            attributes=ec2_events.AWSAPICallViaCloudTrail.Attributes(
                                creation_date=["creationDate"],
                                mfa_authenticated=["mfaAuthenticated"]
                            ),
                            session_issuer=ec2_events.AWSAPICallViaCloudTrail.SessionIssuer(
                                account_id=["accountId"],
                                arn=["arn"],
                                principal_id=["principalId"],
                                type=["type"],
                                user_name=["userName"]
                            ),
                            web_id_federation_data=["webIdFederationData"]
                        ),
                        type=["type"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(request_parameters, dict):
                request_parameters = AWSAPICallViaCloudTrail.RequestParameters(**request_parameters)
            if isinstance(response_elements, dict):
                response_elements = AWSAPICallViaCloudTrail.ResponseElements(**response_elements)
            if isinstance(user_identity, dict):
                user_identity = AWSAPICallViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1ec5a9de6d274a0402bbfec1ff340c5b59cd1db812d99a08aad503dd2419b79b)
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument request_parameters", value=request_parameters, expected_type=type_hints["request_parameters"])
                check_type(argname="argument response_elements", value=response_elements, expected_type=type_hints["response_elements"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if request_id is not None:
                self._values["request_id"] = request_id
            if request_parameters is not None:
                self._values["request_parameters"] = request_parameters
            if response_elements is not None:
                self._values["response_elements"] = response_elements
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestID property.

            Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"]:
            '''(experimental) requestParameters property.

            Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"], result)

        @builtins.property
        def response_elements(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"]:
            '''(experimental) responseElements property.

            Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response_elements")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSAPICallViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.Attachment",
        jsii_struct_bases=[],
        name_mapping={
            "attachment_id": "attachmentId",
            "attach_time": "attachTime",
            "delete_on_termination": "deleteOnTermination",
            "device_index": "deviceIndex",
            "status": "status",
        },
    )
    class Attachment:
        def __init__(
            self,
            *,
            attachment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            attach_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            delete_on_termination: typing.Optional[typing.Sequence[builtins.str]] = None,
            device_index: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Attachment.

            :param attachment_id: (experimental) attachmentId property. Specify an array of string values to match this event if the actual value of attachmentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param attach_time: (experimental) attachTime property. Specify an array of string values to match this event if the actual value of attachTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param delete_on_termination: (experimental) deleteOnTermination property. Specify an array of string values to match this event if the actual value of deleteOnTermination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param device_index: (experimental) deviceIndex property. Specify an array of string values to match this event if the actual value of deviceIndex is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                attachment = ec2_events.AWSAPICallViaCloudTrail.Attachment(
                    attachment_id=["attachmentId"],
                    attach_time=["attachTime"],
                    delete_on_termination=["deleteOnTermination"],
                    device_index=["deviceIndex"],
                    status=["status"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c007ee184f83a686d25d0de7516b15ced8fe69a12215bda8e135aa0e6fb79b40)
                check_type(argname="argument attachment_id", value=attachment_id, expected_type=type_hints["attachment_id"])
                check_type(argname="argument attach_time", value=attach_time, expected_type=type_hints["attach_time"])
                check_type(argname="argument delete_on_termination", value=delete_on_termination, expected_type=type_hints["delete_on_termination"])
                check_type(argname="argument device_index", value=device_index, expected_type=type_hints["device_index"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attachment_id is not None:
                self._values["attachment_id"] = attachment_id
            if attach_time is not None:
                self._values["attach_time"] = attach_time
            if delete_on_termination is not None:
                self._values["delete_on_termination"] = delete_on_termination
            if device_index is not None:
                self._values["device_index"] = device_index
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def attachment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) attachmentId property.

            Specify an array of string values to match this event if the actual value of attachmentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attachment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def attach_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) attachTime property.

            Specify an array of string values to match this event if the actual value of attachTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attach_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def delete_on_termination(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deleteOnTermination property.

            Specify an array of string values to match this event if the actual value of deleteOnTermination is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("delete_on_termination")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def device_index(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deviceIndex property.

            Specify an array of string values to match this event if the actual value of deviceIndex is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("device_index")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Attachment(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "creation_date": "creationDate",
            "mfa_authenticated": "mfaAuthenticated",
        },
    )
    class Attributes:
        def __init__(
            self,
            *,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Attributes.

            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mfa_authenticated: (experimental) mfaAuthenticated property. Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                attributes = ec2_events.AWSAPICallViaCloudTrail.Attributes(
                    creation_date=["creationDate"],
                    mfa_authenticated=["mfaAuthenticated"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a89147380c9c222add9c28309b5799b1a6c618c1d0e5a938f06fa86423c4f6c3)
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument mfa_authenticated", value=mfa_authenticated, expected_type=type_hints["mfa_authenticated"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if mfa_authenticated is not None:
                self._values["mfa_authenticated"] = mfa_authenticated

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mfa_authenticated(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mfaAuthenticated property.

            Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mfa_authenticated")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.CapacityReservationSpecification",
        jsii_struct_bases=[],
        name_mapping={
            "capacity_reservation_preference": "capacityReservationPreference",
        },
    )
    class CapacityReservationSpecification:
        def __init__(
            self,
            *,
            capacity_reservation_preference: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CapacityReservationSpecification.

            :param capacity_reservation_preference: (experimental) capacityReservationPreference property. Specify an array of string values to match this event if the actual value of capacityReservationPreference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                capacity_reservation_specification = ec2_events.AWSAPICallViaCloudTrail.CapacityReservationSpecification(
                    capacity_reservation_preference=["capacityReservationPreference"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__64d3e0c46700fbd1d80e27349241c7d36ae1d1f1c16d93a4cecd89fe16f7e88a)
                check_type(argname="argument capacity_reservation_preference", value=capacity_reservation_preference, expected_type=type_hints["capacity_reservation_preference"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if capacity_reservation_preference is not None:
                self._values["capacity_reservation_preference"] = capacity_reservation_preference

        @builtins.property
        def capacity_reservation_preference(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) capacityReservationPreference property.

            Specify an array of string values to match this event if the actual value of capacityReservationPreference is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("capacity_reservation_preference")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CapacityReservationSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.CpuOptions",
        jsii_struct_bases=[],
        name_mapping={"core_count": "coreCount", "threads_per_core": "threadsPerCore"},
    )
    class CpuOptions:
        def __init__(
            self,
            *,
            core_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            threads_per_core: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CpuOptions.

            :param core_count: (experimental) coreCount property. Specify an array of string values to match this event if the actual value of coreCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param threads_per_core: (experimental) threadsPerCore property. Specify an array of string values to match this event if the actual value of threadsPerCore is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                cpu_options = ec2_events.AWSAPICallViaCloudTrail.CpuOptions(
                    core_count=["coreCount"],
                    threads_per_core=["threadsPerCore"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ff5d15036c820f164153db7d3a9cfec3a418468d0b66eef7beab9c400bdd044b)
                check_type(argname="argument core_count", value=core_count, expected_type=type_hints["core_count"])
                check_type(argname="argument threads_per_core", value=threads_per_core, expected_type=type_hints["threads_per_core"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if core_count is not None:
                self._values["core_count"] = core_count
            if threads_per_core is not None:
                self._values["threads_per_core"] = threads_per_core

        @builtins.property
        def core_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) coreCount property.

            Specify an array of string values to match this event if the actual value of coreCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("core_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def threads_per_core(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) threadsPerCore property.

            Specify an array of string values to match this event if the actual value of threadsPerCore is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("threads_per_core")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CpuOptions(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.CreateFleetRequest",
        jsii_struct_bases=[],
        name_mapping={
            "client_token": "clientToken",
            "existing_instances": "existingInstances",
            "launch_template_configs": "launchTemplateConfigs",
            "on_demand_options": "onDemandOptions",
            "spot_options": "spotOptions",
            "tag_specification": "tagSpecification",
            "target_capacity_specification": "targetCapacitySpecification",
            "type": "type",
        },
    )
    class CreateFleetRequest:
        def __init__(
            self,
            *,
            client_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            existing_instances: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ExistingInstances", typing.Dict[builtins.str, typing.Any]]] = None,
            launch_template_configs: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LaunchTemplateConfigs", typing.Dict[builtins.str, typing.Any]]] = None,
            on_demand_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.OnDemandOptions", typing.Dict[builtins.str, typing.Any]]] = None,
            spot_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SpotOptions", typing.Dict[builtins.str, typing.Any]]] = None,
            tag_specification: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TagSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            target_capacity_specification: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TargetCapacitySpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CreateFleetRequest.

            :param client_token: (experimental) ClientToken property. Specify an array of string values to match this event if the actual value of ClientToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param existing_instances: (experimental) ExistingInstances property. Specify an array of string values to match this event if the actual value of ExistingInstances is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_template_configs: (experimental) LaunchTemplateConfigs property. Specify an array of string values to match this event if the actual value of LaunchTemplateConfigs is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param on_demand_options: (experimental) OnDemandOptions property. Specify an array of string values to match this event if the actual value of OnDemandOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_options: (experimental) SpotOptions property. Specify an array of string values to match this event if the actual value of SpotOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_specification: (experimental) TagSpecification property. Specify an array of string values to match this event if the actual value of TagSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_capacity_specification: (experimental) TargetCapacitySpecification property. Specify an array of string values to match this event if the actual value of TargetCapacitySpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) Type property. Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                # overrides: Any
                
                create_fleet_request = ec2_events.AWSAPICallViaCloudTrail.CreateFleetRequest(
                    client_token=["clientToken"],
                    existing_instances=ec2_events.AWSAPICallViaCloudTrail.ExistingInstances(
                        availability_zone=["availabilityZone"],
                        count=["count"],
                        instance_type=["instanceType"],
                        market_option=["marketOption"],
                        operating_system=["operatingSystem"],
                        tag=["tag"]
                    ),
                    launch_template_configs=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateConfigs(
                        launch_template_specification=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                            launch_template_id=["launchTemplateId"],
                            version=["version"]
                        ),
                        overrides=[overrides],
                        tag=["tag"]
                    ),
                    on_demand_options=ec2_events.AWSAPICallViaCloudTrail.OnDemandOptions(
                        allocation_strategy=["allocationStrategy"],
                        instance_pool_constraint_filter_disabled=["instancePoolConstraintFilterDisabled"],
                        max_instance_count=["maxInstanceCount"],
                        max_target_capacity=["maxTargetCapacity"]
                    ),
                    spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions(
                        allocation_strategy=["allocationStrategy"],
                        instance_pool_constraint_filter_disabled=["instancePoolConstraintFilterDisabled"],
                        instance_pools_to_use_count=["instancePoolsToUseCount"],
                        max_instance_count=["maxInstanceCount"],
                        max_target_capacity=["maxTargetCapacity"]
                    ),
                    tag_specification=ec2_events.AWSAPICallViaCloudTrail.TagSpecification(
                        resource_type=["resourceType"],
                        tag=ec2_events.AWSAPICallViaCloudTrail.TagType(
                            key=["key"],
                            tag=["tag"],
                            value=["value"]
                        )
                    ),
                    target_capacity_specification=ec2_events.AWSAPICallViaCloudTrail.TargetCapacitySpecification(
                        default_target_capacity_type=["defaultTargetCapacityType"],
                        on_demand_target_capacity=["onDemandTargetCapacity"],
                        spot_target_capacity=["spotTargetCapacity"],
                        total_target_capacity=["totalTargetCapacity"]
                    ),
                    type=["type"]
                )
            '''
            if isinstance(existing_instances, dict):
                existing_instances = AWSAPICallViaCloudTrail.ExistingInstances(**existing_instances)
            if isinstance(launch_template_configs, dict):
                launch_template_configs = AWSAPICallViaCloudTrail.LaunchTemplateConfigs(**launch_template_configs)
            if isinstance(on_demand_options, dict):
                on_demand_options = AWSAPICallViaCloudTrail.OnDemandOptions(**on_demand_options)
            if isinstance(spot_options, dict):
                spot_options = AWSAPICallViaCloudTrail.SpotOptions(**spot_options)
            if isinstance(tag_specification, dict):
                tag_specification = AWSAPICallViaCloudTrail.TagSpecification(**tag_specification)
            if isinstance(target_capacity_specification, dict):
                target_capacity_specification = AWSAPICallViaCloudTrail.TargetCapacitySpecification(**target_capacity_specification)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7547d125c8c0ed53fdfac255854fb563ba2ebfd3be3b654aa1e731c74c37b30c)
                check_type(argname="argument client_token", value=client_token, expected_type=type_hints["client_token"])
                check_type(argname="argument existing_instances", value=existing_instances, expected_type=type_hints["existing_instances"])
                check_type(argname="argument launch_template_configs", value=launch_template_configs, expected_type=type_hints["launch_template_configs"])
                check_type(argname="argument on_demand_options", value=on_demand_options, expected_type=type_hints["on_demand_options"])
                check_type(argname="argument spot_options", value=spot_options, expected_type=type_hints["spot_options"])
                check_type(argname="argument tag_specification", value=tag_specification, expected_type=type_hints["tag_specification"])
                check_type(argname="argument target_capacity_specification", value=target_capacity_specification, expected_type=type_hints["target_capacity_specification"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if client_token is not None:
                self._values["client_token"] = client_token
            if existing_instances is not None:
                self._values["existing_instances"] = existing_instances
            if launch_template_configs is not None:
                self._values["launch_template_configs"] = launch_template_configs
            if on_demand_options is not None:
                self._values["on_demand_options"] = on_demand_options
            if spot_options is not None:
                self._values["spot_options"] = spot_options
            if tag_specification is not None:
                self._values["tag_specification"] = tag_specification
            if target_capacity_specification is not None:
                self._values["target_capacity_specification"] = target_capacity_specification
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def client_token(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ClientToken property.

            Specify an array of string values to match this event if the actual value of ClientToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("client_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def existing_instances(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ExistingInstances"]:
            '''(experimental) ExistingInstances property.

            Specify an array of string values to match this event if the actual value of ExistingInstances is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("existing_instances")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ExistingInstances"], result)

        @builtins.property
        def launch_template_configs(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplateConfigs"]:
            '''(experimental) LaunchTemplateConfigs property.

            Specify an array of string values to match this event if the actual value of LaunchTemplateConfigs is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_configs")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplateConfigs"], result)

        @builtins.property
        def on_demand_options(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.OnDemandOptions"]:
            '''(experimental) OnDemandOptions property.

            Specify an array of string values to match this event if the actual value of OnDemandOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("on_demand_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.OnDemandOptions"], result)

        @builtins.property
        def spot_options(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SpotOptions"]:
            '''(experimental) SpotOptions property.

            Specify an array of string values to match this event if the actual value of SpotOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SpotOptions"], result)

        @builtins.property
        def tag_specification(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.TagSpecification"]:
            '''(experimental) TagSpecification property.

            Specify an array of string values to match this event if the actual value of TagSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_specification")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TagSpecification"], result)

        @builtins.property
        def target_capacity_specification(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.TargetCapacitySpecification"]:
            '''(experimental) TargetCapacitySpecification property.

            Specify an array of string values to match this event if the actual value of TargetCapacitySpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_capacity_specification")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TargetCapacitySpecification"], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Type property.

            Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CreateFleetRequest(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.CreateFleetResponse",
        jsii_struct_bases=[],
        name_mapping={
            "error_set": "errorSet",
            "fleet_id": "fleetId",
            "fleet_instance_set": "fleetInstanceSet",
            "request_id": "requestId",
            "xmlns": "xmlns",
        },
    )
    class CreateFleetResponse:
        def __init__(
            self,
            *,
            error_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            fleet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            fleet_instance_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            xmlns: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CreateFleetResponse.

            :param error_set: (experimental) errorSet property. Specify an array of string values to match this event if the actual value of errorSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fleet_id: (experimental) fleetId property. Specify an array of string values to match this event if the actual value of fleetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fleet_instance_set: (experimental) fleetInstanceSet property. Specify an array of string values to match this event if the actual value of fleetInstanceSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestId property. Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param xmlns: (experimental) xmlns property. Specify an array of string values to match this event if the actual value of xmlns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                create_fleet_response = ec2_events.AWSAPICallViaCloudTrail.CreateFleetResponse(
                    error_set=["errorSet"],
                    fleet_id=["fleetId"],
                    fleet_instance_set=["fleetInstanceSet"],
                    request_id=["requestId"],
                    xmlns=["xmlns"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ae7f744fd77b75354d4d99268b7a9bc2d2edc440f8637c452064b4f94c62a023)
                check_type(argname="argument error_set", value=error_set, expected_type=type_hints["error_set"])
                check_type(argname="argument fleet_id", value=fleet_id, expected_type=type_hints["fleet_id"])
                check_type(argname="argument fleet_instance_set", value=fleet_instance_set, expected_type=type_hints["fleet_instance_set"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument xmlns", value=xmlns, expected_type=type_hints["xmlns"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if error_set is not None:
                self._values["error_set"] = error_set
            if fleet_id is not None:
                self._values["fleet_id"] = fleet_id
            if fleet_instance_set is not None:
                self._values["fleet_instance_set"] = fleet_instance_set
            if request_id is not None:
                self._values["request_id"] = request_id
            if xmlns is not None:
                self._values["xmlns"] = xmlns

        @builtins.property
        def error_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorSet property.

            Specify an array of string values to match this event if the actual value of errorSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def fleet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fleetId property.

            Specify an array of string values to match this event if the actual value of fleetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fleet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def fleet_instance_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fleetInstanceSet property.

            Specify an array of string values to match this event if the actual value of fleetInstanceSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fleet_instance_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestId property.

            Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def xmlns(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) xmlns property.

            Specify an array of string values to match this event if the actual value of xmlns is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("xmlns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CreateFleetResponse(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest",
        jsii_struct_bases=[],
        name_mapping={
            "launch_template_data": "launchTemplateData",
            "launch_template_name": "launchTemplateName",
        },
    )
    class CreateLaunchTemplateRequest:
        def __init__(
            self,
            *,
            launch_template_data: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LaunchTemplateData", typing.Dict[builtins.str, typing.Any]]] = None,
            launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CreateLaunchTemplateRequest.

            :param launch_template_data: (experimental) LaunchTemplateData property. Specify an array of string values to match this event if the actual value of LaunchTemplateData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_template_name: (experimental) LaunchTemplateName property. Specify an array of string values to match this event if the actual value of LaunchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                create_launch_template_request = ec2_events.AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest(
                    launch_template_data=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateData(
                        image_id=["imageId"],
                        instance_market_options=ec2_events.AWSAPICallViaCloudTrail.InstanceMarketOptions1(
                            market_type=["marketType"],
                            spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions2(
                                max_price=["maxPrice"],
                                spot_instance_type=["spotInstanceType"]
                            )
                        ),
                        instance_type=["instanceType"],
                        network_interface=ec2_events.AWSAPICallViaCloudTrail.NetworkInterface1(
                            device_index=["deviceIndex"],
                            security_group_id=ec2_events.AWSAPICallViaCloudTrail.SecurityGroupId(
                                content=["content"],
                                tag=["tag"]
                            ),
                            subnet_id=["subnetId"],
                            tag=["tag"]
                        ),
                        user_data=["userData"]
                    ),
                    launch_template_name=["launchTemplateName"]
                )
            '''
            if isinstance(launch_template_data, dict):
                launch_template_data = AWSAPICallViaCloudTrail.LaunchTemplateData(**launch_template_data)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e524f29c35f69fa0d98f369c20eeee8992642e9627d524e39a6e530c31f66f23)
                check_type(argname="argument launch_template_data", value=launch_template_data, expected_type=type_hints["launch_template_data"])
                check_type(argname="argument launch_template_name", value=launch_template_name, expected_type=type_hints["launch_template_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template_data is not None:
                self._values["launch_template_data"] = launch_template_data
            if launch_template_name is not None:
                self._values["launch_template_name"] = launch_template_name

        @builtins.property
        def launch_template_data(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplateData"]:
            '''(experimental) LaunchTemplateData property.

            Specify an array of string values to match this event if the actual value of LaunchTemplateData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_data")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplateData"], result)

        @builtins.property
        def launch_template_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LaunchTemplateName property.

            Specify an array of string values to match this event if the actual value of LaunchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CreateLaunchTemplateRequest(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest",
        jsii_struct_bases=[],
        name_mapping={"launch_template_name": "launchTemplateName"},
    )
    class DeleteLaunchTemplateRequest:
        def __init__(
            self,
            *,
            launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DeleteLaunchTemplateRequest.

            :param launch_template_name: (experimental) LaunchTemplateName property. Specify an array of string values to match this event if the actual value of LaunchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                delete_launch_template_request = ec2_events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest(
                    launch_template_name=["launchTemplateName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__86d51a887d994ae007585d949c55da62f771e53cf16037e01b96cf0eb3d19449)
                check_type(argname="argument launch_template_name", value=launch_template_name, expected_type=type_hints["launch_template_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template_name is not None:
                self._values["launch_template_name"] = launch_template_name

        @builtins.property
        def launch_template_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LaunchTemplateName property.

            Specify an array of string values to match this event if the actual value of LaunchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DeleteLaunchTemplateRequest(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse",
        jsii_struct_bases=[],
        name_mapping={
            "launch_template": "launchTemplate",
            "request_id": "requestId",
            "xmlns": "xmlns",
        },
    )
    class DeleteLaunchTemplateResponse:
        def __init__(
            self,
            *,
            launch_template: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LaunchTemplate1", typing.Dict[builtins.str, typing.Any]]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            xmlns: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DeleteLaunchTemplateResponse.

            :param launch_template: (experimental) launchTemplate property. Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestId property. Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param xmlns: (experimental) xmlns property. Specify an array of string values to match this event if the actual value of xmlns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                delete_launch_template_response = ec2_events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse(
                    launch_template=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                        created_by=["createdBy"],
                        create_time=["createTime"],
                        default_version_number=["defaultVersionNumber"],
                        latest_version_number=["latestVersionNumber"],
                        launch_template_id=["launchTemplateId"],
                        launch_template_name=["launchTemplateName"]
                    ),
                    request_id=["requestId"],
                    xmlns=["xmlns"]
                )
            '''
            if isinstance(launch_template, dict):
                launch_template = AWSAPICallViaCloudTrail.LaunchTemplate1(**launch_template)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d8edb604618da02ff24f7e032e45ee78e7f6a64608e37b98b475cde540ea5863)
                check_type(argname="argument launch_template", value=launch_template, expected_type=type_hints["launch_template"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument xmlns", value=xmlns, expected_type=type_hints["xmlns"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template is not None:
                self._values["launch_template"] = launch_template
            if request_id is not None:
                self._values["request_id"] = request_id
            if xmlns is not None:
                self._values["xmlns"] = xmlns

        @builtins.property
        def launch_template(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplate1"]:
            '''(experimental) launchTemplate property.

            Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplate1"], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestId property.

            Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def xmlns(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) xmlns property.

            Specify an array of string values to match this event if the actual value of xmlns is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("xmlns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DeleteLaunchTemplateResponse(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.EnclaveOptions",
        jsii_struct_bases=[],
        name_mapping={"enabled": "enabled"},
    )
    class EnclaveOptions:
        def __init__(
            self,
            *,
            enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for EnclaveOptions.

            :param enabled: (experimental) enabled property. Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                enclave_options = ec2_events.AWSAPICallViaCloudTrail.EnclaveOptions(
                    enabled=["enabled"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9a995cf4e972c7c848295c54bc1a6dfb93cfc1557922e5477d3998cfcb9cce0f)
                check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if enabled is not None:
                self._values["enabled"] = enabled

        @builtins.property
        def enabled(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enabled property.

            Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enabled")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EnclaveOptions(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.ExistingInstances",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "count": "count",
            "instance_type": "instanceType",
            "market_option": "marketOption",
            "operating_system": "operatingSystem",
            "tag": "tag",
        },
    )
    class ExistingInstances:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            count: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            market_option: typing.Optional[typing.Sequence[builtins.str]] = None,
            operating_system: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ExistingInstances.

            :param availability_zone: (experimental) AvailabilityZone property. Specify an array of string values to match this event if the actual value of AvailabilityZone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param count: (experimental) Count property. Specify an array of string values to match this event if the actual value of Count is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) InstanceType property. Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param market_option: (experimental) MarketOption property. Specify an array of string values to match this event if the actual value of MarketOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param operating_system: (experimental) OperatingSystem property. Specify an array of string values to match this event if the actual value of OperatingSystem is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag: (experimental) tag property. Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                existing_instances = ec2_events.AWSAPICallViaCloudTrail.ExistingInstances(
                    availability_zone=["availabilityZone"],
                    count=["count"],
                    instance_type=["instanceType"],
                    market_option=["marketOption"],
                    operating_system=["operatingSystem"],
                    tag=["tag"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5effead7d091050f3adb1e8a36eee7e9609f233c368426f2216b049fda1cc425)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument count", value=count, expected_type=type_hints["count"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument market_option", value=market_option, expected_type=type_hints["market_option"])
                check_type(argname="argument operating_system", value=operating_system, expected_type=type_hints["operating_system"])
                check_type(argname="argument tag", value=tag, expected_type=type_hints["tag"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if count is not None:
                self._values["count"] = count
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if market_option is not None:
                self._values["market_option"] = market_option
            if operating_system is not None:
                self._values["operating_system"] = operating_system
            if tag is not None:
                self._values["tag"] = tag

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AvailabilityZone property.

            Specify an array of string values to match this event if the actual value of AvailabilityZone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Count property.

            Specify an array of string values to match this event if the actual value of Count is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceType property.

            Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def market_option(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MarketOption property.

            Specify an array of string values to match this event if the actual value of MarketOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("market_option")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def operating_system(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) OperatingSystem property.

            Specify an array of string values to match this event if the actual value of OperatingSystem is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("operating_system")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tag property.

            Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExistingInstances(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.GroupSet1",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class GroupSet1:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.GroupSet1Item", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupSet_1.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                group_set1 = ec2_events.AWSAPICallViaCloudTrail.GroupSet1(
                    items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet1Item(
                        group_id=["groupId"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7b18ba385b80a522eedea14032f63e0122c6cfda77a7b2c192026ed421c809f7)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.GroupSet1Item"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.GroupSet1Item"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupSet1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.GroupSet1Item",
        jsii_struct_bases=[],
        name_mapping={"group_id": "groupId"},
    )
    class GroupSet1Item:
        def __init__(
            self,
            *,
            group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupSet_1Item.

            :param group_id: (experimental) groupId property. Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                group_set1_item = ec2_events.AWSAPICallViaCloudTrail.GroupSet1Item(
                    group_id=["groupId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1d13fbdba024b942dcf9c8f1356eb056e15453cc517e6f1e0938006425b753f7)
                check_type(argname="argument group_id", value=group_id, expected_type=type_hints["group_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if group_id is not None:
                self._values["group_id"] = group_id

        @builtins.property
        def group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupId property.

            Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupSet1Item(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.GroupSet2",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class GroupSet2:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.GroupSet2Item", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupSet_2.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                group_set2 = ec2_events.AWSAPICallViaCloudTrail.GroupSet2(
                    items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                        group_id=["groupId"],
                        group_name=["groupName"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f83e8612294cccda92b6c577d0229f9759578b4b64bc0dd040e2c0ab43d7d312)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.GroupSet2Item"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.GroupSet2Item"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupSet2(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.GroupSet2Item",
        jsii_struct_bases=[],
        name_mapping={"group_id": "groupId", "group_name": "groupName"},
    )
    class GroupSet2Item:
        def __init__(
            self,
            *,
            group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupSet_2Item.

            :param group_id: (experimental) groupId property. Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_name: (experimental) groupName property. Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                group_set2_item = ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                    group_id=["groupId"],
                    group_name=["groupName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f44e2a7a16e53d5ce3c7514c771b037407941ceeb8c8e607ef068bf31b559fa7)
                check_type(argname="argument group_id", value=group_id, expected_type=type_hints["group_id"])
                check_type(argname="argument group_name", value=group_name, expected_type=type_hints["group_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if group_id is not None:
                self._values["group_id"] = group_id
            if group_name is not None:
                self._values["group_name"] = group_name

        @builtins.property
        def group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupId property.

            Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupName property.

            Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupSet2Item(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.GroupSet3",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class GroupSet3:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.GroupSet2Item", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for GroupSet_3.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                group_set3 = ec2_events.AWSAPICallViaCloudTrail.GroupSet3(
                    items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                        group_id=["groupId"],
                        group_name=["groupName"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0d9a7ce24bdcb90d11b6af8179399c5eee43494db0a6c531d8d7b092c7ce7b68)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.GroupSet2Item"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.GroupSet2Item"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GroupSet3(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.InstanceMarketOptions",
        jsii_struct_bases=[],
        name_mapping={"market_type": "marketType", "spot_options": "spotOptions"},
    )
    class InstanceMarketOptions:
        def __init__(
            self,
            *,
            market_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SpotOptions1", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for InstanceMarketOptions.

            :param market_type: (experimental) marketType property. Specify an array of string values to match this event if the actual value of marketType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_options: (experimental) spotOptions property. Specify an array of string values to match this event if the actual value of spotOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                instance_market_options = ec2_events.AWSAPICallViaCloudTrail.InstanceMarketOptions(
                    market_type=["marketType"],
                    spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions1(
                        max_price=["maxPrice"],
                        spot_instance_type=["spotInstanceType"]
                    )
                )
            '''
            if isinstance(spot_options, dict):
                spot_options = AWSAPICallViaCloudTrail.SpotOptions1(**spot_options)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0d1c678c612dc11b784b0fc8a6fd9b19889cf047afa7fa056d76afa7c861bb59)
                check_type(argname="argument market_type", value=market_type, expected_type=type_hints["market_type"])
                check_type(argname="argument spot_options", value=spot_options, expected_type=type_hints["spot_options"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if market_type is not None:
                self._values["market_type"] = market_type
            if spot_options is not None:
                self._values["spot_options"] = spot_options

        @builtins.property
        def market_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) marketType property.

            Specify an array of string values to match this event if the actual value of marketType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("market_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_options(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SpotOptions1"]:
            '''(experimental) spotOptions property.

            Specify an array of string values to match this event if the actual value of spotOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SpotOptions1"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InstanceMarketOptions(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.InstanceMarketOptions1",
        jsii_struct_bases=[],
        name_mapping={"market_type": "marketType", "spot_options": "spotOptions"},
    )
    class InstanceMarketOptions1:
        def __init__(
            self,
            *,
            market_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SpotOptions2", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for InstanceMarketOptions_1.

            :param market_type: (experimental) MarketType property. Specify an array of string values to match this event if the actual value of MarketType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_options: (experimental) SpotOptions property. Specify an array of string values to match this event if the actual value of SpotOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                instance_market_options1 = ec2_events.AWSAPICallViaCloudTrail.InstanceMarketOptions1(
                    market_type=["marketType"],
                    spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions2(
                        max_price=["maxPrice"],
                        spot_instance_type=["spotInstanceType"]
                    )
                )
            '''
            if isinstance(spot_options, dict):
                spot_options = AWSAPICallViaCloudTrail.SpotOptions2(**spot_options)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6b9cf942f7317f5f8fbb44e3b1a816ab7a05bea0971b34634a685121e83e71da)
                check_type(argname="argument market_type", value=market_type, expected_type=type_hints["market_type"])
                check_type(argname="argument spot_options", value=spot_options, expected_type=type_hints["spot_options"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if market_type is not None:
                self._values["market_type"] = market_type
            if spot_options is not None:
                self._values["spot_options"] = spot_options

        @builtins.property
        def market_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MarketType property.

            Specify an array of string values to match this event if the actual value of MarketType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("market_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_options(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SpotOptions2"]:
            '''(experimental) SpotOptions property.

            Specify an array of string values to match this event if the actual value of SpotOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SpotOptions2"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InstanceMarketOptions1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.InstanceState",
        jsii_struct_bases=[],
        name_mapping={"code": "code", "name": "name"},
    )
    class InstanceState:
        def __init__(
            self,
            *,
            code: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InstanceState.

            :param code: (experimental) code property. Specify an array of string values to match this event if the actual value of code is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                instance_state = ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                    code=["code"],
                    name=["name"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__39b18057b8463e891a8afe1714fbc05e84171e650d58a0237a976aaaa6977c7d)
                check_type(argname="argument code", value=code, expected_type=type_hints["code"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if code is not None:
                self._values["code"] = code
            if name is not None:
                self._values["name"] = name

        @builtins.property
        def code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) code property.

            Specify an array of string values to match this event if the actual value of code is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InstanceState(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.InstancesSet",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class InstancesSet:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.InstancesSetItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for InstancesSet.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                instances_set = ec2_events.AWSAPICallViaCloudTrail.InstancesSet(
                    items=[ec2_events.AWSAPICallViaCloudTrail.InstancesSetItem(
                        ami_launch_index=["amiLaunchIndex"],
                        architecture=["architecture"],
                        block_device_mapping=["blockDeviceMapping"],
                        capacity_reservation_specification=ec2_events.AWSAPICallViaCloudTrail.CapacityReservationSpecification(
                            capacity_reservation_preference=["capacityReservationPreference"]
                        ),
                        client_token=["clientToken"],
                        cpu_options=ec2_events.AWSAPICallViaCloudTrail.CpuOptions(
                            core_count=["coreCount"],
                            threads_per_core=["threadsPerCore"]
                        ),
                        current_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                            code=["code"],
                            name=["name"]
                        ),
                        ebs_optimized=["ebsOptimized"],
                        enclave_options=ec2_events.AWSAPICallViaCloudTrail.EnclaveOptions(
                            enabled=["enabled"]
                        ),
                        group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet2(
                            items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                group_id=["groupId"],
                                group_name=["groupName"]
                            )]
                        ),
                        hypervisor=["hypervisor"],
                        image_id=["imageId"],
                        instance_id=["instanceId"],
                        instance_lifecycle=["instanceLifecycle"],
                        instance_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                            code=["code"],
                            name=["name"]
                        ),
                        instance_type=["instanceType"],
                        launch_time=["launchTime"],
                        monitoring=ec2_events.AWSAPICallViaCloudTrail.Monitoring1(
                            state=["state"]
                        ),
                        network_interface_set=ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1(
                            items=[ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item(
                                attachment=ec2_events.AWSAPICallViaCloudTrail.Attachment(
                                    attachment_id=["attachmentId"],
                                    attach_time=["attachTime"],
                                    delete_on_termination=["deleteOnTermination"],
                                    device_index=["deviceIndex"],
                                    status=["status"]
                                ),
                                group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet3(
                                    items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                        group_id=["groupId"],
                                        group_name=["groupName"]
                                    )]
                                ),
                                interface_type=["interfaceType"],
                                ipv6_addresses_set=["ipv6AddressesSet"],
                                mac_address=["macAddress"],
                                network_interface_id=["networkInterfaceId"],
                                owner_id=["ownerId"],
                                private_ip_address=["privateIpAddress"],
                                private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet2(
                                    item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                                        primary=["primary"],
                                        private_ip_address=["privateIpAddress"]
                                    )]
                                ),
                                source_dest_check=["sourceDestCheck"],
                                status=["status"],
                                subnet_id=["subnetId"],
                                tag_set=["tagSet"],
                                vpc_id=["vpcId"]
                            )]
                        ),
                        placement=ec2_events.AWSAPICallViaCloudTrail.Placement(
                            availability_zone=["availabilityZone"],
                            tenancy=["tenancy"]
                        ),
                        previous_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                            code=["code"],
                            name=["name"]
                        ),
                        private_ip_address=["privateIpAddress"],
                        product_codes=["productCodes"],
                        root_device_name=["rootDeviceName"],
                        root_device_type=["rootDeviceType"],
                        source_dest_check=["sourceDestCheck"],
                        spot_instance_request_id=["spotInstanceRequestId"],
                        state_reason=ec2_events.AWSAPICallViaCloudTrail.StateReason(
                            code=["code"],
                            message=["message"]
                        ),
                        subnet_id=["subnetId"],
                        tag_set=ec2_events.AWSAPICallViaCloudTrail.TagSet(
                            items=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                                key=["key"],
                                value=["value"]
                            )]
                        ),
                        virtualization_type=["virtualizationType"],
                        vpc_id=["vpcId"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4b64d6ddffd257ee940d833e700892c4b902e22f4311a1991a15edded3a10b25)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.InstancesSetItem"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.InstancesSetItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InstancesSet(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.InstancesSet1",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class InstancesSet1:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.InstancesSet1Item", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for InstancesSet_1.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                instances_set1 = ec2_events.AWSAPICallViaCloudTrail.InstancesSet1(
                    items=[ec2_events.AWSAPICallViaCloudTrail.InstancesSet1Item(
                        image_id=["imageId"],
                        instance_id=["instanceId"],
                        max_count=["maxCount"],
                        min_count=["minCount"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fd86a4a071eeafdeb128115410bf83727d43ccdb07ddce3ce4ba483088f01133)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.InstancesSet1Item"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.InstancesSet1Item"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InstancesSet1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.InstancesSet1Item",
        jsii_struct_bases=[],
        name_mapping={
            "image_id": "imageId",
            "instance_id": "instanceId",
            "max_count": "maxCount",
            "min_count": "minCount",
        },
    )
    class InstancesSet1Item:
        def __init__(
            self,
            *,
            image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            max_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            min_count: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InstancesSet_1Item.

            :param image_id: (experimental) imageId property. Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_id: (experimental) instanceId property. Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_count: (experimental) maxCount property. Specify an array of string values to match this event if the actual value of maxCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param min_count: (experimental) minCount property. Specify an array of string values to match this event if the actual value of minCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                instances_set1_item = ec2_events.AWSAPICallViaCloudTrail.InstancesSet1Item(
                    image_id=["imageId"],
                    instance_id=["instanceId"],
                    max_count=["maxCount"],
                    min_count=["minCount"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6a73efea3a05946091384729c5fb457cea460b4bfb89589eafdf27b45eb357a2)
                check_type(argname="argument image_id", value=image_id, expected_type=type_hints["image_id"])
                check_type(argname="argument instance_id", value=instance_id, expected_type=type_hints["instance_id"])
                check_type(argname="argument max_count", value=max_count, expected_type=type_hints["max_count"])
                check_type(argname="argument min_count", value=min_count, expected_type=type_hints["min_count"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if image_id is not None:
                self._values["image_id"] = image_id
            if instance_id is not None:
                self._values["instance_id"] = instance_id
            if max_count is not None:
                self._values["max_count"] = max_count
            if min_count is not None:
                self._values["min_count"] = min_count

        @builtins.property
        def image_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageId property.

            Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceId property.

            Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def max_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) maxCount property.

            Specify an array of string values to match this event if the actual value of maxCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def min_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) minCount property.

            Specify an array of string values to match this event if the actual value of minCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("min_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InstancesSet1Item(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.InstancesSetItem",
        jsii_struct_bases=[],
        name_mapping={
            "ami_launch_index": "amiLaunchIndex",
            "architecture": "architecture",
            "block_device_mapping": "blockDeviceMapping",
            "capacity_reservation_specification": "capacityReservationSpecification",
            "client_token": "clientToken",
            "cpu_options": "cpuOptions",
            "current_state": "currentState",
            "ebs_optimized": "ebsOptimized",
            "enclave_options": "enclaveOptions",
            "group_set": "groupSet",
            "hypervisor": "hypervisor",
            "image_id": "imageId",
            "instance_id": "instanceId",
            "instance_lifecycle": "instanceLifecycle",
            "instance_state": "instanceState",
            "instance_type": "instanceType",
            "launch_time": "launchTime",
            "monitoring": "monitoring",
            "network_interface_set": "networkInterfaceSet",
            "placement": "placement",
            "previous_state": "previousState",
            "private_ip_address": "privateIpAddress",
            "product_codes": "productCodes",
            "root_device_name": "rootDeviceName",
            "root_device_type": "rootDeviceType",
            "source_dest_check": "sourceDestCheck",
            "spot_instance_request_id": "spotInstanceRequestId",
            "state_reason": "stateReason",
            "subnet_id": "subnetId",
            "tag_set": "tagSet",
            "virtualization_type": "virtualizationType",
            "vpc_id": "vpcId",
        },
    )
    class InstancesSetItem:
        def __init__(
            self,
            *,
            ami_launch_index: typing.Optional[typing.Sequence[builtins.str]] = None,
            architecture: typing.Optional[typing.Sequence[builtins.str]] = None,
            block_device_mapping: typing.Optional[typing.Sequence[builtins.str]] = None,
            capacity_reservation_specification: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.CapacityReservationSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            client_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            cpu_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.CpuOptions", typing.Dict[builtins.str, typing.Any]]] = None,
            current_state: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.InstanceState", typing.Dict[builtins.str, typing.Any]]] = None,
            ebs_optimized: typing.Optional[typing.Sequence[builtins.str]] = None,
            enclave_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.EnclaveOptions", typing.Dict[builtins.str, typing.Any]]] = None,
            group_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.GroupSet2", typing.Dict[builtins.str, typing.Any]]] = None,
            hypervisor: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_lifecycle: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_state: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.InstanceState", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            launch_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            monitoring: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Monitoring1", typing.Dict[builtins.str, typing.Any]]] = None,
            network_interface_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.NetworkInterfaceSet1", typing.Dict[builtins.str, typing.Any]]] = None,
            placement: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Placement", typing.Dict[builtins.str, typing.Any]]] = None,
            previous_state: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.InstanceState", typing.Dict[builtins.str, typing.Any]]] = None,
            private_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            product_codes: typing.Optional[typing.Sequence[builtins.str]] = None,
            root_device_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            root_device_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_dest_check: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_instance_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            state_reason: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.StateReason", typing.Dict[builtins.str, typing.Any]]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TagSet", typing.Dict[builtins.str, typing.Any]]] = None,
            virtualization_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InstancesSetItem.

            :param ami_launch_index: (experimental) amiLaunchIndex property. Specify an array of string values to match this event if the actual value of amiLaunchIndex is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param architecture: (experimental) architecture property. Specify an array of string values to match this event if the actual value of architecture is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param block_device_mapping: (experimental) blockDeviceMapping property. Specify an array of string values to match this event if the actual value of blockDeviceMapping is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param capacity_reservation_specification: (experimental) capacityReservationSpecification property. Specify an array of string values to match this event if the actual value of capacityReservationSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param client_token: (experimental) clientToken property. Specify an array of string values to match this event if the actual value of clientToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param cpu_options: (experimental) cpuOptions property. Specify an array of string values to match this event if the actual value of cpuOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_state: (experimental) currentState property. Specify an array of string values to match this event if the actual value of currentState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ebs_optimized: (experimental) ebsOptimized property. Specify an array of string values to match this event if the actual value of ebsOptimized is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param enclave_options: (experimental) enclaveOptions property. Specify an array of string values to match this event if the actual value of enclaveOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_set: (experimental) groupSet property. Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param hypervisor: (experimental) hypervisor property. Specify an array of string values to match this event if the actual value of hypervisor is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_id: (experimental) imageId property. Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_id: (experimental) instanceId property. Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Instance reference
            :param instance_lifecycle: (experimental) instanceLifecycle property. Specify an array of string values to match this event if the actual value of instanceLifecycle is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_state: (experimental) instanceState property. Specify an array of string values to match this event if the actual value of instanceState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_time: (experimental) launchTime property. Specify an array of string values to match this event if the actual value of launchTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param monitoring: (experimental) monitoring property. Specify an array of string values to match this event if the actual value of monitoring is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface_set: (experimental) networkInterfaceSet property. Specify an array of string values to match this event if the actual value of networkInterfaceSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param placement: (experimental) placement property. Specify an array of string values to match this event if the actual value of placement is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_state: (experimental) previousState property. Specify an array of string values to match this event if the actual value of previousState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param private_ip_address: (experimental) privateIpAddress property. Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param product_codes: (experimental) productCodes property. Specify an array of string values to match this event if the actual value of productCodes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param root_device_name: (experimental) rootDeviceName property. Specify an array of string values to match this event if the actual value of rootDeviceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param root_device_type: (experimental) rootDeviceType property. Specify an array of string values to match this event if the actual value of rootDeviceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_dest_check: (experimental) sourceDestCheck property. Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_instance_request_id: (experimental) spotInstanceRequestId property. Specify an array of string values to match this event if the actual value of spotInstanceRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state_reason: (experimental) stateReason property. Specify an array of string values to match this event if the actual value of stateReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnetId property. Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_set: (experimental) tagSet property. Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param virtualization_type: (experimental) virtualizationType property. Specify an array of string values to match this event if the actual value of virtualizationType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpcId property. Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                instances_set_item = ec2_events.AWSAPICallViaCloudTrail.InstancesSetItem(
                    ami_launch_index=["amiLaunchIndex"],
                    architecture=["architecture"],
                    block_device_mapping=["blockDeviceMapping"],
                    capacity_reservation_specification=ec2_events.AWSAPICallViaCloudTrail.CapacityReservationSpecification(
                        capacity_reservation_preference=["capacityReservationPreference"]
                    ),
                    client_token=["clientToken"],
                    cpu_options=ec2_events.AWSAPICallViaCloudTrail.CpuOptions(
                        core_count=["coreCount"],
                        threads_per_core=["threadsPerCore"]
                    ),
                    current_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                        code=["code"],
                        name=["name"]
                    ),
                    ebs_optimized=["ebsOptimized"],
                    enclave_options=ec2_events.AWSAPICallViaCloudTrail.EnclaveOptions(
                        enabled=["enabled"]
                    ),
                    group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet2(
                        items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                            group_id=["groupId"],
                            group_name=["groupName"]
                        )]
                    ),
                    hypervisor=["hypervisor"],
                    image_id=["imageId"],
                    instance_id=["instanceId"],
                    instance_lifecycle=["instanceLifecycle"],
                    instance_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                        code=["code"],
                        name=["name"]
                    ),
                    instance_type=["instanceType"],
                    launch_time=["launchTime"],
                    monitoring=ec2_events.AWSAPICallViaCloudTrail.Monitoring1(
                        state=["state"]
                    ),
                    network_interface_set=ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1(
                        items=[ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item(
                            attachment=ec2_events.AWSAPICallViaCloudTrail.Attachment(
                                attachment_id=["attachmentId"],
                                attach_time=["attachTime"],
                                delete_on_termination=["deleteOnTermination"],
                                device_index=["deviceIndex"],
                                status=["status"]
                            ),
                            group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet3(
                                items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                    group_id=["groupId"],
                                    group_name=["groupName"]
                                )]
                            ),
                            interface_type=["interfaceType"],
                            ipv6_addresses_set=["ipv6AddressesSet"],
                            mac_address=["macAddress"],
                            network_interface_id=["networkInterfaceId"],
                            owner_id=["ownerId"],
                            private_ip_address=["privateIpAddress"],
                            private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet2(
                                item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                                    primary=["primary"],
                                    private_ip_address=["privateIpAddress"]
                                )]
                            ),
                            source_dest_check=["sourceDestCheck"],
                            status=["status"],
                            subnet_id=["subnetId"],
                            tag_set=["tagSet"],
                            vpc_id=["vpcId"]
                        )]
                    ),
                    placement=ec2_events.AWSAPICallViaCloudTrail.Placement(
                        availability_zone=["availabilityZone"],
                        tenancy=["tenancy"]
                    ),
                    previous_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                        code=["code"],
                        name=["name"]
                    ),
                    private_ip_address=["privateIpAddress"],
                    product_codes=["productCodes"],
                    root_device_name=["rootDeviceName"],
                    root_device_type=["rootDeviceType"],
                    source_dest_check=["sourceDestCheck"],
                    spot_instance_request_id=["spotInstanceRequestId"],
                    state_reason=ec2_events.AWSAPICallViaCloudTrail.StateReason(
                        code=["code"],
                        message=["message"]
                    ),
                    subnet_id=["subnetId"],
                    tag_set=ec2_events.AWSAPICallViaCloudTrail.TagSet(
                        items=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                            key=["key"],
                            value=["value"]
                        )]
                    ),
                    virtualization_type=["virtualizationType"],
                    vpc_id=["vpcId"]
                )
            '''
            if isinstance(capacity_reservation_specification, dict):
                capacity_reservation_specification = AWSAPICallViaCloudTrail.CapacityReservationSpecification(**capacity_reservation_specification)
            if isinstance(cpu_options, dict):
                cpu_options = AWSAPICallViaCloudTrail.CpuOptions(**cpu_options)
            if isinstance(current_state, dict):
                current_state = AWSAPICallViaCloudTrail.InstanceState(**current_state)
            if isinstance(enclave_options, dict):
                enclave_options = AWSAPICallViaCloudTrail.EnclaveOptions(**enclave_options)
            if isinstance(group_set, dict):
                group_set = AWSAPICallViaCloudTrail.GroupSet2(**group_set)
            if isinstance(instance_state, dict):
                instance_state = AWSAPICallViaCloudTrail.InstanceState(**instance_state)
            if isinstance(monitoring, dict):
                monitoring = AWSAPICallViaCloudTrail.Monitoring1(**monitoring)
            if isinstance(network_interface_set, dict):
                network_interface_set = AWSAPICallViaCloudTrail.NetworkInterfaceSet1(**network_interface_set)
            if isinstance(placement, dict):
                placement = AWSAPICallViaCloudTrail.Placement(**placement)
            if isinstance(previous_state, dict):
                previous_state = AWSAPICallViaCloudTrail.InstanceState(**previous_state)
            if isinstance(state_reason, dict):
                state_reason = AWSAPICallViaCloudTrail.StateReason(**state_reason)
            if isinstance(tag_set, dict):
                tag_set = AWSAPICallViaCloudTrail.TagSet(**tag_set)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__42484b161b8712116727fc2ca55d7bbe3476cd9bbb81e1d429442542c783a7d2)
                check_type(argname="argument ami_launch_index", value=ami_launch_index, expected_type=type_hints["ami_launch_index"])
                check_type(argname="argument architecture", value=architecture, expected_type=type_hints["architecture"])
                check_type(argname="argument block_device_mapping", value=block_device_mapping, expected_type=type_hints["block_device_mapping"])
                check_type(argname="argument capacity_reservation_specification", value=capacity_reservation_specification, expected_type=type_hints["capacity_reservation_specification"])
                check_type(argname="argument client_token", value=client_token, expected_type=type_hints["client_token"])
                check_type(argname="argument cpu_options", value=cpu_options, expected_type=type_hints["cpu_options"])
                check_type(argname="argument current_state", value=current_state, expected_type=type_hints["current_state"])
                check_type(argname="argument ebs_optimized", value=ebs_optimized, expected_type=type_hints["ebs_optimized"])
                check_type(argname="argument enclave_options", value=enclave_options, expected_type=type_hints["enclave_options"])
                check_type(argname="argument group_set", value=group_set, expected_type=type_hints["group_set"])
                check_type(argname="argument hypervisor", value=hypervisor, expected_type=type_hints["hypervisor"])
                check_type(argname="argument image_id", value=image_id, expected_type=type_hints["image_id"])
                check_type(argname="argument instance_id", value=instance_id, expected_type=type_hints["instance_id"])
                check_type(argname="argument instance_lifecycle", value=instance_lifecycle, expected_type=type_hints["instance_lifecycle"])
                check_type(argname="argument instance_state", value=instance_state, expected_type=type_hints["instance_state"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument launch_time", value=launch_time, expected_type=type_hints["launch_time"])
                check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
                check_type(argname="argument network_interface_set", value=network_interface_set, expected_type=type_hints["network_interface_set"])
                check_type(argname="argument placement", value=placement, expected_type=type_hints["placement"])
                check_type(argname="argument previous_state", value=previous_state, expected_type=type_hints["previous_state"])
                check_type(argname="argument private_ip_address", value=private_ip_address, expected_type=type_hints["private_ip_address"])
                check_type(argname="argument product_codes", value=product_codes, expected_type=type_hints["product_codes"])
                check_type(argname="argument root_device_name", value=root_device_name, expected_type=type_hints["root_device_name"])
                check_type(argname="argument root_device_type", value=root_device_type, expected_type=type_hints["root_device_type"])
                check_type(argname="argument source_dest_check", value=source_dest_check, expected_type=type_hints["source_dest_check"])
                check_type(argname="argument spot_instance_request_id", value=spot_instance_request_id, expected_type=type_hints["spot_instance_request_id"])
                check_type(argname="argument state_reason", value=state_reason, expected_type=type_hints["state_reason"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
                check_type(argname="argument tag_set", value=tag_set, expected_type=type_hints["tag_set"])
                check_type(argname="argument virtualization_type", value=virtualization_type, expected_type=type_hints["virtualization_type"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if ami_launch_index is not None:
                self._values["ami_launch_index"] = ami_launch_index
            if architecture is not None:
                self._values["architecture"] = architecture
            if block_device_mapping is not None:
                self._values["block_device_mapping"] = block_device_mapping
            if capacity_reservation_specification is not None:
                self._values["capacity_reservation_specification"] = capacity_reservation_specification
            if client_token is not None:
                self._values["client_token"] = client_token
            if cpu_options is not None:
                self._values["cpu_options"] = cpu_options
            if current_state is not None:
                self._values["current_state"] = current_state
            if ebs_optimized is not None:
                self._values["ebs_optimized"] = ebs_optimized
            if enclave_options is not None:
                self._values["enclave_options"] = enclave_options
            if group_set is not None:
                self._values["group_set"] = group_set
            if hypervisor is not None:
                self._values["hypervisor"] = hypervisor
            if image_id is not None:
                self._values["image_id"] = image_id
            if instance_id is not None:
                self._values["instance_id"] = instance_id
            if instance_lifecycle is not None:
                self._values["instance_lifecycle"] = instance_lifecycle
            if instance_state is not None:
                self._values["instance_state"] = instance_state
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if launch_time is not None:
                self._values["launch_time"] = launch_time
            if monitoring is not None:
                self._values["monitoring"] = monitoring
            if network_interface_set is not None:
                self._values["network_interface_set"] = network_interface_set
            if placement is not None:
                self._values["placement"] = placement
            if previous_state is not None:
                self._values["previous_state"] = previous_state
            if private_ip_address is not None:
                self._values["private_ip_address"] = private_ip_address
            if product_codes is not None:
                self._values["product_codes"] = product_codes
            if root_device_name is not None:
                self._values["root_device_name"] = root_device_name
            if root_device_type is not None:
                self._values["root_device_type"] = root_device_type
            if source_dest_check is not None:
                self._values["source_dest_check"] = source_dest_check
            if spot_instance_request_id is not None:
                self._values["spot_instance_request_id"] = spot_instance_request_id
            if state_reason is not None:
                self._values["state_reason"] = state_reason
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id
            if tag_set is not None:
                self._values["tag_set"] = tag_set
            if virtualization_type is not None:
                self._values["virtualization_type"] = virtualization_type
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def ami_launch_index(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) amiLaunchIndex property.

            Specify an array of string values to match this event if the actual value of amiLaunchIndex is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ami_launch_index")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def architecture(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) architecture property.

            Specify an array of string values to match this event if the actual value of architecture is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("architecture")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def block_device_mapping(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) blockDeviceMapping property.

            Specify an array of string values to match this event if the actual value of blockDeviceMapping is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("block_device_mapping")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def capacity_reservation_specification(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.CapacityReservationSpecification"]:
            '''(experimental) capacityReservationSpecification property.

            Specify an array of string values to match this event if the actual value of capacityReservationSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("capacity_reservation_specification")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.CapacityReservationSpecification"], result)

        @builtins.property
        def client_token(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clientToken property.

            Specify an array of string values to match this event if the actual value of clientToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("client_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cpu_options(self) -> typing.Optional["AWSAPICallViaCloudTrail.CpuOptions"]:
            '''(experimental) cpuOptions property.

            Specify an array of string values to match this event if the actual value of cpuOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cpu_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.CpuOptions"], result)

        @builtins.property
        def current_state(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.InstanceState"]:
            '''(experimental) currentState property.

            Specify an array of string values to match this event if the actual value of currentState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_state")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.InstanceState"], result)

        @builtins.property
        def ebs_optimized(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ebsOptimized property.

            Specify an array of string values to match this event if the actual value of ebsOptimized is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ebs_optimized")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def enclave_options(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.EnclaveOptions"]:
            '''(experimental) enclaveOptions property.

            Specify an array of string values to match this event if the actual value of enclaveOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enclave_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.EnclaveOptions"], result)

        @builtins.property
        def group_set(self) -> typing.Optional["AWSAPICallViaCloudTrail.GroupSet2"]:
            '''(experimental) groupSet property.

            Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.GroupSet2"], result)

        @builtins.property
        def hypervisor(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) hypervisor property.

            Specify an array of string values to match this event if the actual value of hypervisor is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hypervisor")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageId property.

            Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceId property.

            Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Instance reference

            :stability: experimental
            '''
            result = self._values.get("instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_lifecycle(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceLifecycle property.

            Specify an array of string values to match this event if the actual value of instanceLifecycle is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_lifecycle")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_state(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.InstanceState"]:
            '''(experimental) instanceState property.

            Specify an array of string values to match this event if the actual value of instanceState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_state")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.InstanceState"], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceType property.

            Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def launch_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) launchTime property.

            Specify an array of string values to match this event if the actual value of launchTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def monitoring(self) -> typing.Optional["AWSAPICallViaCloudTrail.Monitoring1"]:
            '''(experimental) monitoring property.

            Specify an array of string values to match this event if the actual value of monitoring is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("monitoring")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Monitoring1"], result)

        @builtins.property
        def network_interface_set(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.NetworkInterfaceSet1"]:
            '''(experimental) networkInterfaceSet property.

            Specify an array of string values to match this event if the actual value of networkInterfaceSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.NetworkInterfaceSet1"], result)

        @builtins.property
        def placement(self) -> typing.Optional["AWSAPICallViaCloudTrail.Placement"]:
            '''(experimental) placement property.

            Specify an array of string values to match this event if the actual value of placement is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("placement")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Placement"], result)

        @builtins.property
        def previous_state(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.InstanceState"]:
            '''(experimental) previousState property.

            Specify an array of string values to match this event if the actual value of previousState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_state")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.InstanceState"], result)

        @builtins.property
        def private_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privateIpAddress property.

            Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("private_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def product_codes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) productCodes property.

            Specify an array of string values to match this event if the actual value of productCodes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("product_codes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def root_device_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) rootDeviceName property.

            Specify an array of string values to match this event if the actual value of rootDeviceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("root_device_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def root_device_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) rootDeviceType property.

            Specify an array of string values to match this event if the actual value of rootDeviceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("root_device_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_dest_check(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceDestCheck property.

            Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_dest_check")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_instance_request_id(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) spotInstanceRequestId property.

            Specify an array of string values to match this event if the actual value of spotInstanceRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_instance_request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state_reason(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.StateReason"]:
            '''(experimental) stateReason property.

            Specify an array of string values to match this event if the actual value of stateReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state_reason")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.StateReason"], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnetId property.

            Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_set(self) -> typing.Optional["AWSAPICallViaCloudTrail.TagSet"]:
            '''(experimental) tagSet property.

            Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TagSet"], result)

        @builtins.property
        def virtualization_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) virtualizationType property.

            Specify an array of string values to match this event if the actual value of virtualizationType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("virtualization_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpcId property.

            Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InstancesSetItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.LaunchTemplate",
        jsii_struct_bases=[],
        name_mapping={"launch_template_id": "launchTemplateId", "version": "version"},
    )
    class LaunchTemplate:
        def __init__(
            self,
            *,
            launch_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for LaunchTemplate.

            :param launch_template_id: (experimental) launchTemplateId property. Specify an array of string values to match this event if the actual value of launchTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                launch_template = ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate(
                    launch_template_id=["launchTemplateId"],
                    version=["version"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f6b02dd57a17ed92ce3c563a56461e97038d541402054fced14d393c8a5262bd)
                check_type(argname="argument launch_template_id", value=launch_template_id, expected_type=type_hints["launch_template_id"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template_id is not None:
                self._values["launch_template_id"] = launch_template_id
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def launch_template_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) launchTemplateId property.

            Specify an array of string values to match this event if the actual value of launchTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LaunchTemplate(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.LaunchTemplate1",
        jsii_struct_bases=[],
        name_mapping={
            "created_by": "createdBy",
            "create_time": "createTime",
            "default_version_number": "defaultVersionNumber",
            "latest_version_number": "latestVersionNumber",
            "launch_template_id": "launchTemplateId",
            "launch_template_name": "launchTemplateName",
        },
    )
    class LaunchTemplate1:
        def __init__(
            self,
            *,
            created_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            create_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            default_version_number: typing.Optional[typing.Sequence[builtins.str]] = None,
            latest_version_number: typing.Optional[typing.Sequence[builtins.str]] = None,
            launch_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for LaunchTemplate_1.

            :param created_by: (experimental) createdBy property. Specify an array of string values to match this event if the actual value of createdBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param create_time: (experimental) createTime property. Specify an array of string values to match this event if the actual value of createTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param default_version_number: (experimental) defaultVersionNumber property. Specify an array of string values to match this event if the actual value of defaultVersionNumber is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param latest_version_number: (experimental) latestVersionNumber property. Specify an array of string values to match this event if the actual value of latestVersionNumber is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_template_id: (experimental) launchTemplateId property. Specify an array of string values to match this event if the actual value of launchTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_template_name: (experimental) launchTemplateName property. Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                launch_template1 = ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                    created_by=["createdBy"],
                    create_time=["createTime"],
                    default_version_number=["defaultVersionNumber"],
                    latest_version_number=["latestVersionNumber"],
                    launch_template_id=["launchTemplateId"],
                    launch_template_name=["launchTemplateName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ae23195861dfab6957e3969521bb1de527ba282c1ef91288e68c688c40ba9e02)
                check_type(argname="argument created_by", value=created_by, expected_type=type_hints["created_by"])
                check_type(argname="argument create_time", value=create_time, expected_type=type_hints["create_time"])
                check_type(argname="argument default_version_number", value=default_version_number, expected_type=type_hints["default_version_number"])
                check_type(argname="argument latest_version_number", value=latest_version_number, expected_type=type_hints["latest_version_number"])
                check_type(argname="argument launch_template_id", value=launch_template_id, expected_type=type_hints["launch_template_id"])
                check_type(argname="argument launch_template_name", value=launch_template_name, expected_type=type_hints["launch_template_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if created_by is not None:
                self._values["created_by"] = created_by
            if create_time is not None:
                self._values["create_time"] = create_time
            if default_version_number is not None:
                self._values["default_version_number"] = default_version_number
            if latest_version_number is not None:
                self._values["latest_version_number"] = latest_version_number
            if launch_template_id is not None:
                self._values["launch_template_id"] = launch_template_id
            if launch_template_name is not None:
                self._values["launch_template_name"] = launch_template_name

        @builtins.property
        def created_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) createdBy property.

            Specify an array of string values to match this event if the actual value of createdBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("created_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def create_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) createTime property.

            Specify an array of string values to match this event if the actual value of createTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("create_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def default_version_number(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) defaultVersionNumber property.

            Specify an array of string values to match this event if the actual value of defaultVersionNumber is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("default_version_number")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def latest_version_number(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) latestVersionNumber property.

            Specify an array of string values to match this event if the actual value of latestVersionNumber is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("latest_version_number")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def launch_template_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) launchTemplateId property.

            Specify an array of string values to match this event if the actual value of launchTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def launch_template_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) launchTemplateName property.

            Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LaunchTemplate1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.LaunchTemplateConfigs",
        jsii_struct_bases=[],
        name_mapping={
            "launch_template_specification": "launchTemplateSpecification",
            "overrides": "overrides",
            "tag": "tag",
        },
    )
    class LaunchTemplateConfigs:
        def __init__(
            self,
            *,
            launch_template_specification: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LaunchTemplateSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            overrides: typing.Optional[typing.Sequence[typing.Any]] = None,
            tag: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for LaunchTemplateConfigs.

            :param launch_template_specification: (experimental) LaunchTemplateSpecification property. Specify an array of string values to match this event if the actual value of LaunchTemplateSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param overrides: (experimental) Overrides property. Specify an array of string values to match this event if the actual value of Overrides is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag: (experimental) tag property. Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                # overrides: Any
                
                launch_template_configs = ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateConfigs(
                    launch_template_specification=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                        launch_template_id=["launchTemplateId"],
                        version=["version"]
                    ),
                    overrides=[overrides],
                    tag=["tag"]
                )
            '''
            if isinstance(launch_template_specification, dict):
                launch_template_specification = AWSAPICallViaCloudTrail.LaunchTemplateSpecification(**launch_template_specification)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2de44ddd198bf3077e7a0cb61ef48e20d594819fc8ec2eacb5b6d7f2fce4c70d)
                check_type(argname="argument launch_template_specification", value=launch_template_specification, expected_type=type_hints["launch_template_specification"])
                check_type(argname="argument overrides", value=overrides, expected_type=type_hints["overrides"])
                check_type(argname="argument tag", value=tag, expected_type=type_hints["tag"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template_specification is not None:
                self._values["launch_template_specification"] = launch_template_specification
            if overrides is not None:
                self._values["overrides"] = overrides
            if tag is not None:
                self._values["tag"] = tag

        @builtins.property
        def launch_template_specification(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplateSpecification"]:
            '''(experimental) LaunchTemplateSpecification property.

            Specify an array of string values to match this event if the actual value of LaunchTemplateSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_specification")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplateSpecification"], result)

        @builtins.property
        def overrides(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) Overrides property.

            Specify an array of string values to match this event if the actual value of Overrides is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("overrides")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def tag(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tag property.

            Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LaunchTemplateConfigs(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.LaunchTemplateData",
        jsii_struct_bases=[],
        name_mapping={
            "image_id": "imageId",
            "instance_market_options": "instanceMarketOptions",
            "instance_type": "instanceType",
            "network_interface": "networkInterface",
            "user_data": "userData",
        },
    )
    class LaunchTemplateData:
        def __init__(
            self,
            *,
            image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_market_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.InstanceMarketOptions1", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            network_interface: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.NetworkInterface1", typing.Dict[builtins.str, typing.Any]]] = None,
            user_data: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for LaunchTemplateData.

            :param image_id: (experimental) ImageId property. Specify an array of string values to match this event if the actual value of ImageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_market_options: (experimental) InstanceMarketOptions property. Specify an array of string values to match this event if the actual value of InstanceMarketOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) InstanceType property. Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface: (experimental) NetworkInterface property. Specify an array of string values to match this event if the actual value of NetworkInterface is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_data: (experimental) UserData property. Specify an array of string values to match this event if the actual value of UserData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                launch_template_data = ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateData(
                    image_id=["imageId"],
                    instance_market_options=ec2_events.AWSAPICallViaCloudTrail.InstanceMarketOptions1(
                        market_type=["marketType"],
                        spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions2(
                            max_price=["maxPrice"],
                            spot_instance_type=["spotInstanceType"]
                        )
                    ),
                    instance_type=["instanceType"],
                    network_interface=ec2_events.AWSAPICallViaCloudTrail.NetworkInterface1(
                        device_index=["deviceIndex"],
                        security_group_id=ec2_events.AWSAPICallViaCloudTrail.SecurityGroupId(
                            content=["content"],
                            tag=["tag"]
                        ),
                        subnet_id=["subnetId"],
                        tag=["tag"]
                    ),
                    user_data=["userData"]
                )
            '''
            if isinstance(instance_market_options, dict):
                instance_market_options = AWSAPICallViaCloudTrail.InstanceMarketOptions1(**instance_market_options)
            if isinstance(network_interface, dict):
                network_interface = AWSAPICallViaCloudTrail.NetworkInterface1(**network_interface)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6137738b68cd890072733e093d37dc518975772fc5d4fb108fd1c9b67dd3387b)
                check_type(argname="argument image_id", value=image_id, expected_type=type_hints["image_id"])
                check_type(argname="argument instance_market_options", value=instance_market_options, expected_type=type_hints["instance_market_options"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument network_interface", value=network_interface, expected_type=type_hints["network_interface"])
                check_type(argname="argument user_data", value=user_data, expected_type=type_hints["user_data"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if image_id is not None:
                self._values["image_id"] = image_id
            if instance_market_options is not None:
                self._values["instance_market_options"] = instance_market_options
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if network_interface is not None:
                self._values["network_interface"] = network_interface
            if user_data is not None:
                self._values["user_data"] = user_data

        @builtins.property
        def image_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ImageId property.

            Specify an array of string values to match this event if the actual value of ImageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_market_options(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.InstanceMarketOptions1"]:
            '''(experimental) InstanceMarketOptions property.

            Specify an array of string values to match this event if the actual value of InstanceMarketOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_market_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.InstanceMarketOptions1"], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceType property.

            Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def network_interface(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.NetworkInterface1"]:
            '''(experimental) NetworkInterface property.

            Specify an array of string values to match this event if the actual value of NetworkInterface is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.NetworkInterface1"], result)

        @builtins.property
        def user_data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) UserData property.

            Specify an array of string values to match this event if the actual value of UserData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LaunchTemplateData(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification",
        jsii_struct_bases=[],
        name_mapping={"launch_template_id": "launchTemplateId", "version": "version"},
    )
    class LaunchTemplateSpecification:
        def __init__(
            self,
            *,
            launch_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for LaunchTemplateSpecification.

            :param launch_template_id: (experimental) LaunchTemplateId property. Specify an array of string values to match this event if the actual value of LaunchTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) Version property. Specify an array of string values to match this event if the actual value of Version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                launch_template_specification = ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                    launch_template_id=["launchTemplateId"],
                    version=["version"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__867de257c80f2e55bf5c584b2da21bbc1c15be800b22313c781b2fdc8bad6dce)
                check_type(argname="argument launch_template_id", value=launch_template_id, expected_type=type_hints["launch_template_id"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template_id is not None:
                self._values["launch_template_id"] = launch_template_id
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def launch_template_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LaunchTemplateId property.

            Specify an array of string values to match this event if the actual value of LaunchTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Version property.

            Specify an array of string values to match this event if the actual value of Version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LaunchTemplateSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.Monitoring",
        jsii_struct_bases=[],
        name_mapping={"enabled": "enabled"},
    )
    class Monitoring:
        def __init__(
            self,
            *,
            enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Monitoring.

            :param enabled: (experimental) enabled property. Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                monitoring = ec2_events.AWSAPICallViaCloudTrail.Monitoring(
                    enabled=["enabled"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ff36a2ff2d5ab6a912b5bf30be63bf6c8c779675b12a66899e2032eea5339387)
                check_type(argname="argument enabled", value=enabled, expected_type=type_hints["enabled"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if enabled is not None:
                self._values["enabled"] = enabled

        @builtins.property
        def enabled(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enabled property.

            Specify an array of string values to match this event if the actual value of enabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enabled")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Monitoring(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.Monitoring1",
        jsii_struct_bases=[],
        name_mapping={"state": "state"},
    )
    class Monitoring1:
        def __init__(
            self,
            *,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Monitoring_1.

            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                monitoring1 = ec2_events.AWSAPICallViaCloudTrail.Monitoring1(
                    state=["state"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e69797ed5d0717b16a33ccf546a0778e5135c18aff3d60c8240ae63602ec9000)
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Monitoring1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.NetworkInterface",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "description": "description",
            "group_set": "groupSet",
            "interface_type": "interfaceType",
            "ipv6_addresses_set": "ipv6AddressesSet",
            "mac_address": "macAddress",
            "network_interface_id": "networkInterfaceId",
            "owner_id": "ownerId",
            "private_ip_address": "privateIpAddress",
            "private_ip_addresses_set": "privateIpAddressesSet",
            "requester_id": "requesterId",
            "requester_managed": "requesterManaged",
            "source_dest_check": "sourceDestCheck",
            "status": "status",
            "subnet_id": "subnetId",
            "tag_set": "tagSet",
            "vpc_id": "vpcId",
        },
    )
    class NetworkInterface:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.GroupSet2", typing.Dict[builtins.str, typing.Any]]] = None,
            interface_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            ipv6_addresses_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            mac_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            network_interface_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            owner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            private_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            private_ip_addresses_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1", typing.Dict[builtins.str, typing.Any]]] = None,
            requester_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            requester_managed: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_dest_check: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for NetworkInterface.

            :param availability_zone: (experimental) availabilityZone property. Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_set: (experimental) groupSet property. Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param interface_type: (experimental) interfaceType property. Specify an array of string values to match this event if the actual value of interfaceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ipv6_addresses_set: (experimental) ipv6AddressesSet property. Specify an array of string values to match this event if the actual value of ipv6AddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mac_address: (experimental) macAddress property. Specify an array of string values to match this event if the actual value of macAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface_id: (experimental) networkInterfaceId property. Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param owner_id: (experimental) ownerId property. Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param private_ip_address: (experimental) privateIpAddress property. Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param private_ip_addresses_set: (experimental) privateIpAddressesSet property. Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param requester_id: (experimental) requesterId property. Specify an array of string values to match this event if the actual value of requesterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param requester_managed: (experimental) requesterManaged property. Specify an array of string values to match this event if the actual value of requesterManaged is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_dest_check: (experimental) sourceDestCheck property. Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnetId property. Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_set: (experimental) tagSet property. Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpcId property. Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                network_interface = ec2_events.AWSAPICallViaCloudTrail.NetworkInterface(
                    availability_zone=["availabilityZone"],
                    description=["description"],
                    group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet2(
                        items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                            group_id=["groupId"],
                            group_name=["groupName"]
                        )]
                    ),
                    interface_type=["interfaceType"],
                    ipv6_addresses_set=["ipv6AddressesSet"],
                    mac_address=["macAddress"],
                    network_interface_id=["networkInterfaceId"],
                    owner_id=["ownerId"],
                    private_ip_address=["privateIpAddress"],
                    private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1(
                        item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                            primary=["primary"],
                            private_ip_address=["privateIpAddress"]
                        )]
                    ),
                    requester_id=["requesterId"],
                    requester_managed=["requesterManaged"],
                    source_dest_check=["sourceDestCheck"],
                    status=["status"],
                    subnet_id=["subnetId"],
                    tag_set=["tagSet"],
                    vpc_id=["vpcId"]
                )
            '''
            if isinstance(group_set, dict):
                group_set = AWSAPICallViaCloudTrail.GroupSet2(**group_set)
            if isinstance(private_ip_addresses_set, dict):
                private_ip_addresses_set = AWSAPICallViaCloudTrail.PrivateIpAddressesSet1(**private_ip_addresses_set)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__227a4ab6271e6466be8a2376963953f64ac92718da8e1414f6a1883d4f459556)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument group_set", value=group_set, expected_type=type_hints["group_set"])
                check_type(argname="argument interface_type", value=interface_type, expected_type=type_hints["interface_type"])
                check_type(argname="argument ipv6_addresses_set", value=ipv6_addresses_set, expected_type=type_hints["ipv6_addresses_set"])
                check_type(argname="argument mac_address", value=mac_address, expected_type=type_hints["mac_address"])
                check_type(argname="argument network_interface_id", value=network_interface_id, expected_type=type_hints["network_interface_id"])
                check_type(argname="argument owner_id", value=owner_id, expected_type=type_hints["owner_id"])
                check_type(argname="argument private_ip_address", value=private_ip_address, expected_type=type_hints["private_ip_address"])
                check_type(argname="argument private_ip_addresses_set", value=private_ip_addresses_set, expected_type=type_hints["private_ip_addresses_set"])
                check_type(argname="argument requester_id", value=requester_id, expected_type=type_hints["requester_id"])
                check_type(argname="argument requester_managed", value=requester_managed, expected_type=type_hints["requester_managed"])
                check_type(argname="argument source_dest_check", value=source_dest_check, expected_type=type_hints["source_dest_check"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
                check_type(argname="argument tag_set", value=tag_set, expected_type=type_hints["tag_set"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if description is not None:
                self._values["description"] = description
            if group_set is not None:
                self._values["group_set"] = group_set
            if interface_type is not None:
                self._values["interface_type"] = interface_type
            if ipv6_addresses_set is not None:
                self._values["ipv6_addresses_set"] = ipv6_addresses_set
            if mac_address is not None:
                self._values["mac_address"] = mac_address
            if network_interface_id is not None:
                self._values["network_interface_id"] = network_interface_id
            if owner_id is not None:
                self._values["owner_id"] = owner_id
            if private_ip_address is not None:
                self._values["private_ip_address"] = private_ip_address
            if private_ip_addresses_set is not None:
                self._values["private_ip_addresses_set"] = private_ip_addresses_set
            if requester_id is not None:
                self._values["requester_id"] = requester_id
            if requester_managed is not None:
                self._values["requester_managed"] = requester_managed
            if source_dest_check is not None:
                self._values["source_dest_check"] = source_dest_check
            if status is not None:
                self._values["status"] = status
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id
            if tag_set is not None:
                self._values["tag_set"] = tag_set
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) availabilityZone property.

            Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_set(self) -> typing.Optional["AWSAPICallViaCloudTrail.GroupSet2"]:
            '''(experimental) groupSet property.

            Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.GroupSet2"], result)

        @builtins.property
        def interface_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) interfaceType property.

            Specify an array of string values to match this event if the actual value of interfaceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("interface_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ipv6_addresses_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ipv6AddressesSet property.

            Specify an array of string values to match this event if the actual value of ipv6AddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ipv6_addresses_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mac_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) macAddress property.

            Specify an array of string values to match this event if the actual value of macAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mac_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def network_interface_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) networkInterfaceId property.

            Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def owner_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ownerId property.

            Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("owner_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def private_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privateIpAddress property.

            Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("private_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def private_ip_addresses_set(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1"]:
            '''(experimental) privateIpAddressesSet property.

            Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("private_ip_addresses_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1"], result)

        @builtins.property
        def requester_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requesterId property.

            Specify an array of string values to match this event if the actual value of requesterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("requester_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def requester_managed(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requesterManaged property.

            Specify an array of string values to match this event if the actual value of requesterManaged is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("requester_managed")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_dest_check(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceDestCheck property.

            Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_dest_check")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnetId property.

            Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagSet property.

            Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpcId property.

            Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterface(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.NetworkInterface1",
        jsii_struct_bases=[],
        name_mapping={
            "device_index": "deviceIndex",
            "security_group_id": "securityGroupId",
            "subnet_id": "subnetId",
            "tag": "tag",
        },
    )
    class NetworkInterface1:
        def __init__(
            self,
            *,
            device_index: typing.Optional[typing.Sequence[builtins.str]] = None,
            security_group_id: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SecurityGroupId", typing.Dict[builtins.str, typing.Any]]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for NetworkInterface_1.

            :param device_index: (experimental) DeviceIndex property. Specify an array of string values to match this event if the actual value of DeviceIndex is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param security_group_id: (experimental) SecurityGroupId property. Specify an array of string values to match this event if the actual value of SecurityGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) SubnetId property. Specify an array of string values to match this event if the actual value of SubnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag: (experimental) tag property. Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                network_interface1 = ec2_events.AWSAPICallViaCloudTrail.NetworkInterface1(
                    device_index=["deviceIndex"],
                    security_group_id=ec2_events.AWSAPICallViaCloudTrail.SecurityGroupId(
                        content=["content"],
                        tag=["tag"]
                    ),
                    subnet_id=["subnetId"],
                    tag=["tag"]
                )
            '''
            if isinstance(security_group_id, dict):
                security_group_id = AWSAPICallViaCloudTrail.SecurityGroupId(**security_group_id)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7f701145fa972f02164ece715c83ae36f13c563dbb1c2a23db6abb2468d69263)
                check_type(argname="argument device_index", value=device_index, expected_type=type_hints["device_index"])
                check_type(argname="argument security_group_id", value=security_group_id, expected_type=type_hints["security_group_id"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
                check_type(argname="argument tag", value=tag, expected_type=type_hints["tag"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if device_index is not None:
                self._values["device_index"] = device_index
            if security_group_id is not None:
                self._values["security_group_id"] = security_group_id
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id
            if tag is not None:
                self._values["tag"] = tag

        @builtins.property
        def device_index(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) DeviceIndex property.

            Specify an array of string values to match this event if the actual value of DeviceIndex is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("device_index")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def security_group_id(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SecurityGroupId"]:
            '''(experimental) SecurityGroupId property.

            Specify an array of string values to match this event if the actual value of SecurityGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("security_group_id")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SecurityGroupId"], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SubnetId property.

            Specify an array of string values to match this event if the actual value of SubnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tag property.

            Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterface1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.NetworkInterfaceSet",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class NetworkInterfaceSet:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.NetworkInterfaceSetItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for NetworkInterfaceSet.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                network_interface_set = ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet(
                    items=[ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSetItem(
                        device_index=["deviceIndex"],
                        subnet_id=["subnetId"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dfe5d045bebb4a815d86bb693eb0ea5a0d005f6961a06b13ab6cfa2a3617b9c1)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.NetworkInterfaceSetItem"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.NetworkInterfaceSetItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterfaceSet(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class NetworkInterfaceSet1:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for NetworkInterfaceSet_1.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                network_interface_set1 = ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1(
                    items=[ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item(
                        attachment=ec2_events.AWSAPICallViaCloudTrail.Attachment(
                            attachment_id=["attachmentId"],
                            attach_time=["attachTime"],
                            delete_on_termination=["deleteOnTermination"],
                            device_index=["deviceIndex"],
                            status=["status"]
                        ),
                        group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet3(
                            items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                group_id=["groupId"],
                                group_name=["groupName"]
                            )]
                        ),
                        interface_type=["interfaceType"],
                        ipv6_addresses_set=["ipv6AddressesSet"],
                        mac_address=["macAddress"],
                        network_interface_id=["networkInterfaceId"],
                        owner_id=["ownerId"],
                        private_ip_address=["privateIpAddress"],
                        private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet2(
                            item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                                primary=["primary"],
                                private_ip_address=["privateIpAddress"]
                            )]
                        ),
                        source_dest_check=["sourceDestCheck"],
                        status=["status"],
                        subnet_id=["subnetId"],
                        tag_set=["tagSet"],
                        vpc_id=["vpcId"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__935a809d9aae02a1902f58cca94d7e0b6accf53571a11dd4dac1aa2e424746ce)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterfaceSet1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item",
        jsii_struct_bases=[],
        name_mapping={
            "attachment": "attachment",
            "group_set": "groupSet",
            "interface_type": "interfaceType",
            "ipv6_addresses_set": "ipv6AddressesSet",
            "mac_address": "macAddress",
            "network_interface_id": "networkInterfaceId",
            "owner_id": "ownerId",
            "private_ip_address": "privateIpAddress",
            "private_ip_addresses_set": "privateIpAddressesSet",
            "source_dest_check": "sourceDestCheck",
            "status": "status",
            "subnet_id": "subnetId",
            "tag_set": "tagSet",
            "vpc_id": "vpcId",
        },
    )
    class NetworkInterfaceSet1Item:
        def __init__(
            self,
            *,
            attachment: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Attachment", typing.Dict[builtins.str, typing.Any]]] = None,
            group_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.GroupSet3", typing.Dict[builtins.str, typing.Any]]] = None,
            interface_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            ipv6_addresses_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            mac_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            network_interface_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            owner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            private_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            private_ip_addresses_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.PrivateIpAddressesSet2", typing.Dict[builtins.str, typing.Any]]] = None,
            source_dest_check: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for NetworkInterfaceSet_1Item.

            :param attachment: (experimental) attachment property. Specify an array of string values to match this event if the actual value of attachment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_set: (experimental) groupSet property. Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param interface_type: (experimental) interfaceType property. Specify an array of string values to match this event if the actual value of interfaceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ipv6_addresses_set: (experimental) ipv6AddressesSet property. Specify an array of string values to match this event if the actual value of ipv6AddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mac_address: (experimental) macAddress property. Specify an array of string values to match this event if the actual value of macAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface_id: (experimental) networkInterfaceId property. Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param owner_id: (experimental) ownerId property. Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param private_ip_address: (experimental) privateIpAddress property. Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param private_ip_addresses_set: (experimental) privateIpAddressesSet property. Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_dest_check: (experimental) sourceDestCheck property. Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnetId property. Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_set: (experimental) tagSet property. Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpcId property. Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                network_interface_set1_item = ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item(
                    attachment=ec2_events.AWSAPICallViaCloudTrail.Attachment(
                        attachment_id=["attachmentId"],
                        attach_time=["attachTime"],
                        delete_on_termination=["deleteOnTermination"],
                        device_index=["deviceIndex"],
                        status=["status"]
                    ),
                    group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet3(
                        items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                            group_id=["groupId"],
                            group_name=["groupName"]
                        )]
                    ),
                    interface_type=["interfaceType"],
                    ipv6_addresses_set=["ipv6AddressesSet"],
                    mac_address=["macAddress"],
                    network_interface_id=["networkInterfaceId"],
                    owner_id=["ownerId"],
                    private_ip_address=["privateIpAddress"],
                    private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet2(
                        item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                            primary=["primary"],
                            private_ip_address=["privateIpAddress"]
                        )]
                    ),
                    source_dest_check=["sourceDestCheck"],
                    status=["status"],
                    subnet_id=["subnetId"],
                    tag_set=["tagSet"],
                    vpc_id=["vpcId"]
                )
            '''
            if isinstance(attachment, dict):
                attachment = AWSAPICallViaCloudTrail.Attachment(**attachment)
            if isinstance(group_set, dict):
                group_set = AWSAPICallViaCloudTrail.GroupSet3(**group_set)
            if isinstance(private_ip_addresses_set, dict):
                private_ip_addresses_set = AWSAPICallViaCloudTrail.PrivateIpAddressesSet2(**private_ip_addresses_set)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__234fc55af9c35150f40f2ed131edd4f881ed14ac2facae4332c936cd720c0d01)
                check_type(argname="argument attachment", value=attachment, expected_type=type_hints["attachment"])
                check_type(argname="argument group_set", value=group_set, expected_type=type_hints["group_set"])
                check_type(argname="argument interface_type", value=interface_type, expected_type=type_hints["interface_type"])
                check_type(argname="argument ipv6_addresses_set", value=ipv6_addresses_set, expected_type=type_hints["ipv6_addresses_set"])
                check_type(argname="argument mac_address", value=mac_address, expected_type=type_hints["mac_address"])
                check_type(argname="argument network_interface_id", value=network_interface_id, expected_type=type_hints["network_interface_id"])
                check_type(argname="argument owner_id", value=owner_id, expected_type=type_hints["owner_id"])
                check_type(argname="argument private_ip_address", value=private_ip_address, expected_type=type_hints["private_ip_address"])
                check_type(argname="argument private_ip_addresses_set", value=private_ip_addresses_set, expected_type=type_hints["private_ip_addresses_set"])
                check_type(argname="argument source_dest_check", value=source_dest_check, expected_type=type_hints["source_dest_check"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
                check_type(argname="argument tag_set", value=tag_set, expected_type=type_hints["tag_set"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attachment is not None:
                self._values["attachment"] = attachment
            if group_set is not None:
                self._values["group_set"] = group_set
            if interface_type is not None:
                self._values["interface_type"] = interface_type
            if ipv6_addresses_set is not None:
                self._values["ipv6_addresses_set"] = ipv6_addresses_set
            if mac_address is not None:
                self._values["mac_address"] = mac_address
            if network_interface_id is not None:
                self._values["network_interface_id"] = network_interface_id
            if owner_id is not None:
                self._values["owner_id"] = owner_id
            if private_ip_address is not None:
                self._values["private_ip_address"] = private_ip_address
            if private_ip_addresses_set is not None:
                self._values["private_ip_addresses_set"] = private_ip_addresses_set
            if source_dest_check is not None:
                self._values["source_dest_check"] = source_dest_check
            if status is not None:
                self._values["status"] = status
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id
            if tag_set is not None:
                self._values["tag_set"] = tag_set
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def attachment(self) -> typing.Optional["AWSAPICallViaCloudTrail.Attachment"]:
            '''(experimental) attachment property.

            Specify an array of string values to match this event if the actual value of attachment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attachment")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Attachment"], result)

        @builtins.property
        def group_set(self) -> typing.Optional["AWSAPICallViaCloudTrail.GroupSet3"]:
            '''(experimental) groupSet property.

            Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.GroupSet3"], result)

        @builtins.property
        def interface_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) interfaceType property.

            Specify an array of string values to match this event if the actual value of interfaceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("interface_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ipv6_addresses_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ipv6AddressesSet property.

            Specify an array of string values to match this event if the actual value of ipv6AddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ipv6_addresses_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mac_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) macAddress property.

            Specify an array of string values to match this event if the actual value of macAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mac_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def network_interface_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) networkInterfaceId property.

            Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def owner_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ownerId property.

            Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("owner_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def private_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privateIpAddress property.

            Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("private_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def private_ip_addresses_set(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.PrivateIpAddressesSet2"]:
            '''(experimental) privateIpAddressesSet property.

            Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("private_ip_addresses_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.PrivateIpAddressesSet2"], result)

        @builtins.property
        def source_dest_check(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceDestCheck property.

            Specify an array of string values to match this event if the actual value of sourceDestCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_dest_check")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnetId property.

            Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagSet property.

            Specify an array of string values to match this event if the actual value of tagSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpcId property.

            Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterfaceSet1Item(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.NetworkInterfaceSetItem",
        jsii_struct_bases=[],
        name_mapping={"device_index": "deviceIndex", "subnet_id": "subnetId"},
    )
    class NetworkInterfaceSetItem:
        def __init__(
            self,
            *,
            device_index: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for NetworkInterfaceSetItem.

            :param device_index: (experimental) deviceIndex property. Specify an array of string values to match this event if the actual value of deviceIndex is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnetId property. Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                network_interface_set_item = ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSetItem(
                    device_index=["deviceIndex"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__71214443057156c8f21d62b351580ee3b0e125c9f98f3c59f4360791f0b82685)
                check_type(argname="argument device_index", value=device_index, expected_type=type_hints["device_index"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if device_index is not None:
                self._values["device_index"] = device_index
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def device_index(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deviceIndex property.

            Specify an array of string values to match this event if the actual value of deviceIndex is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("device_index")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnetId property.

            Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterfaceSetItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.OnDemandOptions",
        jsii_struct_bases=[],
        name_mapping={
            "allocation_strategy": "allocationStrategy",
            "instance_pool_constraint_filter_disabled": "instancePoolConstraintFilterDisabled",
            "max_instance_count": "maxInstanceCount",
            "max_target_capacity": "maxTargetCapacity",
        },
    )
    class OnDemandOptions:
        def __init__(
            self,
            *,
            allocation_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_pool_constraint_filter_disabled: typing.Optional[typing.Sequence[builtins.str]] = None,
            max_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            max_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OnDemandOptions.

            :param allocation_strategy: (experimental) AllocationStrategy property. Specify an array of string values to match this event if the actual value of AllocationStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_pool_constraint_filter_disabled: (experimental) InstancePoolConstraintFilterDisabled property. Specify an array of string values to match this event if the actual value of InstancePoolConstraintFilterDisabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_instance_count: (experimental) MaxInstanceCount property. Specify an array of string values to match this event if the actual value of MaxInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_target_capacity: (experimental) MaxTargetCapacity property. Specify an array of string values to match this event if the actual value of MaxTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                on_demand_options = ec2_events.AWSAPICallViaCloudTrail.OnDemandOptions(
                    allocation_strategy=["allocationStrategy"],
                    instance_pool_constraint_filter_disabled=["instancePoolConstraintFilterDisabled"],
                    max_instance_count=["maxInstanceCount"],
                    max_target_capacity=["maxTargetCapacity"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7c6087aa2f7aed0a7621b93f00e7c49f1c80dbc0740018cc8c5a1cd7de82b60b)
                check_type(argname="argument allocation_strategy", value=allocation_strategy, expected_type=type_hints["allocation_strategy"])
                check_type(argname="argument instance_pool_constraint_filter_disabled", value=instance_pool_constraint_filter_disabled, expected_type=type_hints["instance_pool_constraint_filter_disabled"])
                check_type(argname="argument max_instance_count", value=max_instance_count, expected_type=type_hints["max_instance_count"])
                check_type(argname="argument max_target_capacity", value=max_target_capacity, expected_type=type_hints["max_target_capacity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if allocation_strategy is not None:
                self._values["allocation_strategy"] = allocation_strategy
            if instance_pool_constraint_filter_disabled is not None:
                self._values["instance_pool_constraint_filter_disabled"] = instance_pool_constraint_filter_disabled
            if max_instance_count is not None:
                self._values["max_instance_count"] = max_instance_count
            if max_target_capacity is not None:
                self._values["max_target_capacity"] = max_target_capacity

        @builtins.property
        def allocation_strategy(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AllocationStrategy property.

            Specify an array of string values to match this event if the actual value of AllocationStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("allocation_strategy")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_pool_constraint_filter_disabled(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstancePoolConstraintFilterDisabled property.

            Specify an array of string values to match this event if the actual value of InstancePoolConstraintFilterDisabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_pool_constraint_filter_disabled")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def max_instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MaxInstanceCount property.

            Specify an array of string values to match this event if the actual value of MaxInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def max_target_capacity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MaxTargetCapacity property.

            Specify an array of string values to match this event if the actual value of MaxTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_target_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OnDemandOptions(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.Placement",
        jsii_struct_bases=[],
        name_mapping={"availability_zone": "availabilityZone", "tenancy": "tenancy"},
    )
    class Placement:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            tenancy: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Placement.

            :param availability_zone: (experimental) availabilityZone property. Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tenancy: (experimental) tenancy property. Specify an array of string values to match this event if the actual value of tenancy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                placement = ec2_events.AWSAPICallViaCloudTrail.Placement(
                    availability_zone=["availabilityZone"],
                    tenancy=["tenancy"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__50d0019ceecb32aad35e3743c9d429ac6894322cb6d6380e93c00c2270975b8b)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument tenancy", value=tenancy, expected_type=type_hints["tenancy"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if tenancy is not None:
                self._values["tenancy"] = tenancy

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) availabilityZone property.

            Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tenancy(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tenancy property.

            Specify an array of string values to match this event if the actual value of tenancy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tenancy")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Placement(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1",
        jsii_struct_bases=[],
        name_mapping={"item": "item"},
    )
    class PrivateIpAddressesSet1:
        def __init__(
            self,
            *,
            item: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for PrivateIpAddressesSet_1.

            :param item: (experimental) item property. Specify an array of string values to match this event if the actual value of item is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                private_ip_addresses_set1 = ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1(
                    item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                        primary=["primary"],
                        private_ip_address=["privateIpAddress"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dec63858da94f952dca6b37369e5d4277acd2ae0fc157aca6d39a8418eafcf4b)
                check_type(argname="argument item", value=item, expected_type=type_hints["item"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if item is not None:
                self._values["item"] = item

        @builtins.property
        def item(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item"]]:
            '''(experimental) item property.

            Specify an array of string values to match this event if the actual value of item is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("item")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PrivateIpAddressesSet1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item",
        jsii_struct_bases=[],
        name_mapping={"primary": "primary", "private_ip_address": "privateIpAddress"},
    )
    class PrivateIpAddressesSet1Item:
        def __init__(
            self,
            *,
            primary: typing.Optional[typing.Sequence[builtins.str]] = None,
            private_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for PrivateIpAddressesSet_1Item.

            :param primary: (experimental) primary property. Specify an array of string values to match this event if the actual value of primary is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param private_ip_address: (experimental) privateIpAddress property. Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                private_ip_addresses_set1_item = ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                    primary=["primary"],
                    private_ip_address=["privateIpAddress"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b19a31d9426c010252919d38eca5406af14bf08b2fd99640b7099656591dddf5)
                check_type(argname="argument primary", value=primary, expected_type=type_hints["primary"])
                check_type(argname="argument private_ip_address", value=private_ip_address, expected_type=type_hints["private_ip_address"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if primary is not None:
                self._values["primary"] = primary
            if private_ip_address is not None:
                self._values["private_ip_address"] = private_ip_address

        @builtins.property
        def primary(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) primary property.

            Specify an array of string values to match this event if the actual value of primary is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("primary")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def private_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privateIpAddress property.

            Specify an array of string values to match this event if the actual value of privateIpAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("private_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PrivateIpAddressesSet1Item(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet2",
        jsii_struct_bases=[],
        name_mapping={"item": "item"},
    )
    class PrivateIpAddressesSet2:
        def __init__(
            self,
            *,
            item: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for PrivateIpAddressesSet_2.

            :param item: (experimental) item property. Specify an array of string values to match this event if the actual value of item is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                private_ip_addresses_set2 = ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet2(
                    item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                        primary=["primary"],
                        private_ip_address=["privateIpAddress"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d78f3ccd670241d50c93858fff3a0dc886e933187029029af24be088a423341e)
                check_type(argname="argument item", value=item, expected_type=type_hints["item"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if item is not None:
                self._values["item"] = item

        @builtins.property
        def item(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item"]]:
            '''(experimental) item property.

            Specify an array of string values to match this event if the actual value of item is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("item")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PrivateIpAddressesSet2(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.RequestParameters",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "block_device_mapping": "blockDeviceMapping",
            "client_token": "clientToken",
            "create_fleet_request": "createFleetRequest",
            "create_launch_template_request": "createLaunchTemplateRequest",
            "delete_launch_template_request": "deleteLaunchTemplateRequest",
            "description": "description",
            "disable_api_termination": "disableApiTermination",
            "group_description": "groupDescription",
            "group_id": "groupId",
            "group_name": "groupName",
            "group_set": "groupSet",
            "instance_market_options": "instanceMarketOptions",
            "instances_set": "instancesSet",
            "instance_type": "instanceType",
            "ipv6_address_count": "ipv6AddressCount",
            "launch_template": "launchTemplate",
            "monitoring": "monitoring",
            "network_interface_id": "networkInterfaceId",
            "network_interface_set": "networkInterfaceSet",
            "private_ip_addresses_set": "privateIpAddressesSet",
            "subnet_id": "subnetId",
            "tag_specification_set": "tagSpecificationSet",
            "user_data": "userData",
            "vpc_id": "vpcId",
        },
    )
    class RequestParameters:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            block_device_mapping: typing.Optional[typing.Sequence[builtins.str]] = None,
            client_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            create_fleet_request: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.CreateFleetRequest", typing.Dict[builtins.str, typing.Any]]] = None,
            create_launch_template_request: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest", typing.Dict[builtins.str, typing.Any]]] = None,
            delete_launch_template_request: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest", typing.Dict[builtins.str, typing.Any]]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            disable_api_termination: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.GroupSet1", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_market_options: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.InstanceMarketOptions", typing.Dict[builtins.str, typing.Any]]] = None,
            instances_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.InstancesSet1", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            ipv6_address_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            launch_template: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LaunchTemplate", typing.Dict[builtins.str, typing.Any]]] = None,
            monitoring: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Monitoring", typing.Dict[builtins.str, typing.Any]]] = None,
            network_interface_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            network_interface_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.NetworkInterfaceSet", typing.Dict[builtins.str, typing.Any]]] = None,
            private_ip_addresses_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_specification_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TagSpecificationSet", typing.Dict[builtins.str, typing.Any]]] = None,
            user_data: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParameters.

            :param availability_zone: (experimental) availabilityZone property. Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param block_device_mapping: (experimental) blockDeviceMapping property. Specify an array of string values to match this event if the actual value of blockDeviceMapping is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param client_token: (experimental) clientToken property. Specify an array of string values to match this event if the actual value of clientToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param create_fleet_request: (experimental) CreateFleetRequest property. Specify an array of string values to match this event if the actual value of CreateFleetRequest is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param create_launch_template_request: (experimental) CreateLaunchTemplateRequest property. Specify an array of string values to match this event if the actual value of CreateLaunchTemplateRequest is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param delete_launch_template_request: (experimental) DeleteLaunchTemplateRequest property. Specify an array of string values to match this event if the actual value of DeleteLaunchTemplateRequest is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param disable_api_termination: (experimental) disableApiTermination property. Specify an array of string values to match this event if the actual value of disableApiTermination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_description: (experimental) groupDescription property. Specify an array of string values to match this event if the actual value of groupDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_id: (experimental) groupId property. Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_name: (experimental) groupName property. Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_set: (experimental) groupSet property. Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_market_options: (experimental) instanceMarketOptions property. Specify an array of string values to match this event if the actual value of instanceMarketOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instances_set: (experimental) instancesSet property. Specify an array of string values to match this event if the actual value of instancesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ipv6_address_count: (experimental) ipv6AddressCount property. Specify an array of string values to match this event if the actual value of ipv6AddressCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_template: (experimental) launchTemplate property. Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param monitoring: (experimental) monitoring property. Specify an array of string values to match this event if the actual value of monitoring is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface_id: (experimental) networkInterfaceId property. Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface_set: (experimental) networkInterfaceSet property. Specify an array of string values to match this event if the actual value of networkInterfaceSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param private_ip_addresses_set: (experimental) privateIpAddressesSet property. Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnetId property. Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_specification_set: (experimental) tagSpecificationSet property. Specify an array of string values to match this event if the actual value of tagSpecificationSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_data: (experimental) userData property. Specify an array of string values to match this event if the actual value of userData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpcId property. Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                # overrides: Any
                
                request_parameters = ec2_events.AWSAPICallViaCloudTrail.RequestParameters(
                    availability_zone=["availabilityZone"],
                    block_device_mapping=["blockDeviceMapping"],
                    client_token=["clientToken"],
                    create_fleet_request=ec2_events.AWSAPICallViaCloudTrail.CreateFleetRequest(
                        client_token=["clientToken"],
                        existing_instances=ec2_events.AWSAPICallViaCloudTrail.ExistingInstances(
                            availability_zone=["availabilityZone"],
                            count=["count"],
                            instance_type=["instanceType"],
                            market_option=["marketOption"],
                            operating_system=["operatingSystem"],
                            tag=["tag"]
                        ),
                        launch_template_configs=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateConfigs(
                            launch_template_specification=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                                launch_template_id=["launchTemplateId"],
                                version=["version"]
                            ),
                            overrides=[overrides],
                            tag=["tag"]
                        ),
                        on_demand_options=ec2_events.AWSAPICallViaCloudTrail.OnDemandOptions(
                            allocation_strategy=["allocationStrategy"],
                            instance_pool_constraint_filter_disabled=["instancePoolConstraintFilterDisabled"],
                            max_instance_count=["maxInstanceCount"],
                            max_target_capacity=["maxTargetCapacity"]
                        ),
                        spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions(
                            allocation_strategy=["allocationStrategy"],
                            instance_pool_constraint_filter_disabled=["instancePoolConstraintFilterDisabled"],
                            instance_pools_to_use_count=["instancePoolsToUseCount"],
                            max_instance_count=["maxInstanceCount"],
                            max_target_capacity=["maxTargetCapacity"]
                        ),
                        tag_specification=ec2_events.AWSAPICallViaCloudTrail.TagSpecification(
                            resource_type=["resourceType"],
                            tag=ec2_events.AWSAPICallViaCloudTrail.TagType(
                                key=["key"],
                                tag=["tag"],
                                value=["value"]
                            )
                        ),
                        target_capacity_specification=ec2_events.AWSAPICallViaCloudTrail.TargetCapacitySpecification(
                            default_target_capacity_type=["defaultTargetCapacityType"],
                            on_demand_target_capacity=["onDemandTargetCapacity"],
                            spot_target_capacity=["spotTargetCapacity"],
                            total_target_capacity=["totalTargetCapacity"]
                        ),
                        type=["type"]
                    ),
                    create_launch_template_request=ec2_events.AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest(
                        launch_template_data=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplateData(
                            image_id=["imageId"],
                            instance_market_options=ec2_events.AWSAPICallViaCloudTrail.InstanceMarketOptions1(
                                market_type=["marketType"],
                                spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions2(
                                    max_price=["maxPrice"],
                                    spot_instance_type=["spotInstanceType"]
                                )
                            ),
                            instance_type=["instanceType"],
                            network_interface=ec2_events.AWSAPICallViaCloudTrail.NetworkInterface1(
                                device_index=["deviceIndex"],
                                security_group_id=ec2_events.AWSAPICallViaCloudTrail.SecurityGroupId(
                                    content=["content"],
                                    tag=["tag"]
                                ),
                                subnet_id=["subnetId"],
                                tag=["tag"]
                            ),
                            user_data=["userData"]
                        ),
                        launch_template_name=["launchTemplateName"]
                    ),
                    delete_launch_template_request=ec2_events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest(
                        launch_template_name=["launchTemplateName"]
                    ),
                    description=["description"],
                    disable_api_termination=["disableApiTermination"],
                    group_description=["groupDescription"],
                    group_id=["groupId"],
                    group_name=["groupName"],
                    group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet1(
                        items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet1Item(
                            group_id=["groupId"]
                        )]
                    ),
                    instance_market_options=ec2_events.AWSAPICallViaCloudTrail.InstanceMarketOptions(
                        market_type=["marketType"],
                        spot_options=ec2_events.AWSAPICallViaCloudTrail.SpotOptions1(
                            max_price=["maxPrice"],
                            spot_instance_type=["spotInstanceType"]
                        )
                    ),
                    instances_set=ec2_events.AWSAPICallViaCloudTrail.InstancesSet1(
                        items=[ec2_events.AWSAPICallViaCloudTrail.InstancesSet1Item(
                            image_id=["imageId"],
                            instance_id=["instanceId"],
                            max_count=["maxCount"],
                            min_count=["minCount"]
                        )]
                    ),
                    instance_type=["instanceType"],
                    ipv6_address_count=["ipv6AddressCount"],
                    launch_template=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate(
                        launch_template_id=["launchTemplateId"],
                        version=["version"]
                    ),
                    monitoring=ec2_events.AWSAPICallViaCloudTrail.Monitoring(
                        enabled=["enabled"]
                    ),
                    network_interface_id=["networkInterfaceId"],
                    network_interface_set=ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet(
                        items=[ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSetItem(
                            device_index=["deviceIndex"],
                            subnet_id=["subnetId"]
                        )]
                    ),
                    private_ip_addresses_set=["privateIpAddressesSet"],
                    subnet_id=["subnetId"],
                    tag_specification_set=ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSet(
                        items=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItem(
                            resource_type=["resourceType"],
                            tags=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                                key=["key"],
                                value=["value"]
                            )]
                        )]
                    ),
                    user_data=["userData"],
                    vpc_id=["vpcId"]
                )
            '''
            if isinstance(create_fleet_request, dict):
                create_fleet_request = AWSAPICallViaCloudTrail.CreateFleetRequest(**create_fleet_request)
            if isinstance(create_launch_template_request, dict):
                create_launch_template_request = AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest(**create_launch_template_request)
            if isinstance(delete_launch_template_request, dict):
                delete_launch_template_request = AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest(**delete_launch_template_request)
            if isinstance(group_set, dict):
                group_set = AWSAPICallViaCloudTrail.GroupSet1(**group_set)
            if isinstance(instance_market_options, dict):
                instance_market_options = AWSAPICallViaCloudTrail.InstanceMarketOptions(**instance_market_options)
            if isinstance(instances_set, dict):
                instances_set = AWSAPICallViaCloudTrail.InstancesSet1(**instances_set)
            if isinstance(launch_template, dict):
                launch_template = AWSAPICallViaCloudTrail.LaunchTemplate(**launch_template)
            if isinstance(monitoring, dict):
                monitoring = AWSAPICallViaCloudTrail.Monitoring(**monitoring)
            if isinstance(network_interface_set, dict):
                network_interface_set = AWSAPICallViaCloudTrail.NetworkInterfaceSet(**network_interface_set)
            if isinstance(tag_specification_set, dict):
                tag_specification_set = AWSAPICallViaCloudTrail.TagSpecificationSet(**tag_specification_set)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5838fd13b1d0c4446f0f4c64847c4a0bd62e31448fa6cca3f9c92da6712503f9)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument block_device_mapping", value=block_device_mapping, expected_type=type_hints["block_device_mapping"])
                check_type(argname="argument client_token", value=client_token, expected_type=type_hints["client_token"])
                check_type(argname="argument create_fleet_request", value=create_fleet_request, expected_type=type_hints["create_fleet_request"])
                check_type(argname="argument create_launch_template_request", value=create_launch_template_request, expected_type=type_hints["create_launch_template_request"])
                check_type(argname="argument delete_launch_template_request", value=delete_launch_template_request, expected_type=type_hints["delete_launch_template_request"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument disable_api_termination", value=disable_api_termination, expected_type=type_hints["disable_api_termination"])
                check_type(argname="argument group_description", value=group_description, expected_type=type_hints["group_description"])
                check_type(argname="argument group_id", value=group_id, expected_type=type_hints["group_id"])
                check_type(argname="argument group_name", value=group_name, expected_type=type_hints["group_name"])
                check_type(argname="argument group_set", value=group_set, expected_type=type_hints["group_set"])
                check_type(argname="argument instance_market_options", value=instance_market_options, expected_type=type_hints["instance_market_options"])
                check_type(argname="argument instances_set", value=instances_set, expected_type=type_hints["instances_set"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument ipv6_address_count", value=ipv6_address_count, expected_type=type_hints["ipv6_address_count"])
                check_type(argname="argument launch_template", value=launch_template, expected_type=type_hints["launch_template"])
                check_type(argname="argument monitoring", value=monitoring, expected_type=type_hints["monitoring"])
                check_type(argname="argument network_interface_id", value=network_interface_id, expected_type=type_hints["network_interface_id"])
                check_type(argname="argument network_interface_set", value=network_interface_set, expected_type=type_hints["network_interface_set"])
                check_type(argname="argument private_ip_addresses_set", value=private_ip_addresses_set, expected_type=type_hints["private_ip_addresses_set"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
                check_type(argname="argument tag_specification_set", value=tag_specification_set, expected_type=type_hints["tag_specification_set"])
                check_type(argname="argument user_data", value=user_data, expected_type=type_hints["user_data"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if block_device_mapping is not None:
                self._values["block_device_mapping"] = block_device_mapping
            if client_token is not None:
                self._values["client_token"] = client_token
            if create_fleet_request is not None:
                self._values["create_fleet_request"] = create_fleet_request
            if create_launch_template_request is not None:
                self._values["create_launch_template_request"] = create_launch_template_request
            if delete_launch_template_request is not None:
                self._values["delete_launch_template_request"] = delete_launch_template_request
            if description is not None:
                self._values["description"] = description
            if disable_api_termination is not None:
                self._values["disable_api_termination"] = disable_api_termination
            if group_description is not None:
                self._values["group_description"] = group_description
            if group_id is not None:
                self._values["group_id"] = group_id
            if group_name is not None:
                self._values["group_name"] = group_name
            if group_set is not None:
                self._values["group_set"] = group_set
            if instance_market_options is not None:
                self._values["instance_market_options"] = instance_market_options
            if instances_set is not None:
                self._values["instances_set"] = instances_set
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if ipv6_address_count is not None:
                self._values["ipv6_address_count"] = ipv6_address_count
            if launch_template is not None:
                self._values["launch_template"] = launch_template
            if monitoring is not None:
                self._values["monitoring"] = monitoring
            if network_interface_id is not None:
                self._values["network_interface_id"] = network_interface_id
            if network_interface_set is not None:
                self._values["network_interface_set"] = network_interface_set
            if private_ip_addresses_set is not None:
                self._values["private_ip_addresses_set"] = private_ip_addresses_set
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id
            if tag_specification_set is not None:
                self._values["tag_specification_set"] = tag_specification_set
            if user_data is not None:
                self._values["user_data"] = user_data
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) availabilityZone property.

            Specify an array of string values to match this event if the actual value of availabilityZone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def block_device_mapping(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) blockDeviceMapping property.

            Specify an array of string values to match this event if the actual value of blockDeviceMapping is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("block_device_mapping")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def client_token(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clientToken property.

            Specify an array of string values to match this event if the actual value of clientToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("client_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def create_fleet_request(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.CreateFleetRequest"]:
            '''(experimental) CreateFleetRequest property.

            Specify an array of string values to match this event if the actual value of CreateFleetRequest is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("create_fleet_request")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.CreateFleetRequest"], result)

        @builtins.property
        def create_launch_template_request(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest"]:
            '''(experimental) CreateLaunchTemplateRequest property.

            Specify an array of string values to match this event if the actual value of CreateLaunchTemplateRequest is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("create_launch_template_request")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest"], result)

        @builtins.property
        def delete_launch_template_request(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest"]:
            '''(experimental) DeleteLaunchTemplateRequest property.

            Specify an array of string values to match this event if the actual value of DeleteLaunchTemplateRequest is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("delete_launch_template_request")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest"], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def disable_api_termination(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) disableApiTermination property.

            Specify an array of string values to match this event if the actual value of disableApiTermination is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("disable_api_termination")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupDescription property.

            Specify an array of string values to match this event if the actual value of groupDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupId property.

            Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupName property.

            Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_set(self) -> typing.Optional["AWSAPICallViaCloudTrail.GroupSet1"]:
            '''(experimental) groupSet property.

            Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.GroupSet1"], result)

        @builtins.property
        def instance_market_options(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.InstanceMarketOptions"]:
            '''(experimental) instanceMarketOptions property.

            Specify an array of string values to match this event if the actual value of instanceMarketOptions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_market_options")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.InstanceMarketOptions"], result)

        @builtins.property
        def instances_set(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.InstancesSet1"]:
            '''(experimental) instancesSet property.

            Specify an array of string values to match this event if the actual value of instancesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instances_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.InstancesSet1"], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceType property.

            Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ipv6_address_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ipv6AddressCount property.

            Specify an array of string values to match this event if the actual value of ipv6AddressCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ipv6_address_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def launch_template(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplate"]:
            '''(experimental) launchTemplate property.

            Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplate"], result)

        @builtins.property
        def monitoring(self) -> typing.Optional["AWSAPICallViaCloudTrail.Monitoring"]:
            '''(experimental) monitoring property.

            Specify an array of string values to match this event if the actual value of monitoring is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("monitoring")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Monitoring"], result)

        @builtins.property
        def network_interface_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) networkInterfaceId property.

            Specify an array of string values to match this event if the actual value of networkInterfaceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def network_interface_set(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.NetworkInterfaceSet"]:
            '''(experimental) networkInterfaceSet property.

            Specify an array of string values to match this event if the actual value of networkInterfaceSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.NetworkInterfaceSet"], result)

        @builtins.property
        def private_ip_addresses_set(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privateIpAddressesSet property.

            Specify an array of string values to match this event if the actual value of privateIpAddressesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("private_ip_addresses_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnetId property.

            Specify an array of string values to match this event if the actual value of subnetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_specification_set(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.TagSpecificationSet"]:
            '''(experimental) tagSpecificationSet property.

            Specify an array of string values to match this event if the actual value of tagSpecificationSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_specification_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TagSpecificationSet"], result)

        @builtins.property
        def user_data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userData property.

            Specify an array of string values to match this event if the actual value of userData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpcId property.

            Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.ResponseElements",
        jsii_struct_bases=[],
        name_mapping={
            "create_fleet_response": "createFleetResponse",
            "create_launch_template_response": "createLaunchTemplateResponse",
            "delete_launch_template_response": "deleteLaunchTemplateResponse",
            "group_id": "groupId",
            "group_set": "groupSet",
            "instances_set": "instancesSet",
            "network_interface": "networkInterface",
            "owner_id": "ownerId",
            "requester_id": "requesterId",
            "request_id": "requestId",
            "reservation_id": "reservationId",
            "return_": "return",
        },
    )
    class ResponseElements:
        def __init__(
            self,
            *,
            create_fleet_response: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.CreateFleetResponse", typing.Dict[builtins.str, typing.Any]]] = None,
            create_launch_template_response: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse", typing.Dict[builtins.str, typing.Any]]] = None,
            delete_launch_template_response: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse", typing.Dict[builtins.str, typing.Any]]] = None,
            group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            instances_set: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.InstancesSet", typing.Dict[builtins.str, typing.Any]]] = None,
            network_interface: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.NetworkInterface", typing.Dict[builtins.str, typing.Any]]] = None,
            owner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            requester_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            reservation_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            return_: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElements.

            :param create_fleet_response: (experimental) CreateFleetResponse property. Specify an array of string values to match this event if the actual value of CreateFleetResponse is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param create_launch_template_response: (experimental) CreateLaunchTemplateResponse property. Specify an array of string values to match this event if the actual value of CreateLaunchTemplateResponse is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param delete_launch_template_response: (experimental) DeleteLaunchTemplateResponse property. Specify an array of string values to match this event if the actual value of DeleteLaunchTemplateResponse is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_id: (experimental) groupId property. Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_set: (experimental) groupSet property. Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instances_set: (experimental) instancesSet property. Specify an array of string values to match this event if the actual value of instancesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface: (experimental) networkInterface property. Specify an array of string values to match this event if the actual value of networkInterface is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param owner_id: (experimental) ownerId property. Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param requester_id: (experimental) requesterId property. Specify an array of string values to match this event if the actual value of requesterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestId property. Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reservation_id: (experimental) reservationId property. Specify an array of string values to match this event if the actual value of reservationId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param return_: (experimental) _return property. Specify an array of string values to match this event if the actual value of _return is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                response_elements = ec2_events.AWSAPICallViaCloudTrail.ResponseElements(
                    create_fleet_response=ec2_events.AWSAPICallViaCloudTrail.CreateFleetResponse(
                        error_set=["errorSet"],
                        fleet_id=["fleetId"],
                        fleet_instance_set=["fleetInstanceSet"],
                        request_id=["requestId"],
                        xmlns=["xmlns"]
                    ),
                    create_launch_template_response=ec2_events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse(
                        launch_template=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                            created_by=["createdBy"],
                            create_time=["createTime"],
                            default_version_number=["defaultVersionNumber"],
                            latest_version_number=["latestVersionNumber"],
                            launch_template_id=["launchTemplateId"],
                            launch_template_name=["launchTemplateName"]
                        ),
                        request_id=["requestId"],
                        xmlns=["xmlns"]
                    ),
                    delete_launch_template_response=ec2_events.AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse(
                        launch_template=ec2_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                            created_by=["createdBy"],
                            create_time=["createTime"],
                            default_version_number=["defaultVersionNumber"],
                            latest_version_number=["latestVersionNumber"],
                            launch_template_id=["launchTemplateId"],
                            launch_template_name=["launchTemplateName"]
                        ),
                        request_id=["requestId"],
                        xmlns=["xmlns"]
                    ),
                    group_id=["groupId"],
                    group_set=["groupSet"],
                    instances_set=ec2_events.AWSAPICallViaCloudTrail.InstancesSet(
                        items=[ec2_events.AWSAPICallViaCloudTrail.InstancesSetItem(
                            ami_launch_index=["amiLaunchIndex"],
                            architecture=["architecture"],
                            block_device_mapping=["blockDeviceMapping"],
                            capacity_reservation_specification=ec2_events.AWSAPICallViaCloudTrail.CapacityReservationSpecification(
                                capacity_reservation_preference=["capacityReservationPreference"]
                            ),
                            client_token=["clientToken"],
                            cpu_options=ec2_events.AWSAPICallViaCloudTrail.CpuOptions(
                                core_count=["coreCount"],
                                threads_per_core=["threadsPerCore"]
                            ),
                            current_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                                code=["code"],
                                name=["name"]
                            ),
                            ebs_optimized=["ebsOptimized"],
                            enclave_options=ec2_events.AWSAPICallViaCloudTrail.EnclaveOptions(
                                enabled=["enabled"]
                            ),
                            group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet2(
                                items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                    group_id=["groupId"],
                                    group_name=["groupName"]
                                )]
                            ),
                            hypervisor=["hypervisor"],
                            image_id=["imageId"],
                            instance_id=["instanceId"],
                            instance_lifecycle=["instanceLifecycle"],
                            instance_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                                code=["code"],
                                name=["name"]
                            ),
                            instance_type=["instanceType"],
                            launch_time=["launchTime"],
                            monitoring=ec2_events.AWSAPICallViaCloudTrail.Monitoring1(
                                state=["state"]
                            ),
                            network_interface_set=ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1(
                                items=[ec2_events.AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item(
                                    attachment=ec2_events.AWSAPICallViaCloudTrail.Attachment(
                                        attachment_id=["attachmentId"],
                                        attach_time=["attachTime"],
                                        delete_on_termination=["deleteOnTermination"],
                                        device_index=["deviceIndex"],
                                        status=["status"]
                                    ),
                                    group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet3(
                                        items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                            group_id=["groupId"],
                                            group_name=["groupName"]
                                        )]
                                    ),
                                    interface_type=["interfaceType"],
                                    ipv6_addresses_set=["ipv6AddressesSet"],
                                    mac_address=["macAddress"],
                                    network_interface_id=["networkInterfaceId"],
                                    owner_id=["ownerId"],
                                    private_ip_address=["privateIpAddress"],
                                    private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet2(
                                        item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                                            primary=["primary"],
                                            private_ip_address=["privateIpAddress"]
                                        )]
                                    ),
                                    source_dest_check=["sourceDestCheck"],
                                    status=["status"],
                                    subnet_id=["subnetId"],
                                    tag_set=["tagSet"],
                                    vpc_id=["vpcId"]
                                )]
                            ),
                            placement=ec2_events.AWSAPICallViaCloudTrail.Placement(
                                availability_zone=["availabilityZone"],
                                tenancy=["tenancy"]
                            ),
                            previous_state=ec2_events.AWSAPICallViaCloudTrail.InstanceState(
                                code=["code"],
                                name=["name"]
                            ),
                            private_ip_address=["privateIpAddress"],
                            product_codes=["productCodes"],
                            root_device_name=["rootDeviceName"],
                            root_device_type=["rootDeviceType"],
                            source_dest_check=["sourceDestCheck"],
                            spot_instance_request_id=["spotInstanceRequestId"],
                            state_reason=ec2_events.AWSAPICallViaCloudTrail.StateReason(
                                code=["code"],
                                message=["message"]
                            ),
                            subnet_id=["subnetId"],
                            tag_set=ec2_events.AWSAPICallViaCloudTrail.TagSet(
                                items=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                                    key=["key"],
                                    value=["value"]
                                )]
                            ),
                            virtualization_type=["virtualizationType"],
                            vpc_id=["vpcId"]
                        )]
                    ),
                    network_interface=ec2_events.AWSAPICallViaCloudTrail.NetworkInterface(
                        availability_zone=["availabilityZone"],
                        description=["description"],
                        group_set=ec2_events.AWSAPICallViaCloudTrail.GroupSet2(
                            items=[ec2_events.AWSAPICallViaCloudTrail.GroupSet2Item(
                                group_id=["groupId"],
                                group_name=["groupName"]
                            )]
                        ),
                        interface_type=["interfaceType"],
                        ipv6_addresses_set=["ipv6AddressesSet"],
                        mac_address=["macAddress"],
                        network_interface_id=["networkInterfaceId"],
                        owner_id=["ownerId"],
                        private_ip_address=["privateIpAddress"],
                        private_ip_addresses_set=ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1(
                            item=[ec2_events.AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item(
                                primary=["primary"],
                                private_ip_address=["privateIpAddress"]
                            )]
                        ),
                        requester_id=["requesterId"],
                        requester_managed=["requesterManaged"],
                        source_dest_check=["sourceDestCheck"],
                        status=["status"],
                        subnet_id=["subnetId"],
                        tag_set=["tagSet"],
                        vpc_id=["vpcId"]
                    ),
                    owner_id=["ownerId"],
                    requester_id=["requesterId"],
                    request_id=["requestId"],
                    reservation_id=["reservationId"],
                    return=["return"]
                )
            '''
            if isinstance(create_fleet_response, dict):
                create_fleet_response = AWSAPICallViaCloudTrail.CreateFleetResponse(**create_fleet_response)
            if isinstance(create_launch_template_response, dict):
                create_launch_template_response = AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse(**create_launch_template_response)
            if isinstance(delete_launch_template_response, dict):
                delete_launch_template_response = AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse(**delete_launch_template_response)
            if isinstance(instances_set, dict):
                instances_set = AWSAPICallViaCloudTrail.InstancesSet(**instances_set)
            if isinstance(network_interface, dict):
                network_interface = AWSAPICallViaCloudTrail.NetworkInterface(**network_interface)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a2078912c38e252d2463542147c932e78733bdfa4dc7772eca9f30ca32ff2edd)
                check_type(argname="argument create_fleet_response", value=create_fleet_response, expected_type=type_hints["create_fleet_response"])
                check_type(argname="argument create_launch_template_response", value=create_launch_template_response, expected_type=type_hints["create_launch_template_response"])
                check_type(argname="argument delete_launch_template_response", value=delete_launch_template_response, expected_type=type_hints["delete_launch_template_response"])
                check_type(argname="argument group_id", value=group_id, expected_type=type_hints["group_id"])
                check_type(argname="argument group_set", value=group_set, expected_type=type_hints["group_set"])
                check_type(argname="argument instances_set", value=instances_set, expected_type=type_hints["instances_set"])
                check_type(argname="argument network_interface", value=network_interface, expected_type=type_hints["network_interface"])
                check_type(argname="argument owner_id", value=owner_id, expected_type=type_hints["owner_id"])
                check_type(argname="argument requester_id", value=requester_id, expected_type=type_hints["requester_id"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument reservation_id", value=reservation_id, expected_type=type_hints["reservation_id"])
                check_type(argname="argument return_", value=return_, expected_type=type_hints["return_"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if create_fleet_response is not None:
                self._values["create_fleet_response"] = create_fleet_response
            if create_launch_template_response is not None:
                self._values["create_launch_template_response"] = create_launch_template_response
            if delete_launch_template_response is not None:
                self._values["delete_launch_template_response"] = delete_launch_template_response
            if group_id is not None:
                self._values["group_id"] = group_id
            if group_set is not None:
                self._values["group_set"] = group_set
            if instances_set is not None:
                self._values["instances_set"] = instances_set
            if network_interface is not None:
                self._values["network_interface"] = network_interface
            if owner_id is not None:
                self._values["owner_id"] = owner_id
            if requester_id is not None:
                self._values["requester_id"] = requester_id
            if request_id is not None:
                self._values["request_id"] = request_id
            if reservation_id is not None:
                self._values["reservation_id"] = reservation_id
            if return_ is not None:
                self._values["return_"] = return_

        @builtins.property
        def create_fleet_response(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.CreateFleetResponse"]:
            '''(experimental) CreateFleetResponse property.

            Specify an array of string values to match this event if the actual value of CreateFleetResponse is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("create_fleet_response")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.CreateFleetResponse"], result)

        @builtins.property
        def create_launch_template_response(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse"]:
            '''(experimental) CreateLaunchTemplateResponse property.

            Specify an array of string values to match this event if the actual value of CreateLaunchTemplateResponse is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("create_launch_template_response")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse"], result)

        @builtins.property
        def delete_launch_template_response(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse"]:
            '''(experimental) DeleteLaunchTemplateResponse property.

            Specify an array of string values to match this event if the actual value of DeleteLaunchTemplateResponse is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("delete_launch_template_response")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse"], result)

        @builtins.property
        def group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupId property.

            Specify an array of string values to match this event if the actual value of groupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupSet property.

            Specify an array of string values to match this event if the actual value of groupSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instances_set(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.InstancesSet"]:
            '''(experimental) instancesSet property.

            Specify an array of string values to match this event if the actual value of instancesSet is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instances_set")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.InstancesSet"], result)

        @builtins.property
        def network_interface(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.NetworkInterface"]:
            '''(experimental) networkInterface property.

            Specify an array of string values to match this event if the actual value of networkInterface is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.NetworkInterface"], result)

        @builtins.property
        def owner_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ownerId property.

            Specify an array of string values to match this event if the actual value of ownerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("owner_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def requester_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requesterId property.

            Specify an array of string values to match this event if the actual value of requesterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("requester_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestId property.

            Specify an array of string values to match this event if the actual value of requestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reservation_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reservationId property.

            Specify an array of string values to match this event if the actual value of reservationId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reservation_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def return_(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) _return property.

            Specify an array of string values to match this event if the actual value of _return is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("return_")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElements(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.SecurityGroupId",
        jsii_struct_bases=[],
        name_mapping={"content": "content", "tag": "tag"},
    )
    class SecurityGroupId:
        def __init__(
            self,
            *,
            content: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SecurityGroupId.

            :param content: (experimental) content property. Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag: (experimental) tag property. Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                security_group_id = ec2_events.AWSAPICallViaCloudTrail.SecurityGroupId(
                    content=["content"],
                    tag=["tag"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__cfc6e4614f11a43a56d28bc20cedad2944fe2ce266a43728c9dbe4408e38fca6)
                check_type(argname="argument content", value=content, expected_type=type_hints["content"])
                check_type(argname="argument tag", value=tag, expected_type=type_hints["tag"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if content is not None:
                self._values["content"] = content
            if tag is not None:
                self._values["tag"] = tag

        @builtins.property
        def content(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) content property.

            Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tag property.

            Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SecurityGroupId(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.SessionContext",
        jsii_struct_bases=[],
        name_mapping={
            "attributes": "attributes",
            "session_issuer": "sessionIssuer",
            "web_id_federation_data": "webIdFederationData",
        },
    )
    class SessionContext:
        def __init__(
            self,
            *,
            attributes: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            session_issuer: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionIssuer", typing.Dict[builtins.str, typing.Any]]] = None,
            web_id_federation_data: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionContext.

            :param attributes: (experimental) attributes property. Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_issuer: (experimental) sessionIssuer property. Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param web_id_federation_data: (experimental) webIdFederationData property. Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                session_context = ec2_events.AWSAPICallViaCloudTrail.SessionContext(
                    attributes=ec2_events.AWSAPICallViaCloudTrail.Attributes(
                        creation_date=["creationDate"],
                        mfa_authenticated=["mfaAuthenticated"]
                    ),
                    session_issuer=ec2_events.AWSAPICallViaCloudTrail.SessionIssuer(
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        type=["type"],
                        user_name=["userName"]
                    ),
                    web_id_federation_data=["webIdFederationData"]
                )
            '''
            if isinstance(attributes, dict):
                attributes = AWSAPICallViaCloudTrail.Attributes(**attributes)
            if isinstance(session_issuer, dict):
                session_issuer = AWSAPICallViaCloudTrail.SessionIssuer(**session_issuer)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__26eaa0a248c1be55791562b5e3737d7cdb8870d5ecc272f249e30dbeb8514b2f)
                check_type(argname="argument attributes", value=attributes, expected_type=type_hints["attributes"])
                check_type(argname="argument session_issuer", value=session_issuer, expected_type=type_hints["session_issuer"])
                check_type(argname="argument web_id_federation_data", value=web_id_federation_data, expected_type=type_hints["web_id_federation_data"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attributes is not None:
                self._values["attributes"] = attributes
            if session_issuer is not None:
                self._values["session_issuer"] = session_issuer
            if web_id_federation_data is not None:
                self._values["web_id_federation_data"] = web_id_federation_data

        @builtins.property
        def attributes(self) -> typing.Optional["AWSAPICallViaCloudTrail.Attributes"]:
            '''(experimental) attributes property.

            Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attributes")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Attributes"], result)

        @builtins.property
        def session_issuer(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"]:
            '''(experimental) sessionIssuer property.

            Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_issuer")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"], result)

        @builtins.property
        def web_id_federation_data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) webIdFederationData property.

            Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("web_id_federation_data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionContext(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.SessionIssuer",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "type": "type",
            "user_name": "userName",
        },
    )
    class SessionIssuer:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionIssuer.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_name: (experimental) userName property. Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                session_issuer = ec2_events.AWSAPICallViaCloudTrail.SessionIssuer(
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    type=["type"],
                    user_name=["userName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ae0b8ca0f99bf4bf39b296f5a66cdb3186f1799d5da18a1e6dabd35086c6b273)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument user_name", value=user_name, expected_type=type_hints["user_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if type is not None:
                self._values["type"] = type
            if user_name is not None:
                self._values["user_name"] = user_name

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userName property.

            Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionIssuer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.SpotOptions",
        jsii_struct_bases=[],
        name_mapping={
            "allocation_strategy": "allocationStrategy",
            "instance_pool_constraint_filter_disabled": "instancePoolConstraintFilterDisabled",
            "instance_pools_to_use_count": "instancePoolsToUseCount",
            "max_instance_count": "maxInstanceCount",
            "max_target_capacity": "maxTargetCapacity",
        },
    )
    class SpotOptions:
        def __init__(
            self,
            *,
            allocation_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_pool_constraint_filter_disabled: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_pools_to_use_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            max_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            max_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SpotOptions.

            :param allocation_strategy: (experimental) AllocationStrategy property. Specify an array of string values to match this event if the actual value of AllocationStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_pool_constraint_filter_disabled: (experimental) InstancePoolConstraintFilterDisabled property. Specify an array of string values to match this event if the actual value of InstancePoolConstraintFilterDisabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_pools_to_use_count: (experimental) InstancePoolsToUseCount property. Specify an array of string values to match this event if the actual value of InstancePoolsToUseCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_instance_count: (experimental) MaxInstanceCount property. Specify an array of string values to match this event if the actual value of MaxInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_target_capacity: (experimental) MaxTargetCapacity property. Specify an array of string values to match this event if the actual value of MaxTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                spot_options = ec2_events.AWSAPICallViaCloudTrail.SpotOptions(
                    allocation_strategy=["allocationStrategy"],
                    instance_pool_constraint_filter_disabled=["instancePoolConstraintFilterDisabled"],
                    instance_pools_to_use_count=["instancePoolsToUseCount"],
                    max_instance_count=["maxInstanceCount"],
                    max_target_capacity=["maxTargetCapacity"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__185430d2de7bdd627819fa67eda750e9ca5e81f78076ad72583f9a74ce6a23c4)
                check_type(argname="argument allocation_strategy", value=allocation_strategy, expected_type=type_hints["allocation_strategy"])
                check_type(argname="argument instance_pool_constraint_filter_disabled", value=instance_pool_constraint_filter_disabled, expected_type=type_hints["instance_pool_constraint_filter_disabled"])
                check_type(argname="argument instance_pools_to_use_count", value=instance_pools_to_use_count, expected_type=type_hints["instance_pools_to_use_count"])
                check_type(argname="argument max_instance_count", value=max_instance_count, expected_type=type_hints["max_instance_count"])
                check_type(argname="argument max_target_capacity", value=max_target_capacity, expected_type=type_hints["max_target_capacity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if allocation_strategy is not None:
                self._values["allocation_strategy"] = allocation_strategy
            if instance_pool_constraint_filter_disabled is not None:
                self._values["instance_pool_constraint_filter_disabled"] = instance_pool_constraint_filter_disabled
            if instance_pools_to_use_count is not None:
                self._values["instance_pools_to_use_count"] = instance_pools_to_use_count
            if max_instance_count is not None:
                self._values["max_instance_count"] = max_instance_count
            if max_target_capacity is not None:
                self._values["max_target_capacity"] = max_target_capacity

        @builtins.property
        def allocation_strategy(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AllocationStrategy property.

            Specify an array of string values to match this event if the actual value of AllocationStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("allocation_strategy")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_pool_constraint_filter_disabled(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstancePoolConstraintFilterDisabled property.

            Specify an array of string values to match this event if the actual value of InstancePoolConstraintFilterDisabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_pool_constraint_filter_disabled")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_pools_to_use_count(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstancePoolsToUseCount property.

            Specify an array of string values to match this event if the actual value of InstancePoolsToUseCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_pools_to_use_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def max_instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MaxInstanceCount property.

            Specify an array of string values to match this event if the actual value of MaxInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def max_target_capacity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MaxTargetCapacity property.

            Specify an array of string values to match this event if the actual value of MaxTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_target_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SpotOptions(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.SpotOptions1",
        jsii_struct_bases=[],
        name_mapping={
            "max_price": "maxPrice",
            "spot_instance_type": "spotInstanceType",
        },
    )
    class SpotOptions1:
        def __init__(
            self,
            *,
            max_price: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SpotOptions_1.

            :param max_price: (experimental) maxPrice property. Specify an array of string values to match this event if the actual value of maxPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_instance_type: (experimental) spotInstanceType property. Specify an array of string values to match this event if the actual value of spotInstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                spot_options1 = ec2_events.AWSAPICallViaCloudTrail.SpotOptions1(
                    max_price=["maxPrice"],
                    spot_instance_type=["spotInstanceType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f6256d41ebac4fd87d7f7f965e082e7b129262089c9d320bcf1470a3e3b02f49)
                check_type(argname="argument max_price", value=max_price, expected_type=type_hints["max_price"])
                check_type(argname="argument spot_instance_type", value=spot_instance_type, expected_type=type_hints["spot_instance_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if max_price is not None:
                self._values["max_price"] = max_price
            if spot_instance_type is not None:
                self._values["spot_instance_type"] = spot_instance_type

        @builtins.property
        def max_price(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) maxPrice property.

            Specify an array of string values to match this event if the actual value of maxPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_price")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) spotInstanceType property.

            Specify an array of string values to match this event if the actual value of spotInstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SpotOptions1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.SpotOptions2",
        jsii_struct_bases=[],
        name_mapping={
            "max_price": "maxPrice",
            "spot_instance_type": "spotInstanceType",
        },
    )
    class SpotOptions2:
        def __init__(
            self,
            *,
            max_price: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SpotOptions_2.

            :param max_price: (experimental) MaxPrice property. Specify an array of string values to match this event if the actual value of MaxPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_instance_type: (experimental) SpotInstanceType property. Specify an array of string values to match this event if the actual value of SpotInstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                spot_options2 = ec2_events.AWSAPICallViaCloudTrail.SpotOptions2(
                    max_price=["maxPrice"],
                    spot_instance_type=["spotInstanceType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7476a676b2c0c60b652fa0c37bac760f2b86586a571174b667980bba4e90e1e1)
                check_type(argname="argument max_price", value=max_price, expected_type=type_hints["max_price"])
                check_type(argname="argument spot_instance_type", value=spot_instance_type, expected_type=type_hints["spot_instance_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if max_price is not None:
                self._values["max_price"] = max_price
            if spot_instance_type is not None:
                self._values["spot_instance_type"] = spot_instance_type

        @builtins.property
        def max_price(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MaxPrice property.

            Specify an array of string values to match this event if the actual value of MaxPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_price")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SpotInstanceType property.

            Specify an array of string values to match this event if the actual value of SpotInstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SpotOptions2(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.StateReason",
        jsii_struct_bases=[],
        name_mapping={"code": "code", "message": "message"},
    )
    class StateReason:
        def __init__(
            self,
            *,
            code: typing.Optional[typing.Sequence[builtins.str]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for StateReason.

            :param code: (experimental) code property. Specify an array of string values to match this event if the actual value of code is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                state_reason = ec2_events.AWSAPICallViaCloudTrail.StateReason(
                    code=["code"],
                    message=["message"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e65d09b268e1952ab0154274ec573037d6ddef72ada96d94b75e5e39e8b804fe)
                check_type(argname="argument code", value=code, expected_type=type_hints["code"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if code is not None:
                self._values["code"] = code
            if message is not None:
                self._values["message"] = message

        @builtins.property
        def code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) code property.

            Specify an array of string values to match this event if the actual value of code is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "StateReason(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.TagSet",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class TagSet:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.TagSpecificationSetItemItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for TagSet.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                tag_set = ec2_events.AWSAPICallViaCloudTrail.TagSet(
                    items=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__59fbfe02e5fa55f04ade5b49d29c1f4fc5f6d32a713551619d30320ce362816a)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.TagSpecificationSetItemItem"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.TagSpecificationSetItemItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagSet(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.TagSpecification",
        jsii_struct_bases=[],
        name_mapping={"resource_type": "resourceType", "tag": "tag"},
    )
    class TagSpecification:
        def __init__(
            self,
            *,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TagType", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for TagSpecification.

            :param resource_type: (experimental) ResourceType property. Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag: (experimental) Tag property. Specify an array of string values to match this event if the actual value of Tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                tag_specification = ec2_events.AWSAPICallViaCloudTrail.TagSpecification(
                    resource_type=["resourceType"],
                    tag=ec2_events.AWSAPICallViaCloudTrail.TagType(
                        key=["key"],
                        tag=["tag"],
                        value=["value"]
                    )
                )
            '''
            if isinstance(tag, dict):
                tag = AWSAPICallViaCloudTrail.TagType(**tag)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__db02c3d5a8b61948bb0f4a666b089eb59c0bfea280e5951d9cc700fbb0119407)
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
                check_type(argname="argument tag", value=tag, expected_type=type_hints["tag"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if resource_type is not None:
                self._values["resource_type"] = resource_type
            if tag is not None:
                self._values["tag"] = tag

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ResourceType property.

            Specify an array of string values to match this event if the actual value of ResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag(self) -> typing.Optional["AWSAPICallViaCloudTrail.TagType"]:
            '''(experimental) Tag property.

            Specify an array of string values to match this event if the actual value of Tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TagType"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.TagSpecificationSet",
        jsii_struct_bases=[],
        name_mapping={"items": "items"},
    )
    class TagSpecificationSet:
        def __init__(
            self,
            *,
            items: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.TagSpecificationSetItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for TagSpecificationSet.

            :param items: (experimental) items property. Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                tag_specification_set = ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSet(
                    items=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItem(
                        resource_type=["resourceType"],
                        tags=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                            key=["key"],
                            value=["value"]
                        )]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__be1088628136942d7361cfeb844d39b1d5b54e68a91e8da30b1d522478e4988e)
                check_type(argname="argument items", value=items, expected_type=type_hints["items"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if items is not None:
                self._values["items"] = items

        @builtins.property
        def items(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.TagSpecificationSetItem"]]:
            '''(experimental) items property.

            Specify an array of string values to match this event if the actual value of items is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("items")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.TagSpecificationSetItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagSpecificationSet(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.TagSpecificationSetItem",
        jsii_struct_bases=[],
        name_mapping={"resource_type": "resourceType", "tags": "tags"},
    )
    class TagSpecificationSetItem:
        def __init__(
            self,
            *,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.TagSpecificationSetItemItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for TagSpecificationSetItem.

            :param resource_type: (experimental) resourceType property. Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                tag_specification_set_item = ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItem(
                    resource_type=["resourceType"],
                    tags=[ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__375b1dce40b1e5623d30164987d00840948d983f7704f4b571edb904a3e84cba)
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if resource_type is not None:
                self._values["resource_type"] = resource_type
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resourceType property.

            Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.TagSpecificationSetItemItem"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.TagSpecificationSetItemItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagSpecificationSetItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class TagSpecificationSetItemItem:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TagSpecificationSetItemItem.

            :param key: (experimental) key property. Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                tag_specification_set_item_item = ec2_events.AWSAPICallViaCloudTrail.TagSpecificationSetItemItem(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7fb26e8ab6966e98544db1262dadd218d703e39fdf999e029ed6eac533f23ac8)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) key property.

            Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagSpecificationSetItemItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.TagType",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "tag": "tag", "value": "value"},
    )
    class TagType:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tag.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag: (experimental) tag property. Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                tag_type = ec2_events.AWSAPICallViaCloudTrail.TagType(
                    key=["key"],
                    tag=["tag"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e4de976dec9959e29ddb4d260bb8efd5b281b2d6af640774b0cd2bd563e1f8a8)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument tag", value=tag, expected_type=type_hints["tag"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if tag is not None:
                self._values["tag"] = tag
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tag property.

            Specify an array of string values to match this event if the actual value of tag is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TagType(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.TargetCapacitySpecification",
        jsii_struct_bases=[],
        name_mapping={
            "default_target_capacity_type": "defaultTargetCapacityType",
            "on_demand_target_capacity": "onDemandTargetCapacity",
            "spot_target_capacity": "spotTargetCapacity",
            "total_target_capacity": "totalTargetCapacity",
        },
    )
    class TargetCapacitySpecification:
        def __init__(
            self,
            *,
            default_target_capacity_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            on_demand_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            total_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TargetCapacitySpecification.

            :param default_target_capacity_type: (experimental) DefaultTargetCapacityType property. Specify an array of string values to match this event if the actual value of DefaultTargetCapacityType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param on_demand_target_capacity: (experimental) OnDemandTargetCapacity property. Specify an array of string values to match this event if the actual value of OnDemandTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_target_capacity: (experimental) SpotTargetCapacity property. Specify an array of string values to match this event if the actual value of SpotTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param total_target_capacity: (experimental) TotalTargetCapacity property. Specify an array of string values to match this event if the actual value of TotalTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                target_capacity_specification = ec2_events.AWSAPICallViaCloudTrail.TargetCapacitySpecification(
                    default_target_capacity_type=["defaultTargetCapacityType"],
                    on_demand_target_capacity=["onDemandTargetCapacity"],
                    spot_target_capacity=["spotTargetCapacity"],
                    total_target_capacity=["totalTargetCapacity"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1993de2553a1610259e5b2752a8a855d452efc59d31501f38f01db0edb6ca752)
                check_type(argname="argument default_target_capacity_type", value=default_target_capacity_type, expected_type=type_hints["default_target_capacity_type"])
                check_type(argname="argument on_demand_target_capacity", value=on_demand_target_capacity, expected_type=type_hints["on_demand_target_capacity"])
                check_type(argname="argument spot_target_capacity", value=spot_target_capacity, expected_type=type_hints["spot_target_capacity"])
                check_type(argname="argument total_target_capacity", value=total_target_capacity, expected_type=type_hints["total_target_capacity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if default_target_capacity_type is not None:
                self._values["default_target_capacity_type"] = default_target_capacity_type
            if on_demand_target_capacity is not None:
                self._values["on_demand_target_capacity"] = on_demand_target_capacity
            if spot_target_capacity is not None:
                self._values["spot_target_capacity"] = spot_target_capacity
            if total_target_capacity is not None:
                self._values["total_target_capacity"] = total_target_capacity

        @builtins.property
        def default_target_capacity_type(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) DefaultTargetCapacityType property.

            Specify an array of string values to match this event if the actual value of DefaultTargetCapacityType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("default_target_capacity_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def on_demand_target_capacity(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) OnDemandTargetCapacity property.

            Specify an array of string values to match this event if the actual value of OnDemandTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("on_demand_target_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_target_capacity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SpotTargetCapacity property.

            Specify an array of string values to match this event if the actual value of SpotTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_target_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def total_target_capacity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TotalTargetCapacity property.

            Specify an array of string values to match this event if the actual value of TotalTargetCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("total_target_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TargetCapacitySpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.AWSAPICallViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={
            "access_key_id": "accessKeyId",
            "account_id": "accountId",
            "arn": "arn",
            "invoked_by": "invokedBy",
            "principal_id": "principalId",
            "session_context": "sessionContext",
            "type": "type",
        },
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_context: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionContext", typing.Dict[builtins.str, typing.Any]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param access_key_id: (experimental) accessKeyId property. Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param invoked_by: (experimental) invokedBy property. Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_context: (experimental) sessionContext property. Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                user_identity = ec2_events.AWSAPICallViaCloudTrail.UserIdentity(
                    access_key_id=["accessKeyId"],
                    account_id=["accountId"],
                    arn=["arn"],
                    invoked_by=["invokedBy"],
                    principal_id=["principalId"],
                    session_context=ec2_events.AWSAPICallViaCloudTrail.SessionContext(
                        attributes=ec2_events.AWSAPICallViaCloudTrail.Attributes(
                            creation_date=["creationDate"],
                            mfa_authenticated=["mfaAuthenticated"]
                        ),
                        session_issuer=ec2_events.AWSAPICallViaCloudTrail.SessionIssuer(
                            account_id=["accountId"],
                            arn=["arn"],
                            principal_id=["principalId"],
                            type=["type"],
                            user_name=["userName"]
                        ),
                        web_id_federation_data=["webIdFederationData"]
                    ),
                    type=["type"]
                )
            '''
            if isinstance(session_context, dict):
                session_context = AWSAPICallViaCloudTrail.SessionContext(**session_context)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8d00ecb276f2303f7576635652ec1ecd0c1baa249ce2dc8c439d60e93eef2960)
                check_type(argname="argument access_key_id", value=access_key_id, expected_type=type_hints["access_key_id"])
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument invoked_by", value=invoked_by, expected_type=type_hints["invoked_by"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument session_context", value=session_context, expected_type=type_hints["session_context"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if access_key_id is not None:
                self._values["access_key_id"] = access_key_id
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if invoked_by is not None:
                self._values["invoked_by"] = invoked_by
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if session_context is not None:
                self._values["session_context"] = session_context
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def access_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accessKeyId property.

            Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("access_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def invoked_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) invokedBy property.

            Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invoked_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_context(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionContext"]:
            '''(experimental) sessionContext property.

            Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_context")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionContext"], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EBSMultiVolumeSnapshotsCompletionStatus(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EBSMultiVolumeSnapshotsCompletionStatus",
):
    '''(experimental) EventBridge event pattern for aws.ec2@EBSMultiVolumeSnapshotsCompletionStatus.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
        
        e_bSMulti_volume_snapshots_completion_status = ec2_events.EBSMultiVolumeSnapshotsCompletionStatus()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="ebsMultiVolumeSnapshotsCompletionStatusPattern")
    @builtins.classmethod
    def ebs_multi_volume_snapshots_completion_status_pattern(
        cls,
        *,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        result: typing.Optional[typing.Sequence[builtins.str]] = None,
        snapshots: typing.Optional[typing.Sequence[typing.Union["EBSMultiVolumeSnapshotsCompletionStatus.Snapshot", typing.Dict[builtins.str, typing.Any]]]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EBS Multi-Volume Snapshots Completion Status.

        :param cause: (experimental) cause property. Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param request_id: (experimental) request-id property. Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param result: (experimental) result property. Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param snapshots: (experimental) snapshots property. Specify an array of string values to match this event if the actual value of snapshots is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EBSMultiVolumeSnapshotsCompletionStatus.EBSMultiVolumeSnapshotsCompletionStatusProps(
            cause=cause,
            end_time=end_time,
            event=event,
            event_metadata=event_metadata,
            request_id=request_id,
            result=result,
            snapshots=snapshots,
            start_time=start_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "ebsMultiVolumeSnapshotsCompletionStatusPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EBSMultiVolumeSnapshotsCompletionStatus.EBSMultiVolumeSnapshotsCompletionStatusProps",
        jsii_struct_bases=[],
        name_mapping={
            "cause": "cause",
            "end_time": "endTime",
            "event": "event",
            "event_metadata": "eventMetadata",
            "request_id": "requestId",
            "result": "result",
            "snapshots": "snapshots",
            "start_time": "startTime",
        },
    )
    class EBSMultiVolumeSnapshotsCompletionStatusProps:
        def __init__(
            self,
            *,
            cause: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            result: typing.Optional[typing.Sequence[builtins.str]] = None,
            snapshots: typing.Optional[typing.Sequence[typing.Union["EBSMultiVolumeSnapshotsCompletionStatus.Snapshot", typing.Dict[builtins.str, typing.Any]]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ec2@EBSMultiVolumeSnapshotsCompletionStatus event.

            :param cause: (experimental) cause property. Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param request_id: (experimental) request-id property. Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param result: (experimental) result property. Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param snapshots: (experimental) snapshots property. Specify an array of string values to match this event if the actual value of snapshots is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                e_bSMulti_volume_snapshots_completion_status_props = ec2_events.EBSMultiVolumeSnapshotsCompletionStatus.EBSMultiVolumeSnapshotsCompletionStatusProps(
                    cause=["cause"],
                    end_time=["endTime"],
                    event=["event"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    request_id=["requestId"],
                    result=["result"],
                    snapshots=[ec2_events.EBSMultiVolumeSnapshotsCompletionStatus.Snapshot(
                        snapshot_id=["snapshotId"],
                        source=["source"],
                        status=["status"]
                    )],
                    start_time=["startTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f50ff83e7961398decb368943839d7a1446781d9a35629d13f44a4e85b86cbff)
                check_type(argname="argument cause", value=cause, expected_type=type_hints["cause"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument result", value=result, expected_type=type_hints["result"])
                check_type(argname="argument snapshots", value=snapshots, expected_type=type_hints["snapshots"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cause is not None:
                self._values["cause"] = cause
            if end_time is not None:
                self._values["end_time"] = end_time
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if request_id is not None:
                self._values["request_id"] = request_id
            if result is not None:
                self._values["result"] = result
            if snapshots is not None:
                self._values["snapshots"] = snapshots
            if start_time is not None:
                self._values["start_time"] = start_time

        @builtins.property
        def cause(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) cause property.

            Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cause")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event property.

            Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) request-id property.

            Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def result(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) result property.

            Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("result")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def snapshots(
            self,
        ) -> typing.Optional[typing.List["EBSMultiVolumeSnapshotsCompletionStatus.Snapshot"]]:
            '''(experimental) snapshots property.

            Specify an array of string values to match this event if the actual value of snapshots is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("snapshots")
            return typing.cast(typing.Optional[typing.List["EBSMultiVolumeSnapshotsCompletionStatus.Snapshot"]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EBSMultiVolumeSnapshotsCompletionStatusProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EBSMultiVolumeSnapshotsCompletionStatus.Snapshot",
        jsii_struct_bases=[],
        name_mapping={
            "snapshot_id": "snapshotId",
            "source": "source",
            "status": "status",
        },
    )
    class Snapshot:
        def __init__(
            self,
            *,
            snapshot_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            source: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Snapshot.

            :param snapshot_id: (experimental) snapshot_id property. Specify an array of string values to match this event if the actual value of snapshot_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                snapshot = ec2_events.EBSMultiVolumeSnapshotsCompletionStatus.Snapshot(
                    snapshot_id=["snapshotId"],
                    source=["source"],
                    status=["status"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__bf28b3defd2e5583ca5afa741a78b1deb43b395dad0fbaa3f70269b748a49485)
                check_type(argname="argument snapshot_id", value=snapshot_id, expected_type=type_hints["snapshot_id"])
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if snapshot_id is not None:
                self._values["snapshot_id"] = snapshot_id
            if source is not None:
                self._values["source"] = source
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def snapshot_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) snapshot_id property.

            Specify an array of string values to match this event if the actual value of snapshot_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("snapshot_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Snapshot(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EBSSnapshotNotification(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EBSSnapshotNotification",
):
    '''(experimental) EventBridge event pattern for aws.ec2@EBSSnapshotNotification.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
        
        e_bSSnapshot_notification = ec2_events.EBSSnapshotNotification()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="ebsSnapshotNotificationPattern")
    @builtins.classmethod
    def ebs_snapshot_notification_pattern(
        cls,
        *,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        result: typing.Optional[typing.Sequence[builtins.str]] = None,
        snapshot_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        source: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EBS Snapshot Notification.

        :param cause: (experimental) cause property. Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param request_id: (experimental) request-id property. Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param result: (experimental) result property. Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param snapshot_id: (experimental) snapshot_id property. Specify an array of string values to match this event if the actual value of snapshot_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EBSSnapshotNotification.EBSSnapshotNotificationProps(
            cause=cause,
            end_time=end_time,
            event=event,
            event_metadata=event_metadata,
            request_id=request_id,
            result=result,
            snapshot_id=snapshot_id,
            source=source,
            start_time=start_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "ebsSnapshotNotificationPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EBSSnapshotNotification.EBSSnapshotNotificationProps",
        jsii_struct_bases=[],
        name_mapping={
            "cause": "cause",
            "end_time": "endTime",
            "event": "event",
            "event_metadata": "eventMetadata",
            "request_id": "requestId",
            "result": "result",
            "snapshot_id": "snapshotId",
            "source": "source",
            "start_time": "startTime",
        },
    )
    class EBSSnapshotNotificationProps:
        def __init__(
            self,
            *,
            cause: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            result: typing.Optional[typing.Sequence[builtins.str]] = None,
            snapshot_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            source: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ec2@EBSSnapshotNotification event.

            :param cause: (experimental) cause property. Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param request_id: (experimental) request-id property. Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param result: (experimental) result property. Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param snapshot_id: (experimental) snapshot_id property. Specify an array of string values to match this event if the actual value of snapshot_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                e_bSSnapshot_notification_props = ec2_events.EBSSnapshotNotification.EBSSnapshotNotificationProps(
                    cause=["cause"],
                    end_time=["endTime"],
                    event=["event"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    request_id=["requestId"],
                    result=["result"],
                    snapshot_id=["snapshotId"],
                    source=["source"],
                    start_time=["startTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6ebaf3913cbc1886df537023e6fad1c0fc63fe9f6780e25e1f2e00f1a2389482)
                check_type(argname="argument cause", value=cause, expected_type=type_hints["cause"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument result", value=result, expected_type=type_hints["result"])
                check_type(argname="argument snapshot_id", value=snapshot_id, expected_type=type_hints["snapshot_id"])
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cause is not None:
                self._values["cause"] = cause
            if end_time is not None:
                self._values["end_time"] = end_time
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if request_id is not None:
                self._values["request_id"] = request_id
            if result is not None:
                self._values["result"] = result
            if snapshot_id is not None:
                self._values["snapshot_id"] = snapshot_id
            if source is not None:
                self._values["source"] = source
            if start_time is not None:
                self._values["start_time"] = start_time

        @builtins.property
        def cause(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) cause property.

            Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cause")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndTime property.

            Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event property.

            Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) request-id property.

            Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def result(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) result property.

            Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("result")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def snapshot_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) snapshot_id property.

            Specify an array of string values to match this event if the actual value of snapshot_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("snapshot_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StartTime property.

            Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EBSSnapshotNotificationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EBSVolumeNotification(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EBSVolumeNotification",
):
    '''(experimental) EventBridge event pattern for aws.ec2@EBSVolumeNotification.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
        
        e_bSVolume_notification = ec2_events.EBSVolumeNotification()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="ebsVolumeNotificationPattern")
    @builtins.classmethod
    def ebs_volume_notification_pattern(
        cls,
        *,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        result: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EBS Volume Notification.

        :param cause: (experimental) cause property. Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param request_id: (experimental) request-id property. Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param result: (experimental) result property. Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EBSVolumeNotification.EBSVolumeNotificationProps(
            cause=cause,
            event=event,
            event_metadata=event_metadata,
            request_id=request_id,
            result=result,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "ebsVolumeNotificationPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EBSVolumeNotification.EBSVolumeNotificationProps",
        jsii_struct_bases=[],
        name_mapping={
            "cause": "cause",
            "event": "event",
            "event_metadata": "eventMetadata",
            "request_id": "requestId",
            "result": "result",
        },
    )
    class EBSVolumeNotificationProps:
        def __init__(
            self,
            *,
            cause: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            result: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ec2@EBSVolumeNotification event.

            :param cause: (experimental) cause property. Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param request_id: (experimental) request-id property. Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param result: (experimental) result property. Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                e_bSVolume_notification_props = ec2_events.EBSVolumeNotification.EBSVolumeNotificationProps(
                    cause=["cause"],
                    event=["event"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    request_id=["requestId"],
                    result=["result"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fb5e4b50082dd7ca7c0f73d5dde1cbe7e4005411f39f6c546c05b10259605b5c)
                check_type(argname="argument cause", value=cause, expected_type=type_hints["cause"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument result", value=result, expected_type=type_hints["result"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cause is not None:
                self._values["cause"] = cause
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if request_id is not None:
                self._values["request_id"] = request_id
            if result is not None:
                self._values["result"] = result

        @builtins.property
        def cause(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) cause property.

            Specify an array of string values to match this event if the actual value of cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cause")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event property.

            Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) request-id property.

            Specify an array of string values to match this event if the actual value of request-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def result(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) result property.

            Specify an array of string values to match this event if the actual value of result is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("result")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EBSVolumeNotificationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2FastLaunchStateChangeNotification(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EC2FastLaunchStateChangeNotification",
):
    '''(experimental) EventBridge event pattern for aws.ec2@EC2FastLaunchStateChangeNotification.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
        
        e_c2_fast_launch_state_change_notification = ec2_events.EC2FastLaunchStateChangeNotification()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="ec2FastLaunchStateChangeNotificationPattern")
    @builtins.classmethod
    def ec2_fast_launch_state_change_notification_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        state_transition_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Fast Launch State-change Notification.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param image_id: (experimental) imageId property. Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_type: (experimental) resourceType property. Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state_transition_reason: (experimental) stateTransitionReason property. Specify an array of string values to match this event if the actual value of stateTransitionReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2FastLaunchStateChangeNotification.EC2FastLaunchStateChangeNotificationProps(
            event_metadata=event_metadata,
            image_id=image_id,
            resource_type=resource_type,
            state=state,
            state_transition_reason=state_transition_reason,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "ec2FastLaunchStateChangeNotificationPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EC2FastLaunchStateChangeNotification.EC2FastLaunchStateChangeNotificationProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "image_id": "imageId",
            "resource_type": "resourceType",
            "state": "state",
            "state_transition_reason": "stateTransitionReason",
        },
    )
    class EC2FastLaunchStateChangeNotificationProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            state_transition_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ec2@EC2FastLaunchStateChangeNotification event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param image_id: (experimental) imageId property. Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_type: (experimental) resourceType property. Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state_transition_reason: (experimental) stateTransitionReason property. Specify an array of string values to match this event if the actual value of stateTransitionReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                e_c2_fast_launch_state_change_notification_props = ec2_events.EC2FastLaunchStateChangeNotification.EC2FastLaunchStateChangeNotificationProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    image_id=["imageId"],
                    resource_type=["resourceType"],
                    state=["state"],
                    state_transition_reason=["stateTransitionReason"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__beb7781e4684f1bea63ac4bbbce3a5cd013d1526a9fd29359dac89aaf23b5cc7)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument image_id", value=image_id, expected_type=type_hints["image_id"])
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument state_transition_reason", value=state_transition_reason, expected_type=type_hints["state_transition_reason"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if image_id is not None:
                self._values["image_id"] = image_id
            if resource_type is not None:
                self._values["resource_type"] = resource_type
            if state is not None:
                self._values["state"] = state
            if state_transition_reason is not None:
                self._values["state_transition_reason"] = state_transition_reason

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def image_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageId property.

            Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resourceType property.

            Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state_transition_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stateTransitionReason property.

            Specify an array of string values to match this event if the actual value of stateTransitionReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state_transition_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2FastLaunchStateChangeNotificationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2InstanceStateChangeNotification(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EC2InstanceStateChangeNotification",
):
    '''(experimental) EventBridge event pattern for aws.ec2@EC2InstanceStateChangeNotification.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
        
        e_c2_instance_state_change_notification = ec2_events.EC2InstanceStateChangeNotification()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="ec2InstanceStateChangeNotificationPattern")
    @builtins.classmethod
    def ec2_instance_state_change_notification_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Instance State-change Notification.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_id: (experimental) instance-id property. Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Instance reference
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceStateChangeNotification.EC2InstanceStateChangeNotificationProps(
            event_metadata=event_metadata, instance_id=instance_id, state=state
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "ec2InstanceStateChangeNotificationPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EC2InstanceStateChangeNotification.EC2InstanceStateChangeNotificationProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "instance_id": "instanceId",
            "state": "state",
        },
    )
    class EC2InstanceStateChangeNotificationProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ec2@EC2InstanceStateChangeNotification event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param instance_id: (experimental) instance-id property. Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Instance reference
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                e_c2_instance_state_change_notification_props = ec2_events.EC2InstanceStateChangeNotification.EC2InstanceStateChangeNotificationProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    instance_id=["instanceId"],
                    state=["state"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ced313051d54bee0aa7f56bb9e0dfb68f071a4c77338321566e4a85c0206fa63)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument instance_id", value=instance_id, expected_type=type_hints["instance_id"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if instance_id is not None:
                self._values["instance_id"] = instance_id
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instance-id property.

            Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Instance reference

            :stability: experimental
            '''
            result = self._values.get("instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2InstanceStateChangeNotificationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2SpotInstanceInterruptionWarning(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EC2SpotInstanceInterruptionWarning",
):
    '''(experimental) EventBridge event pattern for aws.ec2@EC2SpotInstanceInterruptionWarning.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
        
        e_c2_spot_instance_interruption_warning = ec2_events.EC2SpotInstanceInterruptionWarning()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="ec2SpotInstanceInterruptionWarningPattern")
    @builtins.classmethod
    def ec2_spot_instance_interruption_warning_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_action: typing.Optional[typing.Sequence[builtins.str]] = None,
        instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Spot Instance Interruption Warning.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_action: (experimental) instance-action property. Specify an array of string values to match this event if the actual value of instance-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param instance_id: (experimental) instance-id property. Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Instance reference

        :stability: experimental
        '''
        options = EC2SpotInstanceInterruptionWarning.EC2SpotInstanceInterruptionWarningProps(
            event_metadata=event_metadata,
            instance_action=instance_action,
            instance_id=instance_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "ec2SpotInstanceInterruptionWarningPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.EC2SpotInstanceInterruptionWarning.EC2SpotInstanceInterruptionWarningProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "instance_action": "instanceAction",
            "instance_id": "instanceId",
        },
    )
    class EC2SpotInstanceInterruptionWarningProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_action: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ec2@EC2SpotInstanceInterruptionWarning event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param instance_action: (experimental) instance-action property. Specify an array of string values to match this event if the actual value of instance-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_id: (experimental) instance-id property. Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Instance reference

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
                
                e_c2_spot_instance_interruption_warning_props = ec2_events.EC2SpotInstanceInterruptionWarning.EC2SpotInstanceInterruptionWarningProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    instance_action=["instanceAction"],
                    instance_id=["instanceId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__aa0067f161a3ac77ec180fb0e9c2da91e95c6db900831adc7d7ff67e94adddaf)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument instance_action", value=instance_action, expected_type=type_hints["instance_action"])
                check_type(argname="argument instance_id", value=instance_id, expected_type=type_hints["instance_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if instance_action is not None:
                self._values["instance_action"] = instance_action
            if instance_id is not None:
                self._values["instance_id"] = instance_id

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def instance_action(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instance-action property.

            Specify an array of string values to match this event if the actual value of instance-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_action")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instance-id property.

            Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Instance reference

            :stability: experimental
            '''
            result = self._values.get("instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2SpotInstanceInterruptionWarningProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class InstanceEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.events.InstanceEvents",
):
    '''(experimental) EventBridge event patterns for Instance.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import events as ec2_events
        from aws_cdk.interfaces import aws_ec2 as interfaces_ec2
        
        # instance_ref: interfaces_ec2.IInstanceRef
        
        instance_events = ec2_events.InstanceEvents.from_instance(instance_ref)
    '''

    @jsii.member(jsii_name="fromInstance")
    @builtins.classmethod
    def from_instance(
        cls,
        instance_ref: "_aws_cdk_interfaces_aws_ec2_ceddda9d.IInstanceRef",
    ) -> "InstanceEvents":
        '''(experimental) Create InstanceEvents from a Instance reference.

        :param instance_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5352af6d26a80d213c38949b3d48fe4eb34e4981293dfa424dc3a3055df2e5d)
            check_type(argname="argument instance_ref", value=instance_ref, expected_type=type_hints["instance_ref"])
        return typing.cast("InstanceEvents", jsii.sinvoke(cls, "fromInstance", [instance_ref]))

    @jsii.member(jsii_name="awsAPICallViaCloudTrailPattern")
    def aws_api_call_via_cloud_trail_pattern(
        self,
        *,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Instance AWS API Call via CloudTrail.

        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            aws_region=aws_region,
            error_code=error_code,
            error_message=error_message,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            request_id=request_id,
            request_parameters=request_parameters,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "awsAPICallViaCloudTrailPattern", [options]))

    @jsii.member(jsii_name="ec2InstanceStateChangeNotificationPattern")
    def ec2_instance_state_change_notification_pattern(
        self,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Instance EC2 Instance State-change Notification.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_id: (experimental) instance-id property. Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Instance reference
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceStateChangeNotification.EC2InstanceStateChangeNotificationProps(
            event_metadata=event_metadata, instance_id=instance_id, state=state
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ec2InstanceStateChangeNotificationPattern", [options]))

    @jsii.member(jsii_name="ec2SpotInstanceInterruptionWarningPattern")
    def ec2_spot_instance_interruption_warning_pattern(
        self,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_action: typing.Optional[typing.Sequence[builtins.str]] = None,
        instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Instance EC2 Spot Instance Interruption Warning.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_action: (experimental) instance-action property. Specify an array of string values to match this event if the actual value of instance-action is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param instance_id: (experimental) instance-id property. Specify an array of string values to match this event if the actual value of instance-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Instance reference

        :stability: experimental
        '''
        options = EC2SpotInstanceInterruptionWarning.EC2SpotInstanceInterruptionWarningProps(
            event_metadata=event_metadata,
            instance_action=instance_action,
            instance_id=instance_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ec2SpotInstanceInterruptionWarningPattern", [options]))


__all__ = [
    "AWSAPICallViaCloudTrail",
    "EBSMultiVolumeSnapshotsCompletionStatus",
    "EBSSnapshotNotification",
    "EBSVolumeNotification",
    "EC2FastLaunchStateChangeNotification",
    "EC2InstanceStateChangeNotification",
    "EC2SpotInstanceInterruptionWarning",
    "InstanceEvents",
]

publication.publish()

def _typecheckingstub__1ec5a9de6d274a0402bbfec1ff340c5b59cd1db812d99a08aad503dd2419b79b(
    *,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RequestParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    response_elements: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResponseElements, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c007ee184f83a686d25d0de7516b15ced8fe69a12215bda8e135aa0e6fb79b40(
    *,
    attachment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    attach_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    delete_on_termination: typing.Optional[typing.Sequence[builtins.str]] = None,
    device_index: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a89147380c9c222add9c28309b5799b1a6c618c1d0e5a938f06fa86423c4f6c3(
    *,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__64d3e0c46700fbd1d80e27349241c7d36ae1d1f1c16d93a4cecd89fe16f7e88a(
    *,
    capacity_reservation_preference: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff5d15036c820f164153db7d3a9cfec3a418468d0b66eef7beab9c400bdd044b(
    *,
    core_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    threads_per_core: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7547d125c8c0ed53fdfac255854fb563ba2ebfd3be3b654aa1e731c74c37b30c(
    *,
    client_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    existing_instances: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ExistingInstances, typing.Dict[builtins.str, typing.Any]]] = None,
    launch_template_configs: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LaunchTemplateConfigs, typing.Dict[builtins.str, typing.Any]]] = None,
    on_demand_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.OnDemandOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    spot_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SpotOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    tag_specification: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TagSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    target_capacity_specification: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TargetCapacitySpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae7f744fd77b75354d4d99268b7a9bc2d2edc440f8637c452064b4f94c62a023(
    *,
    error_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    fleet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    fleet_instance_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    xmlns: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e524f29c35f69fa0d98f369c20eeee8992642e9627d524e39a6e530c31f66f23(
    *,
    launch_template_data: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LaunchTemplateData, typing.Dict[builtins.str, typing.Any]]] = None,
    launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86d51a887d994ae007585d949c55da62f771e53cf16037e01b96cf0eb3d19449(
    *,
    launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8edb604618da02ff24f7e032e45ee78e7f6a64608e37b98b475cde540ea5863(
    *,
    launch_template: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LaunchTemplate1, typing.Dict[builtins.str, typing.Any]]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    xmlns: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a995cf4e972c7c848295c54bc1a6dfb93cfc1557922e5477d3998cfcb9cce0f(
    *,
    enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5effead7d091050f3adb1e8a36eee7e9609f233c368426f2216b049fda1cc425(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    count: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    market_option: typing.Optional[typing.Sequence[builtins.str]] = None,
    operating_system: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7b18ba385b80a522eedea14032f63e0122c6cfda77a7b2c192026ed421c809f7(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.GroupSet1Item, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d13fbdba024b942dcf9c8f1356eb056e15453cc517e6f1e0938006425b753f7(
    *,
    group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f83e8612294cccda92b6c577d0229f9759578b4b64bc0dd040e2c0ab43d7d312(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.GroupSet2Item, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f44e2a7a16e53d5ce3c7514c771b037407941ceeb8c8e607ef068bf31b559fa7(
    *,
    group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0d9a7ce24bdcb90d11b6af8179399c5eee43494db0a6c531d8d7b092c7ce7b68(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.GroupSet2Item, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0d1c678c612dc11b784b0fc8a6fd9b19889cf047afa7fa056d76afa7c861bb59(
    *,
    market_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SpotOptions1, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6b9cf942f7317f5f8fbb44e3b1a816ab7a05bea0971b34634a685121e83e71da(
    *,
    market_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SpotOptions2, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39b18057b8463e891a8afe1714fbc05e84171e650d58a0237a976aaaa6977c7d(
    *,
    code: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4b64d6ddffd257ee940d833e700892c4b902e22f4311a1991a15edded3a10b25(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.InstancesSetItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd86a4a071eeafdeb128115410bf83727d43ccdb07ddce3ce4ba483088f01133(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.InstancesSet1Item, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a73efea3a05946091384729c5fb457cea460b4bfb89589eafdf27b45eb357a2(
    *,
    image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    max_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    min_count: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__42484b161b8712116727fc2ca55d7bbe3476cd9bbb81e1d429442542c783a7d2(
    *,
    ami_launch_index: typing.Optional[typing.Sequence[builtins.str]] = None,
    architecture: typing.Optional[typing.Sequence[builtins.str]] = None,
    block_device_mapping: typing.Optional[typing.Sequence[builtins.str]] = None,
    capacity_reservation_specification: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.CapacityReservationSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    client_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    cpu_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.CpuOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    current_state: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.InstanceState, typing.Dict[builtins.str, typing.Any]]] = None,
    ebs_optimized: typing.Optional[typing.Sequence[builtins.str]] = None,
    enclave_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.EnclaveOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    group_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.GroupSet2, typing.Dict[builtins.str, typing.Any]]] = None,
    hypervisor: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_lifecycle: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_state: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.InstanceState, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    launch_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    monitoring: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Monitoring1, typing.Dict[builtins.str, typing.Any]]] = None,
    network_interface_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.NetworkInterfaceSet1, typing.Dict[builtins.str, typing.Any]]] = None,
    placement: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Placement, typing.Dict[builtins.str, typing.Any]]] = None,
    previous_state: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.InstanceState, typing.Dict[builtins.str, typing.Any]]] = None,
    private_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    product_codes: typing.Optional[typing.Sequence[builtins.str]] = None,
    root_device_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    root_device_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_dest_check: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_instance_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    state_reason: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.StateReason, typing.Dict[builtins.str, typing.Any]]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TagSet, typing.Dict[builtins.str, typing.Any]]] = None,
    virtualization_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6b02dd57a17ed92ce3c563a56461e97038d541402054fced14d393c8a5262bd(
    *,
    launch_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae23195861dfab6957e3969521bb1de527ba282c1ef91288e68c688c40ba9e02(
    *,
    created_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    create_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    default_version_number: typing.Optional[typing.Sequence[builtins.str]] = None,
    latest_version_number: typing.Optional[typing.Sequence[builtins.str]] = None,
    launch_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2de44ddd198bf3077e7a0cb61ef48e20d594819fc8ec2eacb5b6d7f2fce4c70d(
    *,
    launch_template_specification: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LaunchTemplateSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    overrides: typing.Optional[typing.Sequence[typing.Any]] = None,
    tag: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6137738b68cd890072733e093d37dc518975772fc5d4fb108fd1c9b67dd3387b(
    *,
    image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_market_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.InstanceMarketOptions1, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    network_interface: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.NetworkInterface1, typing.Dict[builtins.str, typing.Any]]] = None,
    user_data: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__867de257c80f2e55bf5c584b2da21bbc1c15be800b22313c781b2fdc8bad6dce(
    *,
    launch_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff36a2ff2d5ab6a912b5bf30be63bf6c8c779675b12a66899e2032eea5339387(
    *,
    enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e69797ed5d0717b16a33ccf546a0778e5135c18aff3d60c8240ae63602ec9000(
    *,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__227a4ab6271e6466be8a2376963953f64ac92718da8e1414f6a1883d4f459556(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.GroupSet2, typing.Dict[builtins.str, typing.Any]]] = None,
    interface_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ipv6_addresses_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    mac_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    network_interface_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    owner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    private_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    private_ip_addresses_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.PrivateIpAddressesSet1, typing.Dict[builtins.str, typing.Any]]] = None,
    requester_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    requester_managed: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_dest_check: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f701145fa972f02164ece715c83ae36f13c563dbb1c2a23db6abb2468d69263(
    *,
    device_index: typing.Optional[typing.Sequence[builtins.str]] = None,
    security_group_id: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SecurityGroupId, typing.Dict[builtins.str, typing.Any]]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dfe5d045bebb4a815d86bb693eb0ea5a0d005f6961a06b13ab6cfa2a3617b9c1(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.NetworkInterfaceSetItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__935a809d9aae02a1902f58cca94d7e0b6accf53571a11dd4dac1aa2e424746ce(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.NetworkInterfaceSet1Item, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__234fc55af9c35150f40f2ed131edd4f881ed14ac2facae4332c936cd720c0d01(
    *,
    attachment: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Attachment, typing.Dict[builtins.str, typing.Any]]] = None,
    group_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.GroupSet3, typing.Dict[builtins.str, typing.Any]]] = None,
    interface_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ipv6_addresses_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    mac_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    network_interface_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    owner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    private_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    private_ip_addresses_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.PrivateIpAddressesSet2, typing.Dict[builtins.str, typing.Any]]] = None,
    source_dest_check: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71214443057156c8f21d62b351580ee3b0e125c9f98f3c59f4360791f0b82685(
    *,
    device_index: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c6087aa2f7aed0a7621b93f00e7c49f1c80dbc0740018cc8c5a1cd7de82b60b(
    *,
    allocation_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_pool_constraint_filter_disabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    max_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    max_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50d0019ceecb32aad35e3743c9d429ac6894322cb6d6380e93c00c2270975b8b(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    tenancy: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dec63858da94f952dca6b37369e5d4277acd2ae0fc157aca6d39a8418eafcf4b(
    *,
    item: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b19a31d9426c010252919d38eca5406af14bf08b2fd99640b7099656591dddf5(
    *,
    primary: typing.Optional[typing.Sequence[builtins.str]] = None,
    private_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d78f3ccd670241d50c93858fff3a0dc886e933187029029af24be088a423341e(
    *,
    item: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.PrivateIpAddressesSet1Item, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5838fd13b1d0c4446f0f4c64847c4a0bd62e31448fa6cca3f9c92da6712503f9(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    block_device_mapping: typing.Optional[typing.Sequence[builtins.str]] = None,
    client_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    create_fleet_request: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.CreateFleetRequest, typing.Dict[builtins.str, typing.Any]]] = None,
    create_launch_template_request: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.CreateLaunchTemplateRequest, typing.Dict[builtins.str, typing.Any]]] = None,
    delete_launch_template_request: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.DeleteLaunchTemplateRequest, typing.Dict[builtins.str, typing.Any]]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    disable_api_termination: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.GroupSet1, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_market_options: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.InstanceMarketOptions, typing.Dict[builtins.str, typing.Any]]] = None,
    instances_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.InstancesSet1, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ipv6_address_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    launch_template: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LaunchTemplate, typing.Dict[builtins.str, typing.Any]]] = None,
    monitoring: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Monitoring, typing.Dict[builtins.str, typing.Any]]] = None,
    network_interface_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    network_interface_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.NetworkInterfaceSet, typing.Dict[builtins.str, typing.Any]]] = None,
    private_ip_addresses_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_specification_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TagSpecificationSet, typing.Dict[builtins.str, typing.Any]]] = None,
    user_data: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a2078912c38e252d2463542147c932e78733bdfa4dc7772eca9f30ca32ff2edd(
    *,
    create_fleet_response: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.CreateFleetResponse, typing.Dict[builtins.str, typing.Any]]] = None,
    create_launch_template_response: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse, typing.Dict[builtins.str, typing.Any]]] = None,
    delete_launch_template_response: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.DeleteLaunchTemplateResponse, typing.Dict[builtins.str, typing.Any]]] = None,
    group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    instances_set: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.InstancesSet, typing.Dict[builtins.str, typing.Any]]] = None,
    network_interface: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.NetworkInterface, typing.Dict[builtins.str, typing.Any]]] = None,
    owner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    requester_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    reservation_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    return_: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cfc6e4614f11a43a56d28bc20cedad2944fe2ce266a43728c9dbe4408e38fca6(
    *,
    content: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26eaa0a248c1be55791562b5e3737d7cdb8870d5ecc272f249e30dbeb8514b2f(
    *,
    attributes: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    session_issuer: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionIssuer, typing.Dict[builtins.str, typing.Any]]] = None,
    web_id_federation_data: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae0b8ca0f99bf4bf39b296f5a66cdb3186f1799d5da18a1e6dabd35086c6b273(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__185430d2de7bdd627819fa67eda750e9ca5e81f78076ad72583f9a74ce6a23c4(
    *,
    allocation_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_pool_constraint_filter_disabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_pools_to_use_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    max_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    max_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6256d41ebac4fd87d7f7f965e082e7b129262089c9d320bcf1470a3e3b02f49(
    *,
    max_price: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7476a676b2c0c60b652fa0c37bac760f2b86586a571174b667980bba4e90e1e1(
    *,
    max_price: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e65d09b268e1952ab0154274ec573037d6ddef72ada96d94b75e5e39e8b804fe(
    *,
    code: typing.Optional[typing.Sequence[builtins.str]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59fbfe02e5fa55f04ade5b49d29c1f4fc5f6d32a713551619d30320ce362816a(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.TagSpecificationSetItemItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db02c3d5a8b61948bb0f4a666b089eb59c0bfea280e5951d9cc700fbb0119407(
    *,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TagType, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be1088628136942d7361cfeb844d39b1d5b54e68a91e8da30b1d522478e4988e(
    *,
    items: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.TagSpecificationSetItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__375b1dce40b1e5623d30164987d00840948d983f7704f4b571edb904a3e84cba(
    *,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.TagSpecificationSetItemItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fb26e8ab6966e98544db1262dadd218d703e39fdf999e029ed6eac533f23ac8(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4de976dec9959e29ddb4d260bb8efd5b281b2d6af640774b0cd2bd563e1f8a8(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1993de2553a1610259e5b2752a8a855d452efc59d31501f38f01db0edb6ca752(
    *,
    default_target_capacity_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    on_demand_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    total_target_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8d00ecb276f2303f7576635652ec1ecd0c1baa249ce2dc8c439d60e93eef2960(
    *,
    access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_context: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionContext, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f50ff83e7961398decb368943839d7a1446781d9a35629d13f44a4e85b86cbff(
    *,
    cause: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    result: typing.Optional[typing.Sequence[builtins.str]] = None,
    snapshots: typing.Optional[typing.Sequence[typing.Union[EBSMultiVolumeSnapshotsCompletionStatus.Snapshot, typing.Dict[builtins.str, typing.Any]]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf28b3defd2e5583ca5afa741a78b1deb43b395dad0fbaa3f70269b748a49485(
    *,
    snapshot_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    source: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ebaf3913cbc1886df537023e6fad1c0fc63fe9f6780e25e1f2e00f1a2389482(
    *,
    cause: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    result: typing.Optional[typing.Sequence[builtins.str]] = None,
    snapshot_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    source: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb5e4b50082dd7ca7c0f73d5dde1cbe7e4005411f39f6c546c05b10259605b5c(
    *,
    cause: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    result: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__beb7781e4684f1bea63ac4bbbce3a5cd013d1526a9fd29359dac89aaf23b5cc7(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    state_transition_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ced313051d54bee0aa7f56bb9e0dfb68f071a4c77338321566e4a85c0206fa63(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aa0067f161a3ac77ec180fb0e9c2da91e95c6db900831adc7d7ff67e94adddaf(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_action: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5352af6d26a80d213c38949b3d48fe4eb34e4981293dfa424dc3a3055df2e5d(
    instance_ref: _aws_cdk_interfaces_aws_ec2_ceddda9d.IInstanceRef,
) -> None:
    """Type checking stubs"""
    pass
