from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnLoadBalancerAlbAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogs",
):
    '''Builder for CfnLoadBalancerLogsMixin to generate ALB_ACCESS_LOGS for CfnLoadBalancer.

    :cloudformationResource: AWS::ElasticLoadBalancingV2::LoadBalancer
    :logType: ALB_ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        cfn_load_balancer_alb_access_logs = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbAccessLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3900938e6762867d7df9d9603515e946eb140456b5115d6c14969a95c1814565)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnLoadBalancerAlbAccessLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbAccessLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__da9f58ba555763f5153f32a4f1434735e6e12ad72e8c7c309b2780a0e6de7b99)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnLoadBalancerAlbAccessLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbAccessLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9df044c183505d5260672d48a2023af1c99bb0fa3f7442f5cee38702b4d8cec6)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnLoadBalancerAlbAccessLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbAccessLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a350f6192f5ab738b6634cf77d711bd5fd2fda65e8672599c4abc8eba0e63ee)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnLoadBalancerAlbAccessLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnLoadBalancerAlbAccessLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_access_logs_dest_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsDestProps(
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bedf0543a7f447b71cb0da9bff0642fd9954abb863165ec926af2c3ca7a684a8)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbAccessLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLoadBalancerAlbAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_access_logs_firehose_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsFirehoseProps(
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose.JSON,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cff24782a65fa95e3f85c0f087303a68ccf07970a45ab517d0738d1f263afeaa)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLoadBalancerAlbAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_access_logs_log_group_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsLogGroupProps(
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f761f955e04f24622f22506051aee1c8f911f59e581fae64d7c561c8158efcd6)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnLoadBalancerAlbAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnLoadBalancerAlbAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        cfn_load_balancer_alb_access_logs_output_format = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsRecordFields"
)
class CfnLoadBalancerAlbAccessLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    TIME = "TIME"
    '''
    :stability: experimental
    '''
    ELB = "ELB"
    '''
    :stability: experimental
    '''
    CLIENT_PORT = "CLIENT_PORT"
    '''
    :stability: experimental
    '''
    TARGET_PORT = "TARGET_PORT"
    '''
    :stability: experimental
    '''
    REQUEST_PROCESSING_TIME = "REQUEST_PROCESSING_TIME"
    '''
    :stability: experimental
    '''
    TARGET_PROCESSING_TIME = "TARGET_PROCESSING_TIME"
    '''
    :stability: experimental
    '''
    RESPONSE_PROCESSING_TIME = "RESPONSE_PROCESSING_TIME"
    '''
    :stability: experimental
    '''
    ELB_STATUS_CODE = "ELB_STATUS_CODE"
    '''
    :stability: experimental
    '''
    TARGET_STATUS_CODE = "TARGET_STATUS_CODE"
    '''
    :stability: experimental
    '''
    RECEIVED_BYTES = "RECEIVED_BYTES"
    '''
    :stability: experimental
    '''
    SENT_BYTES = "SENT_BYTES"
    '''
    :stability: experimental
    '''
    REQUEST_LINE = "REQUEST_LINE"
    '''
    :stability: experimental
    '''
    USER_AGENT = "USER_AGENT"
    '''
    :stability: experimental
    '''
    SSL_CIPHER = "SSL_CIPHER"
    '''
    :stability: experimental
    '''
    SSL_PROTOCOL = "SSL_PROTOCOL"
    '''
    :stability: experimental
    '''
    TARGET_GROUP_ARN = "TARGET_GROUP_ARN"
    '''
    :stability: experimental
    '''
    TRACE_ID = "TRACE_ID"
    '''
    :stability: experimental
    '''
    DOMAIN_NAME = "DOMAIN_NAME"
    '''
    :stability: experimental
    '''
    CHOSEN_CERT_ARN = "CHOSEN_CERT_ARN"
    '''
    :stability: experimental
    '''
    MATCHED_RULE_PRIORITY = "MATCHED_RULE_PRIORITY"
    '''
    :stability: experimental
    '''
    REQUEST_CREATION_TIME = "REQUEST_CREATION_TIME"
    '''
    :stability: experimental
    '''
    ACTIONS_EXECUTED = "ACTIONS_EXECUTED"
    '''
    :stability: experimental
    '''
    REDIRECT_URL = "REDIRECT_URL"
    '''
    :stability: experimental
    '''
    ERROR_REASON = "ERROR_REASON"
    '''
    :stability: experimental
    '''
    TARGET_PORT_LIST = "TARGET_PORT_LIST"
    '''
    :stability: experimental
    '''
    TARGET_STATUS_CODE_LIST = "TARGET_STATUS_CODE_LIST"
    '''
    :stability: experimental
    '''
    CLASSIFICATION = "CLASSIFICATION"
    '''
    :stability: experimental
    '''
    CLASSIFICATION_REASON = "CLASSIFICATION_REASON"
    '''
    :stability: experimental
    '''
    CONN_TRACE_ID = "CONN_TRACE_ID"
    '''
    :stability: experimental
    '''
    TRANSFORMED_HOST = "TRANSFORMED_HOST"
    '''
    :stability: experimental
    '''
    TRANSFORMED_URI = "TRANSFORMED_URI"
    '''
    :stability: experimental
    '''
    REQUEST_TRANSFORM_STATUS = "REQUEST_TRANSFORM_STATUS"
    '''
    :stability: experimental
    '''
    IP_ADDRESS = "IP_ADDRESS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnLoadBalancerAlbAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_load_balancer_alb_access_logs_s3_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsOutputFormat.S3.JSON,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbAccessLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83aa7523dbf108fdf45739086ac2df4da38ab19f7765b067ce271e9cfa63482f)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbAccessLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnLoadBalancerAlbConnectionLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogs",
):
    '''Builder for CfnLoadBalancerLogsMixin to generate ALB_CONNECTION_LOGS for CfnLoadBalancer.

    :cloudformationResource: AWS::ElasticLoadBalancingV2::LoadBalancer
    :logType: ALB_CONNECTION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        cfn_load_balancer_alb_connection_logs = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbConnectionLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7c84dd12dfa832707a2923e40be93ad57af8b718fecc937ee41f92a8e3d4a993)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnLoadBalancerAlbConnectionLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbConnectionLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7fb760f717360a21044b305578e8e339b448166e9065f3ee93d2769876a4c2dc)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnLoadBalancerAlbConnectionLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbConnectionLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9abf0e3179e266f22681af455f6e741dfa6f7d922f5d710be3b768e8f9567dbb)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnLoadBalancerAlbConnectionLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbConnectionLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25603aef57b2ace26218bdb2fe36719f4a9cfaf0cc707de58af8a08c76ba4b27)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnLoadBalancerAlbConnectionLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnLoadBalancerAlbConnectionLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_connection_logs_dest_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsDestProps(
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsRecordFields.TIME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__beb0ec90ae2738e01ea5197322ca4a8864ea3195f4ac927cc15d93cc920ceddb)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbConnectionLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLoadBalancerAlbConnectionLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_connection_logs_firehose_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsFirehoseProps(
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose.JSON,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsRecordFields.TIME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82a036309c844f274d448d3b15573de0207a66ad763e9b81675cff7de74d25de)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbConnectionLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLoadBalancerAlbConnectionLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_connection_logs_log_group_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsLogGroupProps(
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsRecordFields.TIME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66e2a744ba978a92efd0c2b1b901b6fa87247972f302ed214889dcdf3f205690)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbConnectionLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnLoadBalancerAlbConnectionLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnLoadBalancerAlbConnectionLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        cfn_load_balancer_alb_connection_logs_output_format = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsRecordFields"
)
class CfnLoadBalancerAlbConnectionLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TIME = "TIME"
    '''
    :stability: experimental
    '''
    CLIENT_IP = "CLIENT_IP"
    '''
    :stability: experimental
    '''
    CLIENT_PORT = "CLIENT_PORT"
    '''
    :stability: experimental
    '''
    LISTENER_PORT = "LISTENER_PORT"
    '''
    :stability: experimental
    '''
    TLS_PROTOCOL = "TLS_PROTOCOL"
    '''
    :stability: experimental
    '''
    TLS_CIPHER = "TLS_CIPHER"
    '''
    :stability: experimental
    '''
    TLS_HANDSHAKE_LATENCY = "TLS_HANDSHAKE_LATENCY"
    '''
    :stability: experimental
    '''
    LEAF_CLIENT_CERT_SUBJECT = "LEAF_CLIENT_CERT_SUBJECT"
    '''
    :stability: experimental
    '''
    LEAF_CLIENT_CERT_VALIDITY = "LEAF_CLIENT_CERT_VALIDITY"
    '''
    :stability: experimental
    '''
    LEAF_CLIENT_CERT_SERIAL_NUMBER = "LEAF_CLIENT_CERT_SERIAL_NUMBER"
    '''
    :stability: experimental
    '''
    TLS_VERIFY_STATUS = "TLS_VERIFY_STATUS"
    '''
    :stability: experimental
    '''
    CONN_TRACE_ID = "CONN_TRACE_ID"
    '''
    :stability: experimental
    '''
    TLS_KEYEXCHANGE = "TLS_KEYEXCHANGE"
    '''
    :stability: experimental
    '''
    ELB = "ELB"
    '''
    :stability: experimental
    '''
    IP_ADDRESS = "IP_ADDRESS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbConnectionLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnLoadBalancerAlbConnectionLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_load_balancer_alb_connection_logs_s3_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsS3Props(
                encryption_key=key_ref,
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsOutputFormat.S3.JSON,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbConnectionLogsRecordFields.TIME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75168e3b134e70de040ccb7499c01a0be5c8ebd76d215014b11bd46d92102103)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbConnectionLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbConnectionLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnLoadBalancerAlbHealthCheckLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogs",
):
    '''Builder for CfnLoadBalancerLogsMixin to generate ALB_HEALTH_CHECK_LOGS for CfnLoadBalancer.

    :cloudformationResource: AWS::ElasticLoadBalancingV2::LoadBalancer
    :logType: ALB_HEALTH_CHECK_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        cfn_load_balancer_alb_health_check_logs = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__05fc12132788e1cb747e81e14b5c85d35afc0afcc81762f13817a241b25bc9b3)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnLoadBalancerAlbHealthCheckLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1bc0c5d8edd8022b5960fa9af79562b07ba309175ddd1bd6f772817d87fb26fc)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnLoadBalancerAlbHealthCheckLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__be64b6d4a6f88d7ea1b8d36a3f35110d82fed5a278adfaf93ab0bc901e9800f9)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnLoadBalancerAlbHealthCheckLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a282c7dab738d8c5d4e3b5924929a5b4240586468beabb2cc28276b8c404a205)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnLoadBalancerAlbHealthCheckLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnLoadBalancerAlbHealthCheckLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_health_check_logs_dest_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsDestProps(
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed172ec1083343b261724faa8522701e8d121b8d5282ee79210836d67775250f)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbHealthCheckLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLoadBalancerAlbHealthCheckLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_health_check_logs_firehose_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsFirehoseProps(
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose.JSON,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5933af92faafcae7e7ed21cfd29dd33ae25e02f22fd4c609937c3768251f26f9)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbHealthCheckLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLoadBalancerAlbHealthCheckLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_alb_health_check_logs_log_group_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsLogGroupProps(
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e91508b97ce264e16c2dfef1db5d28bcb82ec211d6dd23ff248b49f3cb9dd1fb)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbHealthCheckLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnLoadBalancerAlbHealthCheckLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnLoadBalancerAlbHealthCheckLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        cfn_load_balancer_alb_health_check_logs_output_format = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsRecordFields"
)
class CfnLoadBalancerAlbHealthCheckLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    TIME = "TIME"
    '''
    :stability: experimental
    '''
    LATENCY = "LATENCY"
    '''
    :stability: experimental
    '''
    TARGET_ADDR = "TARGET_ADDR"
    '''
    :stability: experimental
    '''
    TARGET_GROUP_ID = "TARGET_GROUP_ID"
    '''
    :stability: experimental
    '''
    STATUS = "STATUS"
    '''
    :stability: experimental
    '''
    STATUS_CODE = "STATUS_CODE"
    '''
    :stability: experimental
    '''
    REASON_CODE = "REASON_CODE"
    '''
    :stability: experimental
    '''
    ELB = "ELB"
    '''
    :stability: experimental
    '''
    IP_ADDRESS = "IP_ADDRESS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerAlbHealthCheckLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnLoadBalancerAlbHealthCheckLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_load_balancer_alb_health_check_logs_s3_props = elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsS3Props(
                encryption_key=key_ref,
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3.JSON,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerAlbHealthCheckLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62f6cbd44faeb10f6e95f88b72a50f0902385fb5b78d35954cb6c61ec747b6be)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerAlbHealthCheckLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerAlbHealthCheckLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnLoadBalancerLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerLogsMixin",
):
    '''Specifies an Application Load Balancer, a Network Load Balancer, or a Gateway Load Balancer.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-elasticloadbalancingv2-loadbalancer.html
    :cloudformationResource: AWS::ElasticLoadBalancingV2::LoadBalancer
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_load_balancer_logs_mixin = elasticloadbalancingv2_mixins.CfnLoadBalancerLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::ElasticLoadBalancingV2::LoadBalancer``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b848bb4689a98590b8a6fc047bafa7a29fd77d0479ef3b786049c84f916fe02d)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e6347508044aef58390c2e951930478ca1748f1808b2e95ccbe023e500bc026e)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__01ddadc9aab0991bd8e586a6c33aeb9089405abe394b02532e7e1e4554f98111)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ALB_ACCESS_LOGS")
    def ALB_ACCESS_LOGS(cls) -> "CfnLoadBalancerAlbAccessLogs":
        return typing.cast("CfnLoadBalancerAlbAccessLogs", jsii.sget(cls, "ALB_ACCESS_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ALB_CONNECTION_LOGS")
    def ALB_CONNECTION_LOGS(cls) -> "CfnLoadBalancerAlbConnectionLogs":
        return typing.cast("CfnLoadBalancerAlbConnectionLogs", jsii.sget(cls, "ALB_CONNECTION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ALB_HEALTH_CHECK_LOGS")
    def ALB_HEALTH_CHECK_LOGS(cls) -> "CfnLoadBalancerAlbHealthCheckLogs":
        return typing.cast("CfnLoadBalancerAlbHealthCheckLogs", jsii.sget(cls, "ALB_HEALTH_CHECK_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="NLB_ACCESS_LOGS")
    def NLB_ACCESS_LOGS(cls) -> "CfnLoadBalancerNlbAccessLogs":
        return typing.cast("CfnLoadBalancerNlbAccessLogs", jsii.sget(cls, "NLB_ACCESS_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnLoadBalancerNlbAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogs",
):
    '''Builder for CfnLoadBalancerLogsMixin to generate NLB_ACCESS_LOGS for CfnLoadBalancer.

    :cloudformationResource: AWS::ElasticLoadBalancingV2::LoadBalancer
    :logType: NLB_ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        cfn_load_balancer_nlb_access_logs = elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerNlbAccessLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__732febc99900611e49c413c8f2b4a452f806627dac9fab483d20a28834469ae3)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnLoadBalancerNlbAccessLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerNlbAccessLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c3b7c2fd5285227fc29c1e77091fbe5c147f267bd517f1677cca97dbcc4a6991)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnLoadBalancerNlbAccessLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerNlbAccessLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0057ad6d34907f35d5f44bbde771658360c7c0bc7db3f602a473395c3898bf6a)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnLoadBalancerNlbAccessLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerNlbAccessLogsRecordFields"]] = None,
    ) -> "CfnLoadBalancerLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7ef113a91a0e02a6d9ec5aada7139824824dd154242bbd42424915757e179420)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnLoadBalancerNlbAccessLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnLoadBalancerLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnLoadBalancerNlbAccessLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerNlbAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_nlb_access_logs_dest_props = elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsDestProps(
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c18508d3bb02da133953c5c642dd0a16f02130674cd71edeeeb26e52d7d7e726)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerNlbAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerNlbAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerNlbAccessLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLoadBalancerNlbAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerNlbAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_nlb_access_logs_firehose_props = elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsFirehoseProps(
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose.JSON,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__13657adf9296ea1f37e73975747044347ef04ca175753a3da461a8d969fb2abc)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerNlbAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerNlbAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerNlbAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnLoadBalancerNlbAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerNlbAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            
            cfn_load_balancer_nlb_access_logs_log_group_props = elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsLogGroupProps(
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__26a89537c337554e343785197fdfcd6b63a282976f57f77cac5e0187836d26e1)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerNlbAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerNlbAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerNlbAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnLoadBalancerNlbAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnLoadBalancerNlbAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
        
        cfn_load_balancer_nlb_access_logs_output_format = elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsRecordFields"
)
class CfnLoadBalancerNlbAccessLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    VERSION = "VERSION"
    '''
    :stability: experimental
    '''
    TIME = "TIME"
    '''
    :stability: experimental
    '''
    ELB = "ELB"
    '''
    :stability: experimental
    '''
    LISTENER = "LISTENER"
    '''
    :stability: experimental
    '''
    CLIENT_PORT = "CLIENT_PORT"
    '''
    :stability: experimental
    '''
    DESTINATION_PORT = "DESTINATION_PORT"
    '''
    :stability: experimental
    '''
    CONNECTION_TIME = "CONNECTION_TIME"
    '''
    :stability: experimental
    '''
    TLS_HANDSHAKE_TIME = "TLS_HANDSHAKE_TIME"
    '''
    :stability: experimental
    '''
    RECEIVED_BYTES = "RECEIVED_BYTES"
    '''
    :stability: experimental
    '''
    SENT_BYTES = "SENT_BYTES"
    '''
    :stability: experimental
    '''
    INCOMING_TLS_ALERT = "INCOMING_TLS_ALERT"
    '''
    :stability: experimental
    '''
    CHOSEN_CERT_ARN = "CHOSEN_CERT_ARN"
    '''
    :stability: experimental
    '''
    CHOSEN_CERT_SERIAL = "CHOSEN_CERT_SERIAL"
    '''
    :stability: experimental
    '''
    TLS_CIPHER = "TLS_CIPHER"
    '''
    :stability: experimental
    '''
    TLS_PROTOCOL_VERSION = "TLS_PROTOCOL_VERSION"
    '''
    :stability: experimental
    '''
    TLS_KEYEXCHANGE = "TLS_KEYEXCHANGE"
    '''
    :stability: experimental
    '''
    DOMAIN_NAME = "DOMAIN_NAME"
    '''
    :stability: experimental
    '''
    ALPN_FE_PROTOCOL = "ALPN_FE_PROTOCOL"
    '''
    :stability: experimental
    '''
    ALPN_BE_PROTOCOL = "ALPN_BE_PROTOCOL"
    '''
    :stability: experimental
    '''
    ALPN_CLIENT_PREFERENCE_LIST = "ALPN_CLIENT_PREFERENCE_LIST"
    '''
    :stability: experimental
    '''
    TLS_CONNECTION_CREATION_TIME = "TLS_CONNECTION_CREATION_TIME"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancingv2.mixins.CfnLoadBalancerNlbAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnLoadBalancerNlbAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnLoadBalancerNlbAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_elasticloadbalancingv2 import mixins as elasticloadbalancingv2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_load_balancer_nlb_access_logs_s3_props = elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsOutputFormat.S3.JSON,
                record_fields=[elasticloadbalancingv2_mixins.CfnLoadBalancerNlbAccessLogsRecordFields.TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dc09b9e117af2d95eb4ea58c4c650cae047347f812220542406991672e82263c)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnLoadBalancerNlbAccessLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnLoadBalancerNlbAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnLoadBalancerNlbAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnLoadBalancerNlbAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnLoadBalancerAlbAccessLogs",
    "CfnLoadBalancerAlbAccessLogsDestProps",
    "CfnLoadBalancerAlbAccessLogsFirehoseProps",
    "CfnLoadBalancerAlbAccessLogsLogGroupProps",
    "CfnLoadBalancerAlbAccessLogsOutputFormat",
    "CfnLoadBalancerAlbAccessLogsRecordFields",
    "CfnLoadBalancerAlbAccessLogsS3Props",
    "CfnLoadBalancerAlbConnectionLogs",
    "CfnLoadBalancerAlbConnectionLogsDestProps",
    "CfnLoadBalancerAlbConnectionLogsFirehoseProps",
    "CfnLoadBalancerAlbConnectionLogsLogGroupProps",
    "CfnLoadBalancerAlbConnectionLogsOutputFormat",
    "CfnLoadBalancerAlbConnectionLogsRecordFields",
    "CfnLoadBalancerAlbConnectionLogsS3Props",
    "CfnLoadBalancerAlbHealthCheckLogs",
    "CfnLoadBalancerAlbHealthCheckLogsDestProps",
    "CfnLoadBalancerAlbHealthCheckLogsFirehoseProps",
    "CfnLoadBalancerAlbHealthCheckLogsLogGroupProps",
    "CfnLoadBalancerAlbHealthCheckLogsOutputFormat",
    "CfnLoadBalancerAlbHealthCheckLogsRecordFields",
    "CfnLoadBalancerAlbHealthCheckLogsS3Props",
    "CfnLoadBalancerLogsMixin",
    "CfnLoadBalancerNlbAccessLogs",
    "CfnLoadBalancerNlbAccessLogsDestProps",
    "CfnLoadBalancerNlbAccessLogsFirehoseProps",
    "CfnLoadBalancerNlbAccessLogsLogGroupProps",
    "CfnLoadBalancerNlbAccessLogsOutputFormat",
    "CfnLoadBalancerNlbAccessLogsRecordFields",
    "CfnLoadBalancerNlbAccessLogsS3Props",
]

publication.publish()

def _typecheckingstub__3900938e6762867d7df9d9603515e946eb140456b5115d6c14969a95c1814565(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da9f58ba555763f5153f32a4f1434735e6e12ad72e8c7c309b2780a0e6de7b99(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9df044c183505d5260672d48a2023af1c99bb0fa3f7442f5cee38702b4d8cec6(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a350f6192f5ab738b6634cf77d711bd5fd2fda65e8672599c4abc8eba0e63ee(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLoadBalancerAlbAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bedf0543a7f447b71cb0da9bff0642fd9954abb863165ec926af2c3ca7a684a8(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cff24782a65fa95e3f85c0f087303a68ccf07970a45ab517d0738d1f263afeaa(
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f761f955e04f24622f22506051aee1c8f911f59e581fae64d7c561c8158efcd6(
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83aa7523dbf108fdf45739086ac2df4da38ab19f7765b067ce271e9cfa63482f(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLoadBalancerAlbAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7c84dd12dfa832707a2923e40be93ad57af8b718fecc937ee41f92a8e3d4a993(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fb760f717360a21044b305578e8e339b448166e9065f3ee93d2769876a4c2dc(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9abf0e3179e266f22681af455f6e741dfa6f7d922f5d710be3b768e8f9567dbb(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25603aef57b2ace26218bdb2fe36719f4a9cfaf0cc707de58af8a08c76ba4b27(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLoadBalancerAlbConnectionLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__beb0ec90ae2738e01ea5197322ca4a8864ea3195f4ac927cc15d93cc920ceddb(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82a036309c844f274d448d3b15573de0207a66ad763e9b81675cff7de74d25de(
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbConnectionLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66e2a744ba978a92efd0c2b1b901b6fa87247972f302ed214889dcdf3f205690(
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbConnectionLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75168e3b134e70de040ccb7499c01a0be5c8ebd76d215014b11bd46d92102103(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLoadBalancerAlbConnectionLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05fc12132788e1cb747e81e14b5c85d35afc0afcc81762f13817a241b25bc9b3(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbHealthCheckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1bc0c5d8edd8022b5960fa9af79562b07ba309175ddd1bd6f772817d87fb26fc(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbHealthCheckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__be64b6d4a6f88d7ea1b8d36a3f35110d82fed5a278adfaf93ab0bc901e9800f9(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbHealthCheckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a282c7dab738d8c5d4e3b5924929a5b4240586468beabb2cc28276b8c404a205(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbHealthCheckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed172ec1083343b261724faa8522701e8d121b8d5282ee79210836d67775250f(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbHealthCheckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5933af92faafcae7e7ed21cfd29dd33ae25e02f22fd4c609937c3768251f26f9(
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbHealthCheckLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbHealthCheckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e91508b97ce264e16c2dfef1db5d28bcb82ec211d6dd23ff248b49f3cb9dd1fb(
    *,
    output_format: typing.Optional[CfnLoadBalancerAlbHealthCheckLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbHealthCheckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62f6cbd44faeb10f6e95f88b72a50f0902385fb5b78d35954cb6c61ec747b6be(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLoadBalancerAlbHealthCheckLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerAlbHealthCheckLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b848bb4689a98590b8a6fc047bafa7a29fd77d0479ef3b786049c84f916fe02d(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6347508044aef58390c2e951930478ca1748f1808b2e95ccbe023e500bc026e(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__01ddadc9aab0991bd8e586a6c33aeb9089405abe394b02532e7e1e4554f98111(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__732febc99900611e49c413c8f2b4a452f806627dac9fab483d20a28834469ae3(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerNlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c3b7c2fd5285227fc29c1e77091fbe5c147f267bd517f1677cca97dbcc4a6991(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerNlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0057ad6d34907f35d5f44bbde771658360c7c0bc7db3f602a473395c3898bf6a(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerNlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ef113a91a0e02a6d9ec5aada7139824824dd154242bbd42424915757e179420(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLoadBalancerNlbAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerNlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c18508d3bb02da133953c5c642dd0a16f02130674cd71edeeeb26e52d7d7e726(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerNlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__13657adf9296ea1f37e73975747044347ef04ca175753a3da461a8d969fb2abc(
    *,
    output_format: typing.Optional[CfnLoadBalancerNlbAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerNlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26a89537c337554e343785197fdfcd6b63a282976f57f77cac5e0187836d26e1(
    *,
    output_format: typing.Optional[CfnLoadBalancerNlbAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerNlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dc09b9e117af2d95eb4ea58c4c650cae047347f812220542406991672e82263c(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnLoadBalancerNlbAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnLoadBalancerNlbAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
