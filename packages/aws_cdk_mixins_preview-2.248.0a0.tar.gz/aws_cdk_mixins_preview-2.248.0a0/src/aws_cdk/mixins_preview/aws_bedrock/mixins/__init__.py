from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnAgentAliasEventLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogs",
):
    '''Builder for CfnAgentAliasLogsMixin to generate EVENT_LOGS for CfnAgentAlias.

    :cloudformationResource: AWS::Bedrock::AgentAlias
    :logType: EVENT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_agent_alias_event_logs = bedrock_mixins.CfnAgentAliasEventLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnAgentAliasEventLogsRecordFields"]] = None,
    ) -> "CfnAgentAliasLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79fca0b2cc8b7464f5033cea24254d5510ad5c56b1a6637e7d0bfca111a4d4df)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnAgentAliasEventLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnAgentAliasLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnAgentAliasEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentAliasEventLogsRecordFields"]] = None,
    ) -> "CfnAgentAliasLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89fe3387100b7fef91f835d4ac67e51d37bce801974e9fc63bc096063eaae034)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnAgentAliasEventLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnAgentAliasLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnAgentAliasEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentAliasEventLogsRecordFields"]] = None,
    ) -> "CfnAgentAliasLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e0822e466dbe077f51af762b4ffd98d4adb04de281eead916381c9ad178a8d43)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnAgentAliasEventLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnAgentAliasLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnAgentAliasEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentAliasEventLogsRecordFields"]] = None,
    ) -> "CfnAgentAliasLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edd80dc0e7f99a00914b172307f25ba8a4bde538313860b19aee33d321fb7aa6)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnAgentAliasEventLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnAgentAliasLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnAgentAliasEventLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnAgentAliasEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_agent_alias_event_logs_dest_props = bedrock_mixins.CfnAgentAliasEventLogsDestProps(
                record_fields=[bedrock_mixins.CfnAgentAliasEventLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d2f74cb8151d5e46140fc5b5c2615cec0af029eda5070a12e23eb14e3594f675)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentAliasEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentAliasEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentAliasEventLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnAgentAliasEventLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnAgentAliasEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentAliasEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_agent_alias_event_logs_firehose_props = bedrock_mixins.CfnAgentAliasEventLogsFirehoseProps(
                output_format=bedrock_mixins.CfnAgentAliasEventLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrock_mixins.CfnAgentAliasEventLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6912677f1d384f5bb3508d2031ff3d48c5cf5c2bb38155ab794c2e6faae58fef)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAgentAliasEventLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentAliasEventLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentAliasEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentAliasEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentAliasEventLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnAgentAliasEventLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnAgentAliasEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentAliasEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_agent_alias_event_logs_log_group_props = bedrock_mixins.CfnAgentAliasEventLogsLogGroupProps(
                output_format=bedrock_mixins.CfnAgentAliasEventLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrock_mixins.CfnAgentAliasEventLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c7ab7087311c3b0175b169225b6fa43e0a5709d975bbd336aa0f28c882fedea)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAgentAliasEventLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentAliasEventLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentAliasEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentAliasEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentAliasEventLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnAgentAliasEventLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnAgentAliasEventLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_agent_alias_event_logs_output_format = bedrock_mixins.CfnAgentAliasEventLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsRecordFields"
)
class CfnAgentAliasEventLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TIMESTAMP = "TIMESTAMP"
    '''
    :stability: experimental
    '''
    RESOURCEID = "RESOURCEID"
    '''
    :stability: experimental
    '''
    TRACEID = "TRACEID"
    '''
    :stability: experimental
    '''
    SPANID = "SPANID"
    '''
    :stability: experimental
    '''
    SESSIONID = "SESSIONID"
    '''
    :stability: experimental
    '''
    REQUESTID = "REQUESTID"
    '''
    :stability: experimental
    '''
    OPERATION = "OPERATION"
    '''
    :stability: experimental
    '''
    ATTRIBUTES = "ATTRIBUTES"
    '''
    :stability: experimental
    '''
    BODY = "BODY"
    '''
    :stability: experimental
    '''
    EVENTTYPE = "EVENTTYPE"
    '''
    :stability: experimental
    '''
    EVENTVERSION = "EVENTVERSION"
    '''
    :stability: experimental
    '''
    EVENTNAME = "EVENTNAME"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasEventLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnAgentAliasEventLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnAgentAliasEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentAliasEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_agent_alias_event_logs_s3_props = bedrock_mixins.CfnAgentAliasEventLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrock_mixins.CfnAgentAliasEventLogsOutputFormat.S3.JSON,
                record_fields=[bedrock_mixins.CfnAgentAliasEventLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__daef6923ec3420c1849cbd597c399fbece5d792f992fed71ee9677fd1d577506)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnAgentAliasEventLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentAliasEventLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentAliasEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentAliasEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentAliasEventLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnAgentAliasLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentAliasLogsMixin",
):
    '''Specifies an agent alias as a resource in a top-level template. Minimally, you must specify the following properties:.

    - AgentAliasName – Specify a name for the alias.

    For more information about creating aliases for an agent in Amazon Bedrock , see `Deploy an Amazon Bedrock agent <https://docs.aws.amazon.com/bedrock/latest/userguide/agents-deploy.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-agentalias.html
    :cloudformationResource: AWS::Bedrock::AgentAlias
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_agent_alias_logs_mixin = bedrock_mixins.CfnAgentAliasLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Bedrock::AgentAlias``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a0dfc7504d6bd1e63f0f9b026362c40a22d13b95bb24dac1c86258a5615339d5)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2b47512ed5f12ab1ff859562ad2dcde301164852fe589bf0b679052679351e87)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92b917df052bc5cd7eecf47fb6deae8b8e7fa87e01a499b89e293452bbb757bd)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EVENT_LOGS")
    def EVENT_LOGS(cls) -> "CfnAgentAliasEventLogs":
        return typing.cast("CfnAgentAliasEventLogs", jsii.sget(cls, "EVENT_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnAgentApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogs",
):
    '''Builder for CfnAgentLogsMixin to generate APPLICATION_LOGS for CfnAgent.

    :cloudformationResource: AWS::Bedrock::Agent
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_agent_application_logs = bedrock_mixins.CfnAgentApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnAgentApplicationLogsRecordFields"]] = None,
    ) -> "CfnAgentLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f5af405e5487ad5982b618a834f65864e88c950958b975a2996be73d617ac75a)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnAgentApplicationLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnAgentLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnAgentApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentApplicationLogsRecordFields"]] = None,
    ) -> "CfnAgentLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__668759f73023546dafab6830da9d9a44f666c4ce5ce44310cd7c2f5b20b81c51)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnAgentApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnAgentLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnAgentApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentApplicationLogsRecordFields"]] = None,
    ) -> "CfnAgentLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3acdd3056fd1e4fe07fdba191d267e85d58b79ae5cd53a6c31a92c14a325c393)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnAgentApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnAgentLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnAgentApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentApplicationLogsRecordFields"]] = None,
    ) -> "CfnAgentLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7cb005d92fbe0909b5e12178b9f22003bc5dbac9089ff567f5974729e18e0ff7)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnAgentApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnAgentLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnAgentApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnAgentApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_agent_application_logs_dest_props = bedrock_mixins.CfnAgentApplicationLogsDestProps(
                record_fields=[bedrock_mixins.CfnAgentApplicationLogsRecordFields.AGENT_ALIAS_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__00b3116b7a98043c1145a0e38a20df09cad0b01e19d8021c99df30acc2aead65)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnAgentApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnAgentApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_agent_application_logs_firehose_props = bedrock_mixins.CfnAgentApplicationLogsFirehoseProps(
                output_format=bedrock_mixins.CfnAgentApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrock_mixins.CfnAgentApplicationLogsRecordFields.AGENT_ALIAS_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d59644dad294c004d95eb66669dc4f90d8776da6a96688c42cb94e014a8ba5ed)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAgentApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnAgentApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnAgentApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_agent_application_logs_log_group_props = bedrock_mixins.CfnAgentApplicationLogsLogGroupProps(
                output_format=bedrock_mixins.CfnAgentApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrock_mixins.CfnAgentApplicationLogsRecordFields.AGENT_ALIAS_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98bd847c417c3ce8a18c63e63f9bd863260fed2be3346c389162b99cf4d3e13c)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAgentApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnAgentApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnAgentApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_agent_application_logs_output_format = bedrock_mixins.CfnAgentApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsRecordFields"
)
class CfnAgentApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    AGENT_ALIAS_ARN = "AGENT_ALIAS_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    EVENT_VERSION = "EVENT_VERSION"
    '''
    :stability: experimental
    '''
    OPERATION = "OPERATION"
    '''
    :stability: experimental
    '''
    EVENT_TYPE = "EVENT_TYPE"
    '''
    :stability: experimental
    '''
    WORKFLOW = "WORKFLOW"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''
    EVENT = "EVENT"
    '''
    :stability: experimental
    '''
    AGENT_ARN = "AGENT_ARN"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnAgentApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnAgentApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAgentApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_agent_application_logs_s3_props = bedrock_mixins.CfnAgentApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrock_mixins.CfnAgentApplicationLogsOutputFormat.S3.JSON,
                record_fields=[bedrock_mixins.CfnAgentApplicationLogsRecordFields.AGENT_ALIAS_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8db4ac3bbbc5711d95b57c27421b96065ed7f792d7797e296b291aa1ecfcf0aa)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAgentApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAgentApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAgentApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAgentApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAgentApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnAgentLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnAgentLogsMixin",
):
    '''Specifies an agent as a resource in a top-level template. Minimally, you must specify the following properties:.

    - AgentName – Specify a name for the agent.
    - AgentResourceRoleArn – Specify the Amazon Resource Name (ARN) of the service role with permissions to invoke API operations on the agent. For more information, see `Create a service role for Agents for Amazon Bedrock <https://docs.aws.amazon.com/bedrock/latest/userguide/agents-permissions.html>`_ .
    - FoundationModel – Specify the model ID of a foundation model to use when invoking the agent. For more information, see `Supported regions and models for Agents for Amazon Bedrock <https://docs.aws.amazon.com//bedrock/latest/userguide/agents-supported.html>`_ .

    For more information about using agents in Amazon Bedrock , see `Agents for Amazon Bedrock <https://docs.aws.amazon.com/bedrock/latest/userguide/agents.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-agent.html
    :cloudformationResource: AWS::Bedrock::Agent
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_agent_logs_mixin = bedrock_mixins.CfnAgentLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Bedrock::Agent``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3cbd06c78abcc78331db5ac9be0fdbf5e9781fb8372e3097f56896a00c68916d)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7f50240ae7219a5ed674964ce0fadf836b752680cf01a226b2965968753c44ad)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cfce9bb2653f196155d15a3ab3e29d6a2aa78c78f5f1a2d5c5299f6b5544df1e)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnAgentApplicationLogs":
        return typing.cast("CfnAgentApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnFlowApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogs",
):
    '''Builder for CfnFlowLogsMixin to generate APPLICATION_LOGS for CfnFlow.

    :cloudformationResource: AWS::Bedrock::Flow
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_flow_application_logs = bedrock_mixins.CfnFlowApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnFlowApplicationLogsRecordFields"]] = None,
    ) -> "CfnFlowLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ab3e4b4d158d6623dd786d683e266e86f96f7fd5e3d8b4d0c0aee15b9a7350d0)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnFlowApplicationLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnFlowLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnFlowApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnFlowApplicationLogsRecordFields"]] = None,
    ) -> "CfnFlowLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92e2f7922247e05a55ea9a42e1889ded0a39dd38c9c3753c4a3b77290c1bb590)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnFlowApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnFlowLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnFlowApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnFlowApplicationLogsRecordFields"]] = None,
    ) -> "CfnFlowLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fe42b35b9ec7605d9fad663ff452fee53127be1ea43b231d91cf7b7013487a4d)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnFlowApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnFlowLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnFlowApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnFlowApplicationLogsRecordFields"]] = None,
    ) -> "CfnFlowLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79ff47630f881e24eef083d24bf8e13e70a1f0fe7fb506dc8f49361c6b1d1736)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnFlowApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnFlowLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnFlowApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnFlowApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_flow_application_logs_dest_props = bedrock_mixins.CfnFlowApplicationLogsDestProps(
                record_fields=[bedrock_mixins.CfnFlowApplicationLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25c2d95d72cb6778ad8d992ce885b6d19281c8987eea37bca20cde40bc88df9c)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnFlowApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnFlowApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFlowApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnFlowApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnFlowApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnFlowApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_flow_application_logs_firehose_props = bedrock_mixins.CfnFlowApplicationLogsFirehoseProps(
                output_format=bedrock_mixins.CfnFlowApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrock_mixins.CfnFlowApplicationLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__92122eaed880c6b67dc62a68b0c6c750f9fd1803605ee9372b1081fc8c63f0d3)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnFlowApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFlowApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnFlowApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnFlowApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFlowApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnFlowApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnFlowApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnFlowApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_flow_application_logs_log_group_props = bedrock_mixins.CfnFlowApplicationLogsLogGroupProps(
                output_format=bedrock_mixins.CfnFlowApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrock_mixins.CfnFlowApplicationLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a1ef6d22d2c38dd148f3e5c77e41a2578d1dab2c106f227e563abd1090087ce3)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnFlowApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFlowApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnFlowApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnFlowApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFlowApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnFlowApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnFlowApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_flow_application_logs_output_format = bedrock_mixins.CfnFlowApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsRecordFields"
)
class CfnFlowApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    SCHEMA_VERSION = "SCHEMA_VERSION"
    '''
    :stability: experimental
    '''
    FLOW_ID = "FLOW_ID"
    '''
    :stability: experimental
    '''
    FLOW_ALIAS_ID = "FLOW_ALIAS_ID"
    '''
    :stability: experimental
    '''
    FLOW_VERSION = "FLOW_VERSION"
    '''
    :stability: experimental
    '''
    REQUEST_ID = "REQUEST_ID"
    '''
    :stability: experimental
    '''
    EXECUTION_ID = "EXECUTION_ID"
    '''
    :stability: experimental
    '''
    EVENT_TYPE = "EVENT_TYPE"
    '''
    :stability: experimental
    '''
    EVENT = "EVENT"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnFlowApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnFlowApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnFlowApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_flow_application_logs_s3_props = bedrock_mixins.CfnFlowApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrock_mixins.CfnFlowApplicationLogsOutputFormat.S3.JSON,
                record_fields=[bedrock_mixins.CfnFlowApplicationLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a399da2bfff71b2e84d6023bf44374a7edfe3ef7b9541918e8f706be5f222190)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnFlowApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnFlowApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnFlowApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnFlowApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnFlowApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnFlowLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnFlowLogsMixin",
):
    '''Creates a prompt flow that you can use to send an input through various steps to yield an output.

    You define a flow by configuring nodes, each of which corresponds to a step of the flow, and creating connections between the nodes to create paths to different outputs. You can define the flow in one of the following ways:

    - Define a `FlowDefinition <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bedrock-flow-flowdefinition.html>`_ in the ``Definition`` property.
    - Provide the definition in the ``DefinitionString`` property as a JSON-formatted string matching the `FlowDefinition <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bedrock-flow-flowdefinition.html>`_ property.
    - Provide an Amazon S3 location in the ``DefinitionS3Location`` property that matches the `FlowDefinition <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bedrock-flow-flowdefinition.html>`_ .

    If you use the ``DefinitionString`` or ``DefinitionS3Location`` property, you can use the ``DefinitionSubstitutions`` property to define key-value pairs to replace at runtime.

    For more information, see `How it works <https://docs.aws.amazon.com/bedrock/latest/userguide/flows-how-it-works.html>`_ and `Create a prompt flow in Amazon Bedrock <https://docs.aws.amazon.com/bedrock/latest/userguide/flows-create.html>`_ in the Amazon Bedrock User Guide.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-flow.html
    :cloudformationResource: AWS::Bedrock::Flow
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_flow_logs_mixin = bedrock_mixins.CfnFlowLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Bedrock::Flow``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff618fe0139ad6c1716c844736c0be0c15f70ad6018add372e052dae207ce6be)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89d4c8719a67d215a7ada3b1b40131ef220fb6be5650e60370f4bcc602a52f7e)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a8bfad6fb9b31dbf5489e6ef3ac0d070d963086c9b98a192470032697b53cba9)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnFlowApplicationLogs":
        return typing.cast("CfnFlowApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnKnowledgeBaseApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogs",
):
    '''Builder for CfnKnowledgeBaseLogsMixin to generate APPLICATION_LOGS for CfnKnowledgeBase.

    :cloudformationResource: AWS::Bedrock::KnowledgeBase
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_knowledge_base_application_logs = bedrock_mixins.CfnKnowledgeBaseApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseApplicationLogsRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0984da830d7f204e1c7d487895a415462ccc4fa113b1167c0832625fd1417ca9)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnKnowledgeBaseApplicationLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseApplicationLogsRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9afd6c729cd28bbc4b51ff8d18b051d6fa934af37ede9c1342e2cec7553c0695)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnKnowledgeBaseApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseApplicationLogsRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bf1179280e496ee484ba8c092b53a4d245217292444dcf13687f9cf441a1c0d9)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnKnowledgeBaseApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseApplicationLogsRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__79b211fa86d8cc8e93265b03b2f86f7c40295361ca54c6cd405ebe4fd27b8e89)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnKnowledgeBaseApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnKnowledgeBaseApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_knowledge_base_application_logs_dest_props = bedrock_mixins.CfnKnowledgeBaseApplicationLogsDestProps(
                record_fields=[bedrock_mixins.CfnKnowledgeBaseApplicationLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bb0d8d3af8f047bd1d032378029db455de4543c0cbffa120f6f023cccd2728b)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnKnowledgeBaseApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_knowledge_base_application_logs_firehose_props = bedrock_mixins.CfnKnowledgeBaseApplicationLogsFirehoseProps(
                output_format=bedrock_mixins.CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrock_mixins.CfnKnowledgeBaseApplicationLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__aff1e319ef8344a0f3234642a7de6037059d131688d02fdaeae07fdaa3d2a437)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnKnowledgeBaseApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_knowledge_base_application_logs_log_group_props = bedrock_mixins.CfnKnowledgeBaseApplicationLogsLogGroupProps(
                output_format=bedrock_mixins.CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrock_mixins.CfnKnowledgeBaseApplicationLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__99ce032b7a99cce597b3d0b8376fbfec563221a08cbbb37463a89dd23a024c10)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnKnowledgeBaseApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnKnowledgeBaseApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_knowledge_base_application_logs_output_format = bedrock_mixins.CfnKnowledgeBaseApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsRecordFields"
)
class CfnKnowledgeBaseApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    EVENT = "EVENT"
    '''
    :stability: experimental
    '''
    EVENT_VERSION = "EVENT_VERSION"
    '''
    :stability: experimental
    '''
    EVENT_TYPE = "EVENT_TYPE"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnKnowledgeBaseApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_knowledge_base_application_logs_s3_props = bedrock_mixins.CfnKnowledgeBaseApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrock_mixins.CfnKnowledgeBaseApplicationLogsOutputFormat.S3.JSON,
                record_fields=[bedrock_mixins.CfnKnowledgeBaseApplicationLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ad10a0f75d2e51f781e6f6f4d039074eeb8ec8ad952cd38da4920882c3867ec6)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnKnowledgeBaseApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnKnowledgeBaseLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseLogsMixin",
):
    '''Specifies a knowledge base as a resource in a top-level template. Minimally, you must specify the following properties:.

    - Name – Specify a name for the knowledge base.
    - RoleArn – Specify the Amazon Resource Name (ARN) of the IAM role with permissions to invoke API operations on the knowledge base. For more information, see `Create a service role for Knowledge base for Amazon Bedrock <https://docs.aws.amazon.com/bedrock/latest/userguide/kb-permissions.html>`_ .
    - KnowledgeBaseConfiguration – Specify the embeddings configuration of the knowledge base. The following sub-properties are required:
    - Type – Specify the value ``VECTOR`` .
    - StorageConfiguration – Specify information about the vector store in which the data source is stored. The following sub-properties are required:
    - Type – Specify the vector store service that you are using.

    .. epigraph::

       Redis Enterprise Cloud vector stores are currently unsupported in CloudFormation .

    For more information about using knowledge bases in Amazon Bedrock , see `Knowledge base for Amazon Bedrock <https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base.html>`_ .

    See the *Properties* section below for descriptions of both the required and optional properties.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bedrock-knowledgebase.html
    :cloudformationResource: AWS::Bedrock::KnowledgeBase
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_knowledge_base_logs_mixin = bedrock_mixins.CfnKnowledgeBaseLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Bedrock::KnowledgeBase``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7bcb29991e4e19c615e1385fd0d477b8d4c01c3caacbea038045566a98c009f7)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__975a69d7e7aa49b74e579ee108e7a20efec4c4b71d438ad5e697b23d180deeb3)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__26725175212e581ad90f4417adcc6893a188dd434926ebfa21c2126f2ceac3c9)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnKnowledgeBaseApplicationLogs":
        return typing.cast("CfnKnowledgeBaseApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="RUNTIME_LOGS")
    def RUNTIME_LOGS(cls) -> "CfnKnowledgeBaseRuntimeLogs":
        return typing.cast("CfnKnowledgeBaseRuntimeLogs", jsii.sget(cls, "RUNTIME_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TRACES")
    def TRACES(cls) -> "CfnKnowledgeBaseTraces":
        return typing.cast("CfnKnowledgeBaseTraces", jsii.sget(cls, "TRACES"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnKnowledgeBaseRuntimeLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogs",
):
    '''Builder for CfnKnowledgeBaseLogsMixin to generate RUNTIME_LOGS for CfnKnowledgeBase.

    :cloudformationResource: AWS::Bedrock::KnowledgeBase
    :logType: RUNTIME_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_knowledge_base_runtime_logs = bedrock_mixins.CfnKnowledgeBaseRuntimeLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseRuntimeLogsRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__76717d08ae0c5b48b05f8629ff3f2a002ff2296decab154e69cd7db6f7458808)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnKnowledgeBaseRuntimeLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseRuntimeLogsRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e1089624b651106f6050525f4ea2d29ffe8cfd90d1905055aef65c9caf54b9c)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnKnowledgeBaseRuntimeLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseRuntimeLogsRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2abfbbece6e88024b43d1ce72e602e31f4747bd895c3c4a694de26aeb3a82a69)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnKnowledgeBaseRuntimeLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseRuntimeLogsRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__059a829cfb2c6d46c203dfce4c1304ab07e5736a74a2247dd4a45faafb6a9747)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnKnowledgeBaseRuntimeLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnKnowledgeBaseRuntimeLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseRuntimeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_knowledge_base_runtime_logs_dest_props = bedrock_mixins.CfnKnowledgeBaseRuntimeLogsDestProps(
                record_fields=[bedrock_mixins.CfnKnowledgeBaseRuntimeLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c44b5d6d3d3e5ed1f1f8cb557591be0200c9b57c0c1ed557e4569e2d4ba65590)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseRuntimeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseRuntimeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseRuntimeLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnKnowledgeBaseRuntimeLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseRuntimeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_knowledge_base_runtime_logs_firehose_props = bedrock_mixins.CfnKnowledgeBaseRuntimeLogsFirehoseProps(
                output_format=bedrock_mixins.CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose.JSON,
                record_fields=[bedrock_mixins.CfnKnowledgeBaseRuntimeLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__051583604b018e57d9145f011e1fc3f48d9e34fbaf9312068474005558e483bd)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseRuntimeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseRuntimeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseRuntimeLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnKnowledgeBaseRuntimeLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseRuntimeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_knowledge_base_runtime_logs_log_group_props = bedrock_mixins.CfnKnowledgeBaseRuntimeLogsLogGroupProps(
                output_format=bedrock_mixins.CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[bedrock_mixins.CfnKnowledgeBaseRuntimeLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5aef6bd75e7416980eb0e796953159fd1e9f86565a60309052d56b3f7f4f926b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseRuntimeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseRuntimeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseRuntimeLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnKnowledgeBaseRuntimeLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnKnowledgeBaseRuntimeLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_knowledge_base_runtime_logs_output_format = bedrock_mixins.CfnKnowledgeBaseRuntimeLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsRecordFields"
)
class CfnKnowledgeBaseRuntimeLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    EVENT = "EVENT"
    '''
    :stability: experimental
    '''
    EVENT_VERSION = "EVENT_VERSION"
    '''
    :stability: experimental
    '''
    EVENT_TYPE = "EVENT_TYPE"
    '''
    :stability: experimental
    '''
    LEVEL = "LEVEL"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseRuntimeLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnKnowledgeBaseRuntimeLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseRuntimeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_knowledge_base_runtime_logs_s3_props = bedrock_mixins.CfnKnowledgeBaseRuntimeLogsS3Props(
                encryption_key=key_ref,
                output_format=bedrock_mixins.CfnKnowledgeBaseRuntimeLogsOutputFormat.S3.JSON,
                record_fields=[bedrock_mixins.CfnKnowledgeBaseRuntimeLogsRecordFields.EVENT_TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5dd7b1879338f436497bb617124bc979a873929c6f4bf083d2547205fa54984)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnKnowledgeBaseRuntimeLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseRuntimeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseRuntimeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseRuntimeLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnKnowledgeBaseTraces(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseTraces",
):
    '''Builder for CfnKnowledgeBaseLogsMixin to generate TRACES for CfnKnowledgeBase.

    :cloudformationResource: AWS::Bedrock::KnowledgeBase
    :logType: TRACES
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_knowledge_base_traces = bedrock_mixins.CfnKnowledgeBaseTraces()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseTracesRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are XRAY
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08589a2d786748c325989abffc088e5346dc823a1e86cb0896bb06d3d75a01d4)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnKnowledgeBaseTracesDestProps(record_fields=record_fields)

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toXRay")
    def to_x_ray(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseTracesRecordFields"]] = None,
    ) -> "CfnKnowledgeBaseLogsMixin":
        '''Send traces to X-Ray.

        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        props = CfnKnowledgeBaseTracesXRayProps(record_fields=record_fields)

        return typing.cast("CfnKnowledgeBaseLogsMixin", jsii.invoke(self, "toXRay", [props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseTracesDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnKnowledgeBaseTracesDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseTracesRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_knowledge_base_traces_dest_props = bedrock_mixins.CfnKnowledgeBaseTracesDestProps(
                record_fields=[bedrock_mixins.CfnKnowledgeBaseTracesRecordFields.TRACE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8ec30cac553b1060c4b7d5bf9504d878e057bd3c123a66da851b809177a4afcc)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseTracesRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseTracesRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseTracesDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnKnowledgeBaseTracesOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseTracesOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnKnowledgeBaseTraces.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
        
        cfn_knowledge_base_traces_output_format = bedrock_mixins.CfnKnowledgeBaseTracesOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseTracesRecordFields"
)
class CfnKnowledgeBaseTracesRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TRACE = "TRACE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_bedrock.mixins.CfnKnowledgeBaseTracesXRayProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnKnowledgeBaseTracesXRayProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnKnowledgeBaseTracesRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_bedrock import mixins as bedrock_mixins
            
            cfn_knowledge_base_traces_xRay_props = bedrock_mixins.CfnKnowledgeBaseTracesXRayProps(
                record_fields=[bedrock_mixins.CfnKnowledgeBaseTracesRecordFields.TRACE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6531ad464e01d4341179cf74a10e165b9517faee72403885c5bab36b726b94d)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnKnowledgeBaseTracesRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnKnowledgeBaseTracesRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnKnowledgeBaseTracesXRayProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnAgentAliasEventLogs",
    "CfnAgentAliasEventLogsDestProps",
    "CfnAgentAliasEventLogsFirehoseProps",
    "CfnAgentAliasEventLogsLogGroupProps",
    "CfnAgentAliasEventLogsOutputFormat",
    "CfnAgentAliasEventLogsRecordFields",
    "CfnAgentAliasEventLogsS3Props",
    "CfnAgentAliasLogsMixin",
    "CfnAgentApplicationLogs",
    "CfnAgentApplicationLogsDestProps",
    "CfnAgentApplicationLogsFirehoseProps",
    "CfnAgentApplicationLogsLogGroupProps",
    "CfnAgentApplicationLogsOutputFormat",
    "CfnAgentApplicationLogsRecordFields",
    "CfnAgentApplicationLogsS3Props",
    "CfnAgentLogsMixin",
    "CfnFlowApplicationLogs",
    "CfnFlowApplicationLogsDestProps",
    "CfnFlowApplicationLogsFirehoseProps",
    "CfnFlowApplicationLogsLogGroupProps",
    "CfnFlowApplicationLogsOutputFormat",
    "CfnFlowApplicationLogsRecordFields",
    "CfnFlowApplicationLogsS3Props",
    "CfnFlowLogsMixin",
    "CfnKnowledgeBaseApplicationLogs",
    "CfnKnowledgeBaseApplicationLogsDestProps",
    "CfnKnowledgeBaseApplicationLogsFirehoseProps",
    "CfnKnowledgeBaseApplicationLogsLogGroupProps",
    "CfnKnowledgeBaseApplicationLogsOutputFormat",
    "CfnKnowledgeBaseApplicationLogsRecordFields",
    "CfnKnowledgeBaseApplicationLogsS3Props",
    "CfnKnowledgeBaseLogsMixin",
    "CfnKnowledgeBaseRuntimeLogs",
    "CfnKnowledgeBaseRuntimeLogsDestProps",
    "CfnKnowledgeBaseRuntimeLogsFirehoseProps",
    "CfnKnowledgeBaseRuntimeLogsLogGroupProps",
    "CfnKnowledgeBaseRuntimeLogsOutputFormat",
    "CfnKnowledgeBaseRuntimeLogsRecordFields",
    "CfnKnowledgeBaseRuntimeLogsS3Props",
    "CfnKnowledgeBaseTraces",
    "CfnKnowledgeBaseTracesDestProps",
    "CfnKnowledgeBaseTracesOutputFormat",
    "CfnKnowledgeBaseTracesRecordFields",
    "CfnKnowledgeBaseTracesXRayProps",
]

publication.publish()

def _typecheckingstub__79fca0b2cc8b7464f5033cea24254d5510ad5c56b1a6637e7d0bfca111a4d4df(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnAgentAliasEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89fe3387100b7fef91f835d4ac67e51d37bce801974e9fc63bc096063eaae034(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnAgentAliasEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentAliasEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e0822e466dbe077f51af762b4ffd98d4adb04de281eead916381c9ad178a8d43(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnAgentAliasEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentAliasEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edd80dc0e7f99a00914b172307f25ba8a4bde538313860b19aee33d321fb7aa6(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnAgentAliasEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentAliasEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d2f74cb8151d5e46140fc5b5c2615cec0af029eda5070a12e23eb14e3594f675(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnAgentAliasEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6912677f1d384f5bb3508d2031ff3d48c5cf5c2bb38155ab794c2e6faae58fef(
    *,
    output_format: typing.Optional[CfnAgentAliasEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentAliasEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c7ab7087311c3b0175b169225b6fa43e0a5709d975bbd336aa0f28c882fedea(
    *,
    output_format: typing.Optional[CfnAgentAliasEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentAliasEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__daef6923ec3420c1849cbd597c399fbece5d792f992fed71ee9677fd1d577506(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnAgentAliasEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentAliasEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a0dfc7504d6bd1e63f0f9b026362c40a22d13b95bb24dac1c86258a5615339d5(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b47512ed5f12ab1ff859562ad2dcde301164852fe589bf0b679052679351e87(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92b917df052bc5cd7eecf47fb6deae8b8e7fa87e01a499b89e293452bbb757bd(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f5af405e5487ad5982b618a834f65864e88c950958b975a2996be73d617ac75a(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnAgentApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__668759f73023546dafab6830da9d9a44f666c4ce5ce44310cd7c2f5b20b81c51(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnAgentApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3acdd3056fd1e4fe07fdba191d267e85d58b79ae5cd53a6c31a92c14a325c393(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnAgentApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7cb005d92fbe0909b5e12178b9f22003bc5dbac9089ff567f5974729e18e0ff7(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnAgentApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__00b3116b7a98043c1145a0e38a20df09cad0b01e19d8021c99df30acc2aead65(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnAgentApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d59644dad294c004d95eb66669dc4f90d8776da6a96688c42cb94e014a8ba5ed(
    *,
    output_format: typing.Optional[CfnAgentApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98bd847c417c3ce8a18c63e63f9bd863260fed2be3346c389162b99cf4d3e13c(
    *,
    output_format: typing.Optional[CfnAgentApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8db4ac3bbbc5711d95b57c27421b96065ed7f792d7797e296b291aa1ecfcf0aa(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnAgentApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAgentApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3cbd06c78abcc78331db5ac9be0fdbf5e9781fb8372e3097f56896a00c68916d(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7f50240ae7219a5ed674964ce0fadf836b752680cf01a226b2965968753c44ad(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cfce9bb2653f196155d15a3ab3e29d6a2aa78c78f5f1a2d5c5299f6b5544df1e(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ab3e4b4d158d6623dd786d683e266e86f96f7fd5e3d8b4d0c0aee15b9a7350d0(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnFlowApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92e2f7922247e05a55ea9a42e1889ded0a39dd38c9c3753c4a3b77290c1bb590(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnFlowApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnFlowApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fe42b35b9ec7605d9fad663ff452fee53127be1ea43b231d91cf7b7013487a4d(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnFlowApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnFlowApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79ff47630f881e24eef083d24bf8e13e70a1f0fe7fb506dc8f49361c6b1d1736(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnFlowApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnFlowApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25c2d95d72cb6778ad8d992ce885b6d19281c8987eea37bca20cde40bc88df9c(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnFlowApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__92122eaed880c6b67dc62a68b0c6c750f9fd1803605ee9372b1081fc8c63f0d3(
    *,
    output_format: typing.Optional[CfnFlowApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnFlowApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1ef6d22d2c38dd148f3e5c77e41a2578d1dab2c106f227e563abd1090087ce3(
    *,
    output_format: typing.Optional[CfnFlowApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnFlowApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a399da2bfff71b2e84d6023bf44374a7edfe3ef7b9541918e8f706be5f222190(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnFlowApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnFlowApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff618fe0139ad6c1716c844736c0be0c15f70ad6018add372e052dae207ce6be(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89d4c8719a67d215a7ada3b1b40131ef220fb6be5650e60370f4bcc602a52f7e(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a8bfad6fb9b31dbf5489e6ef3ac0d070d963086c9b98a192470032697b53cba9(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0984da830d7f204e1c7d487895a415462ccc4fa113b1167c0832625fd1417ca9(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9afd6c729cd28bbc4b51ff8d18b051d6fa934af37ede9c1342e2cec7553c0695(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bf1179280e496ee484ba8c092b53a4d245217292444dcf13687f9cf441a1c0d9(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__79b211fa86d8cc8e93265b03b2f86f7c40295361ca54c6cd405ebe4fd27b8e89(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnKnowledgeBaseApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bb0d8d3af8f047bd1d032378029db455de4543c0cbffa120f6f023cccd2728b(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aff1e319ef8344a0f3234642a7de6037059d131688d02fdaeae07fdaa3d2a437(
    *,
    output_format: typing.Optional[CfnKnowledgeBaseApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__99ce032b7a99cce597b3d0b8376fbfec563221a08cbbb37463a89dd23a024c10(
    *,
    output_format: typing.Optional[CfnKnowledgeBaseApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad10a0f75d2e51f781e6f6f4d039074eeb8ec8ad952cd38da4920882c3867ec6(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnKnowledgeBaseApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7bcb29991e4e19c615e1385fd0d477b8d4c01c3caacbea038045566a98c009f7(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__975a69d7e7aa49b74e579ee108e7a20efec4c4b71d438ad5e697b23d180deeb3(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26725175212e581ad90f4417adcc6893a188dd434926ebfa21c2126f2ceac3c9(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__76717d08ae0c5b48b05f8629ff3f2a002ff2296decab154e69cd7db6f7458808(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseRuntimeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e1089624b651106f6050525f4ea2d29ffe8cfd90d1905055aef65c9caf54b9c(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseRuntimeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2abfbbece6e88024b43d1ce72e602e31f4747bd895c3c4a694de26aeb3a82a69(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseRuntimeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__059a829cfb2c6d46c203dfce4c1304ab07e5736a74a2247dd4a45faafb6a9747(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnKnowledgeBaseRuntimeLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseRuntimeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c44b5d6d3d3e5ed1f1f8cb557591be0200c9b57c0c1ed557e4569e2d4ba65590(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseRuntimeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__051583604b018e57d9145f011e1fc3f48d9e34fbaf9312068474005558e483bd(
    *,
    output_format: typing.Optional[CfnKnowledgeBaseRuntimeLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseRuntimeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5aef6bd75e7416980eb0e796953159fd1e9f86565a60309052d56b3f7f4f926b(
    *,
    output_format: typing.Optional[CfnKnowledgeBaseRuntimeLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseRuntimeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5dd7b1879338f436497bb617124bc979a873929c6f4bf083d2547205fa54984(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnKnowledgeBaseRuntimeLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseRuntimeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08589a2d786748c325989abffc088e5346dc823a1e86cb0896bb06d3d75a01d4(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ec30cac553b1060c4b7d5bf9504d878e057bd3c123a66da851b809177a4afcc(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6531ad464e01d4341179cf74a10e165b9517faee72403885c5bab36b726b94d(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnKnowledgeBaseTracesRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
