from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnApplicationEventLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogs",
):
    '''Builder for CfnApplicationLogsMixin to generate EVENT_LOGS for CfnApplication.

    :cloudformationResource: AWS::QBusiness::Application
    :logType: EVENT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
        
        cfn_application_event_logs = qbusiness_mixins.CfnApplicationEventLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationEventLogsRecordFields"]] = None,
    ) -> "CfnApplicationLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2e31ee924e79c60d654ef7420c021ff352b9f83de29a9ccc62d37a046716a035)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnApplicationEventLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnApplicationLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnApplicationEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationEventLogsRecordFields"]] = None,
    ) -> "CfnApplicationLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d34e31e7f28e6d9623407543aa02e24a98471b0062cc49fcc9cb33da27c54014)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnApplicationEventLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnApplicationLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnApplicationEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationEventLogsRecordFields"]] = None,
    ) -> "CfnApplicationLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a12a04f7977985f75ecb608750d79b72a20f7e5c1b93bfdb63908e7268d0f453)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnApplicationEventLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnApplicationLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnApplicationEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationEventLogsRecordFields"]] = None,
    ) -> "CfnApplicationLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c4f7d1ed69da227cb7bad96687fd5cc95437dd676e0866347acdd9d859b0081)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnApplicationEventLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnApplicationLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnApplicationEventLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
            
            cfn_application_event_logs_dest_props = qbusiness_mixins.CfnApplicationEventLogsDestProps(
                record_fields=[qbusiness_mixins.CfnApplicationEventLogsRecordFields.APPLICATION_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__75d8672a14150d6eb40605d6be671736a54661fbb580c4225cc39fac54967a35)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnApplicationEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnApplicationEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnApplicationEventLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnApplicationEventLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnApplicationEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
            
            cfn_application_event_logs_firehose_props = qbusiness_mixins.CfnApplicationEventLogsFirehoseProps(
                output_format=qbusiness_mixins.CfnApplicationEventLogsOutputFormat.Firehose.JSON,
                record_fields=[qbusiness_mixins.CfnApplicationEventLogsRecordFields.APPLICATION_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bfb31f2e5f92ecc4eb9ff6529168fdac2ded2fa8eba3f1cad39289110906317)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnApplicationEventLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnApplicationEventLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnApplicationEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnApplicationEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnApplicationEventLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnApplicationEventLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnApplicationEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
            
            cfn_application_event_logs_log_group_props = qbusiness_mixins.CfnApplicationEventLogsLogGroupProps(
                output_format=qbusiness_mixins.CfnApplicationEventLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[qbusiness_mixins.CfnApplicationEventLogsRecordFields.APPLICATION_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__44cac0b6388cb9fdf068e06877b891290a7d795375487edd74db4648059aff54)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnApplicationEventLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnApplicationEventLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnApplicationEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnApplicationEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnApplicationEventLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnApplicationEventLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnApplicationEventLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
        
        cfn_application_event_logs_output_format = qbusiness_mixins.CfnApplicationEventLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsRecordFields"
)
class CfnApplicationEventLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    APPLICATION_ID = "APPLICATION_ID"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    LOG_TYPE = "LOG_TYPE"
    '''
    :stability: experimental
    '''
    ACCOUNT_ID = "ACCOUNT_ID"
    '''
    :stability: experimental
    '''
    CONVERSATION_ID = "CONVERSATION_ID"
    '''
    :stability: experimental
    '''
    SYSTEM_MESSAGE_ID = "SYSTEM_MESSAGE_ID"
    '''
    :stability: experimental
    '''
    USER_MESSAGE_ID = "USER_MESSAGE_ID"
    '''
    :stability: experimental
    '''
    USER_MESSAGE = "USER_MESSAGE"
    '''
    :stability: experimental
    '''
    SYSTEM_MESSAGE = "SYSTEM_MESSAGE"
    '''
    :stability: experimental
    '''
    OUTPUT_METRICS_IS_MESSAGE_BLOCKED = "OUTPUT_METRICS_IS_MESSAGE_BLOCKED"
    '''
    :stability: experimental
    '''
    OUTPUT_METRICS_IS_MESSAGE_WITH_NO_ANSWER = "OUTPUT_METRICS_IS_MESSAGE_WITH_NO_ANSWER"
    '''
    :stability: experimental
    '''
    COMMENT = "COMMENT"
    '''
    :stability: experimental
    '''
    USEFULNESS_REASON = "USEFULNESS_REASON"
    '''
    :stability: experimental
    '''
    USEFULNESS = "USEFULNESS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationEventLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnApplicationEventLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnApplicationEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_application_event_logs_s3_props = qbusiness_mixins.CfnApplicationEventLogsS3Props(
                encryption_key=key_ref,
                output_format=qbusiness_mixins.CfnApplicationEventLogsOutputFormat.S3.JSON,
                record_fields=[qbusiness_mixins.CfnApplicationEventLogsRecordFields.APPLICATION_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e3f8acd7118d4438b0f5dfecd15a28b54b75d0be6835be32e9c86214936ebe24)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnApplicationEventLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnApplicationEventLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnApplicationEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnApplicationEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnApplicationEventLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnApplicationLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationLogsMixin",
):
    '''Creates an Amazon Q Business application.

    .. epigraph::

       There are new tiers for Amazon Q Business. Not all features in Amazon Q Business Pro are also available in Amazon Q Business Lite. For information on what's included in Amazon Q Business Lite and what's included in Amazon Q Business Pro, see `Amazon Q Business tiers <https://docs.aws.amazon.com/amazonq/latest/qbusiness-ug/tiers.html#user-sub-tiers>`_ . You must use the Amazon Q Business console to assign subscription tiers to users.

       An Amazon Q Apps service linked role will be created if it's absent in the AWS account when ``QAppsConfiguration`` is enabled in the request. For more information, see `Using service-linked roles for Q Apps <https://docs.aws.amazon.com/amazonq/latest/qbusiness-ug/using-service-linked-roles-qapps.html>`_ .

       When you create an application, Amazon Q Business may securely transmit data for processing from your selected AWS region, but within your geography. For more information, see `Cross region inference in Amazon Q Business <https://docs.aws.amazon.com/amazonq/latest/qbusiness-ug/cross-region-inference.html>`_ .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-qbusiness-application.html
    :cloudformationResource: AWS::QBusiness::Application
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_application_logs_mixin = qbusiness_mixins.CfnApplicationLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::QBusiness::Application``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e84fe8d369c72562838387fdaae117e98be3cf0570e02903adb20cf2508b27f9)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62dc97b6e94872349ea0b8ac24843a120b9852800b12632288610257ed38e845)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1265d846673268ba93d93a93dd82e96447415ffec70165e1bf7fe6fc26c78981)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EVENT_LOGS")
    def EVENT_LOGS(cls) -> "CfnApplicationEventLogs":
        return typing.cast("CfnApplicationEventLogs", jsii.sget(cls, "EVENT_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="SYNC_JOB_LOGS")
    def SYNC_JOB_LOGS(cls) -> "CfnApplicationSyncJobLogs":
        return typing.cast("CfnApplicationSyncJobLogs", jsii.sget(cls, "SYNC_JOB_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnApplicationSyncJobLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogs",
):
    '''Builder for CfnApplicationLogsMixin to generate SYNC_JOB_LOGS for CfnApplication.

    :cloudformationResource: AWS::QBusiness::Application
    :logType: SYNC_JOB_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
        
        cfn_application_sync_job_logs = qbusiness_mixins.CfnApplicationSyncJobLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationSyncJobLogsRecordFields"]] = None,
    ) -> "CfnApplicationLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__82791fab0ffd270b4cfaa6eca8f85cbb9cdabcbc01e8fa0f09af27169621d9df)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnApplicationSyncJobLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnApplicationLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnApplicationSyncJobLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationSyncJobLogsRecordFields"]] = None,
    ) -> "CfnApplicationLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a7c853e432127afc1e5b7e60825df1729a6e13477c1049de8aa9dbf3e09b4a5c)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnApplicationSyncJobLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnApplicationLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnApplicationSyncJobLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationSyncJobLogsRecordFields"]] = None,
    ) -> "CfnApplicationLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a7988e4f14e0dbf66a558d4f53f2b1e80e6c64e86c51534a75311fb9dc1f0f2)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnApplicationSyncJobLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnApplicationLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnApplicationSyncJobLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationSyncJobLogsRecordFields"]] = None,
    ) -> "CfnApplicationLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__37f3f8f9a207e71e32c156240352cd9b1b3081f399d986bb2401c056e3110caa)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnApplicationSyncJobLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnApplicationLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnApplicationSyncJobLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationSyncJobLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
            
            cfn_application_sync_job_logs_dest_props = qbusiness_mixins.CfnApplicationSyncJobLogsDestProps(
                record_fields=[qbusiness_mixins.CfnApplicationSyncJobLogsRecordFields.AWSACCOUNTID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93b84b52f42f242d10b070d15693ca792265ec8bbc6fefdfb1b224684f4d2c61)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnApplicationSyncJobLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnApplicationSyncJobLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnApplicationSyncJobLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnApplicationSyncJobLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnApplicationSyncJobLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationSyncJobLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
            
            cfn_application_sync_job_logs_firehose_props = qbusiness_mixins.CfnApplicationSyncJobLogsFirehoseProps(
                output_format=qbusiness_mixins.CfnApplicationSyncJobLogsOutputFormat.Firehose.JSON,
                record_fields=[qbusiness_mixins.CfnApplicationSyncJobLogsRecordFields.AWSACCOUNTID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4d3c04a696f92e74590570369f0293e3934eeb31ac7467d3d116f6dc42f888fd)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnApplicationSyncJobLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnApplicationSyncJobLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnApplicationSyncJobLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnApplicationSyncJobLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnApplicationSyncJobLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnApplicationSyncJobLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnApplicationSyncJobLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationSyncJobLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
            
            cfn_application_sync_job_logs_log_group_props = qbusiness_mixins.CfnApplicationSyncJobLogsLogGroupProps(
                output_format=qbusiness_mixins.CfnApplicationSyncJobLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[qbusiness_mixins.CfnApplicationSyncJobLogsRecordFields.AWSACCOUNTID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5dd66a3d38a487cdff1ca33f970b842f2aa3441835b5f6bad501884734096a0)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnApplicationSyncJobLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnApplicationSyncJobLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnApplicationSyncJobLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnApplicationSyncJobLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnApplicationSyncJobLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnApplicationSyncJobLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnApplicationSyncJobLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
        
        cfn_application_sync_job_logs_output_format = qbusiness_mixins.CfnApplicationSyncJobLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsRecordFields"
)
class CfnApplicationSyncJobLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    AWSACCOUNTID = "AWSACCOUNTID"
    '''
    :stability: experimental
    '''
    DATASOURCEID = "DATASOURCEID"
    '''
    :stability: experimental
    '''
    SYNCJOBID = "SYNCJOBID"
    '''
    :stability: experimental
    '''
    INDEXID = "INDEXID"
    '''
    :stability: experimental
    '''
    MEMBERNAME = "MEMBERNAME"
    '''
    :stability: experimental
    '''
    MEMBERGLOBALNAME = "MEMBERGLOBALNAME"
    '''
    :stability: experimental
    '''
    DOCUMENTID = "DOCUMENTID"
    '''
    :stability: experimental
    '''
    DOCUMENTTITLE = "DOCUMENTTITLE"
    '''
    :stability: experimental
    '''
    SOURCEURI = "SOURCEURI"
    '''
    :stability: experimental
    '''
    ACL = "ACL"
    '''
    :stability: experimental
    '''
    METADATA = "METADATA"
    '''
    :stability: experimental
    '''
    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    CRAWLACTION = "CRAWLACTION"
    '''
    :stability: experimental
    '''
    CRAWLSTATUS = "CRAWLSTATUS"
    '''
    :stability: experimental
    '''
    SYNCSTATUS = "SYNCSTATUS"
    '''
    :stability: experimental
    '''
    INDEXSTATUS = "INDEXSTATUS"
    '''
    :stability: experimental
    '''
    CONNECTORDOCUMENTSTATUS = "CONNECTORDOCUMENTSTATUS"
    '''
    :stability: experimental
    '''
    MEMBERTYPE = "MEMBERTYPE"
    '''
    :stability: experimental
    '''
    ISMEMBERFEDERATED = "ISMEMBERFEDERATED"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    JSONMESSAGE = "JSONMESSAGE"
    '''
    :stability: experimental
    '''
    GROUPNAME = "GROUPNAME"
    '''
    :stability: experimental
    '''
    GROUPGLOBALNAME = "GROUPGLOBALNAME"
    '''
    :stability: experimental
    '''
    ISGROUPFEDERATED = "ISGROUPFEDERATED"
    '''
    :stability: experimental
    '''
    HASHEDDOCUMENTID = "HASHEDDOCUMENTID"
    '''
    :stability: experimental
    '''
    CONTENTTYPE = "CONTENTTYPE"
    '''
    :stability: experimental
    '''
    INTERMEDIATESTATUS = "INTERMEDIATESTATUS"
    '''
    :stability: experimental
    '''
    ERRORMSG = "ERRORMSG"
    '''
    :stability: experimental
    '''
    APPLICATIONID = "APPLICATIONID"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    FEATURENAME = "FEATURENAME"
    '''
    :stability: experimental
    '''
    LOGLEVEL = "LOGLEVEL"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_qbusiness.mixins.CfnApplicationSyncJobLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnApplicationSyncJobLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnApplicationSyncJobLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnApplicationSyncJobLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_qbusiness import mixins as qbusiness_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_application_sync_job_logs_s3_props = qbusiness_mixins.CfnApplicationSyncJobLogsS3Props(
                encryption_key=key_ref,
                output_format=qbusiness_mixins.CfnApplicationSyncJobLogsOutputFormat.S3.JSON,
                record_fields=[qbusiness_mixins.CfnApplicationSyncJobLogsRecordFields.AWSACCOUNTID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__95ed768293fd0309f5a578337291cae88c2f3fcec934a2befb245762e5529689)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnApplicationSyncJobLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnApplicationSyncJobLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnApplicationSyncJobLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnApplicationSyncJobLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnApplicationSyncJobLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnApplicationEventLogs",
    "CfnApplicationEventLogsDestProps",
    "CfnApplicationEventLogsFirehoseProps",
    "CfnApplicationEventLogsLogGroupProps",
    "CfnApplicationEventLogsOutputFormat",
    "CfnApplicationEventLogsRecordFields",
    "CfnApplicationEventLogsS3Props",
    "CfnApplicationLogsMixin",
    "CfnApplicationSyncJobLogs",
    "CfnApplicationSyncJobLogsDestProps",
    "CfnApplicationSyncJobLogsFirehoseProps",
    "CfnApplicationSyncJobLogsLogGroupProps",
    "CfnApplicationSyncJobLogsOutputFormat",
    "CfnApplicationSyncJobLogsRecordFields",
    "CfnApplicationSyncJobLogsS3Props",
]

publication.publish()

def _typecheckingstub__2e31ee924e79c60d654ef7420c021ff352b9f83de29a9ccc62d37a046716a035(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d34e31e7f28e6d9623407543aa02e24a98471b0062cc49fcc9cb33da27c54014(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnApplicationEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a12a04f7977985f75ecb608750d79b72a20f7e5c1b93bfdb63908e7268d0f453(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnApplicationEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c4f7d1ed69da227cb7bad96687fd5cc95437dd676e0866347acdd9d859b0081(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnApplicationEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__75d8672a14150d6eb40605d6be671736a54661fbb580c4225cc39fac54967a35(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bfb31f2e5f92ecc4eb9ff6529168fdac2ded2fa8eba3f1cad39289110906317(
    *,
    output_format: typing.Optional[CfnApplicationEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__44cac0b6388cb9fdf068e06877b891290a7d795375487edd74db4648059aff54(
    *,
    output_format: typing.Optional[CfnApplicationEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3f8acd7118d4438b0f5dfecd15a28b54b75d0be6835be32e9c86214936ebe24(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnApplicationEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e84fe8d369c72562838387fdaae117e98be3cf0570e02903adb20cf2508b27f9(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62dc97b6e94872349ea0b8ac24843a120b9852800b12632288610257ed38e845(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1265d846673268ba93d93a93dd82e96447415ffec70165e1bf7fe6fc26c78981(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__82791fab0ffd270b4cfaa6eca8f85cbb9cdabcbc01e8fa0f09af27169621d9df(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationSyncJobLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a7c853e432127afc1e5b7e60825df1729a6e13477c1049de8aa9dbf3e09b4a5c(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnApplicationSyncJobLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationSyncJobLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a7988e4f14e0dbf66a558d4f53f2b1e80e6c64e86c51534a75311fb9dc1f0f2(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnApplicationSyncJobLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationSyncJobLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37f3f8f9a207e71e32c156240352cd9b1b3081f399d986bb2401c056e3110caa(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnApplicationSyncJobLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationSyncJobLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93b84b52f42f242d10b070d15693ca792265ec8bbc6fefdfb1b224684f4d2c61(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationSyncJobLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4d3c04a696f92e74590570369f0293e3934eeb31ac7467d3d116f6dc42f888fd(
    *,
    output_format: typing.Optional[CfnApplicationSyncJobLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationSyncJobLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5dd66a3d38a487cdff1ca33f970b842f2aa3441835b5f6bad501884734096a0(
    *,
    output_format: typing.Optional[CfnApplicationSyncJobLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationSyncJobLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95ed768293fd0309f5a578337291cae88c2f3fcec934a2befb245762e5529689(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnApplicationSyncJobLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnApplicationSyncJobLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
