from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnRestApiAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogs",
):
    '''Builder for CfnRestApiLogsMixin to generate ACCESS_LOGS for CfnRestApi.

    :cloudformationResource: AWS::ApiGateway::RestApi
    :logType: ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
        
        cfn_rest_api_access_logs = apigateway_mixins.CfnRestApiAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiAccessLogsRecordFields"]] = None,
    ) -> "CfnRestApiLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3c211f7ea2c129370e3aafd69184a0b51bc548f46dcd922e478026761d4b3f62)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnRestApiAccessLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnRestApiLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnRestApiAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiAccessLogsRecordFields"]] = None,
    ) -> "CfnRestApiLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__abf2a3d23aaa2f4c5b1cac51350186c8908baa3d67c7b63a0402652cd1529957)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnRestApiAccessLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRestApiLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnRestApiAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiAccessLogsRecordFields"]] = None,
    ) -> "CfnRestApiLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba433ea0d999aa4fce57ddd731defe6d2f598d12dd36d5ca4e7e078b985be1f5)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnRestApiAccessLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRestApiLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRestApiAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiAccessLogsRecordFields"]] = None,
    ) -> "CfnRestApiLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d8812465feb49c511104a605e304064cd139664ffd47ed68aaeb1876f4467403)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnRestApiAccessLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnRestApiLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnRestApiAccessLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
            
            cfn_rest_api_access_logs_dest_props = apigateway_mixins.CfnRestApiAccessLogsDestProps(
                record_fields=[apigateway_mixins.CfnRestApiAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1e19aac4ab663a72b1d2849e0fba8fce9d1b36edc72c66f105f24f50adf67854)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRestApiAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRestApiAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRestApiAccessLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRestApiAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRestApiAccessLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
            
            cfn_rest_api_access_logs_firehose_props = apigateway_mixins.CfnRestApiAccessLogsFirehoseProps(
                output_format=apigateway_mixins.CfnRestApiAccessLogsOutputFormat.Firehose.JSON,
                record_fields=[apigateway_mixins.CfnRestApiAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7e691c3a54f5af8143ec429aa2a7cebc6dd7d303e63193d77d0441f47b5f6abc)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRestApiAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRestApiAccessLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRestApiAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRestApiAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRestApiAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRestApiAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRestApiAccessLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
            
            cfn_rest_api_access_logs_log_group_props = apigateway_mixins.CfnRestApiAccessLogsLogGroupProps(
                output_format=apigateway_mixins.CfnRestApiAccessLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[apigateway_mixins.CfnRestApiAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2b3d10d841ef766080e774e6d362e9b4a1f70cd34a13c54e9c56bc17661e1ac7)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRestApiAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRestApiAccessLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRestApiAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRestApiAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRestApiAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRestApiAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnRestApiAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
        
        cfn_rest_api_access_logs_output_format = apigateway_mixins.CfnRestApiAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsRecordFields"
)
class CfnRestApiAccessLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    STAGE = "STAGE"
    '''
    :stability: experimental
    '''
    PAYLOAD = "PAYLOAD"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnRestApiAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRestApiAccessLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiAccessLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_rest_api_access_logs_s3_props = apigateway_mixins.CfnRestApiAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=apigateway_mixins.CfnRestApiAccessLogsOutputFormat.S3.JSON,
                record_fields=[apigateway_mixins.CfnRestApiAccessLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b154f09230bcdcb9ff7d6916788fb5a0c2db3a0e38823f18a49e75e54c05386)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnRestApiAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRestApiAccessLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRestApiAccessLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRestApiAccessLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRestApiAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRestApiExecutionLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogs",
):
    '''Builder for CfnRestApiLogsMixin to generate EXECUTION_LOGS for CfnRestApi.

    :cloudformationResource: AWS::ApiGateway::RestApi
    :logType: EXECUTION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
        
        cfn_rest_api_execution_logs = apigateway_mixins.CfnRestApiExecutionLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiExecutionLogsRecordFields"]] = None,
    ) -> "CfnRestApiLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ebee0d2af129881e92fd81380596be992a4bc895597adf54c45744cb582dd452)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnRestApiExecutionLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnRestApiLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnRestApiExecutionLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiExecutionLogsRecordFields"]] = None,
    ) -> "CfnRestApiLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ddccd091912e4bb24272b76dca197140cf3db05ef4dd63c072df6e0cdfbc62b4)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnRestApiExecutionLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRestApiLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnRestApiExecutionLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiExecutionLogsRecordFields"]] = None,
    ) -> "CfnRestApiLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__092e1f811c6737a944cbb1940e87acecd26190570095c3dd54753779b3c45f38)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnRestApiExecutionLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRestApiLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRestApiExecutionLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiExecutionLogsRecordFields"]] = None,
    ) -> "CfnRestApiLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__65b07efdcfc8303713ca613d58281c1c81962fe51f5f27f8acbd58bde29b7d96)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnRestApiExecutionLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnRestApiLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnRestApiExecutionLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiExecutionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
            
            cfn_rest_api_execution_logs_dest_props = apigateway_mixins.CfnRestApiExecutionLogsDestProps(
                record_fields=[apigateway_mixins.CfnRestApiExecutionLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3cea01d6a76ae1436380ec6e6fef05280a6661de202cfcb22ffe7a15b1a9781)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRestApiExecutionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRestApiExecutionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRestApiExecutionLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRestApiExecutionLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRestApiExecutionLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiExecutionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
            
            cfn_rest_api_execution_logs_firehose_props = apigateway_mixins.CfnRestApiExecutionLogsFirehoseProps(
                output_format=apigateway_mixins.CfnRestApiExecutionLogsOutputFormat.Firehose.JSON,
                record_fields=[apigateway_mixins.CfnRestApiExecutionLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c11898e86fd4a03d95ba91568709be613564e25552f78def255991b70191b76f)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRestApiExecutionLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRestApiExecutionLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRestApiExecutionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRestApiExecutionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRestApiExecutionLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRestApiExecutionLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRestApiExecutionLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiExecutionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
            
            cfn_rest_api_execution_logs_log_group_props = apigateway_mixins.CfnRestApiExecutionLogsLogGroupProps(
                output_format=apigateway_mixins.CfnRestApiExecutionLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[apigateway_mixins.CfnRestApiExecutionLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__68663c6dd7dfb093962a08f29d0f0d8572ef879eddf9a9f661e39e8cc7ba7e5b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRestApiExecutionLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRestApiExecutionLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRestApiExecutionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRestApiExecutionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRestApiExecutionLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRestApiExecutionLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnRestApiExecutionLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
        
        cfn_rest_api_execution_logs_output_format = apigateway_mixins.CfnRestApiExecutionLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsRecordFields"
)
class CfnRestApiExecutionLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    STAGE = "STAGE"
    '''
    :stability: experimental
    '''
    PAYLOAD = "PAYLOAD"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiExecutionLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnRestApiExecutionLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRestApiExecutionLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRestApiExecutionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_rest_api_execution_logs_s3_props = apigateway_mixins.CfnRestApiExecutionLogsS3Props(
                encryption_key=key_ref,
                output_format=apigateway_mixins.CfnRestApiExecutionLogsOutputFormat.S3.JSON,
                record_fields=[apigateway_mixins.CfnRestApiExecutionLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4c825be1076cdf0671e67161e9c5fe0d5495712843d5ec86c7b2f6da99447437)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRestApiExecutionLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRestApiExecutionLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRestApiExecutionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRestApiExecutionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRestApiExecutionLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnRestApiLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_apigateway.mixins.CfnRestApiLogsMixin",
):
    '''The ``AWS::ApiGateway::RestApi`` resource creates a REST API.

    For more information, see `restapi:create <https://docs.aws.amazon.com/apigateway/latest/api/API_CreateRestApi.html>`_ in the *Amazon API Gateway REST API Reference* .
    .. epigraph::

       On January 1, 2016, the Swagger Specification was donated to the `OpenAPI initiative <https://docs.aws.amazon.com/https://www.openapis.org/>`_ , becoming the foundation of the OpenAPI Specification.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-apigateway-restapi.html
    :cloudformationResource: AWS::ApiGateway::RestApi
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_apigateway import mixins as apigateway_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_rest_api_logs_mixin = apigateway_mixins.CfnRestApiLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::ApiGateway::RestApi``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cf0043369e44f46816172bac2aecc25ccd548791f59cbbaae76ac1185798fbae)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0f65a50a6e1bf406fd6516b63f0adb2327e270aafff90aede54c8fca18e336a4)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dbefb12055c69f3aa5eea0ae2a59f79199705e896b88d52a00d34c63cbe9ca01)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ACCESS_LOGS")
    def ACCESS_LOGS(cls) -> "CfnRestApiAccessLogs":
        return typing.cast("CfnRestApiAccessLogs", jsii.sget(cls, "ACCESS_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EXECUTION_LOGS")
    def EXECUTION_LOGS(cls) -> "CfnRestApiExecutionLogs":
        return typing.cast("CfnRestApiExecutionLogs", jsii.sget(cls, "EXECUTION_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnRestApiAccessLogs",
    "CfnRestApiAccessLogsDestProps",
    "CfnRestApiAccessLogsFirehoseProps",
    "CfnRestApiAccessLogsLogGroupProps",
    "CfnRestApiAccessLogsOutputFormat",
    "CfnRestApiAccessLogsRecordFields",
    "CfnRestApiAccessLogsS3Props",
    "CfnRestApiExecutionLogs",
    "CfnRestApiExecutionLogsDestProps",
    "CfnRestApiExecutionLogsFirehoseProps",
    "CfnRestApiExecutionLogsLogGroupProps",
    "CfnRestApiExecutionLogsOutputFormat",
    "CfnRestApiExecutionLogsRecordFields",
    "CfnRestApiExecutionLogsS3Props",
    "CfnRestApiLogsMixin",
]

publication.publish()

def _typecheckingstub__3c211f7ea2c129370e3aafd69184a0b51bc548f46dcd922e478026761d4b3f62(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__abf2a3d23aaa2f4c5b1cac51350186c8908baa3d67c7b63a0402652cd1529957(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnRestApiAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba433ea0d999aa4fce57ddd731defe6d2f598d12dd36d5ca4e7e078b985be1f5(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnRestApiAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8812465feb49c511104a605e304064cd139664ffd47ed68aaeb1876f4467403(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRestApiAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1e19aac4ab663a72b1d2849e0fba8fce9d1b36edc72c66f105f24f50adf67854(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7e691c3a54f5af8143ec429aa2a7cebc6dd7d303e63193d77d0441f47b5f6abc(
    *,
    output_format: typing.Optional[CfnRestApiAccessLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b3d10d841ef766080e774e6d362e9b4a1f70cd34a13c54e9c56bc17661e1ac7(
    *,
    output_format: typing.Optional[CfnRestApiAccessLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b154f09230bcdcb9ff7d6916788fb5a0c2db3a0e38823f18a49e75e54c05386(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRestApiAccessLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiAccessLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ebee0d2af129881e92fd81380596be992a4bc895597adf54c45744cb582dd452(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiExecutionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ddccd091912e4bb24272b76dca197140cf3db05ef4dd63c072df6e0cdfbc62b4(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnRestApiExecutionLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiExecutionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__092e1f811c6737a944cbb1940e87acecd26190570095c3dd54753779b3c45f38(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnRestApiExecutionLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiExecutionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__65b07efdcfc8303713ca613d58281c1c81962fe51f5f27f8acbd58bde29b7d96(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRestApiExecutionLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiExecutionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3cea01d6a76ae1436380ec6e6fef05280a6661de202cfcb22ffe7a15b1a9781(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiExecutionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c11898e86fd4a03d95ba91568709be613564e25552f78def255991b70191b76f(
    *,
    output_format: typing.Optional[CfnRestApiExecutionLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiExecutionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__68663c6dd7dfb093962a08f29d0f0d8572ef879eddf9a9f661e39e8cc7ba7e5b(
    *,
    output_format: typing.Optional[CfnRestApiExecutionLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiExecutionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c825be1076cdf0671e67161e9c5fe0d5495712843d5ec86c7b2f6da99447437(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRestApiExecutionLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRestApiExecutionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cf0043369e44f46816172bac2aecc25ccd548791f59cbbaae76ac1185798fbae(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0f65a50a6e1bf406fd6516b63f0adb2327e270aafff90aede54c8fca18e336a4(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dbefb12055c69f3aa5eea0ae2a59f79199705e896b88d52a00d34c63cbe9ca01(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
