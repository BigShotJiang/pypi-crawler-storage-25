from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class AWSXRayInsightUpdate(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_xray.events.AWSXRayInsightUpdate",
):
    '''(experimental) EventBridge event pattern for aws.xray@AWSXRayInsightUpdate.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_xray import events as xray_events
        
        a_wSXRay_insight_update = xray_events.AWSXRayInsightUpdate()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="awsXRayInsightUpdatePattern")
    @builtins.classmethod
    def aws_x_ray_insight_update_pattern(
        cls,
        *,
        categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        client_request_impact_statistics: typing.Optional[typing.Union["AWSXRayInsightUpdate.ClientRequestImpactStatistics", typing.Dict[builtins.str, typing.Any]]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Union["AWSXRayInsightUpdate.Event", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        root_cause_service_id: typing.Optional[typing.Union["AWSXRayInsightUpdate.RootCauseServiceId", typing.Dict[builtins.str, typing.Any]]] = None,
        root_cause_service_request_impact_statistics: typing.Optional[typing.Union["AWSXRayInsightUpdate.ClientRequestImpactStatistics", typing.Dict[builtins.str, typing.Any]]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        summary: typing.Optional[typing.Sequence[builtins.str]] = None,
        top_anomalous_services: typing.Optional[typing.Sequence[typing.Union["AWSXRayInsightUpdate.AwsxRayInsightUpdateItem", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS X-Ray Insight Update.

        :param categories: (experimental) Categories property. Specify an array of string values to match this event if the actual value of Categories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param client_request_impact_statistics: (experimental) ClientRequestImpactStatistics property. Specify an array of string values to match this event if the actual value of ClientRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) Event property. Specify an array of string values to match this event if the actual value of Event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param group_name: (experimental) GroupName property. Specify an array of string values to match this event if the actual value of GroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param insight_id: (experimental) InsightId property. Specify an array of string values to match this event if the actual value of InsightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param root_cause_service_id: (experimental) RootCauseServiceId property. Specify an array of string values to match this event if the actual value of RootCauseServiceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param root_cause_service_request_impact_statistics: (experimental) RootCauseServiceRequestImpactStatistics property. Specify an array of string values to match this event if the actual value of RootCauseServiceRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) State property. Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param summary: (experimental) Summary property. Specify an array of string values to match this event if the actual value of Summary is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param top_anomalous_services: (experimental) TopAnomalousServices property. Specify an array of string values to match this event if the actual value of TopAnomalousServices is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSXRayInsightUpdate.AWSXRayInsightUpdateProps(
            categories=categories,
            client_request_impact_statistics=client_request_impact_statistics,
            end_time=end_time,
            event=event,
            event_metadata=event_metadata,
            group_name=group_name,
            insight_id=insight_id,
            root_cause_service_id=root_cause_service_id,
            root_cause_service_request_impact_statistics=root_cause_service_request_impact_statistics,
            start_time=start_time,
            state=state,
            summary=summary,
            top_anomalous_services=top_anomalous_services,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "awsXRayInsightUpdatePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_xray.events.AWSXRayInsightUpdate.AWSXRayInsightUpdateProps",
        jsii_struct_bases=[],
        name_mapping={
            "categories": "categories",
            "client_request_impact_statistics": "clientRequestImpactStatistics",
            "end_time": "endTime",
            "event": "event",
            "event_metadata": "eventMetadata",
            "group_name": "groupName",
            "insight_id": "insightId",
            "root_cause_service_id": "rootCauseServiceId",
            "root_cause_service_request_impact_statistics": "rootCauseServiceRequestImpactStatistics",
            "start_time": "startTime",
            "state": "state",
            "summary": "summary",
            "top_anomalous_services": "topAnomalousServices",
        },
    )
    class AWSXRayInsightUpdateProps:
        def __init__(
            self,
            *,
            categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            client_request_impact_statistics: typing.Optional[typing.Union["AWSXRayInsightUpdate.ClientRequestImpactStatistics", typing.Dict[builtins.str, typing.Any]]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Union["AWSXRayInsightUpdate.Event", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            root_cause_service_id: typing.Optional[typing.Union["AWSXRayInsightUpdate.RootCauseServiceId", typing.Dict[builtins.str, typing.Any]]] = None,
            root_cause_service_request_impact_statistics: typing.Optional[typing.Union["AWSXRayInsightUpdate.ClientRequestImpactStatistics", typing.Dict[builtins.str, typing.Any]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            summary: typing.Optional[typing.Sequence[builtins.str]] = None,
            top_anomalous_services: typing.Optional[typing.Sequence[typing.Union["AWSXRayInsightUpdate.AwsxRayInsightUpdateItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.xray@AWSXRayInsightUpdate event.

            :param categories: (experimental) Categories property. Specify an array of string values to match this event if the actual value of Categories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param client_request_impact_statistics: (experimental) ClientRequestImpactStatistics property. Specify an array of string values to match this event if the actual value of ClientRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) Event property. Specify an array of string values to match this event if the actual value of Event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param group_name: (experimental) GroupName property. Specify an array of string values to match this event if the actual value of GroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insight_id: (experimental) InsightId property. Specify an array of string values to match this event if the actual value of InsightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param root_cause_service_id: (experimental) RootCauseServiceId property. Specify an array of string values to match this event if the actual value of RootCauseServiceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param root_cause_service_request_impact_statistics: (experimental) RootCauseServiceRequestImpactStatistics property. Specify an array of string values to match this event if the actual value of RootCauseServiceRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) State property. Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param summary: (experimental) Summary property. Specify an array of string values to match this event if the actual value of Summary is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param top_anomalous_services: (experimental) TopAnomalousServices property. Specify an array of string values to match this event if the actual value of TopAnomalousServices is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_xray import events as xray_events
                
                # names: Any
                
                a_wSXRay_insight_update_props = xray_events.AWSXRayInsightUpdate.AWSXRayInsightUpdateProps(
                    categories=["categories"],
                    client_request_impact_statistics=xray_events.AWSXRayInsightUpdate.ClientRequestImpactStatistics(
                        fault_count=["faultCount"],
                        ok_count=["okCount"],
                        total_count=["totalCount"]
                    ),
                    end_time=["endTime"],
                    event=xray_events.AWSXRayInsightUpdate.Event(
                        client_request_impact_statistics=xray_events.AWSXRayInsightUpdate.ClientRequestImpactStatistics(
                            fault_count=["faultCount"],
                            ok_count=["okCount"],
                            total_count=["totalCount"]
                        ),
                        event_time=["eventTime"],
                        root_cause_service_request_impact_statistics=xray_events.AWSXRayInsightUpdate.ClientRequestImpactStatistics(
                            fault_count=["faultCount"],
                            ok_count=["okCount"],
                            total_count=["totalCount"]
                        ),
                        summary=["summary"],
                        top_anomalous_services=[xray_events.AWSXRayInsightUpdate.AwsxRayInsightUpdateItem(
                            service_id=xray_events.AWSXRayInsightUpdate.ServiceId(
                                account_id=["accountId"],
                                name=["name"],
                                names=[names],
                                type=["type"]
                            )
                        )]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    group_name=["groupName"],
                    insight_id=["insightId"],
                    root_cause_service_id=xray_events.AWSXRayInsightUpdate.RootCauseServiceId(
                        account_id=["accountId"],
                        name=["name"],
                        names=[names],
                        type=["type"]
                    ),
                    root_cause_service_request_impact_statistics=xray_events.AWSXRayInsightUpdate.ClientRequestImpactStatistics(
                        fault_count=["faultCount"],
                        ok_count=["okCount"],
                        total_count=["totalCount"]
                    ),
                    start_time=["startTime"],
                    state=["state"],
                    summary=["summary"],
                    top_anomalous_services=[xray_events.AWSXRayInsightUpdate.AwsxRayInsightUpdateItem(
                        service_id=xray_events.AWSXRayInsightUpdate.ServiceId(
                            account_id=["accountId"],
                            name=["name"],
                            names=[names],
                            type=["type"]
                        )
                    )]
                )
            '''
            if isinstance(client_request_impact_statistics, dict):
                client_request_impact_statistics = AWSXRayInsightUpdate.ClientRequestImpactStatistics(**client_request_impact_statistics)
            if isinstance(event, dict):
                event = AWSXRayInsightUpdate.Event(**event)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(root_cause_service_id, dict):
                root_cause_service_id = AWSXRayInsightUpdate.RootCauseServiceId(**root_cause_service_id)
            if isinstance(root_cause_service_request_impact_statistics, dict):
                root_cause_service_request_impact_statistics = AWSXRayInsightUpdate.ClientRequestImpactStatistics(**root_cause_service_request_impact_statistics)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__28dd9249d3b2e140ac6deeeaf0a34485a1a2f9b61193f5f348e89bacd8bfac79)
                check_type(argname="argument categories", value=categories, expected_type=type_hints["categories"])
                check_type(argname="argument client_request_impact_statistics", value=client_request_impact_statistics, expected_type=type_hints["client_request_impact_statistics"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument group_name", value=group_name, expected_type=type_hints["group_name"])
                check_type(argname="argument insight_id", value=insight_id, expected_type=type_hints["insight_id"])
                check_type(argname="argument root_cause_service_id", value=root_cause_service_id, expected_type=type_hints["root_cause_service_id"])
                check_type(argname="argument root_cause_service_request_impact_statistics", value=root_cause_service_request_impact_statistics, expected_type=type_hints["root_cause_service_request_impact_statistics"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument summary", value=summary, expected_type=type_hints["summary"])
                check_type(argname="argument top_anomalous_services", value=top_anomalous_services, expected_type=type_hints["top_anomalous_services"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if categories is not None:
                self._values["categories"] = categories
            if client_request_impact_statistics is not None:
                self._values["client_request_impact_statistics"] = client_request_impact_statistics
            if end_time is not None:
                self._values["end_time"] = end_time
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if group_name is not None:
                self._values["group_name"] = group_name
            if insight_id is not None:
                self._values["insight_id"] = insight_id
            if root_cause_service_id is not None:
                self._values["root_cause_service_id"] = root_cause_service_id
            if root_cause_service_request_impact_statistics is not None:
                self._values["root_cause_service_request_impact_statistics"] = root_cause_service_request_impact_statistics
            if start_time is not None:
                self._values["start_time"] = start_time
            if state is not None:
                self._values["state"] = state
            if summary is not None:
                self._values["summary"] = summary
            if top_anomalous_services is not None:
                self._values["top_anomalous_services"] = top_anomalous_services

        @builtins.property
        def categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Categories property.

            Specify an array of string values to match this event if the actual value of Categories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def client_request_impact_statistics(
            self,
        ) -> typing.Optional["AWSXRayInsightUpdate.ClientRequestImpactStatistics"]:
            '''(experimental) ClientRequestImpactStatistics property.

            Specify an array of string values to match this event if the actual value of ClientRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("client_request_impact_statistics")
            return typing.cast(typing.Optional["AWSXRayInsightUpdate.ClientRequestImpactStatistics"], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndTime property.

            Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional["AWSXRayInsightUpdate.Event"]:
            '''(experimental) Event property.

            Specify an array of string values to match this event if the actual value of Event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional["AWSXRayInsightUpdate.Event"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) GroupName property.

            Specify an array of string values to match this event if the actual value of GroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insight_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InsightId property.

            Specify an array of string values to match this event if the actual value of InsightId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insight_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def root_cause_service_id(
            self,
        ) -> typing.Optional["AWSXRayInsightUpdate.RootCauseServiceId"]:
            '''(experimental) RootCauseServiceId property.

            Specify an array of string values to match this event if the actual value of RootCauseServiceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("root_cause_service_id")
            return typing.cast(typing.Optional["AWSXRayInsightUpdate.RootCauseServiceId"], result)

        @builtins.property
        def root_cause_service_request_impact_statistics(
            self,
        ) -> typing.Optional["AWSXRayInsightUpdate.ClientRequestImpactStatistics"]:
            '''(experimental) RootCauseServiceRequestImpactStatistics property.

            Specify an array of string values to match this event if the actual value of RootCauseServiceRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("root_cause_service_request_impact_statistics")
            return typing.cast(typing.Optional["AWSXRayInsightUpdate.ClientRequestImpactStatistics"], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StartTime property.

            Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) State property.

            Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def summary(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Summary property.

            Specify an array of string values to match this event if the actual value of Summary is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("summary")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def top_anomalous_services(
            self,
        ) -> typing.Optional[typing.List["AWSXRayInsightUpdate.AwsxRayInsightUpdateItem"]]:
            '''(experimental) TopAnomalousServices property.

            Specify an array of string values to match this event if the actual value of TopAnomalousServices is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("top_anomalous_services")
            return typing.cast(typing.Optional[typing.List["AWSXRayInsightUpdate.AwsxRayInsightUpdateItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSXRayInsightUpdateProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_xray.events.AWSXRayInsightUpdate.AwsxRayInsightUpdateItem",
        jsii_struct_bases=[],
        name_mapping={"service_id": "serviceId"},
    )
    class AwsxRayInsightUpdateItem:
        def __init__(
            self,
            *,
            service_id: typing.Optional[typing.Union["AWSXRayInsightUpdate.ServiceId", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for AWSXRayInsightUpdateItem.

            :param service_id: (experimental) ServiceId property. Specify an array of string values to match this event if the actual value of ServiceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_xray import events as xray_events
                
                # names: Any
                
                awsx_ray_insight_update_item = xray_events.AWSXRayInsightUpdate.AwsxRayInsightUpdateItem(
                    service_id=xray_events.AWSXRayInsightUpdate.ServiceId(
                        account_id=["accountId"],
                        name=["name"],
                        names=[names],
                        type=["type"]
                    )
                )
            '''
            if isinstance(service_id, dict):
                service_id = AWSXRayInsightUpdate.ServiceId(**service_id)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b50f5d3b8713115d2b3fe095945f85fd89e36ed4b8b3c0988c2b8859e1eb728a)
                check_type(argname="argument service_id", value=service_id, expected_type=type_hints["service_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if service_id is not None:
                self._values["service_id"] = service_id

        @builtins.property
        def service_id(self) -> typing.Optional["AWSXRayInsightUpdate.ServiceId"]:
            '''(experimental) ServiceId property.

            Specify an array of string values to match this event if the actual value of ServiceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("service_id")
            return typing.cast(typing.Optional["AWSXRayInsightUpdate.ServiceId"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AwsxRayInsightUpdateItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_xray.events.AWSXRayInsightUpdate.ClientRequestImpactStatistics",
        jsii_struct_bases=[],
        name_mapping={
            "fault_count": "faultCount",
            "ok_count": "okCount",
            "total_count": "totalCount",
        },
    )
    class ClientRequestImpactStatistics:
        def __init__(
            self,
            *,
            fault_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            ok_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            total_count: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ClientRequestImpactStatistics.

            :param fault_count: (experimental) FaultCount property. Specify an array of string values to match this event if the actual value of FaultCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ok_count: (experimental) OkCount property. Specify an array of string values to match this event if the actual value of OkCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param total_count: (experimental) TotalCount property. Specify an array of string values to match this event if the actual value of TotalCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_xray import events as xray_events
                
                client_request_impact_statistics = xray_events.AWSXRayInsightUpdate.ClientRequestImpactStatistics(
                    fault_count=["faultCount"],
                    ok_count=["okCount"],
                    total_count=["totalCount"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__25bef61c83f50df3df45246e3c1ce0ed221f0006e14fea511403bde060ef3de4)
                check_type(argname="argument fault_count", value=fault_count, expected_type=type_hints["fault_count"])
                check_type(argname="argument ok_count", value=ok_count, expected_type=type_hints["ok_count"])
                check_type(argname="argument total_count", value=total_count, expected_type=type_hints["total_count"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if fault_count is not None:
                self._values["fault_count"] = fault_count
            if ok_count is not None:
                self._values["ok_count"] = ok_count
            if total_count is not None:
                self._values["total_count"] = total_count

        @builtins.property
        def fault_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) FaultCount property.

            Specify an array of string values to match this event if the actual value of FaultCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fault_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ok_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) OkCount property.

            Specify an array of string values to match this event if the actual value of OkCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ok_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def total_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TotalCount property.

            Specify an array of string values to match this event if the actual value of TotalCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("total_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ClientRequestImpactStatistics(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_xray.events.AWSXRayInsightUpdate.Event",
        jsii_struct_bases=[],
        name_mapping={
            "client_request_impact_statistics": "clientRequestImpactStatistics",
            "event_time": "eventTime",
            "root_cause_service_request_impact_statistics": "rootCauseServiceRequestImpactStatistics",
            "summary": "summary",
            "top_anomalous_services": "topAnomalousServices",
        },
    )
    class Event:
        def __init__(
            self,
            *,
            client_request_impact_statistics: typing.Optional[typing.Union["AWSXRayInsightUpdate.ClientRequestImpactStatistics", typing.Dict[builtins.str, typing.Any]]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            root_cause_service_request_impact_statistics: typing.Optional[typing.Union["AWSXRayInsightUpdate.ClientRequestImpactStatistics", typing.Dict[builtins.str, typing.Any]]] = None,
            summary: typing.Optional[typing.Sequence[builtins.str]] = None,
            top_anomalous_services: typing.Optional[typing.Sequence[typing.Union["AWSXRayInsightUpdate.AwsxRayInsightUpdateItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for Event.

            :param client_request_impact_statistics: (experimental) ClientRequestImpactStatistics property. Specify an array of string values to match this event if the actual value of ClientRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) EventTime property. Specify an array of string values to match this event if the actual value of EventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param root_cause_service_request_impact_statistics: (experimental) RootCauseServiceRequestImpactStatistics property. Specify an array of string values to match this event if the actual value of RootCauseServiceRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param summary: (experimental) Summary property. Specify an array of string values to match this event if the actual value of Summary is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param top_anomalous_services: (experimental) TopAnomalousServices property. Specify an array of string values to match this event if the actual value of TopAnomalousServices is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_xray import events as xray_events
                
                # names: Any
                
                event = xray_events.AWSXRayInsightUpdate.Event(
                    client_request_impact_statistics=xray_events.AWSXRayInsightUpdate.ClientRequestImpactStatistics(
                        fault_count=["faultCount"],
                        ok_count=["okCount"],
                        total_count=["totalCount"]
                    ),
                    event_time=["eventTime"],
                    root_cause_service_request_impact_statistics=xray_events.AWSXRayInsightUpdate.ClientRequestImpactStatistics(
                        fault_count=["faultCount"],
                        ok_count=["okCount"],
                        total_count=["totalCount"]
                    ),
                    summary=["summary"],
                    top_anomalous_services=[xray_events.AWSXRayInsightUpdate.AwsxRayInsightUpdateItem(
                        service_id=xray_events.AWSXRayInsightUpdate.ServiceId(
                            account_id=["accountId"],
                            name=["name"],
                            names=[names],
                            type=["type"]
                        )
                    )]
                )
            '''
            if isinstance(client_request_impact_statistics, dict):
                client_request_impact_statistics = AWSXRayInsightUpdate.ClientRequestImpactStatistics(**client_request_impact_statistics)
            if isinstance(root_cause_service_request_impact_statistics, dict):
                root_cause_service_request_impact_statistics = AWSXRayInsightUpdate.ClientRequestImpactStatistics(**root_cause_service_request_impact_statistics)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a6f01564cc0fdc856370f6e14eb61fa2d167da4c06faa6abc6e9df789284ec08)
                check_type(argname="argument client_request_impact_statistics", value=client_request_impact_statistics, expected_type=type_hints["client_request_impact_statistics"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument root_cause_service_request_impact_statistics", value=root_cause_service_request_impact_statistics, expected_type=type_hints["root_cause_service_request_impact_statistics"])
                check_type(argname="argument summary", value=summary, expected_type=type_hints["summary"])
                check_type(argname="argument top_anomalous_services", value=top_anomalous_services, expected_type=type_hints["top_anomalous_services"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if client_request_impact_statistics is not None:
                self._values["client_request_impact_statistics"] = client_request_impact_statistics
            if event_time is not None:
                self._values["event_time"] = event_time
            if root_cause_service_request_impact_statistics is not None:
                self._values["root_cause_service_request_impact_statistics"] = root_cause_service_request_impact_statistics
            if summary is not None:
                self._values["summary"] = summary
            if top_anomalous_services is not None:
                self._values["top_anomalous_services"] = top_anomalous_services

        @builtins.property
        def client_request_impact_statistics(
            self,
        ) -> typing.Optional["AWSXRayInsightUpdate.ClientRequestImpactStatistics"]:
            '''(experimental) ClientRequestImpactStatistics property.

            Specify an array of string values to match this event if the actual value of ClientRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("client_request_impact_statistics")
            return typing.cast(typing.Optional["AWSXRayInsightUpdate.ClientRequestImpactStatistics"], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventTime property.

            Specify an array of string values to match this event if the actual value of EventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def root_cause_service_request_impact_statistics(
            self,
        ) -> typing.Optional["AWSXRayInsightUpdate.ClientRequestImpactStatistics"]:
            '''(experimental) RootCauseServiceRequestImpactStatistics property.

            Specify an array of string values to match this event if the actual value of RootCauseServiceRequestImpactStatistics is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("root_cause_service_request_impact_statistics")
            return typing.cast(typing.Optional["AWSXRayInsightUpdate.ClientRequestImpactStatistics"], result)

        @builtins.property
        def summary(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Summary property.

            Specify an array of string values to match this event if the actual value of Summary is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("summary")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def top_anomalous_services(
            self,
        ) -> typing.Optional[typing.List["AWSXRayInsightUpdate.AwsxRayInsightUpdateItem"]]:
            '''(experimental) TopAnomalousServices property.

            Specify an array of string values to match this event if the actual value of TopAnomalousServices is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("top_anomalous_services")
            return typing.cast(typing.Optional[typing.List["AWSXRayInsightUpdate.AwsxRayInsightUpdateItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Event(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_xray.events.AWSXRayInsightUpdate.RootCauseServiceId",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "name": "name",
            "names": "names",
            "type": "type",
        },
    )
    class RootCauseServiceId:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            names: typing.Optional[typing.Sequence[typing.Any]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RootCauseServiceId.

            :param account_id: (experimental) AccountId property. Specify an array of string values to match this event if the actual value of AccountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) Name property. Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param names: (experimental) Names property. Specify an array of string values to match this event if the actual value of Names is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) Type property. Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_xray import events as xray_events
                
                # names: Any
                
                root_cause_service_id = xray_events.AWSXRayInsightUpdate.RootCauseServiceId(
                    account_id=["accountId"],
                    name=["name"],
                    names=[names],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__245ddeb6f11914168c3360fe752146d18cdfbce503574cead92bf5e7995a94b2)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument names", value=names, expected_type=type_hints["names"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if name is not None:
                self._values["name"] = name
            if names is not None:
                self._values["names"] = names
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AccountId property.

            Specify an array of string values to match this event if the actual value of AccountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Name property.

            Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def names(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) Names property.

            Specify an array of string values to match this event if the actual value of Names is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("names")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Type property.

            Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RootCauseServiceId(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_xray.events.AWSXRayInsightUpdate.ServiceId",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "name": "name",
            "names": "names",
            "type": "type",
        },
    )
    class ServiceId:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            names: typing.Optional[typing.Sequence[typing.Any]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ServiceId.

            :param account_id: (experimental) AccountId property. Specify an array of string values to match this event if the actual value of AccountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) Name property. Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param names: (experimental) Names property. Specify an array of string values to match this event if the actual value of Names is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) Type property. Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_xray import events as xray_events
                
                # names: Any
                
                service_id = xray_events.AWSXRayInsightUpdate.ServiceId(
                    account_id=["accountId"],
                    name=["name"],
                    names=[names],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3eddaf9c632ee515290a455bcec24b2b6af44854c74082359c494c6783fc35a1)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument names", value=names, expected_type=type_hints["names"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if name is not None:
                self._values["name"] = name
            if names is not None:
                self._values["names"] = names
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AccountId property.

            Specify an array of string values to match this event if the actual value of AccountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Name property.

            Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def names(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) Names property.

            Specify an array of string values to match this event if the actual value of Names is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("names")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Type property.

            Specify an array of string values to match this event if the actual value of Type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ServiceId(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "AWSXRayInsightUpdate",
]

publication.publish()

def _typecheckingstub__28dd9249d3b2e140ac6deeeaf0a34485a1a2f9b61193f5f348e89bacd8bfac79(
    *,
    categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    client_request_impact_statistics: typing.Optional[typing.Union[AWSXRayInsightUpdate.ClientRequestImpactStatistics, typing.Dict[builtins.str, typing.Any]]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Union[AWSXRayInsightUpdate.Event, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    insight_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    root_cause_service_id: typing.Optional[typing.Union[AWSXRayInsightUpdate.RootCauseServiceId, typing.Dict[builtins.str, typing.Any]]] = None,
    root_cause_service_request_impact_statistics: typing.Optional[typing.Union[AWSXRayInsightUpdate.ClientRequestImpactStatistics, typing.Dict[builtins.str, typing.Any]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    summary: typing.Optional[typing.Sequence[builtins.str]] = None,
    top_anomalous_services: typing.Optional[typing.Sequence[typing.Union[AWSXRayInsightUpdate.AwsxRayInsightUpdateItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b50f5d3b8713115d2b3fe095945f85fd89e36ed4b8b3c0988c2b8859e1eb728a(
    *,
    service_id: typing.Optional[typing.Union[AWSXRayInsightUpdate.ServiceId, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25bef61c83f50df3df45246e3c1ce0ed221f0006e14fea511403bde060ef3de4(
    *,
    fault_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    ok_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    total_count: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6f01564cc0fdc856370f6e14eb61fa2d167da4c06faa6abc6e9df789284ec08(
    *,
    client_request_impact_statistics: typing.Optional[typing.Union[AWSXRayInsightUpdate.ClientRequestImpactStatistics, typing.Dict[builtins.str, typing.Any]]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    root_cause_service_request_impact_statistics: typing.Optional[typing.Union[AWSXRayInsightUpdate.ClientRequestImpactStatistics, typing.Dict[builtins.str, typing.Any]]] = None,
    summary: typing.Optional[typing.Sequence[builtins.str]] = None,
    top_anomalous_services: typing.Optional[typing.Sequence[typing.Union[AWSXRayInsightUpdate.AwsxRayInsightUpdateItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__245ddeb6f11914168c3360fe752146d18cdfbce503574cead92bf5e7995a94b2(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    names: typing.Optional[typing.Sequence[typing.Any]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3eddaf9c632ee515290a455bcec24b2b6af44854c74082359c494c6783fc35a1(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    names: typing.Optional[typing.Sequence[typing.Any]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
