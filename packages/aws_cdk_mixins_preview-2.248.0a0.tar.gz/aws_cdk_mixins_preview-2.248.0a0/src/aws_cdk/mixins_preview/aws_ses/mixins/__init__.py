from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnMailManagerIngressPointApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogs",
):
    '''Builder for CfnMailManagerIngressPointLogsMixin to generate APPLICATION_LOGS for CfnMailManagerIngressPoint.

    :cloudformationResource: AWS::SES::MailManagerIngressPoint
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
        
        cfn_mail_manager_ingress_point_application_logs = ses_mixins.CfnMailManagerIngressPointApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointApplicationLogsRecordFields"]] = None,
    ) -> "CfnMailManagerIngressPointLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d5d51a5904e27f30455c9cc0cd2f7213798b985c046975d66ed8e540754bc5c0)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnMailManagerIngressPointApplicationLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnMailManagerIngressPointLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointApplicationLogsRecordFields"]] = None,
    ) -> "CfnMailManagerIngressPointLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b78aa685beb92a7b16017fb26939ae5b16b5ecfb43ca09b94c50a38d91229db2)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnMailManagerIngressPointApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMailManagerIngressPointLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointApplicationLogsRecordFields"]] = None,
    ) -> "CfnMailManagerIngressPointLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4fa0f4958446455a53f3f095141d0e11ca8344caffadba14d487a55eb75ff9e7)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnMailManagerIngressPointApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMailManagerIngressPointLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointApplicationLogsRecordFields"]] = None,
    ) -> "CfnMailManagerIngressPointLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a8db046685f3ebbea9d865cd39e0082220cf76e7802b29f6dbf9c5405dff4520)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnMailManagerIngressPointApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnMailManagerIngressPointLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnMailManagerIngressPointApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_ingress_point_application_logs_dest_props = ses_mixins.CfnMailManagerIngressPointApplicationLogsDestProps(
                record_fields=[ses_mixins.CfnMailManagerIngressPointApplicationLogsRecordFields.INGRESS_POINT_TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a6376a2e9a2b44f2568be987bb50be79a35ee643579bb451ab156907be2656b)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerIngressPointApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerIngressPointApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerIngressPointApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMailManagerIngressPointApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_ingress_point_application_logs_firehose_props = ses_mixins.CfnMailManagerIngressPointApplicationLogsFirehoseProps(
                output_format=ses_mixins.CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[ses_mixins.CfnMailManagerIngressPointApplicationLogsRecordFields.INGRESS_POINT_TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__084ba31028b192806be7a8b0359482d4eccaf577fdb55412b915793bde12b4df)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerIngressPointApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerIngressPointApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerIngressPointApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMailManagerIngressPointApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_ingress_point_application_logs_log_group_props = ses_mixins.CfnMailManagerIngressPointApplicationLogsLogGroupProps(
                output_format=ses_mixins.CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[ses_mixins.CfnMailManagerIngressPointApplicationLogsRecordFields.INGRESS_POINT_TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a4efb1c5462ab6300d9464175913a30f0f2910857475607c7ff2826665eebd5)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerIngressPointApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerIngressPointApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerIngressPointApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnMailManagerIngressPointApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnMailManagerIngressPointApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
        
        cfn_mail_manager_ingress_point_application_logs_output_format = ses_mixins.CfnMailManagerIngressPointApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsRecordFields"
)
class CfnMailManagerIngressPointApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    INGRESS_POINT_TYPE = "INGRESS_POINT_TYPE"
    '''
    :stability: experimental
    '''
    INGRESS_POINT_ID = "INGRESS_POINT_ID"
    '''
    :stability: experimental
    '''
    SENDER_IP_ADDRESS = "SENDER_IP_ADDRESS"
    '''
    :stability: experimental
    '''
    SMTP_MAIL_FROM = "SMTP_MAIL_FROM"
    '''
    :stability: experimental
    '''
    SMTP_HELO = "SMTP_HELO"
    '''
    :stability: experimental
    '''
    TLS_PROTOCOL = "TLS_PROTOCOL"
    '''
    :stability: experimental
    '''
    RECIPIENTS = "RECIPIENTS"
    '''
    :stability: experimental
    '''
    INGRESS_POINT_METADATA = "INGRESS_POINT_METADATA"
    '''
    :stability: experimental
    '''
    TLS_CIPHER_SUITE = "TLS_CIPHER_SUITE"
    '''
    :stability: experimental
    '''
    MESSAGE_SIZE_BYTES = "MESSAGE_SIZE_BYTES"
    '''
    :stability: experimental
    '''
    RULE_SET_ID = "RULE_SET_ID"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    MESSAGE_ID = "MESSAGE_ID"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnMailManagerIngressPointApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_mail_manager_ingress_point_application_logs_s3_props = ses_mixins.CfnMailManagerIngressPointApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=ses_mixins.CfnMailManagerIngressPointApplicationLogsOutputFormat.S3.JSON,
                record_fields=[ses_mixins.CfnMailManagerIngressPointApplicationLogsRecordFields.INGRESS_POINT_TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__86a1e26d01ac7fbbb191431d80577c2760d6284d239e2ffe652cb434296d9efa)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerIngressPointApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerIngressPointApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerIngressPointApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerIngressPointApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnMailManagerIngressPointLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointLogsMixin",
):
    '''Resource to provision an ingress endpoint for receiving email.

    An ingress endpoint serves as the entry point for incoming emails, allowing you to define how emails are received and processed within your AWS environment.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ses-mailmanageringresspoint.html
    :cloudformationResource: AWS::SES::MailManagerIngressPoint
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_mail_manager_ingress_point_logs_mixin = ses_mixins.CfnMailManagerIngressPointLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::SES::MailManagerIngressPoint``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a6fcbb34a2c10891de86d0385859a8bebbf3ae97fb87a3e3f216648008b8172)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e615252dbc0f8508c0d606c357357d1513e80be8a063576eb523aa4ae5dae30)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ecf0481f80d967c4bc56a19e0dc7ea6ea6817835d7d2d767e38be69d94da197b)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnMailManagerIngressPointApplicationLogs":
        return typing.cast("CfnMailManagerIngressPointApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TRAFFIC_POLICY_DEBUG_LOGS")
    def TRAFFIC_POLICY_DEBUG_LOGS(
        cls,
    ) -> "CfnMailManagerIngressPointTrafficPolicyDebugLogs":
        return typing.cast("CfnMailManagerIngressPointTrafficPolicyDebugLogs", jsii.sget(cls, "TRAFFIC_POLICY_DEBUG_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnMailManagerIngressPointTrafficPolicyDebugLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogs",
):
    '''Builder for CfnMailManagerIngressPointLogsMixin to generate TRAFFIC_POLICY_DEBUG_LOGS for CfnMailManagerIngressPoint.

    :cloudformationResource: AWS::SES::MailManagerIngressPoint
    :logType: TRAFFIC_POLICY_DEBUG_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
        
        cfn_mail_manager_ingress_point_traffic_policy_debug_logs = ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]] = None,
    ) -> "CfnMailManagerIngressPointLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__56bf4b6e3edefd4f33d6d0ac48cdb60703b3cdb75725964a25a5545b4396b442)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnMailManagerIngressPointLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]] = None,
    ) -> "CfnMailManagerIngressPointLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4bddc7a91c1124e7c6727457873214e0da3206362918bf4d622f05be6a9891c2)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMailManagerIngressPointLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]] = None,
    ) -> "CfnMailManagerIngressPointLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f37c1531e36b25221fe58b18d015ca0bae514fb9b39a59729275d5dca6bd3fc8)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMailManagerIngressPointLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]] = None,
    ) -> "CfnMailManagerIngressPointLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2380c9270fbf6e609973d7bf68619def6423c4c9e5e3aaf376cad71f703a8b73)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnMailManagerIngressPointLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_ingress_point_traffic_policy_debug_logs_dest_props = ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps(
                record_fields=[ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields.INGRESS_POINT_TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b584474689f58fefe055fbfb014023f5c118d54cb06eed3f3e95f64e8d5b6e3)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_ingress_point_traffic_policy_debug_logs_firehose_props = ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps(
                output_format=ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose.JSON,
                record_fields=[ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields.INGRESS_POINT_TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6821402cc6963a2956d5091e6d91012ad1761b091f6a352bceaf660b20a00c04)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_ingress_point_traffic_policy_debug_logs_log_group_props = ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps(
                output_format=ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields.INGRESS_POINT_TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3f639de91587cfcbde945760d1b6f77575431ac2e8783596b853c2b95ccf4f5b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnMailManagerIngressPointTrafficPolicyDebugLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
        
        cfn_mail_manager_ingress_point_traffic_policy_debug_logs_output_format = ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"
)
class CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    INGRESS_POINT_TYPE = "INGRESS_POINT_TYPE"
    '''
    :stability: experimental
    '''
    INGRESS_POINT_ID = "INGRESS_POINT_ID"
    '''
    :stability: experimental
    '''
    INGRESS_POINT_SESSION_ID = "INGRESS_POINT_SESSION_ID"
    '''
    :stability: experimental
    '''
    TRAFFIC_POLICY_ID = "TRAFFIC_POLICY_ID"
    '''
    :stability: experimental
    '''
    TRAFFIC_POLICY_EVALUATION = "TRAFFIC_POLICY_EVALUATION"
    '''
    :stability: experimental
    '''
    TRAFFIC_POLICY_VERDICT = "TRAFFIC_POLICY_VERDICT"
    '''
    :stability: experimental
    '''
    SENDER_IP_ADDRESS = "SENDER_IP_ADDRESS"
    '''
    :stability: experimental
    '''
    SMTP_MAIL_FROM = "SMTP_MAIL_FROM"
    '''
    :stability: experimental
    '''
    SMTP_HELO = "SMTP_HELO"
    '''
    :stability: experimental
    '''
    TLS_PROTOCOL = "TLS_PROTOCOL"
    '''
    :stability: experimental
    '''
    RECIPIENT = "RECIPIENT"
    '''
    :stability: experimental
    '''
    TLS_CIPHER_SUITE = "TLS_CIPHER_SUITE"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_mail_manager_ingress_point_traffic_policy_debug_logs_s3_props = ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props(
                encryption_key=key_ref,
                output_format=ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3.JSON,
                record_fields=[ses_mixins.CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields.INGRESS_POINT_TYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b5aa3d7b74568a6bf939e19b65f738b0a0c4bfdf63579ddce27715dce7cf942b)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnMailManagerRuleSetApplicationLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogs",
):
    '''Builder for CfnMailManagerRuleSetLogsMixin to generate APPLICATION_LOGS for CfnMailManagerRuleSet.

    :cloudformationResource: AWS::SES::MailManagerRuleSet
    :logType: APPLICATION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
        
        cfn_mail_manager_rule_set_application_logs = ses_mixins.CfnMailManagerRuleSetApplicationLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerRuleSetApplicationLogsRecordFields"]] = None,
    ) -> "CfnMailManagerRuleSetLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a1ea504de6c60cfc2b872b63be306a0e1309ace4185445f805f1cdccc48791cf)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnMailManagerRuleSetApplicationLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnMailManagerRuleSetLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerRuleSetApplicationLogsRecordFields"]] = None,
    ) -> "CfnMailManagerRuleSetLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__507ee61d1f659b529ea98b45ec90f54fcb911b533196b77ed51f8b7061dad2ff)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnMailManagerRuleSetApplicationLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMailManagerRuleSetLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerRuleSetApplicationLogsRecordFields"]] = None,
    ) -> "CfnMailManagerRuleSetLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af63b89dde5af81422232cbe9a7491b18e2492110916181a86e590eda27a2c8e)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnMailManagerRuleSetApplicationLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnMailManagerRuleSetLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerRuleSetApplicationLogsRecordFields"]] = None,
    ) -> "CfnMailManagerRuleSetLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ba42cd9c38a01c1c2755d72c555181b7f11e0b7e3edaa14e2f279ef694945bcd)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnMailManagerRuleSetApplicationLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnMailManagerRuleSetLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnMailManagerRuleSetApplicationLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerRuleSetApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_rule_set_application_logs_dest_props = ses_mixins.CfnMailManagerRuleSetApplicationLogsDestProps(
                record_fields=[ses_mixins.CfnMailManagerRuleSetApplicationLogsRecordFields.RULE_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4efc9c8a567f09225fe52d794ec52571d110fd3212cc127fc1e4d34d9a60e36b)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerRuleSetApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerRuleSetApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerRuleSetApplicationLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMailManagerRuleSetApplicationLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerRuleSetApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_rule_set_application_logs_firehose_props = ses_mixins.CfnMailManagerRuleSetApplicationLogsFirehoseProps(
                output_format=ses_mixins.CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose.JSON,
                record_fields=[ses_mixins.CfnMailManagerRuleSetApplicationLogsRecordFields.RULE_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a5c275c0622bcc6e3945ba82c7167a471049c16dae530aecf46ee8123301b225)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerRuleSetApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerRuleSetApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerRuleSetApplicationLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnMailManagerRuleSetApplicationLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerRuleSetApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            
            cfn_mail_manager_rule_set_application_logs_log_group_props = ses_mixins.CfnMailManagerRuleSetApplicationLogsLogGroupProps(
                output_format=ses_mixins.CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[ses_mixins.CfnMailManagerRuleSetApplicationLogsRecordFields.RULE_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b1b7e2459d7f19b4f8177c1a2a8846acffda8a7145ab7eef2bbda4098b217363)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerRuleSetApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerRuleSetApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerRuleSetApplicationLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnMailManagerRuleSetApplicationLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnMailManagerRuleSetApplicationLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
        
        cfn_mail_manager_rule_set_application_logs_output_format = ses_mixins.CfnMailManagerRuleSetApplicationLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsRecordFields"
)
class CfnMailManagerRuleSetApplicationLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RULE_NAME = "RULE_NAME"
    '''
    :stability: experimental
    '''
    RULE_INDEX = "RULE_INDEX"
    '''
    :stability: experimental
    '''
    RECIPIENTS_MATCHED = "RECIPIENTS_MATCHED"
    '''
    :stability: experimental
    '''
    ACTION_METADATA = "ACTION_METADATA"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    MESSAGE_ID = "MESSAGE_ID"
    '''
    :stability: experimental
    '''
    RULE_SET_NAME = "RULE_SET_NAME"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetApplicationLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnMailManagerRuleSetApplicationLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnMailManagerRuleSetApplicationLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_mail_manager_rule_set_application_logs_s3_props = ses_mixins.CfnMailManagerRuleSetApplicationLogsS3Props(
                encryption_key=key_ref,
                output_format=ses_mixins.CfnMailManagerRuleSetApplicationLogsOutputFormat.S3.JSON,
                record_fields=[ses_mixins.CfnMailManagerRuleSetApplicationLogsRecordFields.RULE_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__31e91368bea3528cd770251d7443a39af0cbb842cf66364c509f1f11a9218c4b)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnMailManagerRuleSetApplicationLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnMailManagerRuleSetApplicationLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnMailManagerRuleSetApplicationLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnMailManagerRuleSetApplicationLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnMailManagerRuleSetLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ses.mixins.CfnMailManagerRuleSetLogsMixin",
):
    '''Resource to create a rule set for a Mail Manager ingress endpoint which contains a list of rules that are evaluated sequentially for each email.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ses-mailmanagerruleset.html
    :cloudformationResource: AWS::SES::MailManagerRuleSet
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_ses import mixins as ses_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_mail_manager_rule_set_logs_mixin = ses_mixins.CfnMailManagerRuleSetLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::SES::MailManagerRuleSet``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eff89b8f63f89d085b1abcb636f0902e76e4098e335c876b71c0d193438537b8)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__61b38d36ae58c8b66349ef0f4827f7625ee95642391d3bfa544124c373f987ba)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1f4aa4944bf1b27534b2a4ee50aa909d323569ee2296cdb959148a34f76bfa9c)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="APPLICATION_LOGS")
    def APPLICATION_LOGS(cls) -> "CfnMailManagerRuleSetApplicationLogs":
        return typing.cast("CfnMailManagerRuleSetApplicationLogs", jsii.sget(cls, "APPLICATION_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnMailManagerIngressPointApplicationLogs",
    "CfnMailManagerIngressPointApplicationLogsDestProps",
    "CfnMailManagerIngressPointApplicationLogsFirehoseProps",
    "CfnMailManagerIngressPointApplicationLogsLogGroupProps",
    "CfnMailManagerIngressPointApplicationLogsOutputFormat",
    "CfnMailManagerIngressPointApplicationLogsRecordFields",
    "CfnMailManagerIngressPointApplicationLogsS3Props",
    "CfnMailManagerIngressPointLogsMixin",
    "CfnMailManagerIngressPointTrafficPolicyDebugLogs",
    "CfnMailManagerIngressPointTrafficPolicyDebugLogsDestProps",
    "CfnMailManagerIngressPointTrafficPolicyDebugLogsFirehoseProps",
    "CfnMailManagerIngressPointTrafficPolicyDebugLogsLogGroupProps",
    "CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat",
    "CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields",
    "CfnMailManagerIngressPointTrafficPolicyDebugLogsS3Props",
    "CfnMailManagerRuleSetApplicationLogs",
    "CfnMailManagerRuleSetApplicationLogsDestProps",
    "CfnMailManagerRuleSetApplicationLogsFirehoseProps",
    "CfnMailManagerRuleSetApplicationLogsLogGroupProps",
    "CfnMailManagerRuleSetApplicationLogsOutputFormat",
    "CfnMailManagerRuleSetApplicationLogsRecordFields",
    "CfnMailManagerRuleSetApplicationLogsS3Props",
    "CfnMailManagerRuleSetLogsMixin",
]

publication.publish()

def _typecheckingstub__d5d51a5904e27f30455c9cc0cd2f7213798b985c046975d66ed8e540754bc5c0(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b78aa685beb92a7b16017fb26939ae5b16b5ecfb43ca09b94c50a38d91229db2(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4fa0f4958446455a53f3f095141d0e11ca8344caffadba14d487a55eb75ff9e7(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a8db046685f3ebbea9d865cd39e0082220cf76e7802b29f6dbf9c5405dff4520(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMailManagerIngressPointApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a6376a2e9a2b44f2568be987bb50be79a35ee643579bb451ab156907be2656b(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__084ba31028b192806be7a8b0359482d4eccaf577fdb55412b915793bde12b4df(
    *,
    output_format: typing.Optional[CfnMailManagerIngressPointApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a4efb1c5462ab6300d9464175913a30f0f2910857475607c7ff2826665eebd5(
    *,
    output_format: typing.Optional[CfnMailManagerIngressPointApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86a1e26d01ac7fbbb191431d80577c2760d6284d239e2ffe652cb434296d9efa(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMailManagerIngressPointApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a6fcbb34a2c10891de86d0385859a8bebbf3ae97fb87a3e3f216648008b8172(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e615252dbc0f8508c0d606c357357d1513e80be8a063576eb523aa4ae5dae30(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ecf0481f80d967c4bc56a19e0dc7ea6ea6817835d7d2d767e38be69d94da197b(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__56bf4b6e3edefd4f33d6d0ac48cdb60703b3cdb75725964a25a5545b4396b442(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4bddc7a91c1124e7c6727457873214e0da3206362918bf4d622f05be6a9891c2(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f37c1531e36b25221fe58b18d015ca0bae514fb9b39a59729275d5dca6bd3fc8(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2380c9270fbf6e609973d7bf68619def6423c4c9e5e3aaf376cad71f703a8b73(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b584474689f58fefe055fbfb014023f5c118d54cb06eed3f3e95f64e8d5b6e3(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6821402cc6963a2956d5091e6d91012ad1761b091f6a352bceaf660b20a00c04(
    *,
    output_format: typing.Optional[CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3f639de91587cfcbde945760d1b6f77575431ac2e8783596b853c2b95ccf4f5b(
    *,
    output_format: typing.Optional[CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b5aa3d7b74568a6bf939e19b65f738b0a0c4bfdf63579ddce27715dce7cf942b(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMailManagerIngressPointTrafficPolicyDebugLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerIngressPointTrafficPolicyDebugLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1ea504de6c60cfc2b872b63be306a0e1309ace4185445f805f1cdccc48791cf(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerRuleSetApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__507ee61d1f659b529ea98b45ec90f54fcb911b533196b77ed51f8b7061dad2ff(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerRuleSetApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af63b89dde5af81422232cbe9a7491b18e2492110916181a86e590eda27a2c8e(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerRuleSetApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba42cd9c38a01c1c2755d72c555181b7f11e0b7e3edaa14e2f279ef694945bcd(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMailManagerRuleSetApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerRuleSetApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4efc9c8a567f09225fe52d794ec52571d110fd3212cc127fc1e4d34d9a60e36b(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerRuleSetApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a5c275c0622bcc6e3945ba82c7167a471049c16dae530aecf46ee8123301b225(
    *,
    output_format: typing.Optional[CfnMailManagerRuleSetApplicationLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerRuleSetApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b1b7e2459d7f19b4f8177c1a2a8846acffda8a7145ab7eef2bbda4098b217363(
    *,
    output_format: typing.Optional[CfnMailManagerRuleSetApplicationLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerRuleSetApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__31e91368bea3528cd770251d7443a39af0cbb842cf66364c509f1f11a9218c4b(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnMailManagerRuleSetApplicationLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnMailManagerRuleSetApplicationLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eff89b8f63f89d085b1abcb636f0902e76e4098e335c876b71c0d193438537b8(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__61b38d36ae58c8b66349ef0f4827f7625ee95642391d3bfa544124c373f987ba(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1f4aa4944bf1b27534b2a4ee50aa909d323569ee2296cdb959148a34f76bfa9c(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
