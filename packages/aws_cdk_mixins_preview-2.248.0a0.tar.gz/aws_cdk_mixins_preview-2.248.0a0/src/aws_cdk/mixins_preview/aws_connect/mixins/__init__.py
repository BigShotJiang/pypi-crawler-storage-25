from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnInstanceAmazonConnectFlowLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogs",
):
    '''Builder for CfnInstanceLogsMixin to generate AMAZON_CONNECT_FLOW_LOGS for CfnInstance.

    :cloudformationResource: AWS::Connect::Instance
    :logType: AMAZON_CONNECT_FLOW_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_connect import mixins as connect_mixins
        
        cfn_instance_amazon_connect_flow_logs = connect_mixins.CfnInstanceAmazonConnectFlowLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceAmazonConnectFlowLogsRecordFields"]] = None,
    ) -> "CfnInstanceLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5675e925b860206ce5fd4abf7370469ad8dac0dc7af85fd9dd4c889d267a322b)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnInstanceAmazonConnectFlowLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnInstanceLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceAmazonConnectFlowLogsRecordFields"]] = None,
    ) -> "CfnInstanceLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f524ccabc53801fb94975d482b7fb463124eafc4ebc48d654cc483de43692a36)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnInstanceAmazonConnectFlowLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnInstanceLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceAmazonConnectFlowLogsRecordFields"]] = None,
    ) -> "CfnInstanceLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6cbfb8169091793561b0df8b00000e4d9789d334697519c2e5aa85a2f3db6c86)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnInstanceAmazonConnectFlowLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnInstanceLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceAmazonConnectFlowLogsRecordFields"]] = None,
    ) -> "CfnInstanceLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__281d7ec173b2cc2ed2c930ba3c1422994f3ed06b15e2ba86daed5a450ab57641)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnInstanceAmazonConnectFlowLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnInstanceLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnInstanceAmazonConnectFlowLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceAmazonConnectFlowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_connect import mixins as connect_mixins
            
            cfn_instance_amazon_connect_flow_logs_dest_props = connect_mixins.CfnInstanceAmazonConnectFlowLogsDestProps(
                record_fields=[connect_mixins.CfnInstanceAmazonConnectFlowLogsRecordFields.INSTANCEARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c1f775d29b8b58d1bc0bea8fcf3b106e354a8b1f1ad4b1b2a2a45f6c7d6521e3)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnInstanceAmazonConnectFlowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnInstanceAmazonConnectFlowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnInstanceAmazonConnectFlowLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnInstanceAmazonConnectFlowLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceAmazonConnectFlowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_connect import mixins as connect_mixins
            
            cfn_instance_amazon_connect_flow_logs_firehose_props = connect_mixins.CfnInstanceAmazonConnectFlowLogsFirehoseProps(
                output_format=connect_mixins.CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose.JSON,
                record_fields=[connect_mixins.CfnInstanceAmazonConnectFlowLogsRecordFields.INSTANCEARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6e1bda4105e74358fdb089389e6a2699a0c5b25c5ce6bd6eeb7bb5706c2c08d8)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnInstanceAmazonConnectFlowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnInstanceAmazonConnectFlowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnInstanceAmazonConnectFlowLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnInstanceAmazonConnectFlowLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceAmazonConnectFlowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_connect import mixins as connect_mixins
            
            cfn_instance_amazon_connect_flow_logs_log_group_props = connect_mixins.CfnInstanceAmazonConnectFlowLogsLogGroupProps(
                output_format=connect_mixins.CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[connect_mixins.CfnInstanceAmazonConnectFlowLogsRecordFields.INSTANCEARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0bfc6587072afc2f1b5991a8f0f960e07a8b5f434543faf018e08cc6feda622b)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnInstanceAmazonConnectFlowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnInstanceAmazonConnectFlowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnInstanceAmazonConnectFlowLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnInstanceAmazonConnectFlowLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnInstanceAmazonConnectFlowLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_connect import mixins as connect_mixins
        
        cfn_instance_amazon_connect_flow_logs_output_format = connect_mixins.CfnInstanceAmazonConnectFlowLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsRecordFields"
)
class CfnInstanceAmazonConnectFlowLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    INSTANCEARN = "INSTANCEARN"
    '''
    :stability: experimental
    '''
    TIMESTAMP = "TIMESTAMP"
    '''
    :stability: experimental
    '''
    ACCOUNTID = "ACCOUNTID"
    '''
    :stability: experimental
    '''
    RESOURCEARN = "RESOURCEARN"
    '''
    :stability: experimental
    '''
    RESOURCETYPE = "RESOURCETYPE"
    '''
    :stability: experimental
    '''
    RESOURCENAME = "RESOURCENAME"
    '''
    :stability: experimental
    '''
    RESOURCEEXECUTIONSTARTTIME = "RESOURCEEXECUTIONSTARTTIME"
    '''
    :stability: experimental
    '''
    RESOURCEPUBLISHTIMESTAMP = "RESOURCEPUBLISHTIMESTAMP"
    '''
    :stability: experimental
    '''
    FLOWTYPE = "FLOWTYPE"
    '''
    :stability: experimental
    '''
    CONTACTID = "CONTACTID"
    '''
    :stability: experimental
    '''
    INITIATIONMETHOD = "INITIATIONMETHOD"
    '''
    :stability: experimental
    '''
    CHANNEL = "CHANNEL"
    '''
    :stability: experimental
    '''
    SUBTYPE = "SUBTYPE"
    '''
    :stability: experimental
    '''
    LOGVERSION = "LOGVERSION"
    '''
    :stability: experimental
    '''
    LOGTYPE = "LOGTYPE"
    '''
    :stability: experimental
    '''
    ACTIONLOGDATA = "ACTIONLOGDATA"
    '''
    :stability: experimental
    '''
    MODULECALLSTACK = "MODULECALLSTACK"
    '''
    :stability: experimental
    '''
    ACTIONCOUNTER = "ACTIONCOUNTER"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceAmazonConnectFlowLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnInstanceAmazonConnectFlowLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceAmazonConnectFlowLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_connect import mixins as connect_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_instance_amazon_connect_flow_logs_s3_props = connect_mixins.CfnInstanceAmazonConnectFlowLogsS3Props(
                encryption_key=key_ref,
                output_format=connect_mixins.CfnInstanceAmazonConnectFlowLogsOutputFormat.S3.JSON,
                record_fields=[connect_mixins.CfnInstanceAmazonConnectFlowLogsRecordFields.INSTANCEARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5d2778ba146ca45fadef075734abb9d66944bdc8d116b344521f64010523ee14)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnInstanceAmazonConnectFlowLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnInstanceAmazonConnectFlowLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnInstanceAmazonConnectFlowLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnInstanceAmazonConnectFlowLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnInstanceLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_connect.mixins.CfnInstanceLogsMixin",
):
    '''*This is a preview release for Amazon Connect . It is subject to change.*.

    Initiates an Amazon Connect instance with all the supported channels enabled. It does not attach any storage, such as Amazon Simple Storage Service (Amazon S3) or Amazon Kinesis.

    Amazon Connect enforces a limit on the total number of instances that you can create or delete in 30 days. If you exceed this limit, you will get an error message indicating there has been an excessive number of attempts at creating or deleting instances. You must wait 30 days before you can restart creating and deleting instances in your account.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-connect-instance.html
    :cloudformationResource: AWS::Connect::Instance
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_connect import mixins as connect_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_instance_logs_mixin = connect_mixins.CfnInstanceLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Connect::Instance``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__002079279089e239349300b2d0a5903bac7ff1cab918690857c88e0aa1736826)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__71c6a4401f1403f580f5c334f43bdc35c02991656897c5d9e7fcc1e7e2454623)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__283f9ad56fd54ee160928c8754f580036fea700d360077b5a1d81ad66d8622c7)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="AMAZON_CONNECT_FLOW_LOGS")
    def AMAZON_CONNECT_FLOW_LOGS(cls) -> "CfnInstanceAmazonConnectFlowLogs":
        return typing.cast("CfnInstanceAmazonConnectFlowLogs", jsii.sget(cls, "AMAZON_CONNECT_FLOW_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnInstanceAmazonConnectFlowLogs",
    "CfnInstanceAmazonConnectFlowLogsDestProps",
    "CfnInstanceAmazonConnectFlowLogsFirehoseProps",
    "CfnInstanceAmazonConnectFlowLogsLogGroupProps",
    "CfnInstanceAmazonConnectFlowLogsOutputFormat",
    "CfnInstanceAmazonConnectFlowLogsRecordFields",
    "CfnInstanceAmazonConnectFlowLogsS3Props",
    "CfnInstanceLogsMixin",
]

publication.publish()

def _typecheckingstub__5675e925b860206ce5fd4abf7370469ad8dac0dc7af85fd9dd4c889d267a322b(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceAmazonConnectFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f524ccabc53801fb94975d482b7fb463124eafc4ebc48d654cc483de43692a36(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceAmazonConnectFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6cbfb8169091793561b0df8b00000e4d9789d334697519c2e5aa85a2f3db6c86(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceAmazonConnectFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__281d7ec173b2cc2ed2c930ba3c1422994f3ed06b15e2ba86daed5a450ab57641(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnInstanceAmazonConnectFlowLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceAmazonConnectFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c1f775d29b8b58d1bc0bea8fcf3b106e354a8b1f1ad4b1b2a2a45f6c7d6521e3(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceAmazonConnectFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6e1bda4105e74358fdb089389e6a2699a0c5b25c5ce6bd6eeb7bb5706c2c08d8(
    *,
    output_format: typing.Optional[CfnInstanceAmazonConnectFlowLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceAmazonConnectFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0bfc6587072afc2f1b5991a8f0f960e07a8b5f434543faf018e08cc6feda622b(
    *,
    output_format: typing.Optional[CfnInstanceAmazonConnectFlowLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceAmazonConnectFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d2778ba146ca45fadef075734abb9d66944bdc8d116b344521f64010523ee14(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnInstanceAmazonConnectFlowLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceAmazonConnectFlowLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__002079279089e239349300b2d0a5903bac7ff1cab918690857c88e0aa1736826(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71c6a4401f1403f580f5c334f43bdc35c02991656897c5d9e7fcc1e7e2454623(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__283f9ad56fd54ee160928c8754f580036fea700d360077b5a1d81ad66d8622c7(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
