from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnPlaybackConfigurationAdDecisionServerLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogs",
):
    '''Builder for CfnPlaybackConfigurationLogsMixin to generate AD_DECISION_SERVER_LOGS for CfnPlaybackConfiguration.

    :cloudformationResource: AWS::MediaTailor::PlaybackConfiguration
    :logType: AD_DECISION_SERVER_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
        
        cfn_playback_configuration_ad_decision_server_logs = mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0212ac1b79afa7baccdcd17e57fc9cd88266be17c8b397a23cc1272d770bb0fa)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnPlaybackConfigurationAdDecisionServerLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e86a052e20c8228bc093ef1e81663e21e26af1acdeb9ebd0590dc4ce4ef2b99)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a630ed534e9ef49e9fa722ba2673200de7833d9ce20ae36627f37365f9fa84ec)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08257b9b52bcc570545a1fda383c2af965d90755db227b2c6b2669a74fe72179)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnPlaybackConfigurationAdDecisionServerLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnPlaybackConfigurationAdDecisionServerLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_ad_decision_server_logs_dest_props = mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsDestProps(
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsRecordFields.ORIGINID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ae6045c4157c0c94df68326404935e98c6954c76a5f9cdd33a4fa9b127ee30c6)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationAdDecisionServerLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_ad_decision_server_logs_firehose_props = mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps(
                output_format=mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose.JSON,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsRecordFields.ORIGINID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51bcbf4341d8a6262e2323e8e30cf4988442ba834e14af562bb1cce7a6208931)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_ad_decision_server_logs_log_group_props = mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps(
                output_format=mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsRecordFields.ORIGINID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c7a7a7285db2c15de00e0feb42f7839930ce050ba0397a74ad33bb135553c6f)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnPlaybackConfigurationAdDecisionServerLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
        
        cfn_playback_configuration_ad_decision_server_logs_output_format = mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"
)
class CfnPlaybackConfigurationAdDecisionServerLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    ORIGINID = "ORIGINID"
    '''
    :stability: experimental
    '''
    CUSTOMERID = "CUSTOMERID"
    '''
    :stability: experimental
    '''
    EVENTTYPE = "EVENTTYPE"
    '''
    :stability: experimental
    '''
    SESSIONTYPE = "SESSIONTYPE"
    '''
    :stability: experimental
    '''
    REQUESTID = "REQUESTID"
    '''
    :stability: experimental
    '''
    EVENTDESCRIPTION = "EVENTDESCRIPTION"
    '''
    :stability: experimental
    '''
    SESSIONID = "SESSIONID"
    '''
    :stability: experimental
    '''
    VODVASTRESPONSETIMEOFFSET = "VODVASTRESPONSETIMEOFFSET"
    '''
    :stability: experimental
    '''
    ADSREQUESTURL = "ADSREQUESTURL"
    '''
    :stability: experimental
    '''
    ADMARKERS = "ADMARKERS"
    '''
    :stability: experimental
    '''
    SEGMENTATIONUPID = "SEGMENTATIONUPID"
    '''
    :stability: experimental
    '''
    SEGMENTATIONTYPEID = "SEGMENTATIONTYPEID"
    '''
    :stability: experimental
    '''
    ORIGINALTARGETURL = "ORIGINALTARGETURL"
    '''
    :stability: experimental
    '''
    UPDATEDTARGETURL = "UPDATEDTARGETURL"
    '''
    :stability: experimental
    '''
    RAWADSREQUEST = "RAWADSREQUEST"
    '''
    :stability: experimental
    '''
    RAWADSREQUESTINDEX = "RAWADSREQUESTINDEX"
    '''
    :stability: experimental
    '''
    RAWADSRESPONSE = "RAWADSRESPONSE"
    '''
    :stability: experimental
    '''
    RAWADSRESPONSEINDEX = "RAWADSRESPONSEINDEX"
    '''
    :stability: experimental
    '''
    AVAIL = "AVAIL"
    '''
    :stability: experimental
    '''
    VASTRESPONSE = "VASTRESPONSE"
    '''
    :stability: experimental
    '''
    VASTAD = "VASTAD"
    '''
    :stability: experimental
    '''
    VODCREATIVEOFFSETS = "VODCREATIVEOFFSETS"
    '''
    :stability: experimental
    '''
    REQUESTHEADERS = "REQUESTHEADERS"
    '''
    :stability: experimental
    '''
    BEACONINFO = "BEACONINFO"
    '''
    :stability: experimental
    '''
    ADBREAKCORRELATIONID = "ADBREAKCORRELATIONID"
    '''
    :stability: experimental
    '''
    PREFETCHSCHEDULENAME = "PREFETCHSCHEDULENAME"
    '''
    :stability: experimental
    '''
    EVENTTIMESTAMP = "EVENTTIMESTAMP"
    '''
    :stability: experimental
    '''
    AWSACCOUNTID = "AWSACCOUNTID"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationAdDecisionServerLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnPlaybackConfigurationAdDecisionServerLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_playback_configuration_ad_decision_server_logs_s3_props = mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsS3Props(
                encryption_key=key_ref,
                output_format=mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3.JSON,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationAdDecisionServerLogsRecordFields.ORIGINID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5a22998b534f25c2e2d7e9bc70c39ad56e7e0827146695953efe16ff9076aae1)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationAdDecisionServerLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationAdDecisionServerLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnPlaybackConfigurationLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationLogsMixin",
):
    '''Adds a new playback configuration to AWS Elemental MediaTailor .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mediatailor-playbackconfiguration.html
    :cloudformationResource: AWS::MediaTailor::PlaybackConfiguration
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_playback_configuration_logs_mixin = mediatailor_mixins.CfnPlaybackConfigurationLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::MediaTailor::PlaybackConfiguration``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8be22dc5fdbd1bf53113a722cc11a9b40329325137f457b06c1a0e52a4e0453b)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__61be5ae7c09b88d8a3fae6f642df86bbdfadab120e49d7ce23b9ac0108b8f205)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d9ece1d228b98eb43999d1e5f071cce2aa5ba0d5b8637938930f2be61005ee29)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="AD_DECISION_SERVER_LOGS")
    def AD_DECISION_SERVER_LOGS(cls) -> "CfnPlaybackConfigurationAdDecisionServerLogs":
        return typing.cast("CfnPlaybackConfigurationAdDecisionServerLogs", jsii.sget(cls, "AD_DECISION_SERVER_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="MANIFEST_SERVICE_LOGS")
    def MANIFEST_SERVICE_LOGS(cls) -> "CfnPlaybackConfigurationManifestServiceLogs":
        return typing.cast("CfnPlaybackConfigurationManifestServiceLogs", jsii.sget(cls, "MANIFEST_SERVICE_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="TRANSCODE_LOGS")
    def TRANSCODE_LOGS(cls) -> "CfnPlaybackConfigurationTranscodeLogs":
        return typing.cast("CfnPlaybackConfigurationTranscodeLogs", jsii.sget(cls, "TRANSCODE_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnPlaybackConfigurationManifestServiceLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogs",
):
    '''Builder for CfnPlaybackConfigurationLogsMixin to generate MANIFEST_SERVICE_LOGS for CfnPlaybackConfiguration.

    :cloudformationResource: AWS::MediaTailor::PlaybackConfiguration
    :logType: MANIFEST_SERVICE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
        
        cfn_playback_configuration_manifest_service_logs = mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ee30b40c967c3ddede60f3474c1333716236f1366bcffe038429d4cf0ace4d55)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnPlaybackConfigurationManifestServiceLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__779bc1620506212603cd0bf2f441fc09f9538cdd5f24bc4a18f176705af08aa9)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnPlaybackConfigurationManifestServiceLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__885cfdc6db35b97c08c385af0249fa780966a96fe797af4141cf20392adcc5a6)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnPlaybackConfigurationManifestServiceLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__014a4750a71f835eca7d99b8d7e79bb5c2ecbdf8e2e3a2ea3109ee4208110f6b)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnPlaybackConfigurationManifestServiceLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnPlaybackConfigurationManifestServiceLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_manifest_service_logs_dest_props = mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsDestProps(
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsRecordFields.CUSTOMERID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f8ea7639cae831bb6e5bb627551ce7ac0291854b8379f792a4ea534e9410c550)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationManifestServiceLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnPlaybackConfigurationManifestServiceLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_manifest_service_logs_firehose_props = mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsFirehoseProps(
                output_format=mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose.JSON,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsRecordFields.CUSTOMERID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a6c249aaf9bff4241a528ac2473dbbc2fe9619835678beae82dc7cea79bfcc22)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationManifestServiceLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnPlaybackConfigurationManifestServiceLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_manifest_service_logs_log_group_props = mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsLogGroupProps(
                output_format=mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsRecordFields.CUSTOMERID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__031150aaafa345a346bc30caca4695e19cb58d04328a3bb579b5d05b5f0640d4)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationManifestServiceLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnPlaybackConfigurationManifestServiceLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnPlaybackConfigurationManifestServiceLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
        
        cfn_playback_configuration_manifest_service_logs_output_format = mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsRecordFields"
)
class CfnPlaybackConfigurationManifestServiceLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    CUSTOMERID = "CUSTOMERID"
    '''
    :stability: experimental
    '''
    EVENTTYPE = "EVENTTYPE"
    '''
    :stability: experimental
    '''
    SESSIONTYPE = "SESSIONTYPE"
    '''
    :stability: experimental
    '''
    REQUESTID = "REQUESTID"
    '''
    :stability: experimental
    '''
    EVENTDESCRIPTION = "EVENTDESCRIPTION"
    '''
    :stability: experimental
    '''
    SESSIONID = "SESSIONID"
    '''
    :stability: experimental
    '''
    ORIGINREQUESTURL = "ORIGINREQUESTURL"
    '''
    :stability: experimental
    '''
    MEDIATAILORPATH = "MEDIATAILORPATH"
    '''
    :stability: experimental
    '''
    RESPONSEBODY = "RESPONSEBODY"
    '''
    :stability: experimental
    '''
    REQUESTNEXTTOKEN = "REQUESTNEXTTOKEN"
    '''
    :stability: experimental
    '''
    ASSETPATH = "ASSETPATH"
    '''
    :stability: experimental
    '''
    ORIGINFULLURL = "ORIGINFULLURL"
    '''
    :stability: experimental
    '''
    ORIGINPREFIXURL = "ORIGINPREFIXURL"
    '''
    :stability: experimental
    '''
    ADDITIONALINFO = "ADDITIONALINFO"
    '''
    :stability: experimental
    '''
    CAUSE = "CAUSE"
    '''
    :stability: experimental
    '''
    RESPONSE = "RESPONSE"
    '''
    :stability: experimental
    '''
    HTTPCODE = "HTTPCODE"
    '''
    :stability: experimental
    '''
    ERRORMESSAGE = "ERRORMESSAGE"
    '''
    :stability: experimental
    '''
    ADADSRESPONSE = "ADADSRESPONSE"
    '''
    :stability: experimental
    '''
    ADADSRAWRESPONSE = "ADADSRAWRESPONSE"
    '''
    :stability: experimental
    '''
    ADADSREQUEST = "ADADSREQUEST"
    '''
    :stability: experimental
    '''
    ADNUMNEWAVAILS = "ADNUMNEWAVAILS"
    '''
    :stability: experimental
    '''
    GENERATEDMEDIAPLAYLIST = "GENERATEDMEDIAPLAYLIST"
    '''
    :stability: experimental
    '''
    REQUESTSTARTTIME = "REQUESTSTARTTIME"
    '''
    :stability: experimental
    '''
    REQUESTENDTIME = "REQUESTENDTIME"
    '''
    :stability: experimental
    '''
    REQUESTSTARTTIMEEPOCHMILLIS = "REQUESTSTARTTIMEEPOCHMILLIS"
    '''
    :stability: experimental
    '''
    REQUESTENDTIMEEPOCHMILLIS = "REQUESTENDTIMEEPOCHMILLIS"
    '''
    :stability: experimental
    '''
    EVENTTIMESTAMP = "EVENTTIMESTAMP"
    '''
    :stability: experimental
    '''
    AWSACCOUNTID = "AWSACCOUNTID"
    '''
    :stability: experimental
    '''
    ORIGINID = "ORIGINID"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationManifestServiceLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnPlaybackConfigurationManifestServiceLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_playback_configuration_manifest_service_logs_s3_props = mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsS3Props(
                encryption_key=key_ref,
                output_format=mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3.JSON,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationManifestServiceLogsRecordFields.CUSTOMERID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9c06f8a43822bcdf697598f867f4347596e8a89282dbe3fef697bd5ee299b270)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationManifestServiceLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationManifestServiceLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnPlaybackConfigurationTranscodeLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogs",
):
    '''Builder for CfnPlaybackConfigurationLogsMixin to generate TRANSCODE_LOGS for CfnPlaybackConfiguration.

    :cloudformationResource: AWS::MediaTailor::PlaybackConfiguration
    :logType: TRANSCODE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
        
        cfn_playback_configuration_transcode_logs = mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationTranscodeLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__33e800b73a0323b27946e73a62c4a77d472eff11fca6400ab43f5de968c5678e)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnPlaybackConfigurationTranscodeLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationTranscodeLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c76eda0e1fe5ec05058a5ffa7f80b5cd93884499ec79a3de0568ba35bf8abd0)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnPlaybackConfigurationTranscodeLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationTranscodeLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f73e62a7ad686ba4f0b391bd5eeda6e94450b2047158596df2b68252a46e26f3)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnPlaybackConfigurationTranscodeLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationTranscodeLogsRecordFields"]] = None,
    ) -> "CfnPlaybackConfigurationLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b3b08d6c53187e4f8a92d92d02cf0b185d11f64b2e9a6945f6b6b58117b3ae5a)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnPlaybackConfigurationTranscodeLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnPlaybackConfigurationLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnPlaybackConfigurationTranscodeLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationTranscodeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_transcode_logs_dest_props = mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsDestProps(
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsRecordFields.EVENTTYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__955961bd579c0616421db1949974c3cf2fde1639fc790c4c2d809344f58b30b5)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationTranscodeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationTranscodeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationTranscodeLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnPlaybackConfigurationTranscodeLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationTranscodeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_transcode_logs_firehose_props = mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsFirehoseProps(
                output_format=mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose.JSON,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsRecordFields.EVENTTYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d99e8c7003770b109775404849bd8046df7409088c1838f2594ada58eba69fc)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationTranscodeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationTranscodeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationTranscodeLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnPlaybackConfigurationTranscodeLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationTranscodeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            
            cfn_playback_configuration_transcode_logs_log_group_props = mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsLogGroupProps(
                output_format=mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsRecordFields.EVENTTYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66ae723fe6002aa037c9742be0b57f48f779e570dd404b5ab88ec222994d1d51)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationTranscodeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationTranscodeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationTranscodeLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnPlaybackConfigurationTranscodeLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnPlaybackConfigurationTranscodeLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
        
        cfn_playback_configuration_transcode_logs_output_format = mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsRecordFields"
)
class CfnPlaybackConfigurationTranscodeLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    EVENTTYPE = "EVENTTYPE"
    '''
    :stability: experimental
    '''
    EVENTDESCRIPTION = "EVENTDESCRIPTION"
    '''
    :stability: experimental
    '''
    SESSIONID = "SESSIONID"
    '''
    :stability: experimental
    '''
    CREATIVEUNIQUEID = "CREATIVEUNIQUEID"
    '''
    :stability: experimental
    '''
    PROFILENAME = "PROFILENAME"
    '''
    :stability: experimental
    '''
    ADURI = "ADURI"
    '''
    :stability: experimental
    '''
    TRANSCODEREQUESTID = "TRANSCODEREQUESTID"
    '''
    :stability: experimental
    '''
    CACHESTATUS = "CACHESTATUS"
    '''
    :stability: experimental
    '''
    EVENTTIMESTAMP = "EVENTTIMESTAMP"
    '''
    :stability: experimental
    '''
    AWSACCOUNTID = "AWSACCOUNTID"
    '''
    :stability: experimental
    '''
    ORIGINID = "ORIGINID"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_mediatailor.mixins.CfnPlaybackConfigurationTranscodeLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnPlaybackConfigurationTranscodeLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnPlaybackConfigurationTranscodeLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_mediatailor import mixins as mediatailor_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_playback_configuration_transcode_logs_s3_props = mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsS3Props(
                encryption_key=key_ref,
                output_format=mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3.JSON,
                record_fields=[mediatailor_mixins.CfnPlaybackConfigurationTranscodeLogsRecordFields.EVENTTYPE]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__304eb2ca27b7df1046926f33dbbcd64e060207353890a349422de6f511acfbe5)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnPlaybackConfigurationTranscodeLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnPlaybackConfigurationTranscodeLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnPlaybackConfigurationTranscodeLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnPlaybackConfigurationAdDecisionServerLogs",
    "CfnPlaybackConfigurationAdDecisionServerLogsDestProps",
    "CfnPlaybackConfigurationAdDecisionServerLogsFirehoseProps",
    "CfnPlaybackConfigurationAdDecisionServerLogsLogGroupProps",
    "CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat",
    "CfnPlaybackConfigurationAdDecisionServerLogsRecordFields",
    "CfnPlaybackConfigurationAdDecisionServerLogsS3Props",
    "CfnPlaybackConfigurationLogsMixin",
    "CfnPlaybackConfigurationManifestServiceLogs",
    "CfnPlaybackConfigurationManifestServiceLogsDestProps",
    "CfnPlaybackConfigurationManifestServiceLogsFirehoseProps",
    "CfnPlaybackConfigurationManifestServiceLogsLogGroupProps",
    "CfnPlaybackConfigurationManifestServiceLogsOutputFormat",
    "CfnPlaybackConfigurationManifestServiceLogsRecordFields",
    "CfnPlaybackConfigurationManifestServiceLogsS3Props",
    "CfnPlaybackConfigurationTranscodeLogs",
    "CfnPlaybackConfigurationTranscodeLogsDestProps",
    "CfnPlaybackConfigurationTranscodeLogsFirehoseProps",
    "CfnPlaybackConfigurationTranscodeLogsLogGroupProps",
    "CfnPlaybackConfigurationTranscodeLogsOutputFormat",
    "CfnPlaybackConfigurationTranscodeLogsRecordFields",
    "CfnPlaybackConfigurationTranscodeLogsS3Props",
]

publication.publish()

def _typecheckingstub__0212ac1b79afa7baccdcd17e57fc9cd88266be17c8b397a23cc1272d770bb0fa(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationAdDecisionServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e86a052e20c8228bc093ef1e81663e21e26af1acdeb9ebd0590dc4ce4ef2b99(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationAdDecisionServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a630ed534e9ef49e9fa722ba2673200de7833d9ce20ae36627f37365f9fa84ec(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationAdDecisionServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08257b9b52bcc570545a1fda383c2af965d90755db227b2c6b2669a74fe72179(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationAdDecisionServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae6045c4157c0c94df68326404935e98c6954c76a5f9cdd33a4fa9b127ee30c6(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationAdDecisionServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51bcbf4341d8a6262e2323e8e30cf4988442ba834e14af562bb1cce7a6208931(
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationAdDecisionServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c7a7a7285db2c15de00e0feb42f7839930ce050ba0397a74ad33bb135553c6f(
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationAdDecisionServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5a22998b534f25c2e2d7e9bc70c39ad56e7e0827146695953efe16ff9076aae1(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnPlaybackConfigurationAdDecisionServerLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationAdDecisionServerLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8be22dc5fdbd1bf53113a722cc11a9b40329325137f457b06c1a0e52a4e0453b(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__61be5ae7c09b88d8a3fae6f642df86bbdfadab120e49d7ce23b9ac0108b8f205(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d9ece1d228b98eb43999d1e5f071cce2aa5ba0d5b8637938930f2be61005ee29(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee30b40c967c3ddede60f3474c1333716236f1366bcffe038429d4cf0ace4d55(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationManifestServiceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__779bc1620506212603cd0bf2f441fc09f9538cdd5f24bc4a18f176705af08aa9(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationManifestServiceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__885cfdc6db35b97c08c385af0249fa780966a96fe797af4141cf20392adcc5a6(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationManifestServiceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__014a4750a71f835eca7d99b8d7e79bb5c2ecbdf8e2e3a2ea3109ee4208110f6b(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationManifestServiceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f8ea7639cae831bb6e5bb627551ce7ac0291854b8379f792a4ea534e9410c550(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationManifestServiceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6c249aaf9bff4241a528ac2473dbbc2fe9619835678beae82dc7cea79bfcc22(
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationManifestServiceLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationManifestServiceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__031150aaafa345a346bc30caca4695e19cb58d04328a3bb579b5d05b5f0640d4(
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationManifestServiceLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationManifestServiceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c06f8a43822bcdf697598f867f4347596e8a89282dbe3fef697bd5ee299b270(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnPlaybackConfigurationManifestServiceLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationManifestServiceLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33e800b73a0323b27946e73a62c4a77d472eff11fca6400ab43f5de968c5678e(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationTranscodeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c76eda0e1fe5ec05058a5ffa7f80b5cd93884499ec79a3de0568ba35bf8abd0(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationTranscodeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f73e62a7ad686ba4f0b391bd5eeda6e94450b2047158596df2b68252a46e26f3(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationTranscodeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b3b08d6c53187e4f8a92d92d02cf0b185d11f64b2e9a6945f6b6b58117b3ae5a(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationTranscodeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__955961bd579c0616421db1949974c3cf2fde1639fc790c4c2d809344f58b30b5(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationTranscodeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d99e8c7003770b109775404849bd8046df7409088c1838f2594ada58eba69fc(
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationTranscodeLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationTranscodeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66ae723fe6002aa037c9742be0b57f48f779e570dd404b5ab88ec222994d1d51(
    *,
    output_format: typing.Optional[CfnPlaybackConfigurationTranscodeLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationTranscodeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__304eb2ca27b7df1046926f33dbbcd64e060207353890a349422de6f511acfbe5(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnPlaybackConfigurationTranscodeLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnPlaybackConfigurationTranscodeLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass
