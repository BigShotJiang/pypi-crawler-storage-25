from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_codecommit as _aws_cdk_interfaces_aws_codecommit_ceddda9d


class AWSAPICallViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.codecommit@AWSAPICallViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
        
        a_wSAPICall_via_cloud_trail = codecommit_events.AWSAPICallViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="awsAPICallViaCloudTrailPattern")
    @builtins.classmethod
    def aws_api_call_via_cloud_trail_pattern(
        cls,
        *,
        additional_event_data: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.AdditionalEventData", typing.Dict[builtins.str, typing.Any]]] = None,
        api_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        resources: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS API Call via CloudTrail.

        :param additional_event_data: (experimental) additionalEventData property. Specify an array of string values to match this event if the actual value of additionalEventData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param api_version: (experimental) apiVersion property. Specify an array of string values to match this event if the actual value of apiVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param read_only: (experimental) readOnly property. Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            additional_event_data=additional_event_data,
            api_version=api_version,
            aws_region=aws_region,
            error_code=error_code,
            error_message=error_message,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            read_only=read_only,
            request_id=request_id,
            request_parameters=request_parameters,
            resources=resources,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "awsAPICallViaCloudTrailPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "additional_event_data": "additionalEventData",
            "api_version": "apiVersion",
            "aws_region": "awsRegion",
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "read_only": "readOnly",
            "request_id": "requestId",
            "request_parameters": "requestParameters",
            "resources": "resources",
            "response_elements": "responseElements",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSAPICallViaCloudTrailProps:
        def __init__(
            self,
            *,
            additional_event_data: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.AdditionalEventData", typing.Dict[builtins.str, typing.Any]]] = None,
            api_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            resources: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codecommit@AWSAPICallViaCloudTrail event.

            :param additional_event_data: (experimental) additionalEventData property. Specify an array of string values to match this event if the actual value of additionalEventData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param api_version: (experimental) apiVersion property. Specify an array of string values to match this event if the actual value of apiVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param read_only: (experimental) readOnly property. Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resources: (experimental) resources property. Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                # approval_rules: Any
                
                a_wSAPICall_via_cloud_trail_props = codecommit_events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
                    additional_event_data=codecommit_events.AWSAPICallViaCloudTrail.AdditionalEventData(
                        capabilities=["capabilities"],
                        clone=["clone"],
                        data_transferred=["dataTransferred"],
                        protocol=["protocol"],
                        repository_id=["repositoryId"],
                        repository_name=["repositoryName"],
                        shallow=["shallow"]
                    ),
                    api_version=["apiVersion"],
                    aws_region=["awsRegion"],
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    read_only=["readOnly"],
                    request_id=["requestId"],
                    request_parameters=codecommit_events.AWSAPICallViaCloudTrail.RequestParameters(
                        after_commit_id=["afterCommitId"],
                        approval_rule_template_content=["approvalRuleTemplateContent"],
                        approval_rule_template_description=["approvalRuleTemplateDescription"],
                        approval_rule_template_name=["approvalRuleTemplateName"],
                        approval_state=["approvalState"],
                        archive_type=["archiveType"],
                        before_commit_id=["beforeCommitId"],
                        branch_name=["branchName"],
                        client_request_token=["clientRequestToken"],
                        comment_id=["commentId"],
                        commit_id=["commitId"],
                        commit_ids=["commitIds"],
                        commit_message=["commitMessage"],
                        conflict_detail_level=["conflictDetailLevel"],
                        conflict_resolution_strategy=["conflictResolutionStrategy"],
                        content=["content"],
                        default_branch_name=["defaultBranchName"],
                        delete_files=[codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                            file_path=["filePath"]
                        )],
                        description=["description"],
                        destination_commit_specifier=["destinationCommitSpecifier"],
                        file_mode=["fileMode"],
                        file_path=["filePath"],
                        file_paths=["filePaths"],
                        in_reply_to=["inReplyTo"],
                        keep_empty_folders=["keepEmptyFolders"],
                        location=codecommit_events.AWSAPICallViaCloudTrail.Location(
                            file_path=["filePath"],
                            file_position=["filePosition"],
                            relative_file_version=["relativeFileVersion"]
                        ),
                        max_conflict_files=["maxConflictFiles"],
                        max_merge_hunks=["maxMergeHunks"],
                        merge_option=["mergeOption"],
                        name=["name"],
                        new_name=["newName"],
                        old_name=["oldName"],
                        parent_commit_id=["parentCommitId"],
                        pull_request_id=["pullRequestId"],
                        pull_request_ids=["pullRequestIds"],
                        pull_request_status=["pullRequestStatus"],
                        put_files=[codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                            file_path=["filePath"]
                        )],
                        references=[codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                            commit=["commit"],
                            ref=["ref"]
                        )],
                        repository_description=["repositoryDescription"],
                        repository_name=["repositoryName"],
                        resource_arn=["resourceArn"],
                        revision_id=["revisionId"],
                        s3_bucket=["s3Bucket"],
                        s3_key=["s3Key"],
                        source_commit_specifier=["sourceCommitSpecifier"],
                        tag_keys=["tagKeys"],
                        tags={
                            "tags_key": "tags"
                        },
                        target_branch=["targetBranch"],
                        targets=[codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem2(
                            destination_reference=["destinationReference"],
                            repository_name=["repositoryName"],
                            source_reference=["sourceReference"]
                        )],
                        throw_if_closed=["throwIfClosed"],
                        title=["title"],
                        upload_id=["uploadId"]
                    ),
                    resources=[codecommit_events.AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem(
                        account_id=["accountId"],
                        arn=["arn"],
                        type=["type"]
                    )],
                    response_elements=codecommit_events.AWSAPICallViaCloudTrail.ResponseElements(
                        after_blob_id=["afterBlobId"],
                        after_commit_id=["afterCommitId"],
                        before_blob_id=["beforeBlobId"],
                        before_commit_id=["beforeCommitId"],
                        blob_id=["blobId"],
                        comment=codecommit_events.AWSAPICallViaCloudTrail.Comment(
                            author_arn=["authorArn"],
                            client_request_token=["clientRequestToken"],
                            comment_id=["commentId"],
                            content=["content"],
                            creation_date=["creationDate"],
                            deleted=["deleted"],
                            in_reply_to=["inReplyTo"],
                            last_modified_date=["lastModifiedDate"]
                        ),
                        commit_id=["commitId"],
                        deleted_branch=codecommit_events.AWSAPICallViaCloudTrail.DeletedBranch(
                            branch_name=["branchName"],
                            commit_id=["commitId"]
                        ),
                        file_path=["filePath"],
                        files_added=[codecommit_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                            absolute_path=["absolutePath"],
                            blob_id=["blobId"],
                            file_mode=["fileMode"]
                        )],
                        files_deleted=[codecommit_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                            absolute_path=["absolutePath"],
                            blob_id=["blobId"],
                            file_mode=["fileMode"]
                        )],
                        files_updated=[codecommit_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                            absolute_path=["absolutePath"],
                            blob_id=["blobId"],
                            file_mode=["fileMode"]
                        )],
                        location=codecommit_events.AWSAPICallViaCloudTrail.Location(
                            file_path=["filePath"],
                            file_position=["filePosition"],
                            relative_file_version=["relativeFileVersion"]
                        ),
                        pull_request=codecommit_events.AWSAPICallViaCloudTrail.PullRequest(
                            approval_rules=[approval_rules],
                            author_arn=["authorArn"],
                            client_request_token=["clientRequestToken"],
                            creation_date=["creationDate"],
                            description=["description"],
                            last_activity_date=["lastActivityDate"],
                            pull_request_id=["pullRequestId"],
                            pull_request_status=["pullRequestStatus"],
                            pull_request_targets=[codecommit_events.AWSAPICallViaCloudTrail.PullRequestItem(
                                destination_commit=["destinationCommit"],
                                destination_reference=["destinationReference"],
                                merge_base=["mergeBase"],
                                merge_metadata=codecommit_events.AWSAPICallViaCloudTrail.MergeMetadata(
                                    is_merged=["isMerged"],
                                    merge_commit_id=["mergeCommitId"],
                                    merged_by=["mergedBy"],
                                    merge_option=["mergeOption"]
                                ),
                                repository_name=["repositoryName"],
                                source_commit=["sourceCommit"],
                                source_reference=["sourceReference"]
                            )],
                            revision_id=["revisionId"],
                            title=["title"]
                        ),
                        pull_request_id=["pullRequestId"],
                        repository_id=["repositoryId"],
                        repository_metadata=codecommit_events.AWSAPICallViaCloudTrail.RepositoryMetadata(
                            account_id=["accountId"],
                            arn=["arn"],
                            clone_url_http=["cloneUrlHttp"],
                            clone_url_ssh=["cloneUrlSsh"],
                            creation_date=["creationDate"],
                            last_modified_date=["lastModifiedDate"],
                            repository_description=["repositoryDescription"],
                            repository_id=["repositoryId"],
                            repository_name=["repositoryName"]
                        ),
                        repository_name=["repositoryName"],
                        tree_id=["treeId"],
                        upload_id=["uploadId"]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=codecommit_events.AWSAPICallViaCloudTrail.UserIdentity(
                        access_key_id=["accessKeyId"],
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        session_context=codecommit_events.AWSAPICallViaCloudTrail.SessionContext(
                            attributes=codecommit_events.AWSAPICallViaCloudTrail.Attributes(
                                creation_date=["creationDate"],
                                mfa_authenticated=["mfaAuthenticated"]
                            ),
                            session_issuer=codecommit_events.AWSAPICallViaCloudTrail.SessionIssuer(
                                account_id=["accountId"],
                                arn=["arn"],
                                principal_id=["principalId"],
                                type=["type"],
                                user_name=["userName"]
                            ),
                            web_id_federation_data=["webIdFederationData"]
                        ),
                        type=["type"],
                        user_name=["userName"]
                    )
                )
            '''
            if isinstance(additional_event_data, dict):
                additional_event_data = AWSAPICallViaCloudTrail.AdditionalEventData(**additional_event_data)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(request_parameters, dict):
                request_parameters = AWSAPICallViaCloudTrail.RequestParameters(**request_parameters)
            if isinstance(response_elements, dict):
                response_elements = AWSAPICallViaCloudTrail.ResponseElements(**response_elements)
            if isinstance(user_identity, dict):
                user_identity = AWSAPICallViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f984782d4e528f36d9cb78a2ccb3e2152d4d5c0df846df436441aeeeada7e998)
                check_type(argname="argument additional_event_data", value=additional_event_data, expected_type=type_hints["additional_event_data"])
                check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument read_only", value=read_only, expected_type=type_hints["read_only"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument request_parameters", value=request_parameters, expected_type=type_hints["request_parameters"])
                check_type(argname="argument resources", value=resources, expected_type=type_hints["resources"])
                check_type(argname="argument response_elements", value=response_elements, expected_type=type_hints["response_elements"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if additional_event_data is not None:
                self._values["additional_event_data"] = additional_event_data
            if api_version is not None:
                self._values["api_version"] = api_version
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if read_only is not None:
                self._values["read_only"] = read_only
            if request_id is not None:
                self._values["request_id"] = request_id
            if request_parameters is not None:
                self._values["request_parameters"] = request_parameters
            if resources is not None:
                self._values["resources"] = resources
            if response_elements is not None:
                self._values["response_elements"] = response_elements
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def additional_event_data(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.AdditionalEventData"]:
            '''(experimental) additionalEventData property.

            Specify an array of string values to match this event if the actual value of additionalEventData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("additional_event_data")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.AdditionalEventData"], result)

        @builtins.property
        def api_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) apiVersion property.

            Specify an array of string values to match this event if the actual value of apiVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("api_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def read_only(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) readOnly property.

            Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("read_only")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestID property.

            Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"]:
            '''(experimental) requestParameters property.

            Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"], result)

        @builtins.property
        def resources(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem"]]:
            '''(experimental) resources property.

            Specify an array of string values to match this event if the actual value of resources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resources")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem"]], result)

        @builtins.property
        def response_elements(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"]:
            '''(experimental) responseElements property.

            Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response_elements")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSAPICallViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.AdditionalEventData",
        jsii_struct_bases=[],
        name_mapping={
            "capabilities": "capabilities",
            "clone": "clone",
            "data_transferred": "dataTransferred",
            "protocol": "protocol",
            "repository_id": "repositoryId",
            "repository_name": "repositoryName",
            "shallow": "shallow",
        },
    )
    class AdditionalEventData:
        def __init__(
            self,
            *,
            capabilities: typing.Optional[typing.Sequence[builtins.str]] = None,
            clone: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_transferred: typing.Optional[typing.Sequence[builtins.str]] = None,
            protocol: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            shallow: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AdditionalEventData.

            :param capabilities: (experimental) capabilities property. Specify an array of string values to match this event if the actual value of capabilities is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param clone: (experimental) clone property. Specify an array of string values to match this event if the actual value of clone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_transferred: (experimental) dataTransferred property. Specify an array of string values to match this event if the actual value of dataTransferred is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param protocol: (experimental) protocol property. Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param shallow: (experimental) shallow property. Specify an array of string values to match this event if the actual value of shallow is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                additional_event_data = codecommit_events.AWSAPICallViaCloudTrail.AdditionalEventData(
                    capabilities=["capabilities"],
                    clone=["clone"],
                    data_transferred=["dataTransferred"],
                    protocol=["protocol"],
                    repository_id=["repositoryId"],
                    repository_name=["repositoryName"],
                    shallow=["shallow"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9964a0826ec1356fccfc5e6444367b4ae9c989729650f71db1aecc94359275df)
                check_type(argname="argument capabilities", value=capabilities, expected_type=type_hints["capabilities"])
                check_type(argname="argument clone", value=clone, expected_type=type_hints["clone"])
                check_type(argname="argument data_transferred", value=data_transferred, expected_type=type_hints["data_transferred"])
                check_type(argname="argument protocol", value=protocol, expected_type=type_hints["protocol"])
                check_type(argname="argument repository_id", value=repository_id, expected_type=type_hints["repository_id"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
                check_type(argname="argument shallow", value=shallow, expected_type=type_hints["shallow"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if capabilities is not None:
                self._values["capabilities"] = capabilities
            if clone is not None:
                self._values["clone"] = clone
            if data_transferred is not None:
                self._values["data_transferred"] = data_transferred
            if protocol is not None:
                self._values["protocol"] = protocol
            if repository_id is not None:
                self._values["repository_id"] = repository_id
            if repository_name is not None:
                self._values["repository_name"] = repository_name
            if shallow is not None:
                self._values["shallow"] = shallow

        @builtins.property
        def capabilities(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) capabilities property.

            Specify an array of string values to match this event if the actual value of capabilities is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("capabilities")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def clone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clone property.

            Specify an array of string values to match this event if the actual value of clone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("clone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_transferred(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dataTransferred property.

            Specify an array of string values to match this event if the actual value of dataTransferred is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_transferred")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def protocol(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) protocol property.

            Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("protocol")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryId property.

            Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def shallow(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) shallow property.

            Specify an array of string values to match this event if the actual value of shallow is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("shallow")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AdditionalEventData(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "creation_date": "creationDate",
            "mfa_authenticated": "mfaAuthenticated",
        },
    )
    class Attributes:
        def __init__(
            self,
            *,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Attributes.

            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mfa_authenticated: (experimental) mfaAuthenticated property. Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                attributes = codecommit_events.AWSAPICallViaCloudTrail.Attributes(
                    creation_date=["creationDate"],
                    mfa_authenticated=["mfaAuthenticated"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__71f9b13a44eddbce04778aa75b9b721afe01e9ad8f710d1e5d3d0ff71d2a1a1c)
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument mfa_authenticated", value=mfa_authenticated, expected_type=type_hints["mfa_authenticated"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if mfa_authenticated is not None:
                self._values["mfa_authenticated"] = mfa_authenticated

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mfa_authenticated(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mfaAuthenticated property.

            Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mfa_authenticated")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem",
        jsii_struct_bases=[],
        name_mapping={"account_id": "accountId", "arn": "arn", "type": "type"},
    )
    class AwsapiCallViaCloudTrailItem:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AWSAPICallViaCloudTrailItem.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) ARN property. Specify an array of string values to match this event if the actual value of ARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                awsapi_call_via_cloud_trail_item = codecommit_events.AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem(
                    account_id=["accountId"],
                    arn=["arn"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__127a2eb8542e01a5b03de95bb9add9598a8737f81728d81b2c491e886087d870)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ARN property.

            Specify an array of string values to match this event if the actual value of ARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AwsapiCallViaCloudTrailItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.Comment",
        jsii_struct_bases=[],
        name_mapping={
            "author_arn": "authorArn",
            "client_request_token": "clientRequestToken",
            "comment_id": "commentId",
            "content": "content",
            "creation_date": "creationDate",
            "deleted": "deleted",
            "in_reply_to": "inReplyTo",
            "last_modified_date": "lastModifiedDate",
        },
    )
    class Comment:
        def __init__(
            self,
            *,
            author_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            client_request_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            content: typing.Optional[typing.Sequence[builtins.str]] = None,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            deleted: typing.Optional[typing.Sequence[builtins.str]] = None,
            in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Comment.

            :param author_arn: (experimental) authorArn property. Specify an array of string values to match this event if the actual value of authorArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param client_request_token: (experimental) clientRequestToken property. Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param comment_id: (experimental) commentId property. Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param content: (experimental) content property. Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param deleted: (experimental) deleted property. Specify an array of string values to match this event if the actual value of deleted is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param in_reply_to: (experimental) inReplyTo property. Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_modified_date: (experimental) lastModifiedDate property. Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                comment = codecommit_events.AWSAPICallViaCloudTrail.Comment(
                    author_arn=["authorArn"],
                    client_request_token=["clientRequestToken"],
                    comment_id=["commentId"],
                    content=["content"],
                    creation_date=["creationDate"],
                    deleted=["deleted"],
                    in_reply_to=["inReplyTo"],
                    last_modified_date=["lastModifiedDate"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9208bd5fca2f7241cc72d771eb3d25ee44293f8cd0c638dab091316b2a74767a)
                check_type(argname="argument author_arn", value=author_arn, expected_type=type_hints["author_arn"])
                check_type(argname="argument client_request_token", value=client_request_token, expected_type=type_hints["client_request_token"])
                check_type(argname="argument comment_id", value=comment_id, expected_type=type_hints["comment_id"])
                check_type(argname="argument content", value=content, expected_type=type_hints["content"])
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument deleted", value=deleted, expected_type=type_hints["deleted"])
                check_type(argname="argument in_reply_to", value=in_reply_to, expected_type=type_hints["in_reply_to"])
                check_type(argname="argument last_modified_date", value=last_modified_date, expected_type=type_hints["last_modified_date"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if author_arn is not None:
                self._values["author_arn"] = author_arn
            if client_request_token is not None:
                self._values["client_request_token"] = client_request_token
            if comment_id is not None:
                self._values["comment_id"] = comment_id
            if content is not None:
                self._values["content"] = content
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if deleted is not None:
                self._values["deleted"] = deleted
            if in_reply_to is not None:
                self._values["in_reply_to"] = in_reply_to
            if last_modified_date is not None:
                self._values["last_modified_date"] = last_modified_date

        @builtins.property
        def author_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) authorArn property.

            Specify an array of string values to match this event if the actual value of authorArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("author_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def client_request_token(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clientRequestToken property.

            Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("client_request_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def comment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commentId property.

            Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def content(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) content property.

            Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def deleted(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deleted property.

            Specify an array of string values to match this event if the actual value of deleted is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deleted")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def in_reply_to(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) inReplyTo property.

            Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("in_reply_to")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_modified_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) lastModifiedDate property.

            Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Comment(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.DeletedBranch",
        jsii_struct_bases=[],
        name_mapping={"branch_name": "branchName", "commit_id": "commitId"},
    )
    class DeletedBranch:
        def __init__(
            self,
            *,
            branch_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for DeletedBranch.

            :param branch_name: (experimental) branchName property. Specify an array of string values to match this event if the actual value of branchName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param commit_id: (experimental) commitId property. Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                deleted_branch = codecommit_events.AWSAPICallViaCloudTrail.DeletedBranch(
                    branch_name=["branchName"],
                    commit_id=["commitId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8474d8349c56e8807e369d7c2abc9c682199e1cb443b4b2bc0508e6e450e92b3)
                check_type(argname="argument branch_name", value=branch_name, expected_type=type_hints["branch_name"])
                check_type(argname="argument commit_id", value=commit_id, expected_type=type_hints["commit_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if branch_name is not None:
                self._values["branch_name"] = branch_name
            if commit_id is not None:
                self._values["commit_id"] = commit_id

        @builtins.property
        def branch_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) branchName property.

            Specify an array of string values to match this event if the actual value of branchName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("branch_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commitId property.

            Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DeletedBranch(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.Location",
        jsii_struct_bases=[],
        name_mapping={
            "file_path": "filePath",
            "file_position": "filePosition",
            "relative_file_version": "relativeFileVersion",
        },
    )
    class Location:
        def __init__(
            self,
            *,
            file_path: typing.Optional[typing.Sequence[builtins.str]] = None,
            file_position: typing.Optional[typing.Sequence[builtins.str]] = None,
            relative_file_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Location.

            :param file_path: (experimental) filePath property. Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param file_position: (experimental) filePosition property. Specify an array of string values to match this event if the actual value of filePosition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param relative_file_version: (experimental) relativeFileVersion property. Specify an array of string values to match this event if the actual value of relativeFileVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                location = codecommit_events.AWSAPICallViaCloudTrail.Location(
                    file_path=["filePath"],
                    file_position=["filePosition"],
                    relative_file_version=["relativeFileVersion"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5f32fe3be5564b5f5ef6f6912226cd7e27798d5c4ecac713853e2881a147577b)
                check_type(argname="argument file_path", value=file_path, expected_type=type_hints["file_path"])
                check_type(argname="argument file_position", value=file_position, expected_type=type_hints["file_position"])
                check_type(argname="argument relative_file_version", value=relative_file_version, expected_type=type_hints["relative_file_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if file_path is not None:
                self._values["file_path"] = file_path
            if file_position is not None:
                self._values["file_position"] = file_position
            if relative_file_version is not None:
                self._values["relative_file_version"] = relative_file_version

        @builtins.property
        def file_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) filePath property.

            Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("file_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def file_position(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) filePosition property.

            Specify an array of string values to match this event if the actual value of filePosition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("file_position")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def relative_file_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) relativeFileVersion property.

            Specify an array of string values to match this event if the actual value of relativeFileVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("relative_file_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Location(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.MergeMetadata",
        jsii_struct_bases=[],
        name_mapping={
            "is_merged": "isMerged",
            "merge_commit_id": "mergeCommitId",
            "merged_by": "mergedBy",
            "merge_option": "mergeOption",
        },
    )
    class MergeMetadata:
        def __init__(
            self,
            *,
            is_merged: typing.Optional[typing.Sequence[builtins.str]] = None,
            merge_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            merged_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for MergeMetadata.

            :param is_merged: (experimental) isMerged property. Specify an array of string values to match this event if the actual value of isMerged is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param merge_commit_id: (experimental) mergeCommitId property. Specify an array of string values to match this event if the actual value of mergeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param merged_by: (experimental) mergedBy property. Specify an array of string values to match this event if the actual value of mergedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param merge_option: (experimental) mergeOption property. Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                merge_metadata = codecommit_events.AWSAPICallViaCloudTrail.MergeMetadata(
                    is_merged=["isMerged"],
                    merge_commit_id=["mergeCommitId"],
                    merged_by=["mergedBy"],
                    merge_option=["mergeOption"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c98d2d025e52776dcb533688e09a4ef9690565c6c9be4278cc4a0ebf7c33f5d3)
                check_type(argname="argument is_merged", value=is_merged, expected_type=type_hints["is_merged"])
                check_type(argname="argument merge_commit_id", value=merge_commit_id, expected_type=type_hints["merge_commit_id"])
                check_type(argname="argument merged_by", value=merged_by, expected_type=type_hints["merged_by"])
                check_type(argname="argument merge_option", value=merge_option, expected_type=type_hints["merge_option"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if is_merged is not None:
                self._values["is_merged"] = is_merged
            if merge_commit_id is not None:
                self._values["merge_commit_id"] = merge_commit_id
            if merged_by is not None:
                self._values["merged_by"] = merged_by
            if merge_option is not None:
                self._values["merge_option"] = merge_option

        @builtins.property
        def is_merged(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) isMerged property.

            Specify an array of string values to match this event if the actual value of isMerged is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("is_merged")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def merge_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mergeCommitId property.

            Specify an array of string values to match this event if the actual value of mergeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("merge_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def merged_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mergedBy property.

            Specify an array of string values to match this event if the actual value of mergedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("merged_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def merge_option(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mergeOption property.

            Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("merge_option")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "MergeMetadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.PullRequest",
        jsii_struct_bases=[],
        name_mapping={
            "approval_rules": "approvalRules",
            "author_arn": "authorArn",
            "client_request_token": "clientRequestToken",
            "creation_date": "creationDate",
            "description": "description",
            "last_activity_date": "lastActivityDate",
            "pull_request_id": "pullRequestId",
            "pull_request_status": "pullRequestStatus",
            "pull_request_targets": "pullRequestTargets",
            "revision_id": "revisionId",
            "title": "title",
        },
    )
    class PullRequest:
        def __init__(
            self,
            *,
            approval_rules: typing.Optional[typing.Sequence[typing.Any]] = None,
            author_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            client_request_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_activity_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_targets: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.PullRequestItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            revision_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            title: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for PullRequest.

            :param approval_rules: (experimental) approvalRules property. Specify an array of string values to match this event if the actual value of approvalRules is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param author_arn: (experimental) authorArn property. Specify an array of string values to match this event if the actual value of authorArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param client_request_token: (experimental) clientRequestToken property. Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_activity_date: (experimental) lastActivityDate property. Specify an array of string values to match this event if the actual value of lastActivityDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_id: (experimental) pullRequestId property. Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_status: (experimental) pullRequestStatus property. Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_targets: (experimental) pullRequestTargets property. Specify an array of string values to match this event if the actual value of pullRequestTargets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param revision_id: (experimental) revisionId property. Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param title: (experimental) title property. Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                # approval_rules: Any
                
                pull_request = codecommit_events.AWSAPICallViaCloudTrail.PullRequest(
                    approval_rules=[approval_rules],
                    author_arn=["authorArn"],
                    client_request_token=["clientRequestToken"],
                    creation_date=["creationDate"],
                    description=["description"],
                    last_activity_date=["lastActivityDate"],
                    pull_request_id=["pullRequestId"],
                    pull_request_status=["pullRequestStatus"],
                    pull_request_targets=[codecommit_events.AWSAPICallViaCloudTrail.PullRequestItem(
                        destination_commit=["destinationCommit"],
                        destination_reference=["destinationReference"],
                        merge_base=["mergeBase"],
                        merge_metadata=codecommit_events.AWSAPICallViaCloudTrail.MergeMetadata(
                            is_merged=["isMerged"],
                            merge_commit_id=["mergeCommitId"],
                            merged_by=["mergedBy"],
                            merge_option=["mergeOption"]
                        ),
                        repository_name=["repositoryName"],
                        source_commit=["sourceCommit"],
                        source_reference=["sourceReference"]
                    )],
                    revision_id=["revisionId"],
                    title=["title"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c3191296fe39464dcecc91f94433dd896230873550018a947153f857fc2263f4)
                check_type(argname="argument approval_rules", value=approval_rules, expected_type=type_hints["approval_rules"])
                check_type(argname="argument author_arn", value=author_arn, expected_type=type_hints["author_arn"])
                check_type(argname="argument client_request_token", value=client_request_token, expected_type=type_hints["client_request_token"])
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument last_activity_date", value=last_activity_date, expected_type=type_hints["last_activity_date"])
                check_type(argname="argument pull_request_id", value=pull_request_id, expected_type=type_hints["pull_request_id"])
                check_type(argname="argument pull_request_status", value=pull_request_status, expected_type=type_hints["pull_request_status"])
                check_type(argname="argument pull_request_targets", value=pull_request_targets, expected_type=type_hints["pull_request_targets"])
                check_type(argname="argument revision_id", value=revision_id, expected_type=type_hints["revision_id"])
                check_type(argname="argument title", value=title, expected_type=type_hints["title"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if approval_rules is not None:
                self._values["approval_rules"] = approval_rules
            if author_arn is not None:
                self._values["author_arn"] = author_arn
            if client_request_token is not None:
                self._values["client_request_token"] = client_request_token
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if description is not None:
                self._values["description"] = description
            if last_activity_date is not None:
                self._values["last_activity_date"] = last_activity_date
            if pull_request_id is not None:
                self._values["pull_request_id"] = pull_request_id
            if pull_request_status is not None:
                self._values["pull_request_status"] = pull_request_status
            if pull_request_targets is not None:
                self._values["pull_request_targets"] = pull_request_targets
            if revision_id is not None:
                self._values["revision_id"] = revision_id
            if title is not None:
                self._values["title"] = title

        @builtins.property
        def approval_rules(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) approvalRules property.

            Specify an array of string values to match this event if the actual value of approvalRules is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_rules")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def author_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) authorArn property.

            Specify an array of string values to match this event if the actual value of authorArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("author_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def client_request_token(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clientRequestToken property.

            Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("client_request_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_activity_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) lastActivityDate property.

            Specify an array of string values to match this event if the actual value of lastActivityDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_activity_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestId property.

            Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestStatus property.

            Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_targets(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.PullRequestItem"]]:
            '''(experimental) pullRequestTargets property.

            Specify an array of string values to match this event if the actual value of pullRequestTargets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_targets")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.PullRequestItem"]], result)

        @builtins.property
        def revision_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) revisionId property.

            Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("revision_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def title(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) title property.

            Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("title")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PullRequest(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.PullRequestItem",
        jsii_struct_bases=[],
        name_mapping={
            "destination_commit": "destinationCommit",
            "destination_reference": "destinationReference",
            "merge_base": "mergeBase",
            "merge_metadata": "mergeMetadata",
            "repository_name": "repositoryName",
            "source_commit": "sourceCommit",
            "source_reference": "sourceReference",
        },
    )
    class PullRequestItem:
        def __init__(
            self,
            *,
            destination_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
            merge_base: typing.Optional[typing.Sequence[builtins.str]] = None,
            merge_metadata: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.MergeMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for PullRequestItem.

            :param destination_commit: (experimental) destinationCommit property. Specify an array of string values to match this event if the actual value of destinationCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination_reference: (experimental) destinationReference property. Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param merge_base: (experimental) mergeBase property. Specify an array of string values to match this event if the actual value of mergeBase is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param merge_metadata: (experimental) mergeMetadata property. Specify an array of string values to match this event if the actual value of mergeMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_commit: (experimental) sourceCommit property. Specify an array of string values to match this event if the actual value of sourceCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_reference: (experimental) sourceReference property. Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                pull_request_item = codecommit_events.AWSAPICallViaCloudTrail.PullRequestItem(
                    destination_commit=["destinationCommit"],
                    destination_reference=["destinationReference"],
                    merge_base=["mergeBase"],
                    merge_metadata=codecommit_events.AWSAPICallViaCloudTrail.MergeMetadata(
                        is_merged=["isMerged"],
                        merge_commit_id=["mergeCommitId"],
                        merged_by=["mergedBy"],
                        merge_option=["mergeOption"]
                    ),
                    repository_name=["repositoryName"],
                    source_commit=["sourceCommit"],
                    source_reference=["sourceReference"]
                )
            '''
            if isinstance(merge_metadata, dict):
                merge_metadata = AWSAPICallViaCloudTrail.MergeMetadata(**merge_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6970327454568d765ea211f9e9516923118aa21d5bf344d80927ca9f2d22ae61)
                check_type(argname="argument destination_commit", value=destination_commit, expected_type=type_hints["destination_commit"])
                check_type(argname="argument destination_reference", value=destination_reference, expected_type=type_hints["destination_reference"])
                check_type(argname="argument merge_base", value=merge_base, expected_type=type_hints["merge_base"])
                check_type(argname="argument merge_metadata", value=merge_metadata, expected_type=type_hints["merge_metadata"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
                check_type(argname="argument source_commit", value=source_commit, expected_type=type_hints["source_commit"])
                check_type(argname="argument source_reference", value=source_reference, expected_type=type_hints["source_reference"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if destination_commit is not None:
                self._values["destination_commit"] = destination_commit
            if destination_reference is not None:
                self._values["destination_reference"] = destination_reference
            if merge_base is not None:
                self._values["merge_base"] = merge_base
            if merge_metadata is not None:
                self._values["merge_metadata"] = merge_metadata
            if repository_name is not None:
                self._values["repository_name"] = repository_name
            if source_commit is not None:
                self._values["source_commit"] = source_commit
            if source_reference is not None:
                self._values["source_reference"] = source_reference

        @builtins.property
        def destination_commit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) destinationCommit property.

            Specify an array of string values to match this event if the actual value of destinationCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination_commit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination_reference(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) destinationReference property.

            Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination_reference")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def merge_base(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mergeBase property.

            Specify an array of string values to match this event if the actual value of mergeBase is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("merge_base")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def merge_metadata(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.MergeMetadata"]:
            '''(experimental) mergeMetadata property.

            Specify an array of string values to match this event if the actual value of mergeMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("merge_metadata")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.MergeMetadata"], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_commit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceCommit property.

            Specify an array of string values to match this event if the actual value of sourceCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_commit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_reference(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceReference property.

            Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_reference")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PullRequestItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.RepositoryMetadata",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "arn": "arn",
            "clone_url_http": "cloneUrlHttp",
            "clone_url_ssh": "cloneUrlSsh",
            "creation_date": "creationDate",
            "last_modified_date": "lastModifiedDate",
            "repository_description": "repositoryDescription",
            "repository_id": "repositoryId",
            "repository_name": "repositoryName",
        },
    )
    class RepositoryMetadata:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            clone_url_http: typing.Optional[typing.Sequence[builtins.str]] = None,
            clone_url_ssh: typing.Optional[typing.Sequence[builtins.str]] = None,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RepositoryMetadata.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param clone_url_http: (experimental) cloneUrlHttp property. Specify an array of string values to match this event if the actual value of cloneUrlHttp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param clone_url_ssh: (experimental) cloneUrlSsh property. Specify an array of string values to match this event if the actual value of cloneUrlSsh is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_modified_date: (experimental) lastModifiedDate property. Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_description: (experimental) repositoryDescription property. Specify an array of string values to match this event if the actual value of repositoryDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                repository_metadata = codecommit_events.AWSAPICallViaCloudTrail.RepositoryMetadata(
                    account_id=["accountId"],
                    arn=["arn"],
                    clone_url_http=["cloneUrlHttp"],
                    clone_url_ssh=["cloneUrlSsh"],
                    creation_date=["creationDate"],
                    last_modified_date=["lastModifiedDate"],
                    repository_description=["repositoryDescription"],
                    repository_id=["repositoryId"],
                    repository_name=["repositoryName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__89e03bde2b3b44f062515c74412268f847f58d87f71974cc0a95e41ee918e8b8)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument clone_url_http", value=clone_url_http, expected_type=type_hints["clone_url_http"])
                check_type(argname="argument clone_url_ssh", value=clone_url_ssh, expected_type=type_hints["clone_url_ssh"])
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument last_modified_date", value=last_modified_date, expected_type=type_hints["last_modified_date"])
                check_type(argname="argument repository_description", value=repository_description, expected_type=type_hints["repository_description"])
                check_type(argname="argument repository_id", value=repository_id, expected_type=type_hints["repository_id"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if clone_url_http is not None:
                self._values["clone_url_http"] = clone_url_http
            if clone_url_ssh is not None:
                self._values["clone_url_ssh"] = clone_url_ssh
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if last_modified_date is not None:
                self._values["last_modified_date"] = last_modified_date
            if repository_description is not None:
                self._values["repository_description"] = repository_description
            if repository_id is not None:
                self._values["repository_id"] = repository_id
            if repository_name is not None:
                self._values["repository_name"] = repository_name

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def clone_url_http(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) cloneUrlHttp property.

            Specify an array of string values to match this event if the actual value of cloneUrlHttp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("clone_url_http")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def clone_url_ssh(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) cloneUrlSsh property.

            Specify an array of string values to match this event if the actual value of cloneUrlSsh is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("clone_url_ssh")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_modified_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) lastModifiedDate property.

            Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryDescription property.

            Specify an array of string values to match this event if the actual value of repositoryDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryId property.

            Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RepositoryMetadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.RequestParameters",
        jsii_struct_bases=[],
        name_mapping={
            "after_commit_id": "afterCommitId",
            "approval_rule_template_content": "approvalRuleTemplateContent",
            "approval_rule_template_description": "approvalRuleTemplateDescription",
            "approval_rule_template_name": "approvalRuleTemplateName",
            "approval_state": "approvalState",
            "archive_type": "archiveType",
            "before_commit_id": "beforeCommitId",
            "branch_name": "branchName",
            "client_request_token": "clientRequestToken",
            "comment_id": "commentId",
            "commit_id": "commitId",
            "commit_ids": "commitIds",
            "commit_message": "commitMessage",
            "conflict_detail_level": "conflictDetailLevel",
            "conflict_resolution_strategy": "conflictResolutionStrategy",
            "content": "content",
            "default_branch_name": "defaultBranchName",
            "delete_files": "deleteFiles",
            "description": "description",
            "destination_commit_specifier": "destinationCommitSpecifier",
            "file_mode": "fileMode",
            "file_path": "filePath",
            "file_paths": "filePaths",
            "in_reply_to": "inReplyTo",
            "keep_empty_folders": "keepEmptyFolders",
            "location": "location",
            "max_conflict_files": "maxConflictFiles",
            "max_merge_hunks": "maxMergeHunks",
            "merge_option": "mergeOption",
            "name": "name",
            "new_name": "newName",
            "old_name": "oldName",
            "parent_commit_id": "parentCommitId",
            "pull_request_id": "pullRequestId",
            "pull_request_ids": "pullRequestIds",
            "pull_request_status": "pullRequestStatus",
            "put_files": "putFiles",
            "references": "references",
            "repository_description": "repositoryDescription",
            "repository_name": "repositoryName",
            "resource_arn": "resourceArn",
            "revision_id": "revisionId",
            "s3_bucket": "s3Bucket",
            "s3_key": "s3Key",
            "source_commit_specifier": "sourceCommitSpecifier",
            "tag_keys": "tagKeys",
            "tags": "tags",
            "target_branch": "targetBranch",
            "targets": "targets",
            "throw_if_closed": "throwIfClosed",
            "title": "title",
            "upload_id": "uploadId",
        },
    )
    class RequestParameters:
        def __init__(
            self,
            *,
            after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            approval_rule_template_content: typing.Optional[typing.Sequence[builtins.str]] = None,
            approval_rule_template_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            approval_rule_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            approval_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            archive_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            branch_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            client_request_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            commit_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
            commit_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            conflict_detail_level: typing.Optional[typing.Sequence[builtins.str]] = None,
            conflict_resolution_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
            content: typing.Optional[typing.Sequence[builtins.str]] = None,
            default_branch_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            delete_files: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination_commit_specifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            file_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
            file_path: typing.Optional[typing.Sequence[builtins.str]] = None,
            file_paths: typing.Optional[typing.Sequence[builtins.str]] = None,
            in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
            keep_empty_folders: typing.Optional[typing.Sequence[builtins.str]] = None,
            location: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Location", typing.Dict[builtins.str, typing.Any]]] = None,
            max_conflict_files: typing.Optional[typing.Sequence[builtins.str]] = None,
            max_merge_hunks: typing.Optional[typing.Sequence[builtins.str]] = None,
            merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            new_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            old_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            parent_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            put_files: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            references: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem1", typing.Dict[builtins.str, typing.Any]]]] = None,
            repository_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            revision_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_commit_specifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            tag_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
            target_branch: typing.Optional[typing.Sequence[builtins.str]] = None,
            targets: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem2", typing.Dict[builtins.str, typing.Any]]]] = None,
            throw_if_closed: typing.Optional[typing.Sequence[builtins.str]] = None,
            title: typing.Optional[typing.Sequence[builtins.str]] = None,
            upload_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParameters.

            :param after_commit_id: (experimental) afterCommitId property. Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param approval_rule_template_content: (experimental) approvalRuleTemplateContent property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateContent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param approval_rule_template_description: (experimental) approvalRuleTemplateDescription property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param approval_rule_template_name: (experimental) approvalRuleTemplateName property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param approval_state: (experimental) approvalState property. Specify an array of string values to match this event if the actual value of approvalState is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param archive_type: (experimental) archiveType property. Specify an array of string values to match this event if the actual value of archiveType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param before_commit_id: (experimental) beforeCommitId property. Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param branch_name: (experimental) branchName property. Specify an array of string values to match this event if the actual value of branchName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param client_request_token: (experimental) clientRequestToken property. Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param comment_id: (experimental) commentId property. Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param commit_id: (experimental) commitId property. Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param commit_ids: (experimental) commitIds property. Specify an array of string values to match this event if the actual value of commitIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param commit_message: (experimental) commitMessage property. Specify an array of string values to match this event if the actual value of commitMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param conflict_detail_level: (experimental) conflictDetailLevel property. Specify an array of string values to match this event if the actual value of conflictDetailLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param conflict_resolution_strategy: (experimental) conflictResolutionStrategy property. Specify an array of string values to match this event if the actual value of conflictResolutionStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param content: (experimental) content property. Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param default_branch_name: (experimental) defaultBranchName property. Specify an array of string values to match this event if the actual value of defaultBranchName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param delete_files: (experimental) deleteFiles property. Specify an array of string values to match this event if the actual value of deleteFiles is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination_commit_specifier: (experimental) destinationCommitSpecifier property. Specify an array of string values to match this event if the actual value of destinationCommitSpecifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param file_mode: (experimental) fileMode property. Specify an array of string values to match this event if the actual value of fileMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param file_path: (experimental) filePath property. Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param file_paths: (experimental) filePaths property. Specify an array of string values to match this event if the actual value of filePaths is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param in_reply_to: (experimental) inReplyTo property. Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param keep_empty_folders: (experimental) keepEmptyFolders property. Specify an array of string values to match this event if the actual value of keepEmptyFolders is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_conflict_files: (experimental) maxConflictFiles property. Specify an array of string values to match this event if the actual value of maxConflictFiles is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_merge_hunks: (experimental) maxMergeHunks property. Specify an array of string values to match this event if the actual value of maxMergeHunks is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param merge_option: (experimental) mergeOption property. Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param new_name: (experimental) newName property. Specify an array of string values to match this event if the actual value of newName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param old_name: (experimental) oldName property. Specify an array of string values to match this event if the actual value of oldName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param parent_commit_id: (experimental) parentCommitId property. Specify an array of string values to match this event if the actual value of parentCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_id: (experimental) pullRequestId property. Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_ids: (experimental) pullRequestIds property. Specify an array of string values to match this event if the actual value of pullRequestIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_status: (experimental) pullRequestStatus property. Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param put_files: (experimental) putFiles property. Specify an array of string values to match this event if the actual value of putFiles is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param references: (experimental) references property. Specify an array of string values to match this event if the actual value of references is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_description: (experimental) repositoryDescription property. Specify an array of string values to match this event if the actual value of repositoryDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_arn: (experimental) resourceArn property. Specify an array of string values to match this event if the actual value of resourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param revision_id: (experimental) revisionId property. Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_bucket: (experimental) s3Bucket property. Specify an array of string values to match this event if the actual value of s3Bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_key: (experimental) s3Key property. Specify an array of string values to match this event if the actual value of s3Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_commit_specifier: (experimental) sourceCommitSpecifier property. Specify an array of string values to match this event if the actual value of sourceCommitSpecifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tag_keys: (experimental) tagKeys property. Specify an array of string values to match this event if the actual value of tagKeys is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_branch: (experimental) targetBranch property. Specify an array of string values to match this event if the actual value of targetBranch is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param targets: (experimental) targets property. Specify an array of string values to match this event if the actual value of targets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param throw_if_closed: (experimental) throwIfClosed property. Specify an array of string values to match this event if the actual value of throwIfClosed is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param title: (experimental) title property. Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param upload_id: (experimental) uploadId property. Specify an array of string values to match this event if the actual value of uploadId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                request_parameters = codecommit_events.AWSAPICallViaCloudTrail.RequestParameters(
                    after_commit_id=["afterCommitId"],
                    approval_rule_template_content=["approvalRuleTemplateContent"],
                    approval_rule_template_description=["approvalRuleTemplateDescription"],
                    approval_rule_template_name=["approvalRuleTemplateName"],
                    approval_state=["approvalState"],
                    archive_type=["archiveType"],
                    before_commit_id=["beforeCommitId"],
                    branch_name=["branchName"],
                    client_request_token=["clientRequestToken"],
                    comment_id=["commentId"],
                    commit_id=["commitId"],
                    commit_ids=["commitIds"],
                    commit_message=["commitMessage"],
                    conflict_detail_level=["conflictDetailLevel"],
                    conflict_resolution_strategy=["conflictResolutionStrategy"],
                    content=["content"],
                    default_branch_name=["defaultBranchName"],
                    delete_files=[codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                        file_path=["filePath"]
                    )],
                    description=["description"],
                    destination_commit_specifier=["destinationCommitSpecifier"],
                    file_mode=["fileMode"],
                    file_path=["filePath"],
                    file_paths=["filePaths"],
                    in_reply_to=["inReplyTo"],
                    keep_empty_folders=["keepEmptyFolders"],
                    location=codecommit_events.AWSAPICallViaCloudTrail.Location(
                        file_path=["filePath"],
                        file_position=["filePosition"],
                        relative_file_version=["relativeFileVersion"]
                    ),
                    max_conflict_files=["maxConflictFiles"],
                    max_merge_hunks=["maxMergeHunks"],
                    merge_option=["mergeOption"],
                    name=["name"],
                    new_name=["newName"],
                    old_name=["oldName"],
                    parent_commit_id=["parentCommitId"],
                    pull_request_id=["pullRequestId"],
                    pull_request_ids=["pullRequestIds"],
                    pull_request_status=["pullRequestStatus"],
                    put_files=[codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                        file_path=["filePath"]
                    )],
                    references=[codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                        commit=["commit"],
                        ref=["ref"]
                    )],
                    repository_description=["repositoryDescription"],
                    repository_name=["repositoryName"],
                    resource_arn=["resourceArn"],
                    revision_id=["revisionId"],
                    s3_bucket=["s3Bucket"],
                    s3_key=["s3Key"],
                    source_commit_specifier=["sourceCommitSpecifier"],
                    tag_keys=["tagKeys"],
                    tags={
                        "tags_key": "tags"
                    },
                    target_branch=["targetBranch"],
                    targets=[codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem2(
                        destination_reference=["destinationReference"],
                        repository_name=["repositoryName"],
                        source_reference=["sourceReference"]
                    )],
                    throw_if_closed=["throwIfClosed"],
                    title=["title"],
                    upload_id=["uploadId"]
                )
            '''
            if isinstance(location, dict):
                location = AWSAPICallViaCloudTrail.Location(**location)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b2314af512fad0db151764f3c8bb72a40766833d0d52a4a01222aa57dae7c063)
                check_type(argname="argument after_commit_id", value=after_commit_id, expected_type=type_hints["after_commit_id"])
                check_type(argname="argument approval_rule_template_content", value=approval_rule_template_content, expected_type=type_hints["approval_rule_template_content"])
                check_type(argname="argument approval_rule_template_description", value=approval_rule_template_description, expected_type=type_hints["approval_rule_template_description"])
                check_type(argname="argument approval_rule_template_name", value=approval_rule_template_name, expected_type=type_hints["approval_rule_template_name"])
                check_type(argname="argument approval_state", value=approval_state, expected_type=type_hints["approval_state"])
                check_type(argname="argument archive_type", value=archive_type, expected_type=type_hints["archive_type"])
                check_type(argname="argument before_commit_id", value=before_commit_id, expected_type=type_hints["before_commit_id"])
                check_type(argname="argument branch_name", value=branch_name, expected_type=type_hints["branch_name"])
                check_type(argname="argument client_request_token", value=client_request_token, expected_type=type_hints["client_request_token"])
                check_type(argname="argument comment_id", value=comment_id, expected_type=type_hints["comment_id"])
                check_type(argname="argument commit_id", value=commit_id, expected_type=type_hints["commit_id"])
                check_type(argname="argument commit_ids", value=commit_ids, expected_type=type_hints["commit_ids"])
                check_type(argname="argument commit_message", value=commit_message, expected_type=type_hints["commit_message"])
                check_type(argname="argument conflict_detail_level", value=conflict_detail_level, expected_type=type_hints["conflict_detail_level"])
                check_type(argname="argument conflict_resolution_strategy", value=conflict_resolution_strategy, expected_type=type_hints["conflict_resolution_strategy"])
                check_type(argname="argument content", value=content, expected_type=type_hints["content"])
                check_type(argname="argument default_branch_name", value=default_branch_name, expected_type=type_hints["default_branch_name"])
                check_type(argname="argument delete_files", value=delete_files, expected_type=type_hints["delete_files"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument destination_commit_specifier", value=destination_commit_specifier, expected_type=type_hints["destination_commit_specifier"])
                check_type(argname="argument file_mode", value=file_mode, expected_type=type_hints["file_mode"])
                check_type(argname="argument file_path", value=file_path, expected_type=type_hints["file_path"])
                check_type(argname="argument file_paths", value=file_paths, expected_type=type_hints["file_paths"])
                check_type(argname="argument in_reply_to", value=in_reply_to, expected_type=type_hints["in_reply_to"])
                check_type(argname="argument keep_empty_folders", value=keep_empty_folders, expected_type=type_hints["keep_empty_folders"])
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument max_conflict_files", value=max_conflict_files, expected_type=type_hints["max_conflict_files"])
                check_type(argname="argument max_merge_hunks", value=max_merge_hunks, expected_type=type_hints["max_merge_hunks"])
                check_type(argname="argument merge_option", value=merge_option, expected_type=type_hints["merge_option"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument new_name", value=new_name, expected_type=type_hints["new_name"])
                check_type(argname="argument old_name", value=old_name, expected_type=type_hints["old_name"])
                check_type(argname="argument parent_commit_id", value=parent_commit_id, expected_type=type_hints["parent_commit_id"])
                check_type(argname="argument pull_request_id", value=pull_request_id, expected_type=type_hints["pull_request_id"])
                check_type(argname="argument pull_request_ids", value=pull_request_ids, expected_type=type_hints["pull_request_ids"])
                check_type(argname="argument pull_request_status", value=pull_request_status, expected_type=type_hints["pull_request_status"])
                check_type(argname="argument put_files", value=put_files, expected_type=type_hints["put_files"])
                check_type(argname="argument references", value=references, expected_type=type_hints["references"])
                check_type(argname="argument repository_description", value=repository_description, expected_type=type_hints["repository_description"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
                check_type(argname="argument resource_arn", value=resource_arn, expected_type=type_hints["resource_arn"])
                check_type(argname="argument revision_id", value=revision_id, expected_type=type_hints["revision_id"])
                check_type(argname="argument s3_bucket", value=s3_bucket, expected_type=type_hints["s3_bucket"])
                check_type(argname="argument s3_key", value=s3_key, expected_type=type_hints["s3_key"])
                check_type(argname="argument source_commit_specifier", value=source_commit_specifier, expected_type=type_hints["source_commit_specifier"])
                check_type(argname="argument tag_keys", value=tag_keys, expected_type=type_hints["tag_keys"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
                check_type(argname="argument target_branch", value=target_branch, expected_type=type_hints["target_branch"])
                check_type(argname="argument targets", value=targets, expected_type=type_hints["targets"])
                check_type(argname="argument throw_if_closed", value=throw_if_closed, expected_type=type_hints["throw_if_closed"])
                check_type(argname="argument title", value=title, expected_type=type_hints["title"])
                check_type(argname="argument upload_id", value=upload_id, expected_type=type_hints["upload_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if after_commit_id is not None:
                self._values["after_commit_id"] = after_commit_id
            if approval_rule_template_content is not None:
                self._values["approval_rule_template_content"] = approval_rule_template_content
            if approval_rule_template_description is not None:
                self._values["approval_rule_template_description"] = approval_rule_template_description
            if approval_rule_template_name is not None:
                self._values["approval_rule_template_name"] = approval_rule_template_name
            if approval_state is not None:
                self._values["approval_state"] = approval_state
            if archive_type is not None:
                self._values["archive_type"] = archive_type
            if before_commit_id is not None:
                self._values["before_commit_id"] = before_commit_id
            if branch_name is not None:
                self._values["branch_name"] = branch_name
            if client_request_token is not None:
                self._values["client_request_token"] = client_request_token
            if comment_id is not None:
                self._values["comment_id"] = comment_id
            if commit_id is not None:
                self._values["commit_id"] = commit_id
            if commit_ids is not None:
                self._values["commit_ids"] = commit_ids
            if commit_message is not None:
                self._values["commit_message"] = commit_message
            if conflict_detail_level is not None:
                self._values["conflict_detail_level"] = conflict_detail_level
            if conflict_resolution_strategy is not None:
                self._values["conflict_resolution_strategy"] = conflict_resolution_strategy
            if content is not None:
                self._values["content"] = content
            if default_branch_name is not None:
                self._values["default_branch_name"] = default_branch_name
            if delete_files is not None:
                self._values["delete_files"] = delete_files
            if description is not None:
                self._values["description"] = description
            if destination_commit_specifier is not None:
                self._values["destination_commit_specifier"] = destination_commit_specifier
            if file_mode is not None:
                self._values["file_mode"] = file_mode
            if file_path is not None:
                self._values["file_path"] = file_path
            if file_paths is not None:
                self._values["file_paths"] = file_paths
            if in_reply_to is not None:
                self._values["in_reply_to"] = in_reply_to
            if keep_empty_folders is not None:
                self._values["keep_empty_folders"] = keep_empty_folders
            if location is not None:
                self._values["location"] = location
            if max_conflict_files is not None:
                self._values["max_conflict_files"] = max_conflict_files
            if max_merge_hunks is not None:
                self._values["max_merge_hunks"] = max_merge_hunks
            if merge_option is not None:
                self._values["merge_option"] = merge_option
            if name is not None:
                self._values["name"] = name
            if new_name is not None:
                self._values["new_name"] = new_name
            if old_name is not None:
                self._values["old_name"] = old_name
            if parent_commit_id is not None:
                self._values["parent_commit_id"] = parent_commit_id
            if pull_request_id is not None:
                self._values["pull_request_id"] = pull_request_id
            if pull_request_ids is not None:
                self._values["pull_request_ids"] = pull_request_ids
            if pull_request_status is not None:
                self._values["pull_request_status"] = pull_request_status
            if put_files is not None:
                self._values["put_files"] = put_files
            if references is not None:
                self._values["references"] = references
            if repository_description is not None:
                self._values["repository_description"] = repository_description
            if repository_name is not None:
                self._values["repository_name"] = repository_name
            if resource_arn is not None:
                self._values["resource_arn"] = resource_arn
            if revision_id is not None:
                self._values["revision_id"] = revision_id
            if s3_bucket is not None:
                self._values["s3_bucket"] = s3_bucket
            if s3_key is not None:
                self._values["s3_key"] = s3_key
            if source_commit_specifier is not None:
                self._values["source_commit_specifier"] = source_commit_specifier
            if tag_keys is not None:
                self._values["tag_keys"] = tag_keys
            if tags is not None:
                self._values["tags"] = tags
            if target_branch is not None:
                self._values["target_branch"] = target_branch
            if targets is not None:
                self._values["targets"] = targets
            if throw_if_closed is not None:
                self._values["throw_if_closed"] = throw_if_closed
            if title is not None:
                self._values["title"] = title
            if upload_id is not None:
                self._values["upload_id"] = upload_id

        @builtins.property
        def after_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) afterCommitId property.

            Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("after_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def approval_rule_template_content(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) approvalRuleTemplateContent property.

            Specify an array of string values to match this event if the actual value of approvalRuleTemplateContent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_rule_template_content")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def approval_rule_template_description(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) approvalRuleTemplateDescription property.

            Specify an array of string values to match this event if the actual value of approvalRuleTemplateDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_rule_template_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def approval_rule_template_name(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) approvalRuleTemplateName property.

            Specify an array of string values to match this event if the actual value of approvalRuleTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_rule_template_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def approval_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) approvalState property.

            Specify an array of string values to match this event if the actual value of approvalState is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def archive_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) archiveType property.

            Specify an array of string values to match this event if the actual value of archiveType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("archive_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def before_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) beforeCommitId property.

            Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("before_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def branch_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) branchName property.

            Specify an array of string values to match this event if the actual value of branchName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("branch_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def client_request_token(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clientRequestToken property.

            Specify an array of string values to match this event if the actual value of clientRequestToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("client_request_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def comment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commentId property.

            Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commitId property.

            Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def commit_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commitIds property.

            Specify an array of string values to match this event if the actual value of commitIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("commit_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def commit_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commitMessage property.

            Specify an array of string values to match this event if the actual value of commitMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("commit_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def conflict_detail_level(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) conflictDetailLevel property.

            Specify an array of string values to match this event if the actual value of conflictDetailLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("conflict_detail_level")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def conflict_resolution_strategy(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) conflictResolutionStrategy property.

            Specify an array of string values to match this event if the actual value of conflictResolutionStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("conflict_resolution_strategy")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def content(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) content property.

            Specify an array of string values to match this event if the actual value of content is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def default_branch_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) defaultBranchName property.

            Specify an array of string values to match this event if the actual value of defaultBranchName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("default_branch_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def delete_files(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]]:
            '''(experimental) deleteFiles property.

            Specify an array of string values to match this event if the actual value of deleteFiles is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("delete_files")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination_commit_specifier(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) destinationCommitSpecifier property.

            Specify an array of string values to match this event if the actual value of destinationCommitSpecifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination_commit_specifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def file_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fileMode property.

            Specify an array of string values to match this event if the actual value of fileMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("file_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def file_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) filePath property.

            Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("file_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def file_paths(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) filePaths property.

            Specify an array of string values to match this event if the actual value of filePaths is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("file_paths")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def in_reply_to(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) inReplyTo property.

            Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("in_reply_to")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def keep_empty_folders(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) keepEmptyFolders property.

            Specify an array of string values to match this event if the actual value of keepEmptyFolders is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("keep_empty_folders")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def location(self) -> typing.Optional["AWSAPICallViaCloudTrail.Location"]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Location"], result)

        @builtins.property
        def max_conflict_files(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) maxConflictFiles property.

            Specify an array of string values to match this event if the actual value of maxConflictFiles is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_conflict_files")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def max_merge_hunks(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) maxMergeHunks property.

            Specify an array of string values to match this event if the actual value of maxMergeHunks is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_merge_hunks")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def merge_option(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mergeOption property.

            Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("merge_option")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def new_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) newName property.

            Specify an array of string values to match this event if the actual value of newName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("new_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def old_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) oldName property.

            Specify an array of string values to match this event if the actual value of oldName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("old_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def parent_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) parentCommitId property.

            Specify an array of string values to match this event if the actual value of parentCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("parent_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestId property.

            Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestIds property.

            Specify an array of string values to match this event if the actual value of pullRequestIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestStatus property.

            Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def put_files(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]]:
            '''(experimental) putFiles property.

            Specify an array of string values to match this event if the actual value of putFiles is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("put_files")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]], result)

        @builtins.property
        def references(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem1"]]:
            '''(experimental) references property.

            Specify an array of string values to match this event if the actual value of references is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("references")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem1"]], result)

        @builtins.property
        def repository_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryDescription property.

            Specify an array of string values to match this event if the actual value of repositoryDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resourceArn property.

            Specify an array of string values to match this event if the actual value of resourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def revision_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) revisionId property.

            Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("revision_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Bucket property.

            Specify an array of string values to match this event if the actual value of s3Bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Key property.

            Specify an array of string values to match this event if the actual value of s3Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_commit_specifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceCommitSpecifier property.

            Specify an array of string values to match this event if the actual value of sourceCommitSpecifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_commit_specifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tag_keys(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) tagKeys property.

            Specify an array of string values to match this event if the actual value of tagKeys is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tag_keys")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        @builtins.property
        def target_branch(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) targetBranch property.

            Specify an array of string values to match this event if the actual value of targetBranch is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_branch")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def targets(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem2"]]:
            '''(experimental) targets property.

            Specify an array of string values to match this event if the actual value of targets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("targets")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem2"]], result)

        @builtins.property
        def throw_if_closed(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) throwIfClosed property.

            Specify an array of string values to match this event if the actual value of throwIfClosed is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("throw_if_closed")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def title(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) title property.

            Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("title")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def upload_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) uploadId property.

            Specify an array of string values to match this event if the actual value of uploadId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("upload_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.RequestParametersItem",
        jsii_struct_bases=[],
        name_mapping={"file_path": "filePath"},
    )
    class RequestParametersItem:
        def __init__(
            self,
            *,
            file_path: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem.

            :param file_path: (experimental) filePath property. Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                request_parameters_item = codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                    file_path=["filePath"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1a13e76a5541ad88bdc180dee0c556d541f5d5c7ad6b5ffbb8ae33ff5f4b8f9f)
                check_type(argname="argument file_path", value=file_path, expected_type=type_hints["file_path"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if file_path is not None:
                self._values["file_path"] = file_path

        @builtins.property
        def file_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) filePath property.

            Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("file_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.RequestParametersItem1",
        jsii_struct_bases=[],
        name_mapping={"commit": "commit", "ref": "ref"},
    )
    class RequestParametersItem1:
        def __init__(
            self,
            *,
            commit: typing.Optional[typing.Sequence[builtins.str]] = None,
            ref: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem_1.

            :param commit: (experimental) commit property. Specify an array of string values to match this event if the actual value of commit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ref: (experimental) ref property. Specify an array of string values to match this event if the actual value of ref is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                request_parameters_item1 = codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                    commit=["commit"],
                    ref=["ref"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c4f90bf3683895791d63886f2b90a3e4e8acf4b5b899c25c04b1b0e3e4b6849b)
                check_type(argname="argument commit", value=commit, expected_type=type_hints["commit"])
                check_type(argname="argument ref", value=ref, expected_type=type_hints["ref"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if commit is not None:
                self._values["commit"] = commit
            if ref is not None:
                self._values["ref"] = ref

        @builtins.property
        def commit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commit property.

            Specify an array of string values to match this event if the actual value of commit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("commit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ref(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ref property.

            Specify an array of string values to match this event if the actual value of ref is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ref")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.RequestParametersItem2",
        jsii_struct_bases=[],
        name_mapping={
            "destination_reference": "destinationReference",
            "repository_name": "repositoryName",
            "source_reference": "sourceReference",
        },
    )
    class RequestParametersItem2:
        def __init__(
            self,
            *,
            destination_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem_2.

            :param destination_reference: (experimental) destinationReference property. Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_reference: (experimental) sourceReference property. Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                request_parameters_item2 = codecommit_events.AWSAPICallViaCloudTrail.RequestParametersItem2(
                    destination_reference=["destinationReference"],
                    repository_name=["repositoryName"],
                    source_reference=["sourceReference"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6fc96e99922494b0f536d5f6fbe4e2814856395dceb18780b8bb20d46b7fafc3)
                check_type(argname="argument destination_reference", value=destination_reference, expected_type=type_hints["destination_reference"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
                check_type(argname="argument source_reference", value=source_reference, expected_type=type_hints["source_reference"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if destination_reference is not None:
                self._values["destination_reference"] = destination_reference
            if repository_name is not None:
                self._values["repository_name"] = repository_name
            if source_reference is not None:
                self._values["source_reference"] = source_reference

        @builtins.property
        def destination_reference(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) destinationReference property.

            Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination_reference")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_reference(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceReference property.

            Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_reference")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem2(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.ResponseElements",
        jsii_struct_bases=[],
        name_mapping={
            "after_blob_id": "afterBlobId",
            "after_commit_id": "afterCommitId",
            "before_blob_id": "beforeBlobId",
            "before_commit_id": "beforeCommitId",
            "blob_id": "blobId",
            "comment": "comment",
            "commit_id": "commitId",
            "deleted_branch": "deletedBranch",
            "file_path": "filePath",
            "files_added": "filesAdded",
            "files_deleted": "filesDeleted",
            "files_updated": "filesUpdated",
            "location": "location",
            "pull_request": "pullRequest",
            "pull_request_id": "pullRequestId",
            "repository_id": "repositoryId",
            "repository_metadata": "repositoryMetadata",
            "repository_name": "repositoryName",
            "tree_id": "treeId",
            "upload_id": "uploadId",
        },
    )
    class ResponseElements:
        def __init__(
            self,
            *,
            after_blob_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            before_blob_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            blob_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            comment: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Comment", typing.Dict[builtins.str, typing.Any]]] = None,
            commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            deleted_branch: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.DeletedBranch", typing.Dict[builtins.str, typing.Any]]] = None,
            file_path: typing.Optional[typing.Sequence[builtins.str]] = None,
            files_added: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.ResponseElementsItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            files_deleted: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.ResponseElementsItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            files_updated: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.ResponseElementsItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            location: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Location", typing.Dict[builtins.str, typing.Any]]] = None,
            pull_request: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.PullRequest", typing.Dict[builtins.str, typing.Any]]] = None,
            pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_metadata: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RepositoryMetadata", typing.Dict[builtins.str, typing.Any]]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            tree_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            upload_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElements.

            :param after_blob_id: (experimental) afterBlobId property. Specify an array of string values to match this event if the actual value of afterBlobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param after_commit_id: (experimental) afterCommitId property. Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param before_blob_id: (experimental) beforeBlobId property. Specify an array of string values to match this event if the actual value of beforeBlobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param before_commit_id: (experimental) beforeCommitId property. Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param blob_id: (experimental) blobId property. Specify an array of string values to match this event if the actual value of blobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param comment: (experimental) comment property. Specify an array of string values to match this event if the actual value of comment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param commit_id: (experimental) commitId property. Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param deleted_branch: (experimental) deletedBranch property. Specify an array of string values to match this event if the actual value of deletedBranch is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param file_path: (experimental) filePath property. Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param files_added: (experimental) filesAdded property. Specify an array of string values to match this event if the actual value of filesAdded is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param files_deleted: (experimental) filesDeleted property. Specify an array of string values to match this event if the actual value of filesDeleted is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param files_updated: (experimental) filesUpdated property. Specify an array of string values to match this event if the actual value of filesUpdated is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request: (experimental) pullRequest property. Specify an array of string values to match this event if the actual value of pullRequest is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_id: (experimental) pullRequestId property. Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_metadata: (experimental) repositoryMetadata property. Specify an array of string values to match this event if the actual value of repositoryMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tree_id: (experimental) treeId property. Specify an array of string values to match this event if the actual value of treeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param upload_id: (experimental) uploadId property. Specify an array of string values to match this event if the actual value of uploadId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                # approval_rules: Any
                
                response_elements = codecommit_events.AWSAPICallViaCloudTrail.ResponseElements(
                    after_blob_id=["afterBlobId"],
                    after_commit_id=["afterCommitId"],
                    before_blob_id=["beforeBlobId"],
                    before_commit_id=["beforeCommitId"],
                    blob_id=["blobId"],
                    comment=codecommit_events.AWSAPICallViaCloudTrail.Comment(
                        author_arn=["authorArn"],
                        client_request_token=["clientRequestToken"],
                        comment_id=["commentId"],
                        content=["content"],
                        creation_date=["creationDate"],
                        deleted=["deleted"],
                        in_reply_to=["inReplyTo"],
                        last_modified_date=["lastModifiedDate"]
                    ),
                    commit_id=["commitId"],
                    deleted_branch=codecommit_events.AWSAPICallViaCloudTrail.DeletedBranch(
                        branch_name=["branchName"],
                        commit_id=["commitId"]
                    ),
                    file_path=["filePath"],
                    files_added=[codecommit_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                        absolute_path=["absolutePath"],
                        blob_id=["blobId"],
                        file_mode=["fileMode"]
                    )],
                    files_deleted=[codecommit_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                        absolute_path=["absolutePath"],
                        blob_id=["blobId"],
                        file_mode=["fileMode"]
                    )],
                    files_updated=[codecommit_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                        absolute_path=["absolutePath"],
                        blob_id=["blobId"],
                        file_mode=["fileMode"]
                    )],
                    location=codecommit_events.AWSAPICallViaCloudTrail.Location(
                        file_path=["filePath"],
                        file_position=["filePosition"],
                        relative_file_version=["relativeFileVersion"]
                    ),
                    pull_request=codecommit_events.AWSAPICallViaCloudTrail.PullRequest(
                        approval_rules=[approval_rules],
                        author_arn=["authorArn"],
                        client_request_token=["clientRequestToken"],
                        creation_date=["creationDate"],
                        description=["description"],
                        last_activity_date=["lastActivityDate"],
                        pull_request_id=["pullRequestId"],
                        pull_request_status=["pullRequestStatus"],
                        pull_request_targets=[codecommit_events.AWSAPICallViaCloudTrail.PullRequestItem(
                            destination_commit=["destinationCommit"],
                            destination_reference=["destinationReference"],
                            merge_base=["mergeBase"],
                            merge_metadata=codecommit_events.AWSAPICallViaCloudTrail.MergeMetadata(
                                is_merged=["isMerged"],
                                merge_commit_id=["mergeCommitId"],
                                merged_by=["mergedBy"],
                                merge_option=["mergeOption"]
                            ),
                            repository_name=["repositoryName"],
                            source_commit=["sourceCommit"],
                            source_reference=["sourceReference"]
                        )],
                        revision_id=["revisionId"],
                        title=["title"]
                    ),
                    pull_request_id=["pullRequestId"],
                    repository_id=["repositoryId"],
                    repository_metadata=codecommit_events.AWSAPICallViaCloudTrail.RepositoryMetadata(
                        account_id=["accountId"],
                        arn=["arn"],
                        clone_url_http=["cloneUrlHttp"],
                        clone_url_ssh=["cloneUrlSsh"],
                        creation_date=["creationDate"],
                        last_modified_date=["lastModifiedDate"],
                        repository_description=["repositoryDescription"],
                        repository_id=["repositoryId"],
                        repository_name=["repositoryName"]
                    ),
                    repository_name=["repositoryName"],
                    tree_id=["treeId"],
                    upload_id=["uploadId"]
                )
            '''
            if isinstance(comment, dict):
                comment = AWSAPICallViaCloudTrail.Comment(**comment)
            if isinstance(deleted_branch, dict):
                deleted_branch = AWSAPICallViaCloudTrail.DeletedBranch(**deleted_branch)
            if isinstance(location, dict):
                location = AWSAPICallViaCloudTrail.Location(**location)
            if isinstance(pull_request, dict):
                pull_request = AWSAPICallViaCloudTrail.PullRequest(**pull_request)
            if isinstance(repository_metadata, dict):
                repository_metadata = AWSAPICallViaCloudTrail.RepositoryMetadata(**repository_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__03243e58e20151253f3c9055a2989503e28716ec743550a9ff74c4ca67db6c3f)
                check_type(argname="argument after_blob_id", value=after_blob_id, expected_type=type_hints["after_blob_id"])
                check_type(argname="argument after_commit_id", value=after_commit_id, expected_type=type_hints["after_commit_id"])
                check_type(argname="argument before_blob_id", value=before_blob_id, expected_type=type_hints["before_blob_id"])
                check_type(argname="argument before_commit_id", value=before_commit_id, expected_type=type_hints["before_commit_id"])
                check_type(argname="argument blob_id", value=blob_id, expected_type=type_hints["blob_id"])
                check_type(argname="argument comment", value=comment, expected_type=type_hints["comment"])
                check_type(argname="argument commit_id", value=commit_id, expected_type=type_hints["commit_id"])
                check_type(argname="argument deleted_branch", value=deleted_branch, expected_type=type_hints["deleted_branch"])
                check_type(argname="argument file_path", value=file_path, expected_type=type_hints["file_path"])
                check_type(argname="argument files_added", value=files_added, expected_type=type_hints["files_added"])
                check_type(argname="argument files_deleted", value=files_deleted, expected_type=type_hints["files_deleted"])
                check_type(argname="argument files_updated", value=files_updated, expected_type=type_hints["files_updated"])
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument pull_request", value=pull_request, expected_type=type_hints["pull_request"])
                check_type(argname="argument pull_request_id", value=pull_request_id, expected_type=type_hints["pull_request_id"])
                check_type(argname="argument repository_id", value=repository_id, expected_type=type_hints["repository_id"])
                check_type(argname="argument repository_metadata", value=repository_metadata, expected_type=type_hints["repository_metadata"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
                check_type(argname="argument tree_id", value=tree_id, expected_type=type_hints["tree_id"])
                check_type(argname="argument upload_id", value=upload_id, expected_type=type_hints["upload_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if after_blob_id is not None:
                self._values["after_blob_id"] = after_blob_id
            if after_commit_id is not None:
                self._values["after_commit_id"] = after_commit_id
            if before_blob_id is not None:
                self._values["before_blob_id"] = before_blob_id
            if before_commit_id is not None:
                self._values["before_commit_id"] = before_commit_id
            if blob_id is not None:
                self._values["blob_id"] = blob_id
            if comment is not None:
                self._values["comment"] = comment
            if commit_id is not None:
                self._values["commit_id"] = commit_id
            if deleted_branch is not None:
                self._values["deleted_branch"] = deleted_branch
            if file_path is not None:
                self._values["file_path"] = file_path
            if files_added is not None:
                self._values["files_added"] = files_added
            if files_deleted is not None:
                self._values["files_deleted"] = files_deleted
            if files_updated is not None:
                self._values["files_updated"] = files_updated
            if location is not None:
                self._values["location"] = location
            if pull_request is not None:
                self._values["pull_request"] = pull_request
            if pull_request_id is not None:
                self._values["pull_request_id"] = pull_request_id
            if repository_id is not None:
                self._values["repository_id"] = repository_id
            if repository_metadata is not None:
                self._values["repository_metadata"] = repository_metadata
            if repository_name is not None:
                self._values["repository_name"] = repository_name
            if tree_id is not None:
                self._values["tree_id"] = tree_id
            if upload_id is not None:
                self._values["upload_id"] = upload_id

        @builtins.property
        def after_blob_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) afterBlobId property.

            Specify an array of string values to match this event if the actual value of afterBlobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("after_blob_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def after_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) afterCommitId property.

            Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("after_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def before_blob_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) beforeBlobId property.

            Specify an array of string values to match this event if the actual value of beforeBlobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("before_blob_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def before_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) beforeCommitId property.

            Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("before_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def blob_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) blobId property.

            Specify an array of string values to match this event if the actual value of blobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("blob_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def comment(self) -> typing.Optional["AWSAPICallViaCloudTrail.Comment"]:
            '''(experimental) comment property.

            Specify an array of string values to match this event if the actual value of comment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comment")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Comment"], result)

        @builtins.property
        def commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commitId property.

            Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def deleted_branch(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.DeletedBranch"]:
            '''(experimental) deletedBranch property.

            Specify an array of string values to match this event if the actual value of deletedBranch is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deleted_branch")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.DeletedBranch"], result)

        @builtins.property
        def file_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) filePath property.

            Specify an array of string values to match this event if the actual value of filePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("file_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def files_added(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]]:
            '''(experimental) filesAdded property.

            Specify an array of string values to match this event if the actual value of filesAdded is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("files_added")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]], result)

        @builtins.property
        def files_deleted(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]]:
            '''(experimental) filesDeleted property.

            Specify an array of string values to match this event if the actual value of filesDeleted is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("files_deleted")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]], result)

        @builtins.property
        def files_updated(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]]:
            '''(experimental) filesUpdated property.

            Specify an array of string values to match this event if the actual value of filesUpdated is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("files_updated")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]], result)

        @builtins.property
        def location(self) -> typing.Optional["AWSAPICallViaCloudTrail.Location"]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Location"], result)

        @builtins.property
        def pull_request(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.PullRequest"]:
            '''(experimental) pullRequest property.

            Specify an array of string values to match this event if the actual value of pullRequest is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.PullRequest"], result)

        @builtins.property
        def pull_request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestId property.

            Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryId property.

            Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_metadata(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RepositoryMetadata"]:
            '''(experimental) repositoryMetadata property.

            Specify an array of string values to match this event if the actual value of repositoryMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_metadata")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RepositoryMetadata"], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tree_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) treeId property.

            Specify an array of string values to match this event if the actual value of treeId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tree_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def upload_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) uploadId property.

            Specify an array of string values to match this event if the actual value of uploadId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("upload_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElements(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.ResponseElementsItem",
        jsii_struct_bases=[],
        name_mapping={
            "absolute_path": "absolutePath",
            "blob_id": "blobId",
            "file_mode": "fileMode",
        },
    )
    class ResponseElementsItem:
        def __init__(
            self,
            *,
            absolute_path: typing.Optional[typing.Sequence[builtins.str]] = None,
            blob_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            file_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElementsItem.

            :param absolute_path: (experimental) absolutePath property. Specify an array of string values to match this event if the actual value of absolutePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param blob_id: (experimental) blobId property. Specify an array of string values to match this event if the actual value of blobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param file_mode: (experimental) fileMode property. Specify an array of string values to match this event if the actual value of fileMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                response_elements_item = codecommit_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                    absolute_path=["absolutePath"],
                    blob_id=["blobId"],
                    file_mode=["fileMode"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1c4e9f6149221d13ff927e82a403d817e654f4bb1b4f7e2a8f8aac35affc34eb)
                check_type(argname="argument absolute_path", value=absolute_path, expected_type=type_hints["absolute_path"])
                check_type(argname="argument blob_id", value=blob_id, expected_type=type_hints["blob_id"])
                check_type(argname="argument file_mode", value=file_mode, expected_type=type_hints["file_mode"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if absolute_path is not None:
                self._values["absolute_path"] = absolute_path
            if blob_id is not None:
                self._values["blob_id"] = blob_id
            if file_mode is not None:
                self._values["file_mode"] = file_mode

        @builtins.property
        def absolute_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) absolutePath property.

            Specify an array of string values to match this event if the actual value of absolutePath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("absolute_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def blob_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) blobId property.

            Specify an array of string values to match this event if the actual value of blobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("blob_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def file_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fileMode property.

            Specify an array of string values to match this event if the actual value of fileMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("file_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElementsItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.SessionContext",
        jsii_struct_bases=[],
        name_mapping={
            "attributes": "attributes",
            "session_issuer": "sessionIssuer",
            "web_id_federation_data": "webIdFederationData",
        },
    )
    class SessionContext:
        def __init__(
            self,
            *,
            attributes: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            session_issuer: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionIssuer", typing.Dict[builtins.str, typing.Any]]] = None,
            web_id_federation_data: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionContext.

            :param attributes: (experimental) attributes property. Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_issuer: (experimental) sessionIssuer property. Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param web_id_federation_data: (experimental) webIdFederationData property. Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                session_context = codecommit_events.AWSAPICallViaCloudTrail.SessionContext(
                    attributes=codecommit_events.AWSAPICallViaCloudTrail.Attributes(
                        creation_date=["creationDate"],
                        mfa_authenticated=["mfaAuthenticated"]
                    ),
                    session_issuer=codecommit_events.AWSAPICallViaCloudTrail.SessionIssuer(
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        type=["type"],
                        user_name=["userName"]
                    ),
                    web_id_federation_data=["webIdFederationData"]
                )
            '''
            if isinstance(attributes, dict):
                attributes = AWSAPICallViaCloudTrail.Attributes(**attributes)
            if isinstance(session_issuer, dict):
                session_issuer = AWSAPICallViaCloudTrail.SessionIssuer(**session_issuer)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9986bd3be0726431712d2d0b18c687d056163f7e42a9e01a11fff9a2fd09e45a)
                check_type(argname="argument attributes", value=attributes, expected_type=type_hints["attributes"])
                check_type(argname="argument session_issuer", value=session_issuer, expected_type=type_hints["session_issuer"])
                check_type(argname="argument web_id_federation_data", value=web_id_federation_data, expected_type=type_hints["web_id_federation_data"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attributes is not None:
                self._values["attributes"] = attributes
            if session_issuer is not None:
                self._values["session_issuer"] = session_issuer
            if web_id_federation_data is not None:
                self._values["web_id_federation_data"] = web_id_federation_data

        @builtins.property
        def attributes(self) -> typing.Optional["AWSAPICallViaCloudTrail.Attributes"]:
            '''(experimental) attributes property.

            Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attributes")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Attributes"], result)

        @builtins.property
        def session_issuer(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"]:
            '''(experimental) sessionIssuer property.

            Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_issuer")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"], result)

        @builtins.property
        def web_id_federation_data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) webIdFederationData property.

            Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("web_id_federation_data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionContext(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.SessionIssuer",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "type": "type",
            "user_name": "userName",
        },
    )
    class SessionIssuer:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionIssuer.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_name: (experimental) userName property. Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                session_issuer = codecommit_events.AWSAPICallViaCloudTrail.SessionIssuer(
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    type=["type"],
                    user_name=["userName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__37e0f57c058b3af2d18aa2d9ee905931f65d05cec200aac03f1698875b6ac94c)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument user_name", value=user_name, expected_type=type_hints["user_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if type is not None:
                self._values["type"] = type
            if user_name is not None:
                self._values["user_name"] = user_name

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userName property.

            Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionIssuer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.AWSAPICallViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={
            "access_key_id": "accessKeyId",
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "session_context": "sessionContext",
            "type": "type",
            "user_name": "userName",
        },
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_context: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionContext", typing.Dict[builtins.str, typing.Any]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param access_key_id: (experimental) accessKeyId property. Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_context: (experimental) sessionContext property. Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_name: (experimental) userName property. Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                user_identity = codecommit_events.AWSAPICallViaCloudTrail.UserIdentity(
                    access_key_id=["accessKeyId"],
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    session_context=codecommit_events.AWSAPICallViaCloudTrail.SessionContext(
                        attributes=codecommit_events.AWSAPICallViaCloudTrail.Attributes(
                            creation_date=["creationDate"],
                            mfa_authenticated=["mfaAuthenticated"]
                        ),
                        session_issuer=codecommit_events.AWSAPICallViaCloudTrail.SessionIssuer(
                            account_id=["accountId"],
                            arn=["arn"],
                            principal_id=["principalId"],
                            type=["type"],
                            user_name=["userName"]
                        ),
                        web_id_federation_data=["webIdFederationData"]
                    ),
                    type=["type"],
                    user_name=["userName"]
                )
            '''
            if isinstance(session_context, dict):
                session_context = AWSAPICallViaCloudTrail.SessionContext(**session_context)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__10a9642cb1969787274208558aa5a7e046214586136c831f9333624df923f5f1)
                check_type(argname="argument access_key_id", value=access_key_id, expected_type=type_hints["access_key_id"])
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument session_context", value=session_context, expected_type=type_hints["session_context"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument user_name", value=user_name, expected_type=type_hints["user_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if access_key_id is not None:
                self._values["access_key_id"] = access_key_id
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if session_context is not None:
                self._values["session_context"] = session_context
            if type is not None:
                self._values["type"] = type
            if user_name is not None:
                self._values["user_name"] = user_name

        @builtins.property
        def access_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accessKeyId property.

            Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("access_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_context(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionContext"]:
            '''(experimental) sessionContext property.

            Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_context")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionContext"], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userName property.

            Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodeCommitApprovalRuleTemplateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitApprovalRuleTemplateChange",
):
    '''(experimental) EventBridge event pattern for aws.codecommit@CodeCommitApprovalRuleTemplateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
        
        code_commit_approval_rule_template_change = codecommit_events.CodeCommitApprovalRuleTemplateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codeCommitApprovalRuleTemplateChangePattern")
    @builtins.classmethod
    def code_commit_approval_rule_template_change_pattern(
        cls,
        *,
        approval_rule_template_content_sha256: typing.Optional[typing.Sequence[builtins.str]] = None,
        approval_rule_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        approval_rule_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
        repositories: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeCommit Approval Rule Template Change.

        :param approval_rule_template_content_sha256: (experimental) approvalRuleTemplateContentSha256 property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateContentSha256 is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param approval_rule_template_id: (experimental) approvalRuleTemplateId property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param approval_rule_template_name: (experimental) approvalRuleTemplateName property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param last_modified_date: (experimental) lastModifiedDate property. Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param repositories: (experimental) repositories property. Specify an array of string values to match this event if the actual value of repositories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeCommitApprovalRuleTemplateChange.CodeCommitApprovalRuleTemplateChangeProps(
            approval_rule_template_content_sha256=approval_rule_template_content_sha256,
            approval_rule_template_id=approval_rule_template_id,
            approval_rule_template_name=approval_rule_template_name,
            caller_user_arn=caller_user_arn,
            creation_date=creation_date,
            event=event,
            event_metadata=event_metadata,
            last_modified_date=last_modified_date,
            notification_body=notification_body,
            repositories=repositories,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codeCommitApprovalRuleTemplateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitApprovalRuleTemplateChange.CodeCommitApprovalRuleTemplateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "approval_rule_template_content_sha256": "approvalRuleTemplateContentSha256",
            "approval_rule_template_id": "approvalRuleTemplateId",
            "approval_rule_template_name": "approvalRuleTemplateName",
            "caller_user_arn": "callerUserArn",
            "creation_date": "creationDate",
            "event": "event",
            "event_metadata": "eventMetadata",
            "last_modified_date": "lastModifiedDate",
            "notification_body": "notificationBody",
            "repositories": "repositories",
        },
    )
    class CodeCommitApprovalRuleTemplateChangeProps:
        def __init__(
            self,
            *,
            approval_rule_template_content_sha256: typing.Optional[typing.Sequence[builtins.str]] = None,
            approval_rule_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            approval_rule_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
            repositories: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codecommit@CodeCommitApprovalRuleTemplateChange event.

            :param approval_rule_template_content_sha256: (experimental) approvalRuleTemplateContentSha256 property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateContentSha256 is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param approval_rule_template_id: (experimental) approvalRuleTemplateId property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param approval_rule_template_name: (experimental) approvalRuleTemplateName property. Specify an array of string values to match this event if the actual value of approvalRuleTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param last_modified_date: (experimental) lastModifiedDate property. Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repositories: (experimental) repositories property. Specify an array of string values to match this event if the actual value of repositories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                code_commit_approval_rule_template_change_props = codecommit_events.CodeCommitApprovalRuleTemplateChange.CodeCommitApprovalRuleTemplateChangeProps(
                    approval_rule_template_content_sha256=["approvalRuleTemplateContentSha256"],
                    approval_rule_template_id=["approvalRuleTemplateId"],
                    approval_rule_template_name=["approvalRuleTemplateName"],
                    caller_user_arn=["callerUserArn"],
                    creation_date=["creationDate"],
                    event=["event"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    last_modified_date=["lastModifiedDate"],
                    notification_body=["notificationBody"],
                    repositories={
                        "repositories_key": "repositories"
                    }
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6d3f710da01300a13042824313398ba188e15c80f9ed31d7219b30aa41788823)
                check_type(argname="argument approval_rule_template_content_sha256", value=approval_rule_template_content_sha256, expected_type=type_hints["approval_rule_template_content_sha256"])
                check_type(argname="argument approval_rule_template_id", value=approval_rule_template_id, expected_type=type_hints["approval_rule_template_id"])
                check_type(argname="argument approval_rule_template_name", value=approval_rule_template_name, expected_type=type_hints["approval_rule_template_name"])
                check_type(argname="argument caller_user_arn", value=caller_user_arn, expected_type=type_hints["caller_user_arn"])
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument last_modified_date", value=last_modified_date, expected_type=type_hints["last_modified_date"])
                check_type(argname="argument notification_body", value=notification_body, expected_type=type_hints["notification_body"])
                check_type(argname="argument repositories", value=repositories, expected_type=type_hints["repositories"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if approval_rule_template_content_sha256 is not None:
                self._values["approval_rule_template_content_sha256"] = approval_rule_template_content_sha256
            if approval_rule_template_id is not None:
                self._values["approval_rule_template_id"] = approval_rule_template_id
            if approval_rule_template_name is not None:
                self._values["approval_rule_template_name"] = approval_rule_template_name
            if caller_user_arn is not None:
                self._values["caller_user_arn"] = caller_user_arn
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if last_modified_date is not None:
                self._values["last_modified_date"] = last_modified_date
            if notification_body is not None:
                self._values["notification_body"] = notification_body
            if repositories is not None:
                self._values["repositories"] = repositories

        @builtins.property
        def approval_rule_template_content_sha256(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) approvalRuleTemplateContentSha256 property.

            Specify an array of string values to match this event if the actual value of approvalRuleTemplateContentSha256 is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_rule_template_content_sha256")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def approval_rule_template_id(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) approvalRuleTemplateId property.

            Specify an array of string values to match this event if the actual value of approvalRuleTemplateId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_rule_template_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def approval_rule_template_name(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) approvalRuleTemplateName property.

            Specify an array of string values to match this event if the actual value of approvalRuleTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_rule_template_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def caller_user_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) callerUserArn property.

            Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("caller_user_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event property.

            Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def last_modified_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) lastModifiedDate property.

            Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notification_body(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) notificationBody property.

            Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notification_body")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repositories(
            self,
        ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) repositories property.

            Specify an array of string values to match this event if the actual value of repositories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repositories")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeCommitApprovalRuleTemplateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodeCommitCommentOnCommit(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitCommentOnCommit",
):
    '''(experimental) EventBridge event pattern for aws.codecommit@CodeCommitCommentOnCommit.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
        
        code_commit_comment_on_commit = codecommit_events.CodeCommitCommentOnCommit()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codeCommitCommentOnCommitPattern")
    @builtins.classmethod
    def code_commit_comment_on_commit_pattern(
        cls,
        *,
        after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeCommit Comment on Commit.

        :param after_commit_id: (experimental) afterCommitId property. Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param before_commit_id: (experimental) beforeCommitId property. Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param comment_id: (experimental) commentId property. Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param in_reply_to: (experimental) inReplyTo property. Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
        :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeCommitCommentOnCommit.CodeCommitCommentOnCommitProps(
            after_commit_id=after_commit_id,
            before_commit_id=before_commit_id,
            caller_user_arn=caller_user_arn,
            comment_id=comment_id,
            event=event,
            event_metadata=event_metadata,
            in_reply_to=in_reply_to,
            notification_body=notification_body,
            repository_id=repository_id,
            repository_name=repository_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codeCommitCommentOnCommitPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitCommentOnCommit.CodeCommitCommentOnCommitProps",
        jsii_struct_bases=[],
        name_mapping={
            "after_commit_id": "afterCommitId",
            "before_commit_id": "beforeCommitId",
            "caller_user_arn": "callerUserArn",
            "comment_id": "commentId",
            "event": "event",
            "event_metadata": "eventMetadata",
            "in_reply_to": "inReplyTo",
            "notification_body": "notificationBody",
            "repository_id": "repositoryId",
            "repository_name": "repositoryName",
        },
    )
    class CodeCommitCommentOnCommitProps:
        def __init__(
            self,
            *,
            after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
            notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codecommit@CodeCommitCommentOnCommit event.

            :param after_commit_id: (experimental) afterCommitId property. Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param before_commit_id: (experimental) beforeCommitId property. Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param comment_id: (experimental) commentId property. Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param in_reply_to: (experimental) inReplyTo property. Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                code_commit_comment_on_commit_props = codecommit_events.CodeCommitCommentOnCommit.CodeCommitCommentOnCommitProps(
                    after_commit_id=["afterCommitId"],
                    before_commit_id=["beforeCommitId"],
                    caller_user_arn=["callerUserArn"],
                    comment_id=["commentId"],
                    event=["event"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    in_reply_to=["inReplyTo"],
                    notification_body=["notificationBody"],
                    repository_id=["repositoryId"],
                    repository_name=["repositoryName"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dfd880ea12a52439268251c55b2545ad3d236639d6034b4a27bd4ec37941ea78)
                check_type(argname="argument after_commit_id", value=after_commit_id, expected_type=type_hints["after_commit_id"])
                check_type(argname="argument before_commit_id", value=before_commit_id, expected_type=type_hints["before_commit_id"])
                check_type(argname="argument caller_user_arn", value=caller_user_arn, expected_type=type_hints["caller_user_arn"])
                check_type(argname="argument comment_id", value=comment_id, expected_type=type_hints["comment_id"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument in_reply_to", value=in_reply_to, expected_type=type_hints["in_reply_to"])
                check_type(argname="argument notification_body", value=notification_body, expected_type=type_hints["notification_body"])
                check_type(argname="argument repository_id", value=repository_id, expected_type=type_hints["repository_id"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if after_commit_id is not None:
                self._values["after_commit_id"] = after_commit_id
            if before_commit_id is not None:
                self._values["before_commit_id"] = before_commit_id
            if caller_user_arn is not None:
                self._values["caller_user_arn"] = caller_user_arn
            if comment_id is not None:
                self._values["comment_id"] = comment_id
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if in_reply_to is not None:
                self._values["in_reply_to"] = in_reply_to
            if notification_body is not None:
                self._values["notification_body"] = notification_body
            if repository_id is not None:
                self._values["repository_id"] = repository_id
            if repository_name is not None:
                self._values["repository_name"] = repository_name

        @builtins.property
        def after_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) afterCommitId property.

            Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("after_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def before_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) beforeCommitId property.

            Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("before_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def caller_user_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) callerUserArn property.

            Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("caller_user_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def comment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commentId property.

            Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event property.

            Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def in_reply_to(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) inReplyTo property.

            Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("in_reply_to")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notification_body(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) notificationBody property.

            Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notification_body")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryId property.

            Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Repository reference

            :stability: experimental
            '''
            result = self._values.get("repository_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeCommitCommentOnCommitProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodeCommitCommentOnPullRequest(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitCommentOnPullRequest",
):
    '''(experimental) EventBridge event pattern for aws.codecommit@CodeCommitCommentOnPullRequest.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
        
        code_commit_comment_on_pull_request = codecommit_events.CodeCommitCommentOnPullRequest()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codeCommitCommentOnPullRequestPattern")
    @builtins.classmethod
    def code_commit_comment_on_pull_request_pattern(
        cls,
        *,
        after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
        pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeCommit Comment on Pull Request.

        :param after_commit_id: (experimental) afterCommitId property. Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param before_commit_id: (experimental) beforeCommitId property. Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param comment_id: (experimental) commentId property. Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param in_reply_to: (experimental) inReplyTo property. Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pull_request_id: (experimental) pullRequestId property. Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
        :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeCommitCommentOnPullRequest.CodeCommitCommentOnPullRequestProps(
            after_commit_id=after_commit_id,
            before_commit_id=before_commit_id,
            caller_user_arn=caller_user_arn,
            comment_id=comment_id,
            event=event,
            event_metadata=event_metadata,
            in_reply_to=in_reply_to,
            notification_body=notification_body,
            pull_request_id=pull_request_id,
            repository_id=repository_id,
            repository_name=repository_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codeCommitCommentOnPullRequestPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitCommentOnPullRequest.CodeCommitCommentOnPullRequestProps",
        jsii_struct_bases=[],
        name_mapping={
            "after_commit_id": "afterCommitId",
            "before_commit_id": "beforeCommitId",
            "caller_user_arn": "callerUserArn",
            "comment_id": "commentId",
            "event": "event",
            "event_metadata": "eventMetadata",
            "in_reply_to": "inReplyTo",
            "notification_body": "notificationBody",
            "pull_request_id": "pullRequestId",
            "repository_id": "repositoryId",
            "repository_name": "repositoryName",
        },
    )
    class CodeCommitCommentOnPullRequestProps:
        def __init__(
            self,
            *,
            after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
            notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codecommit@CodeCommitCommentOnPullRequest event.

            :param after_commit_id: (experimental) afterCommitId property. Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param before_commit_id: (experimental) beforeCommitId property. Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param comment_id: (experimental) commentId property. Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param in_reply_to: (experimental) inReplyTo property. Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_id: (experimental) pullRequestId property. Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                code_commit_comment_on_pull_request_props = codecommit_events.CodeCommitCommentOnPullRequest.CodeCommitCommentOnPullRequestProps(
                    after_commit_id=["afterCommitId"],
                    before_commit_id=["beforeCommitId"],
                    caller_user_arn=["callerUserArn"],
                    comment_id=["commentId"],
                    event=["event"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    in_reply_to=["inReplyTo"],
                    notification_body=["notificationBody"],
                    pull_request_id=["pullRequestId"],
                    repository_id=["repositoryId"],
                    repository_name=["repositoryName"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b42e0ec4e0a8f5d279250cd6a35ac3709654b23b6b369533e7039d9b310e4de5)
                check_type(argname="argument after_commit_id", value=after_commit_id, expected_type=type_hints["after_commit_id"])
                check_type(argname="argument before_commit_id", value=before_commit_id, expected_type=type_hints["before_commit_id"])
                check_type(argname="argument caller_user_arn", value=caller_user_arn, expected_type=type_hints["caller_user_arn"])
                check_type(argname="argument comment_id", value=comment_id, expected_type=type_hints["comment_id"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument in_reply_to", value=in_reply_to, expected_type=type_hints["in_reply_to"])
                check_type(argname="argument notification_body", value=notification_body, expected_type=type_hints["notification_body"])
                check_type(argname="argument pull_request_id", value=pull_request_id, expected_type=type_hints["pull_request_id"])
                check_type(argname="argument repository_id", value=repository_id, expected_type=type_hints["repository_id"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if after_commit_id is not None:
                self._values["after_commit_id"] = after_commit_id
            if before_commit_id is not None:
                self._values["before_commit_id"] = before_commit_id
            if caller_user_arn is not None:
                self._values["caller_user_arn"] = caller_user_arn
            if comment_id is not None:
                self._values["comment_id"] = comment_id
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if in_reply_to is not None:
                self._values["in_reply_to"] = in_reply_to
            if notification_body is not None:
                self._values["notification_body"] = notification_body
            if pull_request_id is not None:
                self._values["pull_request_id"] = pull_request_id
            if repository_id is not None:
                self._values["repository_id"] = repository_id
            if repository_name is not None:
                self._values["repository_name"] = repository_name

        @builtins.property
        def after_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) afterCommitId property.

            Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("after_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def before_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) beforeCommitId property.

            Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("before_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def caller_user_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) callerUserArn property.

            Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("caller_user_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def comment_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commentId property.

            Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("comment_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event property.

            Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def in_reply_to(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) inReplyTo property.

            Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("in_reply_to")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notification_body(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) notificationBody property.

            Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notification_body")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestId property.

            Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryId property.

            Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Repository reference

            :stability: experimental
            '''
            result = self._values.get("repository_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeCommitCommentOnPullRequestProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodeCommitPullRequestStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitPullRequestStateChange",
):
    '''(experimental) EventBridge event pattern for aws.codecommit@CodeCommitPullRequestStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
        
        code_commit_pull_request_state_change = codecommit_events.CodeCommitPullRequestStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codeCommitPullRequestStateChangePattern")
    @builtins.classmethod
    def code_commit_pull_request_state_change_pattern(
        cls,
        *,
        approval_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        author: typing.Optional[typing.Sequence[builtins.str]] = None,
        caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        is_merged: typing.Optional[typing.Sequence[builtins.str]] = None,
        last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
        merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
        override_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        pull_request_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_names: typing.Optional[typing.Sequence[builtins.str]] = None,
        revision_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
        title: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeCommit Pull Request State Change.

        :param approval_status: (experimental) approvalStatus property. Specify an array of string values to match this event if the actual value of approvalStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param author: (experimental) author property. Specify an array of string values to match this event if the actual value of author is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination_commit: (experimental) destinationCommit property. Specify an array of string values to match this event if the actual value of destinationCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination_reference: (experimental) destinationReference property. Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param is_merged: (experimental) isMerged property. Specify an array of string values to match this event if the actual value of isMerged is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param last_modified_date: (experimental) lastModifiedDate property. Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param merge_option: (experimental) mergeOption property. Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param override_status: (experimental) overrideStatus property. Specify an array of string values to match this event if the actual value of overrideStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pull_request_id: (experimental) pullRequestId property. Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pull_request_status: (experimental) pullRequestStatus property. Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param repository_names: (experimental) repositoryNames property. Specify an array of string values to match this event if the actual value of repositoryNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param revision_id: (experimental) revisionId property. Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_commit: (experimental) sourceCommit property. Specify an array of string values to match this event if the actual value of sourceCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_reference: (experimental) sourceReference property. Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param title: (experimental) title property. Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeCommitPullRequestStateChange.CodeCommitPullRequestStateChangeProps(
            approval_status=approval_status,
            author=author,
            caller_user_arn=caller_user_arn,
            creation_date=creation_date,
            description=description,
            destination_commit=destination_commit,
            destination_reference=destination_reference,
            event=event,
            event_metadata=event_metadata,
            is_merged=is_merged,
            last_modified_date=last_modified_date,
            merge_option=merge_option,
            notification_body=notification_body,
            override_status=override_status,
            pull_request_id=pull_request_id,
            pull_request_status=pull_request_status,
            repository_names=repository_names,
            revision_id=revision_id,
            source_commit=source_commit,
            source_reference=source_reference,
            title=title,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codeCommitPullRequestStateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitPullRequestStateChange.CodeCommitPullRequestStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "approval_status": "approvalStatus",
            "author": "author",
            "caller_user_arn": "callerUserArn",
            "creation_date": "creationDate",
            "description": "description",
            "destination_commit": "destinationCommit",
            "destination_reference": "destinationReference",
            "event": "event",
            "event_metadata": "eventMetadata",
            "is_merged": "isMerged",
            "last_modified_date": "lastModifiedDate",
            "merge_option": "mergeOption",
            "notification_body": "notificationBody",
            "override_status": "overrideStatus",
            "pull_request_id": "pullRequestId",
            "pull_request_status": "pullRequestStatus",
            "repository_names": "repositoryNames",
            "revision_id": "revisionId",
            "source_commit": "sourceCommit",
            "source_reference": "sourceReference",
            "title": "title",
        },
    )
    class CodeCommitPullRequestStateChangeProps:
        def __init__(
            self,
            *,
            approval_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            author: typing.Optional[typing.Sequence[builtins.str]] = None,
            caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            is_merged: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
            notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
            override_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            pull_request_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_names: typing.Optional[typing.Sequence[builtins.str]] = None,
            revision_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
            title: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codecommit@CodeCommitPullRequestStateChange event.

            :param approval_status: (experimental) approvalStatus property. Specify an array of string values to match this event if the actual value of approvalStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param author: (experimental) author property. Specify an array of string values to match this event if the actual value of author is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination_commit: (experimental) destinationCommit property. Specify an array of string values to match this event if the actual value of destinationCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination_reference: (experimental) destinationReference property. Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param is_merged: (experimental) isMerged property. Specify an array of string values to match this event if the actual value of isMerged is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_modified_date: (experimental) lastModifiedDate property. Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param merge_option: (experimental) mergeOption property. Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param override_status: (experimental) overrideStatus property. Specify an array of string values to match this event if the actual value of overrideStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_id: (experimental) pullRequestId property. Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pull_request_status: (experimental) pullRequestStatus property. Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_names: (experimental) repositoryNames property. Specify an array of string values to match this event if the actual value of repositoryNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param revision_id: (experimental) revisionId property. Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_commit: (experimental) sourceCommit property. Specify an array of string values to match this event if the actual value of sourceCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_reference: (experimental) sourceReference property. Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param title: (experimental) title property. Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                code_commit_pull_request_state_change_props = codecommit_events.CodeCommitPullRequestStateChange.CodeCommitPullRequestStateChangeProps(
                    approval_status=["approvalStatus"],
                    author=["author"],
                    caller_user_arn=["callerUserArn"],
                    creation_date=["creationDate"],
                    description=["description"],
                    destination_commit=["destinationCommit"],
                    destination_reference=["destinationReference"],
                    event=["event"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    is_merged=["isMerged"],
                    last_modified_date=["lastModifiedDate"],
                    merge_option=["mergeOption"],
                    notification_body=["notificationBody"],
                    override_status=["overrideStatus"],
                    pull_request_id=["pullRequestId"],
                    pull_request_status=["pullRequestStatus"],
                    repository_names=["repositoryNames"],
                    revision_id=["revisionId"],
                    source_commit=["sourceCommit"],
                    source_reference=["sourceReference"],
                    title=["title"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6a692d15914d83c62461b89685c3c6cbd90b007289112493b568456c482df67e)
                check_type(argname="argument approval_status", value=approval_status, expected_type=type_hints["approval_status"])
                check_type(argname="argument author", value=author, expected_type=type_hints["author"])
                check_type(argname="argument caller_user_arn", value=caller_user_arn, expected_type=type_hints["caller_user_arn"])
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument destination_commit", value=destination_commit, expected_type=type_hints["destination_commit"])
                check_type(argname="argument destination_reference", value=destination_reference, expected_type=type_hints["destination_reference"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument is_merged", value=is_merged, expected_type=type_hints["is_merged"])
                check_type(argname="argument last_modified_date", value=last_modified_date, expected_type=type_hints["last_modified_date"])
                check_type(argname="argument merge_option", value=merge_option, expected_type=type_hints["merge_option"])
                check_type(argname="argument notification_body", value=notification_body, expected_type=type_hints["notification_body"])
                check_type(argname="argument override_status", value=override_status, expected_type=type_hints["override_status"])
                check_type(argname="argument pull_request_id", value=pull_request_id, expected_type=type_hints["pull_request_id"])
                check_type(argname="argument pull_request_status", value=pull_request_status, expected_type=type_hints["pull_request_status"])
                check_type(argname="argument repository_names", value=repository_names, expected_type=type_hints["repository_names"])
                check_type(argname="argument revision_id", value=revision_id, expected_type=type_hints["revision_id"])
                check_type(argname="argument source_commit", value=source_commit, expected_type=type_hints["source_commit"])
                check_type(argname="argument source_reference", value=source_reference, expected_type=type_hints["source_reference"])
                check_type(argname="argument title", value=title, expected_type=type_hints["title"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if approval_status is not None:
                self._values["approval_status"] = approval_status
            if author is not None:
                self._values["author"] = author
            if caller_user_arn is not None:
                self._values["caller_user_arn"] = caller_user_arn
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if description is not None:
                self._values["description"] = description
            if destination_commit is not None:
                self._values["destination_commit"] = destination_commit
            if destination_reference is not None:
                self._values["destination_reference"] = destination_reference
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if is_merged is not None:
                self._values["is_merged"] = is_merged
            if last_modified_date is not None:
                self._values["last_modified_date"] = last_modified_date
            if merge_option is not None:
                self._values["merge_option"] = merge_option
            if notification_body is not None:
                self._values["notification_body"] = notification_body
            if override_status is not None:
                self._values["override_status"] = override_status
            if pull_request_id is not None:
                self._values["pull_request_id"] = pull_request_id
            if pull_request_status is not None:
                self._values["pull_request_status"] = pull_request_status
            if repository_names is not None:
                self._values["repository_names"] = repository_names
            if revision_id is not None:
                self._values["revision_id"] = revision_id
            if source_commit is not None:
                self._values["source_commit"] = source_commit
            if source_reference is not None:
                self._values["source_reference"] = source_reference
            if title is not None:
                self._values["title"] = title

        @builtins.property
        def approval_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) approvalStatus property.

            Specify an array of string values to match this event if the actual value of approvalStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("approval_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def author(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) author property.

            Specify an array of string values to match this event if the actual value of author is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("author")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def caller_user_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) callerUserArn property.

            Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("caller_user_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination_commit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) destinationCommit property.

            Specify an array of string values to match this event if the actual value of destinationCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination_commit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination_reference(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) destinationReference property.

            Specify an array of string values to match this event if the actual value of destinationReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination_reference")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event property.

            Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def is_merged(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) isMerged property.

            Specify an array of string values to match this event if the actual value of isMerged is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("is_merged")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_modified_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) lastModifiedDate property.

            Specify an array of string values to match this event if the actual value of lastModifiedDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def merge_option(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mergeOption property.

            Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("merge_option")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notification_body(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) notificationBody property.

            Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notification_body")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def override_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) overrideStatus property.

            Specify an array of string values to match this event if the actual value of overrideStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("override_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestId property.

            Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pull_request_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pullRequestStatus property.

            Specify an array of string values to match this event if the actual value of pullRequestStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pull_request_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_names(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryNames property.

            Specify an array of string values to match this event if the actual value of repositoryNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_names")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def revision_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) revisionId property.

            Specify an array of string values to match this event if the actual value of revisionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("revision_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_commit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceCommit property.

            Specify an array of string values to match this event if the actual value of sourceCommit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_commit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_reference(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceReference property.

            Specify an array of string values to match this event if the actual value of sourceReference is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_reference")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def title(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) title property.

            Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("title")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeCommitPullRequestStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodeCommitRepositoryStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitRepositoryStateChange",
):
    '''(experimental) EventBridge event pattern for aws.codecommit@CodeCommitRepositoryStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
        
        code_commit_repository_state_change = codecommit_events.CodeCommitRepositoryStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="codeCommitRepositoryStateChangePattern")
    @builtins.classmethod
    def code_commit_repository_state_change_pattern(
        cls,
        *,
        base_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        conflict_detail_level: typing.Optional[typing.Sequence[builtins.str]] = None,
        conflict_details_level: typing.Optional[typing.Sequence[builtins.str]] = None,
        conflict_resolution_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
        old_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_full_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeCommit Repository State Change.

        :param base_commit_id: (experimental) baseCommitId property. Specify an array of string values to match this event if the actual value of baseCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param commit_id: (experimental) commitId property. Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param conflict_detail_level: (experimental) conflictDetailLevel property. Specify an array of string values to match this event if the actual value of conflictDetailLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param conflict_details_level: (experimental) conflictDetailsLevel property. Specify an array of string values to match this event if the actual value of conflictDetailsLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param conflict_resolution_strategy: (experimental) conflictResolutionStrategy property. Specify an array of string values to match this event if the actual value of conflictResolutionStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination_commit_id: (experimental) destinationCommitId property. Specify an array of string values to match this event if the actual value of destinationCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param merge_option: (experimental) mergeOption property. Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param old_commit_id: (experimental) oldCommitId property. Specify an array of string values to match this event if the actual value of oldCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_full_name: (experimental) referenceFullName property. Specify an array of string values to match this event if the actual value of referenceFullName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_name: (experimental) referenceName property. Specify an array of string values to match this event if the actual value of referenceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_type: (experimental) referenceType property. Specify an array of string values to match this event if the actual value of referenceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
        :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_commit_id: (experimental) sourceCommitId property. Specify an array of string values to match this event if the actual value of sourceCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeCommitRepositoryStateChange.CodeCommitRepositoryStateChangeProps(
            base_commit_id=base_commit_id,
            caller_user_arn=caller_user_arn,
            commit_id=commit_id,
            conflict_detail_level=conflict_detail_level,
            conflict_details_level=conflict_details_level,
            conflict_resolution_strategy=conflict_resolution_strategy,
            destination_commit_id=destination_commit_id,
            event=event,
            event_metadata=event_metadata,
            merge_option=merge_option,
            old_commit_id=old_commit_id,
            reference_full_name=reference_full_name,
            reference_name=reference_name,
            reference_type=reference_type,
            repository_id=repository_id,
            repository_name=repository_name,
            source_commit_id=source_commit_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "codeCommitRepositoryStateChangePattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.CodeCommitRepositoryStateChange.CodeCommitRepositoryStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "base_commit_id": "baseCommitId",
            "caller_user_arn": "callerUserArn",
            "commit_id": "commitId",
            "conflict_detail_level": "conflictDetailLevel",
            "conflict_details_level": "conflictDetailsLevel",
            "conflict_resolution_strategy": "conflictResolutionStrategy",
            "destination_commit_id": "destinationCommitId",
            "event": "event",
            "event_metadata": "eventMetadata",
            "merge_option": "mergeOption",
            "old_commit_id": "oldCommitId",
            "reference_full_name": "referenceFullName",
            "reference_name": "referenceName",
            "reference_type": "referenceType",
            "repository_id": "repositoryId",
            "repository_name": "repositoryName",
            "source_commit_id": "sourceCommitId",
        },
    )
    class CodeCommitRepositoryStateChangeProps:
        def __init__(
            self,
            *,
            base_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            conflict_detail_level: typing.Optional[typing.Sequence[builtins.str]] = None,
            conflict_details_level: typing.Optional[typing.Sequence[builtins.str]] = None,
            conflict_resolution_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
            old_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_full_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            reference_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codecommit@CodeCommitRepositoryStateChange event.

            :param base_commit_id: (experimental) baseCommitId property. Specify an array of string values to match this event if the actual value of baseCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param commit_id: (experimental) commitId property. Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param conflict_detail_level: (experimental) conflictDetailLevel property. Specify an array of string values to match this event if the actual value of conflictDetailLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param conflict_details_level: (experimental) conflictDetailsLevel property. Specify an array of string values to match this event if the actual value of conflictDetailsLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param conflict_resolution_strategy: (experimental) conflictResolutionStrategy property. Specify an array of string values to match this event if the actual value of conflictResolutionStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination_commit_id: (experimental) destinationCommitId property. Specify an array of string values to match this event if the actual value of destinationCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param merge_option: (experimental) mergeOption property. Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param old_commit_id: (experimental) oldCommitId property. Specify an array of string values to match this event if the actual value of oldCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_full_name: (experimental) referenceFullName property. Specify an array of string values to match this event if the actual value of referenceFullName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_name: (experimental) referenceName property. Specify an array of string values to match this event if the actual value of referenceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reference_type: (experimental) referenceType property. Specify an array of string values to match this event if the actual value of referenceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
            :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_commit_id: (experimental) sourceCommitId property. Specify an array of string values to match this event if the actual value of sourceCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
                
                code_commit_repository_state_change_props = codecommit_events.CodeCommitRepositoryStateChange.CodeCommitRepositoryStateChangeProps(
                    base_commit_id=["baseCommitId"],
                    caller_user_arn=["callerUserArn"],
                    commit_id=["commitId"],
                    conflict_detail_level=["conflictDetailLevel"],
                    conflict_details_level=["conflictDetailsLevel"],
                    conflict_resolution_strategy=["conflictResolutionStrategy"],
                    destination_commit_id=["destinationCommitId"],
                    event=["event"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    merge_option=["mergeOption"],
                    old_commit_id=["oldCommitId"],
                    reference_full_name=["referenceFullName"],
                    reference_name=["referenceName"],
                    reference_type=["referenceType"],
                    repository_id=["repositoryId"],
                    repository_name=["repositoryName"],
                    source_commit_id=["sourceCommitId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d66243ecdc6a79c0519788e11c4a60443a8ceae5fa3be3cd35b58944d1170d5d)
                check_type(argname="argument base_commit_id", value=base_commit_id, expected_type=type_hints["base_commit_id"])
                check_type(argname="argument caller_user_arn", value=caller_user_arn, expected_type=type_hints["caller_user_arn"])
                check_type(argname="argument commit_id", value=commit_id, expected_type=type_hints["commit_id"])
                check_type(argname="argument conflict_detail_level", value=conflict_detail_level, expected_type=type_hints["conflict_detail_level"])
                check_type(argname="argument conflict_details_level", value=conflict_details_level, expected_type=type_hints["conflict_details_level"])
                check_type(argname="argument conflict_resolution_strategy", value=conflict_resolution_strategy, expected_type=type_hints["conflict_resolution_strategy"])
                check_type(argname="argument destination_commit_id", value=destination_commit_id, expected_type=type_hints["destination_commit_id"])
                check_type(argname="argument event", value=event, expected_type=type_hints["event"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument merge_option", value=merge_option, expected_type=type_hints["merge_option"])
                check_type(argname="argument old_commit_id", value=old_commit_id, expected_type=type_hints["old_commit_id"])
                check_type(argname="argument reference_full_name", value=reference_full_name, expected_type=type_hints["reference_full_name"])
                check_type(argname="argument reference_name", value=reference_name, expected_type=type_hints["reference_name"])
                check_type(argname="argument reference_type", value=reference_type, expected_type=type_hints["reference_type"])
                check_type(argname="argument repository_id", value=repository_id, expected_type=type_hints["repository_id"])
                check_type(argname="argument repository_name", value=repository_name, expected_type=type_hints["repository_name"])
                check_type(argname="argument source_commit_id", value=source_commit_id, expected_type=type_hints["source_commit_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if base_commit_id is not None:
                self._values["base_commit_id"] = base_commit_id
            if caller_user_arn is not None:
                self._values["caller_user_arn"] = caller_user_arn
            if commit_id is not None:
                self._values["commit_id"] = commit_id
            if conflict_detail_level is not None:
                self._values["conflict_detail_level"] = conflict_detail_level
            if conflict_details_level is not None:
                self._values["conflict_details_level"] = conflict_details_level
            if conflict_resolution_strategy is not None:
                self._values["conflict_resolution_strategy"] = conflict_resolution_strategy
            if destination_commit_id is not None:
                self._values["destination_commit_id"] = destination_commit_id
            if event is not None:
                self._values["event"] = event
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if merge_option is not None:
                self._values["merge_option"] = merge_option
            if old_commit_id is not None:
                self._values["old_commit_id"] = old_commit_id
            if reference_full_name is not None:
                self._values["reference_full_name"] = reference_full_name
            if reference_name is not None:
                self._values["reference_name"] = reference_name
            if reference_type is not None:
                self._values["reference_type"] = reference_type
            if repository_id is not None:
                self._values["repository_id"] = repository_id
            if repository_name is not None:
                self._values["repository_name"] = repository_name
            if source_commit_id is not None:
                self._values["source_commit_id"] = source_commit_id

        @builtins.property
        def base_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) baseCommitId property.

            Specify an array of string values to match this event if the actual value of baseCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("base_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def caller_user_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) callerUserArn property.

            Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("caller_user_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) commitId property.

            Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def conflict_detail_level(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) conflictDetailLevel property.

            Specify an array of string values to match this event if the actual value of conflictDetailLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("conflict_detail_level")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def conflict_details_level(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) conflictDetailsLevel property.

            Specify an array of string values to match this event if the actual value of conflictDetailsLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("conflict_details_level")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def conflict_resolution_strategy(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) conflictResolutionStrategy property.

            Specify an array of string values to match this event if the actual value of conflictResolutionStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("conflict_resolution_strategy")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) destinationCommitId property.

            Specify an array of string values to match this event if the actual value of destinationCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event property.

            Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def merge_option(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mergeOption property.

            Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("merge_option")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def old_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) oldCommitId property.

            Specify an array of string values to match this event if the actual value of oldCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("old_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_full_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) referenceFullName property.

            Specify an array of string values to match this event if the actual value of referenceFullName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reference_full_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) referenceName property.

            Specify an array of string values to match this event if the actual value of referenceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reference_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reference_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) referenceType property.

            Specify an array of string values to match this event if the actual value of referenceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reference_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryId property.

            Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Repository reference

            :stability: experimental
            '''
            result = self._values.get("repository_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def repository_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) repositoryName property.

            Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("repository_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_commit_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceCommitId property.

            Specify an array of string values to match this event if the actual value of sourceCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_commit_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeCommitRepositoryStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RepositoryEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codecommit.events.RepositoryEvents",
):
    '''(experimental) EventBridge event patterns for Repository.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codecommit import events as codecommit_events
        from aws_cdk.interfaces import aws_codecommit as interfaces_codecommit
        
        # repository_ref: interfaces_codecommit.IRepositoryRef
        
        repository_events = codecommit_events.RepositoryEvents.from_repository(repository_ref)
    '''

    @jsii.member(jsii_name="fromRepository")
    @builtins.classmethod
    def from_repository(
        cls,
        repository_ref: "_aws_cdk_interfaces_aws_codecommit_ceddda9d.IRepositoryRef",
    ) -> "RepositoryEvents":
        '''(experimental) Create RepositoryEvents from a Repository reference.

        :param repository_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6560e34dfd253e278bdb61eeb92735634ce46d1d78d62a7b2176036a11ef713a)
            check_type(argname="argument repository_ref", value=repository_ref, expected_type=type_hints["repository_ref"])
        return typing.cast("RepositoryEvents", jsii.sinvoke(cls, "fromRepository", [repository_ref]))

    @jsii.member(jsii_name="codeCommitCommentOnCommitPattern")
    def code_commit_comment_on_commit_pattern(
        self,
        *,
        after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Repository CodeCommit Comment on Commit.

        :param after_commit_id: (experimental) afterCommitId property. Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param before_commit_id: (experimental) beforeCommitId property. Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param comment_id: (experimental) commentId property. Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param in_reply_to: (experimental) inReplyTo property. Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
        :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeCommitCommentOnCommit.CodeCommitCommentOnCommitProps(
            after_commit_id=after_commit_id,
            before_commit_id=before_commit_id,
            caller_user_arn=caller_user_arn,
            comment_id=comment_id,
            event=event,
            event_metadata=event_metadata,
            in_reply_to=in_reply_to,
            notification_body=notification_body,
            repository_id=repository_id,
            repository_name=repository_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "codeCommitCommentOnCommitPattern", [options]))

    @jsii.member(jsii_name="codeCommitCommentOnPullRequestPattern")
    def code_commit_comment_on_pull_request_pattern(
        self,
        *,
        after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
        pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Repository CodeCommit Comment on Pull Request.

        :param after_commit_id: (experimental) afterCommitId property. Specify an array of string values to match this event if the actual value of afterCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param before_commit_id: (experimental) beforeCommitId property. Specify an array of string values to match this event if the actual value of beforeCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param comment_id: (experimental) commentId property. Specify an array of string values to match this event if the actual value of commentId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param in_reply_to: (experimental) inReplyTo property. Specify an array of string values to match this event if the actual value of inReplyTo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_body: (experimental) notificationBody property. Specify an array of string values to match this event if the actual value of notificationBody is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pull_request_id: (experimental) pullRequestId property. Specify an array of string values to match this event if the actual value of pullRequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
        :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeCommitCommentOnPullRequest.CodeCommitCommentOnPullRequestProps(
            after_commit_id=after_commit_id,
            before_commit_id=before_commit_id,
            caller_user_arn=caller_user_arn,
            comment_id=comment_id,
            event=event,
            event_metadata=event_metadata,
            in_reply_to=in_reply_to,
            notification_body=notification_body,
            pull_request_id=pull_request_id,
            repository_id=repository_id,
            repository_name=repository_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "codeCommitCommentOnPullRequestPattern", [options]))

    @jsii.member(jsii_name="codeCommitRepositoryStateChangePattern")
    def code_commit_repository_state_change_pattern(
        self,
        *,
        base_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        conflict_detail_level: typing.Optional[typing.Sequence[builtins.str]] = None,
        conflict_details_level: typing.Optional[typing.Sequence[builtins.str]] = None,
        conflict_resolution_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
        old_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_full_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        reference_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Repository CodeCommit Repository State Change.

        :param base_commit_id: (experimental) baseCommitId property. Specify an array of string values to match this event if the actual value of baseCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param caller_user_arn: (experimental) callerUserArn property. Specify an array of string values to match this event if the actual value of callerUserArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param commit_id: (experimental) commitId property. Specify an array of string values to match this event if the actual value of commitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param conflict_detail_level: (experimental) conflictDetailLevel property. Specify an array of string values to match this event if the actual value of conflictDetailLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param conflict_details_level: (experimental) conflictDetailsLevel property. Specify an array of string values to match this event if the actual value of conflictDetailsLevel is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param conflict_resolution_strategy: (experimental) conflictResolutionStrategy property. Specify an array of string values to match this event if the actual value of conflictResolutionStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination_commit_id: (experimental) destinationCommitId property. Specify an array of string values to match this event if the actual value of destinationCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event: (experimental) event property. Specify an array of string values to match this event if the actual value of event is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param merge_option: (experimental) mergeOption property. Specify an array of string values to match this event if the actual value of mergeOption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param old_commit_id: (experimental) oldCommitId property. Specify an array of string values to match this event if the actual value of oldCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_full_name: (experimental) referenceFullName property. Specify an array of string values to match this event if the actual value of referenceFullName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_name: (experimental) referenceName property. Specify an array of string values to match this event if the actual value of referenceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reference_type: (experimental) referenceType property. Specify an array of string values to match this event if the actual value of referenceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param repository_id: (experimental) repositoryId property. Specify an array of string values to match this event if the actual value of repositoryId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Repository reference
        :param repository_name: (experimental) repositoryName property. Specify an array of string values to match this event if the actual value of repositoryName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_commit_id: (experimental) sourceCommitId property. Specify an array of string values to match this event if the actual value of sourceCommitId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeCommitRepositoryStateChange.CodeCommitRepositoryStateChangeProps(
            base_commit_id=base_commit_id,
            caller_user_arn=caller_user_arn,
            commit_id=commit_id,
            conflict_detail_level=conflict_detail_level,
            conflict_details_level=conflict_details_level,
            conflict_resolution_strategy=conflict_resolution_strategy,
            destination_commit_id=destination_commit_id,
            event=event,
            event_metadata=event_metadata,
            merge_option=merge_option,
            old_commit_id=old_commit_id,
            reference_full_name=reference_full_name,
            reference_name=reference_name,
            reference_type=reference_type,
            repository_id=repository_id,
            repository_name=repository_name,
            source_commit_id=source_commit_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "codeCommitRepositoryStateChangePattern", [options]))


__all__ = [
    "AWSAPICallViaCloudTrail",
    "CodeCommitApprovalRuleTemplateChange",
    "CodeCommitCommentOnCommit",
    "CodeCommitCommentOnPullRequest",
    "CodeCommitPullRequestStateChange",
    "CodeCommitRepositoryStateChange",
    "RepositoryEvents",
]

publication.publish()

def _typecheckingstub__f984782d4e528f36d9cb78a2ccb3e2152d4d5c0df846df436441aeeeada7e998(
    *,
    additional_event_data: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.AdditionalEventData, typing.Dict[builtins.str, typing.Any]]] = None,
    api_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RequestParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    resources: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.AwsapiCallViaCloudTrailItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    response_elements: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResponseElements, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9964a0826ec1356fccfc5e6444367b4ae9c989729650f71db1aecc94359275df(
    *,
    capabilities: typing.Optional[typing.Sequence[builtins.str]] = None,
    clone: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_transferred: typing.Optional[typing.Sequence[builtins.str]] = None,
    protocol: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    shallow: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71f9b13a44eddbce04778aa75b9b721afe01e9ad8f710d1e5d3d0ff71d2a1a1c(
    *,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__127a2eb8542e01a5b03de95bb9add9598a8737f81728d81b2c491e886087d870(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9208bd5fca2f7241cc72d771eb3d25ee44293f8cd0c638dab091316b2a74767a(
    *,
    author_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    client_request_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    content: typing.Optional[typing.Sequence[builtins.str]] = None,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    deleted: typing.Optional[typing.Sequence[builtins.str]] = None,
    in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8474d8349c56e8807e369d7c2abc9c682199e1cb443b4b2bc0508e6e450e92b3(
    *,
    branch_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5f32fe3be5564b5f5ef6f6912226cd7e27798d5c4ecac713853e2881a147577b(
    *,
    file_path: typing.Optional[typing.Sequence[builtins.str]] = None,
    file_position: typing.Optional[typing.Sequence[builtins.str]] = None,
    relative_file_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c98d2d025e52776dcb533688e09a4ef9690565c6c9be4278cc4a0ebf7c33f5d3(
    *,
    is_merged: typing.Optional[typing.Sequence[builtins.str]] = None,
    merge_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    merged_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c3191296fe39464dcecc91f94433dd896230873550018a947153f857fc2263f4(
    *,
    approval_rules: typing.Optional[typing.Sequence[typing.Any]] = None,
    author_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    client_request_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_activity_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_targets: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.PullRequestItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    revision_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    title: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6970327454568d765ea211f9e9516923118aa21d5bf344d80927ca9f2d22ae61(
    *,
    destination_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
    merge_base: typing.Optional[typing.Sequence[builtins.str]] = None,
    merge_metadata: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.MergeMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89e03bde2b3b44f062515c74412268f847f58d87f71974cc0a95e41ee918e8b8(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    clone_url_http: typing.Optional[typing.Sequence[builtins.str]] = None,
    clone_url_ssh: typing.Optional[typing.Sequence[builtins.str]] = None,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b2314af512fad0db151764f3c8bb72a40766833d0d52a4a01222aa57dae7c063(
    *,
    after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    approval_rule_template_content: typing.Optional[typing.Sequence[builtins.str]] = None,
    approval_rule_template_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    approval_rule_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    approval_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    archive_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    branch_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    client_request_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    commit_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    commit_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    conflict_detail_level: typing.Optional[typing.Sequence[builtins.str]] = None,
    conflict_resolution_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
    content: typing.Optional[typing.Sequence[builtins.str]] = None,
    default_branch_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    delete_files: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination_commit_specifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    file_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
    file_path: typing.Optional[typing.Sequence[builtins.str]] = None,
    file_paths: typing.Optional[typing.Sequence[builtins.str]] = None,
    in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
    keep_empty_folders: typing.Optional[typing.Sequence[builtins.str]] = None,
    location: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Location, typing.Dict[builtins.str, typing.Any]]] = None,
    max_conflict_files: typing.Optional[typing.Sequence[builtins.str]] = None,
    max_merge_hunks: typing.Optional[typing.Sequence[builtins.str]] = None,
    merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    new_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    old_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    parent_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    put_files: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    references: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem1, typing.Dict[builtins.str, typing.Any]]]] = None,
    repository_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    revision_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_commit_specifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    tag_keys: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    target_branch: typing.Optional[typing.Sequence[builtins.str]] = None,
    targets: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem2, typing.Dict[builtins.str, typing.Any]]]] = None,
    throw_if_closed: typing.Optional[typing.Sequence[builtins.str]] = None,
    title: typing.Optional[typing.Sequence[builtins.str]] = None,
    upload_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a13e76a5541ad88bdc180dee0c556d541f5d5c7ad6b5ffbb8ae33ff5f4b8f9f(
    *,
    file_path: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4f90bf3683895791d63886f2b90a3e4e8acf4b5b899c25c04b1b0e3e4b6849b(
    *,
    commit: typing.Optional[typing.Sequence[builtins.str]] = None,
    ref: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6fc96e99922494b0f536d5f6fbe4e2814856395dceb18780b8bb20d46b7fafc3(
    *,
    destination_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03243e58e20151253f3c9055a2989503e28716ec743550a9ff74c4ca67db6c3f(
    *,
    after_blob_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    before_blob_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    blob_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    comment: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Comment, typing.Dict[builtins.str, typing.Any]]] = None,
    commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    deleted_branch: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.DeletedBranch, typing.Dict[builtins.str, typing.Any]]] = None,
    file_path: typing.Optional[typing.Sequence[builtins.str]] = None,
    files_added: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.ResponseElementsItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    files_deleted: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.ResponseElementsItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    files_updated: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.ResponseElementsItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    location: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Location, typing.Dict[builtins.str, typing.Any]]] = None,
    pull_request: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.PullRequest, typing.Dict[builtins.str, typing.Any]]] = None,
    pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_metadata: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RepositoryMetadata, typing.Dict[builtins.str, typing.Any]]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    tree_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    upload_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c4e9f6149221d13ff927e82a403d817e654f4bb1b4f7e2a8f8aac35affc34eb(
    *,
    absolute_path: typing.Optional[typing.Sequence[builtins.str]] = None,
    blob_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    file_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9986bd3be0726431712d2d0b18c687d056163f7e42a9e01a11fff9a2fd09e45a(
    *,
    attributes: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    session_issuer: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionIssuer, typing.Dict[builtins.str, typing.Any]]] = None,
    web_id_federation_data: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37e0f57c058b3af2d18aa2d9ee905931f65d05cec200aac03f1698875b6ac94c(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__10a9642cb1969787274208558aa5a7e046214586136c831f9333624df923f5f1(
    *,
    access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_context: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionContext, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6d3f710da01300a13042824313398ba188e15c80f9ed31d7219b30aa41788823(
    *,
    approval_rule_template_content_sha256: typing.Optional[typing.Sequence[builtins.str]] = None,
    approval_rule_template_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    approval_rule_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
    repositories: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dfd880ea12a52439268251c55b2545ad3d236639d6034b4a27bd4ec37941ea78(
    *,
    after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
    notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b42e0ec4e0a8f5d279250cd6a35ac3709654b23b6b369533e7039d9b310e4de5(
    *,
    after_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    before_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    comment_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    in_reply_to: typing.Optional[typing.Sequence[builtins.str]] = None,
    notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a692d15914d83c62461b89685c3c6cbd90b007289112493b568456c482df67e(
    *,
    approval_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    author: typing.Optional[typing.Sequence[builtins.str]] = None,
    caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    is_merged: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_modified_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
    notification_body: typing.Optional[typing.Sequence[builtins.str]] = None,
    override_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    pull_request_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_names: typing.Optional[typing.Sequence[builtins.str]] = None,
    revision_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_commit: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_reference: typing.Optional[typing.Sequence[builtins.str]] = None,
    title: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d66243ecdc6a79c0519788e11c4a60443a8ceae5fa3be3cd35b58944d1170d5d(
    *,
    base_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    caller_user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    conflict_detail_level: typing.Optional[typing.Sequence[builtins.str]] = None,
    conflict_details_level: typing.Optional[typing.Sequence[builtins.str]] = None,
    conflict_resolution_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    merge_option: typing.Optional[typing.Sequence[builtins.str]] = None,
    old_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_full_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    reference_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    repository_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_commit_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6560e34dfd253e278bdb61eeb92735634ce46d1d78d62a7b2176036a11ef713a(
    repository_ref: _aws_cdk_interfaces_aws_codecommit_ceddda9d.IRepositoryRef,
) -> None:
    """Type checking stubs"""
    pass
