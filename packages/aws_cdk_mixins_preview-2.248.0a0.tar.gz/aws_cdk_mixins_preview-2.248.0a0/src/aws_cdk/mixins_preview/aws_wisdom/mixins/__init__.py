from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnAssistantEventLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogs",
):
    '''Builder for CfnAssistantLogsMixin to generate EVENT_LOGS for CfnAssistant.

    :cloudformationResource: AWS::Wisdom::Assistant
    :logType: EVENT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_wisdom import mixins as wisdom_mixins
        
        cfn_assistant_event_logs = wisdom_mixins.CfnAssistantEventLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnAssistantEventLogsRecordFields"]] = None,
    ) -> "CfnAssistantLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__45f39fc2906273adea0d8c864002ec5e0a69716942448f846b0821400d770eaa)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnAssistantEventLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnAssistantLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnAssistantEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAssistantEventLogsRecordFields"]] = None,
    ) -> "CfnAssistantLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0be1ec0cdb72cb1c75dd57fb48a570af82b8a72a1550eda9d8873197f890ad0d)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnAssistantEventLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnAssistantLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnAssistantEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAssistantEventLogsRecordFields"]] = None,
    ) -> "CfnAssistantLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__edce08554f08839ee68a5f2d43c3e32707efd6317fb88d0d35b7752eb2003445)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnAssistantEventLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnAssistantLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnAssistantEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAssistantEventLogsRecordFields"]] = None,
    ) -> "CfnAssistantLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__40a28785ffe00f875cd2df2705cf80706365f5ebd09b9b4e6dff83a576301ae7)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnAssistantEventLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnAssistantLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnAssistantEventLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnAssistantEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_wisdom import mixins as wisdom_mixins
            
            cfn_assistant_event_logs_dest_props = wisdom_mixins.CfnAssistantEventLogsDestProps(
                record_fields=[wisdom_mixins.CfnAssistantEventLogsRecordFields.ASSISTANT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b527a579ceac40e430f8bf82997fc9ea8d35d8c96b4a0ab4e21b82caa66d11b)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAssistantEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAssistantEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAssistantEventLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnAssistantEventLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnAssistantEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAssistantEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_wisdom import mixins as wisdom_mixins
            
            cfn_assistant_event_logs_firehose_props = wisdom_mixins.CfnAssistantEventLogsFirehoseProps(
                output_format=wisdom_mixins.CfnAssistantEventLogsOutputFormat.Firehose.JSON,
                record_fields=[wisdom_mixins.CfnAssistantEventLogsRecordFields.ASSISTANT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0b30274decbb723b68518b231ae328ac875c6a35ce0a1cae06f1e23c45f736d7)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAssistantEventLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAssistantEventLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAssistantEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAssistantEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAssistantEventLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnAssistantEventLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnAssistantEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAssistantEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_wisdom import mixins as wisdom_mixins
            
            cfn_assistant_event_logs_log_group_props = wisdom_mixins.CfnAssistantEventLogsLogGroupProps(
                output_format=wisdom_mixins.CfnAssistantEventLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[wisdom_mixins.CfnAssistantEventLogsRecordFields.ASSISTANT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39b98f5fb2839143e10890045ecaf866517ffba5b033bb2593d4b82b16c85084)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnAssistantEventLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAssistantEventLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAssistantEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAssistantEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAssistantEventLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnAssistantEventLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnAssistantEventLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_wisdom import mixins as wisdom_mixins
        
        cfn_assistant_event_logs_output_format = wisdom_mixins.CfnAssistantEventLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsRecordFields"
)
class CfnAssistantEventLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    ASSISTANT_ID = "ASSISTANT_ID"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    EVENT_TYPE = "EVENT_TYPE"
    '''
    :stability: experimental
    '''
    SESSION_ID = "SESSION_ID"
    '''
    :stability: experimental
    '''
    SESSION_NAME = "SESSION_NAME"
    '''
    :stability: experimental
    '''
    RECOMMENDATION_ID = "RECOMMENDATION_ID"
    '''
    :stability: experimental
    '''
    RECOMMENDATION = "RECOMMENDATION"
    '''
    :stability: experimental
    '''
    IS_RECOMMENDATION_USEFUL = "IS_RECOMMENDATION_USEFUL"
    '''
    :stability: experimental
    '''
    RELEVANCE_SCORE = "RELEVANCE_SCORE"
    '''
    :stability: experimental
    '''
    RECOMMENDATION_TITLE = "RECOMMENDATION_TITLE"
    '''
    :stability: experimental
    '''
    RECOMMENDATION_SOURCES = "RECOMMENDATION_SOURCES"
    '''
    :stability: experimental
    '''
    INTENT_ID = "INTENT_ID"
    '''
    :stability: experimental
    '''
    INTENT = "INTENT"
    '''
    :stability: experimental
    '''
    INTENT_CLICKED = "INTENT_CLICKED"
    '''
    :stability: experimental
    '''
    UTTERANCE = "UTTERANCE"
    '''
    :stability: experimental
    '''
    PROMPT = "PROMPT"
    '''
    :stability: experimental
    '''
    RESPONSE = "RESPONSE"
    '''
    :stability: experimental
    '''
    SESSION_EVENT_ID = "SESSION_EVENT_ID"
    '''
    :stability: experimental
    '''
    SESSION_EVENT_IDS = "SESSION_EVENT_IDS"
    '''
    :stability: experimental
    '''
    ISSUE_PROBABILITY = "ISSUE_PROBABILITY"
    '''
    :stability: experimental
    '''
    IS_VALID_TRIGGER = "IS_VALID_TRIGGER"
    '''
    :stability: experimental
    '''
    PROMPT_TYPE = "PROMPT_TYPE"
    '''
    :stability: experimental
    '''
    COMPLETION = "COMPLETION"
    '''
    :stability: experimental
    '''
    MODEL_ID = "MODEL_ID"
    '''
    :stability: experimental
    '''
    CONNECT_USER_ARN = "CONNECT_USER_ARN"
    '''
    :stability: experimental
    '''
    CONVERSATION_SESSION_DATA = "CONVERSATION_SESSION_DATA"
    '''
    :stability: experimental
    '''
    SESSION_MESSAGE_ID = "SESSION_MESSAGE_ID"
    '''
    :stability: experimental
    '''
    PARSED_RESPONSE = "PARSED_RESPONSE"
    '''
    :stability: experimental
    '''
    ANSWER_ID = "ANSWER_ID"
    '''
    :stability: experimental
    '''
    GENERATION_ID = "GENERATION_ID"
    '''
    :stability: experimental
    '''
    AI_AGENT_ID = "AI_AGENT_ID"
    '''
    :stability: experimental
    '''
    AI_AGENT_NAME = "AI_AGENT_NAME"
    '''
    :stability: experimental
    '''
    AI_GUARDRAIL_ID = "AI_GUARDRAIL_ID"
    '''
    :stability: experimental
    '''
    NAME = "NAME"
    '''
    :stability: experimental
    '''
    AI_GUARDRAIL = "AI_GUARDRAIL"
    '''
    :stability: experimental
    '''
    CONTENT = "CONTENT"
    '''
    :stability: experimental
    '''
    ACTION = "ACTION"
    '''
    :stability: experimental
    '''
    ACTION_REASON = "ACTION_REASON"
    '''
    :stability: experimental
    '''
    OUTPUTS = "OUTPUTS"
    '''
    :stability: experimental
    '''
    ASSESSMENTS = "ASSESSMENTS"
    '''
    :stability: experimental
    '''
    USAGE = "USAGE"
    '''
    :stability: experimental
    '''
    GUARDRAIL_COVERAGE = "GUARDRAIL_COVERAGE"
    '''
    :stability: experimental
    '''
    AI_AGENT_VERSION = "AI_AGENT_VERSION"
    '''
    :stability: experimental
    '''
    GUARDRAIL_BLOCKED = "GUARDRAIL_BLOCKED"
    '''
    :stability: experimental
    '''
    PARTICIPANT = "PARTICIPANT"
    '''
    :stability: experimental
    '''
    VALUES = "VALUES"
    '''
    :stability: experimental
    '''
    ORCHESTRATION_ID = "ORCHESTRATION_ID"
    '''
    :stability: experimental
    '''
    AI_AGENT_ORCHESTRATION_USE_CASE = "AI_AGENT_ORCHESTRATION_USE_CASE"
    '''
    :stability: experimental
    '''
    ORCHESTRATION_ITERATION = "ORCHESTRATION_ITERATION"
    '''
    :stability: experimental
    '''
    ORCHESTRATION_ERROR = "ORCHESTRATION_ERROR"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantEventLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnAssistantEventLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnAssistantEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnAssistantEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_wisdom import mixins as wisdom_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_assistant_event_logs_s3_props = wisdom_mixins.CfnAssistantEventLogsS3Props(
                encryption_key=key_ref,
                output_format=wisdom_mixins.CfnAssistantEventLogsOutputFormat.S3.JSON,
                record_fields=[wisdom_mixins.CfnAssistantEventLogsRecordFields.ASSISTANT_ID]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6ef07c1c3ad836fd2a7dd0a2dcedb55f1d18cb9878a92275d4645fa32578099a)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnAssistantEventLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnAssistantEventLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnAssistantEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnAssistantEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnAssistantEventLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnAssistantLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_wisdom.mixins.CfnAssistantLogsMixin",
):
    '''Specifies an Amazon Connect Wisdom assistant.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-wisdom-assistant.html
    :cloudformationResource: AWS::Wisdom::Assistant
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_wisdom import mixins as wisdom_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_assistant_logs_mixin = wisdom_mixins.CfnAssistantLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Wisdom::Assistant``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0449472693d2fbe600e1725f76b4c3af145009e8dd010b158349d45c42fd265f)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3bd6722602a152a3fc5db4dc9fada43780ef6612cb7661007d0ae6e427d69934)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6498dd1e57078422137442bb580110f368407a455ff4d9ed5e6b8e3f5e476113)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EVENT_LOGS")
    def EVENT_LOGS(cls) -> "CfnAssistantEventLogs":
        return typing.cast("CfnAssistantEventLogs", jsii.sget(cls, "EVENT_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnAssistantEventLogs",
    "CfnAssistantEventLogsDestProps",
    "CfnAssistantEventLogsFirehoseProps",
    "CfnAssistantEventLogsLogGroupProps",
    "CfnAssistantEventLogsOutputFormat",
    "CfnAssistantEventLogsRecordFields",
    "CfnAssistantEventLogsS3Props",
    "CfnAssistantLogsMixin",
]

publication.publish()

def _typecheckingstub__45f39fc2906273adea0d8c864002ec5e0a69716942448f846b0821400d770eaa(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnAssistantEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0be1ec0cdb72cb1c75dd57fb48a570af82b8a72a1550eda9d8873197f890ad0d(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnAssistantEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAssistantEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__edce08554f08839ee68a5f2d43c3e32707efd6317fb88d0d35b7752eb2003445(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnAssistantEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAssistantEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40a28785ffe00f875cd2df2705cf80706365f5ebd09b9b4e6dff83a576301ae7(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnAssistantEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAssistantEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b527a579ceac40e430f8bf82997fc9ea8d35d8c96b4a0ab4e21b82caa66d11b(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnAssistantEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b30274decbb723b68518b231ae328ac875c6a35ce0a1cae06f1e23c45f736d7(
    *,
    output_format: typing.Optional[CfnAssistantEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAssistantEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39b98f5fb2839143e10890045ecaf866517ffba5b033bb2593d4b82b16c85084(
    *,
    output_format: typing.Optional[CfnAssistantEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAssistantEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6ef07c1c3ad836fd2a7dd0a2dcedb55f1d18cb9878a92275d4645fa32578099a(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnAssistantEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnAssistantEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0449472693d2fbe600e1725f76b4c3af145009e8dd010b158349d45c42fd265f(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3bd6722602a152a3fc5db4dc9fada43780ef6612cb7661007d0ae6e427d69934(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6498dd1e57078422137442bb580110f368407a455ff4d9ed5e6b8e3f5e476113(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
