import json
import re

with open('in-batch35.json', 'r', encoding='utf-8') as f:
    claims = json.load(f)

output = []
entity_total = 0

model_patterns = [
    r'\b(?:Claude|GPT-[34567]|Gemini|Llama|Haiku|Sonnet|Opus|Flash|Codex|Grok)\b',
    r'\b(?:ONNX|PyTorch|Candle|TensorFlow|Keras|JAX)\b',
]

library_patterns = [
    r'\b(?:React|Angular|Vue|Svelte|TanStack|TailwindCSS|shadcn|Playwright|Pytest|FastAPI|Axum|NumPy|Pandas)\b',
    r'\b(?:WhatsApp|WebAssembly|WASM|SQLite|PostgreSQL|Redis|Qdrant)\b',
    r'\b(?:RuVector|RuvSense|AETHER|MERIDIAN|Axios|Winston)\b',
]

time_patterns = [
    r'\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\b',
    r'\b(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b',
    r'\b(?:2026|2025|2024|2023)\b',
]

concept_patterns = [
    r'\b(?:CSI|DensePos[e]?|RF tomography|multistatic|pose estimation|signal processing|machine learning|middleware|authentication|rate limiting|caching|API|deployment)\b',
]

for claim in claims:
    claim_id = claim['id']
    text = claim['text']
    entities = []
    seen_surfaces = set()

    all_patterns = [
        ('model_name', model_patterns),
        ('library_name', library_patterns),
        ('time_expression', time_patterns),
        ('concept', concept_patterns),
    ]

    for kind, pats in all_patterns:
        if len(entities) >= 8:
            break
        for pattern in pats:
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                if len(entities) >= 8:
                    break
                surface = match.group(0)
                key = surface.lower()
                if key not in seen_surfaces:
                    skip = any(c in surface for c in ['://', '\\', '/', '@', '192.', '10.', '172.'])
                    if not skip:
                        entities.append({'kind': kind, 'surface_form': surface})
                        seen_surfaces.add(key)
                        entity_total += 1

    output.append({'id': claim_id, 'entities': entities[:8]})

with open('out-batch35.json', 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)

print("done: %d claims, %d entities" % (len(output), entity_total))
