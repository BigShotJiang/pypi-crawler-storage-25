import os
import subprocess
from pathlib import Path
from typing import Annotated

import typer
from pl_mocks_and_fakes import MockInUnitTests, MockReason
from pl_run_program import (
    SimpleProgramError,
    run_simple_program,
)
from pl_tiny_clients.git_push import git_push
from pl_user_io.display import display
from pl_user_io.task import task
from pl_user_io.yes_no import yes_no

from pl_ci_cd._constants import GIT_PROGRAM

MAIN_BRANCH = "main"
GIT_CREDENTIALS = Path.home() / ".git-credentials"

app = typer.Typer()


@MockInUnitTests(MockReason.UNMITIGATED_SIDE_EFFECT)
def git_credentials_present() -> bool:
    return GIT_CREDENTIALS.exists()  # pragma: no cover


@app.callback()
def ship(  # pragma: no cover
    ctx: typer.Context,
    worktree: Annotated[Path | None, typer.Option()] = None,
    repo_dir: Annotated[Path | None, typer.Option()] = None,
) -> None:
    if repo_dir is None:
        repo_dir = Path.cwd()
    ctx.obj = (worktree, repo_dir)


def _validate_ship_dir(repo_dir: Path) -> tuple[Path, Path, Path]:
    test_script = repo_dir / ".ship" / "test"
    deploy_script = repo_dir / ".ship" / "deploy"
    manual_file = repo_dir / ".ship" / "manual.txt"
    if not test_script.exists():
        msg = f"Missing {test_script}"
        raise RuntimeError(msg)
    if not deploy_script.exists():
        msg = f"Missing {deploy_script}"
        raise RuntimeError(msg)
    if not manual_file.exists():
        msg = f"Missing {manual_file}"
        raise RuntimeError(msg)
    return test_script, deploy_script, manual_file


@app.command("verify")
def verify_cmd(ctx: typer.Context) -> None:  # pragma: no cover
    worktree, repo_dir = ctx.obj
    verify(repo_dir, worktree)


@app.command("deploy")
def deploy_cmd(ctx: typer.Context) -> None:  # pragma: no cover
    worktree, repo_dir = ctx.obj
    deploy(repo_dir, worktree)


def verify(
    repo_dir: Path,
    worktree: Path | None = None,
) -> None:
    test_script, _deploy_script, _manual_file = _validate_ship_dir(repo_dir)

    if worktree is not None:
        _ship_worktree(worktree, repo_dir, test_script, None, verify=True)
    else:
        _ship_main(repo_dir, test_script, None, verify=True)

    display(
        "Verified. Tell the user to run `ship deploy` to finish deployment. "
        "If they reject, make edits and continue using `ship verify`."
    )


def deploy(
    repo_dir: Path,
    worktree: Path | None = None,
) -> None:
    if not git_credentials_present():
        msg = f"Missing {GIT_CREDENTIALS}"
        raise RuntimeError(msg)
    if worktree is not None and _is_mid_rebase(worktree):
        msg = "Rebase conflict. Resolve conflicts and run `ship verify` first."
        raise RuntimeError(msg)
    test_script, deploy_script, manual_file = _validate_ship_dir(repo_dir)
    manual_checks = manual_file.read_text().strip()

    if worktree is not None:
        _ship_worktree(worktree, repo_dir, test_script, manual_checks, verify=False)
    else:
        _ship_main(repo_dir, test_script, manual_checks, verify=False)

    display("Pushing...")
    git_push()

    display(f"Deploying ({deploy_script})...")
    _run_deploy(deploy_script, repo_dir)

    display("Shipped.")


def _require_changes(repo_dir: Path) -> None:
    if not _git(repo_dir, "status", "--porcelain").strip():
        msg = f"Repository at {repo_dir} has no changes to ship."
        raise RuntimeError(msg)


def _ship_main(
    repo_dir: Path, ci_script: Path, manual_checks: str | None, verify: bool
) -> None:
    _require_changes(repo_dir)

    display(f"Running CI ({ci_script})...")
    _run_ci(ci_script, repo_dir)

    if manual_checks is not None and not _run_manual_checks(manual_checks):
        msg = "Manual checks failed."
        raise RuntimeError(msg)

    if verify:
        return

    display("Committing changes...")
    _git(repo_dir, "add", "-A")
    _git(repo_dir, "commit", "-m", "Commit")


def _is_mid_rebase(worktree: Path) -> bool:
    git_dir = Path(_git(worktree, "rev-parse", "--git-dir").strip())
    return (git_dir / "rebase-merge").is_dir() or (git_dir / "rebase-apply").is_dir()


def _resume_rebase(worktree: Path) -> None:
    display("Resuming rebase...")
    try:
        _git(worktree, "diff", "--check")
    except SimpleProgramError:
        _git(worktree, "rebase", "--abort")
        msg = "Conflict markers remain; rebase aborted."
        raise RuntimeError(msg) from None
    _git(worktree, "add", "-A")
    _git(worktree, "-c", "core.editor=/bin/true", "rebase", "--continue")


def _commit_and_rebase(worktree: Path, repo_dir: Path) -> None:
    if _git(repo_dir, "status", "--porcelain").strip():
        msg = f"Repository at {repo_dir} is dirty. Commit or stash changes first."
        raise RuntimeError(msg)

    if _is_mid_rebase(worktree):
        _resume_rebase(worktree)
    else:
        display("Committing worktree changes...")
        _git(worktree, "add", "-A")
        _git(worktree, "commit", "-m", "Commit")

        display(f"Rebasing onto {MAIN_BRANCH}...")
        try:
            _git(worktree, "rebase", MAIN_BRANCH)
        except SimpleProgramError:
            msg = (
                f"Rebase conflict in {worktree}. "
                "Resolve the conflict markers by editing the affected files. "
                "Do NOT run any git commands — ship will handle staging "
                "and completing the rebase. When done, re-run `ship verify` to resume."
            )
            raise RuntimeError(msg) from None


def _ship_worktree(
    worktree: Path,
    repo_dir: Path,
    ci_script: Path,
    manual_checks: str | None,
    verify: bool,
) -> None:
    _commit_and_rebase(worktree, repo_dir)

    display(f"Running CI ({ci_script})...")
    try:
        _run_ci(ci_script, worktree)
    except RuntimeError:
        _undo_auto_commit(worktree)
        raise

    if manual_checks is not None and not _run_manual_checks(manual_checks):
        _undo_auto_commit(worktree)
        msg = "Manual checks failed."
        raise RuntimeError(msg)

    if verify:
        _undo_auto_commit(worktree)
        return

    _amend_auto_fixes(worktree)

    branch = _git(worktree, "branch", "--show-current").strip()
    display(f"Fast-forward merging {branch} into {MAIN_BRANCH}...")
    _git(repo_dir, "merge", "--ff-only", branch)


def _run_manual_checks(manual_checks: str) -> bool:
    task(f"Perform the following manual checks:\n{manual_checks}")
    return yes_no("Did the manual checks pass?")


def _run_ci(ci_script: Path, cwd: Path) -> None:
    result = subprocess.run(
        [str(ci_script)], cwd=cwd, env=dict(os.environ), check=False
    )
    if result.returncode != 0:
        msg = f"CI failed with return code {result.returncode}."
        raise RuntimeError(msg)


def _run_deploy(deploy_script: Path, cwd: Path) -> None:
    result = subprocess.run(
        [str(deploy_script)], cwd=cwd, env=dict(os.environ), check=False
    )
    if result.returncode != 0:
        msg = f"Deploy failed with return code {result.returncode}."
        raise RuntimeError(msg)


def _amend_auto_fixes(worktree: Path) -> None:
    if _git(worktree, "status", "--porcelain").strip():
        _git(worktree, "add", "-A")
        _git(worktree, "commit", "--amend", "--no-edit")


def _undo_auto_commit(worktree: Path) -> None:
    """Revert ship's own commit so the agent's edits remain in the worktree as unstaged changes."""
    _git(worktree, "reset", "--mixed", "HEAD~1")


def _git(cwd: Path, *args: str) -> str:
    return run_simple_program(GIT_PROGRAM, list(args), cwd=cwd, env=dict(os.environ))


def main() -> None:
    app()  # pragma: no cover
