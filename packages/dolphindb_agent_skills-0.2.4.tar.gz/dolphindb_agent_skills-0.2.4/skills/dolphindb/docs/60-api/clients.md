<!-- Auto-mirrored from upstream `documentation-main/db_distr_comp/clients.md`. Do not edit by hand; regenerate via `scripts/build_from_docs.py`. -->

# 操作手册

本节介绍用于数据库管理的 DolphinDB 客户端的用法和示例。

* Web 集群管理器。基于浏览器的网页版客户端。
* DolphinDB VS Code 插件。
* 基于 JAVA 开发的 GUI 客户端。
* 基于网页的 Jupyter Notebook 客户端。
* 基于命令行的 DolphinDB 终端。

详见以下各节。
