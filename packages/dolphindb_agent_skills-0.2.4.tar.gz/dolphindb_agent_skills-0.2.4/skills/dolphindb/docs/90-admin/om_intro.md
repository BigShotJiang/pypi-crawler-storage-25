<!-- Auto-mirrored from upstream `documentation-main/sys_man/om_intro.md`. Do not edit by hand; regenerate via `scripts/build_from_docs.py`. -->

# 系统运维

本章介绍系统运维相关内容，包括集群管理、任务管理、运维监控和安全与容灾等方面。通过学习这些内容，用户将能够获得有关如何高效、安全且可靠地运行系统的实用指导。

另外，DolphinDB 还提供了更完整的运维手册，可以查看 <https://docs.dolphindb.cn/zh/omc/index.html>
