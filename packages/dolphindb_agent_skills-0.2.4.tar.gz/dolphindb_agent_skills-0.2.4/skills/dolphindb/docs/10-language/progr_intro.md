<!-- Auto-mirrored from upstream `documentation-main/progr/progr_intro.md`. Do not edit by hand; regenerate via `scripts/build_from_docs.py`. -->

# 编程语言

本章节包含以下内容：

* DolphinDB 脚本编程语言。包含了 DolphinDB 编程所需要了解的概念和方法，例如数据类型与数据形式、不同类型的对象、运算符及运算规则、具有
  DolphinDB 特色的编程语句、函数化编程等。DolphinDB 脚本语言大小写敏感，所有标识符（如变量、函数名、类名）及保留字（关键字）严格区分大小写。
* SQL 语句。DolphinDB 充分地兼容 ANSI-92 SQL 语言标准和多个主流 SQL 方言。了解 SQL 关键字在 DolphinDB
  中的具体使用方法能够帮助 SQL 使用者更流畅地体验 DolphinDB。
