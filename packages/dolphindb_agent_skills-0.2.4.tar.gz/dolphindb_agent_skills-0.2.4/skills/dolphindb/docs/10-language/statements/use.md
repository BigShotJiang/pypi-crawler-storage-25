<!-- Auto-mirrored from upstream `documentation-main/progr/statements/use.md`. Do not edit by hand; regenerate via `scripts/build_from_docs.py`. -->

# use

要使用一个模块，在模块名前加上"use"关键字。

```
use example::ch9
```

使用 *use* 语句可以调用定义在该模块中的函数。由于不同的模块可以定义相同名字的函数，通过以下规则来区分同名的函数调用：

* 通过模块命名空间区分函数名。

  + 引用定义在该命名空间的函数。
  + 所有DolphinDB内置函数定义在根模块::下。例如，::add(3,4)指的是根模块下的add函数。
* 未指明模块命名空间。

  + 如果当前模块定义了被调用的函数，那么该调用指向当前模块中的函数。
  + 如果只有一个已导入的模块中含有被调用的函数，那么该调用指向这个已导入模块中的函数。
  + 如果超过一个以上的已导入模块都包含了被调用的函数，则抛出异常。
  + 如果导入的模块中不包含被调用的函数，搜索根命名空间。如果在根命名空间也没有找到被调用的函数，抛出异常。

2.00.12 版本前，use 语句仅支持调用 .dos 文件；2.00.12 及之后版本，use 语句支持调用 .dos 文件或 .dom 文件。

注意：

* 若查找目录下存在同名的 .dos 和 .dom 文件，则优先读取 .dos文件。
* 若要加载的 .dom 文件有依赖其他的文件，则会一并加载。
* 若要更新已使用 use 加载的 .dom 文件或 .dos 文件，则需要先调用 clearCachedModules 函数清除缓存。
* 若在 server 初始化时已使用 loadModule 加载 .dom文件或 .dos文件，则启动后再使用 use 加载同名文件将不生效。

自 3.00.0 版本起，支持通过 use 语句切换当前 catalog。使用时，须在 use
后加上“CATALOG”或“catalog”关键字。

```
use CATALOG catalog1
```

相关信息：module
