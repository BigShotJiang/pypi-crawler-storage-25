<!-- Auto-mirrored from upstream `documentation-main/progr/sql/exec.md`. Do not edit by hand; regenerate via `scripts/build_from_docs.py`. -->

# exec

select子句总是生成一张表，即使只选择一列亦是如此。若需要生成一个标量或者一个向量，可使用exec子句。

当与pivot by 共同使用时，exec语句生成一个矩阵，详情参考 pivotBy。

## 例子

```
sym = `C`MS`MS`MS`IBM`IBM`C`C`C$SYMBOL
price= 49.6 29.46 29.52 30.02 174.97 175.23 50.76 50.32 51.29
qty = 2200 1900 2100 3200 6800 5400 1300 2500 8800
timestamp = [09:34:07,09:36:42,09:36:51,09:36:59,09:32:47,09:35:26,09:34:16,09:34:26,09:38:12]
t1 = table(timestamp, sym, qty, price);
t1;
```

| timestamp | sym | qty | price |
| --- | --- | --- | --- |
| 09:34:07 | C | 2200 | 49.6 |
| 09:36:42 | MS | 1900 | 29.46 |
| 09:36:51 | MS | 2100 | 29.52 |
| 09:36:59 | MS | 3200 | 30.02 |
| 09:32:47 | IBM | 6800 | 174.97 |
| 09:35:26 | IBM | 5400 | 175.23 |
| 09:34:16 | C | 1300 | 50.76 |
| 09:34:26 | C | 2500 | 50.32 |
| 09:38:12 | C | 8800 | 51.29 |

```
x = select count(price) from t1;
x;
```

| count\_price |
| --- |
| 9 |

```
typestr x;

TABLE

y = exec count(price) from t1;
y;

9

typestr y;

INT

x = select price from t1;
x;
```

| price |
| --- |
| 49.6 |
| 29.46 |
| 29.52 |
| 30.02 |
| 174.97 |
| 175.23 |
| 50.76 |
| 50.32 |
| 51.29 |

```
typestr x;

TABLE
```

```
y = exec price from t1;
y;

[49.6,29.46,29.52,30.02,174.97,175.23,50.76,50.32,51.29]

typestr y;

FAST DOUBLE VECTOR
```

如果exec语句选择了多列，那么结果和select语句一致，为table类型。

```
y = exec price, qty from t1;
y;
```

| price | qty |
| --- | --- |
| 49.6 | 2200 |
| 29.46 | 1900 |
| 29.52 | 2100 |
| 30.02 | 3200 |
| 174.97 | 6800 |
| 175.23 | 5400 |
| 50.76 | 1300 |
| 50.32 | 2500 |
| 51.29 | 8800 |

```
typestr y;

TABLE
```
