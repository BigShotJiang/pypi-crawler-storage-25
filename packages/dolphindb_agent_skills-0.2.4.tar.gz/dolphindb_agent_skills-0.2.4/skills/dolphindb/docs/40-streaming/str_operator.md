<!-- Auto-mirrored from upstream `documentation-main/stream/str_operator.md`. Do not edit by hand; regenerate via `scripts/build_from_docs.py`. -->

# 流式计算算子

流计算算子可以分为无状态计算和有状态计算。无状态计算是指对输入数据的流式计算不会涉及到历史数据或历史状态，只与当前最新需要处理的这条数据有关。有状态计算是指对输入数据的流式计算与其历史数据和历史状态有关，涉及到状态保存、增量计算优化、避免相同状态重复计算等问题。

DolphinDB 分别实现了无状态算子、有状态算子。本章将详细展开介绍它们。
