<!-- Auto-mirrored from upstream `documentation-main/stream/str_replay.md`. Do not edit by hand; regenerate via `scripts/build_from_docs.py`. -->

# 历史数据回放

一个量化策略在用于实际交易时，处理实时数据的程序通常为事件驱动。而研发量化策略时，需要使用历史数据进行回测，这时的程序通常不是事件驱动。因此同一个策略需要编写两套代码，不仅耗时而且容易出错。在
DolphinDB 中，用户可将历史数据按照时间顺序以”实时数据”的方式导入流数据表中，这样就可以使用同一套代码进行回测和实盘交易。

DolphinDB 的流数据处理框架采用发布-订阅-消费的模式，数据持续地以流的形式发布给数据订阅者。订阅者收到消息以后，可使用自定义函数或者 DolphinDB
内置流处理引擎对接收的消息完成复杂处理。DolphinDB 流数据接口支持多种语言的 API，包括 C++, C#, Java 和 Python 等。用户可以使用这些 API
来编写更加复杂的处理逻辑，更好地与实际生产环境相结合。

根据输入表到输出表的映射，回放支持 1 对 1，N 对 N，N 对 1 三种回放形式。
