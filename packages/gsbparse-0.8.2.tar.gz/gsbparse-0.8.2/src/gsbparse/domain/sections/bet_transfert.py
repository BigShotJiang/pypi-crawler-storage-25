"""Domain section: Budget estimate deferred-debit transfer (Bet_transfert)."""

from dataclasses import dataclass
from datetime import date
from enum import IntEnum

from gsbparse.domain.sections._base import GsbFileSection


class BetTransfertAccountType(IntEnum):
    """Account type stored in the ``Ty`` attribute of a ``<Bet_transfert>`` element."""

    CASH_ACCOUNT = 0
    PARTIAL_BALANCE = 1

    def __str__(self) -> str:
        """Return a lowercase human-readable label."""
        return self.name.lower().replace("_", " ")


@dataclass(frozen=True)
class BetTransfert(GsbFileSection):
    """A deferred-debit or partial-balance settlement entry.

    Used when a credit-card account (deferred debit) or a partial balance
    is settled against a main bank account.

    Attributes:
        Nb: Unique identifier.
        Dt: Settlement date on the main bank account (nullable).
        Ac: Account identifier (the deferred-debit or partial-balance account).
        Ty: Account type being settled (cash account or partial balance).
        Ra: Account or partial-balance number concerned.
        Rt: Replace a transaction whose date falls in the import search window.
        Dd: Create the debit transaction in the target account.
        Dtb: Month switchover date (day after the statement cutoff) (nullable).
        Mlbd: Force settlement date to the last banking day of the month.
        Pa: Party identifier.
        Pn: Payment method identifier.
        Ca: Category identifier.
        Sca: Sub-category identifier.
        Bu: Budget line identifier.
        Sbu: Sub-budget line identifier.
        CPa: Counter-party identifier.
        CCa: Counter-category identifier.
        CSca: Counter-sub-category identifier.
        CBu: Counter-budget identifier.
        CSbu: Counter-sub-budget identifier.
    """

    Nb: int
    Dt: date | None
    Ac: int
    Ty: BetTransfertAccountType
    Ra: int
    Rt: bool
    Dd: bool
    Dtb: date | None
    Mlbd: bool
    Pa: int
    Pn: int
    Ca: int
    Sca: int
    Bu: int
    Sbu: int
    CPa: int
    CCa: int
    CSca: int
    CBu: int
    CSbu: int
