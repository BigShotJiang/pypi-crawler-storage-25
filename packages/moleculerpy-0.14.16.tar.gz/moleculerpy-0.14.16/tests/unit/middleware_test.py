import asyncio
from unittest.mock import AsyncMock, patch  # Added MagicMock for broker mocks

import pytest
import pytest_asyncio

from moleculerpy.broker import Broker
from moleculerpy.decorators import action, event  # Added import for event
from moleculerpy.middleware import Middleware
from moleculerpy.registry import Action, Event  # Changed import
from moleculerpy.service import Service  # Assuming Service can be imported
from moleculerpy.settings import Settings


# Automatically patch all transit-related operations to avoid network connections
@pytest.fixture(autouse=True)
def mock_transit_operations():
    """
    This fixture automatically patches all transit-related operations for every test.
    It ensures no actual network connections are made during testing.
    """
    with (
        patch("moleculerpy.transit.Transit.connect", new_callable=AsyncMock),
        patch("moleculerpy.transit.Transit.disconnect", new_callable=AsyncMock),
        patch("moleculerpy.transit.Transit.request", new_callable=AsyncMock),
        patch("moleculerpy.transit.Transit.publish", new_callable=AsyncMock),
    ):
        yield


class TestMiddleware(Middleware):
    __test__ = False

    def __init__(self, name="TestMiddleware"):
        self.name = name
        self.called_hooks = []
        self.call_log = []  # For more detailed logging

    # Helper to record hook calls, made synchronous for broader applicability
    def _record_call_sync(self, hook_name, **kwargs):
        entry = {"name": self.name, "hook": hook_name}
        if kwargs.get("broker"):
            entry["broker_id"] = kwargs["broker"].nodeID
        if kwargs.get("service"):
            entry["service_name"] = kwargs["service"].name
        if kwargs.get("action"):
            entry["action_name"] = kwargs["action"].name
        if kwargs.get("event"):
            entry["event_name"] = kwargs["event"].name
        self.called_hooks.append(entry)

    # Asynchronous version for async hooks
    async def _record_call_async(self, hook_name, **kwargs):
        # This can be a simple wrapper or duplicate logic if preferred
        self._record_call_sync(hook_name, **kwargs)

    async def local_action(self, next_handler, action: Action):  # Updated type hint
        await self._record_call_async("local_action", action=action)

        async def wrapped_handler(ctx):
            ctx.params["local_action_touched_by"] = self.name
            self.call_log.append(f"{self.name}: local_action_before_{action.name}")
            res = await next_handler(ctx)
            self.call_log.append(f"{self.name}: local_action_after_{action.name}")
            if isinstance(res, dict) or hasattr(
                res, "__setitem__"
            ):  # Check if it can be a dict or supports item assignment
                res["local_action_processed_by"] = self.name
            return res

        return wrapped_handler

    async def remote_action(self, next_handler, action: Action):  # Updated type hint
        await self._record_call_async("remote_action", action=action)
        # Create a broker instance with transit operations already mocked by fixture
        _ = Broker(id="test-broker-mw")

        async def wrapped_handler(ctx):
            ctx.params["remote_action_touched_by"] = self.name
            self.call_log.append(f"{self.name}: remote_action_before_{action.name}")
            res = await next_handler(ctx)
            self.call_log.append(f"{self.name}: remote_action_after_{action.name}")
            if isinstance(res, dict) or hasattr(res, "__setitem__"):
                res["remote_action_processed_by"] = self.name
            return res

        return wrapped_handler

    async def local_event(self, next_handler, event: Event):  # Updated type hint
        await self._record_call_async("local_event", event=event)

        async def wrapped_handler(ctx):
            if ctx.params is None:
                ctx.params = {}  # Ensure params is a dict
            ctx.params["local_event_touched_by"] = self.name
            self.call_log.append(f"{self.name}: local_event_before_{event.name}")
            await next_handler(ctx)
            self.call_log.append(f"{self.name}: local_event_after_{event.name}")

        return wrapped_handler

    # broker_created is synchronous
    def broker_created(self, broker):
        # Directly append to called_hooks as this method is synchronous
        self._record_call_sync("broker_created", broker=broker)

    async def broker_started(self, broker):
        await self._record_call_async("broker_started", broker=broker)

    async def broker_stopped(self, broker):
        await self._record_call_async("broker_stopped", broker=broker)

    async def service_created(self, service):
        await self._record_call_async("service_created", service=service)

    async def service_started(self, service):
        await self._record_call_async("service_started", service=service)

    async def service_stopped(self, service):
        await self._record_call_async("service_stopped", service=service)

    def reset(self):
        self.called_hooks = []
        self.call_log = []


class SimpleService(Service):
    def __init__(self):
        super().__init__("simple")
        self.last_params = None  # For assertion purposes if needed

    @action()
    async def greet(self, ctx):
        self.last_params = ctx.params.copy()  # Store params for inspection
        greeting = f"Hello, {ctx.params.get('name', 'World')}"
        if ctx.params.get("add_punctuation"):
            greeting += ctx.params["add_punctuation"]
        return {"greeting": greeting, "original_params": ctx.params}

    @action(name="another.action")  # Example of an action with a specific name
    async def another(self, ctx):
        return {"message": "another action called", "params": ctx.params}


class EventService(Service):
    def __init__(self):
        super().__init__("emitter")
        self.event_params_log = []  # Log received params for events

    @event()
    async def user_created(self, ctx):
        # For testing, log params including middleware modifications
        self.event_params_log.append(ctx.params.copy())
        # Event handlers typically don't return values that are processed further up a chain by default

    @event(name="multi.handler.event")
    async def multi_handler_1(self, ctx):
        self.event_params_log.append({"handler": "handler1", "params": ctx.params.copy()})

    @event(name="multi.handler.event")  # Same event name, different handler
    async def multi_handler_2(self, ctx):
        self.event_params_log.append({"handler": "handler2", "params": ctx.params.copy()})


@pytest_asyncio.fixture
async def broker_instance():
    # Transit methods are already mocked by the mock_transit_operations fixture
    broker = Broker(id="test-broker-mw")
    yield broker
    # Manually trigger broker_stopped hooks but bypass the actual transit disconnect
    if hasattr(broker, "middlewares") and broker.middlewares:
        await asyncio.gather(
            *[
                middleware.broker_stopped(broker)
                for middleware in broker.middlewares
                if hasattr(middleware, "broker_stopped") and callable(middleware.broker_stopped)
            ]  # type: ignore
        )  # type: ignore


# This fixture creates a broker with a different ID
# Transit methods are already mocked by the mock_transit_operations fixture
@pytest_asyncio.fixture
async def mocked_broker():
    broker = Broker(id="test-broker-mw-mocked")
    yield broker


def test_broker_registers_middlewares_direct():
    mw1 = TestMiddleware(name="MW1")
    # Mock discoverer to avoid event loop issues
    from unittest.mock import Mock

    mock_discoverer = Mock()
    broker = Broker(id="direct-broker", middlewares=[mw1], discoverer=mock_discoverer)
    assert len(broker.middlewares) == 1
    assert broker.middlewares[0] == mw1
    # Check if broker_created was called (synchronously)
    # mw1.called_hooks should have one entry from broker_created
    assert len(mw1.called_hooks) == 1
    assert mw1.called_hooks[0]["hook"] == "broker_created"
    assert mw1.called_hooks[0]["broker_id"] == "direct-broker"
    assert mw1.called_hooks[0]["name"] == "MW1"


# Test for middleware registration via Settings
def test_broker_registers_middlewares_via_settings():
    mw1 = TestMiddleware(name="MW1_Settings")
    settings = Settings(middlewares=[mw1])
    # Mock discoverer to avoid event loop issues
    from unittest.mock import Mock

    mock_discoverer = Mock()
    broker = Broker(id="settings-broker", settings=settings, discoverer=mock_discoverer)
    assert len(broker.middlewares) == 1
    assert broker.middlewares[0] == mw1
    assert len(mw1.called_hooks) == 1
    assert mw1.called_hooks[0]["hook"] == "broker_created"
    assert mw1.called_hooks[0]["broker_id"] == "settings-broker"
    assert mw1.called_hooks[0]["name"] == "MW1_Settings"


# Basic test to ensure the broker_instance fixture works
@pytest.mark.asyncio
async def test_broker_fixture_works(broker_instance):
    assert broker_instance is not None
    assert broker_instance.nodeID == "test-broker-mw"
    # Perform a basic async operation if needed, e.g., start/stop
    await broker_instance.start()
    await broker_instance.stop()
    # Assertions on middleware calls during start/stop can be added here or in dedicated tests


@pytest.mark.asyncio
async def test_local_action_single_middleware():
    mw1 = TestMiddleware(name="MW1")
    broker = Broker(id="single-mw-broker-local-action", middlewares=[mw1])
    service = SimpleService()
    await broker.register(service)

    # New architecture: middleware hooks are called at registration time, not call time
    # SimpleService has 2 actions (greet, another.action), so local_action is called twice
    local_action_hooks = [h for h in mw1.called_hooks if h["hook"] == "local_action"]
    assert len(local_action_hooks) == 2, "Middleware should wrap both actions at registration"

    # Verify simple.greet was wrapped
    greet_hooks = [h for h in local_action_hooks if h["action_name"] == "simple.greet"]
    assert len(greet_hooks) == 1, "simple.greet should be wrapped"
    assert greet_hooks[0]["name"] == "MW1"

    mw1.call_log.clear()  # Clear any logs before the actual call

    await broker.start()

    ctx_params = {"name": "Tester"}
    result = await broker.call("simple.greet", params=ctx_params.copy())  # Pass a copy

    # Check context modification recorded by SimpleService
    assert service.last_params is not None
    assert service.last_params.get("local_action_touched_by") == "MW1"

    # Check result modification
    assert result.get("greeting") == "Hello, Tester"
    assert result.get("local_action_processed_by") == "MW1"

    # Check call log from middleware (filled during wrapped handler execution)
    assert "MW1: local_action_before_simple.greet" in mw1.call_log
    assert "MW1: local_action_after_simple.greet" in mw1.call_log

    await broker.stop()


@pytest.mark.asyncio
async def test_local_action_multiple_middlewares_chaining():
    mw1 = TestMiddleware(name="MW1")  # MW1 is first in list
    mw2 = TestMiddleware(name="MW2")  # MW2 is second in list

    # Middlewares provided as [mw1, mw2].
    # New architecture: wrapping happens at registration time in reverse order.
    # Effective handler: mw1_wrapped(mw2_wrapped(original_action))
    broker = Broker(id="multi-mw-broker-local-action", middlewares=[mw1, mw2])
    service = SimpleService()
    await broker.register(service)

    # New architecture: local_action hooks are called at registration for ALL actions
    # SimpleService has 2 actions, so each middleware wraps 2 actions
    mw1_local_actions = [h for h in mw1.called_hooks if h["hook"] == "local_action"]
    mw2_local_actions = [h for h in mw2.called_hooks if h["hook"] == "local_action"]
    assert len(mw1_local_actions) == 2, "MW1 should wrap both actions"
    assert len(mw2_local_actions) == 2, "MW2 should wrap both actions"

    # Verify simple.greet was wrapped by both middlewares
    mw1_greet = [h for h in mw1_local_actions if h["action_name"] == "simple.greet"]
    mw2_greet = [h for h in mw2_local_actions if h["action_name"] == "simple.greet"]
    assert len(mw1_greet) == 1, "MW1 should wrap simple.greet"
    assert len(mw2_greet) == 1, "MW2 should wrap simple.greet"

    # Clear call logs before the actual call
    mw1.call_log.clear()
    mw2.call_log.clear()

    await broker.start()

    ctx_params = {"name": "ChainTester", "add_punctuation": "!"}
    result = await broker.call("simple.greet", params=ctx_params.copy())

    # Context modification by TestMiddleware: ctx.params["..._touched_by"] = self.name (overwrites)
    # Execution: mw1_wrapped -> mw2_wrapped -> original_action
    # mw1 sets ctx.params["..._touched_by"] = "MW1"
    # mw2 sets ctx.params["..._touched_by"] = "MW2" (overwrites MW1's)
    # So, the service's action (original_action) will see param set by MW2.
    assert service.last_params is not None
    assert service.last_params.get("local_action_touched_by") == "MW2"

    # Result modification by TestMiddleware: res["..._processed_by"] = self.name (overwrites)
    # Execution: original_action returns -> mw2_wrapped processes result -> mw1_wrapped processes result
    # mw2 sets res["..._processed_by"] = "MW2"
    # mw1 sets res["..._processed_by"] = "MW1" (overwrites MW2's)
    # So, the final result will have the field set by MW1.
    assert result.get("local_action_processed_by") == "MW1"

    # Verify call log order (execution order of logged statements within wrappers)
    assert mw1.call_log[0] == "MW1: local_action_before_simple.greet"  # MW1 outer wrapper - before
    assert mw2.call_log[0] == "MW2: local_action_before_simple.greet"  # MW2 inner wrapper - before
    assert mw2.call_log[1] == "MW2: local_action_after_simple.greet"  # MW2 inner wrapper - after
    assert mw1.call_log[1] == "MW1: local_action_after_simple.greet"  # MW1 outer wrapper - after

    assert result.get("greeting") == "Hello, ChainTester!"

    await broker.stop()


@pytest.mark.asyncio
async def test_remote_action_single_middleware():
    mw1 = TestMiddleware(name="MW1_Remote")
    broker = Broker(id="single-mw-remote-action", middlewares=[mw1])

    remote_action_name = "remote.greet"
    # Create an Action with proper parameters - name, node_id, is_local, handler, params_schema
    action_endpoint = Action(remote_action_name, "remote-node", is_local=False)
    broker.registry.add_action(action_endpoint)

    mw1.reset()
    await broker.start()
    mw1.called_hooks.clear()  # Clear broker_started

    ctx_params = {"name": "RemoteTester"}

    with patch.object(broker.transit, "request", new_callable=AsyncMock) as mock_transit_request:
        mock_transit_request.return_value = {
            "data_from": "remote_mock",
            "original_params": ctx_params.copy(),
        }

        result = await broker.call(remote_action_name, params=ctx_params.copy())

        assert len(mw1.called_hooks) == 1
        hook_call_info = mw1.called_hooks[0]
        assert hook_call_info["hook"] == "remote_action"
        assert hook_call_info["action_name"] == remote_action_name
        assert hook_call_info["name"] == "MW1_Remote"

        mock_transit_request.assert_called_once()
        called_context = mock_transit_request.call_args[0][1]

        assert called_context.params.get("remote_action_touched_by") == "MW1_Remote"
        assert result.get("data_from") == "remote_mock"
        assert result.get("remote_action_processed_by") == "MW1_Remote"

        assert "MW1_Remote: remote_action_before_remote.greet" in mw1.call_log
        assert "MW1_Remote: remote_action_after_remote.greet" in mw1.call_log

    await broker.stop()


@pytest.mark.asyncio
async def test_remote_action_multiple_middlewares_chaining():
    mw1 = TestMiddleware(name="MW1_Remote")
    mw2 = TestMiddleware(name="MW2_Remote")

    broker = Broker(id="multi-mw-remote-action", middlewares=[mw1, mw2])

    remote_action_name = "remote.chained.greet"
    action_endpoint = Action(remote_action_name, "remote-node-c", is_local=False)
    broker.registry.add_action(action_endpoint)

    mw1.reset()
    mw2.reset()
    await broker.start()
    mw1.called_hooks.clear()
    mw2.called_hooks.clear()

    ctx_params = {"name": "RemoteChainTester"}

    with patch.object(broker.transit, "request", new_callable=AsyncMock) as mock_transit_request:
        mock_transit_request.return_value = {
            "data_from": "remote_chain_mock",
            "original_params": ctx_params.copy(),
        }

        result = await broker.call(remote_action_name, params=ctx_params.copy())

        assert len(mw1.called_hooks) == 1, "MW1 remote_action hook should be called"
        assert len(mw2.called_hooks) == 1, "MW2 remote_action hook should be called"
        assert mw1.called_hooks[0]["hook"] == "remote_action"
        assert mw2.called_hooks[0]["hook"] == "remote_action"

        mock_transit_request.assert_called_once()
        called_context = mock_transit_request.call_args[0][1]
        assert called_context.params.get("remote_action_touched_by") == "MW2_Remote"

        assert result.get("remote_action_processed_by") == "MW1_Remote"

        assert mw1.call_log[0] == "MW1_Remote: remote_action_before_remote.chained.greet"
        assert mw2.call_log[0] == "MW2_Remote: remote_action_before_remote.chained.greet"
        assert mw2.call_log[1] == "MW2_Remote: remote_action_after_remote.chained.greet"
        assert mw1.call_log[1] == "MW1_Remote: remote_action_after_remote.chained.greet"

    await broker.stop()


@pytest.mark.asyncio
async def test_local_event_emit_single_middleware():
    mw1 = TestMiddleware(name="MW1_EventEmit")
    broker = Broker(id="emit-single-mw", middlewares=[mw1])
    service = EventService()
    await broker.register(service)  # Registers user_created event

    # New architecture: local_event hooks are called at registration time
    # EventService has 3 event handlers (user_created, multi_handler_1, multi_handler_2)
    local_event_hooks = [h for h in mw1.called_hooks if h["hook"] == "local_event"]
    assert len(local_event_hooks) == 3, "Middleware should wrap all 3 event handlers"

    # Verify user_created was wrapped
    user_created_hooks = [h for h in local_event_hooks if h["event_name"] == "user_created"]
    assert len(user_created_hooks) == 1, "user_created should be wrapped"

    mw1.call_log.clear()  # Clear logs before actual emit

    await broker.start()

    event_params = {"username": "testuser", "id": 1}
    await broker.emit("user_created", params=event_params.copy())

    # Check context modification seen by the event handler
    assert len(service.event_params_log) == 1
    logged_params = service.event_params_log[0]
    assert logged_params.get("local_event_touched_by") == "MW1_EventEmit"

    assert "MW1_EventEmit: local_event_before_user_created" in mw1.call_log
    assert "MW1_EventEmit: local_event_after_user_created" in mw1.call_log

    await broker.stop()


@pytest.mark.asyncio
async def test_local_event_emit_multiple_middlewares_chaining():
    mw1 = TestMiddleware(name="MW1_EventEmitChain")  # Outermost
    mw2 = TestMiddleware(name="MW2_EventEmitChain")  # Inner

    broker = Broker(id="emit-multi-mw", middlewares=[mw1, mw2])
    service = EventService()
    await broker.register(service)

    # New architecture: local_event hooks are called at registration for ALL events
    # EventService has 3 event handlers, so each middleware wraps 3 events
    mw1_local_events = [h for h in mw1.called_hooks if h["hook"] == "local_event"]
    mw2_local_events = [h for h in mw2.called_hooks if h["hook"] == "local_event"]
    assert len(mw1_local_events) == 3, "MW1 should wrap all 3 event handlers"
    assert len(mw2_local_events) == 3, "MW2 should wrap all 3 event handlers"

    # Verify user_created was wrapped by both middlewares
    mw1_user_created = [h for h in mw1_local_events if h["event_name"] == "user_created"]
    mw2_user_created = [h for h in mw2_local_events if h["event_name"] == "user_created"]
    assert len(mw1_user_created) == 1, "MW1 should wrap user_created"
    assert len(mw2_user_created) == 1, "MW2 should wrap user_created"

    # Clear call logs before actual emit
    mw1.call_log.clear()
    mw2.call_log.clear()

    await broker.start()

    event_params = {"username": "chainuser", "id": 2}
    await broker.emit("user_created", params=event_params.copy())

    # Context modification (seen by event handler): MW1 sets, then MW2 overwrites
    assert len(service.event_params_log) == 1
    logged_params = service.event_params_log[0]
    assert logged_params.get("local_event_touched_by") == "MW2_EventEmitChain"

    # Call log order (execution of the wrappers)
    assert mw1.call_log[0] == "MW1_EventEmitChain: local_event_before_user_created"
    assert mw2.call_log[0] == "MW2_EventEmitChain: local_event_before_user_created"
    assert mw2.call_log[1] == "MW2_EventEmitChain: local_event_after_user_created"
    assert mw1.call_log[1] == "MW1_EventEmitChain: local_event_after_user_created"

    await broker.stop()


@pytest.mark.asyncio
async def test_local_event_broadcast_multiple_handlers_and_middlewares():
    mw1 = TestMiddleware(name="MW1_EventBroadcast")  # Outermost
    mw2 = TestMiddleware(name="MW2_EventBroadcast")  # Inner

    broker = Broker(id="broadcast-multi-mw", middlewares=[mw1, mw2])
    service = EventService()  # Has two handlers for "multi.handler.event"
    await broker.register(service)

    # New architecture: local_event hooks are called at registration
    # EventService has 3 event handlers, so each middleware wraps 3 events
    mw1_local_events = [h for h in mw1.called_hooks if h["hook"] == "local_event"]
    mw2_local_events = [h for h in mw2.called_hooks if h["hook"] == "local_event"]
    assert len(mw1_local_events) == 3, "MW1 should wrap all 3 event handlers"
    assert len(mw2_local_events) == 3, "MW2 should wrap all 3 event handlers"

    # Verify multi.handler.event was wrapped (has 2 handlers)
    mw1_multi = [h for h in mw1_local_events if h["event_name"] == "multi.handler.event"]
    mw2_multi = [h for h in mw2_local_events if h["event_name"] == "multi.handler.event"]
    assert len(mw1_multi) == 2, "MW1 should wrap both multi.handler.event handlers"
    assert len(mw2_multi) == 2, "MW2 should wrap both multi.handler.event handlers"

    # Clear call logs before actual broadcast
    mw1.call_log.clear()
    mw2.call_log.clear()

    await broker.start()

    event_params = {"data": "broadcast_data"}
    # Using unprefixed event name
    await broker.broadcast("multi.handler.event", params=event_params.copy())

    # Context modification: Each handler should see context modified by MW2.
    assert len(service.event_params_log) == 2
    for log_entry in service.event_params_log:
        assert log_entry["params"].get("local_event_touched_by") == "MW2_EventBroadcast"

    # Call log: Each middleware's before/after logs will appear twice.
    # Example: MW1_before, MW2_before, MW2_after, MW1_after (for handler1)
    #          MW1_before, MW2_before, MW2_after, MW1_after (for handler2)
    assert mw1.call_log.count("MW1_EventBroadcast: local_event_before_multi.handler.event") == 2
    assert mw2.call_log.count("MW2_EventBroadcast: local_event_before_multi.handler.event") == 2
    assert mw2.call_log.count("MW2_EventBroadcast: local_event_after_multi.handler.event") == 2
    assert mw1.call_log.count("MW1_EventBroadcast: local_event_after_multi.handler.event") == 2

    await broker.stop()


@pytest.mark.asyncio
async def test_broker_created_hook():
    mw1 = TestMiddleware(name="MW_BC_1")
    mw2 = TestMiddleware(name="MW_BC_2")

    mw1.reset()
    mw2.reset()

    _ = Broker(id="broker-created-test", middlewares=[mw1, mw2])

    assert len(mw1.called_hooks) == 1
    hook_info1 = mw1.called_hooks[0]
    assert hook_info1["hook"] == "broker_created"
    assert hook_info1["broker_id"] == "broker-created-test"
    assert hook_info1["name"] == "MW_BC_1"

    assert len(mw2.called_hooks) == 1
    hook_info2 = mw2.called_hooks[0]
    assert hook_info2["hook"] == "broker_created"
    assert hook_info2["broker_id"] == "broker-created-test"
    assert hook_info2["name"] == "MW_BC_2"


@pytest.mark.asyncio
async def test_broker_started_hook():
    mw1 = TestMiddleware(name="MW_BS_1")
    mw2 = TestMiddleware(name="MW_BS_2")
    broker = Broker(id="broker-started-test", middlewares=[mw1, mw2])

    mw1.reset()
    mw2.reset()

    await broker.start()

    assert len(mw1.called_hooks) == 1
    hook_info1 = mw1.called_hooks[0]
    assert hook_info1["hook"] == "broker_started"
    assert hook_info1["broker_id"] == "broker-started-test"
    assert hook_info1["name"] == "MW_BS_1"

    assert len(mw2.called_hooks) == 1
    hook_info2 = mw2.called_hooks[0]
    assert hook_info2["hook"] == "broker_started"
    assert hook_info2["broker_id"] == "broker-started-test"
    assert hook_info2["name"] == "MW_BS_2"

    await broker.stop()


@pytest.mark.asyncio
async def test_broker_started_hook_exception_propagates():
    """broker.start() should fail if a middleware lifecycle hook fails."""

    class FailingStartedMW(Middleware):
        async def broker_started(self, broker):
            raise RuntimeError("broker_started failed")

    broker = Broker(id="broker-started-fail-test", middlewares=[FailingStartedMW()])

    with pytest.raises(RuntimeError, match="broker_started failed"):
        await broker.start()


@pytest.mark.asyncio
async def test_broker_stopped_hook():
    mw1 = TestMiddleware(name="MW_BSP_1")
    mw2 = TestMiddleware(name="MW_BSP_2")
    broker = Broker(id="broker-stopped-test", middlewares=[mw1, mw2])

    await broker.start()
    mw1.reset()
    mw2.reset()

    await broker.stop()

    assert len(mw1.called_hooks) == 1
    hook_info1 = mw1.called_hooks[0]
    assert hook_info1["hook"] == "broker_stopped"
    assert hook_info1["broker_id"] == "broker-stopped-test"
    assert hook_info1["name"] == "MW_BSP_1"

    assert len(mw2.called_hooks) == 1
    hook_info2 = mw2.called_hooks[0]
    assert hook_info2["hook"] == "broker_stopped"
    assert hook_info2["broker_id"] == "broker-stopped-test"
    assert hook_info2["name"] == "MW_BSP_2"


@pytest.mark.asyncio
async def test_service_created_and_started_hooks():
    """Test that service_created is called during register(), and service_started during start().

    NOTE: This behavior was changed to fix a bug where service_started was called
    prematurely during register(), before the broker was connected to the cluster.
    Now service_started is only called during broker.start() after all services
    are registered and the broker is fully connected.

    New architecture: local_action hooks are also called at registration time.
    """
    mw1 = TestMiddleware(name="MW_SC_1")
    mw2 = TestMiddleware(name="MW_SC_2")
    broker = Broker(id="service-hooks-test", middlewares=[mw1, mw2])

    mw1.reset()
    mw2.reset()

    service_to_register = SimpleService()
    await broker.register(service_to_register)

    # After register(): service_created + local_action for each action
    # SimpleService has 2 actions (greet, another.action), so:
    # - 1 service_created
    # - 2 local_action hooks
    service_created_hooks1 = [h for h in mw1.called_hooks if h["hook"] == "service_created"]
    local_action_hooks1 = [h for h in mw1.called_hooks if h["hook"] == "local_action"]

    assert len(service_created_hooks1) == 1, "service_created should be called once"
    assert service_created_hooks1[0]["service_name"] == service_to_register.name
    assert service_created_hooks1[0]["name"] == "MW_SC_1"

    assert len(local_action_hooks1) == 2, "local_action should wrap 2 actions"

    service_created_hooks2 = [h for h in mw2.called_hooks if h["hook"] == "service_created"]
    local_action_hooks2 = [h for h in mw2.called_hooks if h["hook"] == "local_action"]

    assert len(service_created_hooks2) == 1, "service_created should be called once"
    assert service_created_hooks2[0]["service_name"] == service_to_register.name
    assert service_created_hooks2[0]["name"] == "MW_SC_2"

    assert len(local_action_hooks2) == 2, "local_action should wrap 2 actions"

    # Now start the broker - this should call service_started
    mw1.reset()
    mw2.reset()
    await broker.start()

    # After start(), service_started should be called
    started_hooks1 = [h for h in mw1.called_hooks if h["hook"] == "service_started"]
    assert len(started_hooks1) == 1
    assert started_hooks1[0]["service_name"] == service_to_register.name
    assert started_hooks1[0]["name"] == "MW_SC_1"

    started_hooks2 = [h for h in mw2.called_hooks if h["hook"] == "service_started"]
    assert len(started_hooks2) == 1
    assert started_hooks2[0]["service_name"] == service_to_register.name
    assert started_hooks2[0]["name"] == "MW_SC_2"

    await broker.stop()


# Example of a more complex test structure for wrapping hooks (illustrative)
# This would require a dummy service and action
# @pytest.mark.asyncio
# async def test_local_action_middleware_wrapping(broker_instance):
#     mw1 = TestMiddleware(name="LocalActionMW")
#     broker_instance.middlewares = [mw1] # Add middleware to fixture instance

#     # Define a dummy service with an action
#     class DummyService(Service):
#         def __init__(self):
#             super().__init__(name="dummy", broker=broker_instance)
#         @self.action()
#         async def my_action(self, ctx):
#             return {"data": "original_data", "params": ctx.params}

#     dummy_service = DummyService()
#     await broker_instance.register(dummy_service) # Register service

#     # Call the action
#     action_name = "dummy.my_action"
#     params = {"key": "value"}
#     result = await broker_instance.call(action_name, params=params)

#     # Assertions
#     assert len(mw1.called_hooks) > 0 # Check specific hooks if necessary
#     assert {"name": "LocalActionMW", "hook": "local_action", "action_name": "dummy.my_action"} in mw1.called_hooks

#     assert result["local_action_processed_by"] == "LocalActionMW"
#     assert result["params"]["local_action_touched_by"] == "LocalActionMW"
#     assert "LocalActionMW: local_action_before_dummy.my_action" in mw1.call_log
#     assert "LocalActionMW: local_action_after_dummy.my_action" in mw1.call_log
#     assert result["data"] == "original_data"
#     await broker_instance.stop() # Ensure broker is stopped if fixture doesn't handle it fully

# TODO: Add more tests for each hook and interaction
# - broker_started, broker_stopped
# - service_created, service_started (and service_stopped when broker supports it)
# - remote_action (might require mocking Transit)
# - local_event
# - Multiple middlewares and their execution order
# - Middlewares modifying context and results

# Placeholder for Action and Event if not directly available or for simpler testing
# class Action:
#     def __init__(self, name):
#         self.name = name

# class Event:
#     def __init__(self, name):
#         self.name = name

# Make sure to adjust imports for Action/Event based on where they are defined in moleculerpy
# from moleculerpy.registry import ActionEndpoint as Action, EventEndpoint as Event
# Using ActionEndpoint and EventEndpoint as placeholders, adjust if these are not the correct classes.
# The example assumes Action/Event objects have a 'name' attribute.
# If they are just strings (action_name, event_name), then TestMiddleware._record_call needs adjustment.
# Based on Broker code, 'endpoint' objects (ActionEndpoint, EventEndpoint) are passed, which should have a 'name'.
# For instance, in Broker.call:
# handler_to_execute = self._apply_middlewares(endpoint.handler, "local_action", endpoint)
# So, 'endpoint' is the metadata. The hooks in middleware.py are defined as:
# def local_action(self, next_handler, action): -> action is the metadata (endpoint)
# def remote_action(self, next_handler, action): -> action is the metadata (endpoint)
# def local_event(self, next_handler, event): -> event is the metadata (endpoint)
# This seems consistent.
# Final check on broker_created sync nature:
# In Broker.__init__:
# for middleware in self.middlewares:
#     if hasattr(middleware, 'broker_created') and callable(getattr(middleware, 'broker_created')):
#         middleware.broker_created(self)
# This is a direct synchronous call. TestMiddleware.broker_created must be synchronous.
# The provided example code for TestMiddleware.broker_created is:
#         def broker_created(self, broker): # Should be synchronous
#            self.called_hooks.append({"name": self.name, "hook": "broker_created", "broker_id": broker.id})
# This is correct. My _record_call_sync helper also works for this.
# The change to `hasattr(res, '__setitem__')` in local_action/remote_action is to handle cases where `res` might be a Context object or other non-dict mapping.
# Context objects in moleculerpy might not be simple dicts.
# Ensure params in local_event is a dict before modification.
# Corrected imports for Action and Event to ActionEndpoint and EventEndpoint as per moleculerpy.registry.
# The broker_instance fixture is simplified. If tests require a fully started/stopped broker, it should be enhanced.
# The test_broker_registers_middlewares_direct assertion was refined to check the content of called_hooks.
# The test_broker_registers_middlewares_via_settings was also refined.
# Added a basic test for the broker_instance fixture itself.
# Commented out the more complex test_local_action_middleware_wrapping as it's illustrative and depends on more setup.
# Added a note that Context.params should be checked/initialized in local_event if it could be None.
# Made _record_call_sync and _record_call_async to clearly distinguish. broker_created calls the sync one.
# All other async hooks call _record_call_async.
# For wrapping hooks, ensured that if `res` is a dict, it's modified. If it's a Context, it might need specific handling.
# The current moleculerpy.context.Context does not directly support item assignment like a dict for arbitrary keys.
# So, the modification `res["local_action_processed_by"] = self.name` might fail if `res` is a Context object.
# The actions in moleculerpy typically return dicts or basic types, not the Context object itself.
# So, `isinstance(res, dict)` should be sufficient for now.
# The `local_event` handler should ensure `ctx.params` is a dictionary before trying to set a key on it.
# Added this check: `if ctx.params is None: ctx.params = {}`
# The example's Action/Event imports were `from moleculerpy.registry import Action, Event`.
# I've used `from moleculerpy.registry import ActionEndpoint as Action, EventEndpoint as Event`
# This seems more aligned with how endpoints are handled in the broker.
# If `Action` and `Event` are indeed the classes for metadata, then this is correct.
# If the actual metadata objects are different, TestMiddleware will need adjustment.
# The `Broker` code passes `endpoint` as metadata. These are `ActionEndpoint` or `EventEndpoint` instances.
# These endpoints do have a `name` attribute. So this part is fine.
# The `Service` class is used for type hinting, and its import from `moleculerpy.service` is assumed to be correct.
# `Context` from `moleculerpy.context` is also assumed.
# The `broker_instance` fixture is simplified; for tests involving broker start/stop lifecycle hooks,
# it would need to `await broker.start()` and `await broker.stop()` with `yield`.
# The current tests for middleware registration don't require a started broker.
# The test `test_broker_fixture_works` does a basic start/stop.
# Final check of `local_action` and `remote_action`: if `res` is not a dict, the modification is skipped.
# This is reasonable. If a specific test expects modification of non-dict results, the middleware or test needs to be adapted.
# `hasattr(res, '__setitem__')` was an attempt to be more flexible but `isinstance(res, dict)` is safer if action handlers primarily return dicts.
# Reverted to `isinstance(res, dict)` for simplicity as per original example.
