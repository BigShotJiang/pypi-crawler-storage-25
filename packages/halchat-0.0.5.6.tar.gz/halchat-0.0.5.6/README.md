# Официальное HalChat API

[Документация](https://halwarsings-organization.gitbook.io/halchat/halchatpy/)
[HalChat](https://halch.at/)