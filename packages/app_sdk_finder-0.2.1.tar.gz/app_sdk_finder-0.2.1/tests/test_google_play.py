from unittest.mock import patch

from app_sdk_finder.google_play import search_apps


MOCK_GPLAY_RESULTS = [
    {
        "title": "WhatsApp Messenger",
        "appId": "com.whatsapp",
        "developer": "WhatsApp LLC",
        "score": 4.7,
        "installs": "10,000,000,000+",
    },
    {
        "title": "WhatsApp Business",
        "appId": "com.whatsapp.w4b",
        "developer": "WhatsApp LLC",
        "score": 4.6,
        "installs": "1,000,000,000+",
    },
    {
        "title": "Unknown App",
        "appId": None,  # some results have null appId
        "developer": "Unknown",
        "score": None,
        "installs": "0",
    },
]


@patch("app_sdk_finder.google_play.gplay_search")
def test_search_apps_parses_response(mock_search):
    mock_search.return_value = MOCK_GPLAY_RESULTS
    results = search_apps("whatsapp")
    assert len(results) == 2  # filters out None appId
    assert results[0].name == "WhatsApp Messenger"
    assert results[0].store_id == "com.whatsapp"
    assert results[0].developer == "WhatsApp LLC"
    assert results[0].rating == 4.7
    assert results[0].platform == "android"


@patch("app_sdk_finder.google_play.gplay_search")
def test_search_apps_filters_null_appid(mock_search):
    mock_search.return_value = MOCK_GPLAY_RESULTS
    results = search_apps("whatsapp")
    store_ids = [r.store_id for r in results]
    assert None not in store_ids
    assert "com.whatsapp" in store_ids


@patch("app_sdk_finder.google_play.gplay_search")
def test_search_apps_empty_results(mock_search):
    mock_search.return_value = []
    results = search_apps("xyznonexistent")
    assert results == []


@patch("app_sdk_finder.google_play.gplay_search")
def test_search_apps_passes_params(mock_search):
    mock_search.return_value = []
    search_apps("test", country="jp", limit=5)
    mock_search.assert_called_once_with("test", lang="en", country="jp", n_hits=5)
