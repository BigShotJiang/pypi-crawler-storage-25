# tests/test_appgoblin.py
import httpx
import pytest

from app_sdk_finder.appgoblin import get_sdks, parse_sdks_from_html, AppNotFoundError
from app_sdk_finder.models import SDKEntry


def test_parse_sdks_from_html(appgoblin_html_with_sdks):
    result = parse_sdks_from_html(appgoblin_html_with_sdks, "835599320")
    assert result.app_name == "TestApp - Great App"
    assert result.store_id == "835599320"
    assert result.platform == "ios"
    assert result.sdk_scan_date == "2026-03-24"
    assert "Business Tools" in result.categories
    assert "Development Tools" in result.categories
    assert "Ad Networks" in result.categories
    assert len(result.categories["Business Tools"]) == 2
    assert result.categories["Business Tools"][0] == SDKEntry(
        name="Stripe", domain="stripe.com", category="Business Tools"
    )
    assert result.categories["Development Tools"][0] == SDKEntry(
        name="Google", domain="google.com", category="Development Tools"
    )


def test_parse_sdks_from_html_no_sdks(appgoblin_html_no_sdks):
    result = parse_sdks_from_html(appgoblin_html_no_sdks, "999999")
    assert result.app_name == "EmptyApp"
    assert result.categories == {}


def test_parse_sdks_from_html_not_found(appgoblin_html_not_found):
    with pytest.raises(AppNotFoundError):
        parse_sdks_from_html(appgoblin_html_not_found, "000000")


def test_get_sdks_success(httpx_mock, appgoblin_html_with_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_html_with_sdks,
    )
    result = get_sdks("835599320")
    assert result.app_name == "TestApp - Great App"
    assert len(result.categories) == 3


def test_get_sdks_http_404(httpx_mock):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/000000",
        status_code=404,
    )
    with pytest.raises(AppNotFoundError):
        get_sdks("000000")


from app_sdk_finder.appgoblin import parse_company_page, get_company_apps, parse_app_info, get_app_info, CompanyNotFoundError
from app_sdk_finder.models import CompanyApp, AppInfo


def test_parse_company_page(appgoblin_company_html):
    result = parse_company_page(appgoblin_company_html, "amplitude.com")
    assert result.sdk_domain == "amplitude.com"
    assert result.total_apps == 5353
    assert result.ios_total == 2451
    assert result.android_total == 2902
    assert len(result.ios_top_apps) == 2
    assert result.ios_top_apps[0].name == "Bible"
    assert result.ios_top_apps[0].store_id == "282935706"
    assert result.ios_top_apps[0].developer == "Life.Church"
    assert result.ios_top_apps[0].monthly_installs == 5293733
    assert len(result.android_top_apps) == 1
    assert result.android_top_apps[0].name == "Dropbox"
    assert result.android_top_apps[0].store_id == "com.dropbox.android"


def test_parse_company_page_not_found(appgoblin_company_html_not_found):
    with pytest.raises(CompanyNotFoundError):
        parse_company_page(appgoblin_company_html_not_found, "nonexistent.com")


def test_get_company_apps_success(httpx_mock, appgoblin_company_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/companies/amplitude.com",
        text=appgoblin_company_html,
    )
    result = get_company_apps("amplitude.com")
    assert result.total_apps == 5353


def test_get_company_apps_404(httpx_mock):
    httpx_mock.add_response(
        url="https://appgoblin.info/companies/nonexistent.com",
        status_code=404,
    )
    with pytest.raises(CompanyNotFoundError):
        get_company_apps("nonexistent.com")


def test_parse_app_info(appgoblin_app_info_html):
    result = parse_app_info(appgoblin_app_info_html, "835599320")
    assert result.name == "TikTok - Videos, Shop & LIVE"
    assert result.store_id == "835599320"
    assert result.store == "Apple App Store"
    assert result.category == "entertainment"
    assert result.rating == 4.73
    assert result.rating_count == 23366292
    assert result.installs == 1168314600
    assert result.weekly_installs == 196567
    assert result.monthly_installs == 745367
    assert result.weekly_active_users == 29938420
    assert result.monthly_active_users == 52244809
    assert result.monthly_ad_revenue == 4213289
    assert result.monthly_iap_revenue == 1271639.9


def test_parse_app_info_not_found(appgoblin_html_not_found):
    with pytest.raises(AppNotFoundError):
        parse_app_info(appgoblin_html_not_found, "000000")


def test_get_app_info_success(httpx_mock, appgoblin_app_info_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_app_info_html,
    )
    result = get_app_info("835599320")
    assert result.name == "TikTok - Videos, Shop & LIVE"
    assert result.monthly_active_users == 52244809
