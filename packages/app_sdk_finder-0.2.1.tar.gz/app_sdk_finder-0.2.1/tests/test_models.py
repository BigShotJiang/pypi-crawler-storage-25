import json

from app_sdk_finder.models import AppSearchResult, AppSDKResult, SDKEntry, CompanyApp, WhoUsesResult, CompareResult, AppInfo


def test_app_search_result_to_dict():
    result = AppSearchResult(
        name="WhatsApp Messenger",
        developer="WhatsApp Inc.",
        store_id="310633997",
        bundle_id="net.whatsapp.WhatsApp",
        rating=4.69,
        platform="ios",
    )
    d = result.to_dict()
    assert d == {
        "name": "WhatsApp Messenger",
        "developer": "WhatsApp Inc.",
        "store_id": "310633997",
        "bundle_id": "net.whatsapp.WhatsApp",
        "rating": 4.69,
        "platform": "ios",
    }


def test_app_search_result_to_dict_none_fields():
    result = AppSearchResult(
        name="Test App",
        developer="Dev",
        store_id="123",
        bundle_id=None,
        rating=None,
        platform="ios",
    )
    d = result.to_dict()
    assert d["bundle_id"] is None
    assert d["rating"] is None


def test_sdk_entry_to_dict():
    entry = SDKEntry(name="Google", domain="google.com")
    assert entry.to_dict() == {"name": "Google", "domain": "google.com", "category": None}


def test_app_sdk_result_to_dict():
    result = AppSDKResult(
        app_name="Instagram",
        store_id="835599320",
        platform="ios",
        sdk_scan_date="2026-03-24",
        categories={
            "Business Tools": [
                SDKEntry(name="Stripe", domain="stripe.com"),
            ],
        },
    )
    d = result.to_dict()
    assert d["app_name"] == "Instagram"
    assert d["categories"]["Business Tools"] == [
        {"name": "Stripe", "domain": "stripe.com", "category": None}
    ]


def test_app_sdk_result_to_dict_empty_categories():
    result = AppSDKResult(
        app_name="SomeApp",
        store_id="999",
        platform="ios",
        sdk_scan_date=None,
        categories={},
    )
    d = result.to_dict()
    assert d["categories"] == {}
    assert d["sdk_scan_date"] is None


def test_app_sdk_result_to_json_compact():
    result = AppSDKResult(
        app_name="Test",
        store_id="1",
        platform="ios",
        sdk_scan_date=None,
        categories={},
    )
    j = json.dumps(result.to_dict(), ensure_ascii=False)
    assert "\n" not in j
    parsed = json.loads(j)
    assert parsed["app_name"] == "Test"


def test_company_app_to_dict():
    app = CompanyApp(name="Bible", store_id="282935706", developer="Life.Church", monthly_installs=5293733, store="Apple App Store")
    d = app.to_dict()
    assert d["name"] == "Bible"
    assert d["monthly_installs"] == 5293733


def test_who_uses_result_to_dict():
    result = WhoUsesResult(
        sdk_domain="amplitude.com",
        total_apps=5353,
        ios_total=2451,
        android_total=2902,
        ios_top_apps=[CompanyApp(name="Bible", store_id="282935706", developer="Life.Church", monthly_installs=5293733, store="Apple App Store")],
        android_top_apps=[],
    )
    d = result.to_dict()
    assert d["total_apps"] == 5353
    assert len(d["ios_top_apps"]) == 1
    assert d["ios_top_apps"][0]["name"] == "Bible"


def test_compare_result_to_dict():
    shared = [SDKEntry(name="Google", domain="google.com", category="Development Tools")]
    only1 = [SDKEntry(name="ByteDance", domain="bytedance.com", category="Ad Networks")]
    only2 = [SDKEntry(name="Amplitude", domain="amplitude.com", category="Analytics: Product")]
    result = CompareResult(
        app1_name="TikTok", app1_store_id="835599320", app1_sdk_count=14,
        app2_name="BeReal", app2_store_id="1459645446", app2_sdk_count=22,
        shared=shared, only_in_app1=only1, only_in_app2=only2,
    )
    d = result.to_dict()
    assert d["app1"]["name"] == "TikTok"
    assert len(d["shared"]) == 1
    assert d["only_in_app2"][0]["name"] == "Amplitude"


def test_app_info_to_dict():
    info = AppInfo(
        name="TikTok", store_id="835599320", store="Apple App Store",
        category="entertainment", rating=4.73, rating_count=23366292,
        installs=1168314600, weekly_installs=196567, monthly_installs=745367,
        weekly_active_users=29938420, monthly_active_users=52244809,
        monthly_ad_revenue=4213289.0, monthly_iap_revenue=1271639.9,
    )
    d = info.to_dict()
    assert d["name"] == "TikTok"
    assert d["monthly_active_users"] == 52244809


def test_app_info_nullable_fields():
    info = AppInfo(
        name="SmallApp", store_id="123", store="Apple App Store",
        category=None, rating=None, rating_count=None,
        installs=None, weekly_installs=None, monthly_installs=None,
        weekly_active_users=None, monthly_active_users=None,
        monthly_ad_revenue=None, monthly_iap_revenue=None,
    )
    d = info.to_dict()
    assert d["rating"] is None
    assert d["monthly_active_users"] is None
