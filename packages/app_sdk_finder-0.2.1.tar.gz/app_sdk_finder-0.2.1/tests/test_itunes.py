import httpx
import pytest

from app_sdk_finder.itunes import search_apps
from app_sdk_finder.models import AppSearchResult


def test_search_apps_parses_response(httpx_mock, itunes_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=whatsapp&entity=software&limit=10&country=us",
        json=itunes_response,
    )
    results = search_apps("whatsapp")
    assert len(results) == 2
    assert results[0] == AppSearchResult(
        name="WhatsApp Messenger",
        developer="WhatsApp Inc.",
        store_id="310633997",
        bundle_id="net.whatsapp.WhatsApp",
        rating=4.69,
        platform="ios",
    )
    assert results[1].store_id == "1386412985"


def test_search_apps_empty_results(httpx_mock, itunes_empty_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=nonexistentapp&entity=software&limit=10&country=us",
        json=itunes_empty_response,
    )
    results = search_apps("nonexistentapp")
    assert results == []


def test_search_apps_custom_params(httpx_mock, itunes_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=whatsapp&entity=software&limit=5&country=cn",
        json=itunes_response,
    )
    results = search_apps("whatsapp", country="cn", limit=5)
    assert len(results) == 2


def test_search_apps_http_error(httpx_mock):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=test&entity=software&limit=10&country=us",
        status_code=500,
    )
    with pytest.raises(httpx.HTTPStatusError):
        search_apps("test")
