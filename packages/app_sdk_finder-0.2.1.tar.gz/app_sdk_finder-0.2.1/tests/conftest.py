import pytest

ITUNES_RESPONSE_JSON = {
    "resultCount": 2,
    "results": [
        {
            "trackName": "WhatsApp Messenger",
            "artistName": "WhatsApp Inc.",
            "trackId": 310633997,
            "bundleId": "net.whatsapp.WhatsApp",
            "averageUserRating": 4.69,
        },
        {
            "trackName": "WhatsApp Business",
            "artistName": "WhatsApp Inc.",
            "trackId": 1386412985,
            "bundleId": "net.whatsapp.WhatsAppSMB",
            "averageUserRating": 4.70,
        },
    ],
}

ITUNES_EMPTY_RESPONSE_JSON = {"resultCount": 0, "results": []}


@pytest.fixture
def itunes_response():
    return ITUNES_RESPONSE_JSON


@pytest.fixture
def itunes_empty_response():
    return ITUNES_EMPTY_RESPONSE_JSON


# Sampled from real AppGoblin page — the SvelteKit init embeds JS objects (not JSON)
# Keys are unquoted, strings use double quotes
APPGOBLIN_HTML_WITH_SDKS = """<!DOCTYPE html><html><head></head><body>
<script>
{
    __sveltekit_abc = { base: "" };
    const element = document.currentScript.parentElement;
    Promise.all([]).then(([kit, app]) => {
        kit.start(app, element, {
            node_ids: [0, 7, 34],
            data: [{type:"data",data:{user:null}},{type:"data",data:{myapp:{id:123,name:"TestApp - Great App",store_id:"835599320",store:"Apple App Store",sdk_last_crawled:"2026-03-24",sdk_last_crawl_result:1},myhistory:{},appSDKsOverview:{company_categories:{"business-tools":[{company_name:"Stripe",company_domain:"stripe.com",company_logo_url:"logo.jpeg"},{company_name:"Twitter X",company_domain:"x.com",company_logo_url:"logo.jpeg"}],"development-tools":[{company_name:"Google",company_domain:"google.com",company_logo_url:"logo.jpeg"}],"ad-networks":[{company_name:"Facebook",company_domain:"facebook.com",company_logo_url:"logo.jpeg"}]}},companyTypes:{types:[{id:1,name:"Ad Networks",url_slug:"ad-networks"},{id:4,name:"Development Tools",url_slug:"development-tools"},{id:5,name:"Business Tools",url_slug:"business-tools"}]}}},{type:"data",data:{}}],
        });
    });
}
</script>
</body></html>"""

APPGOBLIN_HTML_NO_SDKS = """<!DOCTYPE html><html><head></head><body>
<script>
{
    __sveltekit_abc = { base: "" };
    const element = document.currentScript.parentElement;
    Promise.all([]).then(([kit, app]) => {
        kit.start(app, element, {
            node_ids: [0, 7, 34],
            data: [{type:"data",data:{user:null}},{type:"data",data:{myapp:{id:456,name:"EmptyApp",store_id:"999999",store:"Apple App Store",sdk_last_crawled:"2026-01-01",sdk_last_crawl_result:1},myhistory:{},appSDKsOverview:{company_categories:{}},companyTypes:{types:[{id:1,name:"Ad Networks",url_slug:"ad-networks"}]}}},{type:"data",data:{}}],
        });
    });
}
</script>
</body></html>"""

APPGOBLIN_HTML_NOT_FOUND = """<!DOCTYPE html><html><head></head><body>
<h1>404 Not Found</h1>
</body></html>"""


@pytest.fixture
def appgoblin_html_with_sdks():
    return APPGOBLIN_HTML_WITH_SDKS


@pytest.fixture
def appgoblin_html_no_sdks():
    return APPGOBLIN_HTML_NO_SDKS


@pytest.fixture
def appgoblin_html_not_found():
    return APPGOBLIN_HTML_NOT_FOUND


APPGOBLIN_COMPANY_HTML = """<!DOCTYPE html><html><head></head><body>
<script>
{
    __sveltekit_abc = { base: "" };
    const element = document.currentScript.parentElement;
    Promise.all([]).then(([kit, app]) => {
        kit.start(app, element, {
            node_ids: [0, 5],
            data: [{type:"data",data:{user:null}},{type:"data",data:{companyDetails:{categories:{all:{total_apps:5353,sdk_ios_total_apps:2451,sdk_android_total_apps:2902,sdk_total_apps:5353,sdk_android_installs_d30:1221212290}}},apps:[{company_domain:"amplitude.com",store:"Apple App Store",name:"Bible",store_id:"282935706",developer_name:"Life.Church",icon_url_100:"logo.jpeg",rank:1,installs_d30:5293733,sdk:true,api_call:null,app_ads_direct:false,rating:5,installs:0,rating_count:0,store_link:"https://apps.apple.com/us/app/-/id282935706"},{company_domain:"amplitude.com",store:"Apple App Store",name:"Life360",store_id:"384830320",developer_name:"Life360",icon_url_100:"logo.jpeg",rank:2,installs_d30:1883750,sdk:true,api_call:null,app_ads_direct:false,rating:5,installs:0,rating_count:0,store_link:"https://apps.apple.com/us/app/-/id384830320"}],apps:[{company_domain:"amplitude.com",store:"Google Play",name:"Dropbox",store_id:"com.dropbox.android",developer_name:"Dropbox, Inc.",icon_url_100:"logo.jpeg",rank:1,installs_d30:43120122,sdk:true,api_call:true,app_ads_direct:false,rating:5,installs:0,rating_count:0,store_link:"https://play.google.com/store/apps/details?id=com.dropbox.android"}]}},{type:"data",data:{}}],
        });
    });
}
</script>
</body></html>"""

APPGOBLIN_COMPANY_HTML_NOT_FOUND = """<!DOCTYPE html><html><head></head><body>
<h1>404 Not Found</h1>
</body></html>"""

APPGOBLIN_APP_INFO_HTML = """<!DOCTYPE html><html><head></head><body>
<script>
{
    __sveltekit_abc = { base: "" };
    const element = document.currentScript.parentElement;
    Promise.all([]).then(([kit, app]) => {
        kit.start(app, element, {
            node_ids: [0, 7, 34],
            data: [{type:"data",data:{user:null}},{type:"data",data:{myapp:{id:1687435,name:"TikTok - Videos, Shop & LIVE",store_id:"835599320",store:"Apple App Store",category:"entertainment",rating:4.73,rating_count:23366292,installs:1168314600,weekly_active_users:29938420,monthly_active_users:52244809,monthly_ad_revenue:4213289,monthly_iap_revenue:1271639.9,installs_sum_1w:196567,installs_sum_4w:745367,store_last_updated:"2026-04-07",created_at:"2021-02-06",crawl_result:1,release_date:"2014-04-02"},myhistory:{},appSDKsOverview:{company_categories:{}},companyTypes:{types:[]}}},{type:"data",data:{}}],
        });
    });
}
</script>
</body></html>"""


@pytest.fixture
def appgoblin_company_html():
    return APPGOBLIN_COMPANY_HTML


@pytest.fixture
def appgoblin_company_html_not_found():
    return APPGOBLIN_COMPANY_HTML_NOT_FOUND


@pytest.fixture
def appgoblin_app_info_html():
    return APPGOBLIN_APP_INFO_HTML
