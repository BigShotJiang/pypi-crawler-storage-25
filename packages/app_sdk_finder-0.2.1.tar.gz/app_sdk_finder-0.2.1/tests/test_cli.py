import json

from typer.testing import CliRunner

from app_sdk_finder.cli import app

runner = CliRunner()


# --- search tests ---


def test_search_table_output(httpx_mock, itunes_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=whatsapp&entity=software&limit=10&country=us",
        json=itunes_response,
    )
    result = runner.invoke(app, ["search", "whatsapp", "--platform", "ios"])
    assert result.exit_code == 0
    assert "WhatsApp Messenger" in result.output
    assert "310633997" in result.output


def test_search_json_output(httpx_mock, itunes_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=whatsapp&entity=software&limit=10&country=us",
        json=itunes_response,
    )
    result = runner.invoke(app, ["search", "whatsapp", "--platform", "ios", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) == 2
    assert data[0]["name"] == "WhatsApp Messenger"


def test_search_no_results(httpx_mock, itunes_empty_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=xyznonexistent&entity=software&limit=10&country=us",
        json=itunes_empty_response,
    )
    result = runner.invoke(app, ["search", "xyznonexistent", "--platform", "ios"])
    assert result.exit_code == 0
    assert "No apps found" in result.output


def test_search_requires_platform():
    result = runner.invoke(app, ["search", "whatsapp"])
    assert result.exit_code == 2


def test_search_android_table_output():
    from unittest.mock import patch

    mock_results = [
        {"title": "WhatsApp Messenger", "appId": "com.whatsapp", "developer": "WhatsApp LLC", "score": 4.7, "installs": "10B+"},
        {"title": "Unknown", "appId": None, "developer": "X", "score": None, "installs": "0"},
    ]
    with patch("app_sdk_finder.google_play.gplay_search", return_value=mock_results):
        result = runner.invoke(app, ["search", "whatsapp", "--platform", "android"])
    assert result.exit_code == 0
    assert "WhatsApp Messenger" in result.output
    assert "com.whatsapp" in result.output


def test_search_android_json_output():
    from unittest.mock import patch

    mock_results = [
        {"title": "WhatsApp Messenger", "appId": "com.whatsapp", "developer": "WhatsApp LLC", "score": 4.7, "installs": "10B+"},
    ]
    with patch("app_sdk_finder.google_play.gplay_search", return_value=mock_results):
        result = runner.invoke(app, ["search", "whatsapp", "--platform", "android", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) == 1
    assert data[0]["platform"] == "android"
    assert data[0]["store_id"] == "com.whatsapp"


# --- get-sdk tests ---


def test_get_sdk_table_output(httpx_mock, appgoblin_html_with_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_html_with_sdks,
    )
    result = runner.invoke(app, ["get-sdk", "835599320", "--platform", "ios"])
    assert result.exit_code == 0
    assert "Stripe" in result.output
    assert "Google" in result.output
    assert "Business Tools" in result.output


def test_get_sdk_json_output(httpx_mock, appgoblin_html_with_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_html_with_sdks,
    )
    result = runner.invoke(app, ["get-sdk", "835599320", "--platform", "ios", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["app_name"] == "TestApp - Great App"
    assert "Business Tools" in data["categories"]


def test_get_sdk_not_found(httpx_mock):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/000000",
        status_code=404,
    )
    result = runner.invoke(app, ["get-sdk", "000000", "--platform", "ios"])
    assert result.exit_code == 1
    combined = result.output + (result.stderr if hasattr(result, "stderr") else "")
    assert "not found" in combined.lower()


def test_get_sdk_no_sdks(httpx_mock, appgoblin_html_no_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/999999",
        text=appgoblin_html_no_sdks,
    )
    result = runner.invoke(app, ["get-sdk", "999999", "--platform", "ios"])
    assert result.exit_code == 0
    assert "No SDKs detected" in result.output


def test_get_sdk_requires_platform(httpx_mock):
    result = runner.invoke(app, ["get-sdk", "835599320"])
    assert result.exit_code == 2


def test_get_sdk_detail_table(httpx_mock):
    detail_html = """<!DOCTYPE html><html><body>
    <script>
    {__sveltekit_abc={base:""};const e=document.currentScript.parentElement;
    Promise.all([]).then(([k,a])=>{k.start(a,e,{node_ids:[0],
    data:[{type:"data",data:{user:null}},{type:"data",data:{myapp:{name:"TestApp",store_id:"123",store:"Apple App Store"}}}]})});}
    </script>
    <a href="/sdks/Firebase.framework" rel="nofollow">Firebase.framework</a>
    <a href="/sdks/Lottie.framework" rel="nofollow">Lottie.framework</a>
    <a href="/sdks/Amplitude_Amplitude.bundle" rel="nofollow">Amplitude_Amplitude.bundle</a>
    NSCameraUsageDescription NSMicrophoneUsageDescription
    app_queries:["instagram","whatsapp"]
    "abc123.skadnetwork"
    </body></html>"""
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/123/sdks",
        text=detail_html,
    )
    result = runner.invoke(app, ["get-sdk", "123", "--platform", "ios", "--detail"])
    assert result.exit_code == 0
    assert "Firebase.framework" in result.output
    assert "Lottie.framework" in result.output
    assert "Amplitude_Amplitude.bundle" in result.output
    assert "NSCameraUsageDescription" in result.output


def test_get_sdk_detail_json(httpx_mock):
    detail_html = """<!DOCTYPE html><html><body>
    <script>
    {__sveltekit_abc={base:""};const e=document.currentScript.parentElement;
    Promise.all([]).then(([k,a])=>{k.start(a,e,{node_ids:[0],
    data:[{type:"data",data:{user:null}},{type:"data",data:{myapp:{name:"TestApp",store_id:"123",store:"Apple App Store"}}}]})});}
    </script>
    <a href="/sdks/Sentry.framework" rel="nofollow">Sentry.framework</a>
    <a href="/sdks/Core_Core.bundle" rel="nofollow">Core_Core.bundle</a>
    NSLocationWhenInUseUsageDescription
    </body></html>"""
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/456/sdks",
        text=detail_html,
    )
    result = runner.invoke(app, ["get-sdk", "456", "--platform", "ios", "--detail", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "Sentry.framework" in data["frameworks"]
    assert "Core_Core.bundle" in data["bundles"]
    assert "NSLocationWhenInUseUsageDescription" in data["permissions"]


def test_get_sdk_android_package(httpx_mock, appgoblin_html_with_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/com.whatsapp",
        text=appgoblin_html_with_sdks,
    )
    result = runner.invoke(app, ["get-sdk", "com.whatsapp", "--platform", "android"])
    assert result.exit_code == 0
    assert "Stripe" in result.output


# --- who-uses tests (defaults to --platform all) ---


def test_who_uses_table_output(httpx_mock, appgoblin_company_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/companies/amplitude.com",
        text=appgoblin_company_html,
    )
    result = runner.invoke(app, ["who-uses", "amplitude.com"])
    assert result.exit_code == 0
    assert "5,353" in result.output or "5353" in result.output
    assert "Bible" in result.output
    assert "Dropbox" in result.output


def test_who_uses_json_output(httpx_mock, appgoblin_company_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/companies/amplitude.com",
        text=appgoblin_company_html,
    )
    result = runner.invoke(app, ["who-uses", "amplitude.com", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["total_apps"] == 5353
    assert data["ios_top_apps"][0]["name"] == "Bible"


def test_who_uses_platform_filter_ios(httpx_mock, appgoblin_company_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/companies/amplitude.com",
        text=appgoblin_company_html,
    )
    result = runner.invoke(app, ["who-uses", "amplitude.com", "--platform", "ios"])
    assert result.exit_code == 0
    assert "Bible" in result.output
    assert "Dropbox" not in result.output


def test_who_uses_platform_filter_android(httpx_mock, appgoblin_company_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/companies/amplitude.com",
        text=appgoblin_company_html,
    )
    result = runner.invoke(app, ["who-uses", "amplitude.com", "--platform", "android"])
    assert result.exit_code == 0
    assert "Dropbox" in result.output
    assert "Bible" not in result.output


def test_who_uses_not_found(httpx_mock):
    httpx_mock.add_response(
        url="https://appgoblin.info/companies/nonexistent.com",
        status_code=404,
    )
    result = runner.invoke(app, ["who-uses", "nonexistent.com"])
    assert result.exit_code == 1


# --- compare tests ---


def test_compare_table_output(httpx_mock, appgoblin_html_with_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/111111",
        text=appgoblin_html_with_sdks,
    )
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/222222",
        text=appgoblin_html_with_sdks,
    )
    result = runner.invoke(app, ["compare", "111111", "222222", "--platform", "ios"])
    assert result.exit_code == 0
    assert "Shared" in result.output


def test_compare_json_output(httpx_mock, appgoblin_html_with_sdks, appgoblin_html_no_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/111111",
        text=appgoblin_html_with_sdks,
    )
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/222222",
        text=appgoblin_html_no_sdks,
    )
    result = runner.invoke(app, ["compare", "111111", "222222", "--platform", "ios", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "shared" in data
    assert "only_in_app1" in data
    assert "only_in_app2" in data


def test_compare_requires_platform(httpx_mock):
    result = runner.invoke(app, ["compare", "111111", "222222"])
    assert result.exit_code == 2


def test_compare_android_packages(httpx_mock, appgoblin_html_with_sdks, appgoblin_html_no_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/com.app1",
        text=appgoblin_html_with_sdks,
    )
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/com.app2",
        text=appgoblin_html_no_sdks,
    )
    result = runner.invoke(app, ["compare", "com.app1", "com.app2", "--platform", "android", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data["only_in_app1"]) > 0


# --- info tests ---


def test_info_table_output(httpx_mock, appgoblin_app_info_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_app_info_html,
    )
    result = runner.invoke(app, ["info", "835599320", "--platform", "ios"])
    assert result.exit_code == 0
    assert "TikTok" in result.output
    assert "entertainment" in result.output.lower()


def test_info_json_output(httpx_mock, appgoblin_app_info_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_app_info_html,
    )
    result = runner.invoke(app, ["info", "835599320", "--platform", "ios", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["name"] == "TikTok - Videos, Shop & LIVE"
    assert data["monthly_active_users"] == 52244809


def test_info_not_found(httpx_mock):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/000000",
        status_code=404,
    )
    result = runner.invoke(app, ["info", "000000", "--platform", "ios"])
    assert result.exit_code == 1


def test_info_requires_platform(httpx_mock):
    result = runner.invoke(app, ["info", "835599320"])
    assert result.exit_code == 2


def test_info_android_package(httpx_mock, appgoblin_app_info_html):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/com.example",
        text=appgoblin_app_info_html,
    )
    result = runner.invoke(app, ["info", "com.example", "--platform", "android", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["name"] == "TikTok - Videos, Shop & LIVE"


# --- list-sdks tests ---


def test_list_sdks_table_output():
    from unittest.mock import patch
    from app_sdk_finder.models import SDKEntry

    mock_result = {"Ad Networks": [SDKEntry(name="Google", domain="google.com"), SDKEntry(name="Facebook", domain="facebook.com")]}
    with patch("app_sdk_finder.cli.list_sdk_companies", return_value=mock_result):
        result = runner.invoke(app, ["list-sdks", "--category", "ad-networks", "--platform", "ios"])
    assert result.exit_code == 0
    assert "Google" in result.output
    assert "Facebook" in result.output
    assert "Ad Networks" in result.output


def test_list_sdks_json_output():
    from unittest.mock import patch
    from app_sdk_finder.models import SDKEntry

    mock_result = {"Ad Networks": [SDKEntry(name="Google", domain="google.com")]}
    with patch("app_sdk_finder.cli.list_sdk_companies", return_value=mock_result):
        result = runner.invoke(app, ["list-sdks", "--category", "ad-networks", "--platform", "ios", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "Ad Networks" in data
    assert data["Ad Networks"][0]["name"] == "Google"


def test_list_sdks_empty():
    from unittest.mock import patch

    with patch("app_sdk_finder.cli.list_sdk_companies", return_value={}):
        result = runner.invoke(app, ["list-sdks", "--platform", "ios"])
    assert result.exit_code == 0
    assert "No SDKs found" in result.output


def test_list_sdks_invalid_category():
    result = runner.invoke(app, ["list-sdks", "--category", "invalid", "--platform", "ios"])
    assert result.exit_code == 2
    assert "Invalid value" in result.output or "is not one of" in result.output


# --- rank tests ---


def test_rank_table_output():
    from unittest.mock import patch
    from app_sdk_finder.models import SDKRank

    mock_ranks = [
        SDKRank(name="Firebase", domain="firebase.google.com", total_apps=135000, ios_total=31000, android_total=104000),
        SDKRank(name="Amplitude", domain="amplitude.com", total_apps=5353, ios_total=2451, android_total=2902),
    ]
    with patch("app_sdk_finder.cli.rank_sdk_companies", return_value=mock_ranks):
        result = runner.invoke(app, ["list-sdks", "rank", "product-analytics", "--platform", "ios"])
    assert result.exit_code == 0
    assert "Firebase" in result.output
    assert "Amplitude" in result.output
    assert "Ranked by App Adoption" in result.output


def test_rank_json_output():
    from unittest.mock import patch
    from app_sdk_finder.models import SDKRank

    mock_ranks = [
        SDKRank(name="Firebase", domain="firebase.google.com", total_apps=135000, ios_total=31000, android_total=104000),
    ]
    with patch("app_sdk_finder.cli.rank_sdk_companies", return_value=mock_ranks):
        result = runner.invoke(app, ["list-sdks", "rank", "product-analytics", "--platform", "ios", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) == 1
    assert data[0]["name"] == "Firebase"
    assert data[0]["total_apps"] == 135000


def test_rank_empty():
    from unittest.mock import patch

    with patch("app_sdk_finder.cli.rank_sdk_companies", return_value=[]):
        result = runner.invoke(app, ["list-sdks", "rank", "mediation", "--platform", "ios"])
    assert result.exit_code == 0
    assert "No SDKs found" in result.output


def test_rank_invalid_category():
    result = runner.invoke(app, ["list-sdks", "rank", "invalid"])
    assert result.exit_code == 2
