# app-sdk-finder

CLI tool to find SDKs used by iOS/Android apps via [AppGoblin](https://appgoblin.info). Query 6M+ apps' SDK data, compare tech stacks, and rank SDKs by popularity.

## Install

```bash
pip install app-sdk-finder

# Or run without installing
uvx app-sdk-finder --help
```

## Commands

### Search apps

```bash
app-sdk-finder search "bereal" --platform ios
app-sdk-finder search "whatsapp" --platform android --json
```

### Get SDK list

```bash
# Company-level overview
app-sdk-finder get-sdk 1459645446 --platform ios

# Detailed: framework names, bundles, permissions
app-sdk-finder get-sdk 1459645446 --platform ios --detail
```

### Compare two apps

```bash
app-sdk-finder compare 835599320 1459645446 --platform ios
```

### App info (installs, revenue, MAU)

```bash
app-sdk-finder info 835599320 --platform ios
```

### Which apps use a specific SDK

```bash
app-sdk-finder who-uses amplitude.com
app-sdk-finder who-uses firebase.google.com --platform ios
```

### Browse and rank SDKs

```bash
# List all SDKs in a category
app-sdk-finder list-sdks --category product-analytics

# Rank by popularity
app-sdk-finder list-sdks rank product-analytics --platform ios
```

Categories: `ad-networks`, `ad-attribution`, `product-analytics`, `development-tools`, `business-tools`, `mediation`

## Output formats

All commands support `--json` for machine-readable output:

```bash
app-sdk-finder get-sdk 1459645446 --platform ios --json
```

Default output uses rich tables for readability.

## Store IDs

- **iOS**: numeric trackId (e.g. `835599320` for TikTok)
- **Android**: package name (e.g. `com.bereal.ft`)

Use `search` to find the store ID, then pass it to other commands.

## Claude Code Skill

A [Claude Code](https://claude.ai/code) skill is included in `skills/app-sdk-finder/` that lets Claude automatically call this CLI to answer SDK-related questions.

## License

MIT
