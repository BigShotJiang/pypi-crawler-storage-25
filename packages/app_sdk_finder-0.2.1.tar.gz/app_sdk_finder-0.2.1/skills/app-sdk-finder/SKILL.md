---
name: app-sdk-finder
description: Query mobile app SDK usage, tech stacks, and market intelligence via the app-sdk-finder CLI. Use when user asks about what SDKs an app uses, wants to compare app tech stacks, needs SDK popularity rankings, asks which apps use a specific SDK, or wants app metrics (installs, revenue, MAU). Triggers on questions like "what SDK does X app use", "compare X and Y tech stack", "most popular analytics SDK", "who uses Amplitude", "BeReal tech stack".
---

# app-sdk-finder

Query mobile app SDK data from AppGoblin.

## Prerequisites

Before running any command, check if the CLI is available. If not, install it:

```bash
# Check availability
which app-sdk-finder || uvx app-sdk-finder --help

# Install options (pick one):
uvx app-sdk-finder ...          # Run without installing (recommended)
uv tool install app-sdk-finder  # Install globally via uv
pip install app-sdk-finder      # Install via pip
```

Prefer `uvx` for one-off usage (no install needed). Use `uv tool install` if the user will use it frequently.

When using `uvx`, prefix every command: `uvx app-sdk-finder search ...` instead of `app-sdk-finder search ...`.

## Commands

Always use `--json` for structured output, then summarize for the user.

```bash
# Search app by name → get store_id
app-sdk-finder search "<name>" --platform ios|android --json

# SDK overview (company-level categories)
app-sdk-finder get-sdk <store_id> --platform ios|android --json

# SDK detail (framework/bundle/permission names)
app-sdk-finder get-sdk <store_id> --platform ios|android --detail --json

# App metrics (installs, MAU, revenue)
app-sdk-finder info <store_id> --platform ios|android --json

# Compare two apps' SDKs
app-sdk-finder compare <id1> <id2> --platform ios|android --json

# Which apps use a specific SDK
app-sdk-finder who-uses <domain> --json

# List SDK companies in a category
app-sdk-finder list-sdks --category <cat> --json

# Rank SDKs by popularity in a category
app-sdk-finder list-sdks rank <cat> --platform ios|android --json
```

## Store IDs

- **iOS**: numeric trackId (e.g. `835599320`)
- **Android**: package name (e.g. `com.bereal.ft`)

Use `search` first to find the store_id, then pass it to other commands.

## Categories (for list-sdks / rank)

`ad-networks`, `ad-attribution`, `product-analytics`, `development-tools`, `business-tools`, `mediation`

## SDK domains (for who-uses)

Use `list-sdks --category <cat> --json` to discover valid domains, then pass to `who-uses`.

Common domains: `amplitude.com`, `firebase.google.com`, `mixpanel.com`, `adjust.com`, `appsflyer.com`, `datadoghq.com`, `sentry.io`, `stripe.com`, `braze.com`

## Workflow patterns

**"What SDKs does X use?"**
1. `search "<name>" --platform ios --json` → get store_id
2. `get-sdk <store_id> --platform ios --json` → SDK overview
3. Optionally `get-sdk <store_id> --platform ios --detail --json` → framework-level detail

**"Compare X and Y tech stacks"**
1. `search` both apps → get store_ids
2. `compare <id1> <id2> --platform ios --json`

**"Most popular analytics SDK"**
1. `list-sdks rank product-analytics --platform ios --json`

**"Who uses Amplitude?"**
1. `who-uses amplitude.com --json`

**"What's X app's download numbers?"**
1. `search "<name>" --platform ios --json` → get store_id
2. `info <store_id> --platform ios --json`

## Important notes

- `--platform` is **required** for search, get-sdk, compare, info, rank. Only `who-uses` and `list-sdks` don't require it.
- Always use `--json` for machine-readable output, then present a human-friendly summary.
- `--detail` on get-sdk gives framework/bundle names (e.g. `FaceTecSDK.framework`) vs company names (e.g. `FaceTec`). Use when user asks about specific libraries.
- Data comes from AppGoblin's analysis of 6M+ apps. Top apps list in who-uses is limited to 10 per platform.
