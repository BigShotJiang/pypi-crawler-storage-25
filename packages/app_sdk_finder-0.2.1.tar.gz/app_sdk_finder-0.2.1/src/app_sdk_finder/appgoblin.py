import json
import re
from concurrent.futures import ThreadPoolExecutor

import httpx

from app_sdk_finder.models import AppSDKResult, AppSDKDetail, SDKEntry, SDKRank, CompanyApp, WhoUsesResult, AppInfo

APPGOBLIN_BASE_URL = "https://appgoblin.info"
# Max chars to scan when extracting JS objects from HTML
_JS_EXTRACT_LIMIT = 50000


class AppNotFoundError(Exception):
    pass


class CompanyNotFoundError(Exception):
    pass


def _fetch_page(
    path: str,
    error_cls: type[Exception],
    identifier: str,
) -> str:
    """Fetch an AppGoblin page, raising error_cls on 404."""
    response = httpx.get(f"{APPGOBLIN_BASE_URL}{path}", timeout=15)
    if response.status_code == 404:
        raise error_cls(f"Not found on AppGoblin: {identifier}")
    response.raise_for_status()
    return response.text


def _extract_js_object(html: str, prefix: str) -> str | None:
    idx = html.find(prefix)
    if idx < 0:
        return None
    start = idx + len(prefix)
    brace_count = 0
    end = start
    for i in range(start, min(start + _JS_EXTRACT_LIMIT, len(html))):
        if html[i] == "{" or html[i] == "[":
            brace_count += 1
        elif html[i] == "}" or html[i] == "]":
            brace_count -= 1
            if brace_count == 0:
                end = i + 1
                break
    return html[start:end]


def _js_to_json(js_str: str) -> str:
    result = re.sub(r"(?<=[{,])\s*(\w+)\s*:", r'"\1":', js_str)
    # Fix JS shorthand like -.85 → -0.85 (invalid JSON)
    result = re.sub(r":-\.(\d)", r":-0.\1", result)
    result = re.sub(r":\.(\d)", r":0.\1", result)
    return result


def _slug_to_display_name(slug: str, types_map: dict[str, str]) -> str:
    return types_map.get(slug, slug.replace("-", " ").title())


def _extract_apps_arrays(html: str) -> tuple[list[dict], list[dict]]:
    """Extract iOS and Android app arrays from company page."""
    ios_apps: list[dict] = []
    android_apps: list[dict] = []

    for match in re.finditer(r"apps:\[", html):
        start = match.end()
        brace_count = 1
        end = start
        for i in range(start, min(start + _JS_EXTRACT_LIMIT, len(html))):
            if html[i] == "[" or html[i] == "{":
                brace_count += 1
            elif html[i] == "]" or html[i] == "}":
                brace_count -= 1
                if brace_count == 0:
                    end = i
                    break
        arr_str = "[" + html[start:end] + "]"
        try:
            apps_list = json.loads(_js_to_json(arr_str))
        except json.JSONDecodeError:
            continue
        for app_data in apps_list:
            store = app_data.get("store", "")
            entry = {
                "name": app_data.get("name", ""),
                "store_id": app_data.get("store_id", ""),
                "developer": app_data.get("developer_name", ""),
                "monthly_installs": app_data.get("installs_d30", 0),
                "store": store,
            }
            if "Apple" in store:
                ios_apps.append(entry)
            else:
                android_apps.append(entry)
    return ios_apps, android_apps


def parse_sdks_from_html(html: str, store_id: str) -> AppSDKResult:
    # Anchor to myapp object to avoid matching other name: fields
    name_match = re.search(r'myapp:\{[^}]*?name:"([^"]+)"', html)
    if name_match is None:
        raise AppNotFoundError(f"App not found: {store_id}")

    store_match = re.search(r'store:"([^"]*)"', html)
    platform = "ios" if store_match and "Apple" in store_match.group(1) else "android"

    date_match = re.search(r'sdk_last_crawled:"([^"]+)"', html)
    sdk_scan_date = date_match.group(1) if date_match else None

    types_map: dict[str, str] = {}
    types_raw = _extract_js_object(html, "types:")
    if types_raw:
        try:
            types_list = json.loads(_js_to_json(types_raw))
            types_map = {t["url_slug"]: t["name"] for t in types_list}
        except (json.JSONDecodeError, KeyError):
            pass

    categories: dict[str, list[SDKEntry]] = {}
    cc_raw = _extract_js_object(html, "company_categories:")
    if cc_raw:
        try:
            cc_data = json.loads(_js_to_json(cc_raw))
            for slug, companies in cc_data.items():
                if not companies:
                    continue
                display_name = _slug_to_display_name(slug, types_map)
                categories[display_name] = [
                    SDKEntry(
                        name=c["company_name"],
                        domain=c["company_domain"],
                        category=display_name,
                    )
                    for c in companies
                ]
        except (json.JSONDecodeError, KeyError):
            pass

    return AppSDKResult(
        app_name=name_match.group(1),
        store_id=store_id,
        platform=platform,
        sdk_scan_date=sdk_scan_date,
        categories=categories,
    )


def get_sdks(store_id: str) -> AppSDKResult:
    html = _fetch_page(f"/apps/{store_id}", AppNotFoundError, store_id)
    return parse_sdks_from_html(html, store_id)


def parse_sdk_detail(html: str, store_id: str) -> AppSDKDetail:
    """Parse detailed SDK data from /apps/{store_id}/sdks page."""
    name_match = re.search(r'myapp:\{[^}]*?name:"([^"]+)"', html)
    app_name = name_match.group(1) if name_match else store_id

    store_match = re.search(r'store:"([^"]*)"', html)
    platform = "ios" if store_match and "Apple" in store_match.group(1) else "android"

    frameworks = sorted(set(re.findall(r'href="/sdks/([^"]+\.framework)"', html)))
    bundles = sorted(set(re.findall(r'href="/sdks/([^"]+\.bundle)"', html)))
    permissions = sorted(set(re.findall(r'(NS\w+UsageDescription)', html)))
    skadnetwork_ids = sorted(set(re.findall(r'"(\w+\.skadnetwork)"', html)))
    app_queries = sorted(set(re.findall(r'app_queries:\[([^\]]+)\]', html)))
    if app_queries:
        app_queries = [q.strip('"') for q in app_queries[0].split(",")]

    return AppSDKDetail(
        app_name=app_name,
        store_id=store_id,
        platform=platform,
        frameworks=frameworks,
        bundles=bundles,
        permissions=permissions,
        skadnetwork_ids=skadnetwork_ids,
        app_queries=app_queries,
    )


def get_sdk_detail(store_id: str) -> AppSDKDetail:
    """Fetch detailed SDK data from /apps/{store_id}/sdks page."""
    html = _fetch_page(f"/apps/{store_id}/sdks", AppNotFoundError, store_id)
    return parse_sdk_detail(html, store_id)


def parse_company_page(html: str, sdk_domain: str) -> WhoUsesResult:
    if "companyDetails" not in html:
        raise CompanyNotFoundError(f"Company not found: {sdk_domain}")

    total_apps = 0
    ios_total = 0
    android_total = 0

    details_raw = _extract_js_object(html, "categories:{all:")
    if details_raw:
        try:
            details = json.loads(_js_to_json(details_raw))
            total_apps = details.get("total_apps", 0) or details.get("sdk_total_apps", 0)
            ios_total = details.get("sdk_ios_total_apps", 0)
            android_total = details.get("sdk_android_total_apps", 0)
        except json.JSONDecodeError:
            pass

    ios_apps_raw, android_apps_raw = _extract_apps_arrays(html)
    ios_top_apps = [CompanyApp(**a) for a in ios_apps_raw]
    android_top_apps = [CompanyApp(**a) for a in android_apps_raw]

    return WhoUsesResult(
        sdk_domain=sdk_domain,
        total_apps=total_apps,
        ios_total=ios_total,
        android_total=android_total,
        ios_top_apps=ios_top_apps,
        android_top_apps=android_top_apps,
    )


def get_company_apps(sdk_domain: str) -> WhoUsesResult:
    html = _fetch_page(f"/companies/{sdk_domain}", CompanyNotFoundError, sdk_domain)
    return parse_company_page(html, sdk_domain)


def parse_app_info(html: str, store_id: str) -> AppInfo:
    myapp_raw = _extract_js_object(html, "myapp:")
    if myapp_raw is None:
        raise AppNotFoundError(f"App not found: {store_id}")
    try:
        myapp = json.loads(_js_to_json(myapp_raw))
    except json.JSONDecodeError:
        raise AppNotFoundError(f"Failed to parse app data: {store_id}")

    return AppInfo(
        name=myapp.get("name", ""),
        store_id=str(myapp.get("store_id", store_id)),
        store=myapp.get("store", ""),
        category=myapp.get("category"),
        rating=myapp.get("rating"),
        rating_count=myapp.get("rating_count"),
        installs=myapp.get("installs"),
        weekly_installs=myapp.get("installs_sum_1w"),
        monthly_installs=myapp.get("installs_sum_4w"),
        weekly_active_users=myapp.get("weekly_active_users"),
        monthly_active_users=myapp.get("monthly_active_users"),
        monthly_ad_revenue=myapp.get("monthly_ad_revenue"),
        monthly_iap_revenue=myapp.get("monthly_iap_revenue"),
    )


def get_app_info(store_id: str) -> AppInfo:
    html = _fetch_page(f"/apps/{store_id}", AppNotFoundError, store_id)
    return parse_app_info(html, store_id)


SDK_CATEGORIES = {
    "ad-networks": "Ad Networks",
    "ad-attribution": "Analytics: Attribution",
    "product-analytics": "Analytics: Product",
    "development-tools": "Development Tools",
    "business-tools": "Business Tools",
    "mediation": "Mediation",
}


def _fetch_category(slug: str) -> tuple[str, list[SDKEntry]]:
    """Fetch SDK companies for a single category."""
    display_name = SDK_CATEGORIES.get(slug, slug)
    response = httpx.get(f"{APPGOBLIN_BASE_URL}/companies/types/{slug}", timeout=15)
    if response.status_code != 200:
        return display_name, []
    pairs = re.findall(
        r'company_name:"([^"]+)",company_domain:"([^"]+)"',
        response.text,
    )
    seen: set[str] = set()
    companies: list[SDKEntry] = []
    for name, domain in pairs:
        if domain not in seen:
            seen.add(domain)
            companies.append(SDKEntry(name=name, domain=domain))
    return display_name, companies


def list_sdk_companies(category_slug: str | None = None) -> dict[str, list[SDKEntry]]:
    """List all SDK companies from AppGoblin, grouped by category."""
    slugs = [category_slug] if category_slug else list(SDK_CATEGORIES.keys())

    if len(slugs) == 1:
        name, companies = _fetch_category(slugs[0])
        return {name: companies} if companies else {}

    with ThreadPoolExecutor(max_workers=len(slugs)) as pool:
        results = list(pool.map(_fetch_category, slugs))

    return {name: companies for name, companies in results if companies}


def _fetch_company_stats(sdk: SDKEntry) -> SDKRank | None:
    """Fetch total_apps stats for a single SDK company."""
    try:
        result = get_company_apps(sdk.domain)
        return SDKRank(
            name=sdk.name,
            domain=sdk.domain,
            total_apps=result.total_apps,
            ios_total=result.ios_total,
            android_total=result.android_total,
        )
    except Exception:
        return None


def rank_sdk_companies(category_slug: str) -> list[SDKRank]:
    """Rank SDK companies in a category by total app adoption."""
    companies = list_sdk_companies(category_slug)
    if not companies:
        return []

    all_sdks = [sdk for sdks in companies.values() for sdk in sdks]

    with ThreadPoolExecutor(max_workers=10) as pool:
        results = list(pool.map(_fetch_company_stats, all_sdks))

    ranked = [r for r in results if r is not None and r.total_apps > 0]
    ranked.sort(key=lambda r: r.total_apps, reverse=True)
    return ranked


def get_sdks_pair(store_id1: str, store_id2: str) -> tuple[AppSDKResult, AppSDKResult]:
    """Fetch SDK data for two apps concurrently."""
    with ThreadPoolExecutor(max_workers=2) as pool:
        f1 = pool.submit(get_sdks, store_id1)
        f2 = pool.submit(get_sdks, store_id2)
        return f1.result(), f2.result()
