from dataclasses import dataclass, asdict


@dataclass
class AppSearchResult:
    name: str
    developer: str
    store_id: str
    bundle_id: str | None
    rating: float | None
    platform: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class SDKEntry:
    name: str
    domain: str
    category: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class AppSDKResult:
    app_name: str
    store_id: str
    platform: str
    sdk_scan_date: str | None
    categories: dict[str, list[SDKEntry]]

    def to_dict(self) -> dict:
        return {
            "app_name": self.app_name,
            "store_id": self.store_id,
            "platform": self.platform,
            "sdk_scan_date": self.sdk_scan_date,
            "categories": {
                cat: [sdk.to_dict() for sdk in sdks]
                for cat, sdks in self.categories.items()
            },
        }


@dataclass
class AppSDKDetail:
    app_name: str
    store_id: str
    platform: str
    frameworks: list[str]
    bundles: list[str]
    permissions: list[str]
    skadnetwork_ids: list[str]
    app_queries: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CompanyApp:
    name: str
    store_id: str
    developer: str
    monthly_installs: int
    store: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class WhoUsesResult:
    sdk_domain: str
    total_apps: int
    ios_total: int
    android_total: int
    ios_top_apps: list[CompanyApp]
    android_top_apps: list[CompanyApp]

    def to_dict(self) -> dict:
        return {
            "sdk_domain": self.sdk_domain,
            "total_apps": self.total_apps,
            "ios_total": self.ios_total,
            "android_total": self.android_total,
            "ios_top_apps": [a.to_dict() for a in self.ios_top_apps],
            "android_top_apps": [a.to_dict() for a in self.android_top_apps],
        }


@dataclass
class SDKRank:
    name: str
    domain: str
    total_apps: int
    ios_total: int
    android_total: int

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CompareResult:
    app1_name: str
    app1_store_id: str
    app1_sdk_count: int
    app2_name: str
    app2_store_id: str
    app2_sdk_count: int
    shared: list[SDKEntry]
    only_in_app1: list[SDKEntry]
    only_in_app2: list[SDKEntry]

    def to_dict(self) -> dict:
        return {
            "app1": {"name": self.app1_name, "store_id": self.app1_store_id, "sdk_count": self.app1_sdk_count},
            "app2": {"name": self.app2_name, "store_id": self.app2_store_id, "sdk_count": self.app2_sdk_count},
            "shared": [s.to_dict() for s in self.shared],
            "only_in_app1": [s.to_dict() for s in self.only_in_app1],
            "only_in_app2": [s.to_dict() for s in self.only_in_app2],
        }


@dataclass
class AppInfo:
    name: str
    store_id: str
    store: str
    category: str | None
    rating: float | None
    rating_count: int | None
    installs: int | None
    weekly_installs: int | None
    monthly_installs: int | None
    weekly_active_users: int | None
    monthly_active_users: int | None
    monthly_ad_revenue: float | None
    monthly_iap_revenue: float | None

    def to_dict(self) -> dict:
        return asdict(self)
