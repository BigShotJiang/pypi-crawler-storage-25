from google_play_scraper import search as gplay_search

from app_sdk_finder.models import AppSearchResult


def search_apps(
    term: str,
    country: str = "us",
    limit: int = 10,
) -> list[AppSearchResult]:
    """Search Google Play Store for apps by name."""
    results = gplay_search(term, lang="en", country=country, n_hits=limit)
    return [
        AppSearchResult(
            name=r["title"],
            developer=r.get("developer", ""),
            store_id=r.get("appId", ""),
            bundle_id=r.get("appId"),
            rating=r.get("score"),
            platform="android",
        )
        for r in results
        if r.get("appId")  # filter out results with null appId
    ]
