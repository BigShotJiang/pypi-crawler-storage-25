import httpx

from app_sdk_finder.models import AppSearchResult

ITUNES_SEARCH_URL = "https://itunes.apple.com/search"


def search_apps(
    term: str,
    country: str = "us",
    limit: int = 10,
) -> list[AppSearchResult]:
    response = httpx.get(
        ITUNES_SEARCH_URL,
        timeout=15,
        params={
            "term": term,
            "entity": "software",
            "limit": limit,
            "country": country,
        },
    )
    response.raise_for_status()
    data = response.json()
    return [
        AppSearchResult(
            name=item["trackName"],
            developer=item["artistName"],
            store_id=str(item["trackId"]),
            bundle_id=item.get("bundleId"),
            rating=item.get("averageUserRating"),
            platform="ios",
        )
        for item in data.get("results", [])
    ]
