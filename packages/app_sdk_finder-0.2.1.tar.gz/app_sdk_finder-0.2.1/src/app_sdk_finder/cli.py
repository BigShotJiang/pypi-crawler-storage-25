import json
from enum import Enum
from typing import Callable, TypeVar

import typer
from rich.console import Console
from rich.table import Table

from app_sdk_finder.appgoblin import (
    AppNotFoundError,
    CompanyNotFoundError,
    get_sdks,
    get_sdk_detail,
    get_sdks_pair,
    get_company_apps,
    get_app_info,
    list_sdk_companies,
    rank_sdk_companies,
    SDK_CATEGORIES,
)
from app_sdk_finder.models import AppSearchResult, CompareResult, SDKEntry, CompanyApp

app = typer.Typer(
    help="Find SDKs used by iOS/Android apps via AppGoblin.\n\n"
    "Typical workflow:\n\n"
    "  1. search <name>        Find an app and get its store ID\n\n"
    "  2. get-sdk <store_id>   See what SDKs the app uses\n\n"
    "  3. compare <id1> <id2>  Compare SDKs between two apps\n\n"
    "  4. list-sdks                Browse available SDK companies\n\n"
    "  5. list-sdks rank <cat>     Rank SDKs by popularity in a category\n\n"
    "  6. who-uses <domain>        Find which apps use a specific SDK\n\n"
    "  7. info <store_id>          Get app stats (installs, revenue, etc.)\n\n"
    "Store IDs: iOS uses numeric trackId (e.g. 835599320), Android uses package name (e.g. com.bereal.ft).",
)
console = Console()
err_console = Console(stderr=True)

T = TypeVar("T")


class Platform(str, Enum):
    ios = "ios"
    android = "android"


class PlatformAll(str, Enum):
    """Platform filter that includes an 'all' option, used by who-uses."""

    ios = "ios"
    android = "android"
    all = "all"


class SDKCategory(str, Enum):
    ad_networks = "ad-networks"
    ad_attribution = "ad-attribution"
    product_analytics = "product-analytics"
    development_tools = "development-tools"
    business_tools = "business-tools"
    mediation = "mediation"


def _run_or_exit(fn: Callable[[], T], *error_types: type[Exception]) -> T:
    """Run fn, printing errors and exiting on failure."""
    try:
        return fn()
    except (*error_types,) as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(code=1)


def _format_number(n: int | float | None) -> str:
    if n is None:
        return "N/A"
    if isinstance(n, float):
        n = int(n)
    if n >= 1_000_000_000:
        return f"{n / 1_000_000_000:.1f}B"
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def _print_search_table(results: list[AppSearchResult]) -> None:
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("App Name", style="bold")
    table.add_column("Developer")
    table.add_column("Store ID", style="green")
    table.add_column("Rating", justify="right")
    for i, r in enumerate(results, 1):
        rating = f"{r.rating:.2f}" if r.rating is not None else "N/A"
        table.add_row(str(i), r.name, r.developer, r.store_id, rating)
    console.print(table)


def _print_apps_table(label: str, apps: list[CompanyApp]) -> None:
    """Print a table of apps (used by who-uses for iOS/Android sections)."""
    console.print(f"[bold]{label}:[/bold]")
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("App Name", style="bold")
    table.add_column("Developer")
    table.add_column("Store ID", style="green")
    table.add_column("Monthly Installs", justify="right")
    for i, a in enumerate(apps, 1):
        table.add_row(str(i), a.name, a.developer, a.store_id, _format_number(a.monthly_installs))
    console.print(table)
    console.print()


def _print_sdk_table(title: str, sdks: list[SDKEntry]) -> None:
    """Print a table of SDKs (used by compare for shared/only sections)."""
    console.print(f"[bold]{title}:[/bold]")
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Company")
    table.add_column("Domain", style="dim")
    table.add_column("Category")
    for sdk in sdks:
        table.add_row(sdk.name, sdk.domain, sdk.category or "")
    console.print(table)
    console.print()


@app.command()
def search(
    app_name: str = typer.Argument(help="App name to search for"),
    platform: Platform = typer.Option(..., help="Target platform (ios/android)"),
    country: str = typer.Option("us", help="Country code"),
    limit: int = typer.Option(10, help="Max results"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Search for apps by name. Use the store ID from results with get-sdk, compare, or info."""
    if platform == Platform.ios:
        from app_sdk_finder.itunes import search_apps
    else:
        from app_sdk_finder.google_play import search_apps

    results = _run_or_exit(lambda: search_apps(app_name, country=country, limit=limit))

    if not results:
        console.print("[yellow]No apps found[/yellow]")
        return

    if output_json:
        print(json.dumps([r.to_dict() for r in results], ensure_ascii=False))
    else:
        _print_search_table(results)


@app.command("get-sdk")
def get_sdk(
    store_id: str = typer.Argument(help="Store ID (iOS: numeric trackId, Android: package name like com.example.app)"),
    platform: Platform = typer.Option(..., help="Target platform (ios/android)"),
    detail: bool = typer.Option(False, "--detail", help="Show detailed SDK data (frameworks, bundles, permissions)"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Get SDKs used by an app. Works with both iOS trackId and Android package name."""
    if detail:
        result = _run_or_exit(lambda: get_sdk_detail(store_id), AppNotFoundError)

        if output_json:
            print(json.dumps(result.to_dict(), ensure_ascii=False))
            return

        console.print(f"[bold]{result.app_name}[/bold] ({result.store_id})")
        console.print(f"Platform: {result.platform}")
        console.print()

        if result.frameworks:
            console.print(f"[bold]Frameworks ({len(result.frameworks)}):[/bold]")
            table = Table(show_header=True, header_style="bold cyan")
            table.add_column("#", style="dim", width=4)
            table.add_column("Framework", style="bold")
            for i, f in enumerate(result.frameworks, 1):
                table.add_row(str(i), f)
            console.print(table)
            console.print()

        if result.bundles:
            console.print(f"[bold]Bundles ({len(result.bundles)}):[/bold]")
            table = Table(show_header=True, header_style="bold cyan")
            table.add_column("#", style="dim", width=4)
            table.add_column("Bundle", style="bold")
            for i, b in enumerate(result.bundles, 1):
                table.add_row(str(i), b)
            console.print(table)
            console.print()

        if result.permissions:
            console.print(f"[bold]Permissions ({len(result.permissions)}):[/bold]")
            for p in result.permissions:
                console.print(f"  {p}")
            console.print()

        if result.app_queries:
            console.print(f"[bold]App Queries ({len(result.app_queries)}):[/bold]")
            console.print(f"  {', '.join(result.app_queries)}")
            console.print()

        if result.skadnetwork_ids:
            console.print(f"[dim]SKAdNetwork IDs: {len(result.skadnetwork_ids)}[/dim]")
        return

    result = _run_or_exit(lambda: get_sdks(store_id), AppNotFoundError)

    if not result.categories:
        console.print(f"[yellow]No SDKs detected for {result.app_name}[/yellow]")
        return

    if output_json:
        print(json.dumps(result.to_dict(), ensure_ascii=False))
    else:
        console.print(f"[bold]{result.app_name}[/bold] ({result.store_id})")
        console.print(f"Platform: {result.platform}")
        if result.sdk_scan_date:
            console.print(f"SDK Scan: {result.sdk_scan_date}")
        console.print()

        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Category", style="bold")
        table.add_column("Company")
        table.add_column("Domain", style="dim")

        for cat_name, sdks in result.categories.items():
            for i, sdk in enumerate(sdks):
                cat_display = cat_name if i == 0 else ""
                table.add_row(cat_display, sdk.name, sdk.domain)
            table.add_section()

        console.print(table)


@app.command("who-uses")
def who_uses(
    sdk_domain: str = typer.Argument(help="SDK company domain (e.g. amplitude.com). Use 'list-sdks' to browse available domains."),
    platform: PlatformAll = typer.Option(PlatformAll.all, help="Filter by platform"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Find which apps use a specific SDK."""
    result = _run_or_exit(lambda: get_company_apps(sdk_domain), CompanyNotFoundError)

    if output_json:
        print(json.dumps(result.to_dict(), ensure_ascii=False))
        return

    console.print(f"[bold]{sdk_domain}[/bold]")
    console.print(f"Total: {result.total_apps:,} apps ({result.ios_total:,} iOS / {result.android_total:,} Android)")
    console.print()

    if platform in (PlatformAll.all, PlatformAll.ios) and result.ios_top_apps:
        _print_apps_table("iOS Top Apps", result.ios_top_apps)

    if platform in (PlatformAll.all, PlatformAll.android) and result.android_top_apps:
        _print_apps_table("Android Top Apps", result.android_top_apps)


@app.command()
def compare(
    store_id1: str = typer.Argument(help="First app store ID (use 'search' to find it)"),
    store_id2: str = typer.Argument(help="Second app store ID (use 'search' to find it)"),
    platform: Platform = typer.Option(..., help="Target platform (ios/android)"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Compare SDKs between two apps."""
    result1, result2 = _run_or_exit(lambda: get_sdks_pair(store_id1, store_id2), AppNotFoundError)

    sdks1 = {sdk.domain: sdk for cat_sdks in result1.categories.values() for sdk in cat_sdks}
    sdks2 = {sdk.domain: sdk for cat_sdks in result2.categories.values() for sdk in cat_sdks}

    shared_domains = set(sdks1.keys()) & set(sdks2.keys())
    only1_domains = set(sdks1.keys()) - set(sdks2.keys())
    only2_domains = set(sdks2.keys()) - set(sdks1.keys())

    compare_result = CompareResult(
        app1_name=result1.app_name, app1_store_id=store_id1, app1_sdk_count=len(sdks1),
        app2_name=result2.app_name, app2_store_id=store_id2, app2_sdk_count=len(sdks2),
        shared=[sdks1[d] for d in sorted(shared_domains)],
        only_in_app1=[sdks1[d] for d in sorted(only1_domains)],
        only_in_app2=[sdks2[d] for d in sorted(only2_domains)],
    )

    if output_json:
        print(json.dumps(compare_result.to_dict(), ensure_ascii=False))
        return

    console.print(f"[bold]Comparison: {result1.app_name} vs {result2.app_name}[/bold]")
    console.print(f"  {result1.app_name}: {len(sdks1)} SDKs")
    console.print(f"  {result2.app_name}: {len(sdks2)} SDKs")
    console.print()

    if compare_result.shared:
        _print_sdk_table(f"Shared SDKs ({len(compare_result.shared)})", compare_result.shared)
    if compare_result.only_in_app1:
        _print_sdk_table(f"Only in {result1.app_name} ({len(compare_result.only_in_app1)})", compare_result.only_in_app1)
    if compare_result.only_in_app2:
        _print_sdk_table(f"Only in {result2.app_name} ({len(compare_result.only_in_app2)})", compare_result.only_in_app2)


@app.command()
def info(
    store_id: str = typer.Argument(help="Store ID (iOS: numeric trackId, Android: package name like com.example.app)"),
    platform: Platform = typer.Option(..., help="Target platform (ios/android)"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Get app information (installs, revenue, ratings, etc.). Works with both iOS and Android."""
    result = _run_or_exit(lambda: get_app_info(store_id), AppNotFoundError)

    if output_json:
        print(json.dumps(result.to_dict(), ensure_ascii=False))
        return

    console.print(f"[bold]{result.name}[/bold]")
    console.print(f"Store: {result.store}")
    if result.category:
        console.print(f"Category: {result.category.replace('_', ' ').title()}")
    if result.rating is not None:
        console.print(f"Rating: {result.rating:.2f} ({_format_number(result.rating_count)} ratings)")
    if result.installs is not None:
        console.print(f"Installs: {_format_number(result.installs)} total")
        console.print(f"  Weekly: +{_format_number(result.weekly_installs)} | Monthly: +{_format_number(result.monthly_installs)}")
    if result.weekly_active_users is not None or result.monthly_active_users is not None:
        console.print(f"Active Users: {_format_number(result.weekly_active_users)} weekly / {_format_number(result.monthly_active_users)} monthly")
    if result.monthly_ad_revenue is not None or result.monthly_iap_revenue is not None:
        ad = result.monthly_ad_revenue or 0
        iap = result.monthly_iap_revenue or 0
        total = ad + iap
        if total > 0:
            ad_pct = int(ad / total * 100)
            iap_pct = 100 - ad_pct
            console.print(f"Revenue Est: ${_format_number(total)}/month ({ad_pct}% Ads / {iap_pct}% IAP)")


sdks_app = typer.Typer(help="Browse and rank SDK companies by category.")
app.add_typer(sdks_app, name="list-sdks")


@sdks_app.callback(invoke_without_command=True)
def list_sdks(
    ctx: typer.Context,
    category: SDKCategory = typer.Option(
        None,
        help="Filter by category",
    ),
    platform: Platform = typer.Option(None, help="Target platform (ios/android)"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List all known SDK companies. Use the domain with 'who-uses' to find apps using that SDK."""
    if ctx.invoked_subcommand is not None:
        return

    slug = category.value if category else None
    results = _run_or_exit(lambda: list_sdk_companies(slug))

    if not results:
        console.print("[yellow]No SDKs found[/yellow]")
        return

    if output_json:
        out = {cat: [c.to_dict() for c in companies] for cat, companies in results.items()}
        print(json.dumps(out, ensure_ascii=False))
        return

    for cat_name, companies in results.items():
        console.print(f"[bold]{cat_name}[/bold] ({len(companies)} SDKs)")
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("#", style="dim", width=4)
        table.add_column("Company", style="bold")
        table.add_column("Domain (use with who-uses)", style="green")
        for i, c in enumerate(companies, 1):
            table.add_row(str(i), c.name, c.domain)
        console.print(table)
        console.print()


@sdks_app.command()
def rank(
    category: SDKCategory = typer.Argument(help="SDK category to rank"),
    platform: Platform = typer.Option(..., help="Target platform (ios/android)"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Rank SDK companies by app adoption within a category."""
    results = _run_or_exit(lambda: rank_sdk_companies(category.value))

    if not results:
        console.print("[yellow]No SDKs found for this category[/yellow]")
        return

    if output_json:
        print(json.dumps([r.to_dict() for r in results], ensure_ascii=False))
        return

    display_name = SDK_CATEGORIES.get(category.value, category.value)
    console.print(f"[bold]{display_name} — Ranked by App Adoption[/bold]")
    console.print()

    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("SDK", style="bold")
    table.add_column("Domain", style="green")
    table.add_column("Total Apps", justify="right")
    table.add_column("iOS", justify="right")
    table.add_column("Android", justify="right")
    for i, r in enumerate(results, 1):
        table.add_row(
            str(i),
            r.name,
            r.domain,
            _format_number(r.total_apps),
            _format_number(r.ios_total),
            _format_number(r.android_total),
        )
    console.print(table)
