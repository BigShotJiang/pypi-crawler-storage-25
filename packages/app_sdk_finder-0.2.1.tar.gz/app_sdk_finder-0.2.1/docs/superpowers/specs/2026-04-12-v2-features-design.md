# app-sdk-finder v2 设计文档

## 概述

在现有 `search` 和 `get-sdk` 命令基础上，新增 3 个命令，将工具从"查 SDK"升级为"移动 app 技术情报工具"。

- **数据源**：全部基于 AppGoblin（无新外部依赖）
- **输出**：rich 美化表格（默认） / compact raw JSON（`--json`）
- **版本**：0.2.0

## 新增命令

### 1. `app-sdk-finder who-uses <sdk_domain>`

反向查询：哪些 app 用了某个 SDK。

**参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `sdk_domain` | str (必需) | — | SDK 公司域名，如 `amplitude.com`、`firebase.google.com` |
| `--platform` | `ios` \| `android` \| `all` | `all` | 只显示某平台或全部 |
| `--json` | bool | False | 输出 compact raw JSON |

**数据源**：AppGoblin `/companies/{sdk_domain}` 页面

**提取数据：**
- 公司总览：total_apps、sdk_ios_total_apps、sdk_android_total_apps
- iOS Top 10 apps 列表：name、store_id、developer_name、installs_d30、rating
- Android Top 10 apps 列表：同上

**页面 JSON 结构（SvelteKit 嵌入）：**

```json
{
  "companyDetails": {
    "categories": {
      "all": {
        "total_apps": 5353,
        "sdk_ios_total_apps": 2451,
        "sdk_android_total_apps": 2902
      }
    }
  }
}
```

App 列表嵌入为两个独立的 `apps:[...]` 数组（iOS 和 Android 各一个），每个 app 对象：

```json
{
  "company_domain": "amplitude.com",
  "store": "Apple App Store",
  "name": "Bible",
  "store_id": "282935706",
  "developer_name": "Life.Church",
  "rank": 1,
  "installs_d30": 5293733,
  "sdk": true,
  "rating": 5
}
```

**表格输出示例：**

```
Amplitude (amplitude.com)
Total: 5,353 apps (2,451 iOS / 2,902 Android)

iOS Top 10:
┌────┬────────────────────┬──────────────┬─────────────────┐
│  # │ App Name           │ Developer    │ Monthly Installs│
├────┼────────────────────┼──────────────┼─────────────────┤
│  1 │ Bible              │ Life.Church  │ 5,293,733       │
│  2 │ Life360            │ Life360      │ 1,883,750       │
└────┴────────────────────┴──────────────┴─────────────────┘

Android Top 10:
┌────┬────────────────────┬──────────────┬─────────────────┐
│  # │ App Name           │ Developer    │ Monthly Installs│
├────┼────────────────────┼──────────────┼─────────────────┤
│  1 │ Dropbox            │ Dropbox Inc. │ 43,100,000      │
└────┴────────────────────┴──────────────┴─────────────────┘
```

**JSON 输出示例：**

```json
{"sdk_domain":"amplitude.com","total_apps":5353,"ios_total":2451,"android_total":2902,"ios_top_apps":[{"name":"Bible","store_id":"282935706","developer":"Life.Church","monthly_installs":5293733}],"android_top_apps":[{"name":"Dropbox","store_id":"com.dropbox.android","developer":"Dropbox Inc.","monthly_installs":43100000}]}
```

### 2. `app-sdk-finder compare <store_id1> <store_id2>`

并排对比两个 app 的 SDK 技术栈差异。

**参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `store_id1` | str (必需) | — | 第一个 app 的 store ID |
| `store_id2` | str (必需) | — | 第二个 app 的 store ID |
| `--json` | bool | False | 输出 compact raw JSON |

**实现**：复用现有 `appgoblin.get_sdks()` 两次，然后计算集合差异。

**对比逻辑：**
- shared：两个 app 都有的 SDK（按 company_domain 匹配）
- only_in_first：仅第一个 app 有的 SDK
- only_in_second：仅第二个 app 有的 SDK

**表格输出示例：**

```
Comparison: TikTok vs BeReal

              TikTok              BeReal
Platform      ios                 ios
SDK Count     14                  22

Shared SDKs (8):
  Company              Category
  Google               Ad Networks
  Firebase             Analytics: Product
  Stripe               Business Tools
  ...

Only in TikTok (6):
  Company              Category
  ByteDance            Ad Networks
  VK                   Ad Networks
  AppsFlyer            Analytics: Attribution
  ...

Only in BeReal (14):
  Company              Category
  Amplitude            Analytics: Product
  Datadog              Development Tools
  Adjust               Analytics: Attribution
  ...
```

**JSON 输出示例：**

```json
{"app1":{"name":"TikTok","store_id":"835599320","sdk_count":14},"app2":{"name":"BeReal","store_id":"1459645446","sdk_count":22},"shared":[{"name":"Google","domain":"google.com","category":"Ad Networks"}],"only_in_app1":[{"name":"ByteDance","domain":"bytedance.com","category":"Ad Networks"}],"only_in_app2":[{"name":"Amplitude","domain":"amplitude.com","category":"Analytics: Product"}]}
```

### 3. `app-sdk-finder info <store_id>`

获取 app 的基础信息（不只是 SDK）。

**参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `store_id` | str (必需) | — | iOS trackId 或 Android 包名 |
| `--platform` | `ios` \| `android` | `ios` | 目标平台 |
| `--json` | bool | False | 输出 compact raw JSON |

**数据源**：AppGoblin `/apps/{store_id}` 页面中的 `myapp` 对象。

**提取字段：**

```json
{
  "name": "TikTok - Videos, Shop & LIVE",
  "store_id": "835599320",
  "store": "Apple App Store",
  "category": "entertainment",
  "rating": 4.73,
  "rating_count": 23366292,
  "installs": 1168314600,
  "weekly_active_users": 29938420,
  "monthly_active_users": 52244809,
  "monthly_ad_revenue": 4213289,
  "monthly_iap_revenue": 1271639.9,
  "installs_sum_1w": 19656,
  "installs_sum_4w": 745400
}
```

**表格输出示例：**

```
TikTok - Videos, Shop & LIVE
Store: Apple App Store
Category: Entertainment
Rating: 4.73 (23.4M ratings)
Installs: 1.2B total
  Weekly: +19.7K | Monthly: +745.4K
Active Users: 29.9M weekly / 52.2M monthly
Revenue Est: $5.5M/month (77% Ads / 23% IAP)
Developer: TikTok Ltd.
```

**JSON 输出示例：**

```json
{"name":"TikTok - Videos, Shop & LIVE","store_id":"835599320","store":"Apple App Store","category":"entertainment","rating":4.73,"rating_count":23366292,"installs":1168314600,"weekly_installs":19656,"monthly_installs":745400,"weekly_active_users":29938420,"monthly_active_users":52244809,"monthly_ad_revenue":4213289,"monthly_iap_revenue":1271639.9}
```

## 新增数据模型

```python
@dataclass
class CompanyApp:
    name: str
    store_id: str
    developer: str
    monthly_installs: int
    store: str  # "Apple App Store" | "Google Play"

@dataclass
class WhoUsesResult:
    sdk_domain: str
    total_apps: int
    ios_total: int
    android_total: int
    ios_top_apps: list[CompanyApp]
    android_top_apps: list[CompanyApp]

@dataclass
class CompareResult:
    app1_name: str
    app1_store_id: str
    app1_sdk_count: int
    app2_name: str
    app2_store_id: str
    app2_sdk_count: int
    shared: list[SDKEntry]       # 复用现有 SDKEntry，加 category 字段
    only_in_app1: list[SDKEntry]
    only_in_app2: list[SDKEntry]

@dataclass
class AppInfo:
    name: str
    store_id: str
    store: str
    category: str
    rating: float | None
    rating_count: int | None
    installs: int | None
    weekly_installs: int | None
    monthly_installs: int | None
    weekly_active_users: int | None
    monthly_active_users: int | None
    monthly_ad_revenue: float | None
    monthly_iap_revenue: float | None
```

## 现有代码变更

### models.py
- 新增 `CompanyApp`、`WhoUsesResult`、`CompareResult`、`AppInfo` 数据类
- `SDKEntry` 新增 `category: str | None` 字段（向后兼容，默认 None）

### appgoblin.py
- 新增 `get_company_apps(sdk_domain: str) -> WhoUsesResult`：请求 `/companies/{domain}` 页面，提取公司统计和 Top apps
- 新增 `get_app_info(store_id: str) -> AppInfo`：从现有页面请求中提取 `myapp` 对象
- 现有 `get_sdks()` 返回的 `SDKEntry` 需要包含 category 信息（从 company_categories 的 key 映射到 companyTypes.types 的 name）

### cli.py
- 新增 `who_uses` 命令
- 新增 `compare` 命令
- 新增 `info` 命令

## 测试

### test_appgoblin.py（新增）
- 解析 company 页面 → 正确返回 WhoUsesResult（含 iOS/Android top apps）
- company 页面无 apps 数据 → 返回空列表
- 解析 app info → 正确返回 AppInfo 所有字段
- app info 部分字段缺失 → 返回 None 而非报错

### test_cli.py（新增）
- `who-uses` 表格输出包含预期列
- `who-uses --json` 输出合法 JSON
- `who-uses --platform ios` 只显示 iOS
- `compare` 表格输出包含 shared/only_in 分区
- `compare --json` 输出合法 JSON
- `info` 表格输出包含预期字段
- `info --json` 输出合法 JSON
- SDK domain 不存在 → 提示 "Company not found on AppGoblin"

### conftest.py
- 新增 AppGoblin company 页面 fixture
- 新增 AppGoblin app info 页面 fixture

## 依赖

无新增依赖。

## 错误处理

| 场景 | 处理方式 |
|------|----------|
| SDK domain 在 AppGoblin 上不存在 | 提示 "Company not found on AppGoblin"，退出码 1 |
| 网络请求失败 | 打印错误信息，退出码 1 |
| compare 中某个 app 无 SDK 数据 | 正常对比，该 app SDK 数量为 0 |

## 安装与使用

```bash
# 反向查询
app-sdk-finder who-uses amplitude.com
app-sdk-finder who-uses firebase.google.com --platform ios
app-sdk-finder who-uses adjust.com --json

# 对比
app-sdk-finder compare 835599320 1459645446
app-sdk-finder compare 835599320 1459645446 --json

# App 信息
app-sdk-finder info 835599320
app-sdk-finder info 835599320 --json
```
