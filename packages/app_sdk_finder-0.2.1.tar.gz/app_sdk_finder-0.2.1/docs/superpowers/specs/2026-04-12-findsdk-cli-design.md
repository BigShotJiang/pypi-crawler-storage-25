# app-sdk-finder CLI 设计文档

## 概述

一个 Python CLI 工具，通过爬取 [AppGoblin](https://appgoblin.info) 网站，查询 iOS/Android app 使用了哪些 SDK。

- **包名**：app-sdk-finder（PyPI）
- **CLI 命令名**：app-sdk-finder
- **环境管理**：uv
- **CLI 框架**：typer
- **输出**：rich 美化表格（默认） / compact raw JSON（`--json`）
- **平台**：先实现 iOS，预留 Android 接口
- **测试**：pytest，每个功能模块有单测
- **发布**：PyPI

## 架构

### 数据流

```
用户输入 app 名字
    ↓
search 命令 → iTunes Search API (iOS) / Google Play (Android, 预留)
    ↓
返回匹配 app 列表（含 store_id）
    ↓
用户选取 store_id
    ↓
get-sdk 命令 → 请求 appgoblin.info/apps/{store_id}
    ↓
解析 SvelteKit 嵌入的 JSON 数据
    ↓
输出 SDK 列表（表格 / JSON）
```

### 项目结构

```
findSDK/
├── pyproject.toml
├── src/
│   └── app_sdk_finder/
│       ├── __init__.py
│       ├── cli.py            # Typer CLI 入口
│       ├── models.py         # 数据模型
│       ├── appgoblin.py      # AppGoblin 页面解析（iOS/Android 通用）
│       ├── itunes.py         # iOS 搜索：iTunes Search API
│       └── google_play.py    # Android 搜索（预留，抛 NotImplementedError）
├── tests/
│   ├── conftest.py           # 共享 fixtures（mock HTTP 响应等）
│   ├── test_itunes.py        # iTunes Search API 解析测试
│   ├── test_appgoblin.py     # AppGoblin 页面解析测试
│   ├── test_models.py        # 数据模型序列化测试
│   └── test_cli.py           # CLI 命令集成测试（typer.testing.CliRunner）
```

## 命令设计

### `app-sdk-finder search <app_name>`

搜索 app，返回匹配列表。

**参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `app_name` | str (必需) | — | 搜索关键词 |
| `--platform` | `ios` \| `android` | `ios` | 目标平台 |
| `--country` | str | `us` | 国家/地区代码 |
| `--limit` | int | 10 | 最大返回数量 |
| `--json` | bool | False | 输出 compact raw JSON |

**iOS 实现：**
- 调用 `https://itunes.apple.com/search?term={app_name}&entity=software&limit={limit}&country={country}`
- 提取字段：`trackName`, `artistName`, `trackId`, `bundleId`, `averageUserRating`, `artworkUrl60`

**Android 实现（预留）：**
- 调用 google-play-scraper 或类似库搜索
- 暂时抛出 NotImplementedError 并提示 "Android support coming soon"

**表格输出示例（rich 美化）：**
```
  #  App Name              Developer        Store ID     Rating
  1  WhatsApp Messenger    WhatsApp Inc.    310633997    4.69
  2  WhatsApp Business     WhatsApp Inc.    1386412985   4.70
```

**JSON 输出示例（`--json`）：**
```json
[{"name":"WhatsApp Messenger","developer":"WhatsApp Inc.","store_id":"310633997","bundle_id":"net.whatsapp.WhatsApp","rating":4.69,"platform":"ios"}]
```

### `app-sdk-finder get-sdk <store_id>`

根据 store_id 获取 app 的 SDK 列表。

**参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `store_id` | str (必需) | — | iOS: trackId (数字)；Android: 包名 |
| `--platform` | `ios` \| `android` | `ios` | 目标平台 |
| `--json` | bool | False | 输出 compact raw JSON |

**实现：**
1. 请求 `https://appgoblin.info/apps/{store_id}`
2. 从 HTML 中提取 SvelteKit `<script>` 标签内嵌入的 JSON 数据
3. 解析 `appSDKsOverview.company_categories` 获取 SDK 列表
4. 解析 `companyTypes.types` 获取类别名称映射

**AppGoblin 页面 JSON 结构：**

```json
{
  "appSDKsOverview": {
    "company_categories": {
      "business-tools": [
        {
          "company_name": "Stripe",
          "company_domain": "stripe.com",
          "company_logo_url": "company-logos/stripe.com/logo_200x200.jpeg"
        }
      ],
      "development-tools": [
        {
          "company_name": "Google",
          "company_domain": "google.com",
          "company_logo_url": "company-logos/google.com/logo_200x200.jpeg"
        }
      ]
    }
  },
  "companyTypes": {
    "types": [
      {"id": 1, "name": "Ad Networks", "url_slug": "ad-networks"},
      {"id": 2, "name": "Analytics: Attribution", "url_slug": "ad-attribution"},
      {"id": 3, "name": "Analytics: Product", "url_slug": "product-analytics"},
      {"id": 4, "name": "Development Tools", "url_slug": "development-tools"},
      {"id": 5, "name": "Business Tools", "url_slug": "business-tools"},
      {"id": 6, "name": "Mediation", "url_slug": "mediation"}
    ]
  }
}
```

**表格输出示例（rich 美化）：**
```
App: Instagram (835599320)
Platform: iOS
SDK Scan: 2026-03-24

┌─────────────────────┬──────────────────────┬──────────────────┐
│ Category            │ Company              │ Domain           │
├─────────────────────┼──────────────────────┼──────────────────┤
│ Business Tools      │ Line                 │ linepluscorp.com │
│                     │ Twitter X            │ x.com            │
│                     │ Stripe               │ stripe.com       │
├─────────────────────┼──────────────────────┼──────────────────┤
│ Development Tools   │ Airbnb Engineering   │ airbnb.io        │
│                     │ Google               │ google.com       │
└─────────────────────┴──────────────────────┴──────────────────┘
```

**JSON 输出示例（`--json`）：**
```json
{"app_name":"Instagram","store_id":"835599320","platform":"ios","sdk_scan_date":"2026-03-24","categories":{"Business Tools":[{"name":"Stripe","domain":"stripe.com"}],"Development Tools":[{"name":"Google","domain":"google.com"}]}}
```

## 数据模型

```python
@dataclass
class AppSearchResult:
    name: str
    developer: str
    store_id: str
    bundle_id: str | None
    rating: float | None
    platform: str  # "ios" | "android"

@dataclass
class SDKEntry:
    name: str
    domain: str

@dataclass
class AppSDKResult:
    app_name: str
    store_id: str
    platform: str
    sdk_scan_date: str | None
    categories: dict[str, list[SDKEntry]]  # category_name -> SDKs
```

## 测试策略

所有网络请求通过 mock 测试，不依赖外部服务。

### test_itunes.py
- 解析正常 iTunes API 响应 → 正确返回 `AppSearchResult` 列表
- 空结果响应 → 返回空列表
- 异常响应（非 JSON、HTTP 错误） → 抛出合适异常

### test_appgoblin.py
- 解析包含完整 SDK 数据的 HTML → 正确返回 `AppSDKResult`
- 解析无 SDK 数据的 HTML（"No known SDKs"） → 返回空 categories
- 解析异常 HTML（无 SvelteKit 脚本） → 抛出合适异常

### test_models.py
- `AppSearchResult` → JSON 序列化/反序列化
- `AppSDKResult` → JSON 序列化/反序列化
- 边界值：rating 为 None、categories 为空 dict

### test_cli.py
- `search` 命令表格输出包含预期列
- `search --json` 输出合法 JSON
- `get-sdk` 命令表格输出包含预期 SDK
- `get-sdk --json` 输出合法 JSON
- `--platform android` 提示 coming soon
- 无结果场景提示正确信息

### conftest.py
- 提供 iTunes API 响应 fixture（从真实响应采样）
- 提供 AppGoblin HTML 响应 fixture（从真实页面采样）
- httpx mock transport fixture

## 依赖

```toml
[project]
name = "app-sdk-finder"
version = "0.1.0"
description = "CLI tool to find SDKs used by iOS/Android apps via AppGoblin"
requires-python = ">=3.11"
dependencies = [
    "typer>=0.9",
    "httpx>=0.27",
    "rich>=13",
    "beautifulsoup4>=4.12",
]

[project.scripts]
app-sdk-finder = "app_sdk_finder.cli:app"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[dependency-groups]
dev = [
    "pytest>=8",
    "pytest-httpx>=0.30",
]
```

## 错误处理

| 场景 | 处理方式 |
|------|----------|
| 网络请求失败 | 打印错误信息，退出码 1 |
| App 在 AppGoblin 上未找到 | 提示 "App not found on AppGoblin" |
| 未检测到 SDK | 提示 "No SDKs detected for this app" |
| Android platform 暂未实现 | 提示 "Android support coming soon"，退出码 0 |
| JSON 解析失败 | 提示页面结构可能已变更，退出码 1 |

## PyPI 发布

使用 uv 构建和发布：

```bash
uv build
uv publish
```

需要预先配置 PyPI API token（通过 `UV_PUBLISH_TOKEN` 环境变量或 `--token` 参数）。

## 安装与使用

```bash
# 从 PyPI 安装
uv pip install app-sdk-finder

# 或开发模式安装
uv pip install -e .

# 搜索 app
app-sdk-finder search "instagram" --platform ios --country us
app-sdk-finder search "instagram" --json

# 获取 SDK
app-sdk-finder get-sdk 835599320 --platform ios
app-sdk-finder get-sdk 835599320 --json

# Android（预留）
app-sdk-finder search "whatsapp" --platform android
# → "Android support coming soon"
```
