# app-sdk-finder Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Python CLI tool (`app-sdk-finder`) that searches iOS apps by name and retrieves their SDK usage from AppGoblin.

**Architecture:** Two Typer commands (`search`, `get-sdk`). `search` calls iTunes Search API, `get-sdk` scrapes AppGoblin's SvelteKit-embedded JavaScript data. Output as rich tables (default) or compact JSON (`--json`).

**Tech Stack:** Python 3.11+, uv, typer, httpx, rich, beautifulsoup4, pytest, pytest-httpx

---

## File Map

| File | Responsibility |
|------|---------------|
| `pyproject.toml` | Package metadata, dependencies, CLI entry point |
| `src/app_sdk_finder/__init__.py` | Package version |
| `src/app_sdk_finder/models.py` | Dataclasses: `AppSearchResult`, `SDKEntry`, `AppSDKResult` |
| `src/app_sdk_finder/itunes.py` | `search_apps(term, country, limit) -> list[AppSearchResult]` |
| `src/app_sdk_finder/appgoblin.py` | `get_sdks(store_id) -> AppSDKResult` — fetch + parse |
| `src/app_sdk_finder/google_play.py` | Stub: `search_apps()` raises `NotImplementedError` |
| `src/app_sdk_finder/cli.py` | Typer app with `search` and `get-sdk` commands |
| `tests/conftest.py` | Shared fixtures: sample HTML, sample API JSON |
| `tests/test_models.py` | Model serialization tests |
| `tests/test_itunes.py` | iTunes response parsing tests |
| `tests/test_appgoblin.py` | AppGoblin HTML parsing tests |
| `tests/test_cli.py` | CLI integration tests via CliRunner |

---

### Task 1: Project Scaffold

**Files:**
- Create: `pyproject.toml`
- Create: `src/app_sdk_finder/__init__.py`

- [ ] **Step 1: Initialize uv project**

```bash
cd /Users/proalex/Desktop/Project/findSDK
uv init --lib --name app-sdk-finder
```

- [ ] **Step 2: Replace pyproject.toml with correct config**

```toml
[project]
name = "app-sdk-finder"
version = "0.1.0"
description = "CLI tool to find SDKs used by iOS/Android apps via AppGoblin"
requires-python = ">=3.11"
dependencies = [
    "typer>=0.9",
    "httpx>=0.27",
    "rich>=13",
    "beautifulsoup4>=4.12",
]

[project.scripts]
app-sdk-finder = "app_sdk_finder.cli:app"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/app_sdk_finder"]

[dependency-groups]
dev = [
    "pytest>=8",
    "pytest-httpx>=0.35",
]
```

- [ ] **Step 3: Create __init__.py**

```python
# src/app_sdk_finder/__init__.py
__version__ = "0.1.0"
```

- [ ] **Step 4: Install dependencies**

```bash
cd /Users/proalex/Desktop/Project/findSDK
uv sync
```

Expected: dependencies install successfully.

- [ ] **Step 5: Commit**

```bash
git init
git add pyproject.toml src/app_sdk_finder/__init__.py uv.lock .python-version
git commit -m "chore: scaffold app-sdk-finder project with uv"
```

---

### Task 2: Data Models + Tests

**Files:**
- Create: `src/app_sdk_finder/models.py`
- Create: `tests/test_models.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/test_models.py
import json

from app_sdk_finder.models import AppSearchResult, AppSDKResult, SDKEntry


def test_app_search_result_to_dict():
    result = AppSearchResult(
        name="WhatsApp Messenger",
        developer="WhatsApp Inc.",
        store_id="310633997",
        bundle_id="net.whatsapp.WhatsApp",
        rating=4.69,
        platform="ios",
    )
    d = result.to_dict()
    assert d == {
        "name": "WhatsApp Messenger",
        "developer": "WhatsApp Inc.",
        "store_id": "310633997",
        "bundle_id": "net.whatsapp.WhatsApp",
        "rating": 4.69,
        "platform": "ios",
    }


def test_app_search_result_to_dict_none_fields():
    result = AppSearchResult(
        name="Test App",
        developer="Dev",
        store_id="123",
        bundle_id=None,
        rating=None,
        platform="ios",
    )
    d = result.to_dict()
    assert d["bundle_id"] is None
    assert d["rating"] is None


def test_sdk_entry_to_dict():
    entry = SDKEntry(name="Google", domain="google.com")
    assert entry.to_dict() == {"name": "Google", "domain": "google.com"}


def test_app_sdk_result_to_dict():
    result = AppSDKResult(
        app_name="Instagram",
        store_id="835599320",
        platform="ios",
        sdk_scan_date="2026-03-24",
        categories={
            "Business Tools": [
                SDKEntry(name="Stripe", domain="stripe.com"),
            ],
        },
    )
    d = result.to_dict()
    assert d["app_name"] == "Instagram"
    assert d["categories"]["Business Tools"] == [
        {"name": "Stripe", "domain": "stripe.com"}
    ]


def test_app_sdk_result_to_dict_empty_categories():
    result = AppSDKResult(
        app_name="SomeApp",
        store_id="999",
        platform="ios",
        sdk_scan_date=None,
        categories={},
    )
    d = result.to_dict()
    assert d["categories"] == {}
    assert d["sdk_scan_date"] is None


def test_app_sdk_result_to_json_compact():
    result = AppSDKResult(
        app_name="Test",
        store_id="1",
        platform="ios",
        sdk_scan_date=None,
        categories={},
    )
    j = json.dumps(result.to_dict(), ensure_ascii=False)
    assert "\n" not in j
    parsed = json.loads(j)
    assert parsed["app_name"] == "Test"
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
cd /Users/proalex/Desktop/Project/findSDK
uv run pytest tests/test_models.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'app_sdk_finder.models'`

- [ ] **Step 3: Implement models**

```python
# src/app_sdk_finder/models.py
from dataclasses import dataclass, asdict


@dataclass
class AppSearchResult:
    name: str
    developer: str
    store_id: str
    bundle_id: str | None
    rating: float | None
    platform: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class SDKEntry:
    name: str
    domain: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class AppSDKResult:
    app_name: str
    store_id: str
    platform: str
    sdk_scan_date: str | None
    categories: dict[str, list[SDKEntry]]

    def to_dict(self) -> dict:
        return {
            "app_name": self.app_name,
            "store_id": self.store_id,
            "platform": self.platform,
            "sdk_scan_date": self.sdk_scan_date,
            "categories": {
                cat: [sdk.to_dict() for sdk in sdks]
                for cat, sdks in self.categories.items()
            },
        }
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/test_models.py -v
```

Expected: all 6 tests PASS.

- [ ] **Step 5: Commit**

```bash
git add src/app_sdk_finder/models.py tests/test_models.py
git commit -m "feat: add data models with serialization"
```

---

### Task 3: iTunes Search Client + Tests

**Files:**
- Create: `src/app_sdk_finder/itunes.py`
- Create: `tests/conftest.py`
- Create: `tests/test_itunes.py`

- [ ] **Step 1: Create conftest with iTunes fixture**

```python
# tests/conftest.py
import pytest

ITUNES_RESPONSE_JSON = {
    "resultCount": 2,
    "results": [
        {
            "trackName": "WhatsApp Messenger",
            "artistName": "WhatsApp Inc.",
            "trackId": 310633997,
            "bundleId": "net.whatsapp.WhatsApp",
            "averageUserRating": 4.69,
        },
        {
            "trackName": "WhatsApp Business",
            "artistName": "WhatsApp Inc.",
            "trackId": 1386412985,
            "bundleId": "net.whatsapp.WhatsAppSMB",
            "averageUserRating": 4.70,
        },
    ],
}

ITUNES_EMPTY_RESPONSE_JSON = {"resultCount": 0, "results": []}


@pytest.fixture
def itunes_response():
    return ITUNES_RESPONSE_JSON


@pytest.fixture
def itunes_empty_response():
    return ITUNES_EMPTY_RESPONSE_JSON
```

- [ ] **Step 2: Write failing tests**

```python
# tests/test_itunes.py
import httpx
import pytest

from app_sdk_finder.itunes import search_apps
from app_sdk_finder.models import AppSearchResult


def test_search_apps_parses_response(httpx_mock, itunes_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=whatsapp&entity=software&limit=10&country=us",
        json=itunes_response,
    )
    results = search_apps("whatsapp")
    assert len(results) == 2
    assert results[0] == AppSearchResult(
        name="WhatsApp Messenger",
        developer="WhatsApp Inc.",
        store_id="310633997",
        bundle_id="net.whatsapp.WhatsApp",
        rating=4.69,
        platform="ios",
    )
    assert results[1].store_id == "1386412985"


def test_search_apps_empty_results(httpx_mock, itunes_empty_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=nonexistentapp&entity=software&limit=10&country=us",
        json=itunes_empty_response,
    )
    results = search_apps("nonexistentapp")
    assert results == []


def test_search_apps_custom_params(httpx_mock, itunes_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=whatsapp&entity=software&limit=5&country=cn",
        json=itunes_response,
    )
    results = search_apps("whatsapp", country="cn", limit=5)
    assert len(results) == 2


def test_search_apps_http_error(httpx_mock):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=test&entity=software&limit=10&country=us",
        status_code=500,
    )
    with pytest.raises(httpx.HTTPStatusError):
        search_apps("test")
```

- [ ] **Step 3: Run tests to verify they fail**

```bash
uv run pytest tests/test_itunes.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'app_sdk_finder.itunes'`

- [ ] **Step 4: Implement iTunes client**

```python
# src/app_sdk_finder/itunes.py
import httpx

from app_sdk_finder.models import AppSearchResult

ITUNES_SEARCH_URL = "https://itunes.apple.com/search"


def search_apps(
    term: str,
    country: str = "us",
    limit: int = 10,
) -> list[AppSearchResult]:
    response = httpx.get(
        ITUNES_SEARCH_URL,
        params={
            "term": term,
            "entity": "software",
            "limit": limit,
            "country": country,
        },
    )
    response.raise_for_status()
    data = response.json()
    return [
        AppSearchResult(
            name=item["trackName"],
            developer=item["artistName"],
            store_id=str(item["trackId"]),
            bundle_id=item.get("bundleId"),
            rating=item.get("averageUserRating"),
            platform="ios",
        )
        for item in data.get("results", [])
    ]
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
uv run pytest tests/test_itunes.py -v
```

Expected: all 4 tests PASS.

- [ ] **Step 6: Commit**

```bash
git add src/app_sdk_finder/itunes.py tests/conftest.py tests/test_itunes.py
git commit -m "feat: add iTunes Search API client"
```

---

### Task 4: AppGoblin Parser + Tests

**Files:**
- Create: `src/app_sdk_finder/appgoblin.py`
- Modify: `tests/conftest.py`
- Create: `tests/test_appgoblin.py`

- [ ] **Step 1: Add AppGoblin HTML fixtures to conftest**

Append to `tests/conftest.py`:

```python
# Sampled from real AppGoblin page — the SvelteKit init embeds JS objects (not JSON)
# Keys are unquoted, strings use double quotes
APPGOBLIN_HTML_WITH_SDKS = """<!DOCTYPE html><html><head></head><body>
<script>
{
    __sveltekit_abc = { base: "" };
    const element = document.currentScript.parentElement;
    Promise.all([]).then(([kit, app]) => {
        kit.start(app, element, {
            node_ids: [0, 7, 34],
            data: [{type:"data",data:{user:null}},{type:"data",data:{myapp:{id:123,name:"TestApp - Great App",store_id:"835599320",store:"Apple App Store",sdk_last_crawled:"2026-03-24",sdk_last_crawl_result:1},myhistory:{},appSDKsOverview:{company_categories:{"business-tools":[{company_name:"Stripe",company_domain:"stripe.com",company_logo_url:"logo.jpeg"},{company_name:"Twitter X",company_domain:"x.com",company_logo_url:"logo.jpeg"}],"development-tools":[{company_name:"Google",company_domain:"google.com",company_logo_url:"logo.jpeg"}],"ad-networks":[{company_name:"Facebook",company_domain:"facebook.com",company_logo_url:"logo.jpeg"}]}},companyTypes:{types:[{id:1,name:"Ad Networks",url_slug:"ad-networks"},{id:4,name:"Development Tools",url_slug:"development-tools"},{id:5,name:"Business Tools",url_slug:"business-tools"}]}}},{type:"data",data:{}}],
        });
    });
}
</script>
</body></html>"""

APPGOBLIN_HTML_NO_SDKS = """<!DOCTYPE html><html><head></head><body>
<script>
{
    __sveltekit_abc = { base: "" };
    const element = document.currentScript.parentElement;
    Promise.all([]).then(([kit, app]) => {
        kit.start(app, element, {
            node_ids: [0, 7, 34],
            data: [{type:"data",data:{user:null}},{type:"data",data:{myapp:{id:456,name:"EmptyApp",store_id:"999999",store:"Apple App Store",sdk_last_crawled:"2026-01-01",sdk_last_crawl_result:1},myhistory:{},appSDKsOverview:{company_categories:{}},companyTypes:{types:[{id:1,name:"Ad Networks",url_slug:"ad-networks"}]}}},{type:"data",data:{}}],
        });
    });
}
</script>
</body></html>"""

APPGOBLIN_HTML_NOT_FOUND = """<!DOCTYPE html><html><head></head><body>
<h1>404 Not Found</h1>
</body></html>"""


@pytest.fixture
def appgoblin_html_with_sdks():
    return APPGOBLIN_HTML_WITH_SDKS


@pytest.fixture
def appgoblin_html_no_sdks():
    return APPGOBLIN_HTML_NO_SDKS


@pytest.fixture
def appgoblin_html_not_found():
    return APPGOBLIN_HTML_NOT_FOUND
```

- [ ] **Step 2: Write failing tests**

```python
# tests/test_appgoblin.py
import httpx
import pytest

from app_sdk_finder.appgoblin import get_sdks, parse_sdks_from_html, AppNotFoundError
from app_sdk_finder.models import SDKEntry


def test_parse_sdks_from_html(appgoblin_html_with_sdks):
    result = parse_sdks_from_html(appgoblin_html_with_sdks, "835599320")
    assert result.app_name == "TestApp - Great App"
    assert result.store_id == "835599320"
    assert result.platform == "ios"
    assert result.sdk_scan_date == "2026-03-24"
    assert "Business Tools" in result.categories
    assert "Development Tools" in result.categories
    assert "Ad Networks" in result.categories
    assert len(result.categories["Business Tools"]) == 2
    assert result.categories["Business Tools"][0] == SDKEntry(
        name="Stripe", domain="stripe.com"
    )
    assert result.categories["Development Tools"][0] == SDKEntry(
        name="Google", domain="google.com"
    )


def test_parse_sdks_from_html_no_sdks(appgoblin_html_no_sdks):
    result = parse_sdks_from_html(appgoblin_html_no_sdks, "999999")
    assert result.app_name == "EmptyApp"
    assert result.categories == {}


def test_parse_sdks_from_html_not_found(appgoblin_html_not_found):
    with pytest.raises(AppNotFoundError):
        parse_sdks_from_html(appgoblin_html_not_found, "000000")


def test_get_sdks_success(httpx_mock, appgoblin_html_with_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_html_with_sdks,
    )
    result = get_sdks("835599320")
    assert result.app_name == "TestApp - Great App"
    assert len(result.categories) == 3


def test_get_sdks_http_404(httpx_mock):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/000000",
        status_code=404,
    )
    with pytest.raises(AppNotFoundError):
        get_sdks("000000")
```

- [ ] **Step 3: Run tests to verify they fail**

```bash
uv run pytest tests/test_appgoblin.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'app_sdk_finder.appgoblin'`

- [ ] **Step 4: Implement AppGoblin parser**

The page embeds data as JavaScript objects inside a SvelteKit init script. Keys are unquoted identifiers, so we can't use `json.loads` directly. Strategy:

1. Find `appSDKsOverview:{company_categories:{...}}` via regex
2. Find `companyTypes:{types:[...]}` via regex
3. Convert JS object notation to valid JSON (add quotes to keys)
4. Parse with `json.loads`

```python
# src/app_sdk_finder/appgoblin.py
import json
import re

import httpx

from app_sdk_finder.models import AppSDKResult, SDKEntry

APPGOBLIN_BASE_URL = "https://appgoblin.info/apps"


class AppNotFoundError(Exception):
    pass


def _extract_js_object(html: str, prefix: str) -> str | None:
    idx = html.find(prefix)
    if idx < 0:
        return None
    start = idx + len(prefix)
    brace_count = 0
    end = start
    for i in range(start, min(start + 10000, len(html))):
        if html[i] == "{" or html[i] == "[":
            brace_count += 1
        elif html[i] == "}" or html[i] == "]":
            brace_count -= 1
            if brace_count == 0:
                end = i + 1
                break
    return html[start:end]


def _js_to_json(js_str: str) -> str:
    result = re.sub(r"(?<=[{,])\s*(\w+)\s*:", r'"\1":', js_str)
    result = result.replace(":null", ":null")
    return result


def _slug_to_display_name(slug: str, types_map: dict[str, str]) -> str:
    return types_map.get(slug, slug.replace("-", " ").title())


def parse_sdks_from_html(html: str, store_id: str) -> AppSDKResult:
    name_match = re.search(r'name:"([^"]+)"', html)
    if name_match is None:
        raise AppNotFoundError(f"App not found: {store_id}")

    store_match = re.search(r'store:"([^"]*)"', html)
    platform = "ios" if store_match and "Apple" in store_match.group(1) else "android"

    date_match = re.search(r'sdk_last_crawled:"([^"]+)"', html)
    sdk_scan_date = date_match.group(1) if date_match else None

    types_map: dict[str, str] = {}
    types_raw = _extract_js_object(html, "types:")
    if types_raw:
        try:
            types_list = json.loads(_js_to_json(types_raw))
            types_map = {t["url_slug"]: t["name"] for t in types_list}
        except (json.JSONDecodeError, KeyError):
            pass

    categories: dict[str, list[SDKEntry]] = {}
    cc_raw = _extract_js_object(html, "company_categories:")
    if cc_raw:
        try:
            cc_data = json.loads(_js_to_json(cc_raw))
            for slug, companies in cc_data.items():
                if not companies:
                    continue
                display_name = _slug_to_display_name(slug, types_map)
                categories[display_name] = [
                    SDKEntry(
                        name=c["company_name"],
                        domain=c["company_domain"],
                    )
                    for c in companies
                ]
        except (json.JSONDecodeError, KeyError):
            pass

    return AppSDKResult(
        app_name=name_match.group(1),
        store_id=store_id,
        platform=platform,
        sdk_scan_date=sdk_scan_date,
        categories=categories,
    )


def get_sdks(store_id: str) -> AppSDKResult:
    response = httpx.get(f"{APPGOBLIN_BASE_URL}/{store_id}")
    if response.status_code == 404:
        raise AppNotFoundError(f"App not found on AppGoblin: {store_id}")
    response.raise_for_status()
    return parse_sdks_from_html(response.text, store_id)
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
uv run pytest tests/test_appgoblin.py -v
```

Expected: all 5 tests PASS.

- [ ] **Step 6: Commit**

```bash
git add src/app_sdk_finder/appgoblin.py tests/conftest.py tests/test_appgoblin.py
git commit -m "feat: add AppGoblin HTML parser for SDK extraction"
```

---

### Task 5: Google Play Stub

**Files:**
- Create: `src/app_sdk_finder/google_play.py`

- [ ] **Step 1: Create stub**

```python
# src/app_sdk_finder/google_play.py
from app_sdk_finder.models import AppSearchResult


def search_apps(
    term: str,
    country: str = "us",
    limit: int = 10,
) -> list[AppSearchResult]:
    raise NotImplementedError("Android support coming soon")
```

- [ ] **Step 2: Commit**

```bash
git add src/app_sdk_finder/google_play.py
git commit -m "feat: add Google Play search stub"
```

---

### Task 6: CLI Commands + Tests

**Files:**
- Create: `src/app_sdk_finder/cli.py`
- Create: `tests/test_cli.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/test_cli.py
import json

from typer.testing import CliRunner

from app_sdk_finder.cli import app
from tests.conftest import ITUNES_RESPONSE_JSON, APPGOBLIN_HTML_WITH_SDKS

runner = CliRunner()


def test_search_table_output(httpx_mock, itunes_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=whatsapp&entity=software&limit=10&country=us",
        json=itunes_response,
    )
    result = runner.invoke(app, ["search", "whatsapp"])
    assert result.exit_code == 0
    assert "WhatsApp Messenger" in result.output
    assert "310633997" in result.output


def test_search_json_output(httpx_mock, itunes_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=whatsapp&entity=software&limit=10&country=us",
        json=itunes_response,
    )
    result = runner.invoke(app, ["search", "whatsapp", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) == 2
    assert data[0]["name"] == "WhatsApp Messenger"


def test_search_no_results(httpx_mock, itunes_empty_response):
    httpx_mock.add_response(
        url="https://itunes.apple.com/search?term=xyznonexistent&entity=software&limit=10&country=us",
        json=itunes_empty_response,
    )
    result = runner.invoke(app, ["search", "xyznonexistent"])
    assert result.exit_code == 0
    assert "No apps found" in result.output


def test_search_android_not_implemented(httpx_mock):
    result = runner.invoke(app, ["search", "whatsapp", "--platform", "android"])
    assert result.exit_code == 0
    assert "Android support coming soon" in result.output


def test_get_sdk_table_output(httpx_mock, appgoblin_html_with_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_html_with_sdks,
    )
    result = runner.invoke(app, ["get-sdk", "835599320"])
    assert result.exit_code == 0
    assert "Stripe" in result.output
    assert "Google" in result.output
    assert "Business Tools" in result.output


def test_get_sdk_json_output(httpx_mock, appgoblin_html_with_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/835599320",
        text=appgoblin_html_with_sdks,
    )
    result = runner.invoke(app, ["get-sdk", "835599320", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["app_name"] == "TestApp - Great App"
    assert "Business Tools" in data["categories"]


def test_get_sdk_not_found(httpx_mock):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/000000",
        status_code=404,
    )
    result = runner.invoke(app, ["get-sdk", "000000"])
    assert result.exit_code == 1
    assert "not found" in result.output.lower()


def test_get_sdk_no_sdks(httpx_mock, appgoblin_html_no_sdks):
    httpx_mock.add_response(
        url="https://appgoblin.info/apps/999999",
        text=appgoblin_html_no_sdks,
    )
    result = runner.invoke(app, ["get-sdk", "999999"])
    assert result.exit_code == 0
    assert "No SDKs detected" in result.output


def test_get_sdk_android_not_implemented(httpx_mock):
    result = runner.invoke(app, ["get-sdk", "com.whatsapp", "--platform", "android"])
    assert result.exit_code == 0
    assert "Android support coming soon" in result.output
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/test_cli.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'app_sdk_finder.cli'`

- [ ] **Step 3: Implement CLI**

```python
# src/app_sdk_finder/cli.py
import json
import sys
from enum import Enum

import typer
from rich.console import Console
from rich.table import Table

from app_sdk_finder.appgoblin import AppNotFoundError, get_sdks
from app_sdk_finder.models import AppSearchResult

app = typer.Typer(help="Find SDKs used by iOS/Android apps via AppGoblin")
console = Console()
err_console = Console(stderr=True)


class Platform(str, Enum):
    ios = "ios"
    android = "android"


def _print_search_table(results: list[AppSearchResult]) -> None:
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("App Name", style="bold")
    table.add_column("Developer")
    table.add_column("Store ID", style="green")
    table.add_column("Rating", justify="right")
    for i, r in enumerate(results, 1):
        rating = f"{r.rating:.2f}" if r.rating is not None else "N/A"
        table.add_row(str(i), r.name, r.developer, r.store_id, rating)
    console.print(table)


@app.command()
def search(
    app_name: str = typer.Argument(help="App name to search for"),
    platform: Platform = typer.Option(Platform.ios, help="Target platform"),
    country: str = typer.Option("us", help="Country code"),
    limit: int = typer.Option(10, help="Max results"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Search for apps by name."""
    if platform == Platform.android:
        console.print("[yellow]Android support coming soon[/yellow]")
        return

    from app_sdk_finder.itunes import search_apps

    try:
        results = search_apps(app_name, country=country, limit=limit)
    except Exception as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(code=1)

    if not results:
        console.print("[yellow]No apps found[/yellow]")
        return

    if output_json:
        print(json.dumps([r.to_dict() for r in results], ensure_ascii=False))
    else:
        _print_search_table(results)


@app.command("get-sdk")
def get_sdk(
    store_id: str = typer.Argument(help="Store ID (iOS: trackId, Android: package name)"),
    platform: Platform = typer.Option(Platform.ios, help="Target platform"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Get SDKs used by an app."""
    if platform == Platform.android:
        console.print("[yellow]Android support coming soon[/yellow]")
        return

    try:
        result = get_sdks(store_id)
    except AppNotFoundError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    except Exception as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(code=1)

    if not result.categories:
        console.print(f"[yellow]No SDKs detected for {result.app_name}[/yellow]")
        return

    if output_json:
        print(json.dumps(result.to_dict(), ensure_ascii=False))
    else:
        console.print(f"[bold]{result.app_name}[/bold] ({result.store_id})")
        console.print(f"Platform: {result.platform}")
        if result.sdk_scan_date:
            console.print(f"SDK Scan: {result.sdk_scan_date}")
        console.print()

        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Category", style="bold")
        table.add_column("Company")
        table.add_column("Domain", style="dim")

        for cat_name, sdks in result.categories.items():
            for i, sdk in enumerate(sdks):
                cat_display = cat_name if i == 0 else ""
                table.add_row(cat_display, sdk.name, sdk.domain)
            table.add_section()

        console.print(table)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/test_cli.py -v
```

Expected: all 9 tests PASS.

- [ ] **Step 5: Run full test suite**

```bash
uv run pytest -v
```

Expected: all tests PASS (6 models + 4 itunes + 5 appgoblin + 9 cli = 24 tests).

- [ ] **Step 6: Commit**

```bash
git add src/app_sdk_finder/cli.py tests/test_cli.py
git commit -m "feat: add CLI commands with rich table and JSON output"
```

---

### Task 7: End-to-End Smoke Test

**Files:** none (manual verification)

- [ ] **Step 1: Test search command (table)**

```bash
uv run app-sdk-finder search "tiktok" --platform ios --limit 5
```

Expected: rich table with TikTok and related apps, showing name/developer/store_id/rating.

- [ ] **Step 2: Test search command (JSON)**

```bash
uv run app-sdk-finder search "tiktok" --json --limit 3
```

Expected: compact JSON array on one line.

- [ ] **Step 3: Test get-sdk command (table)**

Use a store_id from Step 1's output:

```bash
uv run app-sdk-finder get-sdk 835599320
```

Expected: rich table with SDK categories and companies.

- [ ] **Step 4: Test get-sdk command (JSON)**

```bash
uv run app-sdk-finder get-sdk 835599320 --json
```

Expected: compact JSON object on one line with categories.

- [ ] **Step 5: Test Android not-implemented**

```bash
uv run app-sdk-finder search "whatsapp" --platform android
uv run app-sdk-finder get-sdk com.whatsapp --platform android
```

Expected: both print "Android support coming soon".

- [ ] **Step 6: Test error cases**

```bash
uv run app-sdk-finder get-sdk 000000000
```

Expected: error message "App not found on AppGoblin".

---

### Task 8: PyPI Publish

**Files:**
- Modify: `pyproject.toml` (add metadata for PyPI)

- [ ] **Step 1: Add PyPI metadata to pyproject.toml**

Add these fields to the `[project]` section:

```toml
readme = "README.md"
license = "MIT"
authors = [{ name = "proalex" }]
keywords = ["sdk", "mobile", "ios", "android", "appgoblin"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Environment :: Console",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.11",
    "Topic :: Software Development :: Libraries",
]

[project.urls]
Homepage = "https://github.com/proalex/app-sdk-finder"
```

- [ ] **Step 2: Create minimal README.md**

```markdown
# app-sdk-finder

CLI tool to find SDKs used by iOS/Android apps via [AppGoblin](https://appgoblin.info).

## Install

\```bash
pip install app-sdk-finder
\```

## Usage

\```bash
# Search for an app
app-sdk-finder search "tiktok"

# Get SDKs (use store_id from search results)
app-sdk-finder get-sdk 835599320

# JSON output
app-sdk-finder search "tiktok" --json
app-sdk-finder get-sdk 835599320 --json
\```
```

- [ ] **Step 3: Create LICENSE file**

```
MIT License

Copyright (c) 2026 proalex

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

- [ ] **Step 4: Build and verify**

```bash
uv build
ls dist/
```

Expected: `app_sdk_finder-0.1.0.tar.gz` and `app_sdk_finder-0.1.0-py3-none-any.whl`

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml README.md LICENSE
git commit -m "chore: add PyPI metadata, README, and LICENSE"
```

- [ ] **Step 6: Publish to PyPI**

```bash
uv publish
```

Requires `UV_PUBLISH_TOKEN` env var or `--token` flag with PyPI API token. Confirm with user before executing.
