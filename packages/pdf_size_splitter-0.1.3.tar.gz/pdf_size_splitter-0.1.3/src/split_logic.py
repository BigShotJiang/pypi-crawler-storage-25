import os
from src.pdf_extraction import get_extracted_size
from pypdf import PdfReader

def find_split_point(file_path, start_page, max_size):
    reader = PdfReader(file_path)
    total_pages = len(reader.pages)
    
    # 1ページも収まらない場合は例外を発生させる
    first_page_size = get_extracted_size(file_path, start_page, start_page)
    if first_page_size > max_size:
        raise ValueError("1ページ目が既に指定サイズを超過しているため分割できません")

    # 平均サイズから、おおよそのページ数を予測
    total_file_size = os.path.getsize(file_path)
    avg_page_size = total_file_size / total_pages
    predicted_count = max(1, int(max_size // avg_page_size))
    
    # 予測したページ数を初期値として、微調整（線形探索）を行う
    current_end = min(start_page + predicted_count - 1, total_pages - 1)
    
    # 予測地点が大きすぎる場合は戻る
    while current_end > start_page and get_extracted_size(file_path, start_page, current_end) > max_size:
        current_end -= 1
        
    # 予測地点にまだ余裕がある場合は進む
    while current_end < total_pages - 1 and get_extracted_size(file_path, start_page, current_end + 1) <= max_size:
        current_end += 1

    return current_end
