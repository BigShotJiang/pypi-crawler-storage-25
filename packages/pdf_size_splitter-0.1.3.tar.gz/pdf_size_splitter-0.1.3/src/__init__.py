"""
PDF Size Splitter - PDFファイルを指定したサイズで分割するツール
"""

__version__ = "0.1.3"
__author__ = "momoandbanana22"
