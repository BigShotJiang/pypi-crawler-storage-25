# IDE Integration

Super-Brain plugs into **14 AI coding tools**. Each has a one-command installer that drops the right files in the right places — no manual JSON editing required.

---

## What integration looks like

Super-Brain uses one of three integration styles depending on what the target tool supports:

| Style | Example | How it works |
|---|---|---|
| **MCP server** | Aider, Claude Code, Gemini | Tool calls Super-Brain over stdio JSON-RPC at query time |
| **Hook** | Claude Code, Gemini CLI | Pre-tool hook injects Super-Brain context before the assistant runs file searches |
| **Rules / skills** | Cursor, Copilot, Kiro, Hermes | A markdown rule file the assistant reads on every request |

Most installers use a combination — Claude Code gets a hook **and** a rule file; Aider gets MCP **and** an AGENTS.md; Cursor gets a rules file only.

---

## One-command install

### All at once

```bash
agsuperbrain install --platform all
```

### Per platform

```bash
agsuperbrain claude-install           # Claude Code
agsuperbrain cursor-install           # Cursor
agsuperbrain aider-install            # Aider
agsuperbrain codex-install            # Codex
agsuperbrain opencode-install         # OpenCode
agsuperbrain copilot-install          # GitHub Copilot CLI
agsuperbrain vscode-install           # VS Code Copilot Chat
agsuperbrain gemini-install           # Gemini CLI
agsuperbrain hermes-install           # Hermes
agsuperbrain kiro-install             # Kiro
agsuperbrain antigravity-install      # Google Antigravity
agsuperbrain openclaw-install         # OpenClaw
agsuperbrain droid-install            # Factory Droid
agsuperbrain trae-install             # Trae / Trae CN
```

**Before running any of these**, finish the one-time setup:

```bash
agsuperbrain init
agsuperbrain ingest ./src
agsuperbrain index-vectors
```

The graph needs to exist before your assistant can query it.

---

## Platform matrix

| Platform | Install command | Files created | Integration style |
|---|---|---|---|
| Claude Code | `claude-install` | `.claude/settings.json`, `CLAUDE.md`, `AGENTS.md` | PreToolUse hook + rule files |
| Cursor | `cursor-install` | `.cursor/rules/superbrain.mdc` | Always-on rule file |
| Aider | `aider-install` | `.aider.conf.yml`, `AGENTS.md` | MCP server config + rules |
| Codex | `codex-install` | `AGENTS.md` | Rule file |
| OpenCode | `opencode-install` | `AGENTS.md` | Rule file |
| GitHub Copilot CLI | `copilot-install` | `~/.copilot/skills/superbrain/SKILL.md` | Global skill |
| VS Code Copilot Chat | `vscode-install` | `.github/copilot-instructions.md` | Repo instructions |
| Gemini CLI | `gemini-install` | `.gemini/settings.json`, `AGENTS.md` | BeforeTool hook + rules |
| Hermes | `hermes-install` | `~/.hermes/skills/superbrain/SKILL.md`, `AGENTS.md` | Global skill + rules |
| Kiro | `kiro-install` | `.kiro/skills/superbrain/SKILL.md`, `.kiro/steering/superbrain.md` | Skill + steering |
| Google Antigravity | `antigravity-install` | `.agent/rules/superbrain.md`, `.agent/workflows/superbrain.md` | Rules + workflows |
| OpenClaw | `openclaw-install` | `AGENTS.md` | Rule file |
| Factory Droid | `droid-install` | `AGENTS.md` | Rule file |
| Trae / Trae CN | `trae-install` | `AGENTS.md` | Rule file |

All install commands are idempotent — run them twice and nothing breaks.

---

## Uninstall

Dedicated uninstallers exist for the three tools whose integration changes shared settings files:

```bash
agsuperbrain claude-uninstall      # removes hooks from .claude/settings.json
agsuperbrain cursor-uninstall      # removes .cursor/rules/superbrain.mdc
agsuperbrain aider-uninstall       # unpatches .aider.conf.yml
```

For the other platforms, installation is additive and non-destructive — just delete the file(s) listed in the matrix above.

---

## MCP: what your assistant can do

When the MCP server runs (started automatically by the Aider, Claude Code, and Gemini integrations, or manually via `agsuperbrain mcp-serve`), these tools become available:

| Tool | Purpose |
|---|---|
| `search_code` | Semantic search across code and documents |
| `find_callers` | All functions that call a given function |
| `find_callees` | All functions a given function calls |
| `get_function_body` | Full source, docstring, and signature of a function |
| `path_between` | Call path from one function to another |
| `closure` | Transitive closure of any relationship |
| `get_subgraph` | Local neighborhood around a node |
| `stats` | Counts per node/edge type |
| `list_modules` | Every module in the graph |
| `list_functions` | Every function in the graph, optionally filtered by module |

These are called by your assistant, not by you — but if you're debugging, `agsuperbrain mcp-serve` lets you test them manually.

---

## Using Super-Brain from agent frameworks

Super-Brain's MCP server works with **any framework that speaks MCP**:

- LangChain / LangGraph (via `langchain-mcp-adapters`)
- AutoGen (native MCP)
- CrewAI (MCP tool connector)
- SmolAgents
- Plain stdio JSON-RPC

### LangChain / LangGraph

```python
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_agent
from langchain_mcp_adapters.tools import load_mcp_server

mcp = load_mcp_server(command="agsuperbrain", args=["mcp-serve"])
tools = mcp.get_tools()

llm = ChatOpenAI(model="gpt-4o")
agent = create_agent(llm, tools, prompt="You are a codebase expert.")

response = agent.invoke({"messages": ["How does authentication work?"]})
```

### AutoGen

```python
from autogen import ConversableAgent

agent = ConversableAgent(
    name="code_expert",
    llm_config={"model": "gpt-4o"},
    tools=[{"command": "agsuperbrain", "args": ["mcp-serve"]}],
)
```

### CrewAI

```python
from crewai import Agent
from crewai.tools import MCPTool

code_tools = MCPTool(
    server_name="agsuperbrain",
    server_command="agsuperbrain mcp-serve",
)
expert = Agent(tools=[code_tools], role="Codebase Expert")
```

---

## Manual MCP configuration (advanced)

If you prefer to wire the MCP server yourself instead of using an `<ide>-install` command, here are the configs:

### Claude Code — `~/.claude/settings.json`

```json
{
  "mcpServers": {
    "superbrain": {
      "command": "agsuperbrain",
      "args": ["mcp-serve"]
    }
  }
}
```

### Cursor — `~/.cursor/mcp.json`

```json
{
  "mcpServers": {
    "superbrain": {
      "command": "agsuperbrain",
      "args": ["mcp-serve"]
    }
  }
}
```

Note: `cursor-install` writes a rules file (`.cursor/rules/superbrain.mdc`) for always-on context. MCP is an additional, optional layer — set it up manually if you want both.

### Aider — `.aider.conf.yml`

```yaml
mcp-server: agsuperbrain:mcp-serve
```

### Custom DB paths

Any MCP client can be configured to use a custom graph or vector path:

```json
{
  "mcpServers": {
    "superbrain": {
      "command": "agsuperbrain",
      "args": [
        "mcp-serve",
        "--db", "/path/to/graph",
        "--qdrant-path", "/path/to/qdrant"
      ]
    }
  }
}
```

---

## Troubleshooting

### The assistant doesn't see Super-Brain's tools

1. Run `agsuperbrain doctor` and confirm every component is green.
2. Confirm you've run `agsuperbrain ingest ./src` — the graph must exist.
3. Restart your IDE — MCP servers are loaded at IDE startup.
4. Check the IDE's MCP logs (varies by product). Claude Code logs to `~/.claude/logs/`; Cursor logs under `Help → Toggle Developer Tools → Console`.

### "Connection refused" or "server failed to start"

- Make sure `agsuperbrain` is on your `PATH` (`which agsuperbrain` / `where agsuperbrain` should print a path).
- MCP uses stdio — nothing is listening on a network port, so firewall rules aren't the cause.

### The assistant answers but without Super-Brain context

Re-run the install command for that platform. Integration files may have been overwritten by an update to the IDE or a linter.

---

## Next steps

- [CLI Reference](cli.md) — the commands behind every integration
- [Architecture](architecture.md) — what the MCP tools actually query
- [Why Super-Brain](comparison.md) — the problems this integration solves
