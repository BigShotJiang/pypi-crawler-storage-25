"""
retriever.py
"""

from __future__ import annotations

from dataclasses import dataclass, field

from agsuperbrain.memory.graph.graph_store import GraphStore
from agsuperbrain.memory.vector.embedder import TextEmbedder
from agsuperbrain.memory.vector.vector_store import VectorStore

# ── Module-level constants (not rebuilt per call) ─────────────────
_EXTERNAL_STUB_NAMES: frozenset[str] = frozenset(
    {
        "load",
        "print",
        "open",
        "str",
        "int",
        "list",
        "dict",
        "len",
        "range",
        "type",
        "append",
        "get",
        "json",
        "os",
        "any",
        "all",
        "next",
        "iter",
        "read",
        "write",
        "close",
        "format",
        "split",
        "isinstance",
        "hasattr",
        "getattr",
    }
)

_GRAPH_QUERIES: dict[str, str] = {
    "Function": (
        "MATCH (f:Function {{id:$id}})-[:CALLS*1..{d}]-(n:Function) "
        "RETURN n.id, n.name AS label, n.qualified_name AS text, "
        "       n.source_path, n.source_type, 'Function' AS node_type"
    ),
    "Transcript": (
        "MATCH (t:Transcript {{id:$id}})-[:FOLLOWS*1..{d}]-(n:Transcript) "
        "RETURN n.id, n.id AS label, n.text AS text, "
        "       n.source_path, n.source_type, 'Transcript' AS node_type"
    ),
    "Section": (
        "MATCH (s:Section {{id:$id}})-[:CONTAINS*1..{d}]-(n:Section) "
        "RETURN n.id, n.title AS label, n.title AS text, "
        "       n.source_path, n.source_type, 'Section' AS node_type"
    ),
    "Concept": (
        "MATCH (c:Concept {{id:$id}})<-[:CONTAINS]-(s:Section) "
        "RETURN s.id, s.title AS label, s.title AS text, "
        "       s.source_path, s.source_type, 'Section' AS node_type"
    ),
}


@dataclass
class HybridResult:
    node_id: str
    node_type: str
    text: str
    source_type: str
    source_path: str
    chunk_id: str
    vector_score: float
    graph_hops: int
    final_score: float
    neighbours: list[dict] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)  # ← FIX 5


class HybridRetriever:
    def __init__(
        self,
        graph_store: GraphStore,
        vector_store: VectorStore,
        embedder: TextEmbedder,
        graph_depth: int = 2,
        graph_decay: float = 0.7,
    ) -> None:
        self.gs = graph_store
        self.vs = vector_store
        self.embedder = embedder
        self.graph_depth = graph_depth
        self.graph_decay = graph_decay

    def _vector_search(self, query, top_k, node_type, source_type):
        vec = self.embedder.embed([query])[0]
        return self.vs.search(vec, limit=top_k, node_type=node_type, source_type=source_type)

    def _expand_graph(self, node_id: str, node_type: str, depth: int) -> list[dict]:
        template = _GRAPH_QUERIES.get(node_type)
        if not template:
            return []
        q = template.format(d=depth)
        rows = self.gs.query(q, {"id": node_id})
        results = []
        for r in rows:
            if len(r) < 6:
                continue
            results.append(
                {
                    "node_id": r[0],
                    "label": r[1],
                    "text": r[2] or "",
                    "source_path": r[3] or "",
                    "source_type": r[4] or "",
                    "node_type": r[5],
                }
            )
        return results

    def query(
        self,
        query_text: str,
        top_k: int = 5,
        node_type: str | None = None,
        source_type: str | None = None,
        expand_graph: bool = True,
    ) -> list[HybridResult]:
        hits = self._vector_search(query_text, top_k, node_type, source_type)
        seen: dict[str, HybridResult] = {}

        # ── Seed from vector hits ─────────────────────────────────
        for h in hits:
            name = h.node_id.split("__")[-1]
            # FIX 2: single unified external-stub suppression
            if h.source_path == "external" and name in _EXTERNAL_STUB_NAMES:
                continue
            seen[h.node_id] = HybridResult(
                node_id=h.node_id,
                node_type=h.node_type,
                text=h.text,
                source_type=h.source_type,
                source_path=h.source_path,
                chunk_id=h.chunk_id,
                vector_score=h.score,
                graph_hops=0,
                final_score=h.score,
                metadata=h.payload if hasattr(h, "payload") else {},
            )

        if not expand_graph:
            return sorted(seen.values(), key=lambda x: x.final_score, reverse=True)

        for hop in range(1, self.graph_depth + 1):
            seeds = [r for r in seen.values() if r.graph_hops == hop - 1]
            for direct in seeds:
                try:
                    neighbours = self._expand_graph(direct.node_id, direct.node_type, depth=hop)
                except Exception:
                    neighbours = []
                direct.neighbours = neighbours if hop == 1 else direct.neighbours

                decay_score = direct.vector_score * (self.graph_decay**hop)

                for nb in neighbours:
                    nid = nb["node_id"]
                    if not nid or nid in seen:
                        continue
                    if nb.get("source_path") == "external" and nb.get("label") in _EXTERNAL_STUB_NAMES:
                        continue
                    if node_type and nb["node_type"] != node_type:
                        continue
                    seen[nid] = HybridResult(
                        node_id=nid,
                        node_type=nb["node_type"],
                        text=nb["text"],
                        source_type=nb["source_type"],
                        source_path=nb["source_path"],
                        chunk_id="",
                        vector_score=0.0,
                        graph_hops=hop,
                        final_score=decay_score,
                        metadata={
                            k: v
                            for k, v in nb.items()
                            if k not in {"node_id", "node_type", "text", "source_type", "source_path", "label"}
                        },
                    )

        return sorted(seen.values(), key=lambda x: x.final_score, reverse=True)

    def reason_over_path(self, src_id: str, dst_id: str) -> list[str]:
        """
        Find a directed path from src to dst using BFS.
        Returns list of node IDs along the path, or empty if no path exists.
        """
        from collections import deque

        visited = {src_id}
        queue = deque([(src_id, [src_id])])

        while queue:
            current, path = queue.popleft()
            if current == dst_id:
                return path

            rows = self.gs.query("MATCH (a {id:$src})-[r:CALLS]->(b) RETURN b.id", {"src": current})
            for row in rows:
                next_id = row[0]
                if next_id and next_id not in visited:
                    visited.add(next_id)
                    new_path = path + [next_id]
                    queue.append((next_id, new_path))

        return []

    def ancestor_closure(self, node_id: str, relation: str = "CALLS", max_hops: int = 10) -> list[dict]:
        """
        Compute transitive closure from a node following a relation direction.
        Returns all reachable nodes within max_hops.
        """
        visited = {node_id}
        results = []
        current_front = {node_id}

        for hop in range(max_hops):
            if not current_front:
                break
            next_front = set()
            for nid in current_front:
                rel_clause = {
                    "CALLS": "(a {id:$id})-[r:CALLS]->(b)",
                    "DEFINED_IN": "(a {id:$id})-[r:DEFINED_IN]->(b)",
                    "CONTAINS": "(a {id:$id})-[r:CONTAINS]->(b)",
                }.get(relation, "(a {id:$id})-[r]->(b)")

                rows = self.gs.query(f"MATCH {rel_clause} RETURN b.id, b.name, b.qualified_name", {"id": nid})
                for row in rows:
                    bid = row[0]
                    if bid and bid not in visited:
                        visited.add(bid)
                        next_front.add(bid)
                        results.append(
                            {
                                "node_id": bid,
                                "name": row[1] or "",
                                "qualified_name": row[2] or "",
                                "hops": hop + 1,
                            }
                        )
            current_front = next_front

        return results
