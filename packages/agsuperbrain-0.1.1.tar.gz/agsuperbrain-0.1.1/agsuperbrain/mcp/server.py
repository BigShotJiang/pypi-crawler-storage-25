"""
MCP server for Super-Brain.

Exposes graph intelligence tools via stdio-based JSON-RPC.
Compatible with Claude Code, Cursor, Aider, OpenCode, Cline, Continue.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from agsuperbrain.intelligence.retriever import HybridRetriever
from agsuperbrain.memory.graph.graph_store import GraphStore
from agsuperbrain.memory.vector.embedder import TextEmbedder
from agsuperbrain.memory.vector.vector_store import VectorStore


def _get_store(db_path: str = "./.agsuperbrain/graph") -> GraphStore:
    gs = GraphStore(Path(db_path))
    gs.init_schema()
    return gs


def _get_vs(qdrant_path: str = "./.agsuperbrain/qdrant") -> VectorStore:
    return VectorStore(Path(qdrant_path))


def _get_retriever(db_path: str = "./.agsuperbrain/graph", qdrant_path: str = "./.agsuperbrain/qdrant"):
    gs = _get_store(db_path)
    vs = _get_vs(qdrant_path)
    emb = TextEmbedder()
    return HybridRetriever(gs, vs, emb)


TOOL_HANDLERS = {}


def tool(name: str):
    """Decorator to register a tool handler."""

    def decorator(func):
        TOOL_HANDLERS[name] = func
        return func

    return decorator


@tool("search_code")
def search_code(
    query: str,
    limit: int = 5,
    mode: str = "all",
    db_path: str = "./.agsuperbrain/graph",
    qdrant_path: str = "./.agsuperbrain/qdrant",
) -> dict:
    """Semantic code search."""
    ret = _get_retriever(db_path, qdrant_path)
    node_type = None
    if mode == "code":
        node_type = "Function"
    elif mode == "document":
        node_type = "Section"
    elif mode == "audio":
        node_type = "Transcript"

    results = ret.query(query, top_k=limit, node_type=node_type)
    return {
        "results": [
            {
                "node_id": r.node_id,
                "text": r.text,
                "source_path": r.source_path,
                "score": r.final_score,
                "graph_hops": r.graph_hops,
            }
            for r in results
        ]
    }


@tool("find_callers")
def find_callers(function_id: str, db_path: str = "./.agsuperbrain/graph") -> dict:
    """Find all functions that call the given function."""
    gs = _get_store(db_path)
    rows = gs.query(
        "MATCH (caller:Function)-[:CALLS]->(callee:Function {id:$fid}) "
        "RETURN caller.id, caller.qualified_name, caller.source_path",
        {"fid": function_id},
    )
    return {"callers": [{"id": r[0], "qualified_name": r[1], "source_path": r[2]} for r in rows]}


@tool("find_callees")
def find_callees(function_id: str, db_path: str = "./.agsuperbrain/graph") -> dict:
    """Find all functions called by the given function."""
    gs = _get_store(db_path)
    rows = gs.query(
        "MATCH (caller:Function {id:$fid})-[:CALLS]->(callee:Function) "
        "RETURN callee.id, callee.qualified_name, callee.source_path",
        {"fid": function_id},
    )
    return {"callees": [{"id": r[0], "qualified_name": r[1], "source_path": r[2]} for r in rows]}


@tool("get_function_body")
def get_function_body(qualified_name: str, db_path: str = "./.agsuperbrain/graph") -> dict:
    """Get function body and docstring."""
    gs = _get_store(db_path)
    rows = gs.query(
        "MATCH (f:Function) "
        "WHERE f.qualified_name = $q OR f.name = $q "
        "RETURN f.id, f.qualified_name, f.source_path, f.start_line, f.end_line, "
        "       f.is_method, f.class_name, f.docstring, f.body",
        {"q": qualified_name},
    )
    if not rows:
        return {"error": f"Function not found: {qualified_name}"}
    r = rows[0]
    return {
        "id": r[0],
        "qualified_name": r[1],
        "source_path": r[2],
        "start_line": r[3],
        "end_line": r[4],
        "is_method": r[5],
        "class_name": r[6],
        "docstring": r[7],
        "body": r[8],
    }


@tool("path_between")
def path_between(src_id: str, dst_id: str, db_path: str = "./.agsuperbrain/graph") -> dict:
    """Find path between two functions."""
    gs = _get_store(db_path)
    ret = HybridRetriever(gs, _get_vs(), TextEmbedder())
    path = ret.reason_over_path(src_id, dst_id)
    return {"path": path}


@tool("closure")
def closure(node_id: str, relation: str = "CALLS", max_hops: int = 10, db_path: str = "./.agsuperbrain/graph") -> dict:
    """Get transitive closure from a node."""
    gs = _get_store(db_path)
    ret = HybridRetriever(gs, _get_vs(), TextEmbedder())
    results = ret.ancestor_closure(node_id, relation, max_hops)
    return {"nodes": results}


@tool("get_subgraph")
def get_subgraph(root_id: str, depth: int = 2, db_path: str = "./.agsuperbrain/graph") -> dict:
    """Get subgraph around a root node."""
    gs = _get_store(db_path)
    nodes, edges = gs.get_subgraph(root_id, depth)
    return {"nodes": nodes, "edges": edges}


@tool("stats")
def stats(db_path: str = "./.agsuperbrain/graph") -> dict:
    """Get graph statistics."""
    gs = _get_store(db_path)
    metrics = {}
    for label, q in [
        ("modules", "MATCH (m:Module) RETURN count(m)"),
        ("functions", "MATCH (f:Function) RETURN count(f)"),
        ("calls", "MATCH ()-[:CALLS]->() RETURN count(*)"),
        ("documents", "MATCH (d:Document) RETURN count(d)"),
        ("sections", "MATCH (s:Section) RETURN count(s)"),
        ("concepts", "MATCH (c:Concept) RETURN count(c)"),
        ("transcripts", "MATCH (t:Transcript) RETURN count(t)"),
    ]:
        rows = gs.query(q)
        metrics[label] = rows[0][0] if rows else 0
    return metrics


@tool("list_modules")
def list_modules(db_path: str = "./.agsuperbrain/graph") -> dict:
    """List all modules."""
    gs = _get_store(db_path)
    rows = gs.query("MATCH (m:Module) RETURN m.id, m.name, m.source_path")
    return {"modules": [{"id": r[0], "name": r[1], "source_path": r[2]} for r in rows]}


@tool("list_functions")
def list_functions(module_id: str | None = None, db_path: str = "./.agsuperbrain/graph") -> dict:
    """List all functions, optionally filtered by module."""
    gs = _get_store(db_path)
    if module_id:
        rows = gs.query(
            "MATCH (f:Function)-[:DEFINED_IN]->(m:Module {id:$mid}) RETURN f.id, f.name, f.qualified_name, f.is_method",
            {"mid": module_id},
        )
    else:
        rows = gs.query("MATCH (f:Function) RETURN f.id, f.name, f.qualified_name, f.is_method")
    return {"functions": [{"id": r[0], "name": r[1], "qualified_name": r[2], "is_method": r[3]} for r in rows]}


def _handle_request(req: dict) -> dict:
    """Handle a single JSON-RPC request."""
    method = req.get("method")
    params = req.get("params", {})
    request_id = req.get("id")

    if method not in TOOL_HANDLERS:
        return {
            "error": {"code": -32601, "message": f"Method not found: {method}"},
            "id": request_id,
        }

    try:
        result = TOOL_HANDLERS[method](**params)
        return {"result": result, "id": request_id}
    except Exception as e:
        return {
            "error": {"code": -32603, "message": str(e)},
            "id": request_id,
        }


def main():
    """Run the MCP server."""
    if len(sys.argv) > 1 and sys.argv[1] == "--version":
        print("agsuperbrain-mcp 0.1.0")
        return

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            print(json.dumps({"error": {"code": -32700, "message": "Parse error"}}))
            continue

        resp = _handle_request(req)
        print(json.dumps(resp), flush=True)


if __name__ == "__main__":
    main()
