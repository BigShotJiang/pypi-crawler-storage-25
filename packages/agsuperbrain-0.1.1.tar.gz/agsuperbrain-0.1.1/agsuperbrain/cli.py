"""cli.py — Typer CLI entry point (Phase 1 + Phase 3 + Phase 4)."""

from __future__ import annotations

import os
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(name="agsuperbrain", add_completion=False)
console = Console()
_DB = Path("./.agsuperbrain/graph")
_QDRANT = Path("./.agsuperbrain/qdrant")
_AUDIO = Path("./.agsuperbrain/audio")
_OUT = Path("./output/graph.html")
_PID_FILE = Path("./.agsuperbrain/watcher.pid")


def _stop_watcher(path: Path = Path(".")) -> bool:
    """Stop the background watcher process, if any.

    Returns True if a watcher was running and was signalled; False if no
    watcher was running (or the PID file was stale/unreadable). In all cases
    the PID file is removed so a subsequent `init` starts a fresh watcher.
    """
    import signal

    pid_file = path / ".agsuperbrain" / "watcher.pid"
    if not pid_file.exists():
        return False

    try:
        pid = int(pid_file.read_text().strip())
    except (OSError, ValueError):
        try:
            pid_file.unlink()
        except OSError:
            pass
        return False

    was_alive = _is_pid_alive(pid)
    if was_alive:
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            # Process already gone between check and signal — benign race.
            pass

    try:
        pid_file.unlink()
    except OSError:
        pass

    return was_alive


def _is_pid_alive(pid: int) -> bool:
    """Return True iff a process with this PID is currently running.

    Cross-platform: POSIX uses signal 0; Windows uses the Win32 API directly
    because Windows does not implement signal-0-as-probe and raises OSError.
    """
    if pid <= 0:
        return False

    if os.name == "nt":
        import ctypes

        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        STILL_ACTIVE = 259
        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return False
        try:
            exit_code = ctypes.c_ulong()
            ok = kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
            return bool(ok) and exit_code.value == STILL_ACTIVE
        finally:
            kernel32.CloseHandle(handle)

    # POSIX
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        # Process exists but we cannot signal it — still alive.
        return True
    except OSError:
        # Anything unexpected — treat as not alive so the caller can recover.
        return False
    return True


@app.callback()
def _global_callback(
    ctx: typer.Context,
    verbose: bool = typer.Option(False, "--verbose", "-v", is_flag=True),
) -> None:
    """Auto-start watcher on first run if not already running."""
    if os.environ.get("AGSB_DAEMON"):
        return

    config_dir = Path(".agsuperbrain")
    pid_file = config_dir / "watcher.pid"

    if not (config_dir.exists() and pid_file.exists()):
        return

    # Liveness check must never crash the CLI: one stale PID file should
    # not prevent the user from running `doctor` or any other command.
    try:
        old_pid = int(pid_file.read_text().strip())
    except (OSError, ValueError):
        # Unreadable or malformed PID file — clean up and move on.
        try:
            pid_file.unlink()
        except OSError:
            pass
        return

    if _is_pid_alive(old_pid):
        return

    # Stale PID — clear it and restart the watcher in the background.
    try:
        pid_file.unlink()
    except OSError:
        pass
    try:
        _start_watcher_background(Path("."))
    except Exception:
        # Background start is best-effort; never block the foreground command.
        pass


def _start_watcher_background(path: Path = Path(".")) -> None:
    """Start watcher in background daemon mode."""
    import subprocess

    config_dir = path / ".agsuperbrain"
    config_dir.mkdir(parents=True, exist_ok=True)

    pid_file = config_dir / "watcher.pid"

    if pid_file.exists():
        try:
            old_pid = int(pid_file.read_text().strip())
        except (OSError, ValueError):
            old_pid = -1

        if old_pid > 0 and _is_pid_alive(old_pid):
            console.print(f"[dim]Watcher already running (PID {old_pid})[/dim]")
            return

        try:
            pid_file.unlink()
        except OSError:
            pass

    env = os.environ.copy()
    env["AGSB_DAEMON"] = "1"

    # start_new_session is POSIX-only; on Windows, use DETACHED_PROCESS instead.
    popen_kwargs: dict = {
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "env": env,
    }
    if os.name == "nt":
        # 0x00000008 = DETACHED_PROCESS — the child has no console attached.
        popen_kwargs["creationflags"] = 0x00000008
    else:
        popen_kwargs["start_new_session"] = True

    proc = subprocess.Popen(
        ["agsuperbrain", "watch", str(path)],
        **popen_kwargs,
    )

    pid_file.write_text(str(proc.pid))
    console.print(f"[green]✓[/green] Watcher started (PID {proc.pid})")


def _store(db: Path):
    from agsuperbrain.memory.graph.graph_store import GraphStore

    s = GraphStore(db)
    s.init_schema()
    return s


# ── Phase 1: Code ─────────────────────────────────────────────────────────────


@app.command()
def ingest(
    paths: list[Path] = typer.Argument(...),
    db: Path = typer.Option(_DB, "--db"),
    verbose: bool = typer.Option(False, "--verbose", "-v", is_flag=True),
) -> None:
    """Ingest source code into the graph."""
    from agsuperbrain.core.pipeline import CodeGraphPipeline

    CodeGraphPipeline(_store(db)).run(paths, verbose)


# ── Phase 3: Documents ────────────────────────────────────────────────────────


@app.command(name="ingest-doc")
def ingest_doc(
    paths: list[Path] = typer.Argument(...),
    db: Path = typer.Option(_DB, "--db"),
    verbose: bool = typer.Option(False, "--verbose", "-v", is_flag=True),
) -> None:
    """Ingest documents (PDF, DOCX, PPTX, Markdown…) into the graph."""
    from rich.progress import (
        BarColumn,
        Progress,
        SpinnerColumn,
        TextColumn,
        TimeElapsedColumn,
    )

    from agsuperbrain.extraction.doc_extractor import DocExtractor
    from agsuperbrain.preprocessing.doc_parser import DocParser, is_document

    store = _store(db)
    parser = DocParser()
    extractor = DocExtractor()

    files: list[Path] = []
    for p in paths:
        if p.is_dir():
            for f in p.rglob("*"):
                if is_document(f):
                    files.append(f)
        elif p.is_file() and is_document(p):
            files.append(p)

    if not files:
        console.print("[yellow]No supported document files found.[/yellow]")
        raise typer.Exit()

    console.rule("[bold cyan]Super-Brain · Phase 3: Document Ingestion")
    console.print(f"[dim]{len(files)} document(s) to process.[/dim]\n")

    ok = failed = total_sections = total_concepts = 0
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeElapsedColumn(),
        console=console,
    ) as prog:
        task = prog.add_task("Processing…", total=len(files))
        for fp in files:
            prog.update(task, description=f"[cyan]{fp.name}[/cyan]")
            try:
                pr = parser.parse(fp)
                ex = extractor.extract(pr)
                store.upsert_doc(ex)
                ok += 1
                total_sections += len(ex.sections)
                total_concepts += len(ex.concepts)
                if verbose:
                    console.print(
                        f"  ✓ [green]{fp.name}[/green] "
                        f"[dim]— {len(ex.sections)} sections, "
                        f"{len(ex.concepts)} concepts[/dim]"
                    )
            except Exception as e:
                failed += 1
                console.print(f"  ✗ [red]{fp.name}[/red] — {e}")
            prog.advance(task)

    console.rule("[bold green]Done")
    console.print(f"  Documents : {ok}")
    console.print(f"  Sections  : {total_sections}")
    console.print(f"  Concepts  : {total_concepts}")
    if failed:
        console.print(f"  [red]Errors    : {failed}[/red]")


# ── Phase 4: Audio / Video ────────────────────────────────────────────────────


@app.command(name="ingest-audio")
def ingest_audio(
    sources: list[str] = typer.Argument(
        ...,
        help="YouTube URLs or local audio/video file paths",
    ),
    db: Path = typer.Option(_DB, "--db"),
    model_size: str = typer.Option("base", "--model", "-m", help="Whisper model: tiny/base/small/medium"),
    cache_dir: Path = typer.Option(_AUDIO, "--cache"),
    verbose: bool = typer.Option(False, "--verbose", "-v", is_flag=True),
) -> None:
    """
    Transcribe audio/video (URL or local file) into the graph.

    Examples:
        superbrain ingest-audio https://youtu.be/xxxx
        superbrain ingest-audio ./talk.mp4 --model small
        superbrain ingest-audio https://youtu.be/xxxx ./lecture.mp3
    """
    from agsuperbrain.extraction.audio_extractor import AudioExtractor
    from agsuperbrain.preprocessing.audio_fetcher import AudioFetcher

    store = _store(db)
    fetcher = AudioFetcher(cache_dir=cache_dir)
    extractor = AudioExtractor(model_size=model_size)

    console.rule("[bold cyan]Super-Brain · Phase 4: Audio/Video Ingestion")
    console.print(f"[dim]{len(sources)} source(s) | model: {model_size}[/dim]\n")

    for src in sources:
        console.print(f"[cyan]▶ {src}[/cyan]")
        try:
            # Step 1: fetch / download → .wav
            console.print("  [dim]Fetching audio…[/dim]")
            af = fetcher.fetch(src)
            console.print(f"  [dim]→ {af.wav_path.name}  title: {af.title!r}[/dim]")

            # Step 2: transcribe → segments
            console.print("  [dim]Transcribing (this may take a while on CPU)…[/dim]")
            ex = extractor.extract(af)
            console.print(f"  [dim]→ {len(ex.segments)} segments  duration: {ex.source.duration_s:.1f}s[/dim]")

            # Step 3: write to graph
            store.upsert_audio(ex)
            console.print("  [green]✓ Ingested[/green]")

            if verbose:
                for seg in ex.segments[:5]:
                    console.print(f"    [{seg.start_sec:.1f}s → {seg.end_sec:.1f}s] [dim]{seg.text[:80]}[/dim]")
                if len(ex.segments) > 5:
                    console.print(f"    [dim]... {len(ex.segments) - 5} more segments[/dim]")

        except Exception as e:
            console.print(f"  [red]✗ Failed[/red] — {e}")

    console.rule("[bold green]Done")


# ── Shared commands ───────────────────────────────────────────────────────────


@app.command()
def visualize(
    db: Path = typer.Option(_DB, "--db"),
    output: Path = typer.Option(_OUT, "--output", "-o"),
    root: str | None = typer.Option(None, "--root", "-r"),
    depth: int = typer.Option(3, "--depth", "-d"),
) -> None:
    """Generate interactive HTML graph."""
    from agsuperbrain.memory.graph.visualizer import visualize as viz

    viz(_store(db), output, root, depth)
    console.print(f"\n[dim]Open:[/dim] file://{output.resolve()}")


@app.command()
def query(
    cypher: str = typer.Argument(...),
    db: Path = typer.Option(_DB, "--db"),
) -> None:
    """Run a raw Cypher query."""
    rows = _store(db).query(cypher)
    if not rows:
        console.print("[dim]No results.[/dim]")
        return
    t = Table(header_style="bold cyan")
    for i in range(len(rows[0])):
        t.add_column(f"col_{i}")
    for r in rows:
        t.add_row(*[str(v) for v in r])
    console.print(t)


@app.command()
def stats(db: Path = typer.Option(_DB, "--db")) -> None:
    """Show graph statistics across all phases."""
    s = _store(db)
    t = Table(title="Graph Stats", header_style="bold cyan")
    t.add_column("Metric")
    t.add_column("Count", justify="right")
    t.add_column("Phase", justify="center")
    for label, q, phase in [
        ("Modules", "MATCH (m:Module)      RETURN count(m)", "1"),
        ("Functions", "MATCH (f:Function)    RETURN count(f)", "1"),
        ("Call edges", "MATCH ()-[:CALLS]->() RETURN count(*)", "1"),
        ("Documents", "MATCH (d:Document)    RETURN count(d)", "3"),
        ("Sections", "MATCH (s:Section)     RETURN count(s)", "3"),
        ("Concepts", "MATCH (c:Concept)     RETURN count(c)", "3"),
        ("Audio sources", "MATCH (a:AudioSource) RETURN count(a)", "4"),
        ("Transcript segs", "MATCH (t:Transcript)  RETURN count(t)", "4"),
        ("FOLLOWS edges", "MATCH ()-[:FOLLOWS]->() RETURN count(*)", "4"),
    ]:
        rows = s.query(q)
        t.add_row(label, str(rows[0][0] if rows else 0), phase)
    console.print(t)


@app.command(name="index-vectors")
def index_vectors(
    db: Path = typer.Option(_DB, "--db"),
    qdrant_path: Path = typer.Option(_QDRANT, "--qdrant-path"),
    batch_size: int = typer.Option(64, "--batch-size"),
    incremental: bool = typer.Option(False, "--incremental", "-i", help="Only embed nodes not already in Qdrant"),
) -> None:
    """Embed every graph node and store in local Qdrant."""
    from agsuperbrain.core.index_pipeline import VectorIndexPipeline
    from agsuperbrain.memory.graph.graph_store import GraphStore
    from agsuperbrain.memory.vector.embedder import TextEmbedder
    from agsuperbrain.memory.vector.vector_store import VectorStore

    gs = GraphStore(db)
    gs.init_schema()
    vs = VectorStore(db_path=qdrant_path)
    emb = TextEmbedder()

    total = VectorIndexPipeline(gs, vs, emb, batch_size=batch_size).run(incremental=incremental)
    console.print(f"[bold green]✓[/bold green] {total} vectors indexed.")


@app.command(name="search-vectors")
def search_vectors(
    query: str = typer.Argument(..., help="Natural language query"),
    limit: int = typer.Option(5, "--limit", "-k"),
    node_type: str = typer.Option("", "--type", "-t", help="Filter: Function|Section|Concept|Transcript"),
    source_type: str = typer.Option("", "--source-type", "-s", help="Filter: code|document|audio|external"),
    qdrant_path: Path = typer.Option(_QDRANT, "--qdrant-path"),
) -> None:
    """Semantic search over all indexed graph nodes."""
    from agsuperbrain.memory.vector.embedder import TextEmbedder
    from agsuperbrain.memory.vector.vector_store import VectorStore

    emb = TextEmbedder()
    vs = VectorStore(db_path=qdrant_path)
    qvec = emb.embed([query])[0]

    results = vs.search(
        qvec,
        limit=limit,
        node_type=node_type or None,
        source_type=source_type or None,
    )

    if not results:
        console.print("[yellow]No results.[/yellow]")
        return

    t = Table(title=f'Search: "{query}"', header_style="bold cyan")
    t.add_column("Score", justify="right", style="bold green")
    t.add_column("Type", style="cyan")
    t.add_column("Text", max_width=60)
    t.add_column("Source", style="dim")

    for r in results:
        src_short = r.source_path.split("/")[-1] if r.source_path else ""
        t.add_row(
            f"{r.score:.4f}",
            r.node_type,
            r.text[:100],
            src_short,
        )
    console.print(t)


@app.command()
def report(
    db: Path = typer.Option(_DB, "--db"),
    out: Path = typer.Option(Path("./GRAPH_REPORT.md"), "--out", "-o"),
) -> None:
    """Generate GRAPH_REPORT.md summarising the graph (god-nodes, cross-module deps, orphans, suggested questions)."""
    from agsuperbrain.analytics.report import generate_report

    md = generate_report(_store(db))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(md, encoding="utf-8")
    console.print(f"[bold green]✓[/bold green] Wrote {out}")


@app.command(name="inspect-function")
def inspect_function(
    name: str = typer.Argument(..., help="Qualified name (e.g. 'DataProcessor.process') or bare name ('process')"),
    db: Path = typer.Option(_DB, "--db"),
) -> None:
    """Dump body + docstring for a function straight from KùzuDB (diagnostic)."""
    s = _store(db)
    rows = s.query(
        "MATCH (f:Function) "
        "WHERE f.qualified_name = $q OR f.name = $q "
        "RETURN f.qualified_name, f.source_path, f.start_line, f.end_line, "
        "       f.is_method, f.class_name, f.docstring, f.body",
        {"q": name},
    )
    if not rows:
        console.print(f"[yellow]No function matches[/yellow] {name!r}")
        raise typer.Exit(code=1)

    for r in rows:
        qn, src, sl, el, is_m, cn, doc, body = r
        console.rule(f"[bold cyan]{qn}[/bold cyan]")
        console.print(f"[dim]source:[/dim] {src}:{sl}-{el}")
        if is_m:
            console.print(f"[dim]class:[/dim]  {cn or ''}")
        console.print(f"[dim]docstring ({len(doc or '')} chars):[/dim]")
        console.print((doc or "").strip() or "[dim](empty)[/dim]")
        console.print(f"\n[dim]body ({len(body or '')} chars):[/dim]")
        console.print(body or "[dim](empty)[/dim]")


@app.command(name="watch")
def watch(
    paths: list[Path] = typer.Argument(...),
    db: Path = typer.Option(_DB, "--db"),
    qdrant: Path = typer.Option(_QDRANT, "--qdrant"),
    poll_secs: float = typer.Option(2.0, "--poll", "-p", help="Poll interval in seconds"),
    once: bool = typer.Option(False, "--once", "-1", help="Single pass instead of continuous"),
) -> None:
    """
    Watch directories for file changes and incrementally re-index.

    Examples:
        superbrain watch ./src
        superbrain watch ./src --once
        superbrain watch ./src --poll 5
    """
    from agsuperbrain.core.pipeline import DEFAULT_EXCLUDE_DIRS
    from agsuperbrain.core.watcher import FileWatcher
    from agsuperbrain.memory.graph.graph_store import GraphStore
    from agsuperbrain.memory.vector.vector_store import VectorStore

    gs = GraphStore(db)
    gs.init_schema()
    vs = VectorStore(db_path=qdrant)

    watcher = FileWatcher(
        gs,
        vs,
        paths,
        exclude_dirs=DEFAULT_EXCLUDE_DIRS,
    )
    if once:
        watcher.run_once()
    else:
        watcher.start(poll_interval=poll_secs)


@app.command(name="link")
def link_crossmodal(
    db: Path = typer.Option(_DB, "--db"),
    mode: str = typer.Option("all", "--mode", "-m", help="Linking mode: all|documented|mentions"),
) -> None:
    """
    Create cross-modal links between graph layers.

    Links:
      - documented_by: Section → Function (via keyword matching)
      - mentions: Transcript → Function/Concept (via keyword matching)

    Examples:
        superbrain link
        superbrain link --mode documented
        superbrain link --mode mentions
    """
    from agsuperbrain.core.pipeline import link_documented_by, link_mentions

    gs = _store(db)
    gs.init_schema()

    console.rule("[bold cyan]Super-Brain · Cross-Modal Linking")

    linked = 0
    if mode in ("all", "documented"):
        console.print("[dim]Linking documents to functions…[/dim]")
        linked += link_documented_by(gs)
        console.print(f"  [dim]{linked} DOCUMENTED_BY links created[/dim]")

    if mode in ("all", "mentions"):
        mentions = link_mentions(gs)
        console.print(f"  [dim]{mentions} MENTIONS links created[/dim]")
        linked += mentions

    console.print(f"[bold green]✓[/bold green] {linked} cross-modal links created")


@app.command(name="stop")
def stop_cmd(
    path: Path = typer.Option(Path("."), "--path", "-p", help="Project directory"),
) -> None:
    """
    Stop the background watcher. Data is preserved.

    Use this when you want to pause indexing without deleting the graph.
    Re-run `agsuperbrain init` (or any ingest command) to resume.

    Examples:
        agsuperbrain stop
        agsuperbrain stop --path ./my-project
    """
    if _stop_watcher(path):
        console.print("[green]✓[/green] Watcher stopped.")
    else:
        console.print("[dim]No watcher was running.[/dim]")


@app.command(name="clean")
def clean(
    path: Path = typer.Option(Path("."), "--path", "-p", help="Project directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """
    Stop the watcher and wipe all Super-Brain data for this project.

    Removes the entire .agsuperbrain/ directory (graph, vectors, audio cache,
    config, PID file). Your source code is never touched.

    Examples:
        agsuperbrain clean
        agsuperbrain clean --yes          # skip confirmation
        agsuperbrain clean --path ./repo
    """
    import shutil

    config_dir = path / ".agsuperbrain"
    if not config_dir.exists():
        console.print("[dim]Nothing to clean — no .agsuperbrain/ directory found.[/dim]")
        return

    if not yes:
        console.print(f"[yellow]This will delete:[/yellow] {config_dir.resolve()}")
        if not typer.confirm("Proceed?"):
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()

    # Stop watcher first so it can't re-create files mid-clean.
    if _stop_watcher(path):
        console.print("[dim]Stopped background watcher.[/dim]")

    try:
        shutil.rmtree(config_dir)
    except OSError as exc:
        console.print(f"[yellow]Partial clean — {exc}[/yellow]")
        return

    console.print(f"[red]Removed:[/red] {config_dir}")
    console.print("[bold green]✓[/bold green] Super-Brain data cleared.")


@app.command(name="doctor")
def doctor(
    db: Path = typer.Option(_DB, "--db"),
    qdrant: Path = typer.Option(_QDRANT, "--qdrant"),
) -> None:
    """
    Run health checks on the Super-Brain installation.

    Verifies:
    - KuzuDB schema and connectivity
    - Qdrant connectivity
    - tree-sitter language grammars
    - Required system tools (ffmpeg)
    """
    from rich.table import Table

    console.print("\n[bold cyan]Super-Brain Health Check[/bold cyan]\n")

    checks = []

    # 1. Check KuzuDB
    try:
        from agsuperbrain.memory.graph.graph_store import GraphStore

        gs = GraphStore(db)
        gs.init_schema()
        gs.query("MATCH (n) RETURN count(n) LIMIT 1")
        checks.append(("KuzuDB", "OK", "green"))
    except Exception as e:
        checks.append(("KuzuDB", f"FAIL: {e}", "red"))

    # 2. Check Qdrant
    try:
        from agsuperbrain.memory.vector.vector_store import VectorStore

        vs = VectorStore(db_path=qdrant)
        vs.count()
        checks.append(("Qdrant", "OK", "green"))
    except Exception as e:
        checks.append(("Qdrant", f"FAIL: {e}", "red"))

    # 3. Check tree-sitter
    try:
        from agsuperbrain.preprocessing.code_parser import _SUPPORTED_LANGUAGES

        checks.append(("tree-sitter", f"OK ({len(_SUPPORTED_LANGUAGES)} langs)", "green"))
    except Exception as e:
        checks.append(("tree-sitter", f"FAIL: {e}", "red"))

    # 4. Check embedder
    try:
        from agsuperbrain.memory.vector.embedder import TextEmbedder

        emb = TextEmbedder()
        _ = emb.dimension
        checks.append(("Embedder", "OK", "green"))
    except Exception as e:
        checks.append(("Embedder", f"FAIL: {e}", "red"))

    # 5. Check ffmpeg
    import subprocess

    try:
        result = subprocess.run(["ffmpeg", "-version"], capture_output=True, timeout=5)
        if result.returncode == 0:
            checks.append(("ffmpeg", "OK", "green"))
        else:
            checks.append(("ffmpeg", "NOT FOUND", "yellow"))
    except FileNotFoundError:
        checks.append(("ffmpeg", "NOT FOUND", "yellow"))
    except Exception as e:
        checks.append(("ffmpeg", f"ERROR: {e}", "yellow"))

    # 6. Check data directories
    for name, path in [("Graph", db), ("Qdrant", qdrant)]:
        if path.exists():
            checks.append((name, f"OK ({path})", "green"))
        else:
            checks.append((name, f"MISSING ({path})", "yellow"))

    # Render table
    t = Table(header_style="bold cyan")
    t.add_column("Check", style="bold")
    t.add_column("Status")
    for name, status, color in checks:
        t.add_row(name, f"[{color}]{status}[/{color}]")
    console.print(t)

    failed = sum(1 for _, _, c in checks if c == "red")
    if failed > 0:
        console.print(f"\n[red]✗ {failed} check(s) failed[/red]")
        raise typer.Exit(code=1)
    console.print("\n[green]✓ All checks passed[/green]")


@app.command(name="cluster")
def cluster_graph(
    db: Path = typer.Option(_DB, "--db"),
    resolution: float = typer.Option(
        1.0, "--resolution", "-r", help="Leiden resolution (higher = more, smaller communities)"
    ),
    random_state: int = typer.Option(42, "--seed", "-s"),
) -> None:
    """
    Detect communities in the graph using Leiden algorithm.

    Clusters by edge density — no embeddings needed.
    Communities are saved to the graph for later querying.

    Examples:
        superbrain cluster
        superbrain cluster --resolution 1.5
    """
    from agsuperbrain.memory.graph.clustering import cluster

    gs = _store(db)
    gs.init_schema()

    console.rule("[bold cyan]Super-Brain · Community Detection")
    result = cluster(gs, resolution=resolution, random_state=random_state)

    for comm in result.communities:
        gs._create_node(
            "Community",
            {
                "id": f"community_{comm.id}",
                "name": comm.name,
                "size": comm.size,
                "modularity": result.modularity,
            },
        )
        for node_id in comm.nodes:
            gs._merge_edge(
                "Function",
                node_id,
                "Community",
                f"community_{comm.id}",
                "IN_COMMUNITY",
                {"source_path": "clustering"},
            )

    console.print(f"[bold green]✓[/bold green] {len(result.communities)} communities detected")
    console.print(f"[dim]Modularity:[/dim] {result.modularity:.4f}")

    t = Table(title="Communities", header_style="bold cyan")
    t.add_column("ID", justify="right")
    t.add_column("Size", justify="right")
    t.add_column("Sample Nodes", max_width=60)
    for comm in result.communities[:10]:
        sample = ", ".join(comm.nodes[:3])
        t.add_row(str(comm.id), str(comm.size), sample)
    console.print(t)


@app.command(name="export")
def export_graph(
    db: Path = typer.Option(_DB, "--db"),
    output: Path = typer.Option(Path("./graph-export.json"), "--output", "-o"),
) -> None:
    """Export the graph to JSON for portability."""
    from agsuperbrain.memory.graph.graph_store import GraphStore as _GraphStore

    gs = _GraphStore(db)
    gs.init_schema()

    data = {"nodes": [], "edges": []}

    for label in ["Module", "Function", "Document", "Section", "Concept", "AudioSource", "Transcript"]:
        rows = gs.query(f"MATCH (n:{label}) RETURN n")
        for row in rows:
            if row[0]:
                data["nodes"].append({"label": label, **row[0]})

    for rel in ["CALLS", "DEFINED_IN", "CONTAINS", "SOURCE", "FOLLOWS"]:
        rows = gs.query(f"MATCH (a)-[r:{rel}]->(b) RETURN a.id, b.id, r")
        for row in rows:
            if row[0] and row[1]:
                data["edges"].append({"source": row[0], "target": row[1], "relation": rel})

    import json

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(data, indent=2), encoding="utf-8")
    console.print(f"[green]Exported:[/green] {len(data['nodes'])} nodes, {len(data['edges'])} edges")


@app.command(name="import")
def import_graph(
    input: Path = typer.Argument(...),
    db: Path = typer.Option(_DB, "--db"),
) -> None:
    """Import graph from JSON export."""
    import json

    from agsuperbrain.memory.graph.graph_store import GraphStore as _GraphStore

    data = json.loads(input.read_text("utf-8"))

    gs = _GraphStore(db)
    gs.init_schema()

    for node in data.get("nodes", []):
        label = node.pop("label", "Function")
        gs._create_node(label, node)

    for edge in data.get("edges", []):
        src, tgt = edge.get("source"), edge.get("target")
        rel = edge.get("relation", "CALLS")
        if src and tgt:
            gs._merge_edge("Function", src, "Function", tgt, rel, {})

    console.print(f"[green]Imported:[/green] {len(data.get('nodes', []))} nodes")


def _build_tools(db, qdrant_path, no_llm=False):
    from agsuperbrain.intelligence.context_builder import ContextBuilder
    from agsuperbrain.intelligence.llm_engine import get_llm_engine
    from agsuperbrain.intelligence.retriever import HybridRetriever
    from agsuperbrain.intelligence.tools import SuperBrainTools
    from agsuperbrain.memory.graph.graph_store import GraphStore
    from agsuperbrain.memory.vector.embedder import TextEmbedder
    from agsuperbrain.memory.vector.vector_store import VectorStore

    gs = GraphStore(db)
    gs.init_schema()
    vs = VectorStore(db_path=qdrant_path)
    emb = TextEmbedder()
    ret = HybridRetriever(gs, vs, emb)
    cb = ContextBuilder()

    llm = None
    if not no_llm:
        llm = get_llm_engine()

    return SuperBrainTools(ret, cb, llm_engine=llm)


@app.command(name="ask")
def ask(
    query: str = typer.Argument(...),
    mode: str = typer.Option("all", "--mode", "-m"),
    top_k: int = typer.Option(5, "--top-k", "-k"),
    json_output: bool = typer.Option(False, "--json"),
    no_llm: bool = typer.Option(False, "--no-llm"),
    db: Path = typer.Option(_DB, "--db"),
    qdrant_path: Path = typer.Option(_QDRANT, "--qdrant-path"),
) -> None:
    tools = _build_tools(db, qdrant_path, no_llm)
    tools.top_k = top_k
    dispatch = {
        "all": tools.search,
        "code": tools.code_tool,
        "audio": tools.audio_tool,
        "document": tools.document_tool,
    }
    resp = dispatch.get(mode, tools.search)(query)

    if json_output:
        console.print(resp.to_json())
        return

    console.rule("[bold cyan]Super-Brain Answer")
    console.print(f"\n[bold]{resp.answer}[/bold]\n")
    console.print(f"[dim]LLM used:[/dim] {'yes' if resp.used_llm else 'no (deterministic)'}")

    t = Table(title="Evidence", header_style="bold cyan")
    t.add_column("Score", justify="right")
    t.add_column("Hops", justify="right")
    t.add_column("Type", justify="left")
    t.add_column("Text", justify="left")
    t.add_column("Source", justify="left")
    for e in resp.evidence:
        if e.get("is_stub"):
            continue  # hide stubs from table
        t.add_row(
            str(e["score"]),
            str(e["graph_hops"]),
            e["node_type"],
            e["text"][:80],
            e["source_path"].split("/")[-1] if e["source_path"] else "",
        )
    console.print(t)
    console.print(f"\n[dim]Confidence:[/dim] [bold]{resp.confidence:.0%}[/bold]")


@app.command(name="mcp-serve")
def mcp_serve() -> None:
    """
    Start MCP server for IDE/agent integration.

    This exposes Super-Brain tools via stdio JSON-RPC, compatible with:
    - Claude Code
    - Cursor
    - Aider
    - OpenCode
    - Cline
    - Continue

    Example configuration:

    Claude Code:
      Create ~/.claude/settings.json with:
      {
        "mcpServers": {
          "agsuperbrain": {
            "command": "superbrain",
            "args": ["mcp-serve"]
          }
        }
      }

    Cursor:
      Add to ~/.cursor/mcp.json

    Aider:
      Add to .aider.conf.yml:
      mcp-server: agsuperbrain:mcp-serve
    """
    from agsuperbrain.mcp.server import main

    main()


def _detect_source_dir(project: Path) -> Path | None:
    """Return the project root as the default ingest target.

    The extraction pipeline already skips the standard noise directories
    (.venv, node_modules, __pycache__, .git, dist, build, .tox, etc.)
    via the default exclude list, so scanning from the project root is
    safe for any layout — flat Python, src-layout Python, Maven/Gradle/
    Spring Boot (src/main/java/...), Go (cmd/, internal/, pkg/), Rust
    crates, .NET per-project folders, Rails, Flutter (lib/), Swift
    (Sources/), Unity, Unreal, and monorepos. Returns None only if the
    project directory doesn't exist.
    """
    return project if project.is_dir() else None


@app.command(name="init")
def init(
    path: Path = typer.Option(Path("."), "--path", "-p", help="Project directory to initialize"),
    src: Path | None = typer.Option(
        None,
        "--src",
        help="Specific source directory to ingest. Default: the whole "
        "project (standard noise like .venv, node_modules, .git, "
        "dist, build is excluded automatically). Useful for "
        "monorepos: --src ./services/api",
    ),
    skip_ingest: bool = typer.Option(
        False,
        "--skip-ingest",
        help="Skip the initial ingest + index-vectors pass",
    ),
) -> None:
    """
    Initialize Super-Brain in the current project.

    Performs, in order:
      1. Writes .agsuperbrain/config.yaml, .agsuperbrainignore, and updates
         .gitignore and .claude/settings.json
      2. Runs `ingest` + `index-vectors` on the project root (or the path
         given by --src). The pipeline already excludes .venv, node_modules,
         __pycache__, .git, dist, build, etc., so this works for any
         layout — flat, src-layout, Maven/Gradle, Go, Rust, .NET, Rails,
         Flutter, monorepos, and so on.
      3. Starts the background file watcher so subsequent edits are
         incrementally re-indexed

    Examples:
        agsuperbrain init
        agsuperbrain init --path ./my-project
        agsuperbrain init --src ./services/api       # monorepo: one workspace
        agsuperbrain init --skip-ingest              # config only; ingest later
    """
    import json

    config_dir = path / ".agsuperbrain"
    config_dir.mkdir(exist_ok=True)

    config_file = config_dir / "config.yaml"
    if not config_file.exists():
        config_file.write_text("""# Super-Brain configuration
# See docs for all options

# Exclude directories (added to defaults)
exclude: []

# Languages to index (default: all supported)
languages:
  - python
  - javascript
  - typescript

# Watcher settings
watcher:
  debounce_ms: 500

# Graph settings
graph:
  db_path: ./.agsuperbrain/graph

# Vector settings
vector:
  db_path: ./.agsuperbrain/qdrant
""")
        console.print(f"[green]Created:[/green] {config_file}")

    ignore_file = path / ".agsuperbrainignore"
    if not ignore_file.exists():
        ignore_file.write_text("""# Super-Brain package-specific ignores
# These are internal to the package, not user code
.agsuperbrain/
*.log
""")
        console.print(f"[green]Created:[/green] {ignore_file}")

    claude_settings = path / ".claude" / "settings.json"
    claude_settings.parent.mkdir(exist_ok=True)

    mcp_config = {"mcpServers": {"agsuperbrain": {"command": "agsuperbrain", "args": ["mcp-serve"]}}}

    if claude_settings.exists():
        existing = json.loads(claude_settings.read_text())
        existing.setdefault("mcpServers", {}).update(mcp_config["mcpServers"])
        claude_settings.write_text(json.dumps(existing, indent=2))
        console.print(f"[green]Updated:[/green] {claude_settings}")
    else:
        claude_settings.write_text(json.dumps(mcp_config, indent=2))
        console.print(f"[green]Created:[/green] {claude_settings}")

    gitignore = path / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text()
        if ".agsuperbrain/" not in content:
            gitignore.write_text(content + "\n# Super-Brain\n.agsuperbrain/\n")
            console.print("[green]Updated:[/green] .gitignore")

    console.print(f"\n[bold green]✓[/bold green] Super-Brain initialized in {path}")

    ingest_target: Path | None = None
    if not skip_ingest:
        if src is not None:
            if src.exists():
                ingest_target = src
            else:
                console.print(f"\n[yellow]Source path {src} does not exist. Skipping initial ingest.[/yellow]")
        else:
            ingest_target = _detect_source_dir(path)
            if ingest_target is None:
                console.print(
                    "\n[dim]No source directory detected. "
                    "Run `agsuperbrain ingest <path>` when you have code to "
                    "index.[/dim]"
                )

    if ingest_target is not None:
        console.print(
            f"\n[bold cyan]Ingesting[/bold cyan] [green]{ingest_target}[/green] "
            f"[dim](use --skip-ingest to opt out)[/dim]"
        )
        try:
            from agsuperbrain.core.pipeline import CodeGraphPipeline

            CodeGraphPipeline(_store(_DB)).run([ingest_target], verbose=False)
        except ImportError as exc:
            console.print(
                f"\n[yellow]Ingest skipped — missing runtime dependency:[/yellow] "
                f"[dim]{exc}[/dim]\n"
                f"  Reinstall with all dependencies:  "
                f"[cyan]pip install -U agsuperbrain[/cyan]\n"
                f"  Diagnose all components:          "
                f"[cyan]agsuperbrain doctor[/cyan]\n"
                f"  Then retry ingest:                "
                f"[cyan]agsuperbrain ingest .[/cyan]"
            )
        except Exception as exc:
            console.print(
                f"\n[yellow]Ingest skipped due to error:[/yellow] {exc}\n"
                f"  Retry after fixing:  [cyan]agsuperbrain ingest .[/cyan]"
            )
        else:
            console.print("\n[bold cyan]Building vector index...[/bold cyan]")
            try:
                from agsuperbrain.core.index_pipeline import VectorIndexPipeline
                from agsuperbrain.memory.graph.graph_store import GraphStore
                from agsuperbrain.memory.vector.embedder import TextEmbedder
                from agsuperbrain.memory.vector.vector_store import VectorStore

                gs = GraphStore(_DB)
                gs.init_schema()
                vs = VectorStore(db_path=_QDRANT)
                total = VectorIndexPipeline(gs, vs, TextEmbedder()).run(incremental=True)
                console.print(f"[bold green]✓[/bold green] {total} vectors indexed.")
            except ImportError as exc:
                console.print(
                    f"\n[yellow]Vector indexing skipped — missing runtime dependency:[/yellow] "
                    f"[dim]{exc}[/dim]\n"
                    f"  Reinstall with all dependencies:  "
                    f"[cyan]pip install -U agsuperbrain[/cyan]\n"
                    f"  Then retry:                       "
                    f"[cyan]agsuperbrain index-vectors[/cyan]"
                )
            except Exception as exc:
                console.print(
                    f"\n[yellow]Vector indexing skipped due to error:[/yellow] {exc}\n"
                    f"  Retry after fixing:  [cyan]agsuperbrain index-vectors[/cyan]"
                )

    console.print("\n[bold cyan]Starting background watcher...[/bold cyan]")
    _start_watcher_background(path)
    console.print("[dim]Watcher is now running in background.[/dim]")
    console.print("Your code will be automatically indexed as you work!")

    console.print(
        "\n[bold]Next:[/bold] wire Super-Brain into your AI coding tool:\n"
        "  [cyan]agsuperbrain claude-install[/cyan]   "
        "[dim]# or cursor-install / aider-install / codex-install / ...[/dim]\n"
        "  [cyan]agsuperbrain install --platform all[/cyan]  "
        "[dim]# all 14 supported tools at once[/dim]"
    )


# ── Platform-specific install commands ──────────────────────────────────


@app.command(name="claude-install")
def install_claude(
    path: Path = typer.Option(Path("."), "--path", "-p", help="Project directory"),
) -> None:
    """
    Install always-on integration for Claude Code.

    Creates:
      - .claude/settings.json with PreToolUse hook
      - AGENTS.md with always-on rules
      - MCP server configuration

    This makes Claude Code automatically use the knowledge graph
    before every file search - no need to explicitly invoke.

    Example:
        agsuperbrain claude install
    """
    import json

    console.rule("[bold cyan]Super-Brain · Claude Code Integration")

    # 1. Create CLAUDE.md rules (global)
    claude_md = path / "CLAUDE.md"
    rules_content = """# Super-Brain Knowledge Graph

You have access to a Super-Brain knowledge graph in this project.

When answering architecture questions:
1. Check if a knowledge graph exists: .agsuperbrain/graph/
2. If it exists, query it first instead of searching raw files
3. Use AGENTS.md for context about the codebase

Commands:
- agsuperbrain ask "question" - Query the graph
- agsuperbrain visualize - Open interactive graph
"""
    if claude_md.exists():
        content = claude_md.read_text()
        if "# Super-Brain" not in content:
            claude_md.write_text(content + "\n\n" + rules_content)
            console.print("[green]Updated:[/green] CLAUDE.md")
    else:
        claude_md.write_text(rules_content)
        console.print("[green]Created:[/green] CLAUDE.md")

    # 2. Create AGENTS.md
    agents_md = path / "AGENTS.md"
    agent_rules = """# Super-Brain Agent Rules

## Always-On Context
- Read .agsuperbrain/graph/ for knowledge graph
- Query graph before searching raw files for architecture questions

## Tools
Use `agsuperbrain` CLI for:
- Semantic search: agsuperbrain search-vectors "query"
- Ask questions: agsuperbrain ask "question"
- Visualize: agsuperbrain visualize

## Graph Tips
- God nodes = most called functions (entry points)
- Call chains show dependencies
- Communities show related code groups
"""
    if agents_md.exists():
        content = agents_md.read_text()
        if "# Super-Brain" not in content:
            agents_md.write_text(content + "\n\n" + agent_rules)
            console.print("[green]Updated:[/green] AGENTS.md")
    else:
        agents_md.write_text(agent_rules)
        console.print("[green]Created:[/green] AGENTS.md")

    # 3. Create PreToolUse hook in settings.json
    settings_file = path / ".claude" / "settings.json"
    settings_file.parent.mkdir(exist_ok=True)

    current_settings = {} if not settings_file.exists() else json.loads(settings_file.read_text())

    current_settings.update(
        {
            "hooks": {
                "PreToolUse": {
                    "type": "command",
                    "command": "bash",
                    "arguments": [
                        "-c",
                        '[ -f .agsuperbrain/graph/superbrain.db ] && echo \'{"hookSpecificOutput":{"hookEventName":"PreToolUse","additionalContext":"Super-Brain: Knowledge graph exists. Use agsuperbrain ask or search-vectors before raw file searches."}}\' || echo \'\'',
                    ],
                }
            }
        }
    )

    settings_file.write_text(json.dumps(current_settings, indent=2))
    console.print("[green]Created:[/green] .claude/settings.json with PreToolUse hook")

    console.print("\n[bold green]✓[/bold green] Claude Code always-on installed")
    console.print("\nNow Claude will consult the graph before file searches!")


@app.command(name="claude-uninstall")
def uninstall_claude(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Remove Claude Code always-on integration."""
    console = Console()

    files_to_remove = [
        path / "CLAUDE.md",
        path / "AGENTS.md",
    ]

    for f in files_to_remove:
        if f.exists():
            f.unlink()
            console.print(f"[yellow]Removed:[/yellow] {f.name}")

    # Keep MCP config but remove hooks
    settings_file = path / ".claude" / "settings.json"
    if settings_file.exists():
        import json

        settings = json.loads(settings_file.read_text())
        if "hooks" in settings:
            del settings["hooks"]
            settings_file.write_text(json.dumps(settings, indent=2))
            console.print("[yellow]Removed:[/yellow] hooks from settings.json")

    console.print("[green]Claude Code integration removed[/green]")


@app.command(name="cursor-install")
def install_cursor(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """
    Install always-on for Cursor.

    Creates .cursor/rules/superbrain.mdc with always-on rules.

    Example:
        agsuperbrain cursor-install
    """
    from rich.console import Console

    console = Console()

    console.rule("[bold cyan]Super-Brain · Cursor Integration")

    rules_dir = path / ".cursor" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)

    rules_file = rules_dir / "superbrain.mdc"
    rules_content = """# Super-Brain Knowledge Graph

Always apply this rule: Use the Super-Brain knowledge graph for architecture questions.

Commands available:
- agsuperbrain ask "question" - Query the graph
- agsuperbrain search-vectors "query" - Semantic search
- agsuperbrain visualize - Open interactive graph

When answering questions about code architecture:
1. Query the graph first via `agsuperbrain ask`
2. Check .agsuperbrain/graph/ for existing knowledge

This provides context about functions, callers, dependencies, and communities.
"""

    if rules_file.exists():
        console.print(f"[yellow]Already exists:[/yellow] {rules_file.name}")
    else:
        rules_file.write_text(rules_content)
        console.print(f"[green]Created:[/green] {rules_file}")

    console.print("\n[bold green]✓[/bold green] Cursor always-on installed")


@app.command(name="cursor-uninstall")
def uninstall_cursor(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Remove Cursor always-on integration."""
    from rich.console import Console

    console = Console()

    rules_file = path / ".cursor" / "rules" / "superbrain.mdc"
    if rules_file.exists():
        rules_file.unlink()
        console.print(f"[yellow]Removed:[/yellow] {rules_file.name}")
    else:
        console.print("[dim]No Cursor rules found[/dim]")


@app.command(name="aider-install")
def install_aider(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """
    Install always-on for Aider.

    Updates .aider.conf.yml with MCP server.

    Example:
        agsuperbrain aider install
    """
    from rich.console import Console

    console = Console()

    console.rule("[bold cyan]Super-Brain · Aider Integration")

    conf_file = path / ".aider.conf.yml"
    mcp_line = "mcp-server: agsuperbrain:mcp-serve\n"

    if conf_file.exists():
        content = conf_file.read_text()
        if "agsuperbrain" not in content:
            conf_file.write_text(content + "\n" + mcp_line)
            console.print("[green]Updated:[/green] .aider.conf.yml")
        else:
            console.print("[dim]Already configured[/dim]")
    else:
        conf_file.write_text(mcp_line)
        console.print("[green]Created:[/green] .aider.conf.yml")

    # Also create AGENTS.md for always-on
    agents_file = path / "AGENTS.md"
    agents_content = """# Super-Brain for Aider

## Always-On
Use the Super-Brain knowledge graph:

- `agsuperbrain ask "question"` - Query graph
- `agsuperbrain search-vectors "query"` - Semantic search

Query graph before searching files for architecture context.
"""

    if agents_file.exists():
        content = agents_file.read_text()
        if "# Super-Brain" not in content:
            agents_file.write_text(content + "\n\n" + agents_content)
            console.print("[green]Updated:[/green] AGENTS.md")
    else:
        agents_file.write_text(agents_content)
        console.print("[green]Created:[/green] AGENTS.md")

    console.print("\n[bold green]✓[/bold green] Aider always-on installed")


@app.command(name="aider-uninstall")
def uninstall_aider(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Remove Aider always-on integration."""
    from rich.console import Console

    console = Console()

    conf_file = path / ".aider.conf.yml"
    if conf_file.exists():
        lines = [line for line in conf_file.read_text().splitlines() if "agsuperbrain" not in line]
        conf_file.write_text("\n".join(lines) + "\n")
        console.print("[yellow]Removed Super-Brain from:[/yellow] .aider.conf.yml")


# ── Additional Platform Install Commands ────────────────────────────────────────


@app.command(name="codex-install")
def install_codex(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """
    Install always-on for OpenAI Codex.

    Creates AGENTS.md and PreToolUse hook.

    Example:
        agsuperbrain codex install
    """

    console.rule("[bold cyan]Super-Brain · Codex Integration")

    agents_md = path / "AGENTS.md"
    agents_content = """# Super-Brain for Codex

Always consult the knowledge graph for architecture questions.

Commands:
- agsuperbrain ask "question"
- agsuperbrain search-vectors "query"

Query .agsuperbrain/graph/ first for context.
"""
    if agents_md.exists():
        content = agents_md.read_text()
        if "# Super-Brain" not in content:
            agents_md.write_text(content + "\n\n" + agents_content)
            console.print("[green]Updated:[/green] AGENTS.md")
    else:
        agents_md.write_text(agents_content)
        console.print("[green]Created:[/green] AGENTS.md")

    console.print("\n[bold green]✓[/bold green] Codex always-on installed")


@app.command(name="opencode-install")
def install_opencode(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """
    Install always-on for OpenCode.

    Creates AGENTS.md and plugin.

    Example:
        agsuperbrain opencode install
    """

    console.rule("[bold cyan]Super-Brain · OpenCode Integration")

    agents_md = path / "AGENTS.md"
    agents_content = """# Super-Brain for OpenCode

Always consult the knowledge graph for architecture questions.

Commands:
- agsuperbrain ask "question"
- agsuperbrain search-vectors "query"
"""
    if agents_md.exists():
        content = agents_md.read_text()
        if "# Super-Brain" not in content:
            agents_md.write_text(content + "\n\n" + agents_content)
    else:
        agents_md.write_text(agents_content)
        console.print("[green]Created:[/green] AGENTS.md")

    console.print("\n[bold green]✓[/bold green] OpenCode always-on installed")


@app.command(name="copilot-install")
def install_copilot(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """
    Install for GitHub Copilot CLI.

    Example:
        agsuperbrain copilot install
    """
    console.rule("[bold cyan]Super-Brain · GitHub Copilot CLI")

    # Create skill file
    skill_dir = Path.home() / ".copilot" / "skills" / "superbrain"
    skill_dir.parent.mkdir(parents=True, exist_ok=True)

    skill_content = """# Super-Brain Skill

Query the Super-Brain knowledge graph using:
- agsuperbrain ask "question"
- agsuperbrain search-vectors "query"

This provides context about code architecture, dependencies, and communities.
"""
    skill_file = skill_dir / "SKILL.md"
    skill_file.parent.mkdir(parents=True, exist_ok=True)
    skill_file.write_text(skill_content)
    console.print(f"[green]Created:[/green] {skill_file}")

    console.print("\n[bold green]✓[/bold green] GitHub Copilot CLI installed")


@app.command(name="vscode-install")
def install_vscode(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """
    Install for VS Code Copilot Chat.

    Creates .github/copilot-instructions.md
    """
    console.rule("[bold cyan]Super-Brain · VS Code Copilot")

    instructions = path / ".github" / "copilot-instructions.md"
    instructions.parent.mkdir(parents=True, exist_ok=True)

    content = """# Super-Brain Context

Use agsuperbrain CLI for knowledge graph queries:
- agsuperbrain ask "question"
- agsuperbrain search-vectors "query"

This provides architecture context before file searches.
"""
    instructions.write_text(content)
    console.print(f"[green]Created:[/green] {instructions}")

    console.print("\n[bold green]✓[/bold green] VS Code Copilot installed")


@app.command(name="openclaw-install")
def install_openclaw(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Install for OpenClaw."""
    console.rule("[bold cyan]Super-Brain · OpenClaw")

    agents_md = path / "AGENTS.md"
    if agents_md.exists():
        content = agents_md.read_text()
        if "# Super-Brain" not in content:
            agents_md.write_text(
                content + "\n\n# Super-Brain for OpenClaw\nUse agsuperbrain ask for architecture context."
            )
    else:
        agents_md.write_text("# Super-Brain for OpenClaw\nUse agsuperbrain ask for architecture context.")
    console.print("[green]Created:[/green] AGENTS.md")

    console.print("\n[bold green]✓[/bold green] OpenClaw installed")


@app.command(name="droid-install")
def install_droid(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Install for Factory Droid."""
    console.rule("[bold cyan]Super-Brain · Factory Droid")

    agents_md = path / "AGENTS.md"
    if agents_md.exists():
        content = agents_md.read_text()
        if "# Super-Brain" not in content:
            agents_md.write_text(content + "\n\n# Super-Brain for Factory Droid\nUse agsuperbrain ask for context.")
    else:
        agents_md.write_text("# Super-Brain for Factory Droid\nUse agsuperbrain ask for context.")
    console.print("[green]Created:[/green] AGENTS.md")

    console.print("\n[bold green]✓[/bold green] Factory Droid installed")


@app.command(name="trae-install")
def install_trae(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Install for Trae AI."""
    console.rule("[bold cyan]Super-Brain · Trae")

    agents_md = path / "AGENTS.md"
    if agents_md.exists():
        content = agents_md.read_text()
        if "# Super-Brain" not in content:
            agents_md.write_text(content + "\n\n# Super-Brain for Trae\nUse agsuperbrain ask for architecture context.")
    else:
        agents_md.write_text("# Super-Brain for Trae\nUse agsuperbrain ask for architecture context.")
    console.print("[green]Created:[/green] AGENTS.md")

    console.print("\n[bold green]✓[/bold green] Trae installed")


@app.command(name="gemini-install")
def install_gemini(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Install for Gemini CLI."""
    import json

    console.rule("[bold cyan]Super-Brain · Gemini CLI")

    # Create AGENTS.md
    agents_md = path / "AGENTS.md"
    agents_content = """# Super-Brain for Gemini CLI

Use agsuperbrain CLI for architecture queries:
- agsuperbrain ask "question"
- agsuperbrain search-vectors "query"
"""
    if agents_md.exists():
        content = agents_md.read_text()
        if "# Super-Brain" not in content:
            agents_md.write_text(content + "\n\n" + agents_content)
    else:
        agents_md.write_text(agents_content)
    console.print("[green]Created:[/green] AGENTS.md")

    # Create .gemini/settings.json with BeforeTool hook
    gemini_dir = path / ".gemini"
    gemini_dir.mkdir(exist_ok=True)
    settings_file = gemini_dir / "settings.json"

    hook_config = {
        "hooks": {
            "BeforeTool": {
                "type": "command",
                "command": "bash",
                "arguments": [
                    "-c",
                    "[ -f .agsuperbrain/graph/superbrain.db ] && echo 'Super-Brain: Use agsuperbrain ask before file reads.' || echo ''",
                ],
            }
        }
    }

    if settings_file.exists():
        existing = json.loads(settings_file.read_text())
        existing.update(hook_config)
        settings_file.write_text(json.dumps(existing, indent=2))
    else:
        settings_file.write_text(json.dumps(hook_config, indent=2))

    console.print("[green]Created:[/green] .gemini/settings.json with BeforeTool hook")

    console.print("\n[bold green]✓[/bold green] Gemini CLI installed")


@app.command(name="hermes-install")
def install_hermes(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Install for Hermes AI."""
    console.rule("[bold cyan]Super-Brain · Hermes")

    # Create global skill
    skill_dir = Path.home() / ".hermes" / "skills" / "superbrain"
    skill_dir.mkdir(parents=True, exist_ok=True)

    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text("""# Super-Brain Skill

Use agsuperbrain ask "question" to query the knowledge graph.
Use agsuperbrain search-vectors "query" for semantic search.
""")
    console.print(f"[green]Created:[/green] {skill_file}")

    # Create AGENTS.md
    agents_md = path / "AGENTS.md"
    if agents_md.exists():
        content = agents_md.read_text()
        if "# Super-Brain" not in content:
            agents_md.write_text(content + "\n\n# Super-Brain for Hermes\nUse agsuperbrain ask.")
    else:
        agents_md.write_text("# Super-Brain for Hermes\nUse agsuperbrain ask.")
    console.print("[green]Created:[/green] AGENTS.md")

    console.print("\n[bold green]✓[/bold green] Hermes installed")


@app.command(name="kiro-install")
def install_kiro(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Install for Kiro IDE."""
    console.rule("[bold cyan]Super-Brain · Kiro")

    # Create skill
    skill_dir = path / ".kiro" / "skills" / "superbrain"
    skill_dir.mkdir(parents=True, exist_ok=True)

    skill_file = skill_dir / "SKILL.md"
    skill_file.write_text("""# Super-Brain Skill

Invoke via /superbrain command.
Use agsuperbrain ask for architecture questions.
""")
    console.print(f"[green]Created:[/green] {skill_file}")

    # Create steering file
    steering_dir = path / ".kiro" / "steering"
    steering_dir.mkdir(parents=True, exist_ok=True)

    steering_file = steering_dir / "superbrain.md"
    steering_file.write_text("""# Super-Brain Steering

inclusion: always
""")
    console.print(f"[green]Created:[/green] {steering_file}")

    console.print("\n[bold green]✓[/bold green] Kiro installed")


@app.command(name="antigravity-install")
def install_antigravity(
    path: Path = typer.Option(Path("."), "--path", "-p"),
) -> None:
    """Install for Google Antigravity."""
    console.rule("[bold cyan]Super-Brain · Google Antigravity")

    # Create agent rules
    rules_dir = path / ".agent" / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)

    rules_file = rules_dir / "superbrain.md"
    rules_file.write_text("""# Super-Brain Agent Rules

Always apply:
- Use agsuperbrain ask "question" to query the knowledge graph
- Use agsuperbrain search-vectors "query" for semantic search

This provides architecture context before file operations.
""")
    console.print(f"[green]Created:[/green] {rules_file}")

    # Create workflows
    workflow_dir = path / ".agent" / "workflows"
    workflow_dir.mkdir(parents=True, exist_ok=True)

    workflow_file = workflow_dir / "superbrain.md"
    workflow_file.write_text("""# Super-Brain Workflows

Commands:
- /superbrain ask "question"
- /superbrain search "query"
- /superbrain visualize
""")
    console.print(f"[green]Created:[/green] {workflow_file}")

    console.print("\n[bold green]✓[/bold green] Google Antigravity installed")


# ── Unified install command ────────────────────────────────────────────────


@app.command(name="install")
def install_all(
    platform: str = typer.Option(
        "all",
        "--platform",
        "-p",
        help="Platform: all, claude, cursor, aider, codex, opencode, vscode, openclaw, droid, trae, gemini, hermes, kiro, antigravity",
    ),
    path: Path = typer.Option(Path("."), "--path"),
) -> None:
    """
    Install Super-Brain for specific platform(s).

    Examples:
        agsuperbrain install                    # Show help
        agsuperbrain install all               # Install all platforms
        agsuperbrain install claude            # Claude Code
        agsuperbrain install cursor             # Cursor
        agsuperbrain install aider              # Aider

    Supported platforms: all, claude, cursor, aider, codex, opencode, vscode, openclaw, droid, trae, gemini, hermes, kiro, antigravity
    """
    platform = platform.lower()

    if platform == "all":
        console.print("[bold]Installing all platforms...[/bold]\n")

    installed = []

    if platform == "all" or platform == "claude":
        try:
            install_claude(path)
            installed.append("claude")
        except Exception as e:
            console.print(f"[red]Claude install failed: {e}[/red]")

    if platform == "all" or platform == "cursor":
        try:
            install_cursor(path)
            installed.append("cursor")
        except Exception as e:
            console.print(f"[red]Cursor install failed: {e}[/red]")

    if platform == "all" or platform == "aider":
        try:
            install_aider(path)
            installed.append("aider")
        except Exception as e:
            console.print(f"[red]Aider install failed: {e}[/red]")

    if platform == "all" or platform == "codex":
        try:
            install_codex(path)
            installed.append("codex")
        except Exception as e:
            console.print(f"[red]Codex install failed: {e}[/red]")

    if platform == "all" or platform == "opencode":
        try:
            install_opencode(path)
            installed.append("opencode")
        except Exception as e:
            console.print(f"[red]OpenCode install failed: {e}[/red]")

    if platform == "all" or platform == "vscode":
        try:
            install_vscode(path)
            installed.append("vscode")
        except Exception as e:
            console.print(f"[red]VSCode install failed: {e}[/red]")

    if platform == "all" or platform == "openclaw":
        try:
            install_openclaw(path)
            installed.append("openclaw")
        except Exception as e:
            console.print(f"[red]OpenClaw install failed: {e}[/red]")

    if platform == "all" or platform == "droid":
        try:
            install_droid(path)
            installed.append("droid")
        except Exception as e:
            console.print(f"[red]Factory Droid install failed: {e}[/red]")

    if platform == "all" or platform == "trae":
        try:
            install_trae(path)
            installed.append("trae")
        except Exception as e:
            console.print(f"[red]Trae install failed: {e}[/red]")

    if platform == "all" or platform == "gemini":
        try:
            install_gemini(path)
            installed.append("gemini")
        except Exception as e:
            console.print(f"[red]Gemini CLI install failed: {e}[/red]")

    if platform == "all" or platform == "hermes":
        try:
            install_hermes(path)
            installed.append("hermes")
        except Exception as e:
            console.print(f"[red]Hermes install failed: {e}[/red]")

    if platform == "all" or platform == "kiro":
        try:
            install_kiro(path)
            installed.append("kiro")
        except Exception as e:
            console.print(f"[red]Kiro install failed: {e}[/red]")

    if platform == "all" or platform == "antigravity":
        try:
            install_antigravity(path)
            installed.append("antigravity")
        except Exception as e:
            console.print(f"[red]Google Antigravity install failed: {e}[/red]")

    if installed:
        console.rule("[bold green]Installation Complete")
        console.print(f"[green]Installed: {', '.join(installed)}[/green]")
