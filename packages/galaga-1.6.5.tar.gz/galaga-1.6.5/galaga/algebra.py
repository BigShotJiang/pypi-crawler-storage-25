"""Core algebra and multivector types.

This module is the numeric engine of the ``ga`` library. It contains:

1. ``Algebra`` — An immutable Clifford algebra factory, parameterised by a
   metric signature. On construction it precomputes the full multiplication
   table (sign and index arrays), so that all subsequent products are
   table lookups, not recomputation.

2. ``Multivector`` — A lightweight value type: just an ``Algebra`` reference
   and a dense NumPy array of ``2^n`` coefficients (one per basis blade).
   Operator overloads (``*``, ``^``, ``|``, ``~``) delegate to the named
   functions below.

3. Named operations — Every GA product and transformation is a module-level
   function (``gp``, ``op``, ``left_contraction``, ``grade``, ``reverse``,
   etc.). These are the stable public API; operators are convenience sugar.

Representation choices
----------------------
- **Basis blades as bitmasks.** A blade like e₁₃ is the integer ``0b101``
  (bits 0 and 2 set). This makes the geometric product a XOR of bitmasks
  (for the resulting blade) plus a sign computation (for reordering).

- **Dense coefficient arrays.** A multivector in Cl(n) stores ``2^n`` floats,
  one per blade, regardless of sparsity. This is simple and fast for small n
  (≤8 or so). The index into the array *is* the bitmask.

- **Precomputed multiplication tables.** ``_mul_index[i,j]`` gives the
  result bitmask and ``_mul_sign[i,j]`` gives the sign+metric factor for
  the product of basis blades i and j. This turns the geometric product
  into a sparse scatter-add over nonzero coefficients.

- **Precomputed grade masks.** ``_grade_masks[k]`` is a boolean array that
  selects all blade indices of grade k. Grade projection is a single
  masked copy.
"""

from __future__ import annotations

import numpy as np


def _sign_of_reorder(a: int, b: int) -> int:
    """Compute the sign incurred by concatenating two basis blade bitmasks.

    When we multiply basis blades e_A and e_B, the result blade is e_{A^B}
    but we need to count how many transpositions are required to move the
    basis vectors of B past those of A into canonical (sorted) order.

    Algorithm: for each bit in A (from high to low), count how many bits
    in B are *below* it. Each such pair is one transposition → one sign flip.
    The total parity (even/odd) gives the sign: +1 or -1.

    This is the standard "canonical reordering sign" from Clifford algebra
    implementations. It runs in O(n²) where n is the number of basis vectors,
    which is fine for n ≤ 16.
    """
    n = 0
    a = a >> 1
    while a:
        n += bin(a & b).count("1")
        a = a >> 1
    return 1 - 2 * (n & 1)


from . import render as _render
from .basis_blade import BasisBlade
from .blade_convention import BladeConvention, _resolve_metric_role_key, b_default, build_blades
from .latex_emit import emit as _latex_emit
from .latex_nodes import Seq, Text
from .latex_nodes import fmt_coeff as _fmt_coeff
from .latex_nodes import sci_lnode as _sci_lnode
from .latex_symbols import LatexSymbols
from .notation import Notation
from .ops import build_expr, ga_op, is_sym, make_sym


def _resolve_symbolic(lazy: bool | None, symbolic: bool | None) -> bool:
    """Resolve lazy=/symbolic= pair. Raises if both are explicitly set."""
    if lazy is not None and symbolic is not None:
        raise ValueError("Cannot pass both lazy= and symbolic=; use one or the other")
    if symbolic is not None:
        return symbolic
    if lazy is not None:
        return lazy
    return False


class Algebra:
    """Immutable Clifford algebra Cl(p,q,r) defined by a metric signature.

    Can be constructed two ways:

    1. Explicit signature — an iterable of basis vector squares::

        Algebra((1, 1, 1))          # Cl(3,0) — 3D Euclidean
        Algebra((1, -1, -1, -1))    # Cl(1,3) — spacetime
        Algebra((1, 1, 1, 0))       # Cl(3,0,1) — PGA

    2. Cl(p, q, r) notation — counts of +1, -1, and 0 basis vectors::

        Algebra(3)                  # Cl(3,0) — 3D Euclidean
        Algebra(1, 3)               # Cl(1,3) — spacetime
        Algebra(3, 0, 1)            # Cl(3,0,1) — PGA

    The signature ordering is: r null vectors, then p positive, then q negative.
    This matches the convention used by clifford, kingdon, ganja.js, and most
    PGA literature (where the null basis vector is conventionally e₀).

    On construction, the algebra precomputes:
    - ``_mul_index[i,j]``: the bitmask of the result blade for basis blades i*j
    - ``_mul_sign[i,j]``:  the scalar factor (reordering sign × metric) for i*j
    - ``_grade_masks[k]``: boolean mask selecting all grade-k blade indices

    These tables make all subsequent products O(s) where s is the number of
    nonzero coefficients, with no per-product sign/metric computation.

    Args:
        p_or_signature: Either an iterable of +1/-1/0 (explicit signature),
                        or an int p (number of positive basis vectors).
        q: Number of negative basis vectors (only when p is an int).
        r: Number of null/degenerate basis vectors (only when p is an int).
        blades: A BladeConvention controlling blade naming and display.
                If None, uses b_default() (compact, 1-based, e prefix).
        repr_unicode: If True (default), ``repr()`` uses Unicode.
                      If False, ``repr()`` uses ASCII.
        display_repr: If True, ``repr()``, ``str()``, and ``_repr_latex_()`` on
                 multivectors delegate to ``mv.display()`` (showing
                 name = expression = value) instead of the default rendering.
    """

    __slots__ = (
        "_sig",
        "_dim",
        "_n",
        "_mul_index",
        "_mul_sign",
        "_grade_masks",
        "_repr_unicode",
        "_complement_sign",
        "_blades",
        "_blades_convention",
        "_display_order",
        "_notation",
        "_display_mode",
    )

    def __init__(
        self,
        p_or_signature,
        q: int = 0,
        r: int = 0,
        *,
        blades=None,
        repr_unicode: bool = True,
        notation: Notation | None = None,
        display_repr: bool = False,
    ):
        self._notation = notation or Notation()
        # Resolve signature: iterable of squares, or (p, q, r) counts
        if isinstance(p_or_signature, (int, np.integer)) and not isinstance(p_or_signature, bool):
            if not isinstance(q, (int, np.integer)) or not isinstance(r, (int, np.integer)):
                raise TypeError("q and r must be integers")
            if p_or_signature < 0 or q < 0 or r < 0:
                raise ValueError("p, q, r must be non-negative integers")
            signature = (0,) * r + (1,) * p_or_signature + (-1,) * q
        elif isinstance(p_or_signature, (tuple, list)):
            if q != 0 or r != 0:
                raise TypeError("q and r cannot be used with an explicit signature")
            signature = tuple(p_or_signature)
            if not all(s in (1, -1, 0, 1.0, -1.0, 0.0) for s in signature):
                raise ValueError("Signature values must be +1, -1, or 0")
            signature = tuple(int(s) for s in signature)
        else:
            raise TypeError(
                f"First argument must be a signature tuple/list or an int p, got {type(p_or_signature).__name__}"
            )
        self._sig = signature
        self._n = len(signature)
        self._dim = 1 << self._n
        self._repr_unicode = repr_unicode
        self._display_mode = display_repr

        # Resolve blade convention
        if blades is None:
            blades = b_default()
        if not isinstance(blades, BladeConvention):
            raise TypeError(f"blades must be a BladeConvention, got {type(blades).__name__}")
        self._blades_convention = blades

        # Precompute multiplication tables
        mul_index = np.empty((self._dim, self._dim), dtype=np.intp)
        mul_sign = np.zeros((self._dim, self._dim), dtype=np.float64)

        for i in range(self._dim):
            for j in range(self._dim):
                result, sign = self._blade_product(i, j)
                mul_index[i, j] = result
                mul_sign[i, j] = sign

        self._mul_index = mul_index
        self._mul_sign = mul_sign

        # Precompute grade masks
        self._grade_masks = {}
        for k in range(self._n + 1):
            self._grade_masks[k] = np.array([bin(i).count("1") == k for i in range(self._dim)], dtype=bool)

        # Precompute complement signs
        full = self._dim - 1
        comp_sign = np.zeros(self._dim)
        for s in range(self._dim):
            sc = full ^ s
            swaps = 0
            for i in range(self._n):
                if sc & (1 << i):
                    swaps += bin(s >> (i + 1)).count("1")
            comp_sign[s] = (-1) ** swaps
        self._complement_sign = comp_sign

        # Build BasisBlade objects via convention
        self._blades = build_blades(blades, signature)

        # Resolve display order
        if blades.display_order is not None:
            do = tuple(blades.display_order)
            if len(do) != self._dim:
                raise ValueError(f"display_order has {len(do)} entries, expected {self._dim}")
            if set(do) != set(range(self._dim)):
                raise ValueError("display_order must be a permutation of range(dim)")
            self._display_order = do
        else:
            self._display_order = tuple(range(self._dim))

    def _blade_product(self, a: int, b: int) -> tuple[int, float]:
        """Compute the geometric product of two basis blades given as bitmask indices.

        The geometric product of e_A * e_B involves three steps:
        1. Reordering sign: count transpositions to merge the two index sets.
        2. Result blade: XOR the bitmasks (shared indices cancel out).
        3. Metric factor: each shared basis vector contributes its signature
           value (the square of that basis vector: +1, -1, or 0).

        If any shared basis vector is degenerate (signature 0), the entire
        product vanishes — this is how null/projective dimensions work.

        Returns:
            (result_bitmask, sign * metric_factor)
        """
        sign = _sign_of_reorder(a, b)
        result = a ^ b
        # Apply metric: for each shared basis vector, multiply by its signature
        shared = a & b
        metric = 1.0
        for k in range(self._n):
            if shared & (1 << k):
                metric *= self._sig[k]
        if metric == 0:
            return 0, 0.0
        return result, sign * metric

    @property
    def signature(self) -> tuple[int, ...]:
        return self._sig

    @property
    def n(self) -> int:
        return self._n

    @property
    def dim(self) -> int:
        return self._dim

    @property
    def notation(self):
        """The Notation object controlling symbolic rendering."""
        return self._notation

    def basis_vectors(self, lazy: bool | None = None, *, symbolic: bool | None = None) -> tuple[Multivector, ...]:
        """Return the n basis 1-vectors (named + numeric by default).

        Args:
            lazy: Deprecated alias for symbolic.
            symbolic: If True, return named + symbolic blades that build expression
                  trees when used in arithmetic.
        """
        is_symbolic = _resolve_symbolic(lazy, symbolic)
        vecs = []
        for k in range(self._n):
            bitmask = 1 << k
            data = np.zeros(self._dim)
            data[bitmask] = 1.0
            mv = Multivector(self, data)
            mv._is_symbolic = is_symbolic
            mv._grade = 1
            mv._is_basis = True
            vecs.append(mv)
        return tuple(vecs)

    def basis_blades(
        self, k: int, *, lazy: bool | None = None, symbolic: bool | None = None
    ) -> tuple[Multivector, ...]:
        """Return all basis blades of a given grade, in canonical bitmask order.

        Args:
            k: The grade to select (0 = scalars, 1 = vectors, 2 = bivectors, …).
            lazy: Deprecated alias for symbolic.
            symbolic: If True, return symbolic blades that build expression trees.

        Example::

            e12, e13, e23 = alg.basis_blades(2)
        """
        is_symbolic = _resolve_symbolic(lazy, symbolic)
        blades = []
        for idx in self._display_order:
            if bin(idx).count("1") == k:
                data = np.zeros(self._dim)
                data[idx] = self._blades[idx].sign if idx in self._blades else 1.0
                mv = Multivector(self, data)
                mv._is_symbolic = is_symbolic
                mv._grade = k
                mv._is_basis = True
                blades.append(mv)
        return tuple(blades)

    def locals(
        self, *, grades: list[int] | None = None, lazy: bool | None = None, symbolic: bool | None = None
    ) -> dict[str, Multivector]:
        """Return a dict of all basis blades keyed by ASCII name.

        Designed for ``locals().update(alg.locals())`` in notebooks and
        top-level scripts. Keys are valid Python identifiers derived from
        the blade convention (e.g. ``e1``, ``e12``, ``y0y1``, ``s1``).

        Args:
            grades: If given, only include these grades. E.g. ``[1, 2]``.
            lazy: Deprecated alias for symbolic.
            symbolic: If True, blades are symbolic (build expression trees).

        Example::

            locals().update(alg.locals())          # all blades
            locals().update(alg.locals(grades=[1, 2]))  # vectors + bivectors
        """
        is_symbolic = _resolve_symbolic(lazy, symbolic)
        result = {}
        for idx, bb in self._blades.items():
            if idx == 0:
                continue
            if grades is not None and bin(idx).count("1") not in grades:
                continue
            data = np.zeros(self._dim)
            data[idx] = bb.sign
            mv = Multivector(self, data)
            mv._is_symbolic = is_symbolic
            mv._grade = bin(idx).count("1")
            mv._is_basis = True
            result[bb.ascii_name] = mv
        return result

    def pseudoscalar(self, lazy: bool | None = None, *, symbolic: bool | None = None) -> Multivector:
        """Return the unit pseudoscalar I (𝑰)."""
        is_symbolic = _resolve_symbolic(lazy, symbolic)
        data = np.zeros(self._dim)
        data[self._dim - 1] = 1.0
        mv = Multivector(self, data)
        mv._grade = self._n
        mv._is_basis = True
        if is_symbolic:
            mv._is_symbolic = True
        return mv

    @property
    def I(self) -> Multivector:
        """Unit pseudoscalar."""
        return self.pseudoscalar()

    @property
    def identity(self) -> Multivector:
        """Scalar identity 𝟙."""
        return self.scalar(1.0)

    def scalar(self, value: float) -> Multivector:
        """Create a scalar multivector (grade-0) with the given value."""
        data = np.zeros(self._dim)
        data[0] = value
        mv = Multivector(self, data)
        mv._grade = 0
        return mv

    def fraction(self, numerator: int, denominator: int) -> Multivector:
        """Create a named scalar fraction: fraction(1, 2) → symbolic MV displaying as 1/2.

        Both numerator and denominator are named so the expression tree
        renders symbolically (e.g. \\frac{1}{2} in LaTeX).
        """
        if denominator == 0:
            raise ValueError("Denominator cannot be zero")
        a = self.scalar(numerator).name(str(numerator))
        b = self.scalar(denominator).name(str(denominator))
        return a / b

    frac = fraction

    @property
    def pi(self) -> Multivector:
        """π as a named symbolic scalar."""
        return self.scalar(np.pi).name(latex=r"\pi")

    @property
    def e(self) -> Multivector:
        """Euler's number e as a named symbolic scalar."""
        return self.scalar(np.e).name(latex=r"e")

    @property
    def tau(self) -> Multivector:
        """τ = 2π as a named symbolic scalar with expression tree."""
        return (2 * self.pi).name(latex=r"\tau")

    @property
    def sqrt2(self) -> Multivector:
        """√2 as a named symbolic scalar with Sqrt expression tree."""
        return scalar_sqrt(self.scalar(2).name("2"))

    @property
    def h(self) -> Multivector:
        """Planck constant h as a named symbolic scalar."""
        return self.scalar(6.62607015e-34).name(latex=r"h")

    @property
    def hbar(self) -> Multivector:
        """Reduced Planck constant ℏ = h/2π as a named symbolic scalar."""
        return self.scalar(1.054571817e-34).name(latex=r"\hbar")

    @property
    def c(self) -> Multivector:
        """Speed of light c as a named symbolic scalar."""
        return self.scalar(299792458.0).name(latex=r"c")

    def vector(self, coeffs) -> Multivector:
        """Create a 1-vector from coefficients."""
        data = np.zeros(self._dim)
        for k, c in enumerate(coeffs):
            data[1 << k] = c
        mv = Multivector(self, data)
        mv._grade = 1
        return mv

    def blade(self, name, *, lazy: bool | None = None, symbolic: bool | None = None) -> Multivector:
        """Lookup a basis blade by name or multivector.

        Returns the canonical basis blade (coefficient +1 at the bitmask).
        For sign-compensated blades matching basis_blades() output, use
        basis_blades() instead.

        Args:
            name: A string (metric-role key, display name, or prefix+digits),
                or a Multivector (must be a single basis blade).
            lazy: Deprecated alias for symbolic.
            symbolic: If True, return a symbolic multivector.

        Search order for strings:
        1. Metric-role string (e.g. "+1-1", "pss")
        2. Exact match against any name variant (ascii, unicode, latex)
        3. Parse as prefix + digits using the convention's index_base
        """
        is_symbolic = _resolve_symbolic(lazy, symbolic)

        if isinstance(name, Multivector):
            nonzero = np.nonzero(np.abs(name.data) > 1e-12)[0]
            if len(nonzero) != 1:
                raise ValueError("Not a basis blade — has multiple nonzero components")
            bitmask = int(nonzero[0])
            data = np.zeros(self._dim)
            data[bitmask] = 1.0
            mv = Multivector(self, data)
            mv._is_basis = True
            if is_symbolic:
                mv.symbolic()
            return mv

        if name == "1" or name == "":
            mv = self.scalar(1.0)
            if is_symbolic:
                mv.symbolic()
            return mv

        # 1. Try metric-role key
        try:
            bitmask = _resolve_metric_role_key(name, self._sig)
            data = np.zeros(self._dim)
            data[bitmask] = 1.0
            mv = Multivector(self, data)
            mv._is_basis = True
            if is_symbolic:
                mv.symbolic()
            return mv
        except ValueError:
            pass

        # 2. Exact match against blade name variants
        for idx, bb in self._blades.items():
            if name in (bb.ascii_name, bb.unicode_name, bb.latex_name):
                data = np.zeros(self._dim)
                data[idx] = 1.0
                mv = Multivector(self, data)
                mv._is_basis = True
                if is_symbolic:
                    mv.symbolic()
                return mv

        # 3. Prefix + digits parsing
        conv = self._blades_convention
        a_pre = conv.prefix
        if name.startswith(a_pre):
            digits_str = name[len(a_pre) :]
            if digits_str.isdigit():
                indices = [int(ch) for ch in digits_str]
                bitmask = 0
                for idx in indices:
                    vec_idx = idx - conv.index_base
                    if vec_idx < 0 or vec_idx >= self._n:
                        raise ValueError(
                            f"Basis index {idx} out of range for {self._n}D algebra (index_base={conv.index_base})"
                        )
                    bitmask |= 1 << vec_idx
                data = np.zeros(self._dim)
                data[bitmask] = 1.0
                mv = Multivector(self, data)
                mv._is_basis = True
                if is_symbolic:
                    mv.symbolic()
                return mv

        raise ValueError(f"Unknown blade name: {name!r}")

    def rotor(self, B: Multivector, radians: float | None = None, degrees: float | None = None) -> Multivector:
        """Create a rotor R = cos(θ/2) - sin(θ/2)B̂ for rotation by θ in plane B.

        B must be an even multivector (scalar, bivector, pseudoscalar in even
        dimensions, or any combination). It does not need to be unit — it is
        normalized automatically. This allows bivectors (spatial rotations),
        scalars (identity), and pseudoscalars like I in STA (U(1) phase).

        Args:
            B: Even multivector defining the rotation generator (normalized internally).
            radians: Rotation angle in radians.
            degrees: Rotation angle in degrees (converted internally).

        Raises:
            ValueError: If B has any odd-grade components.
        """
        if radians is not None and degrees is not None:
            raise ValueError("Specify radians= or degrees=, not both")
        if radians is None and degrees is None:
            raise ValueError("Specify radians= or degrees=")
        if not is_even(B):
            odd = [k for k in range(self._n + 1) if k % 2 == 1 and not np.allclose(grade(B, k).data, 0)]
            raise ValueError(f"B must be an even multivector, but has odd-grade components: {odd}")
        # Reject pure scalars — need at least a grade-2 component to define a rotation plane
        if is_scalar(B):
            raise ValueError("B must contain a bivector (grade-2) component to define a rotation plane")
        theta = radians if radians is not None else np.radians(degrees)
        B_hat = unit(B)
        return self.scalar(np.cos(theta / 2)) - np.sin(theta / 2) * B_hat

    # Aliases
    rotor_from_bivector = rotor
    rotor_from_plane_angle = rotor

    _SUBSCRIPTS = str.maketrans("0123456789", "₀₁₂₃₄₅₆₇₈₉")

    def _blade_name(self, index: int, unicode: bool = False) -> str:
        if index == 0:
            return ""
        bb = self._blades[index]
        return bb.unicode_name if unicode else bb.ascii_name

    def _blade_latex(self, index: int) -> str:
        if index == 0:
            return ""
        return self._blades[index].latex_name

    def get_basis_blade(self, mv_or_index) -> BasisBlade:
        """Look up a BasisBlade by multivector, bitmask, or metric-role string.

        Args:
            mv_or_index: A Multivector (must be a basis blade), an int bitmask,
                or a metric-role string (e.g. "+1-1", "pss").
        """
        if isinstance(mv_or_index, str):
            bitmask = _resolve_metric_role_key(mv_or_index, self._sig)
            return self._blades[bitmask]
        if isinstance(mv_or_index, int):
            return self._blades[mv_or_index]
        mv = mv_or_index
        if hasattr(mv, "data"):
            nonzero = np.nonzero(np.abs(mv.data) > 1e-12)[0]
            if len(nonzero) != 1:
                raise ValueError("Not a basis blade — has multiple nonzero components")
            return self._blades[int(nonzero[0])]
        raise TypeError(f"Expected Multivector or int, got {type(mv_or_index)}")

    def __repr__(self) -> str:
        """Short signature notation, e.g. ``Cl(3,0)`` or ``Cl(1,3)``."""
        pos = self._sig.count(1)
        neg = self._sig.count(-1)
        zero = self._sig.count(0)
        parts = [str(pos), str(neg)]
        if zero:
            parts.append(str(zero))
        return f"Cl({','.join(parts)})"


def _coeff_lnode(c: float, blade: str, coeff_format: str | None, style: str):
    """Build an LNode for a single coefficient × blade term."""
    if coeff_format:
        formatted = format(c, coeff_format)
        coeff_node = _sci_lnode(formatted, style)
        if blade == "":
            return coeff_node
        return Seq([coeff_node, Text(f" {blade}")])
    else:
        formatted = _fmt_coeff(c)
        if blade == "":
            return _sci_lnode(formatted, style)
        if np.isclose(abs(c), 1.0):
            return Text(blade if c > 0 else f"-{blade}")
        coeff_node = _sci_lnode(formatted, style)
        return Seq([coeff_node, Text(f" {blade}")])


class _DisplayResult:
    """Wrapper so display() output is auto-detected as LaTeX by galaga_marimo."""

    __slots__ = ("_parts", "_sep", "_eval_mv")

    def __init__(self, parts: list[str], sep: str, eval_mv):
        self._parts = parts
        self._sep = sep
        self._eval_mv = eval_mv

    def _render(self, coeff_format: str | None = None) -> str:
        if coeff_format is None or self._eval_mv is None:
            return self._sep.join(self._parts)
        # Re-render with coeff_format on the eval (last) part only
        formatted_eval = self._eval_mv.latex(coeff_format=coeff_format)
        parts = list(self._parts)
        # Replace the last part (eval) if it's present
        if parts and parts[-1] == self._eval_mv.latex():
            parts[-1] = formatted_eval
        return self._sep.join(parts)

    def latex(self, coeff_format: str | None = None) -> str:
        return self._render(coeff_format)

    def _repr_latex_(self) -> str:
        return f"${self._render()}$"

    def __str__(self) -> str:
        return self._render()

    def __repr__(self) -> str:
        return self._render()

    def __format__(self, spec: str) -> str:
        if spec in ("", "s"):
            return self._render()
        if spec == "latex":
            return self._render()
        return self._render(coeff_format=spec)


class Multivector:
    """A multivector in a Clifford algebra.

    This is a lightweight value type: just an algebra reference plus a dense
    NumPy array of 2^n float64 coefficients. The array index *is* the blade
    bitmask, so ``data[0]`` is the scalar part, ``data[0b001]`` is the e₁
    coefficient, ``data[0b011]`` is the e₁₂ coefficient, etc.

    Operator overloads map to the named functions:
    - ``a * b``  → ``gp(a, b)``     (geometric product)
    - ``a ^ b``  → ``op(a, b)``     (outer/wedge product)
    - ``a | b``  → ``doran_lasenby_inner(a, b)``
    - ``~a``     → ``reverse(a)``
    - ``a[k]``   → ``grade(a, k)``  (grade projection)

    Scalar arithmetic (``3 * v``, ``v + 2``, ``v / 5``) is also supported
    and operates on the coefficient array directly.

    Attributes:
        algebra: The parent ``Algebra`` instance (shared, not copied).
        data: Dense NumPy float64 array of length ``algebra.dim``.
    """

    __slots__ = (
        "algebra",
        "data",
        "_name",
        "_name_latex",
        "_name_unicode",
        "_is_symbolic",
        "_expr",
        "_grade",
        "_is_basis",
    )

    def __init__(self, algebra: Algebra, data: np.ndarray):
        """Wrap a coefficient array as a multivector in the given algebra.

        Users should not call this directly — use ``Algebra.scalar()``,
        ``Algebra.vector()``, ``Algebra.blade()``, or arithmetic on
        basis vectors instead.
        """
        self.algebra = algebra
        self.data = np.array(data, dtype=np.float64)
        self._name = None
        self._name_latex = None
        self._name_unicode = None
        self._is_symbolic = False
        self._expr = None
        self._grade = None
        self._is_basis = False

    def _check_same(self, other: Multivector):
        if self.algebra is not other.algebra:
            raise ValueError(
                f"Cannot operate on multivectors from different algebras: {self.algebra} vs {other.algebra}"
            )

    def _copy_with(self, **overrides) -> Multivector:
        """Return a copy with selected fields overridden."""
        mv = Multivector.__new__(Multivector)
        mv.algebra = self.algebra
        mv.data = self.data
        mv._name = overrides.get("_name", self._name)
        mv._name_latex = overrides.get("_name_latex", self._name_latex)
        mv._name_unicode = overrides.get("_name_unicode", self._name_unicode)
        mv._is_symbolic = overrides.get("_is_symbolic", self._is_symbolic)
        mv._expr = overrides.get("_expr", self._expr)
        mv._grade = overrides.get("_grade", self._grade)
        mv._is_basis = False
        return mv

    def name(
        self,
        label: str | None = None,
        *,
        latex: str | None = None,
        unicode: str | None = None,
        ascii: str | None = None,
    ) -> Multivector:
        """Assign a display name. Sets symbolic. Returns self (or a copy for basis vectors).

        For basis vectors returned by basis_vectors(), basis_blades(), locals(),
        pseudoscalar(), or blade(), this returns a named copy — the original
        basis vector is not mutated.

        At least one of ``label`` or ``latex`` must be provided. If ``latex``
        is given, ``unicode`` and ``ascii`` are auto-derived from it unless
        explicitly overridden.

        Args:
            label: Default name used for all formats unless overridden. Optional
                   if ``latex`` is provided.
            latex: LaTeX-specific name. Also used to derive unicode/ascii.
            unicode: Unicode-specific name override.
            ascii: ASCII-specific name override.
        """
        if label is None and latex is None:
            raise ValueError("At least one of label or latex must be provided")
        # Protect basis vectors: operate on a copy instead of mutating
        if self._is_basis:
            copy = self._copy_with()
            return copy.name(label, latex=latex, unicode=unicode, ascii=ascii)
        # Auto-derive unicode/ascii from latex if not explicitly given
        if latex is not None and (unicode is None or ascii is None):
            result = LatexSymbols().lookup(latex)
            if result is not None:
                uni_derived, asc_derived = result
                if unicode is None:
                    unicode = uni_derived
                if ascii is None:
                    ascii = asc_derived
        self._name = ascii or label or latex
        self._name_latex = latex or label
        self._name_unicode = unicode or label or self._name
        self._is_symbolic = True
        # Auto-detect grade if homogeneous
        if self._grade is None:
            self._grade = self.homogeneous_grade()
        # Build a Sym expr so .anon() can reveal the name-based tree
        if self._expr is None:
            self._expr = make_sym(self, self._name_unicode, name_latex=self._name_latex, name_ascii=self._name)
        return self

    def anon(self) -> Multivector:
        """Remove the display name in-place. Preserves symbolic/numeric. Returns self."""
        if is_sym(self._expr) and self._expr._name == (self._name_unicode or self._name):
            self._expr = None
        self._name = None
        self._name_latex = None
        self._name_unicode = None
        return self

    def symbolic(self) -> Multivector:
        """Set symbolic mode in-place. Returns self."""
        self._is_symbolic = True
        return self

    def lazy(self) -> Multivector:
        """Deprecated alias for symbolic()."""
        return self.symbolic()

    def numeric(self, name: str | None = None) -> Multivector:
        """Force numeric evaluation in-place. Strips name unless one is given.

        Args:
            name: If provided, set this as the display name (named numeric).
                  If omitted, the name is cleared (anonymous numeric).
        """
        self._is_symbolic = False
        self._expr = None
        if name is not None:
            self._name = name
            self._name_latex = name
            self._name_unicode = name
        else:
            self._name = None
            self._name_latex = None
            self._name_unicode = None
        return self

    def eager(self, name: str | None = None) -> Multivector:
        """Deprecated alias for numeric()."""
        return self.numeric(name)

    def eval(self) -> Multivector:
        """Return a new anonymous eager copy — the concrete numeric result."""
        return self._copy_with(
            _is_symbolic=False,
            _expr=None,
            _name=None,
            _name_latex=None,
            _name_unicode=None,
        )

    def reveal(self) -> Multivector:
        """Return a new anonymous copy with the same symbolic/numeric state.

        Like eval() but preserves laziness. Useful for displaying the
        underlying value of a named MV without mutating it.
        """
        return self._copy_with(
            _name=None,
            _name_latex=None,
            _name_unicode=None,
        )

    def copy_as(
        self,
        label: str | None = None,
        *,
        latex: str | None = None,
        unicode: str | None = None,
        ascii: str | None = None,
    ) -> Multivector:
        """Return a named copy. Like .name() but non-mutating."""
        return self._copy_with().name(label, latex=latex, unicode=unicode, ascii=ascii)

    def display(self, compact: bool = False) -> _DisplayResult:
        """Return a LaTeX-renderable object showing name = expression = value, omitting duplicates."""
        parts = []
        eval_mv = self.eval()
        name_latex = self._latex_raw() if self._name is not None else None
        eval_latex = eval_mv._latex_raw()

        reveal_latex = None
        if self._is_symbolic and self._expr is not None:
            r_latex = self.reveal()._latex_raw()
            if r_latex != name_latex and r_latex != eval_latex:
                reveal_latex = r_latex

        if name_latex is not None:
            parts.append(name_latex)
        if reveal_latex is not None:
            parts.append(reveal_latex)
        if eval_latex not in parts:
            parts.append(eval_latex)

        sep = " = " if compact else " \\quad = \\quad "
        return _DisplayResult(parts, sep, eval_mv)

    def _to_expr(self):
        """Convert this MV to an Expr node for use in expression trees.

        Named MVs become Sym nodes (so they appear by name in trees).
        Anonymous symbolic MVs use their stored expr tree.
        Anonymous eager MVs become Sym nodes with their string representation,
        using the algebra's LaTeX name for single basis blades.
        """
        if self._name is not None:
            inner = self._expr if self._expr is not None and not is_sym(self._expr) else None
            return make_sym(
                self,
                self._name_unicode or self._name,
                name_latex=self._name_latex,
                name_ascii=self._name,
                inner_expr=inner,
            )
        if self._expr is not None:
            return self._expr
        display = str(self)
        return make_sym(self, display, name_latex=self.latex())

    # --- Operator overloads ---

    def _is_any_symbolic(self, other=None) -> bool:
        if self._is_symbolic:
            return True
        if isinstance(other, Multivector) and other._is_symbolic:
            return True
        return False

    def _symbolic_result(self, data: np.ndarray, expr) -> Multivector:
        """Build a symbolic MV with computed data and an expression tree."""
        mv = Multivector.__new__(Multivector)
        mv.algebra = self.algebra
        mv.data = np.array(data, dtype=np.float64)
        mv._name = None
        mv._name_latex = None
        mv._name_unicode = None
        mv._is_symbolic = True
        mv._expr = expr
        mv._grade = None
        mv._is_basis = False
        return mv

    def __add__(self, other):
        if isinstance(other, (int, float)):
            d = self.data.copy()
            d[0] += other
            if self._is_symbolic:
                return self._symbolic_result(d, build_expr("add", self._to_expr(), build_expr("scalar", other)))
            return Multivector(self.algebra, d)
        if not isinstance(other, Multivector):
            return NotImplemented
        self._check_same(other)
        if self._is_any_symbolic(other):
            return self._symbolic_result(
                self.data + other.data,
                build_expr("add", self._to_expr(), other._to_expr()),
            )
        return Multivector(self.algebra, self.data + other.data)

    def __radd__(self, other):
        if isinstance(other, (int, float)) and self._is_symbolic:
            d = self.data.copy()
            d[0] += other
            return self._symbolic_result(d, build_expr("add", build_expr("scalar", other), self._to_expr()))
        return self.__add__(other)

    def __sub__(self, other):
        if isinstance(other, (int, float)):
            d = self.data.copy()
            d[0] -= other
            if self._is_symbolic:
                return self._symbolic_result(d, build_expr("sub", self._to_expr(), build_expr("scalar", other)))
            return Multivector(self.algebra, d)
        if not isinstance(other, Multivector):
            return NotImplemented
        self._check_same(other)
        if self._is_any_symbolic(other):
            return self._symbolic_result(
                self.data - other.data,
                build_expr("sub", self._to_expr(), other._to_expr()),
            )
        return Multivector(self.algebra, self.data - other.data)

    def __rsub__(self, other):
        if isinstance(other, (int, float)):
            d = -self.data.copy()
            d[0] += other
            if self._is_symbolic:
                return self._symbolic_result(d, build_expr("sub", build_expr("scalar", other), self._to_expr()))
            return Multivector(self.algebra, d)
        return NotImplemented

    def __neg__(self):
        if self._is_symbolic:
            return self._symbolic_result(-self.data, build_expr("neg", self._to_expr()))
        return Multivector(self.algebra, -self.data)

    def __mul__(self, other):
        """Geometric product (a * b) or scalar multiplication."""
        if isinstance(other, (int, float)):
            if self._is_symbolic:
                return self._symbolic_result(
                    self.data * other,
                    build_expr("scalar_mul", other, self._to_expr()),
                )
            return Multivector(self.algebra, self.data * other)
        if not isinstance(other, Multivector):
            return NotImplemented
        return gp(self, other)

    def __rmul__(self, other):
        if isinstance(other, (int, float)):
            if self._is_symbolic:
                return self._symbolic_result(
                    self.data * other,
                    build_expr("scalar_mul", other, self._to_expr()),
                )
            return Multivector(self.algebra, self.data * other)
        if isinstance(other, Multivector):
            return other.__mul__(self)
        return NotImplemented

    def __xor__(self, other):
        """Outer product (a ^ b)."""
        if not isinstance(other, Multivector):
            return NotImplemented
        return op(self, other)

    def __or__(self, other):
        """Doran–Lasenby inner product (a | b)."""
        if not isinstance(other, Multivector):
            return NotImplemented
        return doran_lasenby_inner(self, other)

    def __invert__(self):
        """Reverse (~a)."""
        return reverse(self)

    def __truediv__(self, other):
        if isinstance(other, (int, float)):
            if self._is_symbolic:
                return self._symbolic_result(
                    self.data / other,
                    build_expr("scalar_div", self._to_expr(), other),
                )
            return Multivector(self.algebra, self.data / other)
        if isinstance(other, Multivector):
            self._check_same(other)
            if is_scalar(other):
                s = other.data[0]
                if abs(s) < 1e-300:
                    raise ZeroDivisionError("Division by zero scalar multivector")
                if self._is_any_symbolic(other):
                    return self._symbolic_result(
                        self.data / s,
                        build_expr("div", self._to_expr(), other._to_expr()),
                    )
                return Multivector(self.algebra, self.data / s)
            return self * inverse(other)
        return NotImplemented

    def __rtruediv__(self, other):
        """Support scalar / multivector: k / x = k * x⁻¹."""
        if isinstance(other, (int, float)):
            return other * inverse(self)
        return NotImplemented

    def __pow__(self, n):
        if not isinstance(n, int):
            return NotImplemented
        if n == 0:
            return self.algebra.scalar(1.0)
        if n == 2:
            return squared(self)
        if n < 0:
            return inverse(self) ** (-n)
        result = self
        for _ in range(n - 1):
            result = result * self
        return result

    def __eq__(self, other):
        """Approximate equality using ``np.allclose``.

        Supports comparison with other Multivectors (must be from the same
        algebra) and with scalars (int/float), which are compared against
        the scalar part with all other components expected to be zero.

        Note: uses ``np.allclose`` (atol=1e-8, rtol=1e-5) rather than exact
        equality, because floating-point products accumulate rounding errors.
        """
        if isinstance(other, Multivector):
            self._check_same(other)
            return np.allclose(self.data, other.data)
        if isinstance(other, (int, float)):
            expected = np.zeros(self.algebra.dim)
            expected[0] = other
            return np.allclose(self.data, expected)
        return NotImplemented

    def __hash__(self):
        """Hash based on raw coefficient bytes.

        Required because we define ``__eq__`` — without this, Multivector
        would be unhashable, which breaks marimo's cell dependency tracking
        and prevents use in sets/dicts.

        Note: this is consistent with ``__eq__`` for *exact* byte equality,
        but two multivectors that are ``__eq__`` (via ``allclose``) may have
        different hashes if their floats differ in the last bits. This is an
        acceptable trade-off — hash collisions are harmless, and the
        alternative (quantising floats) adds complexity for little benefit.
        """
        return hash(self.data.tobytes())

    def __getitem__(self, k: int) -> Multivector:
        """Grade projection: x[k] returns grade-k component."""
        return grade(self, k)

    # --- Convenience properties/methods ---

    @property
    def inv(self) -> Multivector:
        """Inverse: x⁻¹"""
        if self._is_symbolic:
            result = inverse(Multivector(self.algebra, self.data))
            return self._symbolic_result(result.data, build_expr("inverse", self._to_expr()))
        return inverse(self)

    @property
    def dag(self) -> Multivector:
        """Reverse (dagger): x†"""
        return ~self

    @property
    def bar(self) -> Multivector:
        """Clifford conjugate: x̄ (reverse ∘ involute)"""
        return conjugate(self)

    @property
    def sq(self) -> Multivector:
        """Squared: x²"""
        if self._is_symbolic:
            result = gp(Multivector(self.algebra, self.data), Multivector(self.algebra, self.data))
            return self._symbolic_result(result.data, build_expr("squared", self._to_expr()))
        return gp(self, self)

    @property
    def scalar_part(self) -> float:
        """Extract grade-0 coefficient as a float."""
        return float(self.data[0])

    def __float__(self) -> float:
        """Convert to float. Only valid for scalar (grade-0) multivectors."""
        if self._grade is None:
            self._grade = self.homogeneous_grade()
        if self._grade is not None and self._grade != 0:
            raise TypeError(
                f"Cannot convert grade-{self._grade} multivector to float; "
                "only scalar (grade-0) multivectors support float()"
            )
        # _grade is 0 or None (zero MV) — both are valid scalars
        if self._grade is None and np.any(np.abs(self.data[1:]) > 1e-12):
            raise TypeError(
                "Cannot convert mixed-grade multivector to float; only scalar (grade-0) multivectors support float()"
            )
        return float(self.data[0])

    def __abs__(self) -> float:
        """Absolute value. Only valid for scalar (grade-0) multivectors."""
        return abs(float(self))

    @property
    def vector_part(self) -> np.ndarray:
        """Extract grade-1 coefficients as a numpy array."""
        n = self.algebra._n
        return np.array([self.data[1 << i] for i in range(n)])

    def homogeneous_grade(self) -> int | None:
        """Return the grade if this MV is homogeneous, or None if mixed.

        A multivector is homogeneous if all its nonzero coefficients belong
        to the same grade. Returns that grade, or None if multiple grades
        are present or the MV is zero.
        """
        alg = self.algebra
        found = None
        for k in range(alg.n + 1):
            if np.any(np.abs(self.data[alg._grade_masks[k]]) > 1e-12):
                if found is not None:
                    return None  # multiple grades
                found = k
        return found

    def _format(self, unicode: bool = False) -> str:
        alg = self.algebra
        terms = []
        for i in alg._display_order:
            c = self.data[i]
            if abs(c) < 1e-12:
                continue
            name = alg._blade_name(i, unicode=unicode)
            c = c * alg._blades[i].sign
            if name == "":
                terms.append(f"{c:g}")
            elif np.isclose(abs(c), 1.0):
                terms.append(f"{name}" if c > 0 else f"-{name}")
            else:
                terms.append(f"{c:g}{name}")
        if not terms:
            return "0"
        result = terms[0]
        for t in terms[1:]:
            if t.startswith("-"):
                result += " - " + t[1:]
            else:
                result += " + " + t
        return result

    def __repr__(self) -> str:
        """Representation controlled by algebra.repr_unicode."""
        if self.algebra._display_mode:
            return repr(self.display())
        if self.algebra._repr_unicode:
            return self.__str__()
        return self._format(unicode=False)

    def __str__(self) -> str:
        """Unicode representation, e.g. ``3 + 2e₁ - e₃``."""
        if self.algebra._display_mode:
            return str(self.display())
        if self._name_unicode is not None:
            return self._name_unicode
        if self._name is not None:
            return self._name
        if self._is_symbolic and self._expr is not None:
            return _render.render(self._expr, self.algebra._notation)
        return self._format(unicode=True)

    def __format__(self, spec: str) -> str:
        """Support format specs: numeric specs (e.g. '.3f') format coefficients,
        'latex'/'unicode'/'ascii' select representation mode."""
        if spec in ("", "s"):
            return str(self)
        if spec == "latex":
            return self.latex()
        if spec in ("unicode", "u"):
            if self._name_unicode is not None:
                return self._name_unicode
            if self._is_symbolic and self._expr is not None:
                return _render.render(self._expr, self.algebra._notation)
            return self._format(unicode=True)
        if spec in ("ascii", "a"):
            if self._name is not None:
                return self._name
            if self._is_symbolic and self._expr is not None:
                return _render.render(self._expr, self.algebra._notation)
            return self._format(unicode=False)
        # Numeric format spec — apply to each coefficient, no threshold
        alg = self.algebra
        terms = []
        for i in alg._display_order:
            c = self.data[i]
            if c == 0.0:
                continue
            c = c * alg._blades[i].sign
            name = alg._blade_name(i, unicode=True)
            formatted_c = format(c, spec)
            if name == "":
                terms.append(formatted_c)
            else:
                terms.append(f"{formatted_c}{name}")
        if not terms:
            return format(0.0, spec)
        result = terms[0]
        for t in terms[1:]:
            if t.startswith("-"):
                result += " - " + t[1:]
            else:
                result += " + " + t
        return result

    def _latex_raw(self, wrap: str | None = None, coeff_format: str | None = None) -> str:
        """Core LaTeX rendering, ignoring display_mode. Used by display()."""
        # Named → return name
        if self._name_latex is not None and coeff_format is None:
            raw = self._name_latex
        elif self._name is not None and coeff_format is None:
            raw = self._name
        # Anonymous symbolic → delegate to renderer
        elif self._is_symbolic and self._expr is not None and coeff_format is None:
            raw = _render.render_latex(self._expr, self.algebra._notation)
        else:
            # Eager anonymous → coefficient rendering via LNodes
            alg = self.algebra
            style = alg._notation.scientific
            term_nodes = []
            for i in alg._display_order:
                c = self.data[i]
                if coeff_format:
                    if c == 0.0:
                        continue
                else:
                    if abs(c) < 1e-12:
                        continue
                c = c * alg._blades[i].sign
                blade = alg._blade_latex(i)
                term_nodes.append(_coeff_lnode(c, blade, coeff_format, style))
            if not term_nodes:
                raw = format(0.0, coeff_format) if coeff_format else "0"
            else:
                raw = _latex_emit(term_nodes[0])
                for tn in term_nodes[1:]:
                    s = _latex_emit(tn)
                    if s.startswith("-"):
                        raw += " - " + s[1:]
                    else:
                        raw += " + " + s
        if wrap == "$":
            return f"${raw}$"
        if wrap == "$$":
            return f"$$\n{raw}\n$$"
        return raw

    def latex(self, wrap: str | None = None, coeff_format: str | None = None) -> str:
        """Return LaTeX representation of this multivector.

        Args:
            wrap: Optional delimiter — '$' for inline, '$$' for display block.
            coeff_format: Optional format spec for coefficients (e.g. '.3f').
                         When set, all coefficients are shown explicitly
                         (the drop-1 convention is disabled).
        """
        # Display mode: delegate to display() for the full name = expr = value form
        if self.algebra._display_mode and wrap is None and coeff_format is None:
            return self.display().latex()
        return self._latex_raw(wrap=wrap, coeff_format=coeff_format)

    def _repr_latex_(self) -> str:
        """Jupyter/Marimo notebook integration."""
        if self.algebra._display_mode:
            return self.display()._repr_latex_()
        return f"${self.latex()}$"


# ============================================================
# Core named operations
# ============================================================
#
# Every GA product is a module-level function. This is the stable public API.
# Operators on Multivector (*, ^, |, ~) are convenience sugar that delegate here.
#
# Implementation pattern: all products iterate over nonzero coefficients of the
# operands and accumulate into an output array using the precomputed multiplication
# tables. The differences between products are *which grade combinations survive*:
#
#   gp:                  all grades (full geometric product)
#   op:                  grade(a) + grade(b) only (wedge)
#   left_contraction:    grade(b) - grade(a) only, must be ≥ 0
#   right_contraction:   grade(a) - grade(b) only, must be ≥ 0
#   doran_lasenby_inner: |grade(a) - grade(b)|, including scalars (the | operator)
#   hestenes_inner:      |grade(a) - grade(b)|, but zero if either is grade-0
#   scalar_product:      grade-0 only (just the scalar part of gp)
# ============================================================


@ga_op("gp", arity=2)
def gp(a: Multivector, b: Multivector) -> Multivector:
    """Geometric product — the fundamental product of Clifford algebra.

    Computes a*b using the precomputed multiplication tables. For each nonzero
    coefficient in ``a``, we vectorise the scatter-add across all of ``b``'s
    coefficients at once (using NumPy fancy indexing), which is significantly
    faster than a double Python loop for dense multivectors.
    """
    a._check_same(b)
    alg = a.algebra
    out = np.zeros(alg.dim)
    # Vectorized: for each nonzero coeff in a, accumulate contributions
    for i in np.nonzero(a.data)[0]:
        ai = a.data[i]
        indices = alg._mul_index[i]
        signs = alg._mul_sign[i]
        out[indices] += ai * b.data * signs
    return Multivector(alg, out)


@ga_op("op", arity=2, grade=lambda r, s, n: r + s if r + s <= n else None)
def op(a: Multivector, b: Multivector) -> Multivector:
    """Outer (wedge) product — keeps only the grade-raising part of gp.

    For homogeneous blades of grade r and s, the outer product is the
    grade-(r+s) part of the geometric product. For mixed-grade multivectors,
    it's applied component-wise: each (grade_i, grade_j) pair contributes
    only if the result lands on grade i+j.

    Key property: a ∧ a = 0 for any vector a (antisymmetry).
    """
    a._check_same(b)
    alg = a.algebra
    out = np.zeros(alg.dim)
    for i in np.nonzero(a.data)[0]:
        gi = bin(i).count("1")
        ai = a.data[i]
        for j in np.nonzero(b.data)[0]:
            gj = bin(j).count("1")
            target_grade = gi + gj
            k = alg._mul_index[i, j]
            if bin(k).count("1") == target_grade:
                out[k] += ai * b.data[j] * alg._mul_sign[i, j]
    return Multivector(alg, out)


@ga_op("left_contraction", arity=2, grade=lambda r, s, n: s - r if s >= r else None)
def left_contraction(a: Multivector, b: Multivector) -> Multivector:
    """Left contraction: a ⌋ b.

    Keeps only the grade-(s-r) part of gp(a, b), where r = grade(a) and
    s = grade(b). If r > s, the result is zero — you can't "remove" more
    grade than is present.

    This is the most common inner product in GA literature. It answers:
    "project out the part of b that contains a". For example,
    ``left_contraction(e1, e12)`` = e₂ — the e₁ "factor" is removed.

    Key difference from Hestenes inner: left contraction allows scalars
    to pass through (scalar ⌋ x = scalar * x), while Hestenes kills them.
    """
    a._check_same(b)
    alg = a.algebra
    out = np.zeros(alg.dim)
    for i in np.nonzero(a.data)[0]:
        gi = bin(i).count("1")
        ai = a.data[i]
        for j in np.nonzero(b.data)[0]:
            gj = bin(j).count("1")
            target_grade = gj - gi
            if target_grade < 0:
                continue
            k = alg._mul_index[i, j]
            if bin(k).count("1") == target_grade:
                out[k] += ai * b.data[j] * alg._mul_sign[i, j]
    return Multivector(alg, out)


@ga_op("right_contraction", arity=2, grade=lambda r, s, n: r - s if r >= s else None)
def right_contraction(a: Multivector, b: Multivector) -> Multivector:
    """Right contraction: a ⌊ b.

    Mirror of left contraction: keeps grade-(r-s) part of gp(a, b).
    If r < s, the result is zero.

    Satisfies: right_contraction(a, b) = reverse(left_contraction(reverse(b), reverse(a)))
    """
    a._check_same(b)
    alg = a.algebra
    out = np.zeros(alg.dim)
    for i in np.nonzero(a.data)[0]:
        gi = bin(i).count("1")
        ai = a.data[i]
        for j in np.nonzero(b.data)[0]:
            gj = bin(j).count("1")
            target_grade = gi - gj
            if target_grade < 0:
                continue
            k = alg._mul_index[i, j]
            if bin(k).count("1") == target_grade:
                out[k] += ai * b.data[j] * alg._mul_sign[i, j]
    return Multivector(alg, out)


@ga_op("hestenes_inner", arity=2, grade=lambda r, s, n: abs(r - s) if r > 0 and s > 0 else None)
def hestenes_inner(a: Multivector, b: Multivector) -> Multivector:
    """Hestenes inner product.

    Like left contraction but with two key differences:
    1. Uses |grade(a) - grade(b)| instead of grade(b) - grade(a), so it's
       nonzero in both directions (e.g. bivector · vector ≠ 0).
    2. Kills scalars: if either operand is grade-0, the result is zero.

    For vector-on-vector, all inner products agree. The differences only show
    up with mixed grades — see the README comparison table for examples.
    """
    a._check_same(b)
    alg = a.algebra
    out = np.zeros(alg.dim)
    for i in np.nonzero(a.data)[0]:
        gi = bin(i).count("1")
        if gi == 0:
            continue
        ai = a.data[i]
        for j in np.nonzero(b.data)[0]:
            gj = bin(j).count("1")
            if gj == 0:
                continue
            target_grade = abs(gi - gj)
            k = alg._mul_index[i, j]
            if bin(k).count("1") == target_grade:
                out[k] += ai * b.data[j] * alg._mul_sign[i, j]
    return Multivector(alg, out)


@ga_op("doran_lasenby_inner", arity=2, grade=lambda r, s, n: abs(r - s))
def doran_lasenby_inner(a: Multivector, b: Multivector) -> Multivector:
    """Doran–Lasenby inner product: grade-|r-s| part of gp(a,b), including scalars.

    Like Hestenes inner but does NOT kill scalars. When either operand is
    grade-0, the result is the scalar times the other operand (grade
    difference = the other operand's grade).

    This is the ``|`` operator on Multivector, and the convention used by
    Doran & Lasenby ("Geometric Algebra for Physicists") and Dorst et al.
    ("Geometric Algebra for Computer Science").
    """
    a._check_same(b)
    alg = a.algebra
    out = np.zeros(alg.dim)
    for i in np.nonzero(a.data)[0]:
        gi = bin(i).count("1")
        ai = a.data[i]
        for j in np.nonzero(b.data)[0]:
            gj = bin(j).count("1")
            target_grade = abs(gi - gj)
            k = alg._mul_index[i, j]
            if bin(k).count("1") == target_grade:
                out[k] += ai * b.data[j] * alg._mul_sign[i, j]
    return Multivector(alg, out)


dorst_inner = doran_lasenby_inner


@ga_op("scalar_product", arity=2, grade=lambda r, s, n: 0)
def scalar_product(a: Multivector, b: Multivector) -> Multivector:
    """Scalar product: grade-0 part of the geometric product."""
    return grade(gp(a, b), 0)


@ga_op("commutator", arity=2)
def commutator(a: Multivector, b: Multivector) -> Multivector:
    """Commutator: ab - ba."""
    return gp(a, b) - gp(b, a)


@ga_op("anticommutator", arity=2)
def anticommutator(a: Multivector, b: Multivector) -> Multivector:
    """Anticommutator: ab + ba."""
    return gp(a, b) + gp(b, a)


@ga_op("lie_bracket", arity=2)
def lie_bracket(a: Multivector, b: Multivector) -> Multivector:
    """Lie bracket: ½(ab - ba).

    The half-scaled commutator under which bivectors form a Lie algebra
    with clean structure constants: [Bᵢ, Bⱼ] = εᵢⱼₖ Bₖ.
    """
    return commutator(a, b) * 0.5


@ga_op("jordan_product", arity=2)
def jordan_product(a: Multivector, b: Multivector) -> Multivector:
    """Jordan product: ½(ab + ba).

    The symmetric part of the geometric product. For vectors,
    this equals the inner product: a ∘ b = a · b.
    """
    return anticommutator(a, b) * 0.5


# --- Unary operations ---


@ga_op("reverse", arity=1, grade=lambda k, n: k)
def reverse(x: Multivector) -> Multivector:
    """Reverse (†, tilde): reverses the order of basis vectors in each blade.

    The grade-k component is multiplied by (-1)^(k(k-1)/2):
    - grade 0, 1: unchanged  (sign = +1)
    - grade 2, 3: negated    (sign = -1)
    - grade 4, 5: unchanged  (sign = +1)
    - ...and so on in a period-4 cycle.

    Why this matters: the reverse is the natural "adjoint" in GA. For a
    versor (product of vectors) V = v₁v₂...vₖ, the reverse is
    ~V = vₖ...v₂v₁. The sandwich product R x ~R uses the reverse to
    apply rotations/boosts, and V~V gives the squared norm.
    """
    alg = x.algebra
    out = x.data.copy()
    for k in range(alg.n + 1):
        sign = (-1) ** (k * (k - 1) // 2)
        if sign == -1:
            out[alg._grade_masks[k]] *= -1
    return Multivector(alg, out)


@ga_op("involute", arity=1, grade=lambda k, n: k)
def involute(x: Multivector) -> Multivector:
    """Grade involution (hat): grade-k component is multiplied by (-1)^k.

    Even grades are unchanged, odd grades are negated. This is the
    automorphism that distinguishes the even and odd sub-algebras.
    """
    alg = x.algebra
    out = x.data.copy()
    for k in range(alg.n + 1):
        if k % 2 == 1:
            out[alg._grade_masks[k]] *= -1
    return Multivector(alg, out)


@ga_op("conjugate", arity=1, grade=lambda k, n: k)
def conjugate(x: Multivector) -> Multivector:
    """Clifford conjugate: reverse composed with grade involution.

    Combines both sign-flip patterns. The grade-k component is multiplied
    by (-1)^(k(k+1)/2). This is the composition ``involute(reverse(x))``.
    """
    return involute(reverse(x))


def grade(x: Multivector, k: int | str) -> Multivector:
    """Extract grade-k component, or 'even'/'odd' for parity selection."""
    if x._is_symbolic:
        if k == "even":
            result = even_grades(Multivector(x.algebra, x.data))
            return x._symbolic_result(result.data, build_expr("even_grades", x._to_expr()))
        if k == "odd":
            result = odd_grades(Multivector(x.algebra, x.data))
            return x._symbolic_result(result.data, build_expr("odd_grades", x._to_expr()))
        result = grade(Multivector(x.algebra, x.data), k)
        mv = x._symbolic_result(result.data, build_expr("grade", x._to_expr(), k))
        mv._grade = k
        return mv
    if k == "even":
        return even_grades(x)
    if k == "odd":
        return odd_grades(x)
    alg = x.algebra
    if k < 0 or k > alg.n:
        return Multivector(alg, np.zeros(alg.dim))
    out = np.zeros(alg.dim)
    mask = alg._grade_masks[k]
    out[mask] = x.data[mask]
    mv = Multivector(alg, out)
    mv._grade = k
    return mv


def grades(x: Multivector, ks: list[int]) -> Multivector:
    """Extract multiple grade components."""
    alg = x.algebra
    out = np.zeros(alg.dim)
    for k in ks:
        if 0 <= k <= alg.n:
            mask = alg._grade_masks[k]
            out[mask] = x.data[mask]
    return Multivector(alg, out)


def scalar_sqrt(x) -> Multivector:
    """Square root of a scalar multivector or number.

    Accepts a Multivector or a plain number (int/float). Numbers are
    coerced to scalar MVs if possible, otherwise np.sqrt is used.
    """
    if isinstance(x, (int, float)):
        if x < 0:
            raise ValueError(f"scalar_sqrt of negative value {x}")
        # No algebra context — but if we got here from a plain number,
        # just return a float. The user can wrap it if needed.
        return x.__class__(np.sqrt(x))
    if not isinstance(x, Multivector):
        raise TypeError(f"scalar_sqrt expects a Multivector or number, got {type(x).__name__}")
    # Lazy path
    if x._is_symbolic:
        result = scalar_sqrt(Multivector(x.algebra, x.data))
        return x._symbolic_result(result.data, build_expr("sqrt", x._to_expr()))
    # Eager path
    if not is_scalar(x):
        raise ValueError("scalar_sqrt requires a pure scalar multivector")
    s = float(x.data[0])
    if s < 0:
        raise ValueError(f"scalar_sqrt of negative value {s}")
    return x.algebra.scalar(np.sqrt(s))


def sqrt(x) -> Multivector:
    """Square root via Study number decomposition (Roelfs & De Keninck 2022).

    Works for any multivector that decomposes as a + bI where a is the
    scalar part and bI = x - a squares to a scalar. This includes:
    - Pure scalars
    - Rotors (e.g. cos(θ) + sin(θ) e₁₂)
    - PGA translators (e.g. 1 + ½d e₀₁)
    - Any Study number

    For pure scalars or plain numbers, delegates to scalar_sqrt.

    Raises ValueError if bI does not square to a scalar.
    """
    if isinstance(x, (int, float)):
        return scalar_sqrt(x)
    if not isinstance(x, Multivector):
        raise TypeError(f"sqrt expects a Multivector or number, got {type(x).__name__}")
    if x._is_symbolic:
        result = sqrt(Multivector(x.algebra, x.data))
        return x._symbolic_result(result.data, build_expr("sqrt", x._to_expr()))
    if is_scalar(x):
        return scalar_sqrt(x)
    a = x.scalar_part
    bI = x - x.algebra.scalar(a)
    bI_sq = gp(bI, bI)
    if not is_scalar(bI_sq):
        raise ValueError("sqrt requires a Study number (non-scalar part must square to a scalar)")
    bI_sq_val = bI_sq.scalar_part
    if np.isclose(bI_sq_val, 0.0):
        cp = np.sqrt(a)
    else:
        norm_s = a * a - bI_sq_val
        cp = np.sqrt(0.5 * (a + np.sqrt(norm_s)))
    return bI / (2 * cp) + x.algebra.scalar(cp)


@ga_op("dual", arity=1, grade=lambda k, n: n - k)
def dual(x: Multivector) -> Multivector:
    """Dual: left-contract x into the inverse pseudoscalar.

    Maps a grade-k blade to a grade-(n-k) blade. In 3D Euclidean space,
    dual(e₁ ∧ e₂) = e₃. This is the standard Hodge-like duality in GA.

    Implementation: ``left_contraction(x, I⁻¹)`` where I is the unit
    pseudoscalar. We use left contraction (not geometric product with I⁻¹)
    because it gives the correct grade mapping for all signatures.
    """
    try:
        I_inv = inverse(x.algebra.pseudoscalar())
    except ValueError:
        raise ValueError(
            "dual() requires an invertible pseudoscalar (I² ≠ 0). "
            "This algebra has a degenerate metric — use complement() instead."
        ) from None
    return left_contraction(x, I_inv)


@ga_op("undual", arity=1, grade=lambda k, n: n - k)
def undual(x: Multivector) -> Multivector:
    """Undual: left-contract x into the pseudoscalar (inverse of dual).

    ``undual(dual(x)) = x`` for all x.
    """
    I = x.algebra.pseudoscalar()
    return left_contraction(x, I)


@ga_op("complement", arity=1, grade=lambda k, n: n - k)
def complement(x: Multivector) -> Multivector:
    """Right complement: metric-independent duality.

    Maps grade-k to grade-(n-k) by replacing each basis blade's index set
    with its complement, with a sign chosen so that
    ``x * complement(x)`` is proportional to the pseudoscalar.

    Unlike ``dual()``, this works in **all** signatures including degenerate
    algebras (PGA). It is purely combinatorial — no metric is used.
    """
    alg = x.algebra
    full = alg.dim - 1
    out = np.zeros(alg.dim)
    for i in range(alg.dim):
        if x.data[i] != 0:
            out[full ^ i] += alg._complement_sign[i] * x.data[i]
    return Multivector(alg, out)


@ga_op("uncomplement", arity=1, grade=lambda k, n: n - k)
def uncomplement(x: Multivector) -> Multivector:
    """Inverse of complement: ``uncomplement(complement(x)) = x`` for all x."""
    alg = x.algebra
    full = alg.dim - 1
    out = np.zeros(alg.dim)
    for i in range(alg.dim):
        if x.data[i] != 0:
            # Inverse sign: complement_sign[S^c] since we're going backwards
            j = full ^ i
            out[j] += alg._complement_sign[j] * x.data[i]
    return Multivector(alg, out)


@ga_op("regressive_product", arity=2, grade=lambda r, s, n: r + s - n if r + s >= n else None)
def regressive_product(a: Multivector, b: Multivector) -> Multivector:
    """Regressive product (meet): complement-based, works in all signatures.

    Computes the intersection of the subspaces represented by blades a and b.
    Uses the complement operator (metric-independent), so it works in
    degenerate algebras like PGA where the pseudoscalar is not invertible.

    Definition: a ∨ b = uncomplement(complement(a) ∧ complement(b))
    """
    return uncomplement(op(complement(a), complement(b)))


def metric_regressive_product(a: Multivector, b: Multivector) -> Multivector:
    """Regressive product via metric dual: (a* ∧ b*)*.

    Only works in nondegenerate algebras (VGA, STA, CGA).
    Raises ValueError in degenerate algebras (PGA).
    """
    return undual(op(dual(a), dual(b)))


# Aliases
meet = regressive_product
join = op


def norm2(x: Multivector) -> Multivector:
    """Squared norm: grade-0 part of x * ~x. Returns a scalar multivector."""
    if x._is_symbolic:
        result = norm2(Multivector(x.algebra, x.data))
        return x._symbolic_result(result.data, build_expr("norm2", x._to_expr()))
    return grade(gp(x, reverse(x)), 0)


def norm(x: Multivector):
    """Norm: sqrt(|norm2(x)|). Returns float for numeric, symbolic scalar MV for symbolic."""
    if x._is_symbolic:
        val = float(np.sqrt(abs(float(norm2(x)))))
        result = x.algebra.scalar(val)
        return x._symbolic_result(result.data, build_expr("norm", x._to_expr()))
    return float(np.sqrt(abs(float(norm2(x)))))


@ga_op("unit", arity=1, grade=lambda k, n: k)
def unit(x: Multivector) -> Multivector:
    """Normalize to unit multivector."""
    n = norm(x)
    if n < 1e-15:
        raise ValueError("Cannot normalize near-zero multivector")
    return x / n


@ga_op("inverse", arity=1, grade=lambda k, n: k)
def inverse(x: Multivector) -> Multivector:
    """General multivector inverse: x⁻¹ such that x * x⁻¹ = 1.

    Dispatches by algebra dimension:
    - d ≤ 5: Hitzer closed-form inverse (Hitzer & Sangwine 2017)
    - d ≥ 6: Shirokov iterative algorithm (arXiv:2005.04015)

    Both produce a true inverse for any invertible multivector, not just
    versors. Raises ValueError if the multivector is not invertible.
    """
    alg = x.algebra
    if alg.n <= 5:
        num, denom = _hitzer_inv(x)
    else:
        num, denom = _shirokov_inv(x)
    if abs(denom) < 1e-15:
        raise ValueError("Multivector is not invertible")
    return num / denom


def _hitzer_inv(x: Multivector) -> tuple[Multivector, float]:
    """Hitzer closed-form inverse for d ≤ 5 (Hitzer & Sangwine 2017)."""
    d = x.algebra.n
    if d == 0:
        return x.algebra.scalar(1.0), x.scalar_part
    elif d == 1:
        num = involute(x)
    elif d == 2:
        num = conjugate(x)
    elif d == 3:
        xconj = conjugate(x)
        num = gp(xconj, reverse(gp(x, xconj)))
    elif d == 4:
        xconj = conjugate(x)
        x_xconj = gp(x, xconj)
        num = gp(xconj, x_xconj - 2 * grades(x_xconj, [3, 4]))
    elif d == 5:
        xconj = conjugate(x)
        x_xconj = gp(x, xconj)
        combo = gp(xconj, reverse(x_xconj))
        x_combo = gp(x, combo)
        num = gp(combo, x_combo - 2 * grades(x_combo, [1, 4]))
    else:
        raise NotImplementedError(f"Hitzer inverse not available for d={d}")
    denom = scalar_product(x, num).scalar_part
    return num, denom


def _shirokov_inv(x: Multivector) -> tuple[Multivector, float]:
    """Shirokov iterative inverse for any algebra (arXiv:2005.04015)."""
    alg = x.algebra
    n = 2 ** ((alg.n + 1) // 2)
    # Build powers of x using addition chains
    powers = [x]  # powers[0] = x^1
    for _i in range(1, n):
        powers.append(gp(powers[-1], x))
    # Iterative adjugate construction
    cs = []
    xs = []
    for i in range(1, n + 1):
        xi = powers[i - 1]
        for j in range(len(cs)):
            xi = xi - gp(powers[i - j - 2], x.algebra.scalar(cs[j]))
        sp = scalar_product(xi, x.algebra.scalar(1.0)).scalar_part
        if i < n:
            # Check if xi is scalar (converged early)
            if np.allclose(xi.data[1:], 0):
                adj = xs[-1] - x.algebra.scalar(cs[-1]) if xs else x.algebra.scalar(1.0)
                return adj, xi.scalar_part
            xs.append(xi)
            cs.append(n * sp / i if sp != 0 else 0)
        else:
            # Final iteration: xi should be scalar
            adj = xs[-1] - x.algebra.scalar(cs[-1]) if xs else x.algebra.scalar(1.0)
            return adj, xi.scalar_part
    # Should not reach here
    raise RuntimeError("Shirokov inverse failed to converge")


# --- Predicates ---


def is_scalar(x: Multivector) -> bool:
    """True if x is a pure scalar (all non-grade-0 components are zero)."""
    return np.allclose(x.data[1:], 0)


def is_vector(x: Multivector) -> bool:
    """True if x is a pure 1-vector."""
    return x == grade(x, 1)


def is_bivector(x: Multivector) -> bool:
    """True if x is a pure 2-vector."""
    return x == grade(x, 2)


def is_even(x: Multivector) -> bool:
    """True if x contains only even-grade components (grades 0, 2, 4, …)."""
    alg = x.algebra
    for k in range(alg.n + 1):
        if k % 2 == 1 and np.any(np.abs(x.data[alg._grade_masks[k]]) > 1e-12):
            return False
    return True


def is_rotor(x: Multivector) -> bool:
    """True if x is a rotor: even-graded and x * ~x ≈ 1."""
    return is_even(x) and np.isclose(gp(x, reverse(x)).scalar_part, 1.0)


def is_basis_blade(x: Multivector) -> bool:
    """True if x is a basis blade (possibly scaled).

    A basis blade has exactly one nonzero component in the coefficient
    array. e.g. e₁, 3e₁₂, -e₁₂₃ are blades; e₁ + e₂ is not.
    """
    return np.count_nonzero(np.abs(x.data) > 1e-12) == 1


@ga_op("even_grades", arity=1, grade=lambda k, n: k if k % 2 == 0 else None)
def even_grades(x: Multivector) -> Multivector:
    """Extract even-grade components."""
    alg = x.algebra
    return grades(x, [k for k in range(0, alg.n + 1, 2)])


@ga_op("odd_grades", arity=1, grade=lambda k, n: k if k % 2 == 1 else None)
def odd_grades(x: Multivector) -> Multivector:
    """Extract odd-grade components."""
    alg = x.algebra
    return grades(x, [k for k in range(1, alg.n + 1, 2)])


def squared(x: Multivector) -> Multivector:
    """Geometric product of x with itself: x²."""
    if x._is_symbolic:
        return x.sq
    return gp(x, x)


def sandwich(r: Multivector, x: Multivector) -> Multivector:
    """Sandwich product: r x ~r.

    The fundamental transformation in GA. When r is a rotor (even-graded,
    r*~r = 1), this applies the rotation/boost encoded by r to x.
    Grade-preserving: if x is grade-k, the result is also grade-k.

    Laziness-aware: if r or x is symbolic, the result is symbolic with a symbolic
    expression tree.
    """
    return r * x * ~r


sw = sandwich


@ga_op("exp", arity=1)
def exp(B: Multivector) -> Multivector:
    """Bivector exponential: exp(B) = cos(|B|) + sin(|B|) * B/|B|.

    For a bivector B in a Euclidean algebra (B² < 0), this produces a rotor.
    For a timelike bivector (B² > 0), uses hyperbolic functions instead:
    exp(B) = cosh(|B|) + sinh(|B|) * B/|B|.
    For a null bivector (B² = 0), exp(B) = 1 + B.

    This is the standard way to build a rotor from a bivector without
    manually computing cos(θ/2) and sin(θ/2). Note: ``alg.rotor(B, radians=θ)``
    computes ``exp(-θ/2 * B)`` for a unit bivector B.
    """
    B2 = gp(B, B).scalar_part
    if abs(B2) < 1e-15:
        # Null bivector: exp(B) = 1 + B
        return B.algebra.scalar(1.0) + B
    if B2 < 0:
        # Spacelike bivector (Euclidean rotation): B² < 0
        mag = np.sqrt(-B2)
        return B.algebra.scalar(np.cos(mag)) + np.sin(mag) / mag * B
    else:
        # Timelike bivector (hyperbolic/boost): B² > 0
        mag = np.sqrt(B2)
        return B.algebra.scalar(np.cosh(mag)) + np.sinh(mag) / mag * B


@ga_op("log", arity=1)
def log(R: Multivector) -> Multivector:
    """Rotor logarithm: extract the bivector B such that exp(B) = R.

    R should be a normalised rotor (even-graded, R*~R = 1). Returns the
    bivector B. For Euclidean rotors, B encodes the half-angle and plane:
    the rotation angle is 2*norm(B) and the plane is unit(B).

    Raises ValueError if R is a pure scalar ±1 (log is zero or undefined).
    """
    s = R.data[0]  # scalar part
    B = R - R.algebra.scalar(s)  # bivector part
    B2 = gp(B, B).scalar_part

    if abs(B2) < 1e-15:
        # Pure scalar rotor: R ≈ ±1, log = 0
        return R.algebra.scalar(0.0) * R

    if B2 < 0:
        # Euclidean rotor
        mag = np.sqrt(-B2)
        theta = np.arctan2(mag, s)
        return (theta / mag) * B
    else:
        # Hyperbolic rotor
        mag = np.sqrt(B2)
        phi = np.arctanh(mag / s) if abs(s) > abs(mag) else np.arctan2(mag, s)
        return (phi / mag) * B


@ga_op("outerexp", arity=1)
def outerexp(x: Multivector) -> Multivector:
    """Outer exponential: 1 + x + x∧x/2! + x∧x∧x/3! + ...

    Uses the wedge product instead of the geometric product. The series
    always terminates at grade n (algebra dimension), so this is exact.
    """
    alg = x.algebra
    terms = [alg.scalar(1.0), x]
    for k in range(2, alg.n + 1):
        t = op(terms[-1], x) / k
        if np.allclose(t.data, 0):
            break
        terms.append(t)
    return sum(terms[1:], start=terms[0])


@ga_op("outersin", arity=1)
def outersin(x: Multivector) -> Multivector:
    """Outer sine: odd terms of the outer exponential series."""
    alg = x.algebra
    terms = [x]
    w = x
    for k in range(2, alg.n + 1):
        w = op(w, x) / k
        if np.allclose(w.data, 0):
            break
        if k % 2 == 1:
            terms.append(w)
    return sum(terms[1:], start=terms[0]) if terms else alg.scalar(0.0)


@ga_op("outercos", arity=1)
def outercos(x: Multivector) -> Multivector:
    """Outer cosine: even terms of the outer exponential series."""
    alg = x.algebra
    terms = [alg.scalar(1.0)]
    w = x
    for k in range(2, alg.n + 1):
        w = op(w, x) / k
        if np.allclose(w.data, 0):
            break
        if k % 2 == 0:
            terms.append(w)
    return sum(terms[1:], start=terms[0])


@ga_op("outertan", arity=1)
def outertan(x: Multivector) -> Multivector:
    """Outer tangent: outersin(x) / outercos(x)."""
    return gp(outersin(x), inverse(outercos(x)))


def project(v: Multivector, B: Multivector) -> Multivector:
    """Project v onto the subspace defined by blade B.

    Computes the component of v that lies within B:
    project(v, B) = (v ⌋ B) * B⁻¹

    For a vector v and a blade B, this gives the part of v parallel to B.
    """
    return gp(left_contraction(v, B), inverse(B))


def reject(v: Multivector, B: Multivector) -> Multivector:
    """Reject v from the subspace defined by blade B.

    Computes the component of v perpendicular to B:
    reject(v, B) = v - project(v, B)

    For a vector v and a blade B, this gives the part of v orthogonal to B.
    """
    return v - project(v, B)


def reflect(v: Multivector, n: Multivector) -> Multivector:
    """Reflect v in the hyperplane orthogonal to vector n.

    Computes -n * v * n⁻¹. The vector n defines the normal to the
    reflection hyperplane. For a unit vector n, this simplifies to
    -n * v * n.

    Note: this is a sandwich product with a sign flip. For reflection
    *through* n (not the hyperplane), use ``sandwich(n, v)`` instead.
    """
    return gp(gp(-n, v), inverse(n))


# --- Aliases ---
# These are literally the same functions, not wrappers. They exist so users
# can write whichever name feels natural: ``wedge(a, b)`` or ``op(a, b)``,
# ``rev(x)`` or ``reverse(x)``, etc. The short names are the "canonical" ones
# used throughout the codebase; the long names are for readability.

geometric_product = gp
wedge = op
outer_product = op
rev = reverse
grade_involution = involute
normalize = unit
normalise = unit
norm_squared = norm2
magnitude_squared = norm2
mag2 = norm2


def ip(a: Multivector, b: Multivector, mode: str = "doran_lasenby") -> Multivector:
    """Unified inner product dispatcher — removes ambiguity about which inner product.

    GA has multiple inner products that agree on simple cases (vector·vector)
    but diverge on mixed grades. Rather than guessing, this function makes
    the choice explicit.

    Modes:
        "doran_lasenby" — Doran–Lasenby inner product (default). Uses |r-s|
                     grade selection, includes scalars. This is the ``|``
                     operator. Also known as the Dorst inner product.
        "hestenes" — Hestenes inner product. Like Doran–Lasenby but kills
                     scalars (zero if either operand is grade-0).
        "left"     — Left contraction (a ⌋ b). Grade s-r, zero if r > s.
                     Most common in GA literature.
        "right"    — Right contraction (a ⌊ b). Grade r-s, zero if s > r.
                     Mirror of left contraction.
        "scalar"   — Scalar product. Grade-0 part of gp(a, b) only.
    """
    match mode:
        case "doran_lasenby" | "dorst":
            return doran_lasenby_inner(a, b)
        case "hestenes":
            return hestenes_inner(a, b)
        case "left":
            return left_contraction(a, b)
        case "right":
            return right_contraction(a, b)
        case "scalar":
            return scalar_product(a, b)
        case _:
            raise ValueError(
                f"Unknown inner product mode: {mode!r}. "
                f"Use 'doran_lasenby', 'dorst', 'hestenes', 'left', 'right', or 'scalar'."
            )


inner_product = ip
