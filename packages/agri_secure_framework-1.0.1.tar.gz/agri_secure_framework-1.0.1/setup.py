#!/usr/bin/env python
"""
setup.py - Installation configuration for agri_secure
Run: pip install -e . for development install
"""

import os
import sys
from setuptools import setup, find_packages

# Read long description from README
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

# Read requirements
with open("requirements.txt", "r", encoding="utf-8") as f:
    requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]

# Read development requirements
with open("requirements-dev.txt", "r", encoding="utf-8") as f:
    dev_requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]

setup(
    # Package Information
    name="agri-secure-framework",
    version="1.0.1",
    author="Mathews Phiri",
    author_email="mathewsphirip189@gmail.com",
    description="Production-ready cybersecurity framework for agricultural data systems",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/zambia-agri/agri-secure-framework",
    
    # Package Discovery
    packages=find_packages(exclude=["tests*", "examples*"]),
    include_package_data=True,
    zip_safe=False,
    
    # Python Version
    python_requires=">=3.8, <3.14",
    
    # Dependencies
    install_requires=requirements,
    
    # Extra Dependencies
    extras_require={
        "django": ["Django>=3.2,<5.0"],
        "flask": ["Flask>=2.0,<3.0"],
        "fastapi": ["fastapi>=0.95,<1.0", "uvicorn[standard]>=0.21"],
        "postgres": ["psycopg2-binary>=2.9"],
        "mysql": ["mysqlclient>=2.1"],
        "mongodb": ["pymongo>=4.3"],
        "redis": ["redis>=4.5"],
        "aws": ["boto3>=1.26"],
        "azure": ["azure-storage-blob>=12.0"],
        "gcp": ["google-cloud-storage>=2.0"],
        "dev": dev_requirements,
        "all": [
            "Django>=3.2,<5.0",
            "Flask>=2.0,<3.0",
            "fastapi>=0.95,<1.0",
            "uvicorn[standard]>=0.21",
            "psycopg2-binary>=2.9",
            "pymongo>=4.3",
            "redis>=4.5",
            "boto3>=1.26",
        ]
    },
    
    # Command Line Scripts
    entry_points={
        "console_scripts": [
            "agri-secure=agri_secure.cli:main",
            "agri-secure-admin=agri_secure.admin:main",
        ],
    },
    
    # Classifiers
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Natural Language :: English",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Security",
        "Topic :: Security :: Cryptography",
        "Topic :: Database",
        "Topic :: Internet :: WWW/HTTP",
        "Framework :: Django",
        "Framework :: Flask",
        "Framework :: FastAPI",
    ],
    
    # Project URLs - DEFINED ONLY ONCE
    project_urls={
        "Documentation": "https://agri-secure-framework.readthedocs.io",
        "Source": "https://github.com/zambia-agri/agri-secure-framework",
        "Tracker": "https://github.com/zambia-agri/agri-secure-framework/issues",
        "Changelog": "https://github.com/zambia-agri/agri-secure-framework/blob/main/CHANGELOG.md",
    },
    
    # Package Data
    package_data={
        "agri_secure": [
            "py.typed",
            "core/*.pyi",
            "models/schemas/*.json",
        ],
    },
    
    # Metadata
    keywords="agriculture security encryption cybersecurity zambia nist framework blockchain",
    platforms=["any"],
    license="MIT",
)