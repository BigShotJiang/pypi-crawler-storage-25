from manuscript import Pipeline
from manuscript.utils.visualization import visualize_page
from manuscript.detectors import YOLO, EAST
from manuscript.recognizers import TRBA

img_path = r"2c05a920-e3a7-44c2-b8ee-dfa3bf017f1c.jpeg"

pipeline = Pipeline(
    detector=YOLO(
        score_thresh=0.01,
        weights=r"yolo26x_obb_text_g1",
        axis_aligned_output=False,
        containment_threshold=1.1,
    ),
    recognizer=TRBA(weights="trba_lite_g2", region_preparer="quad_warp"),
)
#bbox
#polygon_mask
#quad_warp
result = pipeline.predict(
    img_path,
)

text = pipeline.get_text(result["page"])
print(text)

vis_img = visualize_page(img_path, result["page"])
vis_img.show()
