"""CO2 Concentration characteristic implementation."""

from __future__ import annotations

from .base import BaseCharacteristic
from .templates import ConcentrationTemplate


class CO2ConcentrationCharacteristic(BaseCharacteristic[float]):
    r"""Carbon Dioxide concentration characteristic (0x2B8C).

    YAML registry name uses LaTeX subscript form ("CO\\textsubscript{2} Concentration").
    We restore explicit `_characteristic_name` so UUID resolution succeeds because
    the automatic CamelCase splitter cannot derive the LaTeX form from the class name.

    Represents carbon dioxide concentration in parts per million (ppm)
    with a resolution of 1 ppm.
    """

    # Explicit YAML/registry name (contains LaTeX markup not derivable heuristically)
    _characteristic_name = "CO\\textsubscript{2} Concentration"

    _template = ConcentrationTemplate()

    _manual_unit: str | None = "ppm"  # Override template's "ppm" default

    # Template configuration
    resolution: float = 1.0
