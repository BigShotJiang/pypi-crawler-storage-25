"""Elevation characteristic implementation."""

from __future__ import annotations

from ...types.units import LengthUnit
from .base import BaseCharacteristic
from .templates import ScaledSint24Template


class ElevationCharacteristic(BaseCharacteristic[float]):
    """Elevation characteristic (0x2A6C).

    org.bluetooth.characteristic.elevation

    Elevation characteristic.

    Represents the elevation relative to sea level unless otherwise
    specified in the service.

    Format: sint24 (3 bytes) with 0.01 meter resolution.
    """

    _template = ScaledSint24Template(scale_factor=0.01)

    _manual_unit: str | None = LengthUnit.METERS.value  # Override template's "units" default
    resolution: float = 0.01
