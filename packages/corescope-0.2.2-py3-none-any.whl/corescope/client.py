import logging
from datetime import datetime
from typing import Optional, Tuple, Type, TypeVar
from urllib.parse import quote

import objectrest

from corescope.internal.models import BaseModel
from corescope.internal.utils import datetime_to_iso8601
from corescope.models import (
    BulkNodeHealthEntry,
    NodeHealthSummary,
    Stats,
    Observer,
    Channel,
    PacketsSummary,
    PayloadType,
    NodeSummary,
    NeighborsSummary,
    ChannelMessagesSummary,
    NetworkNodesStatus,
    RolesSummary,
    RFSNRSummary,
    Topology,
    SubPathsSummary,
    DistanceSummary
)

BaseModelType = TypeVar('BaseModelType', bound=BaseModel)


class CoreScopeClient:
    def __init__(self, base_url: str, verbose: bool = False, ssl_verify: bool = True):
        if base_url.endswith("/"):
            base_url = base_url[:-1]
        self._base_url = base_url
        self._session = objectrest.Session()
        self._ssl_verify = ssl_verify
        logging.basicConfig(format='%(levelname)s:%(message)s', level=(logging.DEBUG if verbose else logging.ERROR))
        self._logger = logging.getLogger("corescope")

    def __str__(self):
        return f"{self.__class__.__name__}(url={self._base_url})"

    def __repr__(self):
        return f"{self.__class__.__name__}(url={self._base_url})"

    def _prepare_request(self,
                         endpoint: str,
                         params: Optional[dict] = None) -> Tuple[str, dict]:
        """
        Prepare API call

        :param endpoint: CoreScope endpoint
        :type endpoint: str
        :param params: Dictionary of parameters to add to url
        :type params: dict, optional
        :returns: URL and parameters
        :rtype: Tuple[str, dict]
        """
        if endpoint.startswith("/"):
            endpoint = endpoint[1:]

        if not params:
            params = {}

        url = f"{self._base_url}/{endpoint}"

        return url, params

    def _get_object(self,
                    endpoint: str,
                    model: Type[BaseModelType],
                    extract_list: bool = False,
                    sub_keys: Optional[list[str]] = None,
                    params: Optional[dict] = None) -> BaseModelType | list[BaseModelType] | None:
        """
        Get JSON data from API call as a Pydantic model

        :param endpoint: CoreScope endpoint
        :type endpoint: str
        :param model: Pydantic model
        :type model: type[BaseModel]
        :param extract_list: Result is a list of Pydantic model
        :type extract_list: bool, optional
        :param sub_keys: List of sub keys to navigate to starting point for Pydantic serialization
        :type sub_keys: list, optional
        :param params: Dictionary of parameters to add to url
        :type params: dict, optional
        :returns: object of type model, or None
        :rtype: Optional[BaseModel]
        """
        url, params = self._prepare_request(endpoint=endpoint, params=params)

        return objectrest.get_object(url=url,  # type: ignore
                                     model=model,
                                     params=params,
                                     extract_list=extract_list,
                                     sub_keys=sub_keys,
                                     verify=self._ssl_verify,
                                     # Optionally ignore SSL errors for self-signed certificates
                                     raise_on_error=True)

    def get_node(self, public_key: str) -> NodeSummary | None:
        return self._get_object(endpoint=f"/api/nodes/{public_key}",  # type: ignore
                                model=NodeSummary)

    def get_stats(self) -> Stats | None:
        return self._get_object(endpoint="/api/stats",  # type: ignore
                                model=Stats)

    def get_node_health_reports(self) -> list[BulkNodeHealthEntry] | None:
        return self._get_object(endpoint="/api/nodes/bulk-health",  # type: ignore
                                model=BulkNodeHealthEntry,
                                extract_list=True)

    def get_node_health(self, public_key: str) -> NodeHealthSummary | None:
        return self._get_object(endpoint=f"/api/nodes/{public_key}/health",  # type: ignore
                                model=NodeHealthSummary)

    def get_observers(self) -> list[Observer] | None:
        return self._get_object(endpoint="/api/observers",  # type: ignore
                                model=Observer,
                                extract_list=True,
                                sub_keys=["observers"])

    def get_channels(self) -> list[Channel] | None:
        return self._get_object(endpoint="/api/channels",  # type: ignore
                                model=Channel,
                                extract_list=True,
                                sub_keys=["channels"])

    def get_channel_messages(self, channel_name: str) -> ChannelMessagesSummary | None:
        return self._get_object(endpoint=f"/api/channels/{quote(channel_name)}/messages",  # type: ignore
                                model=ChannelMessagesSummary)

    def get_packets(self, since: Optional[datetime] = None, limit: int = 50000,
                    _type: Optional[PayloadType] = None) -> PacketsSummary | None:
        params = {
            "limit": limit,
            "groupByHash": True,
        }
        if since:
            params["since"] = datetime_to_iso8601(since)
        if _type:
            params["type"] = _type.value
        return self._get_object(endpoint="/api/packets",  # type: ignore
                                model=PacketsSummary,
                                params=params)

    def get_node_neighbors(self, public_key: str) -> NeighborsSummary | None:
        return self._get_object(endpoint=f"/api/nodes/{public_key}/neighbors",  # type: ignore
                                model=NeighborsSummary)

    def get_network_status(self) -> NetworkNodesStatus | None:
        return self._get_object(endpoint="/api/nodes/network-status",  # type: ignore
                                model=NetworkNodesStatus)

    def get_roles(self) -> RolesSummary | None:
        return self._get_object(endpoint="/api/analytics/roles",  # type: ignore
                                model=RolesSummary)

    def get_rf_snr(self, window: Optional[str] = None) -> RFSNRSummary | None:
        params = {}
        if window:
            params["window"] = window
        return self._get_object(endpoint="/api/analytics/rf",  # type: ignore
                                model=RFSNRSummary,
                                params=params)

    def get_topology(self) -> Topology | None:
        return self._get_object(endpoint="/api/analytics/topology",  # type: ignore
                                model=Topology)

    def get_subpaths(self) -> SubPathsSummary | None:
        return self._get_object(endpoint="/api/analytics/subpaths",  # type: ignore
                                model=SubPathsSummary)

    def get_distance(self) -> DistanceSummary | None:
        return self._get_object(endpoint="/api/analytics/distance",  # type: ignore
                                model=DistanceSummary)
