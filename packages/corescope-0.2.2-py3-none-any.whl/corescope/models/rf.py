from corescope.internal import BaseModel, Field


class Bin(BaseModel):
    count: int = Field(alias="count")
    w: float = Field(alias="w")
    x: float = Field(alias="x")


class PacketSizes(BaseModel):
    bins: list[Bin] = Field(alias="bins")
    max: int = Field(alias="max")
    min: int = Field(alias="min")


class PacketsPerHourItem(BaseModel):
    hour: str = Field(alias="hour")
    count: int = Field(alias="count")


class PayloadType(BaseModel):
    type: int = Field(alias="type")
    name: str = Field(alias="name")
    count: int = Field(alias="count")


class Rssi(BaseModel):
    average: float = Field(alias="avg")
    max: int = Field(alias="max")
    median: int = Field(alias="median")
    min: int = Field(alias="min")
    standard_deviation: float = Field(alias="stddev")


class RssiValues(BaseModel):
    bins: list[Bin] = Field(alias="bins")
    max: int = Field(alias="max")
    min: int = Field(alias="min")


class ScatterDatum(BaseModel):
    snr: float = Field(alias="snr")
    rssi: int = Field(alias="rssi")


class SignalOverTimeItem(BaseModel):
    hour: str = Field(alias="hour")
    count: int = Field(alias="count")
    average_snr: float = Field(alias="avgSnr")


class Snr(BaseModel):
    average: float = Field(alias="avg")
    max: float = Field(alias="max")
    median: float = Field(alias="median")
    min: float = Field(alias="min")
    standard_deviation: float = Field(alias="stddev")


class SnrByTypeItem(BaseModel):
    name: str = Field(alias="name")
    count: int = Field(alias="count")
    average: float = Field(alias="avg")
    min: float = Field(alias="min")
    max: float = Field(alias="max")


class SnrValues(BaseModel):
    bins: list[Bin] = Field(alias="bins")
    max: float = Field(alias="max")
    min: float = Field(alias="min")


class RFSNRSummary(BaseModel):
    avg_packet_size: int = Field(alias="avgPacketSize")
    max_packet_size: int = Field(alias="maxPacketSize")
    min_packet_size: int = Field(alias="minPacketSize")
    packet_sizes: PacketSizes = Field(alias="packetSizes")
    packets_per_hour: list[PacketsPerHourItem] = Field(alias="packetsPerHour")
    payload_types: list[PayloadType] = Field(alias="payloadTypes")
    rssi: Rssi = Field(alias="rssi")
    rssi_values: RssiValues = Field(alias="rssiValues")
    scatter_data: list[ScatterDatum] = Field(alias="scatterData")
    signal_over_time: list[SignalOverTimeItem] = Field(alias="signalOverTime")
    snr: Snr = Field(alias="snr")
    snr_by_type: list[SnrByTypeItem] = Field(alias="snrByType")
    snr_values: SnrValues = Field(alias="snrValues")
    time_span_hours: float = Field(alias="timeSpanHours")
    total_all_packets: int = Field(alias="totalAllPackets")
    total_packets: int = Field(alias="totalPackets")
    total_transmissions: int = Field(alias="totalTransmissions")
