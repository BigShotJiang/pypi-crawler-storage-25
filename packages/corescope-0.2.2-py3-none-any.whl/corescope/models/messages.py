from datetime import datetime
from typing import Annotated

from corescope.internal import BaseModel, Field, UnixTimestampAsDateTime


class Message(BaseModel):
    hops: int = Field(alias="hops")
    observer_names: list[str] = Field(alias="observers")
    packet_hash: str = Field(alias="packetHash")
    packet_id: int = Field(alias="packetId")
    repeats: int = Field(alias="repeats")
    sender: str = Field(alias="sender")
    sender_timestamp: Annotated[UnixTimestampAsDateTime, Field(alias="sender_timestamp")]
    snr: float = Field(alias="snr")
    text: str = Field(alias="text")
    timestamp: datetime = Field(alias="timestamp")
