from typing import Optional

from corescope.internal import BaseModel, Field


class RoleCounts(BaseModel):
    companion: Optional[int] = Field(alias="companion", default=0)
    repeater: Optional[int] = Field(alias="repeater", default=0)
    room: Optional[int] = Field(alias="room", default=0)
    sensor: Optional[int] = Field(alias="sensor", default=0)


class NetworkNodesStatus(BaseModel):
    active: int = Field(alias="active")
    degraded: int = Field(alias="degraded")
    role_counts: RoleCounts = Field(alias="roleCounts")
    silent: int = Field(alias="silent")
    total: int = Field(alias="total")
