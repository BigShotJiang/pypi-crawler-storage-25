from datetime import datetime
from typing import Optional

from corescope.internal import BaseModel, Field

class Observation(BaseModel):
    id: int = Field(alias="id")
    observer_id: str = Field(alias="observer_id")
    observer_name: str = Field(alias="observer_name")
    path_json: str = Field(alias="path_json")
    rssi: int = Field(alias="rssi")
    snr: float = Field(alias="snr")
    timestamp: datetime = Field(alias="timestamp")
    transmission_id: int = Field(alias="transmission_id")
