from datetime import datetime
from typing import Optional

from corescope.internal import BaseModel, Field


class Neighbor(BaseModel):
    public_key: str = Field(alias="pubkey")
    prefix: str = Field(alias="prefix")
    name: str = Field(alias="name")
    role: str = Field(alias="role")
    count: int = Field(alias="count")
    score: float = Field(alias="score")
    first_seen: datetime = Field(alias="first_seen")
    last_seen: datetime = Field(alias="last_seen")
    avg_snr: float = Field(alias="avg_snr")
    distance_km: Optional[float] = Field(alias="distance_km", default=None)
    observer_public_keys: list[str] = Field(alias="observers")
    ambiguous: bool = Field(alias="ambiguous")


class NeighborsSummary(BaseModel):
    node_public_key: str = Field(alias="node")
    neighbors: list[Neighbor] = Field(alias="neighbors")
    total_observations: int = Field(alias="total_observations")
