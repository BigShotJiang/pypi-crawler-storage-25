from datetime import datetime

from corescope.internal import BaseModel, Field
from corescope.models.messages import Message


class Channel(BaseModel):
    hash: str = Field(alias="hash")
    name: str = Field(alias="name")
    last_activity: datetime = Field(alias="lastActivity")
    last_message: str = Field(alias="lastMessage")
    last_sender: str | None = Field(alias="lastSender")
    message_count: int = Field(alias="messageCount")


class ChannelMessagesSummary(BaseModel):
    messages: list[Message] = Field(alias="messages")
    total: int = Field(alias="total")
