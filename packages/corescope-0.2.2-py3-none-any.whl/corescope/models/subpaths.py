from corescope.internal import BaseModel, Field

class Subpath(BaseModel):
    count: int = Field(alias="count")
    hops: int = Field(alias="hops")
    path: str = Field(alias="path")
    percentage_of_all_paths: float = Field(alias="pct")
    raw_hops: list[str] = Field(alias="rawHops")


class SubPathsSummary(BaseModel):
    subpaths: list[Subpath] = Field(alias="subpaths")
    total_paths_count: int = Field(alias="totalPaths")
