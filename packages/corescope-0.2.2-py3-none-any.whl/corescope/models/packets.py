import json
from datetime import datetime
from enum import Enum
from typing import Optional, Any

from corescope.internal import BaseModel, Field


class PayloadType(int, Enum):
    REQ = 0
    RESPONSE = 1
    TXT_MSG = 2
    ACK = 3
    ADVERT = 4
    GRP_TXT = 5  # Also CHAN
    GRP_DATA = 6
    ANON_REQ = 7
    PATH = 8
    TRACE = 9
    MULTIPART = 10
    CONTROL = 11
    UNKNOWN_12 = 12
    UNKNOWN_13 = 13
    UNKNOWN_14 = 14
    RAW_CUSTOM = 15


class Packet(BaseModel):
    parsed_path: Optional[list[str]] = Field(alias='_parsedPath', default=[])
    decoded_json: str = Field(alias='decoded_json')
    direction: str = Field(alias='direction')
    first_seen: datetime = Field(alias='first_seen')
    hash: str = Field(alias='hash')
    id: int = Field(alias='id')
    observation_count: int = Field(alias='observation_count')
    observer_id: str = Field(alias='observer_id')
    observer_name: str = Field(alias='observer_name')
    path_json: str = Field(alias='path_json')
    payload_type: PayloadType = Field(alias='payload_type')
    raw_hex: str = Field(alias='raw_hex')
    resolved_path: Optional[list[str | None]] = Field(alias='resolved_path', default=[])
    route_type: int = Field(alias='route_type')
    rssi: Optional[int] = Field(alias='rssi', default=None)
    snr: Optional[float] = Field(alias='snr', default=None)
    timestamp: datetime = Field(alias='timestamp')

    @property
    def payload_json(self) -> dict[str, Any]:
        return json.loads(self.decoded_json)

    @property
    def sender(self) -> Optional[str]:
        if self.payload_type != PayloadType.GRP_TXT:
            return None

        return self.payload_json.get('sender')


class PacketsSummary(BaseModel):
    packets: list[Packet] = Field(alias='packets')
    total: int = Field(alias='total')
