from datetime import datetime

from corescope.internal import BaseModel, Field

class Observer(BaseModel):
    id: str = Field(alias="id")
    name: str = Field(alias="name")
    iata: str = Field(alias="iata")
    last_seen: datetime = Field(alias="last_seen")
    first_seen: datetime = Field(alias="first_seen")
    packet_count: int = Field(alias="packet_count")
    model: str | None = Field(alias="model")
    firmware: str | None = Field(alias="firmware")
    client_version: str | None = Field(alias="client_version")
    radio: str | None = Field(alias="radio")
    battery_mv: int | None = Field(alias="battery_mv")
    uptime_secs: int | None = Field(alias="uptime_secs")
    noise_floor: float | None = Field(alias="noise_floor")
    last_packet_at: datetime | None = Field(alias="last_packet_at")
    packets_last_hour: int | None = Field(alias="packetsLastHour")
    latitude: float | None = Field(alias="lat")
    longitude: float | None = Field(alias="lon")
    node_role: str | None = Field(alias="nodeRole")
