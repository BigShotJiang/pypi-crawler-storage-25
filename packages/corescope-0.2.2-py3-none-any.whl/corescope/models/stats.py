from typing import Optional

from corescope.internal import BaseModel, Field


class StatCounts(BaseModel):
    repeaters: Optional[int] = Field(alias="repeaters", default=None)
    rooms: Optional[int] = Field(alias="rooms", default=None)
    companions: Optional[int] = Field(alias="companions", default=None)
    sensors: Optional[int] = Field(alias="sensors", default=None)


class Stats(BaseModel):
    total_packets: int = Field(alias="totalPackets")
    total_transmissions: int = Field(alias="totalTransmissions")
    total_observations: int = Field(alias="totalObservations")
    total_nodes: int = Field(alias="totalNodes")
    total_nodes_all_time: int = Field(alias="totalNodesAllTime")
    total_observers: int = Field(alias="totalObservers")
    packets_last_hour: int = Field(alias="packetsLastHour")
    packets_last_24_hours: int = Field(alias="packetsLast24h")
    engine: Optional[str] = Field(alias="engine", default=None)
    version: Optional[str] = Field(alias="version", default=None)
    commit: Optional[str] = Field(alias="commit", default=None)
    build_time: Optional[str] = Field(alias="buildTime")
    counts: StatCounts = Field(alias="counts")
    backfilling: bool = Field(alias="backfilling", default=False)
    backfill_progress: Optional[int] = Field(alias="backfillProgress", default=None)
    signature_drops: Optional[int] = Field(alias="signatureDrops", default=None)
    hash_migration_complete: bool = Field(alias="hashMigrateComplete", default=False)
    store_data_mb: Optional[float] = Field(alias="storeDataMB", default=None)
    process_rss_mb: Optional[float] = Field(alias="processRSSMB", default=None)
    go_heap_in_use_mb: Optional[float] = Field(alias="goHeapInUseMB", default=None)
    go_sys_mb: Optional[float] = Field(alias="goSysMB", default=None)
