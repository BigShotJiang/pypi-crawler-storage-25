from typing import Optional

from corescope.internal import BaseModel, Field


class CategoryStatsCategory(BaseModel):
    average: float = Field(alias="avg")
    count: int = Field(alias="count")
    max: float = Field(alias="max")
    median: float = Field(alias="median")
    min: float = Field(alias="min")


class CategoryStats(BaseModel):
    companion_to_companion: Optional[CategoryStatsCategory] = Field(alias='C↔C', default=None)
    companion_to_repeater: Optional[CategoryStatsCategory] = Field(alias='C↔R', default=None)
    repeater_to_repeater: Optional[CategoryStatsCategory] = Field(alias='R↔R', default=None)


class Bin(BaseModel):
    count: int = Field(alias="count")
    w: float = Field(alias="w")
    x: float = Field(alias="x")


class DistHistogram(BaseModel):
    bins: list[Bin] = Field(alias="bins")
    max: float = Field(alias="max")
    min: int = Field(alias="min")


class DistOverTimeItem(BaseModel):
    average: float = Field(alias="avg")
    count: int = Field(alias="count")
    hour: str = Field(alias="hour")


class Summary(BaseModel):
    average_distance: float = Field(alias="avgDist")
    max_distance: float = Field(alias="maxDist")
    total_hops: int = Field(alias="totalHops")
    total_paths: int = Field(alias="totalPaths")


class TopHop(BaseModel):
    best_snr: float = Field(alias="bestSnr")
    distance: float = Field(alias="dist")
    from_name: str = Field(alias="fromName")
    from_public_key: str = Field(alias="fromPk")
    hash: str = Field(alias="hash")
    median_snr: float = Field(alias="medianSnr")
    observer_count: int = Field(alias="obsCount")
    timestamp: str = Field(alias="timestamp")
    to_name: str = Field(alias="toName")
    to_public_key: str = Field(alias="toPk")
    type: str = Field(alias="type")


class Hop(BaseModel):
    distance: float = Field(alias="dist")
    from_name: str = Field(alias="fromName")
    from_public_key: str = Field(alias="fromPk")
    to_name: str = Field(alias="toName")
    to_public_key: str = Field(alias="toPk")


class TopPath(BaseModel):
    hash: str = Field(alias="hash")
    hop_count: int = Field(alias="hopCount")
    hops: list[Hop] = Field(alias="hops")
    timestamp: str = Field(alias="timestamp")
    total_distance: float = Field(alias="totalDist")


class DistanceSummary(BaseModel):
    category_stats: CategoryStats = Field(alias="catStats")
    distance_histogram: DistHistogram = Field(alias="distHistogram")
    distance_over_time: list[DistOverTimeItem] = Field(alias="distOverTime")
    summary: Summary = Field(alias="summary")
    top_hops: list[TopHop] = Field(alias="topHops")
    top_paths: list[TopPath] = Field(alias="topPaths")
