from corescope.internal import BaseModel, Field


class BestPathListEntry(BaseModel):
    hop: str = Field(alias="hop")
    min_distance: int = Field(alias="minDist")
    name: str | None = Field(alias="name")
    observer_id: str = Field(alias="observer_id")
    observer_name: str = Field(alias="observer_name")
    public_key: str | None = Field(alias="pubkey")


class HopDistributionEntry(BaseModel):
    count: int = Field(alias="count")
    hops: int = Field(alias="hops")


class HopsVsSnrEntry(BaseModel):
    average_snr: float = Field(alias="avgSnr")
    count: int = Field(alias="count")
    hops: int = Field(alias="hops")


class MultiObsNodeObserver(BaseModel):
    count: int = Field(alias="count")
    min_distance: int = Field(alias="minDist")
    observer_id: str = Field(alias="observer_id")
    observer_name: str = Field(alias="observer_name")


class MultiObsNode(BaseModel):
    hop: str = Field(alias="hop")
    name: str | None = Field(alias="name")
    observers: list[MultiObsNodeObserver] = Field(alias="observers")
    public_key: str = Field(alias="pubkey")


class Observer(BaseModel):
    id: str = Field(alias="id")
    name: str = Field(alias="name")


class RingNode(BaseModel):
    count: int = Field(alias='count')
    distance_range: str | None = Field(alias='distRange')
    hop: str | None = Field(alias='hop')
    name: str | None = Field(alias='name')
    pubkey: str | None = Field(alias='pubkey')


class Ring(BaseModel):
    hops: int
    nodes: list[RingNode]


class PerObserverReachEntry(BaseModel):
    observer_name: str
    rings: list[Ring]


class TopPair(BaseModel):
    count: int = Field(alias='count')
    hop_a: str = Field(alias='hopA')
    hop_b: str = Field(alias='hopB')
    name_a: str = Field(alias='nameA')
    name_b: str = Field(alias='nameB')
    public_key_a: str = Field(alias='pubkeyA')
    public_key_b: str = Field(alias='pubkeyB')


class TopRepeater(BaseModel):
    count: int = Field(alias='count')
    hop: str = Field(alias='hop')
    name: str = Field(alias='name')
    public_key: str = Field(alias='pubkey')


class Topology(BaseModel):
    average_hops: float = Field(alias='avgHops')
    best_path_list: list[BestPathListEntry] = Field(alias='bestPathList')
    hop_distribution: list[HopDistributionEntry] = Field(alias='hopDistribution')
    hops_vs_snr: list[HopsVsSnrEntry] = Field(alias='hopsVsSnr')
    max_hops: int = Field(alias='maxHops')
    median_hops: int = Field(alias='medianHops')
    multi_obs_nodes: list[MultiObsNode] = Field(alias='multiObsNodes')
    observers: list[Observer] = Field(alias='observers')
    per_observer_reach: dict[str, PerObserverReachEntry] = Field(alias='perObserverReach')
    top_pairs: list[TopPair] = Field(alias='topPairs')
    top_repeaters: list[TopRepeater] = Field(alias='topRepeaters')
    unique_nodes: int = Field(alias='uniqueNodes')
