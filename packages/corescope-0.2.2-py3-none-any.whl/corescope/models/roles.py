from corescope.internal import BaseModel, Field


class Role(BaseModel):
    role: str = Field(alias="role")
    node_count: int = Field(alias="nodeCount")
    with_skew: int = Field(alias="withSkew")
    mean_absolute_skew_seconds: float = Field(alias="meanAbsSkewSec")
    median_absolute_skew_seconds: float = Field(alias="medianAbsSkewSec")
    ok_count: int = Field(alias="okCount")
    warning_count: int = Field(alias="warningCount")
    critical_count: int = Field(alias="criticalCount")
    absurd_count: int = Field(alias="absurdCount")
    no_clock_count: int = Field(alias="noClockCount")


class RolesSummary(BaseModel):
    total_nodes: int = Field(alias="totalNodes")
    roles: list[Role] = Field(alias="roles")
