from typing import Any, Optional, Annotated

from pydantic import BaseModel, Field as _PydanticField, BeforeValidator
from pydantic_core import PydanticUndefined

from corescope.internal.utils import epoch_to_datetime

_Unset: Any = PydanticUndefined

UnixTimestampAsDateTime = Annotated[
    Any, BeforeValidator(lambda v: epoch_to_datetime(epoch_time=v) if isinstance(v, (int, float)) else v)]


def _Field(default_if_not_present: Optional[Any] = _Unset, default_if_not_set: Optional[Any] = _Unset,
           **kwargs) -> Any:
    """
    Extension of pydantic.Field
    :param _type: pydantic type
    :param default_if_not_present: Value to set for property if key is not present in incoming data
    :param default_if_not_set: Value to set for property if key is present in incoming data but is set to None
    :param kwargs: Additional kwargs passed to pydantic.Field
    :return: pydantic Field
    """
    return _PydanticField(**kwargs)


class _Base(BaseModel):
    pass
