"""
Typed response objects returned by the Phoenix SDK.
Plain dataclasses — no heavy runtime dependencies.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


# ── Customers ─────────────────────────────────────────────────────────────────

@dataclass
class Customer:
    id: str
    tenant_id: str
    full_name: str
    status: str
    kyc_status: str
    created_at: str
    email: Optional[str] = None
    phone: Optional[str] = None
    external_id: Optional[str] = None
    metadata: dict = field(default_factory=dict)


# ── Eye — Scoring ──────────────────────────────────────────────────────────────

@dataclass
class SHAPReason:
    feature: str
    direction: str
    magnitude: float
    human_readable: str


@dataclass
class ScoreDecision:
    application_id: str
    customer_id: str
    outcome: str          # approve | refer | decline
    pd: float             # probability of default 0–1
    risk_band: str        # low | medium | high | very_high
    processing_ms: int
    assigned_limit: Optional[int] = None      # NGN kobo
    interest_rate: Optional[float] = None     # annual decimal e.g. 0.24
    model_version: Optional[str] = None
    reasons: list[SHAPReason] = field(default_factory=list)


# ── Eye — Fraud ────────────────────────────────────────────────────────────────

@dataclass
class FraudCheck:
    customer_id: str
    fraud_score: float    # 0–1
    action: str           # allow | flag | block
    severity: str         # low | medium | high | critical
    blacklisted: bool
    rules_triggered: list[str] = field(default_factory=list)
    alert_id: Optional[str] = None


# ── Eye — Categorisation ───────────────────────────────────────────────────────

@dataclass
class CategorisedTransaction:
    narration: str
    category: str
    subcategory: Optional[str]
    confidence: float


@dataclass
class CategorisationResult:
    transactions: list[CategorisedTransaction]


# ── Rise — Loans ───────────────────────────────────────────────────────────────

@dataclass
class ScheduleEntry:
    id: str
    installment_number: int
    due_date: str
    principal_due: int    # kobo
    interest_due: int     # kobo
    total_due: int        # kobo
    paid_amount: int      # kobo
    status: str           # pending | partial | paid | overdue


@dataclass
class LoanPayment:
    id: str
    amount: int
    reference: str
    channel: str
    recorded_at: str
    created_at: str


@dataclass
class Loan:
    id: str
    tenant_id: str
    customer_id: str
    product: str
    principal: int         # kobo
    interest_rate: float
    tenor_months: int
    outstanding_balance: int
    status: str            # pending | active | overdue | closed | declined | referred
    created_at: str
    updated_at: str
    eye_application_id: Optional[str] = None
    decline_reason: Optional[str] = None
    disbursed_at: Optional[str] = None
    maturity_date: Optional[str] = None
    schedule: list[ScheduleEntry] = field(default_factory=list)
    payments: list[LoanPayment] = field(default_factory=list)


# ── Nest — Accounts ───────────────────────────────────────────────────────────

@dataclass
class Account:
    id: str
    tenant_id: str
    customer_id: str
    account_number: str
    type: str
    currency: str
    status: str
    balance: int           # kobo
    created_at: str
    updated_at: str
    label: Optional[str] = None


@dataclass
class Transaction:
    id: str
    account_id: str
    type: str              # credit | debit
    amount: int            # kobo
    balance_before: int
    balance_after: int
    description: str
    reference: str
    channel: str
    created_at: str
    counterpart_account_id: Optional[str] = None


# ── Shield — Fraud ─────────────────────────────────────────────────────────────

@dataclass
class FraudAlert:
    id: str
    tenant_id: str
    customer_id: str
    rule_triggered: str
    fraud_score: float
    severity: str          # low | medium | high | critical
    action_taken: str      # allow | flag | block
    status: str            # open | resolved | false_positive
    created_at: str
    resolved_by: Optional[str] = None
    details: dict = field(default_factory=dict)


@dataclass
class BlacklistEntry:
    id: str
    identifier_type: str
    source_tenant_id: str
    confirmed_at: str
    reason: Optional[str] = None


# ── Input helpers ─────────────────────────────────────────────────────────────

@dataclass
class BureauData:
    total_accounts: int = 0
    active_loans: int = 0
    delinquent_accounts: int = 0
    total_outstanding: int = 0
    oldest_account_months: int = 0
    bureau_score: Optional[int] = None


@dataclass
class OpenBankingData:
    avg_monthly_inflow: float = 0.0
    avg_monthly_outflow: float = 0.0
    salary_detected: bool = False
    salary_amount: Optional[float] = None
    months_of_data: int = 0
    loan_repayment_detected: bool = False
    gambling_transactions: int = 0
    bounce_count: int = 0


@dataclass
class CustomerProfile:
    age: Optional[int] = None
    employment_type: Optional[str] = None
    monthly_income: Optional[float] = None
    state: Optional[str] = None
