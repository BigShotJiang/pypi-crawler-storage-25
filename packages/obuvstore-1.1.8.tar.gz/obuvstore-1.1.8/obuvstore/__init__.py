"""
obuvstore/__init__.py
Запускается автоматически при любом: import obuvstore
"""
import os
import sys


def _get_sql_path() -> str:
    """Путь к SQL-файлу внутри пакета — всегда относительно __init__.py"""
    current = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(current, "data", "obuvstore_full.sql")


def _ensure_resource_dirs():
    res = os.path.join(os.getcwd(), "resources")
    os.makedirs(res, exist_ok=True)


def _export_sql():
    """Копирует встроенный SQL в корень проекта."""
    src = _get_sql_path()
    dst = os.path.join(os.getcwd(), "obuvstore_schema.sql")
    if not os.path.exists(dst):
        import shutil
        shutil.copy(src, dst)
        print(f"[obuvstore] SQL-схема скопирована → {dst}")
    else:
        print(f"[obuvstore] SQL-схема уже существует: {dst}")


def _apply_db():
    """Подключается к MySQL и применяет схему."""
    try:
        from obuvstore.database.connection import get_connection
        conn = get_connection()
        sql_path = _get_sql_path()
        with open(sql_path, encoding="utf-8") as f:
            raw = f.read()
        cursor = conn.cursor()
        for stmt in raw.split(";"):
            s = stmt.strip()
            if s:
                try:
                    cursor.execute(s)
                except Exception:
                    pass
        conn.commit()
        cursor.close()
        print("[obuvstore] ✅ База данных готова.")
    except Exception as e:
        print(
            f"\n[obuvstore] ⚠️  БД недоступна: {e}\n"
            "  1. Открой obuvstore/config.py\n"
            "  2. Установи DB_HOST, DB_USER, DB_PASSWORD\n"
            "  3. Запусти снова — всё применится автоматически\n"
            "  Или импортируй obuvstore_schema.sql вручную в MySQL Workbench\n"
        )


# ── Выполняется при: import obuvstore ────────────────────────
_ensure_resource_dirs()
_export_sql()
_apply_db()

# ── Публичный API ─────────────────────────────────────────────
from obuvstore.ui.styles      import get_app_stylesheet   # noqa
from obuvstore.ui.login       import LoginDialog           # noqa
from obuvstore.ui.main_window import MainWindow            # noqa


def run_app():
    from PyQt5.QtWidgets import QApplication
    app = QApplication(sys.argv)
    app.setStyleSheet(get_app_stylesheet())

    current_user = {}

    login = LoginDialog()
    login.login_success.connect(lambda u: current_user.update(u))
    login.guest_mode.connect(lambda: current_user.update({"role_name": "Гость"}))
    login.exec_()

    if not current_user:
        sys.exit(0)

    window = MainWindow(user=current_user if current_user.get("user_id") else None)
    window.show()
    sys.exit(app.exec_())
