Ancillary Functions
-------------------

.. automodule:: cesard.ancillary
    :members:
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        buffer_min_overlap
        buffer_time
        check_scene_consistency
        check_spacing
        combine_polygons
        compute_hash
        datamask
        date_to_utc
        defaultdict_to_dict
        generate_unique_id
        get_kml
        get_max_ext
        get_tmp_name
        group_by_attr
        group_by_time
        pixel_size_degrees
        vrt_add_overviews