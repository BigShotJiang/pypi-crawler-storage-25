import cloudscraper
from bs4 import BeautifulSoup
import json, os, re, requests, ssl, shutil, tarfile, time
from requests.adapters import HTTPAdapter

CHROME_CIPHER_SUITES = [
    'ECDHE-ECDSA-AES128-GCM-SHA256','ECDHE-RSA-AES128-GCM-SHA256',
    'ECDHE-ECDSA-AES256-GCM-SHA384','ECDHE-RSA-AES256-GCM-SHA384',
    'ECDHE-ECDSA-CHACHA20-POLY1305','ECDHE-RSA-CHACHA20-POLY1305'
]

class CipherAdapter(HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
        context.set_ciphers(':'.join(CHROME_CIPHER_SUITES))
        kwargs['ssl_context'] = context
        return super(CipherAdapter, self).init_poolmanager(*args, **kwargs)

class SpyAgent:
    def __init__(self):
        self.scraper = cloudscraper.create_scraper(browser={'browser': 'chrome', 'platform': 'android', 'desktop': False})
        self.scraper.mount("https://", CipherAdapter())
        self.patterns = {
            "Secrets": r"(?i)(token|auth|config|secret|key|admin|password|access_token|client_id|aws_|firebase|s3_)[^=]{0,20}[:=]\s*['\"\`]([a-zA-Z0-9\-_=\.\/\+]{8,})['\"`]",
            "Endpoints": r"['\"`](/(?:api|v\d|auth|config|admin|graphql|rest|user|account|payment)/[\w\-\._~%?#&=/]*)['\"`]"
        }

    def print_banner(self):
        os.system("clear")
        print("\033[1;36m.---.\n/     \\\n| () () |  AGENT\n \\  ^  /   JS-MINER\n  |||||\n--- DARK VISION V5.3.2 ---\n   [ STORAGE ENABLED ]\033[0m\n")

    def archive_and_move(self, base_dir, domain):
        archive_name = f"{domain}.tar.gz"
        try:
            with tarfile.open(archive_name, "w:gz") as tar:
                tar.add(base_dir, arcname=os.path.basename(base_dir))
            dest = f"/sdcard/Download/{archive_name}"
            if os.path.exists("/sdcard"):
                shutil.move(archive_name, dest)
                print(f"\033[1;32m✅ Master Loot Moved: Internal Storage/Download/{archive_name}\033[0m")
                shutil.rmtree(base_dir)
        except Exception as e: print(f"❌ Archive Error: {e}")

    def run(self):
        self.print_banner()
        target = input("🎯 TARGET URL: ").strip()
        if not target: return
        if not target.startswith(('http://', 'https://')): target = 'https://' + target
        domain = target.replace('https://','').replace('http://','').split('/')[0]
        base_dir = f"scan_{domain}"
        for d in [f"{base_dir}/js_files", f"{base_dir}/other_assets"]:
            if not os.path.exists(d): os.makedirs(d)

        try:
            res = self.scraper.get(target, timeout=15)
            soup = BeautifulSoup(res.text, 'html.parser')
            assets = list(set([s['src'] for s in soup.find_all('script', src=True)] + [l['href'] for l in soup.find_all('link', href=True)]))
            print(f"📦 Harvesting {len(assets)} Assets...")
            # Intel collection logic would go here
            print(f"\n\033[1;32m[✅] SCANNED SUCCESSFULLY!")
            self.archive_and_move(base_dir, domain)
        except Exception as e: print(f"❌ Error: {e}")

def run_mission():
    SpyAgent().run()
