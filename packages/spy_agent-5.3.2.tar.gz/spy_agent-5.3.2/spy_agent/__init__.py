"""Spy-Agent: Advanced JS Miner"""
__version__ = "5.3.2"
from .main import SpyAgent, run_mission
