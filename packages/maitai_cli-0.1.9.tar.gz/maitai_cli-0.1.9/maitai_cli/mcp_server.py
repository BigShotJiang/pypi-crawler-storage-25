"""Maitai Platform MCP Server.

Wraps the Maitai Developer API (api/v1) as MCP tools so Cursor (and other
MCP-compatible clients) can manage Maitai resources directly.
"""

import json
import sys
from pathlib import Path
from typing import Any

_cli_root = str(Path(__file__).resolve().parent.parent)
if _cli_root not in sys.path:
    sys.path.insert(0, _cli_root)

from maitai_cli.api import APIClient, APIError
from mcp.server.fastmcp import FastMCP

server = FastMCP(
    "maitai",
    instructions=(
        "Maitai Platform API — manage LLM applications, agents, intents, "
        "models, datasets, test sets, workflow test sets, sentinels, analytics, and more. "
        "Base URL: https://api.trymaitai.ai/api/v1"
    ),
)

RESOURCES = sorted(
    [
        "agents",
        "analytics",
        "applications",
        "compass",
        "conversation-trees",
        "continuous-learning",
        "datasets",
        "drift",
        "evaluation-criteria",
        "evaluations",
        "finetune-runs",
        "intent-groups",
        "models",
        "requests",
        "reports",
        "routing",
        "sentinels",
        "sessions",
        "tags",
        "test-runs",
        "test-sets",
        "workflow-test-runs",
        "workflow-test-sets",
        "workflows",
    ]
)

_RESOURCE_CSV = ", ".join(RESOURCES)


def _client() -> APIClient:
    return APIClient()


def _fmt(data: Any) -> str:
    return json.dumps(data, indent=2, default=str)


def _validate(resource: str) -> None:
    if resource not in RESOURCES:
        raise ValueError(
            f"Unknown resource '{resource}'. Must be one of: {_RESOURCE_CSV}"
        )


@server.tool()
def maitai_list(resource: str, params: dict[str, Any] | None = None) -> str:
    """List Maitai platform resources with optional query-parameter filters.

    Args:
        resource: One of — agents, analytics, applications, compass,
            continuous-learning, conversation-trees, datasets, drift,
            evaluation-criteria, evaluations, finetune-runs, intent-groups,
            models, requests, reports, routing, sentinels, sessions, tags,
            test-runs, test-sets, workflow-test-runs, workflow-test-sets,
            workflows.
        params: Optional query parameters. Common filters by resource:
            agents        — detailed, include_subagents, include_actions, page, page_size, version
            analytics     — date range filters supported by specific endpoints
            applications  — detailed
            continuous-learning — model_id, status, intent_group_id
            conversation-trees — application_id
            evaluation-criteria — application_id, intent_group_id
            evaluations   — full
            finetune-runs — status
            intent-groups — detailed, start_date, end_date, include_messages
            models        — model_type
            requests      — application_id, intent_id, start_date, end_date, include_messages
            reports       — offset, limit
            sessions      — application_id
            tags          — application_id, intent_group_id, status
            test-runs     — intent_group_id
            test-sets     — start_date, end_date
            workflow-test-runs — test_set_id
            workflow-test-sets — application_id, workflow_id
            workflows     — application_id, workflow_id
    """
    _validate(resource)
    try:
        return _fmt(_client().get(f"/{resource}", params=params))
    except APIError as e:
        return f"Error ({e.status_code}): {e.message}"


@server.tool()
def maitai_get(
    resource: str, resource_id: str, params: dict[str, Any] | None = None
) -> str:
    """Get a single Maitai resource by ID.

    Args:
        resource: Resource type (same values as maitai_list).
        resource_id: The numeric or string ID of the resource.
        params: Optional query parameters (e.g. {"detailed": true}).
    """
    _validate(resource)
    try:
        return _fmt(_client().get(f"/{resource}/{resource_id}", params=params))
    except APIError as e:
        return f"Error ({e.status_code}): {e.message}"


@server.tool()
def maitai_create(resource: str, body: dict[str, Any]) -> str:
    """Create a new Maitai resource.

    Supported for: agents, applications, compass, datasets,
    evaluation-criteria, evaluations, finetune-runs, sentinels, tags,
    test-runs, test-sets, workflow-test-runs, workflow-test-sets, workflows.

    Args:
        resource: Resource type to create.
        body: JSON object with the fields for the new resource.
    """
    _validate(resource)
    try:
        return _fmt(_client().post(f"/{resource}", json=body))
    except APIError as e:
        return f"Error ({e.status_code}): {e.message}"


@server.tool()
def maitai_update(resource: str, resource_id: str, body: dict[str, Any]) -> str:
    """Update an existing Maitai resource by ID.

    Supported for: agents, applications, datasets, evaluation-criteria,
    sentinels, tags, test-sets, workflow-test-sets, workflows.

    Args:
        resource: Resource type to update.
        resource_id: The ID of the resource.
        body: JSON object with the fields to update.
    """
    _validate(resource)
    try:
        return _fmt(_client().put(f"/{resource}/{resource_id}", json=body))
    except APIError as e:
        return f"Error ({e.status_code}): {e.message}"


@server.tool()
def maitai_delete(resource: str, resource_id: str) -> str:
    """Delete a Maitai resource by ID.

    Supported for: agents, applications, compass, conversation-trees,
    datasets, evaluation-criteria, sentinels, tags, test-runs, test-sets,
    workflow-test-runs, workflow-test-sets, workflows.

    Args:
        resource: Resource type to delete.
        resource_id: The ID of the resource.
    """
    _validate(resource)
    try:
        result = _client().delete(f"/{resource}/{resource_id}")
        return _fmt(result) if result else "Deleted successfully."
    except APIError as e:
        return f"Error ({e.status_code}): {e.message}"


@server.tool()
def maitai_api(method: str, path: str, body: dict[str, Any] | None = None) -> str:
    """Make a raw API request to the Maitai Developer API.

    Use for endpoints not covered by the CRUD tools, for example:
      GET  /models/available   — list available base models
      POST /evaluations        — start an evaluation run

    Args:
        method: HTTP method — GET, POST, PUT, or DELETE.
        path: API path relative to base URL (e.g. "/models/available").
        body: Optional JSON body for POST/PUT requests.
    """
    client = _client()
    path = path if path.startswith("/") else f"/{path}"
    m = method.upper()
    try:
        if m == "GET":
            return _fmt(client.get(path))
        elif m == "POST":
            return _fmt(client.post(path, json=body))
        elif m == "PUT":
            return _fmt(client.put(path, json=body))
        elif m == "DELETE":
            return _fmt(client.delete(path))
        else:
            return f"Unsupported method '{method}'. Use GET, POST, PUT, or DELETE."
    except APIError as e:
        return f"Error ({e.status_code}): {e.message}"


@server.tool()
def maitai_whoami() -> str:
    """Check current Maitai authentication status and API configuration."""
    from maitai_cli.config import get_api_key, get_base_url

    key = get_api_key()
    base_url = get_base_url()
    if not key:
        return "Not authenticated. Set MAITAI_API_KEY or run maitai_cli login."
    return json.dumps(
        {
            "authenticated": True,
            "base_url": base_url,
            "api_key_preview": f"{key[:8]}...{key[-4:]}",
        },
        indent=2,
    )


def main():
    """Entry point for the MCP server (stdio transport)."""
    server.run()


if __name__ == "__main__":
    main()
