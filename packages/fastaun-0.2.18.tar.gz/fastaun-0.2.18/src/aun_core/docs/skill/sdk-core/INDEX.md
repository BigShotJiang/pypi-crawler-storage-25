# AUN SDK 文档索引

> 渐进式三层结构。Layer 1 极简地图，总是加载；Layer 2 概念交叉索引，按主题查找时加载；Layer 3 每篇文档的详细摘要，需要深入时加载。

---

## Layer 1：文档地图

| 文档 | 说明 |
|------|------|
| [01-快速开始](01-快速开始.md) | 最小示例 · 安装 · 配置 · 核心流程 |
| [02-WebSocket协议](02-WebSocket协议.md) | 握手流程 · 消息格式 · 裸 WebSocket 示例 |
| [03-核心概念](03-核心概念.md) | AID · 连接状态机 · 认证流程 · E2EE |
| [04-连接与认证](04-连接与认证.md) | 创建AID · 连接网关 · 网关发现 · 调用RPC · 事件订阅 |
| [05-E2EE加密通信](05-E2EE加密通信.md) | E2EE加密消息 · ProtectedHeaders · 会话管理 · 自定义密钥存储 |
| [06-API手册](06-API手册.md) | AUNClient · AuthNamespace · MetaNamespace（信任根列表 / issuer root 更新） · E2EEManager · 内置事件 · RPC手册索引 |
| [07-错误处理](07-错误处理.md) | 错误类层级 · 错误码速查 · 重试策略 |
| [08-最佳实践](08-最佳实践.md) | 幂等初始化 · 多AID隔离 · 环境变量 · 资源清理 |

### RPC 手册

| 文档 | 说明 |
|------|------|
| [消息Payload参考约定](消息Payload参考约定.md) | `message.send` / `group.send` 共用业务负载格式 · `payload.type` 类型总览 · 附件引用 |
| [group-rpc-manual](group-rpc-manual.md) | Group 服务 RPC 接口 · 群组创建/加入/成员管理/消息收发 · `payload.type` 负载类型 |
| [message-rpc-manual](message-rpc-manual.md) | Message 服务 RPC 接口 · 点对点消息发送/拉取/确认 · `payload.type` 负载类型 |
| [meta-rpc-manual](meta-rpc-manual.md) | Meta 服务 RPC 接口 · ping/status/信任根列表与 PKI 下载端点 |
| [storage-rpc-manual](storage-rpc-manual.md) | Storage 服务 RPC 接口 · 文件上传/下载/对象管理 |
| [stream-rpc-manual](stream-rpc-manual.md) | Stream 服务 RPC 接口 · 流式数据传输 |

---

## Layer 2：概念交叉索引

### 身份与认证
- **AID 格式与结构** → [03-核心概念](03-核心概念.md)
- **创建 AID** → [04-连接与认证](04-连接与认证.md) · [06-API手册](06-API手册.md)
- **认证流程（挑战-应答）** → [03-核心概念](03-核心概念.md)
- **认证失败处理** → [07-错误处理](07-错误处理.md)

### 连接与协议
- **WebSocket 握手协议** → [02-WebSocket协议](02-WebSocket协议.md)
- **状态机（4 状态）** → [03-核心概念](03-核心概念.md)
- **连接网关** → [04-连接与认证](04-连接与认证.md)
- **网关自动发现** → [04-连接与认证](04-连接与认证.md)
- **连接状态事件** → [06-API手册](06-API手册.md)

### E2EE 端到端加密
- **E2EE 机制概述** → [03-核心概念](03-核心概念.md)
- **加密消息收发** → [05-E2EE加密通信](05-E2EE加密通信.md)
- **会话管理** → [05-E2EE加密通信](05-E2EE加密通信.md)
- **E2EEManager API** → [06-API手册](06-API手册.md)
- **E2EE 错误类** → [07-错误处理](07-错误处理.md)
- **E2EE 幂等运行** → [08-最佳实践](08-最佳实践.md)

### RPC 调用与事件
- **`client.call()` 模式** → [04-连接与认证](04-连接与认证.md)
- **`client.on()` 事件订阅** → [04-连接与认证](04-连接与认证.md)
- **裸 WebSocket RPC 调用** → [02-WebSocket协议](02-WebSocket协议.md)
- **内置事件列表** → [06-API手册](06-API手册.md)
- **RPC 手册索引** → [06-API手册](06-API手册.md)
- **消息 payload 类型总览与格式约定** → [消息Payload参考约定](消息Payload参考约定.md)
- **Group RPC 与群消息收发** → [group-rpc-manual](group-rpc-manual.md)
- **Message RPC 与 P2P 消息收发** → [message-rpc-manual](message-rpc-manual.md)
- **Meta RPC** → [meta-rpc-manual](meta-rpc-manual.md)
- **Storage RPC** → [storage-rpc-manual](storage-rpc-manual.md)
- **Stream RPC** → [stream-rpc-manual](stream-rpc-manual.md)

### 配置与存储
- **构造参数** → [01-快速开始](01-快速开始.md)
- **数据目录布局** → [01-快速开始](01-快速开始.md)
- **自定义 KeyStore** → [05-E2EE加密通信](05-E2EE加密通信.md)
- **自定义 SecretStore** → [05-E2EE加密通信](05-E2EE加密通信.md)
- **多 AID 隔离** → [08-最佳实践](08-最佳实践.md)
- **环境变量配置** → [08-最佳实践](08-最佳实践.md)

### 错误处理
- **错误类层级** → [07-错误处理](07-错误处理.md)
- **错误码对照表** → [07-错误处理](07-错误处理.md)
- **重试策略** → [07-错误处理](07-错误处理.md)

---

## Layer 3：文档详细摘要

### 01-快速开始
入门文档。双客户端最小可运行示例（创建 AID → 认证 → 连接 → 消息收发 → 关闭），pip 安装命令，AUNClient 构造参数，数据目录布局。

### 02-WebSocket协议
底层协议细节。连接握手流程（challenge → auth.connect → hello-ok），消息格式（RPC 请求/响应/事件通知），裸 WebSocket 完整示例。适合在其他语言中实现客户端。

### 03-核心概念
SDK 的核心抽象。AID 域名格式身份及本地密钥对管理；连接状态机及自动重连；认证流程（挑战-应答）；E2EE 两级离线加密流程。

### 04-连接与认证
SDK 高层封装。`create_aid` + `authenticate` 认证流程；`connect` 参数（含自动重连、心跳、令牌刷新）；`client.call()` RPC 调用模式；`client.on()` 事件订阅。

### 05-E2EE加密通信
E2EE 完整收发流程（加密发送 + 监听解密 + 后台消息循环）；`protected_headers` 与可验证 `context` 元数据；密钥管理（prekey 缓存 / replay guard / group epoch）；自定义 `KeyStore` / `SecretStore` Protocol。

### 06-API手册
完整 API 文档。AUNClient 构造函数/属性/方法；AuthNamespace 方法；E2EEManager 方法；内置事件列表；RPC 手册索引。

### 07-错误处理
`AUNError` 基类及子类层级；错误属性；错误码速查表；指数退避重试策略；常见错误场景。

### 08-最佳实践
幂等连接初始化；安全关闭；E2EE 幂等运行；多 AID 隔离；环境变量驱动配置；资源清理。

### 消息Payload参考约定
`message.send` 和 `group.send` 共用的业务 payload 约定。包含 `payload.type` 类型总览、信封字段边界、公共辅助字段、提及语义、各类型字段格式、附件引用规范和降级处理建议。
