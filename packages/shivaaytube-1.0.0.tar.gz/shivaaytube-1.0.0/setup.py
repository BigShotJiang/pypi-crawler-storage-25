from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="shivaaytube",
    version="1.0.0",
    author="Shivaay20005",
    author_email="shivaay20005@gmail.com", # Isse badal dena
    description="A powerful YouTube search and high-quality download library",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Shivaay20005/Shivaay_Extract_Tube",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
    install_requires=[
        "requests>=2.31.0",
        "typing_extensions>=4.0.0",
        "yt-dlp>=2025.1.15",
        "mutagen>=1.47.0",
        "colorama>=0.4.6",
        "pyfiglet>=1.0.2"
    ],
    entry_points={
        'console_scripts': [
            'shivaaytube=shivaay_extract_tube.cli:main', # Isse 'shivaaytube' command chalegi
        ],
    },
)
