# SHIVAAY EXTRACT TUBE

![Shivaay Extract Tube](Shivaay_extract_tube.png)

Welcome to **Shivaay Extract Tube**, the ultimate lightweight tool to extract data and download media from YouTube without needing official APIs or heavy automation.

**Developed by:** [Shivaay](https://github.com/Shivaay20005)  
**Repository:** [Shivaay_Extract_Tube](https://github.com/Shivaay20005/Shivaay_Extract_Tube)

---

## 🚀 Features

This repository is packed with capabilities:

### 1. 🎥 Media Downloader (`downloader.py`)

A robust command-line tool to searching and downloading content.

- **Search & Download**: Search for any keyword (e.g., "New Haryanvi Songs").
- **Channel Grabber**: Download the latest videos from any specific YouTube Channel.
- **Audio/Video Choice**: Choose between downloading just the Audio (Music) or the Full Video.
- **Smart Formats**: Automatically selects the best format that works on your PC (avoids needing FFmpeg).

### 2. 🔍 Advanced Scraping Library (`shivaay_extract_tube/`)

A high-speed scraping module that powers the downloader.

- **No API Keys Needed**: Works out of the box.
- **Get Channel Videos**: Fetch every single video ID from a channel.
- **Get Playlists**: Extract all videos from a playlist URL.
- **Search**: Perform YouTube searches programmatically.
- **Shorts & Streams**: Can specifically target Shorts or Live Streams.

---

## 🛠️ Installation

1.  **Install Python** (if not already installed).
2.  **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```
    _(This installs `requests`, `typing_extensions`, and `yt-dlp`)_

---

## ⚡ How to Run

### To Download Videos/Music:

Simply run the interactive downloader script:

```bash
py downloader.py
```

### To Run the GUI App:

```bash
py gui_app.py
```

Follow the on-screen prompts to search for videos or paste a Channel ID.

---

## 📚 Using as a Python Library

**Shivaay Extract Tube** is designed to be easily integrated into other projects.

### 📦 Installation
If you want to use it in other projects on your PC, install it in editable mode:
```bash
py -m pip install -e .
```

### 💻 Code Example
```python
import shivaay_extract_tube

# 1. Get videos from a specific Channel
print("--- Channel Videos ---")
videos = shivaay_extract_tube.get_channel(channel_username="ShivaayDeveloper", limit=5)
for v in videos:
    title = v['title']['runs'][0]['text']
    print(f"ID: {v['videoId']} | Title: {title}")

# 2. Search for videos
print("\n--- Search Results ---")
search_results = shivaay_extract_tube.get_search("Python Tutorial", limit=3)
for result in search_results:
    print(f"Found: {result['title']['runs'][0]['text']}")
```

---

## 📂 Project Structure

- `downloader.py` - The main user-friendly tool for downloading.
- `prepare_icon.py` - The main user-friendly tool for downloading.
- `shivaay_extract_tube/` - The core folder containing the scraping logic.
- `requirements.txt` - List of required Python packages.
- `README.md` - This file.

---

## 📦 Building Standalone App (.exe)

To create a portable `.exe` file that you can share with friends (no Python required for them):

1.  Double-click **`BUILD_EXE.bat`**.
2.  Wait for the process to finish (it installs dependencies and compiles the code).
3.  Your app will be ready in the **`dist/`** folder named **`ShivaayTube.exe`**.
    - You can copy/paste this `.exe` file anywhere or send it to another PC.

---

## ⚠️ Disclaimer

This tool is for educational purposes only. Please respect YouTube's Terms of Service and Copyright laws when downloading content.
