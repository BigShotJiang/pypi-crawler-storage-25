import os
import yt_dlp
from .shivaay_extract_tube import get_video

def download(video_url_or_id: str, is_audio: bool = False, output_path: str = "downloads", quality: str = "720p"):
    """
    Powerful download function shared by CLI and Library users.
    """
    if not os.path.exists(output_path):
        os.makedirs(output_path)

    # Resolution mapping
    if is_audio:
        format_opt = 'bestaudio/best'
    else:
        if quality == "360p": format_opt = '18/best'
        elif quality == "1080p": format_opt = 'bestvideo[height<=1080]+bestaudio/best'
        else: format_opt = '22/18/best[protocol^=http][ext=mp4]/best'

    opts = {
        'format': format_opt,
        'outtmpl': f'{output_path}/%(title)s.%(ext)s',
        'quiet': True,
        'no_warnings': True,
        'nocheckcertificate': True,
        'extractor_args': {
            'youtube': {
                'player_client': ['android', 'web_creator'],
                'skip': ['hls', 'dash']
            }
        }
    }

    final_path = [None]
    def hook(d):
        if d['status'] == 'finished': final_path[0] = d.get('filename')
    opts['progress_hooks'] = [hook]

    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([video_url_or_id if "youtube.com" in video_url_or_id else f"https://youtube.com/watch?v={video_url_or_id}"])
    
    # Apply Tags (Internal)
    if is_audio and final_path[0]:
        _apply_tags(final_path[0])
    
    return final_path[0]

def _apply_tags(file_path):
    try:
        from mutagen.mp3 import MP3
        from mutagen.mp4 import MP4
        ext = file_path.split('.')[-1].lower()
        if ext == "mp3":
            audio = MP3(file_path)
            audio.save() # Placeholder for simple save, can be expanded
        elif ext == "m4a":
            audio = MP4(file_path)
            audio.save()
    except: pass
