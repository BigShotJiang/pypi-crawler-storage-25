import sys
import os
import time
from .shivaay_extract_tube import get_search, get_channel, get_playlist
from .downloader import download

# Fix Windows Terminal Encoding for Emojis
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except: pass

# Import aesthetics libraries
try:
    from colorama import init, Fore, Style
    import pyfiglet
except ImportError:
    class Fore: CYAN = MAGENTA = GREEN = YELLOW = RED = RESET = BLUE = WHITE = ""
    class Style: BRIGHT = RESET_ALL = NORMAL = ""
    def init(autoreset=True): pass
    class pyfiglet:
        @staticmethod
        def figlet_format(text, **kwargs): return text

# Initialize Colorama
init(autoreset=True)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_banner():
    clear_screen()
    try:
        ascii_art = pyfiglet.figlet_format("ShivaayTube", font="slant")
    except:
        ascii_art = r"""
   _____ __    _                         ______      __          
  / ___// /_  (_)__________  ____ ___  _/_  __/_  __/ /_  ___    
  \__ \/ __ \/ / ___/ __  / __ `/ __ \/ / / / / / / __ \/ _ \   
 ___/ / / / / / /__/ /_/ / /_/ / /_/ / / / / / /_/ / /_/ /  __/   
/____/_/ /_/_/\___/\__,_/\__,_/\__, / /_/  \__,_/_.___/\___/    
                              /____/                             
"""
    print(Fore.RED + Style.BRIGHT + ascii_art)
    print(Fore.WHITE + Style.BRIGHT + "    >>> ShivaayTube - Ultimate YouTube Downloader <<<    ")
    print(Fore.RED + "    " + "="*56 + "\n" + Style.RESET_ALL)

def get_video_info_str(video_data):
    title = video_data.get('title', {}).get('runs', [{}])[0].get('text', 'Unknown')
    duration = video_data.get('lengthText', {}).get('simpleText', 'N/A')
    return title, duration

def main():
    while True:
        print_banner()
        print(Fore.YELLOW + "  [1] 🔍 Search and Download")
        print(Fore.YELLOW + "  [2] 📺 Channel Videos")
        print(Fore.YELLOW + "  [3] 📑 Playlist Videos")
        print(Fore.RED    + "  [0] 🚪 Exit")
        
        try:
            choice = input(Fore.CYAN + Style.BRIGHT + "\n Option > " + Style.RESET_ALL).strip()
        except EOFError: break
        
        videos = []
        
        if choice == '1':
            query = input(Fore.GREEN + "Search: ")
            print(Fore.YELLOW + "[*] Searching...")
            videos = list(get_search(query, limit=15))
        elif choice == '2':
            cid = input(Fore.GREEN + "Channel ID / URL: ")
            print(Fore.YELLOW + "[*] Fetching channel...")
            videos = list(get_channel(cid, limit=15))
        elif choice == '3':
            pid = input(Fore.GREEN + "Playlist ID / URL: ")
            print(Fore.YELLOW + "[*] Fetching playlist...")
            videos = list(get_playlist(pid, limit=15))
        elif choice == '0': sys.exit()
        else: continue

        if not videos:
            print(Fore.RED + "No results found.")
            time.sleep(2); continue

        # List Results
        print_banner()
        print(f"{Fore.MAGENTA}FOUND {len(videos)} VIDEOS:")
        for i, v in enumerate(videos):
            t, d = get_video_info_str(v)
            print(f"{Fore.YELLOW}[{i+1}] {t} ({d})")
        
        sel = input(Fore.CYAN + "\nSelect Number (or 'all' / 'b' for back): ").strip().lower()
        if sel == 'b': continue
        
        print(f"\n{Fore.YELLOW}╔══════════════════════╗")
        print(f"{Fore.YELLOW}║  [1] 🎬 Video (MP4)  ║")
        print(f"{Fore.YELLOW}║  [2] 🎵 Audio (MP3)  ║")
        print(f"{Fore.YELLOW}╚══════════════════════╝")
        fmt = input(Fore.CYAN + "Format > " + Style.RESET_ALL).strip()
        is_audio = fmt == '2'
        dl_type = "🎵 AUDIO" if is_audio else "🎬 VIDEO"
        print(Fore.MAGENTA + f"[Mode: {dl_type}]")

        try:
            if sel == 'all':
                to_dl = videos
            else:
                indices = [int(x.strip()) - 1 for x in sel.split(',')]
                to_dl = [videos[i] for i in indices if 0 <= i < len(videos)]
        except:
            print(Fore.RED + "Invalid selection.")
            time.sleep(1); continue

        for i, v in enumerate(to_dl):
            t, _ = get_video_info_str(v)
            print(Fore.CYAN + f"\n[*] Downloading {i+1}/{len(to_dl)} as {dl_type}: {t}...")
            try:
                path = download(v['videoId'], is_audio=is_audio)
                ext = os.path.splitext(path)[1].upper() if path else ""
                print(Fore.GREEN + f"[✔] Done! Saved as {dl_type}: {os.path.basename(path)} {ext}")
            except Exception as e:
                print(Fore.RED + f"[✘] Error: {e}")
        
        input(Fore.YELLOW + "\nPress Enter to continue...")

if __name__ == "__main__":
    main()
