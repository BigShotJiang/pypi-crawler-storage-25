from __future__ import annotations

from dataclasses import dataclass
import json
from math import sqrt
from pathlib import Path
from typing import Sequence

from physicsos.schemas.common import ArtifactRef
from physicsos.schemas.taps import SeparatedOperatorIR, SeparatedOperatorTermIR, TAPSAxisSpec


Matrix = list[list[float]]


@dataclass(frozen=True)
class SeparatedFieldTerm:
    weight: float
    factors: dict[str, list[float]]


@dataclass(frozen=True)
class SeparatedFieldSample:
    coordinates: dict[str, float]
    nearest_node_indices: dict[str, int]
    value: float


@dataclass(frozen=True)
class SeparatedFieldState:
    axes: list[TAPSAxisSpec]
    terms: list[SeparatedFieldTerm]

    @property
    def rank(self) -> int:
        return len(self.terms)

    def evaluate_at_node_indices(self, node_indices: dict[str, int]) -> float:
        value = 0.0
        for term in self.terms:
            product = term.weight
            for axis in self.axes:
                axis_values = term.factors[axis.name]
                product *= axis_values[node_indices[axis.name]]
            value += product
        return value

    def sample_nearest(self, coordinates: dict[str, float], axis_nodes: dict[str, Sequence[float]]) -> SeparatedFieldSample:
        indices = {axis.name: _nearest_index(axis_nodes[axis.name], coordinates[axis.name]) for axis in self.axes}
        return SeparatedFieldSample(coordinates=dict(coordinates), nearest_node_indices=indices, value=self.evaluate_at_node_indices(indices))


@dataclass(frozen=True)
class SubspaceLinearSystemContribution:
    term_id: str
    formulation_term_id: str
    role: str
    target: str
    scale: float
    axis_operator: str


@dataclass(frozen=True)
class SubspaceLinearSystem:
    axis_name: str
    lhs: Matrix
    rhs: list[float]
    contributions: list[SubspaceLinearSystemContribution]


@dataclass(frozen=True)
class EssentialAxisConstraint:
    axis_name: str
    node_index: int
    value: float


@dataclass(frozen=True)
class SubspaceIterationStep:
    iteration: int
    axis_name: str
    residual_norm: float
    update_norm: float
    converged: bool


@dataclass(frozen=True)
class SubspaceIterationResult:
    axis_name: str
    node_values: list[float]
    residual_norm: float
    converged: bool
    iteration_history: list[SubspaceIterationStep]
    linear_system: SubspaceLinearSystem
    constraints_applied: list[EssentialAxisConstraint]


@dataclass(frozen=True)
class SubspaceALSResult:
    field_state: SeparatedFieldState
    residual_norm: float
    converged: bool
    iteration_history: list[SubspaceIterationStep]
    axis_systems: list[SubspaceLinearSystem]
    constraints_applied: list[EssentialAxisConstraint]
    dense_residual_size: int


@dataclass(frozen=True)
class RankEnrichmentDiagnostic:
    rank: int
    residual_norm: float
    relative_residual_reduction: float
    update_norm: float
    converged: bool


@dataclass(frozen=True)
class SubspaceEnrichmentResult:
    field_state: SeparatedFieldState
    residual_norm: float
    converged: bool
    rank_diagnostics: list[RankEnrichmentDiagnostic]
    iteration_history: list[SubspaceIterationStep]
    axis_systems: list[SubspaceLinearSystem]
    constraints_applied: list[EssentialAxisConstraint]
    dense_residual_size: int


@dataclass(frozen=True)
class NonlinearIterationDiagnostic:
    iteration: int
    method: str
    residual_norm: float
    update_norm: float
    converged: bool


@dataclass(frozen=True)
class NonlinearSolveResult:
    field_state: SeparatedFieldState
    residual_norm: float
    converged: bool
    nonlinear_history: list[NonlinearIterationDiagnostic]
    linear_results: list[SubspaceEnrichmentResult]


@dataclass(frozen=True)
class TimeSlabSpec:
    index: int
    start: float
    end: float


@dataclass(frozen=True)
class TimeSlabResult:
    slab: TimeSlabSpec
    result: SubspaceEnrichmentResult
    initial_state: SeparatedFieldState | None


@dataclass(frozen=True)
class SlabContinuationResult:
    slabs: list[TimeSlabResult]
    final_state: SeparatedFieldState
    converged: bool


@dataclass(frozen=True)
class BaselineSample:
    node_indices: dict[str, int]
    value: float


@dataclass(frozen=True)
class BaselineGateResult:
    passed: bool
    max_error: float
    rms_error: float
    sample_count: int
    tolerance: float
    errors: list[str]


class SeparatedFieldKernel:
    """Manage separated CP field factors without encoding a specific PDE."""

    def build_rank_one(self, axes: Sequence[TAPSAxisSpec], factors: dict[str, Sequence[float]], *, weight: float = 1.0) -> SeparatedFieldState:
        axis_list = list(axes)
        factor_map = _validated_factor_map(axis_list, factors)
        return SeparatedFieldState(axes=axis_list, terms=[SeparatedFieldTerm(weight=float(weight), factors=factor_map)])

    def normalize(self, state: SeparatedFieldState) -> SeparatedFieldState:
        normalized_terms: list[SeparatedFieldTerm] = []
        for term in state.terms:
            weight = term.weight
            factors: dict[str, list[float]] = {}
            for axis in state.axes:
                values = [float(value) for value in term.factors[axis.name]]
                norm = sqrt(sum(value * value for value in values))
                if norm == 0.0:
                    msg = f"Cannot normalize zero factor for axis {axis.name!r}."
                    raise ValueError(msg)
                factors[axis.name] = [value / norm for value in values]
                weight *= norm
            normalized_terms.append(SeparatedFieldTerm(weight=weight, factors=factors))
        return SeparatedFieldState(axes=state.axes, terms=normalized_terms)

    def append_rank_one(self, state: SeparatedFieldState, factors: dict[str, Sequence[float]], *, weight: float = 1.0) -> SeparatedFieldState:
        factor_map = _validated_factor_map(state.axes, factors)
        return SeparatedFieldState(axes=state.axes, terms=[*state.terms, SeparatedFieldTerm(weight=float(weight), factors=factor_map)])

    def reconstruct_dense(self, state: SeparatedFieldState) -> dict[str, object]:
        if len(state.axes) > 3:
            msg = "Dense reconstruction is only intended for diagnostics on up to three axes."
            raise ValueError(msg)
        shape = [_axis_point_count(axis) for axis in state.axes]
        values: list[float] = []
        for indices in _index_product(shape):
            values.append(state.evaluate_at_node_indices(dict(zip([axis.name for axis in state.axes], indices))))
        return {"axis_order": [axis.name for axis in state.axes], "shape": shape, "values": values}

    def combine(self, states: Sequence[SeparatedFieldState]) -> SeparatedFieldState:
        if not states:
            msg = "Cannot combine an empty list of separated field states."
            raise ValueError(msg)
        axes = states[0].axes
        axis_names = [axis.name for axis in axes]
        terms: list[SeparatedFieldTerm] = []
        for state in states:
            if [axis.name for axis in state.axes] != axis_names:
                msg = "Cannot combine separated field states with different axis order."
                raise ValueError(msg)
            terms.extend(state.terms)
        return SeparatedFieldState(axes=axes, terms=terms)

    def orthogonalize(self, state: SeparatedFieldState, *, axis_name: str | None = None, tolerance: float = 1e-12) -> SeparatedFieldState:
        if state.rank <= 1:
            return self.normalize(state)
        target_axis = axis_name or state.axes[0].name
        axes = state.axes
        orthogonal_terms: list[SeparatedFieldTerm] = []
        for term in self.normalize(state).terms:
            factors = {name: values[:] for name, values in term.factors.items()}
            vector = factors[target_axis]
            for previous in orthogonal_terms:
                basis = previous.factors[target_axis]
                projection = sum(value * basis[index] for index, value in enumerate(vector))
                vector = [value - projection * basis[index] for index, value in enumerate(vector)]
            norm = sqrt(sum(value * value for value in vector))
            if norm <= tolerance:
                continue
            factors[target_axis] = [value / norm for value in vector]
            orthogonal_terms.append(SeparatedFieldTerm(weight=term.weight * norm, factors=factors))
        if not orthogonal_terms:
            msg = f"All rank terms became linearly dependent during orthogonalization on axis {target_axis!r}."
            raise ValueError(msg)
        return SeparatedFieldState(axes=axes, terms=orthogonal_terms)


class SubspaceLinearSystemKernel:
    """Assemble one axis-local ALS linear system from separated operator terms."""

    def assemble_axis_system(
        self,
        *,
        operator_ir: SeparatedOperatorIR,
        target_axis: str,
        axis_operators: dict[str, AxisBasisOperatorSet],
        fixed_factors: dict[str, Sequence[float]],
        coefficient_values: dict[str, float] | None = None,
        geometry_factor_values: dict[str, float] | None = None,
    ) -> SubspaceLinearSystem:
        if operator_ir.status != "ready":
            msg = f"SeparatedOperatorIR must be ready before assembly, got {operator_ir.status!r}."
            raise ValueError(msg)
        if target_axis not in axis_operators:
            msg = f"Missing axis basis operators for target axis {target_axis!r}."
            raise ValueError(msg)

        target_ops = axis_operators[target_axis]
        size = len(target_ops.nodes)
        lhs = _zeros(size)
        rhs = [0.0 for _ in range(size)]
        contributions: list[SubspaceLinearSystemContribution] = []
        coefficients = coefficient_values or {}
        geometry_factors = geometry_factor_values or {}

        for term in operator_ir.terms:
            axis_operator_name = self._target_axis_operator_name(term, target_axis)
            scale = self._term_scale(
                term=term,
                target_axis=target_axis,
                axis_operators=axis_operators,
                fixed_factors=fixed_factors,
                coefficient_values=coefficients,
                geometry_factor_values=geometry_factors,
            )
            if term.role == "source" or axis_operator_name == "source":
                source = target_ops.source_vector_for_constant(scale)
                for row, value in enumerate(source):
                    rhs[row] += value
                target = "rhs"
            else:
                axis_matrix = target_ops.matrix_for(axis_operator_name)
                _add_scaled_matrix(lhs, axis_matrix, scale)
                target = "lhs"
            contributions.append(
                SubspaceLinearSystemContribution(
                    term_id=term.id,
                    formulation_term_id=term.formulation_term_id,
                    role=term.role,
                    target=target,
                    scale=scale,
                    axis_operator=axis_operator_name,
                )
            )
        return SubspaceLinearSystem(axis_name=target_axis, lhs=lhs, rhs=rhs, contributions=contributions)

    def _target_axis_operator_name(self, term: SeparatedOperatorTermIR, target_axis: str) -> str:
        matching = [block.operator for block in term.axis_blocks if block.axis_name == target_axis]
        if len(matching) > 1:
            msg = f"Term {term.id!r} has multiple blocks for target axis {target_axis!r}; combine them as separate terms."
            raise ValueError(msg)
        if matching:
            return matching[0]
        if term.role == "source":
            return "source"
        return "identity"

    def _term_scale(
        self,
        *,
        term: SeparatedOperatorTermIR,
        target_axis: str,
        axis_operators: dict[str, AxisBasisOperatorSet],
        fixed_factors: dict[str, Sequence[float]],
        coefficient_values: dict[str, float],
        geometry_factor_values: dict[str, float],
    ) -> float:
        scale = 1.0
        for coefficient_ref in _term_coefficient_refs(term):
            scale *= _required_scalar(coefficient_values, coefficient_ref, "coefficient")
        for factor_ref in _term_geometry_factor_refs(term):
            scale *= _required_scalar(geometry_factor_values, factor_ref, "geometry factor")
        for block in term.axis_blocks:
            if block.axis_name == target_axis:
                continue
            if block.axis_name not in axis_operators:
                msg = f"Missing axis basis operators for fixed axis {block.axis_name!r}."
                raise ValueError(msg)
            if block.axis_name not in fixed_factors:
                msg = f"Missing fixed factor for axis {block.axis_name!r}."
                raise ValueError(msg)
            matrix = axis_operators[block.axis_name].matrix_for(block.operator)
            factor = [float(value) for value in fixed_factors[block.axis_name]]
            if len(factor) != len(matrix):
                msg = f"Fixed factor for axis {block.axis_name!r} has length {len(factor)}, expected {len(matrix)}."
                raise ValueError(msg)
            if term.role == "source":
                scale *= _linear_form(matrix, factor)
            else:
                scale *= _quadratic_form(matrix, factor)
        return scale


class SubspaceIterationKernel:
    """Execute generic separated weak-form axis solves after IR validation."""

    def __init__(self, *, linear_system_kernel: SubspaceLinearSystemKernel | None = None) -> None:
        self.linear_system_kernel = linear_system_kernel or SubspaceLinearSystemKernel()

    def solve_single_axis(
        self,
        *,
        operator_ir: SeparatedOperatorIR,
        target_axis: str,
        axis_operators: dict[str, AxisBasisOperatorSet],
        fixed_factors: dict[str, Sequence[float]] | None = None,
        coefficient_values: dict[str, float] | None = None,
        geometry_factor_values: dict[str, float] | None = None,
        essential_constraints: Sequence[EssentialAxisConstraint] | None = None,
        tolerance: float = 1e-10,
    ) -> SubspaceIterationResult:
        system = self.linear_system_kernel.assemble_axis_system(
            operator_ir=operator_ir,
            target_axis=target_axis,
            axis_operators=axis_operators,
            fixed_factors=fixed_factors or {},
            coefficient_values=coefficient_values or {},
            geometry_factor_values=geometry_factor_values or {},
        )
        constraints = list(essential_constraints or [])
        lhs, rhs = _apply_essential_constraints(system.lhs, system.rhs, target_axis, constraints)
        node_values = _dense_solve(lhs, rhs)
        residual_norm = _constrained_residual_norm(system.lhs, system.rhs, node_values, target_axis, constraints)
        update_norm = sqrt(sum(value * value for value in node_values))
        converged = residual_norm <= tolerance
        return SubspaceIterationResult(
            axis_name=target_axis,
            node_values=node_values,
            residual_norm=residual_norm,
            converged=converged,
            iteration_history=[
                SubspaceIterationStep(
                    iteration=1,
                    axis_name=target_axis,
                    residual_norm=residual_norm,
                    update_norm=update_norm,
                    converged=converged,
                )
            ],
            linear_system=system,
            constraints_applied=constraints,
        )

    def solve_rank_one_als(
        self,
        *,
        operator_ir: SeparatedOperatorIR,
        axis_operators: dict[str, AxisBasisOperatorSet],
        coefficient_values: dict[str, float] | None = None,
        geometry_factor_values: dict[str, float] | None = None,
        essential_constraints: Sequence[EssentialAxisConstraint] | None = None,
        initial_factors: dict[str, Sequence[float]] | None = None,
        axis_order: Sequence[str] | None = None,
        damping: float = 1.0,
        max_iterations: int = 25,
        tolerance: float = 1e-8,
    ) -> SubspaceALSResult:
        if damping <= 0.0 or damping > 1.0:
            msg = "ALS damping must be in the interval (0, 1]."
            raise ValueError(msg)
        if max_iterations < 1:
            msg = "ALS max_iterations must be at least 1."
            raise ValueError(msg)
        axes = list(operator_ir.axes or [operators.axis for operators in axis_operators.values()])
        axis_names = [axis.name for axis in axes]
        order = list(axis_order or axis_names)
        unknown = sorted(set(order) - set(axis_names))
        if unknown:
            msg = f"ALS axis_order references unknown axes: {', '.join(unknown)}."
            raise ValueError(msg)
        for axis_name in axis_names:
            if axis_name not in axis_operators:
                msg = f"Missing axis basis operators for axis {axis_name!r}."
                raise ValueError(msg)

        factors = self._initial_factor_map(axes, axis_operators, initial_factors)
        constraints = list(essential_constraints or [])
        history: list[SubspaceIterationStep] = []
        axis_systems: list[SubspaceLinearSystem] = []
        residual_norm = float("inf")
        converged = False

        for iteration in range(1, max_iterations + 1):
            max_update = 0.0
            for axis_name in order:
                old = factors[axis_name]
                solved = self.solve_single_axis(
                    operator_ir=operator_ir,
                    target_axis=axis_name,
                    axis_operators=axis_operators,
                    fixed_factors={name: values for name, values in factors.items() if name != axis_name},
                    coefficient_values=coefficient_values,
                    geometry_factor_values=geometry_factor_values,
                    essential_constraints=constraints,
                    tolerance=tolerance,
                )
                updated = [(1.0 - damping) * old_value + damping * new_value for old_value, new_value in zip(old, solved.node_values)]
                factors[axis_name] = updated
                update_norm = sqrt(sum((new_value - old_value) ** 2 for old_value, new_value in zip(old, updated)))
                max_update = max(max_update, update_norm)
                axis_systems.append(solved.linear_system)
                history.append(
                    SubspaceIterationStep(
                        iteration=iteration,
                        axis_name=axis_name,
                        residual_norm=solved.residual_norm,
                        update_norm=update_norm,
                        converged=False,
                    )
                )
            raw_state = SeparatedFieldState(axes=axes, terms=[SeparatedFieldTerm(weight=1.0, factors={name: values[:] for name, values in factors.items()})])
            residual_norm, residual_size = _dense_global_residual_norm(
                operator_ir=operator_ir,
                axis_operators=axis_operators,
                field_state=raw_state,
                coefficient_values=coefficient_values or {},
                geometry_factor_values=geometry_factor_values or {},
            )
            converged = residual_norm <= tolerance and max_update <= tolerance
            if history:
                last = history[-1]
                history[-1] = SubspaceIterationStep(
                    iteration=last.iteration,
                    axis_name=last.axis_name,
                    residual_norm=residual_norm,
                    update_norm=last.update_norm,
                    converged=converged,
                )
            if converged:
                break

        state = SeparatedFieldKernel().normalize(
            SeparatedFieldState(axes=axes, terms=[SeparatedFieldTerm(weight=1.0, factors={name: values[:] for name, values in factors.items()})])
        )
        return SubspaceALSResult(
            field_state=state,
            residual_norm=residual_norm,
            converged=converged,
            iteration_history=history,
            axis_systems=axis_systems,
            constraints_applied=constraints,
            dense_residual_size=residual_size,
        )

    def solve_with_rank_enrichment(
        self,
        *,
        operator_ir: SeparatedOperatorIR,
        axis_operators: dict[str, AxisBasisOperatorSet],
        coefficient_values: dict[str, float] | None = None,
        geometry_factor_values: dict[str, float] | None = None,
        essential_constraints: Sequence[EssentialAxisConstraint] | None = None,
        initial_rank_factors: Sequence[dict[str, Sequence[float]]] | None = None,
        axis_order: Sequence[str] | None = None,
        max_rank: int = 2,
        damping: float = 1.0,
        max_iterations_per_rank: int = 25,
        tolerance: float = 1e-8,
        restart_on_stagnation: bool = True,
        stagnation_tolerance: float = 1e-12,
        orthogonalize_axis: str | None = None,
    ) -> SubspaceEnrichmentResult:
        if max_rank < 1:
            msg = "max_rank must be at least 1."
            raise ValueError(msg)
        if len(operator_ir.axes) == 1:
            axis_name = operator_ir.axes[0].name
            single = self.solve_single_axis(
                operator_ir=operator_ir,
                target_axis=axis_name,
                axis_operators=axis_operators,
                coefficient_values=coefficient_values,
                geometry_factor_values=geometry_factor_values,
                essential_constraints=essential_constraints,
                tolerance=tolerance,
            )
            state = SeparatedFieldState(
                axes=list(operator_ir.axes),
                terms=[SeparatedFieldTerm(weight=1.0, factors={axis_name: list(single.node_values)})],
            )
            return SubspaceEnrichmentResult(
                field_state=state,
                residual_norm=single.residual_norm,
                converged=single.converged,
                rank_diagnostics=[
                    RankEnrichmentDiagnostic(
                        rank=1,
                        residual_norm=single.residual_norm,
                        relative_residual_reduction=1.0 if single.converged else 0.0,
                        update_norm=single.iteration_history[-1].update_norm,
                        converged=single.converged,
                    )
                ],
                iteration_history=single.iteration_history,
                axis_systems=[single.linear_system],
                constraints_applied=single.constraints_applied,
                dense_residual_size=len(single.node_values),
            )
        field_kernel = SeparatedFieldKernel()
        rank_states: list[SeparatedFieldState] = []
        diagnostics: list[RankEnrichmentDiagnostic] = []
        history: list[SubspaceIterationStep] = []
        axis_systems: list[SubspaceLinearSystem] = []
        previous_residual = float("inf")
        dense_residual_size = 0
        converged = False

        seeds = list(initial_rank_factors or [])
        for rank_index in range(1, max_rank + 1):
            seed = seeds[rank_index - 1] if rank_index - 1 < len(seeds) else self._rank_seed(operator_ir.axes, axis_operators, rank_index)
            rank_result = self.solve_rank_one_als(
                operator_ir=operator_ir,
                axis_operators=axis_operators,
                coefficient_values=coefficient_values,
                geometry_factor_values=geometry_factor_values,
                essential_constraints=essential_constraints,
                initial_factors=seed,
                axis_order=axis_order,
                damping=damping,
                max_iterations=max_iterations_per_rank,
                tolerance=tolerance,
            )
            rank_states.append(rank_result.field_state)
            combined_state = field_kernel.combine(rank_states)
            if orthogonalize_axis is not None:
                combined_state = field_kernel.orthogonalize(combined_state, axis_name=orthogonalize_axis)
                rank_states = [SeparatedFieldState(axes=combined_state.axes, terms=[term]) for term in combined_state.terms]
            residual_norm, dense_residual_size = _dense_global_residual_norm(
                operator_ir=operator_ir,
                axis_operators=axis_operators,
                field_state=combined_state,
                coefficient_values=coefficient_values or {},
                geometry_factor_values=geometry_factor_values or {},
            )
            if previous_residual == float("inf"):
                reduction = 0.0
            else:
                reduction = max(0.0, previous_residual - residual_norm) / max(previous_residual, 1e-300)
            update_norm = sqrt(sum(step.update_norm * step.update_norm for step in rank_result.iteration_history if step.iteration == rank_result.iteration_history[-1].iteration))
            converged = residual_norm <= tolerance
            diagnostics.append(
                RankEnrichmentDiagnostic(
                    rank=rank_index,
                    residual_norm=residual_norm,
                    relative_residual_reduction=reduction,
                    update_norm=update_norm,
                    converged=converged,
                )
            )
            history.extend(rank_result.iteration_history)
            axis_systems.extend(rank_result.axis_systems)
            if converged:
                break
            if restart_on_stagnation and rank_index > 1 and reduction <= stagnation_tolerance:
                break
            previous_residual = residual_norm

        return SubspaceEnrichmentResult(
            field_state=field_kernel.combine(rank_states),
            residual_norm=diagnostics[-1].residual_norm if diagnostics else float("inf"),
            converged=converged,
            rank_diagnostics=diagnostics,
            iteration_history=history,
            axis_systems=axis_systems,
            constraints_applied=list(essential_constraints or []),
            dense_residual_size=dense_residual_size,
        )

    def solve_nonlinear(
        self,
        *,
        operator_builder,
        initial_operator_ir: SeparatedOperatorIR,
        axis_operators: dict[str, AxisBasisOperatorSet],
        coefficient_values: dict[str, float] | None = None,
        geometry_factor_values: dict[str, float] | None = None,
        essential_constraints: Sequence[EssentialAxisConstraint] | None = None,
        method: str = "picard",
        max_iterations: int = 20,
        tolerance: float = 1e-8,
        damping: float = 1.0,
        max_rank: int = 1,
        axis_order: Sequence[str] | None = None,
        orthogonalize_axis: str | None = None,
    ) -> NonlinearSolveResult:
        if method not in {"picard", "newton", "fixed_point"}:
            msg = f"Unsupported nonlinear method {method!r}."
            raise ValueError(msg)
        previous_state: SeparatedFieldState | None = None
        linear_results: list[SubspaceEnrichmentResult] = []
        history: list[NonlinearIterationDiagnostic] = []
        operator_ir = initial_operator_ir
        converged = False
        residual_norm = float("inf")
        for iteration in range(1, max_iterations + 1):
            if previous_state is not None:
                operator_ir = operator_builder(previous_state, iteration)
            linear = self.solve_with_rank_enrichment(
                operator_ir=operator_ir,
                axis_operators=axis_operators,
                coefficient_values=coefficient_values,
                geometry_factor_values=geometry_factor_values,
                essential_constraints=essential_constraints,
                axis_order=axis_order,
                max_rank=max_rank,
                damping=damping,
                tolerance=tolerance,
                orthogonalize_axis=orthogonalize_axis,
            )
            update_norm = _field_update_norm(previous_state, linear.field_state)
            residual_norm = linear.residual_norm
            converged = residual_norm <= tolerance and update_norm <= tolerance
            history.append(
                NonlinearIterationDiagnostic(
                    iteration=iteration,
                    method=method,
                    residual_norm=residual_norm,
                    update_norm=update_norm,
                    converged=converged,
                )
            )
            linear_results.append(linear)
            previous_state = linear.field_state
            if converged:
                break
        if previous_state is None:
            msg = "Nonlinear solve did not execute any iterations."
            raise ValueError(msg)
        return NonlinearSolveResult(field_state=previous_state, residual_norm=residual_norm, converged=converged, nonlinear_history=history, linear_results=linear_results)

    def solve_time_slabs(
        self,
        *,
        operator_ir: SeparatedOperatorIR,
        axis_operators: dict[str, AxisBasisOperatorSet],
        slabs: Sequence[TimeSlabSpec],
        coefficient_values: dict[str, float] | None = None,
        geometry_factor_values: dict[str, float] | None = None,
        essential_constraints: Sequence[EssentialAxisConstraint] | None = None,
        initial_state: SeparatedFieldState | None = None,
        max_rank: int = 1,
        tolerance: float = 1e-8,
    ) -> SlabContinuationResult:
        if not slabs:
            msg = "Time slab continuation requires at least one slab."
            raise ValueError(msg)
        results: list[TimeSlabResult] = []
        state = initial_state
        converged = True
        for slab in slabs:
            initial_rank_factors = None
            if state is not None and state.terms:
                initial_rank_factors = [state.terms[0].factors]
            result = self.solve_with_rank_enrichment(
                operator_ir=operator_ir,
                axis_operators=axis_operators,
                coefficient_values=coefficient_values,
                geometry_factor_values=geometry_factor_values,
                essential_constraints=essential_constraints,
                initial_rank_factors=initial_rank_factors,
                max_rank=max_rank,
                tolerance=tolerance,
            )
            results.append(TimeSlabResult(slab=slab, result=result, initial_state=state))
            state = result.field_state
            converged = converged and result.converged
        return SlabContinuationResult(slabs=results, final_state=state, converged=converged)

    def _initial_factor_map(
        self,
        axes: Sequence[TAPSAxisSpec],
        axis_operators: dict[str, AxisBasisOperatorSet],
        initial_factors: dict[str, Sequence[float]] | None,
    ) -> dict[str, list[float]]:
        if initial_factors is not None:
            return _validated_factor_map(axes, initial_factors)
        factors: dict[str, list[float]] = {}
        for axis in axes:
            factors[axis.name] = [1.0 for _ in axis_operators[axis.name].nodes]
        return factors

    def _rank_seed(
        self,
        axes: Sequence[TAPSAxisSpec],
        axis_operators: dict[str, AxisBasisOperatorSet],
        rank_index: int,
    ) -> dict[str, list[float]]:
        seed: dict[str, list[float]] = {}
        for axis in axes:
            size = len(axis_operators[axis.name].nodes)
            if rank_index == 1:
                seed[axis.name] = [1.0 for _ in range(size)]
            else:
                seed[axis.name] = [1.0 + 0.05 * rank_index * (index - (size - 1) / 2.0) for index in range(size)]
        return seed


def export_taps_execution_artifacts(
    *,
    result: SubspaceALSResult | SubspaceEnrichmentResult | SubspaceIterationResult | NonlinearSolveResult | SlabContinuationResult,
    axis_operators: dict[str, AxisBasisOperatorSet],
    reconstruction_coordinates: Sequence[dict[str, float]] | None = None,
    baseline_gate: BaselineGateResult | None = None,
    execution_metadata: dict[str, object] | None = None,
) -> dict[str, object]:
    if isinstance(result, NonlinearSolveResult):
        linear_result = result.linear_results[-1]
        payload = export_taps_execution_artifacts(
            result=linear_result,
            axis_operators=axis_operators,
            reconstruction_coordinates=reconstruction_coordinates,
            baseline_gate=baseline_gate,
            execution_metadata=execution_metadata,
        )
        payload["taps_subspace_iteration_history"].update(
            {
                "execution_mode": "nonlinear",
                "converged": result.converged,
                "residual_norm": result.residual_norm,
                "nonlinear_history": [_nonlinear_diagnostic_payload(item) for item in result.nonlinear_history],
                "linear_solve_count": len(result.linear_results),
            }
        )
        return payload
    if isinstance(result, SlabContinuationResult):
        if result.final_state is None:
            msg = "Slab continuation result has no final state."
            raise ValueError(msg)
        final_result = result.slabs[-1].result
        payload = export_taps_execution_artifacts(
            result=final_result,
            axis_operators=axis_operators,
            reconstruction_coordinates=reconstruction_coordinates,
            baseline_gate=baseline_gate,
            execution_metadata=execution_metadata,
        )
        payload["taps_factors"] = _field_state_payload(result.final_state)
        payload["taps_subspace_iteration_history"].update(
            {
                "execution_mode": "time_slab_continuation",
                "converged": result.converged,
                "residual_norm": final_result.residual_norm,
                "slabs": [_time_slab_result_payload(item) for item in result.slabs],
            }
        )
        axis_nodes = {axis_name: operators.nodes for axis_name, operators in axis_operators.items()}
        payload["taps_reconstruction_samples"] = [
            result.final_state.sample_nearest(coordinates, axis_nodes).__dict__
            for coordinates in (reconstruction_coordinates or _default_reconstruction_coordinates(result.final_state.axes, axis_nodes))
        ]
        return payload
    if isinstance(result, (SubspaceALSResult, SubspaceEnrichmentResult)):
        field_state = result.field_state
        axis_nodes = {axis_name: operators.nodes for axis_name, operators in axis_operators.items()}
        samples = [
            field_state.sample_nearest(coordinates, axis_nodes).__dict__
            for coordinates in (reconstruction_coordinates or _default_reconstruction_coordinates(field_state.axes, axis_nodes))
        ]
        return {
            "taps_axis_operators": {axis_name: _axis_operator_payload(operators) for axis_name, operators in axis_operators.items()},
            "taps_factors": _field_state_payload(field_state),
            "taps_subspace_iteration_history": {
                "converged": result.converged,
                "residual_norm": result.residual_norm,
                "dense_residual_size": result.dense_residual_size,
                "rank_diagnostics": [_rank_diagnostic_payload(item) for item in result.rank_diagnostics] if isinstance(result, SubspaceEnrichmentResult) else [],
                "baseline_gate": _baseline_gate_payload(baseline_gate) if baseline_gate is not None else None,
                "execution_metadata": execution_metadata or {},
                "steps": [_iteration_step_payload(step) for step in result.iteration_history],
            },
            "taps_reconstruction_samples": samples,
        }
    return {
        "taps_axis_operators": {axis_name: _axis_operator_payload(operators) for axis_name, operators in axis_operators.items()},
        "taps_factors": {
            "axis_order": [result.axis_name],
            "rank": 1,
            "terms": [{"weight": 1.0, "factors": {result.axis_name: result.node_values}}],
        },
        "taps_subspace_iteration_history": {
            "converged": result.converged,
            "residual_norm": result.residual_norm,
            "dense_residual_size": len(result.node_values),
            "baseline_gate": _baseline_gate_payload(baseline_gate) if baseline_gate is not None else None,
            "execution_metadata": execution_metadata or {},
            "steps": [_iteration_step_payload(step) for step in result.iteration_history],
        },
        "taps_reconstruction_samples": [
            {
                "coordinates": {result.axis_name: axis_operators[result.axis_name].nodes[index]},
                "nearest_node_indices": {result.axis_name: index},
                "value": value,
            }
            for index, value in enumerate(result.node_values)
        ],
    }


def write_taps_execution_artifacts(
    *,
    result: SubspaceALSResult | SubspaceEnrichmentResult | SubspaceIterationResult | NonlinearSolveResult | SlabContinuationResult,
    axis_operators: dict[str, AxisBasisOperatorSet],
    output_dir: str | Path,
    reconstruction_coordinates: Sequence[dict[str, float]] | None = None,
    baseline_gate: BaselineGateResult | None = None,
    execution_metadata: dict[str, object] | None = None,
) -> list[ArtifactRef]:
    payload = export_taps_execution_artifacts(
        result=result,
        axis_operators=axis_operators,
        reconstruction_coordinates=reconstruction_coordinates,
        baseline_gate=baseline_gate,
        execution_metadata=execution_metadata,
    )
    directory = Path(output_dir)
    directory.mkdir(parents=True, exist_ok=True)
    artifact_specs = [
        ("taps_axis_operators", "taps_axis_operators.json"),
        ("taps_factors", "taps_factors.json"),
        ("taps_subspace_iteration_history", "taps_subspace_iteration_history.json"),
        ("taps_reconstruction_samples", "taps_reconstruction_samples.json"),
    ]
    artifacts: list[ArtifactRef] = []
    for kind, filename in artifact_specs:
        path = directory / filename
        path.write_text(json.dumps(payload[kind], indent=2), encoding="utf-8")
        artifacts.append(ArtifactRef(uri=str(path), kind=kind, format="json"))
    return artifacts


def evaluate_baseline_gate(
    *,
    field_state: SeparatedFieldState,
    samples: Sequence[BaselineSample],
    tolerance: float,
) -> BaselineGateResult:
    if tolerance < 0.0:
        msg = "Baseline gate tolerance must be non-negative."
        raise ValueError(msg)
    if not samples:
        return BaselineGateResult(passed=False, max_error=float("inf"), rms_error=float("inf"), sample_count=0, tolerance=tolerance, errors=["No independent baseline samples were provided."])
    squared = 0.0
    max_error = 0.0
    errors: list[str] = []
    for sample in samples:
        predicted = field_state.evaluate_at_node_indices(sample.node_indices)
        error = abs(predicted - sample.value)
        max_error = max(max_error, error)
        squared += error * error
        if error > tolerance:
            errors.append(f"baseline sample {sample.node_indices} error {error:.6g} exceeds tolerance {tolerance:.6g}")
    rms = sqrt(squared / len(samples))
    return BaselineGateResult(passed=not errors, max_error=max_error, rms_error=rms, sample_count=len(samples), tolerance=tolerance, errors=errors)


@dataclass(frozen=True)
class AxisBasisOperatorSet:
    """P1 axis-local Galerkin operators for separated TAPS execution."""

    axis: TAPSAxisSpec
    basis_ref: str
    element_order: str
    nodes: list[float]
    elements: list[tuple[int, int]]
    quadrature_points: list[float]
    quadrature_weights: list[float]
    mass_matrix: Matrix
    stiffness_matrix: Matrix
    derivative_matrix: Matrix
    identity_matrix: Matrix
    lumped_mass: list[float]

    def matrix_for(self, operator: str) -> Matrix:
        if operator == "mass":
            return self.mass_matrix
        if operator in {"stiffness", "gradient"}:
            return self.stiffness_matrix
        if operator == "derivative":
            return self.derivative_matrix
        if operator == "identity":
            return self.identity_matrix
        msg = f"Axis operator {operator!r} is not available from the P1 axis basis kernel."
        raise ValueError(msg)

    def source_vector_for_constant(self, value: float = 1.0) -> list[float]:
        return [value * weight for weight in self.lumped_mass]

    def source_vector_from_nodal_values(self, values: Sequence[float]) -> list[float]:
        if len(values) != len(self.nodes):
            msg = f"Expected {len(self.nodes)} nodal values for axis {self.axis.name!r}, got {len(values)}."
            raise ValueError(msg)
        return _matvec(self.mass_matrix, [float(value) for value in values])


class AxisBasisKernel:
    """Build axis-local basis and operator blocks after formulation/operator IR validation."""

    def __init__(self, *, element_order: str = "p1", quadrature_order: int = 2) -> None:
        if element_order.lower() != "p1":
            msg = "Only P1 axis basis is implemented; higher order/C-HiDeNN bases must use another kernel."
            raise ValueError(msg)
        if quadrature_order != 2:
            msg = "Only two-point Gauss quadrature is implemented for the initial P1 axis kernel."
            raise ValueError(msg)
        self.element_order = element_order.lower()
        self.quadrature_order = quadrature_order

    def build(self, axis: TAPSAxisSpec, *, basis_ref: str | None = None) -> AxisBasisOperatorSet:
        nodes = _uniform_axis_nodes(axis)
        size = len(nodes)
        elements = [(index, index + 1) for index in range(size - 1)]
        mass = _zeros(size)
        stiffness = _zeros(size)
        derivative = _zeros(size)
        lumped = [0.0 for _ in range(size)]
        quadrature_points: list[float] = []
        quadrature_weights: list[float] = []

        for left, right in elements:
            x0 = nodes[left]
            x1 = nodes[right]
            h = x1 - x0
            _assemble_2x2(mass, (left, right), [[h / 3.0, h / 6.0], [h / 6.0, h / 3.0]])
            _assemble_2x2(stiffness, (left, right), [[1.0 / h, -1.0 / h], [-1.0 / h, 1.0 / h]])
            _assemble_2x2(derivative, (left, right), [[-0.5, 0.5], [-0.5, 0.5]])
            lumped[left] += h / 2.0
            lumped[right] += h / 2.0
            for xi, weight in _gauss2_interval(x0, x1):
                quadrature_points.append(xi)
                quadrature_weights.append(weight)

        return AxisBasisOperatorSet(
            axis=axis,
            basis_ref=basis_ref or f"basis:{axis.name}:p1",
            element_order=self.element_order,
            nodes=nodes,
            elements=elements,
            quadrature_points=quadrature_points,
            quadrature_weights=quadrature_weights,
            mass_matrix=mass,
            stiffness_matrix=stiffness,
            derivative_matrix=derivative,
            identity_matrix=_identity(size),
            lumped_mass=lumped,
        )


def build_axis_basis_operators(axis: TAPSAxisSpec, *, basis_ref: str | None = None) -> AxisBasisOperatorSet:
    return AxisBasisKernel().build(axis, basis_ref=basis_ref)


def _uniform_axis_nodes(axis: TAPSAxisSpec) -> list[float]:
    if axis.min_value is None or axis.max_value is None:
        msg = f"Axis {axis.name!r} needs min_value and max_value for P1 basis generation."
        raise ValueError(msg)
    if axis.points is None:
        msg = f"Axis {axis.name!r} needs points for P1 basis generation."
        raise ValueError(msg)
    if axis.points < 2:
        msg = f"Axis {axis.name!r} needs at least 2 points, got {axis.points}."
        raise ValueError(msg)
    if axis.max_value <= axis.min_value:
        msg = f"Axis {axis.name!r} must satisfy max_value > min_value."
        raise ValueError(msg)
    spacing = (axis.max_value - axis.min_value) / float(axis.points - 1)
    return [axis.min_value + spacing * index for index in range(axis.points)]


def _axis_point_count(axis: TAPSAxisSpec) -> int:
    if axis.points is None or axis.points < 2:
        msg = f"Axis {axis.name!r} needs at least 2 points for separated field factors."
        raise ValueError(msg)
    return axis.points


def _validated_factor_map(axes: Sequence[TAPSAxisSpec], factors: dict[str, Sequence[float]]) -> dict[str, list[float]]:
    axis_names = {axis.name for axis in axes}
    unknown = sorted(set(factors) - axis_names)
    missing = sorted(axis_names - set(factors))
    if unknown:
        msg = f"Separated field factors reference unknown axes: {', '.join(unknown)}."
        raise ValueError(msg)
    if missing:
        msg = f"Separated field factors are missing axes: {', '.join(missing)}."
        raise ValueError(msg)
    validated: dict[str, list[float]] = {}
    for axis in axes:
        values = [float(value) for value in factors[axis.name]]
        expected = _axis_point_count(axis)
        if len(values) != expected:
            msg = f"Axis {axis.name!r} expected {expected} factor values, got {len(values)}."
            raise ValueError(msg)
        validated[axis.name] = values
    return validated


def _nearest_index(nodes: Sequence[float], coordinate: float) -> int:
    if not nodes:
        msg = "Cannot sample an axis with no nodes."
        raise ValueError(msg)
    return min(range(len(nodes)), key=lambda index: abs(float(nodes[index]) - float(coordinate)))


def _index_product(shape: Sequence[int]) -> list[tuple[int, ...]]:
    if not shape:
        return [()]
    tail = _index_product(shape[1:])
    return [(index, *rest) for index in range(shape[0]) for rest in tail]


def _zeros(size: int) -> Matrix:
    return [[0.0 for _ in range(size)] for _ in range(size)]


def _identity(size: int) -> Matrix:
    matrix = _zeros(size)
    for index in range(size):
        matrix[index][index] = 1.0
    return matrix


def _add_scaled_matrix(target: Matrix, matrix: Matrix, scale: float) -> None:
    if len(target) != len(matrix):
        msg = "Matrix size mismatch during separated subspace assembly."
        raise ValueError(msg)
    for row_index, row in enumerate(matrix):
        if len(target[row_index]) != len(row):
            msg = "Matrix row size mismatch during separated subspace assembly."
            raise ValueError(msg)
        for col_index, value in enumerate(row):
            target[row_index][col_index] += scale * value


def _assemble_2x2(target: Matrix, dofs: tuple[int, int], local: list[list[float]]) -> None:
    for local_i, global_i in enumerate(dofs):
        for local_j, global_j in enumerate(dofs):
            target[global_i][global_j] += local[local_i][local_j]


def _gauss2_interval(x0: float, x1: float) -> list[tuple[float, float]]:
    midpoint = 0.5 * (x0 + x1)
    half_length = 0.5 * (x1 - x0)
    offset = half_length / sqrt(3.0)
    return [(midpoint - offset, half_length), (midpoint + offset, half_length)]


def _matvec(matrix: Matrix, vector: list[float]) -> list[float]:
    return [sum(value * vector[col] for col, value in enumerate(row)) for row in matrix]


def _quadratic_form(matrix: Matrix, vector: list[float]) -> float:
    return sum(vector[row] * value * vector[col] for row, matrix_row in enumerate(matrix) for col, value in enumerate(matrix_row))


def _linear_form(matrix: Matrix, vector: list[float]) -> float:
    return sum(sum(value * vector[col] for col, value in enumerate(row)) for row in matrix)


def _field_update_norm(previous: SeparatedFieldState | None, current: SeparatedFieldState) -> float:
    current_values = SeparatedFieldKernel().reconstruct_dense(current)["values"]
    if not isinstance(current_values, list):
        msg = "Separated field reconstruction did not return a value list."
        raise ValueError(msg)
    if previous is None:
        return sqrt(sum(float(value) * float(value) for value in current_values))
    previous_values = SeparatedFieldKernel().reconstruct_dense(previous)["values"]
    if not isinstance(previous_values, list) or len(previous_values) != len(current_values):
        msg = "Cannot compute update norm for incompatible separated field states."
        raise ValueError(msg)
    return sqrt(sum((float(current_value) - float(previous_values[index])) ** 2 for index, current_value in enumerate(current_values)))


def _dense_global_residual_norm(
    *,
    operator_ir: SeparatedOperatorIR,
    axis_operators: dict[str, AxisBasisOperatorSet],
    field_state: SeparatedFieldState,
    coefficient_values: dict[str, float],
    geometry_factor_values: dict[str, float],
) -> tuple[float, int]:
    shape = [len(axis_operators[axis.name].nodes) for axis in field_state.axes]
    squared = 0.0
    size = 0
    for indices_tuple in _index_product(shape):
        indices = dict(zip([axis.name for axis in field_state.axes], indices_tuple))
        lhs_value = 0.0
        rhs_value = 0.0
        for operator_term in operator_ir.terms:
            scale = _operator_term_scalar_scale(operator_term, coefficient_values, geometry_factor_values)
            if operator_term.role == "source" or not _term_has_unknown_field(operator_term):
                rhs_value += scale * _source_value_at_indices(operator_term, field_state.axes, axis_operators, indices)
            else:
                lhs_value += scale * sum(
                    _operator_value_at_indices(operator_term, field_state.axes, axis_operators, term.factors, indices, term.weight)
                    for term in field_state.terms
                )
        diff = lhs_value - rhs_value
        squared += diff * diff
        size += 1
    return sqrt(squared), size


def _axis_operator_payload(operators: AxisBasisOperatorSet) -> dict[str, object]:
    return {
        "axis": operators.axis.model_dump(mode="json"),
        "basis_ref": operators.basis_ref,
        "element_order": operators.element_order,
        "nodes": operators.nodes,
        "elements": [list(element) for element in operators.elements],
        "quadrature_points": operators.quadrature_points,
        "quadrature_weights": operators.quadrature_weights,
        "mass_matrix": operators.mass_matrix,
        "stiffness_matrix": operators.stiffness_matrix,
        "derivative_matrix": operators.derivative_matrix,
        "identity_matrix": operators.identity_matrix,
        "lumped_mass": operators.lumped_mass,
    }


def _field_state_payload(state: SeparatedFieldState) -> dict[str, object]:
    return {
        "axis_order": [axis.name for axis in state.axes],
        "rank": state.rank,
        "terms": [{"weight": term.weight, "factors": term.factors} for term in state.terms],
    }


def _iteration_step_payload(step: SubspaceIterationStep) -> dict[str, object]:
    return {
        "iteration": step.iteration,
        "axis_name": step.axis_name,
        "residual_norm": step.residual_norm,
        "update_norm": step.update_norm,
        "converged": step.converged,
    }


def _rank_diagnostic_payload(diagnostic: RankEnrichmentDiagnostic) -> dict[str, object]:
    return {
        "rank": diagnostic.rank,
        "residual_norm": diagnostic.residual_norm,
        "relative_residual_reduction": diagnostic.relative_residual_reduction,
        "update_norm": diagnostic.update_norm,
        "converged": diagnostic.converged,
    }


def _nonlinear_diagnostic_payload(diagnostic: NonlinearIterationDiagnostic) -> dict[str, object]:
    return {
        "iteration": diagnostic.iteration,
        "method": diagnostic.method,
        "residual_norm": diagnostic.residual_norm,
        "update_norm": diagnostic.update_norm,
        "converged": diagnostic.converged,
    }


def _time_slab_result_payload(result: TimeSlabResult) -> dict[str, object]:
    return {
        "index": result.slab.index,
        "start": result.slab.start,
        "end": result.slab.end,
        "initial_rank": result.initial_state.rank if result.initial_state is not None else 0,
        "final_rank": result.result.field_state.rank,
        "residual_norm": result.result.residual_norm,
        "converged": result.result.converged,
        "steps": [_iteration_step_payload(step) for step in result.result.iteration_history],
    }


def _baseline_gate_payload(gate: BaselineGateResult) -> dict[str, object]:
    return {
        "passed": gate.passed,
        "max_error": gate.max_error,
        "rms_error": gate.rms_error,
        "sample_count": gate.sample_count,
        "tolerance": gate.tolerance,
        "errors": gate.errors,
    }


def _default_reconstruction_coordinates(axes: Sequence[TAPSAxisSpec], axis_nodes: dict[str, Sequence[float]]) -> list[dict[str, float]]:
    first = {axis.name: float(axis_nodes[axis.name][0]) for axis in axes}
    last = {axis.name: float(axis_nodes[axis.name][-1]) for axis in axes}
    midpoint = {axis.name: float(axis_nodes[axis.name][len(axis_nodes[axis.name]) // 2]) for axis in axes}
    return [first, midpoint, last]


def _operator_term_scalar_scale(
    term: SeparatedOperatorTermIR,
    coefficient_values: dict[str, float],
    geometry_factor_values: dict[str, float],
) -> float:
    scale = 1.0
    for coefficient_ref in _term_coefficient_refs(term):
        scale *= _required_scalar(coefficient_values, coefficient_ref, "coefficient")
    for factor_ref in _term_geometry_factor_refs(term):
        scale *= _required_scalar(geometry_factor_values, factor_ref, "geometry factor")
    return scale


def _term_has_unknown_field(term: SeparatedOperatorTermIR) -> bool:
    return term.role != "source"


def _operator_value_at_indices(
    term: SeparatedOperatorTermIR,
    axes: Sequence[TAPSAxisSpec],
    axis_operators: dict[str, AxisBasisOperatorSet],
    factors: dict[str, list[float]],
    indices: dict[str, int],
    weight: float = 1.0,
) -> float:
    product = weight
    for axis in axes:
        operator = _axis_operator_name_for_term(term, axis.name)
        applied = _matvec(axis_operators[axis.name].matrix_for(operator), factors[axis.name])
        product *= applied[indices[axis.name]]
    return product


def _source_value_at_indices(
    term: SeparatedOperatorTermIR,
    axes: Sequence[TAPSAxisSpec],
    axis_operators: dict[str, AxisBasisOperatorSet],
    indices: dict[str, int],
) -> float:
    product = 1.0
    for axis in axes:
        operator = _axis_operator_name_for_term(term, axis.name)
        if operator == "source":
            vector = axis_operators[axis.name].source_vector_for_constant(1.0)
        else:
            vector = _matvec(axis_operators[axis.name].matrix_for(operator), [1.0 for _ in axis_operators[axis.name].nodes])
        product *= vector[indices[axis.name]]
    return product


def _axis_operator_name_for_term(term: SeparatedOperatorTermIR, axis_name: str) -> str:
    matching = [block.operator for block in term.axis_blocks if block.axis_name == axis_name]
    if len(matching) > 1:
        msg = f"Term {term.id!r} has multiple blocks for axis {axis_name!r}; split them before execution."
        raise ValueError(msg)
    if matching:
        return matching[0]
    if term.role == "source":
        return "source"
    return "identity"


def _term_coefficient_refs(term: SeparatedOperatorTermIR) -> list[str]:
    refs = list(term.coefficient_refs)
    for block in term.axis_blocks:
        if block.coefficient_ref is not None and block.coefficient_ref not in refs:
            refs.append(block.coefficient_ref)
    return refs


def _term_geometry_factor_refs(term: SeparatedOperatorTermIR) -> list[str]:
    refs = list(term.geometry_factor_refs)
    for block in term.axis_blocks:
        if block.geometry_factor_ref is not None and block.geometry_factor_ref not in refs:
            refs.append(block.geometry_factor_ref)
    return refs


def _required_scalar(values: dict[str, float], ref: str, kind: str) -> float:
    if ref not in values:
        msg = f"Missing scalar {kind} value for {ref!r}."
        raise ValueError(msg)
    return float(values[ref])


def _apply_essential_constraints(
    lhs: Matrix,
    rhs: list[float],
    axis_name: str,
    constraints: Sequence[EssentialAxisConstraint],
) -> tuple[Matrix, list[float]]:
    constrained_lhs = [row[:] for row in lhs]
    constrained_rhs = list(rhs)
    size = len(constrained_rhs)
    for constraint in constraints:
        if constraint.axis_name != axis_name:
            continue
        index = constraint.node_index
        if index < 0 or index >= size:
            msg = f"Essential constraint node index {index} is out of range for axis {axis_name!r}."
            raise ValueError(msg)
        value = float(constraint.value)
        for row_index in range(size):
            if row_index != index:
                constrained_rhs[row_index] -= constrained_lhs[row_index][index] * value
                constrained_lhs[row_index][index] = 0.0
        for col_index in range(size):
            constrained_lhs[index][col_index] = 0.0
        constrained_lhs[index][index] = 1.0
        constrained_rhs[index] = value
    return constrained_lhs, constrained_rhs


def _dense_solve(matrix: Matrix, rhs: list[float], *, pivot_tolerance: float = 1e-14) -> list[float]:
    size = len(rhs)
    if len(matrix) != size or any(len(row) != size for row in matrix):
        msg = "Dense solve requires a square matrix matching rhs size."
        raise ValueError(msg)
    a = [row[:] + [float(rhs[row_index])] for row_index, row in enumerate(matrix)]
    for pivot_col in range(size):
        pivot_row = max(range(pivot_col, size), key=lambda row: abs(a[row][pivot_col]))
        if abs(a[pivot_row][pivot_col]) <= pivot_tolerance:
            msg = "Linear system is singular or ill-conditioned for direct dense solve."
            raise ValueError(msg)
        if pivot_row != pivot_col:
            a[pivot_col], a[pivot_row] = a[pivot_row], a[pivot_col]
        pivot = a[pivot_col][pivot_col]
        for col in range(pivot_col, size + 1):
            a[pivot_col][col] /= pivot
        for row in range(size):
            if row == pivot_col:
                continue
            factor = a[row][pivot_col]
            if factor == 0.0:
                continue
            for col in range(pivot_col, size + 1):
                a[row][col] -= factor * a[pivot_col][col]
    return [a[row][size] for row in range(size)]


def _constrained_residual_norm(
    lhs: Matrix,
    rhs: list[float],
    solution: list[float],
    axis_name: str,
    constraints: Sequence[EssentialAxisConstraint],
) -> float:
    constrained_nodes = {constraint.node_index for constraint in constraints if constraint.axis_name == axis_name}
    residual = _matvec(lhs, solution)
    squared = 0.0
    for index, value in enumerate(residual):
        if index in constrained_nodes:
            continue
        diff = value - rhs[index]
        squared += diff * diff
    return sqrt(squared)
