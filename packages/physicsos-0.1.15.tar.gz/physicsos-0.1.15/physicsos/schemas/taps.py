from __future__ import annotations

from typing import Literal

from pydantic import Field

from physicsos.schemas.common import ArtifactRef, StrictBaseModel
from physicsos.schemas.geometry import BoundaryRole, GeometryMeshContract


class TAPSAxisSpec(StrictBaseModel):
    name: str
    kind: Literal["space", "parameter", "time", "geometry"]
    min_value: float | None = None
    max_value: float | None = None
    points: int | None = None
    units: str | None = None


class TAPSBasisConfig(StrictBaseModel):
    tensor_rank: int = 8
    patch_size: int = 3
    dilation: float = 1.0
    reproducing_order: int = 2
    quadrature_order: int = 3


class TAPSNonlinearConfig(StrictBaseModel):
    method: Literal["picard", "newton", "fixed_point"] = "picard"
    max_iterations: int = 50
    tolerance: float = 1e-10
    damping: float = 0.8
    linear_reaction: float = 1.0
    cubic_reaction: float = 0.1
    coupling_strength: float = 0.25


class TAPSGeometryEncodingSpec(StrictBaseModel):
    kind: Literal[
        "sdf",
        "occupancy_mask",
        "surface_point_cloud",
        "volume_point_cloud",
        "mesh_graph",
        "boundary_graph",
        "laplacian_eigenbasis",
        "multi_resolution_grid",
        "parametric_shape_vector",
    ]
    uri: str
    resolution: list[int] | None = None
    target_backend: str | None = None
    boundary_policy: Literal["dirichlet_zero", "ignore_inactive", "embedded_boundary"] = "dirichlet_zero"


class TAPSCoefficientSpec(StrictBaseModel):
    name: str
    value: float | int | str | list[float] | dict
    role: Literal["material", "source", "boundary", "operator", "solver"] = "operator"
    units: str | None = None
    region_ids: list[str] = Field(default_factory=list)
    source: Literal["physics_problem", "knowledge_agent", "user", "template", "default"] = "physics_problem"


class TAPSBoundaryConditionSpec(StrictBaseModel):
    id: str
    region_id: str
    boundary_role: BoundaryRole | None = None
    field: str
    kind: str
    value: float | int | str | list[float] | dict
    units: str | None = None
    source: Literal["physics_problem", "knowledge_agent", "user", "template", "default"] = "physics_problem"


class TAPSEquationTerm(StrictBaseModel):
    id: str
    role: Literal[
        "time_derivative",
        "mass",
        "diffusion",
        "advection",
        "reaction",
        "source",
        "constraint",
        "boundary",
        "interface",
        "constitutive",
        "custom",
    ]
    expression: str
    fields: list[str] = Field(default_factory=list)
    coefficients: list[str] = Field(default_factory=list)
    integration_domain: str | None = None
    assumptions: list[str] = Field(default_factory=list)


class TAPSWeakFormSpec(StrictBaseModel):
    family: str
    strong_form: str | None = None
    trial_fields: list[str] = Field(default_factory=list)
    test_functions: list[str] = Field(default_factory=list)
    terms: list[TAPSEquationTerm] = Field(default_factory=list)
    boundary_terms: list[TAPSEquationTerm] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    residual_expression: str | None = None
    source: Literal["physics_problem", "knowledge_agent", "user", "template", "hybrid"] = "physics_problem"


class TAPSIntegralTermIR(StrictBaseModel):
    id: str
    role: Literal[
        "time_derivative",
        "mass",
        "diffusion",
        "advection",
        "reaction",
        "source",
        "boundary_flux",
        "boundary_penalty",
        "constraint",
        "interface",
        "constitutive",
        "custom",
    ]
    field: str
    test_function: str
    integrand: str
    domain_ref: str
    measure_ref: Literal["dx", "ds", "dS", "dt", "dp", "custom"] = "dx"
    coefficients: list[str] = Field(default_factory=list)
    required_geometry_factors: list[
        Literal["volume_measure", "boundary_measure", "metric", "jacobian", "domain_indicator", "normal", "mapping"]
    ] = Field(default_factory=list)


class TAPSGeometryRequirement(StrictBaseModel):
    id: str
    target_ref: str
    factor: Literal["volume_measure", "boundary_measure", "metric", "jacobian", "domain_indicator", "normal", "mapping"]
    separability: Literal["required", "preferred", "not_required"] = "required"
    reason: str


class TAPSBindingDiagnostic(StrictBaseModel):
    id: str
    kind: Literal["field", "coefficient", "source", "boundary", "geometry", "operator"]
    status: Literal["bound", "missing", "ambiguous", "assumed"]
    target: str
    message: str


class TAPSFormulationIR(StrictBaseModel):
    id: str
    problem_id: str
    status: Literal["ready", "missing_bindings", "needs_knowledge", "unsupported"]
    family: str
    fields: list[str] = Field(default_factory=list)
    axes: list[TAPSAxisSpec] = Field(default_factory=list)
    terms: list[TAPSIntegralTermIR] = Field(default_factory=list)
    boundary_conditions: list[TAPSBoundaryConditionSpec] = Field(default_factory=list)
    coefficient_bindings: list[TAPSCoefficientSpec] = Field(default_factory=list)
    source_bindings: list[TAPSCoefficientSpec] = Field(default_factory=list)
    geometry_contract: GeometryMeshContract
    geometry_requirements: list[TAPSGeometryRequirement] = Field(default_factory=list)
    diagnostics: list[TAPSBindingDiagnostic] = Field(default_factory=list)
    missing_bindings: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)


class SeparatedGeometryFactorRef(StrictBaseModel):
    name: str
    factor: Literal["volume_measure", "boundary_measure", "metric", "jacobian", "domain_indicator", "normal", "mapping", "coefficient"]
    axis_names: list[str] = Field(default_factory=list)
    rank: int | None = None
    compression_error: float | None = None
    artifact: ArtifactRef | None = None


class SeparatedGeometryOperator(StrictBaseModel):
    id: str
    geometry_id: str
    axis_domains: list[TAPSAxisSpec] = Field(default_factory=list)
    basis_refs: list[str] = Field(default_factory=list)
    factors: list[SeparatedGeometryFactorRef] = Field(default_factory=list)
    validity_region: dict[str, float | int | str | bool] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)


class TAPSGeometrySeparabilityAssessment(StrictBaseModel):
    status: Literal["executable_taps", "needs_geometry_compression", "route_to_fem", "missing_bindings"]
    can_execute_separated: bool
    separated_operator: SeparatedGeometryOperator | None = None
    missing_requirements: list[str] = Field(default_factory=list)
    fallback_backend: Literal["fenicsx", "openfoam", "su2", "mesh_fem_bridge", "none"] = "none"
    reasons: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class SeparatedAxisOperatorBlock(StrictBaseModel):
    axis_name: str
    basis_ref: str | None = None
    operator: Literal["mass", "stiffness", "derivative", "gradient", "curl", "divergence", "identity", "source", "boundary", "custom"]
    coefficient_ref: str | None = None
    geometry_factor_ref: str | None = None
    power: int = 1
    transpose: bool = False


class SeparatedOperatorTermIR(StrictBaseModel):
    id: str
    formulation_term_id: str
    role: Literal[
        "time_derivative",
        "mass",
        "diffusion",
        "advection",
        "reaction",
        "source",
        "boundary_flux",
        "boundary_penalty",
        "constraint",
        "interface",
        "constitutive",
        "custom",
    ]
    axis_blocks: list[SeparatedAxisOperatorBlock] = Field(default_factory=list)
    coefficient_refs: list[str] = Field(default_factory=list)
    geometry_factor_refs: list[str] = Field(default_factory=list)
    contraction: str
    assumptions: list[str] = Field(default_factory=list)


class SeparatedOperatorIR(StrictBaseModel):
    id: str
    formulation_id: str
    status: Literal["ready", "needs_operator_review", "missing_bindings", "unsupported"]
    terms: list[SeparatedOperatorTermIR] = Field(default_factory=list)
    axes: list[TAPSAxisSpec] = Field(default_factory=list)
    geometry_operator: SeparatedGeometryOperator
    missing_bindings: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)


class TAPSTimeSlabPlanSpec(StrictBaseModel):
    index: int
    start: float
    end: float


class TAPSBaselineSampleSpec(StrictBaseModel):
    node_indices: dict[str, int]
    value: float


class TAPSExecutionPlan(StrictBaseModel):
    id: str
    formulation_id: str
    operator_ir_id: str
    status: Literal["ready", "needs_operator_review", "missing_bindings", "unsupported"]
    tensor_rank: int = 1
    axis_order: list[str] = Field(default_factory=list)
    subspace_solver: Literal["direct", "least_squares", "gmres", "cg", "custom"] = "direct"
    damping: float = 1.0
    max_iterations: int = 25
    tolerance: float = 1e-8
    slab_policy: Literal["single_slab", "time_slab", "parameter_slab", "none"] = "none"
    time_slabs: list[TAPSTimeSlabPlanSpec] = Field(default_factory=list)
    nonlinear_policy: Literal["none", "picard", "newton", "fixed_point"] = "none"
    operator_update_policy: Literal["frozen_ir", "runtime_extension", "external_callback"] = "frozen_ir"
    orthogonalize_axis: str | None = None
    baseline_policy: Literal["not_required", "optional", "required"] = "not_required"
    baseline_tolerance: float = 1e-8
    baseline_samples: list[TAPSBaselineSampleSpec] = Field(default_factory=list)
    fallback: Literal["none", "needs_operator_review", "fenicsx", "openfoam", "full_solver"] = "none"
    assumptions: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)


class ProposeSeparatedOperatorOutput(StrictBaseModel):
    operator_ir: SeparatedOperatorIR
    execution_plan: TAPSExecutionPlan


class TAPSCompilationPlan(StrictBaseModel):
    problem_id: str
    status: Literal["ready", "needs_knowledge", "needs_user_input", "unsupported"]
    equation_family: str
    unknown_fields: list[str] = Field(default_factory=list)
    axes: list[TAPSAxisSpec] = Field(default_factory=list)
    weak_form: TAPSWeakFormSpec | None = None
    required_knowledge_queries: list[str] = Field(default_factory=list)
    missing_inputs: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    recommended_next_action: Literal[
        "compile_taps_problem",
        "ask_knowledge_agent",
        "ask_user",
        "author_runtime_extension",
        "fallback_solver",
    ]


class TAPSRuntimeExtensionSpec(StrictBaseModel):
    id: str
    problem_id: str
    purpose: str
    language: Literal["python", "ufl", "sympy", "jax", "torch", "custom"] = "python"
    entrypoint: str
    artifact: ArtifactRef
    required_inputs: list[str] = Field(default_factory=list)
    expected_outputs: list[str] = Field(default_factory=list)
    safety_status: Literal["draft", "requires_review", "approved_for_local_run"] = "draft"
    notes: list[str] = Field(default_factory=list)


class TAPSProblem(StrictBaseModel):
    id: str
    problem_id: str
    axes: list[TAPSAxisSpec] = Field(default_factory=list)
    operator_weak_form: str | None = None
    weak_form: TAPSWeakFormSpec | None = None
    compilation_status: Literal["compiled", "knowledge_assisted", "scaffold", "unsupported"] = "scaffold"
    basis: TAPSBasisConfig = Field(default_factory=TAPSBasisConfig)
    nonlinear: TAPSNonlinearConfig = Field(default_factory=TAPSNonlinearConfig)
    geometry_encodings: list[TAPSGeometryEncodingSpec] = Field(default_factory=list)
    coefficients: list[TAPSCoefficientSpec] = Field(default_factory=list)
    boundary_conditions: list[TAPSBoundaryConditionSpec] = Field(default_factory=list)
    slabs: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)


class TAPSSupportScore(StrictBaseModel):
    score: float
    supported: bool
    reasons: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)


class TAPSResidualReport(StrictBaseModel):
    residuals: dict[str, float] = Field(default_factory=dict)
    rank: int
    converged: bool
    recommended_action: Literal["accept", "increase_rank", "refine_axes", "split_slab", "fallback"]


class TAPSResultArtifacts(StrictBaseModel):
    factor_matrices: list[ArtifactRef] = Field(default_factory=list)
    reconstruction_metadata: ArtifactRef | None = None
    residual_history: ArtifactRef | None = None


class NumericalDiscretizationSpec(StrictBaseModel):
    dimension: int
    node_counts: dict[str, int] = Field(default_factory=dict)
    element_order: int = 1
    quadrature_order: int | None = None


class NumericalCoefficientBinding(StrictBaseModel):
    name: str
    role: Literal["diffusion", "reaction", "source", "boundary", "operator", "solver"]
    value: float | int | str | list[float] | dict
    source_name: str | None = None
    units: str | None = None


class NumericalBoundaryConditionBinding(StrictBaseModel):
    id: str
    region_id: str
    boundary_role: BoundaryRole | None = None
    field: str
    kind: str
    value: float | int | str | list[float] | dict
    units: str | None = None


class NumericalSourceBinding(StrictBaseModel):
    name: str
    value: float | int | str | list[float] | dict
    expression: str | None = None
    units: str | None = None


class NumericalSolvePlanOutput(StrictBaseModel):
    problem_id: str
    status: Literal["ready", "fallback_required", "unsupported"] = "ready"
    solver_family: str
    backend_target: str = "taps"
    field_bindings: dict[str, str] = Field(default_factory=dict)
    discretization: NumericalDiscretizationSpec
    coefficient_bindings: list[NumericalCoefficientBinding] = Field(default_factory=list)
    source_bindings: list[NumericalSourceBinding] = Field(default_factory=list)
    boundary_condition_bindings: list[NumericalBoundaryConditionBinding] = Field(default_factory=list)
    initial_condition_bindings: list[dict[str, float | int | str | list[float] | dict]] = Field(default_factory=list)
    linearization_policy: str | None = None
    expected_artifacts: list[str] = Field(default_factory=list)
    validation_checks: list[str] = Field(default_factory=list)
    fallback_decision: str | None = None
    assumptions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    unsupported_reasons: list[str] = Field(default_factory=list)


class BackendPreparationPlanOutput(StrictBaseModel):
    problem_id: str
    status: Literal["ready", "needs_inputs", "unsupported"] = "ready"
    target_backend: str
    backend_family: Literal["fenicsx", "mfem", "petsc", "openfoam", "su2", "generic"]
    field_space_plan: list[dict[str, object]] = Field(default_factory=list)
    mesh_export: dict[str, object] = Field(default_factory=dict)
    coefficient_map: list[dict[str, object]] = Field(default_factory=list)
    boundary_tag_map: list[dict[str, object]] = Field(default_factory=list)
    stabilization_policy: dict[str, object] = Field(default_factory=dict)
    solver_controls: dict[str, object] = Field(default_factory=dict)
    dependency_checks: list[dict[str, object]] = Field(default_factory=list)
    approval_gate: dict[str, object] = Field(default_factory=dict)
    expected_artifacts: list[str] = Field(default_factory=list)
    validation_checks: list[str] = Field(default_factory=list)
    assumptions: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    unsupported_reasons: list[str] = Field(default_factory=list)
