from __future__ import annotations


# DeepAgents subagents are optional CLI assistants. Do not register PhysicsOS
# workflow nodes here: geometry/mesh, TAPS/FEM/solver, verification,
# postprocess, and case-memory stages are owned by the typed PhysicsOS workflow.
# Future DeepAgents subagents should use distinct document/research/artifact
# assistant names rather than reusing workflow node names.
SUBAGENTS: list[dict] = []
