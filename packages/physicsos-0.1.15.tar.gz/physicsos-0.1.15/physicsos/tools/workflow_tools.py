from __future__ import annotations

from typing import Literal

from pydantic import Field
from uuid import uuid4

from physicsos.agents.structured import (
    CoreAgentLLMConfig,
    StructuredAgentResult,
    StructuredLLMClient,
    call_structured_agent,
    create_openai_structured_client,
    load_core_agent_config,
    structured_agent_event_context,
)
from physicsos.schemas.common import StrictBaseModel
from physicsos.schemas.problem import PhysicsProblem
from physicsos.tools.problem_tools import (
    BuildPhysicsProblemInput,
    BuildPhysicsProblemOutput,
    CanonicalPhysicsProblemOutput,
    ValidatePhysicsProblemOutput,
    canonicalize_physics_problem,
    validate_physics_problem,
    CanonicalPhysicsProblemInput,
    ValidatePhysicsProblemInput,
)
from physicsos.workflows.universal import PhysicsOSWorkflowResult, run_physicsos_workflow


class RunTypedPhysicsOSWorkflowInput(StrictBaseModel):
    user_request: str = Field(
        description=(
            "Current natural-language modeling or simulation request. Always pass the user's current request here. "
            "If problem is None, the PhysicsOS workflow builds a new PhysicsProblem from this request. "
            "If problem is provided, the workflow treats it as the current PhysicsProblem state and updates it from this request."
        )
    )
    problem: PhysicsProblem | None = Field(
        default=None,
        description=(
            "Optional current PhysicsProblem state. Pass None when no current typed problem exists. "
            "Pass the latest PhysicsProblem returned by a prior workflow when the user is modifying or continuing that model. "
            "Providing problem supplies state context for the LLM-backed build/update step."
        ),
    )
    use_knowledge: bool = True
    arxiv_max_results: int = 0
    use_deepsearch: bool = False
    taps_rank: int = 8
    max_validation_attempts: int = 2
    taps_max_wall_time_seconds: float = 120.0
    core_agents_mode: Literal["llm", "hybrid"] | None = Field(
        default=None,
        description="Optional runtime override for core PhysicsOS workflow LLM mode. Natural-language workflow entry does not support deterministic fallback.",
    )


class RunTypedPhysicsOSWorkflowOutput(StrictBaseModel):
    build: BuildPhysicsProblemOutput
    canonicalization: CanonicalPhysicsProblemOutput | None = None
    initial_validation: ValidatePhysicsProblemOutput | None = None
    workflow: PhysicsOSWorkflowResult | None = None
    missing_inputs: list[str] = Field(default_factory=list)


BUILD_PHYSICS_PROBLEM_SYSTEM_PROMPT = """Extract a PhysicsOS BuildPhysicsProblemOutput from the user request.
Return only a JSON object matching the output schema. Preserve explicit geometry, materials, boundary conditions,
initial conditions, source terms, targets, and uncertainty. Do not replace user-provided values with defaults.
If a current PhysicsProblem state is provided in the input assumptions, update that typed state according to user_request.
Do not discard existing geometry, fields, operators, materials, boundary ids/roles, or material values unless user_request explicitly changes them.
If no current PhysicsProblem state is provided, build a new PhysicsProblem from user_request."""


def _workflow_user_request(input: RunTypedPhysicsOSWorkflowInput) -> str:
    return input.user_request.strip()


def _build_input_for_workflow(input: RunTypedPhysicsOSWorkflowInput, request: str) -> BuildPhysicsProblemInput:
    assumptions: list[str] = []
    if input.problem is not None:
        assumptions.append(
            "CURRENT_PHYSICS_PROBLEM_STATE_JSON="
            + input.problem.model_dump_json()
        )
        assumptions.append(
            "Use CURRENT_PHYSICS_PROBLEM_STATE_JSON as the current typed PhysicsProblem state. "
            "Apply user_request as an update/repair/continuation and return the updated PhysicsProblem."
        )
    return BuildPhysicsProblemInput(user_request=request, assumptions=assumptions)


def _build_problem_semantic_errors(output: BuildPhysicsProblemOutput) -> list[str]:
    if not output.missing_inputs:
        return []
    return [
        "BuildPhysicsProblemOutput.missing_inputs blocks workflow execution. "
        "Review the user_request, current problem state, and validation_feedback. "
        "If a missing value is explicitly present in the user request or can be supplied from LLM physics knowledge, "
        "put it in the typed PhysicsProblem and remove that missing_inputs entry. "
        "If it is genuinely absent, keep it in missing_inputs; do not invent user-specific values."
    ]


def _build_problem_semantic_feedback(output: BuildPhysicsProblemOutput, errors: list[str]) -> list[str]:
    return [
        "Previous typed build output still had unresolved missing_inputs.",
        f"missing_inputs={output.missing_inputs}",
        *errors,
        "Return a complete BuildPhysicsProblemOutput if possible; otherwise return the same genuinely missing inputs.",
    ]


def _last_valid_build_output(result: StructuredAgentResult[BuildPhysicsProblemOutput]) -> BuildPhysicsProblemOutput | None:
    for attempt in reversed(result.attempts):
        if attempt.parsed is None:
            continue
        try:
            return BuildPhysicsProblemOutput.model_validate(attempt.parsed)
        except Exception:
            continue
    return None


def build_physics_problem_structured(
    input: BuildPhysicsProblemInput,
    *,
    client: StructuredLLMClient,
    config: CoreAgentLLMConfig | None = None,
) -> BuildPhysicsProblemOutput:
    result = call_structured_agent(
        agent_name="build-physics-problem-agent",
        input_model=input,
        output_model=BuildPhysicsProblemOutput,
        system_prompt=BUILD_PHYSICS_PROBLEM_SYSTEM_PROMPT,
        client=client,
        config=config,
        semantic_validator=_build_problem_semantic_errors,
        semantic_feedback_builder=_build_problem_semantic_feedback,
    )
    if result.output is None:
        recovered = _last_valid_build_output(result)
        if recovered is not None:
            return recovered.model_copy(
                update={
                    "assumptions": [
                        *recovered.assumptions,
                        "Structured LLM problem extraction exhausted semantic retries with unresolved missing_inputs; workflow blocked without deterministic fallback.",
                    ]
                }
            )
        return BuildPhysicsProblemOutput(
            problem=None,
            missing_inputs=["structured_llm_output"],
            assumptions=[result.error or "Structured build-physics-problem agent failed validation."],
        )
    return result.output


def _build_problem_with_llm_first_fallback(
    build_input: BuildPhysicsProblemInput,
    *,
    core_config: CoreAgentLLMConfig,
    structured_client: StructuredLLMClient | None,
) -> BuildPhysicsProblemOutput:
    if structured_client is not None:
        built = build_physics_problem_structured(build_input, client=structured_client, config=core_config)
        if built.problem is not None:
            return built
        return BuildPhysicsProblemOutput(
            problem=None,
            missing_inputs=[*built.missing_inputs, "structured_llm_problem_extraction_failed"],
            assumptions=[
                "Structured LLM problem extraction failed after validation retries; deterministic fallback is disabled.",
                *built.assumptions,
            ],
        )
    return BuildPhysicsProblemOutput(
        problem=None,
        missing_inputs=["structured_llm_client_unavailable"],
        assumptions=["No structured LLM client was available; deterministic fallback is disabled."],
    )


def _run_typed_physicsos_workflow_impl(
    input: RunTypedPhysicsOSWorkflowInput,
    *,
    structured_client: StructuredLLMClient | None = None,
) -> RunTypedPhysicsOSWorkflowOutput:
    run_id = f"workflow:{uuid4().hex}"
    core_config = load_core_agent_config()
    if input.core_agents_mode is not None:
        core_config = core_config.model_copy(update={"mode": input.core_agents_mode})
    request = _workflow_user_request(input)
    build_input = _build_input_for_workflow(input, request)
    with structured_agent_event_context(run_id=run_id):
        if core_config.mode in {"llm", "hybrid"}:
            built = _build_problem_with_llm_first_fallback(build_input, core_config=core_config, structured_client=structured_client)
        elif core_config.mode == "deterministic":
            built = BuildPhysicsProblemOutput(
                problem=None,
                missing_inputs=["deterministic_core_agents_mode_removed"],
                assumptions=[
                    "Natural-language PhysicsOS workflow requires LLM or hybrid core_agents.mode; deterministic problem-builder fallback has been removed.",
                ],
            )
        else:
            built = BuildPhysicsProblemOutput(
                problem=None,
                missing_inputs=["unsupported_core_agents_mode"],
                assumptions=[f"Unsupported core_agents_mode={core_config.mode!r}."],
            )
    if built.problem is None:
        return RunTypedPhysicsOSWorkflowOutput(build=built, missing_inputs=built.missing_inputs)
    if built.missing_inputs:
        return RunTypedPhysicsOSWorkflowOutput(build=built, missing_inputs=built.missing_inputs)

    canonicalization = canonicalize_physics_problem(CanonicalPhysicsProblemInput(problem=built.problem))
    if canonicalization.status != "ready":
        return RunTypedPhysicsOSWorkflowOutput(
            build=built,
            canonicalization=canonicalization,
            missing_inputs=[*built.missing_inputs, *canonicalization.missing_boundary_roles],
        )

    built = built.model_copy(update={"problem": canonicalization.problem})
    initial_validation = validate_physics_problem(ValidatePhysicsProblemInput(problem=canonicalization.problem))
    workflow = run_physicsos_workflow(
        problem=canonicalization.problem,
        run_id=run_id,
        use_knowledge=input.use_knowledge,
        arxiv_max_results=input.arxiv_max_results,
        use_deepsearch=input.use_deepsearch,
        taps_rank=input.taps_rank,
        max_validation_attempts=input.max_validation_attempts,
        taps_max_wall_time_seconds=input.taps_max_wall_time_seconds,
        structured_client=structured_client,
        core_agent_config=core_config,
    )
    return RunTypedPhysicsOSWorkflowOutput(
        build=built,
        canonicalization=canonicalization,
        initial_validation=initial_validation,
        workflow=workflow,
        missing_inputs=built.missing_inputs,
    )


def run_typed_physicsos_workflow(input: RunTypedPhysicsOSWorkflowInput) -> RunTypedPhysicsOSWorkflowOutput:
    """Natural-language entry point for the typed PhysicsOS workflow."""
    core_config = load_core_agent_config()
    if input.core_agents_mode is not None:
        core_config = core_config.model_copy(update={"mode": input.core_agents_mode})
    structured_client: StructuredLLMClient | None = None
    if core_config.mode in {"llm", "hybrid"}:
        try:
            structured_client = create_openai_structured_client()
        except (ImportError, RuntimeError) as exc:
            return RunTypedPhysicsOSWorkflowOutput(
                build=BuildPhysicsProblemOutput(
                    problem=None,
                    missing_inputs=["structured_llm_client_unavailable"],
                    assumptions=[f"Failed to create structured LLM client: {exc}"],
                ),
                missing_inputs=["structured_llm_client_unavailable"],
            )
    try:
        return _run_typed_physicsos_workflow_impl(input, structured_client=structured_client)
    except Exception as exc:
        return RunTypedPhysicsOSWorkflowOutput(
            build=BuildPhysicsProblemOutput(
                problem=None,
                missing_inputs=["structured_llm_workflow_failed"],
                assumptions=[f"Structured LLM workflow failed without deterministic fallback: {exc.__class__.__name__}: {exc}"],
            ),
            missing_inputs=["structured_llm_workflow_failed"],
        )


run_typed_physicsos_workflow.input_model = RunTypedPhysicsOSWorkflowInput
run_typed_physicsos_workflow.output_model = RunTypedPhysicsOSWorkflowOutput
run_typed_physicsos_workflow.side_effects = "may create workflow artifacts"
run_typed_physicsos_workflow.requires_approval = False
