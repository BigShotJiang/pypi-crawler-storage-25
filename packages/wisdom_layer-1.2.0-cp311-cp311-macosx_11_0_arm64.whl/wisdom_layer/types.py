"""Public type definitions for the Wisdom Layer SDK."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, Field


class MemoryTier(StrEnum):
    """Memory tier classification."""

    RAW = "raw"  # Tier 1: Unprocessed events
    CONSOLIDATED = "consolidated"  # Tier 2: Weighted, searchable knowledge
    REFLECTIVE = "reflective"  # Tier 3: Narrative synthesis


class Memory(BaseModel):
    """A memory record across any tier.

    ``embedding_model_id`` and ``embedding_dim`` are persisted on every row
    so vector search can refuse to compare across embedding spaces. Defaults
    match the historical free-tier baseline (``all-MiniLM-L6-v2`` @ 384) and
    are backfilled by storage migration 0003 for any row written before
    Phase 0.4 landed. See doc 06 §0.4 and doc 11 §2.
    """

    id: str
    tier: MemoryTier
    content: str
    event_type: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)
    salience: float = Field(default=0.5, ge=0.0, le=1.0)
    reinforcement_count: int = 0
    emotional_intensity: float = Field(default=0.0, ge=0.0, le=1.0)
    embedding_model_id: str = "all-MiniLM-L6-v2"
    embedding_dim: int = 384
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    source_ids: list[str] = Field(default_factory=list)


class MemorySearchResult(BaseModel):
    """Result from a memory search operation."""

    memory: Memory
    similarity: float = Field(ge=0.0, le=1.0)


class Reflection(BaseModel):
    """A Tier 3 reflective journal entry."""

    id: str
    content: str
    source_memory_ids: list[str] = Field(default_factory=list)
    insights: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class DreamPhase(StrEnum):
    """Phases of a dream cycle."""

    RECONSOLIDATION = "reconsolidation"
    CRITICISM = "criticism"
    SYNTHESIS = "synthesis"
    ENTROPY = "entropy"
    JOURNAL = "journal"


class PhaseCost(BaseModel):
    """Per-phase LLM cost entry on a :class:`DreamReport`.

    v0.5 Phase 4 — populated by the dreams pipeline from the cost ledger
    so operators can see which cycle phase (and which model) consumed
    what. ``cost_usd`` is zero for local inference (Ollama).
    """

    phase: str
    model: str = ""
    tokens_in: int = 0
    tokens_out: int = 0
    usd: float = 0.0
    duration_ms: int = 0
    calls: int = 0


class DreamReport(BaseModel):
    """Report from a completed dream cycle.

    ``cost_breakdown`` and the ``total_*`` aggregates are populated in
    v0.5 Phase 4 — earlier cycles that predate the cost ledger leave
    these at their zero defaults.
    """

    cycle_id: str
    started_at: datetime
    completed_at: datetime
    phases_completed: list[DreamPhase]
    reconsolidated: int = 0
    new_insights: int = 0
    decayed: int = 0
    directives_proposed: int = 0
    journal_entry_id: str | None = None
    cost_breakdown: list[PhaseCost] = Field(default_factory=list)
    total_tokens: int = 0
    total_usd: float = 0.0
    total_duration_ms: int = 0


class RiskLevel(StrEnum):
    """Risk level from critic evaluation."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class CriticFlag(BaseModel):
    """A specific concern raised by the critic."""

    category: str
    description: str
    severity: RiskLevel
    evidence: str = ""


class CriticReview(BaseModel):
    """Result of critic evaluation on agent output."""

    risk_level: RiskLevel
    flags: list[CriticFlag] = Field(default_factory=list)
    pass_through: bool = True
    reasoning: str = ""


class AuditReport(BaseModel):
    """Report from a behavioral audit."""

    period: str
    consistency_score: float = Field(ge=0.0, le=1.0)
    narrative_drift_score: float = Field(ge=0.0, le=1.0)
    self_correction_rate: float = Field(ge=0.0, le=1.0)
    directive_adherence: float = Field(ge=0.0, le=1.0)
    flags: list[CriticFlag] = Field(default_factory=list)


class DirectiveStatus(StrEnum):
    """Status of a directive."""

    ACTIVE = "active"
    PROVISIONAL = "provisional"
    PERMANENT = "permanent"
    INACTIVE = "inactive"


class Directive(BaseModel):
    """A behavioral rule that persists across sessions."""

    id: str
    text: str
    status: DirectiveStatus = DirectiveStatus.ACTIVE
    # Reserved for future per-directive overrides; not user-settable in
    # v1.0. Lifecycle is driven by ``status`` alone:
    # provisional → active → permanent (always-applied) → inactive.
    priority: str = "contextual"
    usage_count: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_used: datetime | None = None


class DirectiveProposal(BaseModel):
    """A proposed change to the directive set."""

    id: str
    action: str  # "add", "modify", "remove"
    text: str
    reasoning: str
    confidence: float = Field(ge=0.0, le=1.0)
    source_memory_ids: list[str] = Field(default_factory=list)


class Trajectory(BaseModel):
    """Agent development trajectory over time."""

    wisdom_score: float = Field(ge=0.0, le=1.0)
    self_correction_rate: float = Field(ge=0.0, le=1.0)
    memory_utilization: float = Field(ge=0.0, le=1.0)
    directive_evolution_count: int = 0
    dream_cycles_completed: int = 0
    insight_quality: float = Field(ge=0.0, le=1.0)


class CognitiveHealth(BaseModel):
    """Current cognitive health snapshot.

    .. deprecated::
        Prefer :class:`HealthReport` (returned by ``agent.health()``) which
        carries the full v0.5 health surface. ``CognitiveHealth`` remains
        for backwards compatibility and is unused internally.
    """

    memory_load: float = Field(ge=0.0, le=1.0)
    consolidation_backlog: int = 0
    drift_risk: float = Field(ge=0.0, le=1.0)
    last_dream_cycle: datetime | None = None
    active_directives: int = 0
    provisional_directives: int = 0


class CognitiveHealthStatus(StrEnum):
    """Classifier verdict for overall cognitive health.

    - ``healthy``: wisdom score above threshold, dreams succeeding,
      directives stable.
    - ``stagnant``: agent is idle — little capture, little
      reinforcement. Not failing, but not learning.
    - ``drifting``: directives demoting faster than they're stabilizing
      or critic contradictions are climbing.
    - ``overloaded``: dream cycles are failing or budget guards are
      firing — capacity is the bottleneck.
    """

    HEALTHY = "healthy"
    STAGNANT = "stagnant"
    DRIFTING = "drifting"
    OVERLOADED = "overloaded"


class MemoryStats(BaseModel):
    """Memory tier counts and recent quality signals."""

    stream_count: int = 0
    consolidated_count: int = 0
    journal_count: int = 0
    avg_salience: float = Field(default=0.0, ge=0.0, le=1.0)
    dedup_rate_7d: float = Field(default=0.0, ge=0.0, le=1.0)


class DirectiveStats(BaseModel):
    """Directive lifecycle counts and recent churn."""

    provisional_count: int = 0
    active_count: int = 0
    permanent_count: int = 0
    demotion_rate_7d: float = Field(default=0.0, ge=0.0, le=1.0)
    avg_age_days: float = Field(default=0.0, ge=0.0)


class DreamStats(BaseModel):
    """Dream cycle throughput and reliability over the last 7 days."""

    runs_7d: int = 0
    success_rate_7d: float = Field(default=0.0, ge=0.0, le=1.0)
    avg_duration_ms: float = Field(default=0.0, ge=0.0)
    last_run_ago_hours: float | None = None


class CostStats(BaseModel):
    """Token and spend aggregates over the last 7 days."""

    tokens_7d: int = 0
    usd_7d: float = Field(default=0.0, ge=0.0)
    avg_tokens_per_dream: float = Field(default=0.0, ge=0.0)


class HealthReport(BaseModel):
    """Full cognitive health surface for an agent.

    Free tier receives stats only — ``wisdom_score``, ``cognitive_health``,
    and ``remedy_url`` stay ``None``. Pro and Enterprise tiers receive the
    full composite and classifier.
    """

    timestamp: datetime = Field(default_factory=datetime.utcnow)
    tier: str = "free"
    memory_stats: MemoryStats = Field(default_factory=MemoryStats)
    directive_stats: DirectiveStats = Field(default_factory=DirectiveStats)
    dream_stats: DreamStats = Field(default_factory=DreamStats)
    cost_stats: CostStats = Field(default_factory=CostStats)
    wisdom_score: float | None = Field(default=None, ge=0.0, le=1.0)
    cognitive_health: CognitiveHealthStatus | None = None
    remedy_url: str | None = None


# --- Cost visibility (v0.5 Phase 4) --------------------------------------

class CostBucket(BaseModel):
    """Spend + token + call aggregate for one dimension of ``CostSummary``."""

    cost_usd: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    calls: int = 0


class CostSummary(BaseModel):
    """Aggregate cost report returned by ``agent.cost.summary()``.

    ``by_category`` keys follow the ledger's v0.5 classifier (``capture``,
    ``dream.reconsolidate``, ``dream.critic``, ``explain`` …). ``by_model``
    keys are adapter ``model_id`` values — exactly what appears in the
    cost ledger.
    """

    total_usd: float = 0.0
    total_tokens: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_calls: int = 0
    by_category: dict[str, CostBucket] = Field(default_factory=dict)
    by_model: dict[str, CostBucket] = Field(default_factory=dict)
    window_start: datetime | None = None
    window_end: datetime | None = None


class CostEstimate(BaseModel):
    """Pre-flight dream cost estimate from ``agent.dreams.estimate_cost()``.

    ``confidence`` reflects how much historical signal was available to
    project the estimate forward:

    - ``high``: ≥ 5 prior cycles of the same depth.
    - ``medium``: 2–4 prior cycles.
    - ``low``: 0–1 prior cycles — estimate is a rough lower bound.
    """

    estimated_usd: float = 0.0
    estimated_tokens: int = 0
    confidence: Literal["low", "medium", "high"] = "low"
    sample_size: int = 0
    window_days: int = 14
