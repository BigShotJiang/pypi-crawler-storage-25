"""Dreams API routes — trigger, history, schedule controls."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, Query

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/dreams", tags=["dreams"])

AgentDep = Depends(get_agent)


@router.post("/trigger")
async def trigger_dream(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Trigger a dream cycle now."""
    report = await agent.dreams.trigger()
    return report if isinstance(report, dict) else report.__dict__


@router.get("/history")
async def dream_history(
    limit: int = Query(default=10, ge=1, le=100),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """Get dream cycle history with cost data, most recent first."""
    cycles = await agent.dreams.history(limit=limit)
    for cycle in cycles:
        cid = cycle.get("cycle_id")
        if cid:
            try:
                breakdown = await agent._backend.sum_cost_by_cycle(
                    agent_id=agent._agent_id,
                    cycle_id=cid,
                )
                total_tokens = sum(
                    r["input_tokens"] + r["output_tokens"] for r in breakdown
                )
                total_usd = sum(r["cost_usd"] for r in breakdown)
                cycle["cost_breakdown"] = breakdown
                cycle["total_tokens"] = total_tokens
                cycle["total_usd"] = total_usd
            except Exception:
                cycle["cost_breakdown"] = []
                cycle["total_tokens"] = 0
                cycle["total_usd"] = 0.0
    return cycles


@router.post("/schedule")
async def schedule_dream(
    interval_hours: float = Body(embed=True),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Schedule recurring dream cycles."""
    result = await agent.dreams.schedule(interval_hours=interval_hours)
    return result if isinstance(result, dict) else result.__dict__


@router.post("/pause")
async def pause_schedule(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Pause the dream schedule."""
    result = await agent.dreams.pause()
    return result if isinstance(result, dict) else result.__dict__


@router.post("/resume")
async def resume_schedule(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Resume the dream schedule."""
    result = await agent.dreams.resume()
    return result if isinstance(result, dict) else result.__dict__


@router.post("/unschedule")
async def unschedule_dream(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Remove the dream schedule."""
    result = await agent.dreams.unschedule()
    return result if isinstance(result, dict) else result.__dict__


@router.get("/estimate-cost")
async def estimate_cost(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Estimate the cost of running a dream cycle."""
    result = await agent.dreams.estimate_cost()
    return result if isinstance(result, dict) else result.__dict__


@router.get("/schedule/status")
async def schedule_status(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Get current dream schedule status."""
    next_run = agent.dreams.next_run
    last_run = agent.dreams.last_run
    return {
        "next_run": next_run.isoformat() if next_run else None,
        "last_run": last_run.isoformat() if last_run else None,
    }
