"""Critic API routes — entropy + audits."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/critic", tags=["critic"])

AgentDep = Depends(get_agent)

_LEVEL_MAP: dict[str, str] = {
    "low": "healthy",
    "moderate": "elevated",
    "high": "high",
    "critical": "critical",
    "healthy": "healthy",
    "elevated": "elevated",
}


@router.get("/entropy")
async def get_entropy(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Compute directive entropy score (point-in-time diagnostic)."""
    result = await agent.critic.entropy()
    raw = result if isinstance(result, dict) else (
        result.model_dump() if hasattr(result, "model_dump") else result.__dict__
    )

    components = raw.get("components", {})
    level = str(raw.get("level", "healthy"))

    return {
        "entropy_score": raw.get("entropy_score", 0.0),
        "level": _LEVEL_MAP.get(level, level),
        "churn": components.get("churn", 0.0),
        "volume": components.get("volume", 0.0),
        "staleness": components.get("staleness", 0.0),
        "total_directives": raw.get("total_directives", 0),
    }


@router.get("/reviews")
async def list_reviews(
    limit: int = Query(default=20, ge=1, le=100),
    risk_level: str | None = Query(default=None),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """List stored critic reviews, most recent first."""
    return await agent.critic.reviews(limit=limit, risk_level=risk_level)


@router.get("/audits")
async def get_latest_audit(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Run a coherence audit on the active directive set."""
    result = await agent.critic.audit()
    return result if isinstance(result, dict) else (
        result.model_dump() if hasattr(result, "model_dump") else result.__dict__
    )


@router.post("/grounding")
async def verify_grounding(
    payload: dict[str, str],
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Verify a draft output's claims against the fact store (Pro+)."""
    return await agent.critic.verify_grounding(payload["output"])
