"""Demo mode routes — seed data, day progression, reset.

NOT mounted by default. Enable with ``--demo`` flag or by importing the
router directly. Uses the Acme SaaS customer support seed corpus from
the original wisdom-layer-demo.

NOTE — pricing in the seed corpus below is FICTIONAL.

The plans referenced in ``_SEED_INTERACTIONS`` (Starter, Pro, Growth at
$79 / $199, with $15/seat add-ons, SSO/SAML on Enterprise, etc.) describe
a make-believe SaaS company called Acme — they are NOT Wisdom Layer's own
plans, prices, or features. They exist solely to give the demo agent
realistic-sounding training material so a viewer can see the dream cycle
extracting durable directives from messy support tickets. Do NOT update
these strings when Wisdom Layer's real pricing changes; the agent's
seeded directives reference them directly and rewriting one without the
others would break the demo's coherence.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import APIRouter, Depends

from wisdom_layer.dashboard.server import get_agent

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/demo", tags=["demo"])

AgentDep = Depends(get_agent)

_SEED_INTERACTIONS: list[dict[str, str]] = [
    {
        "category": "billing",
        "user_message": (
            "I was charged twice this month. My invoice shows two identical "
            "charges for $79 on the 3rd and the 4th."
        ),
        "agent_response": (
            "I'm sorry to hear that. Let me look into this right away. "
            "What I'll do first is pull up both payment IDs — if they share the same "
            "payment_intent_id, one is a retry that should not have settled. In that case "
            "we issue a credit to your next invoice rather than a refund, because the credit "
            "clears faster than a bank reversal."
        ),
        "signal": "duplicate charges require credit, not refund; always verify payment_id first",
    },
    {
        "category": "billing",
        "user_message": (
            "I upgraded from Pro ($79/mo) to Growth ($199/mo) 12 days into my billing cycle "
            "and got charged $82.67. Where does that number come from?"
        ),
        "agent_response": (
            "That's the prorated charge for the upgrade. Your billing cycle is 30 days, "
            "so you had 18 days remaining. The price difference is $120/month. "
            "Formula: (18 / 30) × $120 = $72. Plus applicable tax brings it to $82.67."
        ),
        "signal": (
            "proration formula: charge = (days_remaining / days_in_period) × price_diff; "
            "upgrade takes effect immediately"
        ),
    },
    {
        "category": "billing",
        "user_message": (
            "My annual subscription auto-renewed two weeks ago and I didn't want to renew. "
            "Can I get a refund?"
        ),
        "agent_response": (
            "For annual subscriptions, our renewal dispute window is 14 days from the charge "
            "date — and you're within that window, so you're eligible for a full refund. "
            "Monthly subscribers get 30 days, but annual is 14 because we commit "
            "infrastructure capacity at the annual rate."
        ),
        "signal": (
            "annual plan customers get a 14-day grace period for renewal disputes, "
            "not the standard 30-day"
        ),
    },
    {
        "category": "upgrades",
        "user_message": (
            "If I upgrade from Starter to Pro today, do I get Pro features right now "
            "or do I have to wait until my next billing cycle?"
        ),
        "agent_response": (
            "You get Pro access the instant you confirm the upgrade — no waiting for renewal. "
            "The prorated charge for the remaining days posts immediately. We never defer "
            "feature access."
        ),
        "signal": (
            "mid-cycle upgrades: prorate immediately, access unlocks instantly, "
            "never defer to renewal date"
        ),
    },
    {
        "category": "upgrades",
        "user_message": "I want to downgrade from Growth to Pro. Will I lose any of my data?",
        "agent_response": (
            "You won't lose data — but Growth gives you unlimited workspaces; Pro caps you "
            "at 5. Workspaces over the limit become read-only at your next renewal date. "
            "You can still export them. We send a warning email 7 days before the cycle ends."
        ),
        "signal": (
            "downgrade impact: data over the new plan's limit becomes read-only at renewal; "
            "warn the customer 7 days before their cycle ends"
        ),
    },
    {
        "category": "onboarding",
        "user_message": (
            "I'm trying to set up SSO with our Okta instance but I can't find "
            "the SAML configuration in the dashboard. We're on Pro."
        ),
        "agent_response": (
            "SSO and SAML are Enterprise-tier features — they're not available on Pro. "
            "I can set you up with a 14-day Enterprise trial so you can validate the "
            "integration before committing. We do support OAuth with Google and GitHub "
            "on all plans as an alternative."
        ),
        "signal": (
            "SSO/SAML requires Enterprise plan; "
            "offer 14-day Enterprise trial if on lower plan"
        ),
    },
    {
        "category": "onboarding",
        "user_message": (
            "We keep hitting rate limit errors on the API. We're making about 5,000 "
            "calls per day. What plan do we need?"
        ),
        "agent_response": (
            "At 5,000 calls/day, you're just under Pro's 10,000/day limit. "
            "The breakdown: Free=100/day, Pro=10k/day, Growth=100k/day. "
            "If your usage is growing, Growth gives you 10x headroom."
        ),
        "signal": (
            "API rate limits: Free=100/day, Pro=10k/day, "
            "Growth=100k/day, Enterprise=unlimited"
        ),
    },
    {
        "category": "features",
        "user_message": (
            "I'm confused about seat pricing. If I invite 10 people to my workspace, "
            "does that use 10 seats?"
        ),
        "agent_response": (
            "Yes — 10 people uses 10 seats from your workspace allocation. "
            "Your plan includes a base seat count (Starter: 3, Pro: 10, Growth: unlimited). "
            "Additional seats beyond base are $15/seat/month. Billing is per workspace, "
            "not per person — same user in two workspaces counts twice."
        ),
        "signal": (
            "seat licensing: billed per workspace, not per user; "
            "all users in a workspace share the workspace seat allocation"
        ),
    },
    {
        "category": "features",
        "user_message": (
            "How long does Acme keep our data? We need to retain records for 3 years "
            "for compliance purposes."
        ),
        "agent_response": (
            "Retention by plan: Free=30 days, Pro/Growth=12 months, Enterprise=unlimited. "
            "For a 3-year requirement, Enterprise is the native option. However, all plans "
            "support scheduled data exports to your own storage (S3, GCS), so you can "
            "maintain the archive independently."
        ),
        "signal": (
            "data retention: Free=30 days, Pro=12 months, Growth=12 months, "
            "Enterprise=unlimited; data export always available"
        ),
    },
    {
        "category": "churn",
        "user_message": (
            "The price increase to $199/month for Growth is too much. "
            "We've been customers for 2 years. Is there anything you can do?"
        ),
        "agent_response": (
            "As a loyalty offer for Growth customers of 2+ years, I can apply a 15% "
            "discount if you commit to an annual plan. That brings your effective "
            "monthly cost to $169.15, locked in for 12 months."
        ),
        "signal": (
            "price sensitivity: offer 15% loyalty discount for annual commitment "
            "before escalating to manager; don't discount monthly plans"
        ),
    },
]

_SEED_CONSOLIDATED: list[dict[str, str]] = [
    {
        "text": (
            "Billing disputes follow a consistent pattern: verify payment IDs first, "
            "then issue credits (not refunds) for duplicate charges. Prorated charges use "
            "the formula (days_remaining / days_in_period) × price_diff."
        ),
        "source_category": "billing",
    },
    {
        "text": (
            "Plan upgrades take effect immediately with prorated billing. Downgrades "
            "apply at renewal — data over the new limit becomes read-only. Always warn "
            "customers 7 days before the cycle ends."
        ),
        "source_category": "upgrades",
    },
    {
        "text": (
            "Feature questions cluster around seat pricing, data retention, and rate "
            "limits. Customers consistently confuse per-user vs per-workspace billing. "
            "Reference specific plan limits (Free/Pro/Growth/Enterprise) every time."
        ),
        "source_category": "features",
    },
]

_SEED_JOURNAL = (
    "After processing 11 support interactions across billing, upgrades, onboarding, "
    "features, and churn categories, several patterns emerged: (1) billing disputes "
    "require systematic verification before action — credits clear faster than refunds; "
    "(2) plan transition rules are a major source of customer confusion; (3) empathy-first "
    "responses to price sensitivity combined with loyalty discounts significantly reduce "
    "churn risk. The agent has internalized 5 directives covering these domains, with "
    "the proration formula and payment verification being the most operationally critical."
)

_SEED_DIRECTIVES = [
    "Always verify payment_id before issuing credits or refunds",
    (
        "Use the proration formula for mid-cycle upgrade charges: "
        "(days_remaining / days_in_period) × price_diff"
    ),
    (
        "Lead with empathy when customers express price frustration "
        "— offer loyalty discounts before escalating"
    ),
    "Warn customers about read-only data limits 7 days before downgrade takes effect at renewal",
    "Reference specific plan limits (Free/Pro/Growth/Enterprise) when answering feature questions",
]


@router.post("/seed")
async def seed_data(agent: Any = AgentDep) -> dict[str, Any]:
    """Populate the agent with the Acme SaaS demo corpus.

    Automatically resets existing data before seeding so the endpoint
    is idempotent — safe to call multiple times.
    """
    try:
        backend = agent._backend
        db = backend._db()
        for table in (
            "memories", "directives", "directive_proposals",
            "dream_reports", "cost_records",
        ):
            db.execute(f"DELETE FROM {table}")  # noqa: S608
        db.commit()
        logger.info("Demo data cleared before re-seed")
    except Exception:
        logger.exception("Pre-seed reset failed")

    memory_count = 0
    for interaction in _SEED_INTERACTIONS:
        content = {
            "category": interaction["category"],
            "user_message": interaction["user_message"],
            "agent_response": interaction["agent_response"],
            "signal": interaction["signal"],
        }
        await agent.memory.capture(
            event_type="interaction",
            content=content,
            emotional_intensity=0.5,
        )
        memory_count += 1

    t1_ids = []
    try:
        backend = agent._backend
        db = backend._db()
        cursor = db.execute(
            "SELECT id FROM memories WHERE agent_id = ? ORDER BY created_at DESC LIMIT ?",
            (agent._agent_id, len(_SEED_INTERACTIONS)),
        )
        t1_ids = [row[0] for row in cursor.fetchall()]
    except Exception:
        pass

    consolidated_count = 0
    source_idx = 0
    for con in _SEED_CONSOLIDATED:
        source_ids = t1_ids[source_idx : source_idx + 3] if t1_ids else []
        source_idx += 3
        await agent.memory.capture(
            event_type="consolidated",
            content={"text": con["text"], "source_category": con["source_category"]},
            emotional_intensity=0.4,
        )
        consolidated_count += 1
        if source_ids:
            try:
                import json as _json
                mem_id_row = db.execute(
                    "SELECT id FROM memories WHERE agent_id = ? ORDER BY created_at DESC LIMIT 1",
                    (agent._agent_id,),
                ).fetchone()
                if mem_id_row:
                    db.execute(
                        "UPDATE memories SET tier = 2, source_ids = ? WHERE id = ?",
                        (_json.dumps(source_ids), mem_id_row[0]),
                    )
                    db.commit()
            except Exception:
                pass

    await agent.memory.capture(
        event_type="journal",
        content={"text": _SEED_JOURNAL},
        emotional_intensity=0.3,
    )
    try:
        mem_id_row = db.execute(
            "SELECT id FROM memories WHERE agent_id = ? ORDER BY created_at DESC LIMIT 1",
            (agent._agent_id,),
        ).fetchone()
        if mem_id_row:
            db.execute("UPDATE memories SET tier = 3 WHERE id = ?", (mem_id_row[0],))
            db.commit()
    except Exception:
        pass

    directive_count = 0
    for text in _SEED_DIRECTIVES:
        await agent.directives.add(text)
        directive_count += 1

    try:
        db.execute(
            "UPDATE directives SET usage_count = 3 WHERE agent_id = ? AND usage_count = 0",
            (agent._agent_id,),
        )
        db.commit()
    except Exception:
        pass

    logger.info(
        "Demo data seeded",
        extra={
            "memories": memory_count + consolidated_count + 1,
            "directives": directive_count,
        },
    )

    return {
        "seeded": True,
        "memories": memory_count + consolidated_count + 1,
        "directives": directive_count,
    }


@router.post("/progress-day")
async def progress_day(agent: Any = AgentDep) -> dict[str, Any]:
    """Simulate a day of agent activity: capture memories + trigger dream."""
    day_memories = [
        {
            "event_type": "interaction",
            "content": {
                "category": "support",
                "user_message": f"Simulated support query {uuid.uuid4().hex[:8]}",
                "agent_response": "Resolved with standard procedure.",
            },
        },
        {
            "event_type": "observation",
            "content": {
                "text": f"Pattern noticed: recurring question about feature {uuid.uuid4().hex[:8]}",
            },
        },
    ]

    captured = 0
    for mem in day_memories:
        await agent.memory.capture(
            event_type=mem["event_type"],
            content=mem["content"],
        )
        captured += 1

    dream_triggered = False
    try:
        await agent.dreams.trigger()
        dream_triggered = True
    except Exception:
        pass

    return {
        "memories_captured": captured,
        "dream_triggered": dream_triggered,
    }


@router.post("/reset")
async def reset_demo(agent: Any = AgentDep) -> dict[str, str]:
    """Reset agent state for a fresh demo."""
    try:
        backend = agent._backend
        db = backend._db()
        for table in (
            "memories", "directives", "directive_proposals",
            "dream_reports", "cost_records",
        ):
            db.execute(f"DELETE FROM {table}")  # noqa: S608
        db.commit()
    except Exception:
        logger.exception("Demo reset failed")
        return {"status": "partial_reset"}

    return {"status": "reset_complete"}
