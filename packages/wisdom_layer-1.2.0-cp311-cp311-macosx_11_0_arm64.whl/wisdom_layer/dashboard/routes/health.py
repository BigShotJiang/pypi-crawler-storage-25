"""Health API routes — cognitive vitals dashboard."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Query

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/health", tags=["health"])

AgentDep = Depends(get_agent)

logger = logging.getLogger(__name__)


def _to_dict(obj: Any) -> dict[str, Any]:
    """Coerce Pydantic model / dataclass / dict into a plain dict."""
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if hasattr(obj, "__dict__"):
        return obj.__dict__
    return {}


async def _compute_score_components(agent: Any) -> dict[str, float]:
    """Compute the 5 wisdom sub-scores from raw backend stats."""
    try:
        from wisdom_layer._internal.health import (
            compute_memory_diversity,
            compute_reinforcement_ratio,
        )

        stats = await agent._backend.get_health_report_stats(
            agent_id=agent._agent_id,
        )
        admin = agent._admin
        memory = stats.get("memory", {})
        dreams = stats.get("dreams", {})
        critic = stats.get("critic", {})
        journals = stats.get("journals", {})

        diversity = compute_memory_diversity(
            memory.get("event_type_counts", {}),
        )
        coherence = float(critic.get("pass_rate_7d", 1.0))

        dream_failures = int(dreams.get("failure_count_7d", 0))
        dream_runs = int(dreams.get("runs_7d", 0))
        dream_health = (
            1.0 - (dream_failures / dream_runs) if dream_runs > 0 else 0.5
        )

        reinforcement = compute_reinforcement_ratio(
            int(memory.get("reinforced_count", 0)),
            int(memory.get("total_memories", 0)),
        )

        target_days = getattr(admin, "wisdom_journal_target_days", 7)
        entries_7d = int(journals.get("entries_7d", 0))
        expected = 7.0 / target_days if target_days > 0 else 0.0
        journal_freq = (
            max(0.0, min(1.0, entries_7d / expected)) if expected > 0 else 0.0
        )

        return {
            "memory_diversity": round(diversity, 3),
            "directive_coherence": round(coherence, 3),
            "dream_health": round(dream_health, 3),
            "reinforcement_ratio": round(reinforcement, 3),
            "journal_frequency": round(journal_freq, 3),
        }
    except Exception:
        logger.debug("Could not compute score components", exc_info=True)
        return {}


def _serialize_report(
    report: Any,
    score_components: dict[str, float] | None = None,
) -> dict[str, Any]:
    """Flatten HealthReport into the shape the frontend expects."""
    raw = _to_dict(report)
    memory = _to_dict(raw.get("memory_stats", {}))
    directive = _to_dict(raw.get("directive_stats", {}))
    dream = _to_dict(raw.get("dream_stats", {}))
    cost = _to_dict(raw.get("cost_stats", {}))

    cognitive_health = raw.get("cognitive_health")
    classification = "healthy"
    if cognitive_health is not None:
        if isinstance(cognitive_health, str):
            classification = cognitive_health
        elif hasattr(cognitive_health, "value"):
            classification = cognitive_health.value
        else:
            classification = str(cognitive_health)

    total_memories = (
        memory.get("stream_count", 0)
        + memory.get("consolidated_count", 0)
        + memory.get("journal_count", 0)
    )

    return {
        "wisdom_score": raw.get("wisdom_score") or 0.0,
        "classification": classification,
        "stats": {
            "total_memories": total_memories,
            "total_directives": (
                directive.get("provisional_count", 0)
                + directive.get("active_count", 0)
                + directive.get("permanent_count", 0)
            ),
            "active_directives": directive.get("active_count", 0),
            "dream_cycles": dream.get("runs_7d", 0),
            "last_dream_at": dream.get("last_run_ago_hours"),
        },
        "memory_stats": memory,
        "directive_stats": directive,
        "dream_stats": dream,
        "cost_stats": cost,
        "score_components": score_components or {},
        "remedy_suggestion": _remedy_for(classification),
        "remedy_url": raw.get("remedy_url"),
    }


def _remedy_for(classification: str) -> str | None:
    """Human-readable suggestion for non-healthy states."""
    remedies = {
        "stagnant": (
            "This agent isn't receiving enough new experiences. "
            "Capture more interactions or observations to give the "
            "learning pipeline material to work with."
        ),
        "drifting": (
            "Directives are changing faster than they're stabilizing. "
            "Review the proposal queue and consider approving or "
            "rejecting pending changes to restore stability."
        ),
        "overloaded": (
            "Dream cycles are failing or budget limits are being hit. "
            "Check resource limits and budget configuration, or reduce "
            "dream frequency."
        ),
    }
    return remedies.get(classification)


@router.get("")
async def get_health(agent: Any = AgentDep) -> dict[str, Any]:
    """Current health report (wisdom_score, classifier, stats)."""
    report = await agent.health()
    components = await _compute_score_components(agent)
    return _serialize_report(report, score_components=components)


@router.get("/trajectory")
async def get_trajectory(
    days: int = Query(default=30, ge=1, le=365),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """Daily health snapshots over the last N days."""
    snapshots = await agent.health.trajectory(days=days)
    return [
        s if isinstance(s, dict) else s.__dict__
        for s in snapshots
    ]


@router.post("/snapshot")
async def capture_snapshot(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Force-capture a health snapshot now."""
    report = await agent.health.capture_snapshot()
    return _serialize_report(report)
