"""Memory API routes — search, capture, export, consolidate, decay."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, Path, Query
from pydantic import BaseModel, Field

from wisdom_layer.dashboard.server import get_agent


class CaptureRequest(BaseModel):
    """Body for POST /api/memory/capture."""

    event_type: str
    content: dict[str, Any]
    emotional_intensity: float = Field(default=0.0)

router = APIRouter(prefix="/api/memory", tags=["memory"])

AgentDep = Depends(get_agent)


@router.get("/search")
async def search_memories(
    query: str = Query(),
    limit: int = Query(default=5, ge=1, le=100),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """Semantic search over agent memories."""
    return await agent.memory.search(query, limit=limit)


@router.post("/capture")
async def capture_memory(
    body: CaptureRequest,
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Capture a new Tier 1 raw memory."""
    memory_id = await agent.memory.capture(
        body.event_type, body.content,
        emotional_intensity=body.emotional_intensity,
    )
    return {"memory_id": memory_id}


@router.get("/export")
async def export_memories(
    include_provenance: bool = Query(default=False),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Export all memories as a portable bundle."""
    return await agent.memory.export(include_provenance=include_provenance)


@router.post("/consolidate")
async def consolidate_memories(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Run memory consolidation (tier promotion)."""
    return await agent.memory.consolidate()


@router.post("/decay")
async def run_memory_decay(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Run memory decay pass (prune stale/low-salience memories)."""
    return await agent.memory.run_decay_pass()


@router.delete("/{memory_id}")
async def delete_memory(
    memory_id: str = Path(),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Delete a specific memory by ID."""
    result = await agent.memory.delete(memory_id)
    return result if isinstance(result, dict) else {"deleted": memory_id}


@router.post("/re-embed")
async def re_embed(
    batch_size: int = Body(default=100, embed=True),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Re-embed all memories with the current embedding model."""
    result = await agent.memory.reembed(batch_size=batch_size)
    return result if isinstance(result, dict) else {"result": str(result)}
