"""Cost API routes — spend visibility."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/cost", tags=["cost"])

AgentDep = Depends(get_agent)


@router.get("/summary")
async def get_cost_summary(
    window: str = Query(default="7d"),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Aggregate cost summary over window (e.g., '1d', '7d', '30d', 'all')."""
    result = await agent.cost.summary(window=window)
    raw = result if isinstance(result, dict) else (
        result.model_dump() if hasattr(result, "model_dump") else result.__dict__
    )

    budget = None
    try:
        budget_data = await agent.cost.budget()
        if hasattr(budget_data, "model_dump"):
            budget_data = budget_data.model_dump()
        elif not isinstance(budget_data, dict):
            budget_data = budget_data.__dict__ if hasattr(budget_data, "__dict__") else {}
        budget = budget_data
    except Exception:
        pass

    daily_cap = None
    if budget:
        daily_cap = budget.get("daily_cap_usd") or budget.get("daily_cap")

    return {
        "window": window,
        "total_cost": raw.get("total_usd", 0.0),
        "daily_cap": daily_cap,
        "daily_spend": raw.get("total_usd", 0.0),
        "breakdown": raw.get("by_category", {}),
    }
