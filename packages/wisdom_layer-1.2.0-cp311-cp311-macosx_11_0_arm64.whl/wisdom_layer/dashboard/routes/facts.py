"""Facts API routes — Pro-tier atomic fact subsystem.

Surfaces ``agent.facts.*`` to the dashboard: on-demand extraction,
semantic search, per-subject and per-memory listing, subject export,
and claim verification. Every route requires ``fact_extraction``
(Pro+); the SDK raises :class:`TierRestrictionError` which the global
exception middleware translates to a 402.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/facts", tags=["facts"])

AgentDep = Depends(get_agent)


@router.post("/extract/{memory_id}")
async def extract_facts(
    memory_id: str,
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Run on-demand fact extraction against a single memory."""
    persisted = await agent.facts.extract(memory_id)
    return {
        "memory_id": memory_id,
        "fact_count": len(persisted),
        "facts": persisted,
    }


@router.get("/search")
async def search_facts(
    query: str = Query(..., min_length=1),
    limit: int = Query(default=5, ge=1, le=50),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """Search facts by semantic similarity (substring fallback)."""
    return await agent.facts.search(query, limit=limit)


@router.get("/by-subject/{subject}")
async def list_for_subject(
    subject: str,
    limit: int = Query(default=50, ge=1, le=500),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """Return all stored facts about ``subject``, newest first."""
    return await agent.facts.list_for_subject(subject, limit=limit)


@router.get("/by-memory/{memory_id}")
async def list_for_memory(
    memory_id: str,
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """Return every fact extracted from a single source memory."""
    return await agent.facts.list_for_memory(memory_id)


@router.get("/export/{subject}")
async def export_subject(
    subject: str,
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Portable snapshot of every fact about ``subject``."""
    return await agent.facts.export_subject(subject)


@router.post("/verify-claim")
async def verify_claim(
    payload: dict[str, str],
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Check whether a stored fact matches an expected value."""
    return await agent.facts.verify_claim(
        subject=payload["subject"],
        attribute=payload["attribute"],
        expected_value=payload["expected_value"],
    )
