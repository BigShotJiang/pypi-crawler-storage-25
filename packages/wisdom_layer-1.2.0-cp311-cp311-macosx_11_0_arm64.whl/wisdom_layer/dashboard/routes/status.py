"""Status and version API routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Request

import wisdom_layer
from wisdom_layer.dashboard.routes.usage import compute_caps
from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api", tags=["status"])

AgentDep = Depends(get_agent)


@router.get("/status")
async def get_status(
    request: Request,
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Agent runtime status (tier, features, counts, evolution)."""
    raw = await agent.status()

    features_raw = raw.get("features", [])
    features = (
        {f: True for f in features_raw}
        if isinstance(features_raw, list)
        else features_raw
    )

    return {
        "tier": raw.get("tier", "free"),
        "features": features,
        "feature_flags": raw.get("feature_flags", {}),
        "counts": raw.get("counts", {}),
        "evolution_summary": raw.get("evolution_summary", {}),
        "caps": await compute_caps(agent),
        "demo_mode": getattr(request.app.state, "demo_mode", False),
    }


@router.get("/version")
async def get_version(agent: Any = AgentDep) -> dict[str, str]:
    """SDK version and agent metadata."""
    return {
        "sdk_version": wisdom_layer.__version__,
        "agent_id": agent.agent_id,
        "agent_name": agent.name,
    }
