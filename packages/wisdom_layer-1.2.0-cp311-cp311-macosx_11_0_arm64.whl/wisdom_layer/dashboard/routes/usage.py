"""Tier-cap progress API route.

Surfaces ``current`` vs ``limit`` for every Free-tier cap so the
dashboard can render progress widgets without polling the SDK directly.
On Pro / Enterprise / active-trial tiers the limits collapse to
``None`` (unlimited) and ``exceeded`` is always ``False``; the frontend
hides the matching widget.

Per BUSINESSFY/06_CAP_ENFORCEMENT_UX.md and BUSINESSFY/07.8.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, Depends

from wisdom_layer.dashboard.server import get_agent
from wisdom_layer.license import Tier

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

router = APIRouter(prefix="/api", tags=["usage"])

AgentDep = Depends(get_agent)


def _warning_at(limit: int | None, thresholds: tuple[float, ...]) -> int | None:
    """First (lowest) integer threshold at which the dashboard should
    color-shift the progress bar. Returns ``None`` when ``limit`` is
    unlimited or ``thresholds`` is empty."""
    if limit is None or not thresholds:
        return None
    return int(limit * min(thresholds))


async def compute_caps(agent: WisdomAgent) -> dict[str, Any]:
    """Snapshot the agent's cap counters into a serialisable dict.

    Reads:
        - Agent count via ``_agent_registry.count()``
        - Memory count via ``backend.get_agent_counts``
        - Message count via ``_usage_counter.message_count_30d`` (if
          ``initialize()`` has run; otherwise ``current=0``)
    Limits collapse to ``None`` on Pro / Enterprise / Trial — the
    same predicate ``_do_capture`` uses to skip cap enforcement.
    """
    effective_tier = agent._tier
    free = effective_tier == Tier.FREE
    limits = agent._config.resource_limits
    thresholds = agent._admin.cap_warning_thresholds

    agent_current = agent._agent_registry.count()
    agent_limit = limits.max_agents_free if free else None

    counts = await agent._backend.get_agent_counts(agent_id=agent._agent_id)
    memory_current = int(counts.get("memories", 0))
    memory_limit = limits.max_memories_free if free else None

    if agent._usage_counter is not None:
        message_current = agent._usage_counter.message_count_30d()
        reset_at_dt = agent._usage_counter.reset_at()
    else:
        message_current = 0
        reset_at_dt = None
    message_limit = limits.max_messages_per_30d_free if free else None
    reset_at = reset_at_dt.isoformat() if reset_at_dt else None

    def _exceeded(current: int, limit: int | None) -> bool:
        return limit is not None and current >= limit

    return {
        "tier": effective_tier.value,
        "agents": {
            "current": agent_current,
            "limit": agent_limit,
            "warning_at": _warning_at(agent_limit, thresholds),
            "exceeded": _exceeded(agent_current, agent_limit),
        },
        "memories": {
            "current": memory_current,
            "limit": memory_limit,
            "warning_at": _warning_at(memory_limit, thresholds),
            "exceeded": _exceeded(memory_current, memory_limit),
        },
        "messages_30d": {
            "current": message_current,
            "limit": message_limit,
            "warning_at": _warning_at(message_limit, thresholds),
            "exceeded": _exceeded(message_current, message_limit),
            "reset_at": reset_at,
        },
    }


@router.get("/usage/caps")
async def get_usage_caps(agent: Any = AgentDep) -> dict[str, Any]:
    """Return current cap usage and limits for every tier-cap kind."""
    return await compute_caps(agent)
