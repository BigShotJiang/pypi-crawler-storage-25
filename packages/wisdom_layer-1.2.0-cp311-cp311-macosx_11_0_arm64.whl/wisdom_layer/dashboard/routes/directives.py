"""Directive API routes — CRUD + proposals + lifecycle."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, Path, Query

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/directives", tags=["directives"])

AgentDep = Depends(get_agent)


@router.get("")
async def list_directives(
    include_inactive: bool = Query(default=False),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """List directives (active by default, optionally all)."""
    if include_inactive:
        return await agent.directives.all()
    return await agent.directives.active()


@router.post("")
async def add_directive(
    text: str = Body(embed=True),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Add a new directive (respects directive_evolution_mode)."""
    return await agent.directives.add(text)


@router.get("/export")
async def export_directives(
    include_inactive: bool = Query(default=True),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Export all directives as a portable bundle."""
    return await agent.directives.export(include_inactive=include_inactive)


@router.post("/decay")
async def run_decay(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Run directive decay pass."""
    return await agent.directives.run_decay()


@router.get("/proposals/pending")
async def list_proposals(
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """List pending directive proposals."""
    return await agent.directives.proposals()


@router.post("/proposals/{proposal_id}/approve")
async def approve_proposal(
    proposal_id: str = Path(),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Approve a pending directive proposal."""
    return await agent.directives.approve(proposal_id)


@router.post("/proposals/{proposal_id}/reject")
async def reject_proposal(
    proposal_id: str = Path(),
    reason: str = Body(default="", embed=True),
    agent: Any = AgentDep,
) -> None:
    """Reject a pending directive proposal."""
    await agent.directives.reject(proposal_id, reason=reason)


@router.get("/{directive_id}")
async def get_directive(
    directive_id: str = Path(),
    agent: Any = AgentDep,
) -> dict[str, Any] | None:
    """Fetch a single directive by ID."""
    return await agent.directives.get(directive_id)


@router.post("/{directive_id}/promote")
async def promote_directive(
    directive_id: str = Path(),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Promote a directive to the next lifecycle stage."""
    return await agent.directives.promote(directive_id)


@router.post("/{directive_id}/deactivate")
async def deactivate_directive(
    directive_id: str = Path(),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Deactivate a directive."""
    return await agent.directives.deactivate(directive_id)
