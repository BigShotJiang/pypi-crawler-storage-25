"""Configuration API routes — read-only agent config surface.

All reference data the dashboard needs (archetypes, field metadata,
valid enum values) is derived from the SDK's own classes. The frontend
must not maintain parallel copies of these constants.
"""

from __future__ import annotations

import dataclasses
from typing import Any

from fastapi import APIRouter, Depends

from wisdom_layer._internal.admin_defaults import AdminDefaults
from wisdom_layer.config import DreamConfig, PersonalityConfig
from wisdom_layer.config.flags import FeatureFlags
from wisdom_layer.config.limits import ResourceLimits
from wisdom_layer.config.lock import LockConfig
from wisdom_layer.dashboard.server import get_agent
from wisdom_layer.types import (
    CognitiveHealthStatus,
    DirectiveStatus,
    DreamPhase,
    MemoryTier,
)

router = APIRouter(prefix="/api/config", tags=["config"])

AgentDep = Depends(get_agent)


# ── Archetype registry ──────────────────────────────────────────
# Each entry maps a factory method to human-readable metadata.
# The field values come from calling the real factory at import time.

_ARCHETYPE_FACTORIES: list[tuple[str, str, str, AdminDefaults]] = [
    ("balanced", "Balanced", "General-purpose defaults",
     AdminDefaults.balanced()),
    ("research", "Research", "Deep accumulation, long retention",
     AdminDefaults.for_research()),
    ("coding", "Coding", "High churn, tight rules, fast cleanup",
     AdminDefaults.for_coding_assistant()),
    ("consumer_support", "Consumer Support",
     "End-user-facing service; user-respectful directive phrasing",
     AdminDefaults.for_consumer_support()),
    ("strategic", "Strategic",
     "High-stakes, strict coherence, institutional memory",
     AdminDefaults.for_strategic_advisors()),
    ("lightweight", "Lightweight", "Small models, minimal LLM calls",
     AdminDefaults.for_lightweight_local()),
]

_BALANCED = dataclasses.asdict(AdminDefaults.balanced())

_KEY_ARCHETYPE_FIELDS = [
    "salience_recency_half_life_days",
    "decay_factor",
    "weaken_days",
    "archive_days",
    "directive_max_volume",
    "coherence_threshold",
    "dream_evolve_max_per_cycle",
    "dream_evolve_temperature",
    "consolidation_max_inputs",
    "max_context_chars",
]


def _build_archetypes() -> list[dict[str, Any]]:
    """Build archetype profiles from real SDK factory methods."""
    result = []
    for key, name, tagline, instance in _ARCHETYPE_FACTORIES:
        all_fields = dataclasses.asdict(instance)
        key_fields = {k: all_fields[k] for k in _KEY_ARCHETYPE_FIELDS}
        tuned = [
            k for k in _KEY_ARCHETYPE_FIELDS
            if all_fields[k] != _BALANCED[k]
        ]
        result.append({
            "key": key,
            "name": name,
            "tagline": tagline,
            "fields": key_fields,
            "all_fields": all_fields,
            "tuned_fields": tuned,
        })
    return result


# ── Field metadata extractors ───────────────────────────────────

def _dataclass_field_info(cls: type) -> list[dict[str, Any]]:
    """Extract name, default, and type from a dataclass."""
    result = []
    for f in dataclasses.fields(cls):
        default = f.default if f.default is not dataclasses.MISSING else None
        result.append({
            "name": f.name,
            "default": default,
            "type": str(f.type),
        })
    return result


def _pydantic_field_info(cls: Any) -> list[dict[str, Any]]:
    """Extract name and default from a Pydantic model."""
    result = []
    for name, field_info in cls.model_fields.items():
        result.append({
            "name": name,
            "default": field_info.default,
        })
    return result


def _strenum_values(cls: Any) -> list[str]:
    """Extract string values from a StrEnum."""
    return [member.value for member in cls]


# ── Cached metadata (computed once at import) ───────────────────

_METADATA: dict[str, Any] = {
    "archetypes": _build_archetypes(),
    "personality_traits": _pydantic_field_info(PersonalityConfig),
    "feature_flags": _dataclass_field_info(FeatureFlags),
    "resource_limits": _dataclass_field_info(ResourceLimits),
    "lock_fields": _dataclass_field_info(LockConfig),
    "dream_phases": _strenum_values(DreamPhase),
    "dream_intensities": ["light", "standard", "deep"],
    "dream_defaults": DreamConfig().model_dump(),
    "directive_statuses": _strenum_values(DirectiveStatus),
    "health_classifications": _strenum_values(CognitiveHealthStatus),
    "memory_tiers": [
        {"value": t.value, "name": t.name.lower()} for t in MemoryTier
    ],
    "wisdom_components": [
        "memory_diversity",
        "directive_coherence",
        "dream_health",
        "reinforcement_ratio",
        "journal_frequency",
    ],
    "entropy_levels": ["healthy", "moderate", "high", "alert"],
    "archetype_field_order": _KEY_ARCHETYPE_FIELDS,
}


# ── Route handlers ──────────────────────────────────────────────


@router.get("")
async def get_config(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Full agent configuration snapshot."""
    config = agent._config
    return {
        "agent_id": agent._agent_id,
        "name": config.name,
        "role": config.role,
        "personality": config.personality.model_dump(),
        "dreams": config.dreams.model_dump(),
        "feature_flags": config.feature_flags.__dict__,
        "resource_limits": config.resource_limits.__dict__,
        "lock": config.lock.__dict__,
        "session": config.session.__dict__,
        "admin_defaults": agent._admin.__dict__,
        "tier": str(agent.tier),
        "retry_policy": (
            config.retry_policy.__dict__ if config.retry_policy else None
        ),
        "shutdown_timeout_s": config.shutdown_timeout_s,
    }


@router.get("/metadata")
async def get_metadata() -> dict[str, Any]:
    """SDK-derived reference data for the dashboard UI.

    Returns archetypes, valid enum values, field metadata, and defaults
    — all introspected from the SDK's own classes. The frontend should
    use this as its single source of truth for config reference data.
    """
    return _METADATA


@router.get("/personality")
async def get_personality(
    agent: Any = AgentDep,
) -> dict[str, float]:
    """Agent personality parameters."""
    return agent._config.personality.model_dump()


@router.get("/feature-flags")
async def get_feature_flags(
    agent: Any = AgentDep,
) -> dict[str, bool]:
    """Feature flag states."""
    return agent._config.feature_flags.__dict__


@router.get("/resource-limits")
async def get_resource_limits(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Resource limit configuration."""
    return agent._config.resource_limits.__dict__


@router.get("/lock")
async def get_lock_config(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Lock configuration (memory_mode, directive_evolution_mode, freeze_decay)."""
    return agent._config.lock.__dict__


@router.get("/budget")
async def get_budget_config(
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Budget configuration."""
    guard = agent._budget_guard
    if guard is None:
        return {"configured": False}
    return {
        "configured": True,
        **guard.config.__dict__,
    }
