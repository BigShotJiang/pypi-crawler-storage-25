"""Journal API routes — history, retrieval, synthesis."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Path, Query

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/journals", tags=["journals"])

AgentDep = Depends(get_agent)


@router.get("")
async def list_journals(
    limit: int = Query(default=10, ge=1, le=100),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """List journal entries, most recent first."""
    return await agent.journals.history(limit=limit)


@router.get("/{journal_id}")
async def get_journal(
    journal_id: str = Path(),
    agent: Any = AgentDep,
) -> dict[str, Any] | None:
    """Fetch a single journal entry by ID."""
    return await agent.journals.get(journal_id)
