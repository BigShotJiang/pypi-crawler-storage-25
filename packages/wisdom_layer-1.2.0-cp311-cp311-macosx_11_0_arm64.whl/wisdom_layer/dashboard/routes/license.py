"""License / trial state API route.

Surfaces the trial mechanic to the dashboard: ``trial_ends_at``,
``tier_at_expiry``, and the live computed ``effective_tier`` /
``is_in_trial`` flags. The frontend renders ``TrialCountdownCard``
from this payload.

Stateless in the SDK — every read recomputes against
``agent._clock.now()`` and the JWT-carried claims, so a long-running
dashboard automatically sees the trial expire mid-session.

Per BUSINESSFY/04_TRIAL_MECHANIC.md and BUSINESSFY/07.8.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, Depends

from wisdom_layer.dashboard.server import get_agent

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

router = APIRouter(prefix="/api", tags=["license"])

AgentDep = Depends(get_agent)


@router.get("/license/trial")
async def get_license_trial(agent: Any = AgentDep) -> dict[str, Any]:
    """Return trial-state for the current license.

    Shape::

        {
            "is_in_trial": bool,
            "trial_ends_at": iso str | null,
            "tier_at_expiry": "free" | "pro" | "enterprise" | null,
            "effective_tier": "free" | "pro" | "enterprise",
            "contracted_tier": "free" | "pro" | "enterprise",
        }

    Non-trial licenses (and anonymous Free, which has no claims at all)
    return ``is_in_trial=false`` with both ``trial_ends_at`` and
    ``tier_at_expiry`` null. ``effective_tier`` always reflects what the
    agent is currently treated as — that's the value the cap routes and
    feature gates compare against.
    """
    wisdom_agent: WisdomAgent = agent
    now = wisdom_agent._clock.now()
    claims = wisdom_agent._claims

    if claims is None:
        return {
            "is_in_trial": False,
            "trial_ends_at": None,
            "tier_at_expiry": None,
            "effective_tier": wisdom_agent._tier_contract.value,
            "contracted_tier": wisdom_agent._tier_contract.value,
        }

    return {
        "is_in_trial": claims.is_in_trial(now),
        "trial_ends_at": (
            claims.trial_ends_at.isoformat()
            if claims.trial_ends_at is not None
            else None
        ),
        "tier_at_expiry": claims.tier_at_expiry,
        "effective_tier": claims.effective_tier(now),
        "contracted_tier": wisdom_agent._tier_contract.value,
    }
