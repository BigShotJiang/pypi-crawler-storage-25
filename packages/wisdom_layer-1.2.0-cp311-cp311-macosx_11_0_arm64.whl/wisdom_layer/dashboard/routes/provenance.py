"""Provenance API routes — trace, explain, export."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/provenance", tags=["provenance"])

AgentDep = Depends(get_agent)


@router.get("/trace")
async def trace(
    entity_id: str = Query(),
    limit: int = Query(default=200, ge=1, le=1000),
    agent: Any = AgentDep,
) -> list[dict[str, Any]]:
    """Get the provenance chain for an entity."""
    return await agent.provenance.trace(entity_id, limit=limit)


@router.get("/explain")
async def explain(
    entity_id: str = Query(),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Get a human-readable explanation of an entity's provenance."""
    return await agent.provenance.explain(entity_id)


@router.get("/export")
async def export_provenance(
    since: str | None = Query(default=None),
    until: str | None = Query(default=None),
    limit: int = Query(default=500, ge=1, le=5000),
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Export a time-windowed slice of the provenance log."""
    return await agent.provenance.export(since=since, until=until, limit=limit)
