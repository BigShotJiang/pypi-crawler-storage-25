"""Chat API route — baseline vs memory-only vs wisdom-augmented comparison."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from wisdom_layer.dashboard.server import get_agent

router = APIRouter(prefix="/api/chat", tags=["chat"])

AgentDep = Depends(get_agent)

logger = logging.getLogger(__name__)


class ChatRequest(BaseModel):
    """Body for POST /api/chat."""

    question: str
    mode: str = "compare"


async def _baseline_answer(
    llm: Any,
    clock: Any,
    question: str,
) -> tuple[str, int]:
    """Plain LLM call — no memory, no directives."""
    t0 = clock.monotonic()
    result = await llm.generate(
        messages=[{"role": "user", "content": question}],
        system="You are a helpful assistant. Answer concisely.",
    )
    ms = round((clock.monotonic() - t0) * 1000)
    return (result if isinstance(result, str) else str(result)), ms


async def _gather_context(
    agent: Any,
    question: str,
) -> tuple[list[str], list[str]]:
    """Retrieve relevant memories and active directives."""
    memory_context: list[str] = []
    directive_context: list[str] = []

    try:
        memories = await agent.memory.search(question, limit=5)
        memory_context = [
            str(m.get("content", m.get("text", "")))
            for m in memories
        ]
    except Exception:
        logger.debug("Memory search failed", exc_info=True)

    try:
        directives = await agent.directives.active()
        directive_context = [
            str(d.get("text", ""))
            for d in directives[:10]
        ]
    except Exception:
        logger.debug("Directive fetch failed", exc_info=True)

    return memory_context, directive_context


async def _memory_only_answer(
    llm: Any,
    clock: Any,
    question: str,
    memory_context: list[str],
) -> tuple[str, int]:
    """LLM call with memory context but no directives."""
    system = (
        "You are a helpful assistant with access to past interactions. "
        "Use the provided memories to give a grounded, relevant answer. "
        "Answer concisely."
    )
    if memory_context:
        system += (
            "\n\nRELEVANT MEMORIES:\n"
            + "\n".join(f"- {m}" for m in memory_context)
        )

    t0 = clock.monotonic()
    result = await llm.generate(
        messages=[{"role": "user", "content": question}],
        system=system,
    )
    ms = round((clock.monotonic() - t0) * 1000)
    return (result if isinstance(result, str) else str(result)), ms


async def _wisdom_answer(
    llm: Any,
    clock: Any,
    question: str,
    memory_context: list[str],
    directive_context: list[str],
) -> tuple[str, int]:
    """LLM call with both memory context and directive guidance."""
    system = (
        "You are a helpful assistant augmented with the agent's memories "
        "and behavioral directives. Use the provided context to give a "
        "grounded, relevant answer. Cite specific memories when applicable. "
        "Answer concisely."
    )
    context_parts: list[str] = []
    if memory_context:
        context_parts.append(
            "RELEVANT MEMORIES:\n"
            + "\n".join(f"- {m}" for m in memory_context),
        )
    if directive_context:
        context_parts.append(
            "ACTIVE DIRECTIVES:\n"
            + "\n".join(f"- {d}" for d in directive_context),
        )
    if context_parts:
        system += "\n\n" + "\n\n".join(context_parts)

    t0 = clock.monotonic()
    result = await llm.generate(
        messages=[{"role": "user", "content": question}],
        system=system,
    )
    ms = round((clock.monotonic() - t0) * 1000)
    return (result if isinstance(result, str) else str(result)), ms


@router.post("")
async def chat(
    body: ChatRequest,
    agent: Any = AgentDep,
) -> dict[str, Any]:
    """Answer a question across up to three cognitive layers.

    Modes:
        baseline  — model only, no context
        memory    — past interactions, no learned rules
        compare   — baseline + wisdom (default)
        all       — all three layers side-by-side
    """
    clock = agent._clock
    llm = agent._model

    baseline_text: str | None = None
    baseline_ms: int | None = None
    memory_text: str | None = None
    memory_ms: int | None = None
    wisdom_text: str | None = None
    wisdom_ms_val: int | None = None
    memory_context: list[str] = []
    directive_context: list[str] = []

    needs_baseline = body.mode in ("baseline", "compare", "all")
    needs_memory = body.mode in ("memory", "all")
    needs_wisdom = body.mode in ("compare", "all")

    if needs_baseline:
        baseline_text, baseline_ms = await _baseline_answer(
            llm, clock, body.question,
        )

    if needs_memory or needs_wisdom:
        memory_context, directive_context = await _gather_context(
            agent, body.question,
        )

    if needs_memory:
        memory_text, memory_ms = await _memory_only_answer(
            llm, clock, body.question, memory_context,
        )

    if needs_wisdom:
        wisdom_text, wisdom_ms_val = await _wisdom_answer(
            llm, clock, body.question, memory_context, directive_context,
        )

    return {
        "question": body.question,
        "mode": body.mode,
        "baseline_answer": baseline_text,
        "baseline_latency_ms": baseline_ms,
        "memory_answer": memory_text,
        "memory_latency_ms": memory_ms,
        "wisdom_answer": wisdom_text,
        "wisdom_latency_ms": wisdom_ms_val,
        "memory_count": len(memory_context),
        "directive_count": len(directive_context),
        "memories_used": memory_context,
        "directives_used": directive_context,
    }
