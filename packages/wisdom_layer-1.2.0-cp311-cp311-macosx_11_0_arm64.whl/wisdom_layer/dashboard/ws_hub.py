"""WebSocket hub that forwards SDK events to connected dashboard clients."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from fastapi import WebSocket

    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)

_SDK_EVENTS = [
    "agent.initialized",
    "agent.closed",
    "memory.captured",
    "memory.consolidated",
    "memory.consolidation_started",
    "memory.consolidation_failed",
    "memory.deleted",
    "memory.session_deleted",
    "memory.agent_deleted",
    "memory.decay_pass_completed",
    "memory.session_pruned",
    "memory.dedup_marked",
    "memory.capture_suppressed",
    "memory.searched",
    "memory.reembedded",
    "memory.exported",
    "memory.imported",
    "memory.session_started",
    "memory.session_ended",
    "memory.subject_forgotten",
    "fact.extracted",
    "respond.completed",
    "dream.started",
    "dream.step_completed",
    "dream.completed",
    "dream.scheduled.start",
    "dream.scheduled.complete",
    "dream.scheduled.failed",
    "dream.scheduled.skipped",
    "directive.added",
    "directive.promoted",
    "directive.revoked",
    "directive.write_blocked",
    "directive.proposed",
    "directive.proposal_approved",
    "directive.proposal_rejected",
    "directive.evolution_completed",
    "directive.decay_completed",
    "directive.exported",
    "directive.imported",
    "directive.reset",
    "critic.review_completed",
    "critic.audit_completed",
    "journal.written",
    "journal.synthesized",
    "health.snapshot",
]

FLUSH_INTERVAL_S = 0.1


class WebSocketHub:
    """Broadcast SDK events to all connected WebSocket clients."""

    def __init__(self) -> None:
        self._clients: set[WebSocket] = set()
        self._buffer: list[dict[str, Any]] = []
        self._flush_task: asyncio.Task[None] | None = None
        self._tokens: list[Any] = []
        self._agent: WisdomAgent | None = None

    def attach(self, agent: WisdomAgent) -> None:
        """Subscribe to all SDK events on the agent's event bus."""
        self._agent = agent
        for event_name in _SDK_EVENTS:
            token = agent.on(event_name, self._on_sdk_event)
            self._tokens.append(token)
        self._flush_task = asyncio.create_task(self._flush_loop())

    def detach(self, agent: WisdomAgent) -> None:
        """Unsubscribe from the agent's event bus."""
        self._agent = None
        for token in self._tokens:
            agent.off(token)
        self._tokens.clear()
        if self._flush_task is not None:
            self._flush_task.cancel()
            self._flush_task = None

    async def connect(self, ws: WebSocket) -> None:
        """Accept and register a WebSocket client."""
        await ws.accept()
        self._clients.add(ws)
        logger.info(
            "Dashboard WS client connected",
            extra={"client_count": len(self._clients)},
        )

    def disconnect(self, ws: WebSocket) -> None:
        """Remove a WebSocket client."""
        self._clients.discard(ws)

    def _on_sdk_event(self, event: Any) -> None:
        """Buffer an SDK event for the next flush."""
        clock = self._agent._clock if self._agent is not None else None
        ts = clock.now().isoformat() if clock else ""
        self._buffer.append({
            "type": event.name,
            "timestamp": ts,
            "data": event.data if hasattr(event, "data") else {},
        })

    async def _flush_loop(self) -> None:
        """Periodically flush buffered events to all clients."""
        while True:
            await asyncio.sleep(FLUSH_INTERVAL_S)
            if not self._buffer or not self._clients:
                self._buffer.clear()
                continue
            batch = self._buffer[:]
            self._buffer.clear()
            payload = json.dumps(batch)
            dead: list[WebSocket] = []
            for ws in self._clients:
                try:
                    await ws.send_text(payload)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self._clients.discard(ws)

    @property
    def client_count(self) -> int:
        """Number of connected WebSocket clients."""
        return len(self._clients)
