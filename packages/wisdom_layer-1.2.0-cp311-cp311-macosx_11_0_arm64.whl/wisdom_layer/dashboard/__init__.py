"""Optional dashboard server for the Wisdom Layer SDK.

Requires the ``dashboard`` extra: ``pip install wisdom-layer[dashboard]``
"""

from __future__ import annotations

from wisdom_layer.dashboard.server import DashboardServer, mount_dashboard

__all__ = ["DashboardServer", "mount_dashboard"]
