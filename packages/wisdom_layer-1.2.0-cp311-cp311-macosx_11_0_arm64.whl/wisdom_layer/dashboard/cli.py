"""CLI entry point: ``wisdom-layer-dashboard``."""

from __future__ import annotations

import argparse
import logging
import sys

logger = logging.getLogger(__name__)


def main(argv: list[str] | None = None) -> None:
    """Launch the Wisdom Layer dashboard server."""
    parser = argparse.ArgumentParser(
        description="Wisdom Layer Dashboard — cognitive architecture visibility",
        epilog=(
            "GitHub: https://github.com/rhatigan-agi/wisdom-layer "
            "· Star if useful · Report issues there"
        ),
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Bind host (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8741,
        help="Bind port (default: 8741)",
    )
    parser.add_argument(
        "--db",
        default="wisdom.db",
        help="SQLite database path (default: wisdom.db)",
    )
    parser.add_argument(
        "--agent-id",
        default="dashboard-agent",
        help="Agent ID to load (default: dashboard-agent)",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Log level (default: INFO)",
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        default=False,
        help="Mount demo routes (seed, progress-day, reset)",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    try:
        import uvicorn
    except ImportError:
        logger.error(
            "uvicorn not found. Install with: pip install wisdom-layer[dashboard]",
        )
        sys.exit(1)

    from wisdom_layer.dashboard._bootstrap import create_app

    app = create_app(
        db_path=args.db,
        agent_id=args.agent_id,
        demo=args.demo,
    )

    logger.info(
        "Starting dashboard",
        extra={"host": args.host, "port": args.port, "db": args.db},
    )
    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
