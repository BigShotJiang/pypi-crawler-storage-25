"""Bootstrap helper for the ``wisdom-layer-dashboard`` CLI.

Creates a :class:`WisdomAgent` from a SQLite database and an auto-detected
LLM adapter, then returns a mounted FastAPI app.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING

from wisdom_layer.agent import WisdomAgent
from wisdom_layer.config import AgentConfig
from wisdom_layer.dashboard.server import mount_dashboard
from wisdom_layer.storage.sqlite import SQLiteBackend

if TYPE_CHECKING:
    from fastapi import FastAPI

logger = logging.getLogger(__name__)


def _resolve_llm() -> object:
    """Auto-detect an LLM adapter from environment variables.

    Checks for API keys in order: Anthropic, OpenAI, Gemini, Ollama, LiteLLM.
    Falls back to :class:`FakeLLMAdapter` when nothing is configured
    (dashboard still works for browsing stored data).
    """
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
    if anthropic_key:
        from wisdom_layer.llm.anthropic import AnthropicAdapter

        logger.info("Using Anthropic adapter", extra={"source": "env"})
        return AnthropicAdapter(api_key=anthropic_key)

    openai_key = os.environ.get("OPENAI_API_KEY")
    if openai_key:
        from wisdom_layer.llm.openai import OpenAIAdapter

        logger.info("Using OpenAI adapter", extra={"source": "env"})
        return OpenAIAdapter(api_key=openai_key)

    gemini_key = os.environ.get("GOOGLE_API_KEY") or os.environ.get("GEMINI_API_KEY")
    if gemini_key:
        from wisdom_layer.llm.gemini import GeminiAdapter

        logger.info("Using Gemini adapter", extra={"source": "env"})
        return GeminiAdapter(api_key=gemini_key)

    ollama_host = os.environ.get("OLLAMA_HOST")
    if ollama_host:
        from wisdom_layer.llm.ollama import OllamaAdapter

        logger.info("Using Ollama adapter", extra={"host": ollama_host})
        return OllamaAdapter(base_url=ollama_host)

    litellm_model = os.environ.get("LITELLM_MODEL")
    litellm_embedding_model = os.environ.get("LITELLM_EMBEDDING_MODEL")
    if litellm_model and litellm_embedding_model:
        from wisdom_layer.llm.litellm import LiteLLMAdapter

        logger.info(
            "Using LiteLLM adapter",
            extra={
                "model": litellm_model,
                "embedding_model": litellm_embedding_model,
            },
        )
        return LiteLLMAdapter(
            model=litellm_model,
            embedding_model=litellm_embedding_model,
        )

    if litellm_model and not litellm_embedding_model:
        logger.warning(
            "LITELLM_MODEL is set but LITELLM_EMBEDDING_MODEL is not. "
            "LiteLLM requires both to construct an adapter; falling back "
            "to placeholder LLM. Set LITELLM_EMBEDDING_MODEL to enable.",
        )

    from wisdom_layer.testing.llm import FakeLLMAdapter

    logger.warning(
        "No LLM API key found in environment. Chat features will return "
        "placeholder responses. Set ANTHROPIC_API_KEY, OPENAI_API_KEY, "
        "GOOGLE_API_KEY, OLLAMA_HOST, or LITELLM_MODEL + "
        "LITELLM_EMBEDDING_MODEL to enable real LLM calls.",
    )
    return FakeLLMAdapter()


def create_app(
    *,
    db_path: str = "wisdom.db",
    agent_id: str = "dashboard-agent",
    demo: bool = False,
) -> FastAPI:
    """Create a ready-to-serve dashboard app from CLI arguments.

    The agent is created synchronously (constructor only); full async
    initialization happens in the FastAPI lifespan handler.

    Args:
        db_path: Path to the SQLite database file.
        agent_id: Agent ID to use for the dashboard session.
        demo: If True, mount the demo routes (seed, progress-day, reset).

    Returns:
        A FastAPI application ready for ``uvicorn.run()``.
    """
    llm = _resolve_llm()
    backend = SQLiteBackend(db_path, embed_fn=getattr(llm, "embed", None))

    config = AgentConfig(
        name=agent_id,
        role="Dashboard viewer",
        api_key=os.environ.get("WISDOM_LAYER_LICENSE", ""),
    )

    agent = WisdomAgent(
        agent_id=agent_id,
        config=config,
        llm=llm,  # type: ignore[arg-type]
        backend=backend,
    )

    extra_routers = []
    if demo:
        from wisdom_layer.dashboard.routes.demo import router as demo_router

        extra_routers.append(demo_router)

    logger.info(
        "Dashboard agent created",
        extra={"agent_id": agent_id, "db_path": db_path, "demo": demo},
    )

    return mount_dashboard(agent, extra_routers=extra_routers)
