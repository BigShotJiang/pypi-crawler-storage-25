"""DashboardServer — FastAPI app factory for the Wisdom Layer dashboard."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from wisdom_layer.dashboard.middleware import register_exception_handlers
from wisdom_layer.dashboard.ws_hub import WebSocketHub

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)

_STATIC_DIR = Path(__file__).parent / "_static"


def get_agent(request: Request) -> WisdomAgent:
    """FastAPI dependency: retrieve the agent from app state."""
    return request.app.state.agent


class DashboardServer:
    """Manages a FastAPI application wired to a WisdomAgent.

    Args:
        agent: The agent instance to expose via the dashboard API.
        title: OpenAPI title for the app.
    """

    def __init__(
        self,
        agent: WisdomAgent,
        *,
        title: str = "Wisdom Layer Dashboard",
        extra_routers: list[Any] | None = None,
    ) -> None:
        self._agent = agent
        self._hub = WebSocketHub()
        self._title = title
        self._extra_routers = extra_routers or []
        self._app: FastAPI | None = None

    def app(self) -> FastAPI:
        """Build and return the FastAPI application."""
        if self._app is not None:
            return self._app

        hub = self._hub
        agent = self._agent

        @asynccontextmanager
        async def lifespan(application: FastAPI) -> AsyncIterator[None]:
            if not agent._validated:
                await agent.initialize()
            hub.attach(agent)
            logger.info(
                "Dashboard server started",
                extra={"agent_id": agent.agent_id},
            )
            yield
            hub.detach(agent)

        application = FastAPI(title=self._title, lifespan=lifespan)
        application.state.agent = agent
        application.state.demo_mode = len(self._extra_routers) > 0

        application.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

        register_exception_handlers(application)

        from wisdom_layer.dashboard.routes import (
            chat,
            config,
            cost,
            critic,
            directives,
            dreams,
            facts,
            health,
            journals,
            memory,
            provenance,
            status,
            usage,
        )
        from wisdom_layer.dashboard.routes import (
            license as license_route,
        )

        for mod in (
            health, status, cost, directives, critic,
            memory, dreams, journals, provenance, config, chat, facts,
            usage, license_route,
        ):
            application.include_router(mod.router)

        for extra_router in self._extra_routers:
            application.include_router(extra_router)

        @application.websocket("/ws")
        async def websocket_endpoint(ws: WebSocket) -> None:
            await hub.connect(ws)
            try:
                while True:
                    await ws.receive_text()
            except WebSocketDisconnect:
                hub.disconnect(ws)

        if _STATIC_DIR.is_dir():
            application.mount(
                "/",
                StaticFiles(directory=str(_STATIC_DIR), html=True),
                name="static",
            )

        self._app = application
        return application


def mount_dashboard(
    agent: WisdomAgent,
    *,
    extra_routers: list[Any] | None = None,
    **kwargs: Any,
) -> FastAPI:
    """Convenience function: create a DashboardServer and return its app.

    Args:
        agent: The WisdomAgent to expose.
        extra_routers: Additional APIRouters to include (e.g. demo routes).
        **kwargs: Passed to DashboardServer constructor.

    Returns:
        A configured FastAPI application ready for uvicorn.
    """
    server = DashboardServer(agent, extra_routers=extra_routers, **kwargs)
    return server.app()
