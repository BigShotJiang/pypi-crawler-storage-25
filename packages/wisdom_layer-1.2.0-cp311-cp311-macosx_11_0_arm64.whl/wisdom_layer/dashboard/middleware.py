"""Shared exception handling for dashboard API routes."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from fastapi.responses import JSONResponse

if TYPE_CHECKING:
    from fastapi import FastAPI, Request

logger = logging.getLogger(__name__)


def register_exception_handlers(app: FastAPI) -> None:
    """Map SDK exceptions to HTTP status codes."""
    from wisdom_layer.errors import (
        AgentLockedError,
        ConfigError,
        DirectiveDuplicateError,
        FeatureDisabledError,
        MemoryFrozenError,
        ModelAdapterError,
        StorageError,
        TierRestrictionError,
    )

    @app.exception_handler(TierRestrictionError)
    async def _tier_restriction(
        _request: Request, exc: TierRestrictionError,
    ) -> JSONResponse:
        # Cap-violation path → 402 Payment Required with structured body
        # so the frontend can render a context-specific upgrade card.
        # Per BUSINESSFY/06_CAP_ENFORCEMENT_UX.md.
        if exc.cap_kind is not None:
            reset_at = exc.reset_at.isoformat() if exc.reset_at else None
            return JSONResponse(
                status_code=402,
                content={
                    "error": "tier_cap_reached",
                    "detail": str(exc),
                    "cap_kind": exc.cap_kind,
                    "current": exc.current,
                    "limit": exc.limit,
                    "reset_at": reset_at,
                    "upgrade_url": exc.upgrade_url,
                },
            )
        # Feature-gate path → 403 Forbidden (legacy contract preserved).
        return JSONResponse(
            status_code=403,
            content={
                "error": "tier_restriction",
                "detail": str(exc),
                "feature": exc.feature,
                "required_tier": exc.required_tier,
                "upgrade_url": exc.upgrade_url,
            },
        )

    @app.exception_handler(FeatureDisabledError)
    async def _feature_disabled(
        _request: Request, exc: FeatureDisabledError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=403,
            content={"error": "feature_disabled", "detail": str(exc)},
        )

    @app.exception_handler(MemoryFrozenError)
    async def _memory_frozen(
        _request: Request, exc: MemoryFrozenError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=409,
            content={"error": "memory_frozen", "detail": str(exc)},
        )

    @app.exception_handler(AgentLockedError)
    async def _agent_locked(
        _request: Request, exc: AgentLockedError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=409,
            content={"error": "agent_locked", "detail": str(exc)},
        )

    @app.exception_handler(StorageError)
    async def _storage_error(
        _request: Request, exc: StorageError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=503,
            content={"error": "storage_error", "detail": str(exc)},
        )

    @app.exception_handler(DirectiveDuplicateError)
    async def _directive_duplicate(
        _request: Request, exc: DirectiveDuplicateError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=409,
            content={"error": "directive_duplicate", "detail": str(exc)},
        )

    @app.exception_handler(ModelAdapterError)
    async def _model_adapter_error(
        _request: Request, exc: ModelAdapterError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=503,
            content={"error": "model_adapter_error", "detail": str(exc)},
        )

    @app.exception_handler(ConfigError)
    async def _config_error(
        _request: Request, exc: ConfigError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=400,
            content={"error": "config_error", "detail": str(exc)},
        )

    @app.exception_handler(ValueError)
    async def _value_error(
        _request: Request, exc: ValueError,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=400,
            content={"error": "validation_error", "detail": str(exc)},
        )
