"""Opt-in signal handlers for graceful agent shutdown."""

from __future__ import annotations

import asyncio
import logging
import signal
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)

_original_handlers: dict[int, Any] = {}


def install_signal_handlers(agent: WisdomAgent) -> None:
    """Register SIGTERM/SIGINT handlers that trigger ``agent.close()``.

    Only works when an asyncio event loop is running. Call this after
    ``agent.initialize()`` to ensure the agent is ready for shutdown.

    Args:
        agent: The agent instance to close on signal.
    """
    loop = asyncio.get_running_loop()

    def _handler(signum: int, _frame: object) -> None:
        sig_name = signal.Signals(signum).name
        logger.info(
            "Received %s — initiating graceful shutdown",
            sig_name,
            extra={"agent_id": agent._agent_id, "signal": sig_name},
        )
        loop.create_task(agent.close())

    for sig in (signal.SIGTERM, signal.SIGINT):
        _original_handlers[sig] = signal.getsignal(sig)
        signal.signal(sig, _handler)


def uninstall_signal_handlers() -> None:
    """Restore original signal handlers."""
    for sig, handler in _original_handlers.items():
        signal.signal(sig, handler)
    _original_handlers.clear()
