"""FrozenClock — deterministic :class:`Clock` implementation for tests.

This module is the *single source of truth* for ``FrozenClock``. It is
re-exported in two places:

- ``wisdom_layer.clock`` — for use by the internal SDK test suite
- ``wisdom_layer.testing.clock`` (lands in Phase 0.10) — the public surface
  customers may import from in their own tests

Both re-exports point at this implementation so the two never drift apart.

The class is intentionally minimal: it only freezes time. Any time-aware
behaviour a test needs — sleeping, retrying, expiring TTLs — composes on
top by calling ``advance(seconds=...)`` between assertions.

Doc reference: ``01_memory_architecture.md`` §"Time source (Clock protocol)",
``06_extraction_plan.md`` §0.1.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import TracebackType

__all__ = ["FrozenClock"]


# A fixed reproducible epoch — never the real "now". Tests that depend on a
# specific date should call freeze_at() explicitly. The default exists only
# so a bare FrozenClock() is meaningful and machine-independent.
_DEFAULT_EPOCH = datetime(2026, 1, 1, 0, 0, 0, tzinfo=UTC)


@dataclass
class FrozenClock:
    """A :class:`Clock` that only advances when explicitly told to.

    Wall-clock time (:meth:`now`) and the monotonic counter (:meth:`monotonic`)
    advance in lockstep with :meth:`advance`. They start at the value passed
    to the constructor (defaults to ``2026-01-01T00:00:00Z`` so test runs are
    reproducible across machines and timezones).

    Example::

        clock = FrozenClock()
        t0 = clock.now()
        clock.advance(seconds=30)
        t1 = clock.now()
        assert (t1 - t0).total_seconds() == 30

    The class also implements the context-manager protocol so the form
    ``with clock.advance(seconds=30): ...`` reads top-down in tests. The
    advance is always cumulative — there is no "rewind on exit". The
    context-manager form is purely a syntax flourish; the state mutation
    happens on the call to :meth:`advance`, not on entering the block.
    """

    _now: datetime = field(default_factory=lambda: _DEFAULT_EPOCH)
    _monotonic: float = 0.0

    def now(self) -> datetime:
        """Return the current frozen wall-clock time as a UTC-aware datetime."""
        return self._now

    def monotonic(self) -> float:
        """Return the current frozen monotonic seconds value."""
        return self._monotonic

    def freeze_at(self, dt: datetime) -> None:
        """Set the wall-clock time to a specific instant.

        The monotonic counter is *not* reset — only :meth:`now` jumps. Tests
        that need a specific monotonic origin should construct a new
        :class:`FrozenClock` rather than mixing :meth:`freeze_at` with
        :meth:`advance` semantics.

        Args:
            dt: A timezone-aware datetime. Naive datetimes are rejected
                because the SDK is UTC-only and silent timezone coercion
                is a class of bug we don't want to enable in tests.

        Raises:
            ValueError: If ``dt`` is naive (``dt.tzinfo is None``).
        """
        if dt.tzinfo is None:
            raise ValueError(
                "FrozenClock.freeze_at requires a timezone-aware datetime; "
                "got naive datetime. Use datetime(..., tzinfo=timezone.utc)."
            )
        self._now = dt.astimezone(UTC)

    def advance(self, *, seconds: float) -> FrozenClock:
        """Advance both wall-clock and monotonic time by ``seconds``.

        Returns ``self`` so the result is usable as a context manager:

        ::

            with clock.advance(seconds=30):
                ...   # the state mutation already happened on the call

        The CM form is a no-op on enter/exit — it exists purely so tests
        can read top-down. The advance is always cumulative.

        Args:
            seconds: A non-negative duration in seconds. May be a float
                (e.g. ``0.001`` for sub-second windows).

        Returns:
            ``self`` (for context-manager use).

        Raises:
            ValueError: If ``seconds`` is negative.
        """
        if seconds < 0:
            raise ValueError(
                f"FrozenClock.advance requires non-negative seconds; got {seconds}"
            )
        self._now = self._now + timedelta(seconds=seconds)
        self._monotonic += float(seconds)
        return self

    # --- Context-manager protocol (no-op; the mutation happens in advance()) ---

    def __enter__(self) -> FrozenClock:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        return None
