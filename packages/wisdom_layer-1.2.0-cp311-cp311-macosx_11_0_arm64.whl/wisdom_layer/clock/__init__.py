"""Time source for the Wisdom Layer SDK.

Every subsystem that touches time reads through the :class:`Clock` protocol —
never directly from ``datetime.now()`` or ``time.monotonic()``. The lint rule
``lint_no_datetime_now.py`` (doc 06 §0.11) enforces this at commit time.

The two files allowed to touch wall-clock APIs directly are:

- ``wisdom_layer/clock/__init__.py`` — the :class:`SystemClock` implementation
- ``wisdom_layer/clock/_frozen.py``  — the :class:`FrozenClock` implementation,
  shared between the internal SDK test suite and the public
  ``wisdom_layer.testing.clock`` surface that lands in Phase 0.10.

Doc reference: ``01_memory_architecture.md`` §"Time source (Clock protocol)".
"""

from __future__ import annotations

import time
from datetime import UTC, datetime
from typing import Protocol, runtime_checkable

from wisdom_layer.clock._frozen import FrozenClock

__all__ = ["Clock", "SystemClock", "FrozenClock"]


@runtime_checkable
class Clock(Protocol):
    """The SDK's sole time source.

    Injected at :class:`WisdomAgent` construction and threaded through every
    subsystem that needs to read 'now' — decay age calculations, session TTL
    pruning, directive reinforcement windows, dream-cycle timestamps, event
    emission, cost-tracker rollover, circuit-breaker cooldown.

    Tests supply :class:`FrozenClock` so cognition is deterministic. Production
    code uses :class:`SystemClock`, the implicit default.
    """

    def now(self) -> datetime:
        """Return a timezone-aware UTC datetime for the current instant.

        Use this for any value the customer will read — timestamps on events,
        memory rows, directives, cost records.
        """
        ...

    def monotonic(self) -> float:
        """Return a monotonic seconds value for elapsed-time measurements.

        Use this for circuit-breaker cooldowns, retry backoff, rate-limit
        windows, and span durations. The value is not related to wall-clock
        time, only guaranteed to be non-decreasing.

        Never subtract two :meth:`now` values to get a duration — that is
        wrong across DST and NTP jumps. Always use :meth:`monotonic` for
        intervals.
        """
        ...


class SystemClock:
    """Default :class:`Clock` implementation backed by the OS wall clock.

    Wraps :func:`datetime.datetime.now` (with ``timezone.utc``) and
    :func:`time.monotonic`. This is the implicit default if no ``clock=``
    kwarg is passed to :class:`WisdomAgent`.

    Subsystems should never construct their own :class:`SystemClock`. They
    accept the clock the agent gives them so a single :class:`WisdomAgent`
    has a single time source — replacing it in tests gives deterministic
    behaviour across every subsystem.
    """

    def now(self) -> datetime:
        """Return the current UTC wall-clock time as a timezone-aware datetime."""
        return datetime.now(UTC)

    def monotonic(self) -> float:
        """Return the current monotonic seconds value from the OS."""
        return time.monotonic()
