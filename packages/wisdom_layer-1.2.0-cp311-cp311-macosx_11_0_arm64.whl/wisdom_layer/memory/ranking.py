"""Memory search ranking constants and helpers.

The ranking formula:
    ``score = cosine_similarity + RECENCY_WEIGHT * exp(-age_seconds / RECENCY_HALF_LIFE_SECONDS)``

Both constants are module-level named values. Customers who need
different tuning can override via ``ResourceLimits`` in a future version;
for now these are the canonical defaults from doc 01.

Doc reference: ``01_memory_architecture.md`` §"Vector search ranking formula".
"""

from __future__ import annotations

import math

# Recency weighting coefficient (doc 01 spec default: 0.25).
# Controls how much recency boosts search results relative to cosine similarity.
RECENCY_WEIGHT: float = 0.25

# Half-life for recency decay in seconds (3 days = 259200s).
# After 3 days, the recency bonus halves.
RECENCY_HALF_LIFE_SECONDS: float = 259_200.0


def recency_bonus(age_seconds: float) -> float:
    """Compute the recency bonus for a memory of the given age.

    Args:
        age_seconds: Age of the memory in seconds since creation.

    Returns:
        Recency bonus in range (0, RECENCY_WEIGHT].
    """
    return RECENCY_WEIGHT * math.exp(-age_seconds / RECENCY_HALF_LIFE_SECONDS)
