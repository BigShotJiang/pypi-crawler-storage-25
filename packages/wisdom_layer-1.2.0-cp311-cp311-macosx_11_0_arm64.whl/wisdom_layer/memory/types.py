"""Memory subsystem types.

Doc reference: ``01_memory_architecture.md`` §"Deletion primitives",
``06_extraction_plan.md`` §A.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class DeleteReport:
    """Result of a delete operation.

    Returned by ``memory.delete()``, ``memory.delete_session()``, and
    ``memory.delete_all_for_agent()``. Carries the count of deleted rows
    and the emitted event ID so callers can correlate the audit trail
    with the returned receipt.

    Attributes:
        deleted: Total number of rows deleted across all tables.
        per_table: Breakdown by table name (e.g. ``{"memories": 5}``).
        agent_id: The agent whose data was deleted.
        event_id: ID of the emitted delete event for audit correlation.
    """

    deleted: int = 0
    per_table: dict[str, int] = field(default_factory=dict)
    agent_id: str = ""
    event_id: str = ""
