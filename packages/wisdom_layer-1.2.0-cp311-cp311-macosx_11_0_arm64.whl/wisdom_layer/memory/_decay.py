"""Decay system — salience scoring and decay invariants.

This module contains the pure salience scoring function and the
structural invariants that govern memory decay (decay-exempt event
types, the ln(2) constant).

All numeric T2 tuning knobs (salience weights, cap, half-life; weaken
and archive thresholds; emotional immunity threshold; decay factor)
live on :class:`wisdom_layer._internal.admin_defaults.AdminDefaults`
and are threaded through by the caller. The values here are structural
only.

``compute_salience()`` is a pure helper used by the batch decay pass
(``run_decay_pass``) to rescore memory salience. It has no side
effects and is never called from capture, search, or respond paths —
only from explicit decay operations.

Doc reference: ``01_memory_architecture.md`` §"Salience Scoring",
``07_config_architecture.md`` §"Tier 2: Admin Config".
"""

from __future__ import annotations

import math

from wisdom_layer._internal.admin_defaults import AdminDefaults

# ---------------------------------------------------------------------------
# Structural invariants (T3)
# ---------------------------------------------------------------------------

#: Event types that are immune to decay regardless of age or reinforcement.
#: Consolidated insights are the product of expensive LLM synthesis and
#: should never be silently weakened or archived.
DECAY_EXEMPT_TYPES: frozenset[str] = frozenset({"reconsolidated_insight"})

#: Natural log of 2, used in the exponential decay formula.
_LN2: float = math.log(2)

# ---------------------------------------------------------------------------
# Backwards-compatibility re-exports (scheduled for deletion in v0.4)
# ---------------------------------------------------------------------------
#
# Decay thresholds moved to :class:`AdminDefaults`. These names are
# kept so existing tests continue to resolve ``weaken_days`` /
# ``archive_days`` / ``emotional_immunity_threshold`` by their old
# module-level names. Values are sourced from
# ``AdminDefaults()`` (balanced archetype — matches pre-v0.3 behavior).

_COMPAT_AD = AdminDefaults()
WEAKEN_DAYS: int = _COMPAT_AD.weaken_days
ARCHIVE_DAYS: int = _COMPAT_AD.archive_days
EMOTIONAL_IMMUNITY_THRESHOLD: float = _COMPAT_AD.emotional_immunity_threshold


# ---------------------------------------------------------------------------
# Salience scoring — pure function, no side effects
# ---------------------------------------------------------------------------


def compute_salience(
    *,
    reinforcement_count: int,
    emotional_intensity: float,
    age_seconds: float,
    admin_defaults: AdminDefaults | None = None,
) -> float:
    """Compute the salience score for a memory.

    Pure function — no DB access, no async, no side effects.
    All inputs are scalars; the output is a float in [0.0, 1.0].

    Used by ``run_decay_pass()`` for batch rescore. Never called
    from capture, search, or respond paths.

    Formula (doc 01 §"Salience Scoring")::

        salience = (reinf_w * min(reinforcement / cap, 1.0))
                 + (emo_w  * clamp(emotional_intensity, 0, 1))
                 + (rec_w  * exp(-ln2 * age_days / half_life_days))

    Args:
        reinforcement_count: Times this memory has been retrieved.
        emotional_intensity: Emotional weight (0.0–1.0 expected,
            clamped to [0.0, 1.0] internally).
        age_seconds: Age of the memory in seconds since creation.
        admin_defaults: T2 tuning bundle. Defaults to
            ``AdminDefaults()`` (balanced archetype, matches pre-v0.3
            behavior) when omitted.

    Returns:
        Salience score clamped to [0.0, 1.0].
    """
    ad = admin_defaults or AdminDefaults()

    # Reinforcement component: saturates at salience_reinforcement_cap
    reinf_term = ad.salience_reinforcement_weight * min(
        reinforcement_count / ad.salience_reinforcement_cap, 1.0
    )

    # Emotional component: explicitly clamped to [0, 1]
    clamped_intensity = max(0.0, min(emotional_intensity, 1.0))
    emo_term = ad.salience_emotion_weight * clamped_intensity

    # Recency component: exponential decay with half-life from AdminDefaults
    age_days = age_seconds / 86_400.0
    recency_term = ad.salience_recency_weight * math.exp(
        -_LN2 * age_days / ad.salience_recency_half_life_days
    )

    # Sum and clamp to [0, 1]
    raw = reinf_term + emo_term + recency_term
    return max(0.0, min(raw, 1.0))
