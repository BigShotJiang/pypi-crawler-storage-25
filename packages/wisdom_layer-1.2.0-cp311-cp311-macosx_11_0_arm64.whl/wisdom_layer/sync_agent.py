"""Synchronous façade over :class:`WisdomAgent`.

The SDK is asyncio-first — LLM calls, embeddings, and dream cycles all
benefit from a real event loop. But the audience includes scripters,
Jupyter users, and sync-framework integrations. :class:`SyncWisdomAgent`
lets them use the SDK without writing ``await``.

Design:

* The wrapper starts one dedicated background thread running its own
  :mod:`asyncio` event loop. Every sync call submits its coroutine to
  that loop via :func:`asyncio.run_coroutine_threadsafe` and blocks on
  the result.
* This works in Jupyter (where the main thread already runs a loop)
  because the worker loop is in a *different* thread.
* Async resources (SQLite connections, HTTP clients) are created lazily
  inside the worker loop, so they stay bound to it.

Doc reference: ``11_integration_ergonomics_resolutions.md`` §"Sync Wrapper".
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import threading
from typing import TYPE_CHECKING, Any, TypeVar

from wisdom_layer.agent import WisdomAgent

if TYPE_CHECKING:
    from collections.abc import Coroutine
    from types import TracebackType

logger = logging.getLogger(__name__)

T = TypeVar("T")


class _LoopThread:
    """A daemon thread owning one persistent asyncio event loop."""

    def __init__(self) -> None:
        self._loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._ready = threading.Event()
        self._thread = threading.Thread(
            target=self._run, name="wisdom-layer-sync", daemon=True
        )
        self._thread.start()
        self._ready.wait()

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._ready.set()
        self._loop.run_forever()

    def submit(self, coro: Coroutine[Any, Any, T]) -> T:
        """Run ``coro`` on the worker loop and block until it returns."""
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result()

    def close(self, *, timeout: float = 5.0) -> None:
        if not self._loop.is_running():
            return
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=timeout)
        with contextlib.suppress(RuntimeError):
            self._loop.close()


class _SyncProxy:
    """Generic proxy converting a target's async methods into sync ones.

    Non-coroutine attributes pass through unchanged. Coroutine functions
    are wrapped to submit on the shared loop thread.
    """

    def __init__(self, target: object, loop_thread: _LoopThread) -> None:
        self._target = target
        self._loop_thread = loop_thread

    def __getattr__(self, name: str) -> Any:
        attr = getattr(self._target, name)
        if asyncio.iscoroutinefunction(attr):
            def sync_method(*args: Any, **kwargs: Any) -> Any:
                return self._loop_thread.submit(attr(*args, **kwargs))
            sync_method.__name__ = name
            sync_method.__doc__ = attr.__doc__
            return sync_method
        return attr

    def __repr__(self) -> str:
        return f"_SyncProxy({self._target!r})"


class _SyncHealthProxy:
    """Callable sync proxy over :class:`HealthInterface`.

    ``agent.health`` is not a method but a callable object with sub-
    methods (``trajectory``, ``capture_snapshot``). The standard
    :class:`_SyncProxy` assumes a plain target; this subclass adds
    ``__call__`` so ``agent.health()`` returns the current report
    synchronously, while ``.trajectory(...)`` / ``.capture_snapshot()``
    block on their async twins.
    """

    def __init__(self, target: Any, loop_thread: _LoopThread) -> None:
        self._target = target
        self._loop_thread = loop_thread

    def __call__(self) -> Any:
        return self._loop_thread.submit(self._target())

    def trajectory(self, days: int = 30) -> Any:
        return self._loop_thread.submit(self._target.trajectory(days=days))

    def capture_snapshot(self) -> Any:
        return self._loop_thread.submit(self._target.capture_snapshot())

    def __repr__(self) -> str:
        return f"_SyncHealthProxy({self._target!r})"


class SyncWisdomAgent:
    """Blocking wrapper around :class:`WisdomAgent`.

    Every async method on the underlying agent (and its sub-interfaces
    ``memory``, ``dreams``, ``critic``, ``directives``, ``journals``,
    ``analytics``) is exposed as a blocking equivalent. Non-async
    attributes pass through unchanged.

    Usage::

        from wisdom_layer import SyncWisdomAgent
        from wisdom_layer.llm.anthropic import AnthropicAdapter

        agent = SyncWisdomAgent(
            name="demo", llm=AnthropicAdapter(api_key="sk-ant-..."),
        )
        agent.initialize()
        agent.memory.capture("conversation", {"user": "hi"})
        results = agent.memory.search("hi")
        agent.close()

    Construction takes the same kwargs as :class:`WisdomAgent`. The
    wrapper owns one dedicated event-loop thread and shuts it down on
    :meth:`close` or as a context manager::

        with SyncWisdomAgent(name="demo", llm=...) as agent:
            agent.initialize()
            ...
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._loop_thread = _LoopThread()
        self._closed = False
        try:
            self._agent = WisdomAgent(*args, **kwargs)
        except BaseException:
            self._loop_thread.close()
            raise

    # -- Lifecycle -----------------------------------------------------------

    def initialize(self) -> None:
        """Initialize the underlying agent (storage, license check, etc.)."""
        self._loop_thread.submit(self._agent.initialize())

    def close(self) -> None:
        """Close the backend (if ownable) and stop the worker loop thread."""
        if self._closed:
            return
        self._closed = True
        backend = getattr(self._agent, "_backend", None)
        close = getattr(backend, "close", None)
        if close is not None:
            try:
                self._loop_thread.submit(close())
            except Exception:
                logger.exception("SyncWisdomAgent: backend close failed")
        self._loop_thread.close()

    def __enter__(self) -> SyncWisdomAgent:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()

    # -- Pass-through attributes --------------------------------------------

    @property
    def agent_id(self) -> str:
        return self._agent.agent_id

    @property
    def name(self) -> str:
        return self._agent.name

    @property
    def tier(self) -> Any:
        return self._agent.tier

    # -- Sync sub-interfaces -------------------------------------------------

    @property
    def memory(self) -> _SyncProxy:
        return _SyncProxy(self._agent.memory, self._loop_thread)

    @property
    def dreams(self) -> _SyncProxy:
        return _SyncProxy(self._agent.dreams, self._loop_thread)

    @property
    def critic(self) -> _SyncProxy:
        return _SyncProxy(self._agent.critic, self._loop_thread)

    @property
    def directives(self) -> _SyncProxy:
        return _SyncProxy(self._agent.directives, self._loop_thread)

    @property
    def journals(self) -> _SyncProxy:
        return _SyncProxy(self._agent.journals, self._loop_thread)

    @property
    def analytics(self) -> _SyncProxy:
        return _SyncProxy(self._agent.analytics, self._loop_thread)

    @property
    def cost(self) -> _SyncProxy:
        """Blocking proxy over ``agent.cost`` (v0.5 Phase 4)."""
        return _SyncProxy(self._agent.cost, self._loop_thread)

    @property
    def health(self) -> _SyncHealthProxy:
        """Blocking callable proxy over ``agent.health``.

        ``agent.health()`` returns a :class:`HealthReport` (current snapshot).
        ``agent.health.trajectory(days)`` returns a time series of snapshots.
        ``agent.health.capture_snapshot()`` writes a snapshot and emits an
        event. All calls block on the worker loop.
        """
        return _SyncHealthProxy(self._agent.health, self._loop_thread)

    # -- Direct sync forms of agent-level methods ---------------------------

    def status(self) -> dict[str, object]:
        """Return the runtime capability snapshot (blocking)."""
        return self._loop_thread.submit(self._agent.status())

    def status_display(self) -> str:
        """Return the human-readable status block (blocking)."""
        return self._loop_thread.submit(self._agent.status_display())

    def run(self, coro: Coroutine[Any, Any, T]) -> T:
        """Escape hatch: run an arbitrary coroutine on the worker loop.

        Useful when a caller needs to await a method not yet surfaced
        on the sync wrapper.
        """
        return self._loop_thread.submit(coro)
