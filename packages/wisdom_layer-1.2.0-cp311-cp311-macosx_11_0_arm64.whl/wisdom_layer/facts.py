"""Atomic fact extraction surface — Beta in v1.0.

The ``FactsInterface`` (mounted at ``agent.facts``) is the public entry
point for the v1.0 fact subsystem. It does three things:

1. **On-demand extraction** — ``extract(memory_id)`` runs the LLM
   extraction pipeline against a single memory and persists the
   resulting triples. This is the synchronous, user-controlled path.
2. **Recall** — ``search``, ``list_for_subject``, and
   ``list_for_memory`` give callers tier-appropriate access to stored
   facts (provenance back to source memory included).
3. **Verification helper** — ``verify_claim(subject, attribute,
   expected_value)`` is the lookup the Critic uses when grounding a
   draft response. Two-pass: an exact-attribute scan first
   (zero-cost happy path), then a semantic fallback through
   ``search_facts`` when the exact match misses. The fallback bridges
   the dual-LLM key drift case — the fact extractor and the claim
   extractor are independent LLM calls and routinely name the same
   attribute differently (``charged_amount`` vs
   ``duplicate_charge_amount``).

Background extraction (auto-run on every ``memory.captured`` event) is
wired in ``WisdomAgent.__init__`` via ``_subscribe_fact_extractor`` —
this module only owns the surface and the per-call extraction logic.
The background path uses the same ``_extract_for_memory`` helper that
``extract()`` does, so on-demand and event-driven extraction stay
behaviorally identical.

Tier and opt-in gating
----------------------
* All methods require the ``fact_extraction`` feature
  (Pro/Enterprise). Free tier raises :class:`TierRestrictionError`.
* ``AdminDefaults.enable_fact_extraction`` defaults to ``False``. The
  background subscriber checks this flag and silently skips when it's
  off, so users opt in by setting it to ``True`` on their config. The
  on-demand ``extract()`` method does **not** require the flag — if a
  user explicitly calls it, they want the work done.

Provenance contract
-------------------
Every persisted fact carries ``source_memory_id``. Callers can walk
``list_for_memory(memory_id)`` to enumerate the atomic claims a single
captured turn produced, or ``list_for_subject(subject)`` to assemble
the full history about a subject across every source memory.
"""

from __future__ import annotations

import logging
import uuid
from typing import TYPE_CHECKING, cast

from wisdom_layer._internal.extraction import (
    build_extraction_prompt,
    parse_extraction_output,
)
from wisdom_layer.asyncutils import sync_twin

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)


class FactsInterface:
    """Public facts API — extract, recall, verify atomic claims."""

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    # --- Extraction ---------------------------------------------------------

    @sync_twin
    async def extract(self, memory_id: str) -> list[dict[str, object]]:
        """Run fact extraction against a single captured memory.

        Synchronous, on-demand counterpart to the background subscriber.
        Use this when you want the work done now (e.g., immediately
        after a high-signal capture) instead of waiting for the event
        loop to catch up. Idempotency: each call writes a fresh row per
        extracted fact — last-write-wins at retrieval time. Reconciliation
        across runs is a v1.0.1 concern.

        Args:
            memory_id: ID of a memory previously persisted via
                ``agent.memory.capture()`` (or any session capture).

        Returns:
            List of fact dicts that were persisted. Empty list if the
            memory has no extractable claims, or if it could not be
            found.

        Raises:
            TierRestrictionError: Caller is on Free tier.
        """
        self._agent._require_feature("fact_extraction", "Pro")
        return await self._agent._extract_facts_for_memory(memory_id)

    # --- Recall -------------------------------------------------------------

    @sync_twin
    async def search(
        self,
        query: str,
        *,
        limit: int = 5,
    ) -> list[dict[str, object]]:
        """Search facts by semantic similarity to ``query``.

        When the backend is bound to an embedder (the default for
        SQLiteBackend), the query is embedded and ranked against every
        fact embedded under the same model via cosine similarity.
        Cross-model rows and rows that pre-date migration 0022 fall
        through to a substring scan over ``(subject, attribute, value)``
        so no fact ever becomes unreachable after a model upgrade.

        Backends with no ``embed_fn`` bound run the substring scan
        directly — same behavior as the original v1.0 release.

        Args:
            query: A natural-language question or phrase. Embedded for
                semantic matching against stored facts.
            limit: Maximum results.

        Returns:
            List of fact dicts, ranked by similarity (or newest-first
            for the substring fallback). Each carries ``id``,
            ``subject``, ``attribute``, ``value``, ``confidence``,
            ``source_memory_id``, ``created_at``, and ``similarity``
            (when the embedded path was taken — the substring fallback
            uses ``similarity=1.0`` as a text-match marker).

        Raises:
            TierRestrictionError: Caller is on Free tier.
        """
        self._agent._require_feature("fact_extraction", "Pro")
        return await self._agent._backend.search_facts(
            agent_id=self._agent._agent_id,
            query=query,
            limit=limit,
        )

    @sync_twin
    async def list_for_subject(
        self,
        subject: str,
        *,
        limit: int = 50,
    ) -> list[dict[str, object]]:
        """Return all stored facts about ``subject``, newest first.

        Multiple values for the same ``(subject, attribute)`` may
        appear: the newest entry is the current belief, older entries
        are retained as history (useful for the v1.0.1 reconciliation
        pass and for ``export_subject`` audits).

        Raises:
            TierRestrictionError: Caller is on Free tier.
        """
        self._agent._require_feature("fact_extraction", "Pro")
        return await self._agent._backend.list_facts_for_subject(
            agent_id=self._agent._agent_id,
            subject=subject,
            limit=limit,
        )

    @sync_twin
    async def list_for_memory(self, memory_id: str) -> list[dict[str, object]]:
        """Return every fact extracted from a single source memory.

        Closes the provenance loop: given a captured turn, surface the
        atomic claims it contributed to the fact store. Used by the
        Critic's grounding verifier and by ``provenance.trace``.

        Raises:
            TierRestrictionError: Caller is on Free tier.
        """
        self._agent._require_feature("fact_extraction", "Pro")
        return await self._agent._backend.list_facts_for_memory(
            agent_id=self._agent._agent_id,
            memory_id=memory_id,
        )

    @sync_twin
    async def export_subject(self, subject: str) -> dict[str, object]:
        """Return a portable snapshot of every fact about ``subject``.

        Wraps ``list_for_subject`` in a stable envelope suitable for
        GDPR-style export, audit logs, or the dashboard's per-subject
        drill-down. The shape is intentionally flat — consumers should
        treat the ``facts`` list as the source of truth and the
        envelope keys as informational.

        Raises:
            TierRestrictionError: Caller is on Free tier.
        """
        self._agent._require_feature("fact_extraction", "Pro")
        facts = await self._agent._backend.list_facts_for_subject(
            agent_id=self._agent._agent_id,
            subject=subject,
            limit=10_000,
        )
        return {
            "agent_id": self._agent._agent_id,
            "subject": subject,
            "fact_count": len(facts),
            "facts": facts,
        }

    # --- Verification helper ------------------------------------------------

    @sync_twin
    async def verify_claim(
        self,
        subject: str,
        attribute: str,
        expected_value: str,
    ) -> dict[str, object]:
        """Check whether a stored fact matches an expected value.

        Used by the Critic's grounding verifier and available to
        callers that want to spot-check a draft sentence against
        memory. Returns a structured result instead of a bare bool so
        consumers can surface contradicting values in error messages
        without a follow-up query.

        Two-pass lookup
        ---------------
        **Pass 1 — exact attribute lookup.** Scans the most recent facts
        for ``subject`` and finds the newest entry whose ``attribute``
        matches case-insensitively. This is the fast path: zero
        embedding cost, identical to the v1.0.0a behavior.

        **Pass 2 — semantic fallback.** When Pass 1 misses (no fact
        carries that exact attribute name), the verifier embeds a
        ``"{subject} {attribute} {expected_value}"`` query and runs it
        through ``backend.search_facts``. The top result must (a) clear
        the ``AdminDefaults.grounding_semantic_threshold`` cosine floor
        (default 0.60) and (b) share a case-insensitive substring on
        the subject, then it falls into the same value comparator as
        Pass 1. This bridges dual-LLM key drift — the fact extractor
        and the claim extractor routinely invent different attribute
        names for the same fact (``charged_amount`` vs
        ``duplicate_charge_amount``) and Pass 2 keeps verification from
        falling silently into ``"unknown"``.

        Pass 2 degrades gracefully when the backend has no embedder
        bound or when ``search_facts`` is unavailable — both fall back
        to ``"unknown"`` rather than raising.

        Value comparison (both passes)
        ------------------------------
        Compares values case-insensitively after stripping. The
        comparison is intentionally conservative: partial matches
        (substring containment) count as a match so the LLM's
        paraphrasing doesn't trigger false contradictions on values
        like ``"Austin, TX"`` vs ``"Austin"``.

        Returns:
            ``{"verified": bool, "match_type": str, "stored_value":
            str | None, "source_memory_id": str | None,
            "match_source": str | None, "similarity": float | None}``.

            * ``match_type`` — one of ``"exact"``, ``"substring"``,
              ``"contradicts"``, ``"unknown"``.
            * ``match_source`` — ``"exact"`` (Pass 1 hit), ``"semantic"``
              (Pass 2 hit), or ``None`` (no candidate found at all).
              Surfaces in the audit trail so callers can drill from
              ``"verified 8/10 claims"`` down to ``"6 exact, 2 semantic"``.
            * ``similarity`` — cosine score for Pass 2 hits; ``None``
              for Pass 1 hits and unknowns.

        Raises:
            TierRestrictionError: Caller is on Free tier.
        """
        self._agent._require_feature("fact_extraction", "Pro")

        # Pass 1: exact-attribute lookup against subject's facts.
        exact = await self._verify_claim_exact(subject, attribute, expected_value)
        if exact["match_type"] != "unknown":
            return exact

        # Pass 2: semantic fallback for dual-LLM key drift.
        return await self._verify_claim_semantic(subject, attribute, expected_value)

    async def _verify_claim_exact(
        self,
        subject: str,
        attribute: str,
        expected_value: str,
    ) -> dict[str, object]:
        """Pass 1 — exact-attribute lookup. Identical to v1.0.0a semantics."""
        facts = await self._agent._backend.list_facts_for_subject(
            agent_id=self._agent._agent_id,
            subject=subject,
            limit=200,
        )

        attr_norm = attribute.strip().lower()
        for fact in facts:
            if str(fact.get("attribute", "")).strip().lower() != attr_norm:
                continue
            stored_raw = fact.get("value")
            if stored_raw is None:
                continue
            stored = str(stored_raw).strip()
            if not stored:
                continue
            return _build_verdict(
                stored=stored,
                expected=expected_value,
                source_memory_id=fact.get("source_memory_id"),
                match_source="exact",
                similarity=None,
            )

        return _UNKNOWN_VERDICT

    async def _verify_claim_semantic(
        self,
        subject: str,
        attribute: str,
        expected_value: str,
    ) -> dict[str, object]:
        """Pass 2 — semantic fallback via ``backend.search_facts``.

        Only triggers when Pass 1 returns ``"unknown"``. Returns the
        canonical unknown verdict (with ``match_source=None``) when:

        * the backend has no embedder bound and ``search_facts`` raises
          or returns nothing useful;
        * no candidate clears
          ``AdminDefaults.grounding_semantic_threshold``;
        * the top semantic candidate has no usable ``value`` field;
        * the top candidate's subject doesn't share a case-insensitive
          substring with the requested subject (prevents bleed across
          unrelated subjects with similar attribute/value embeddings).
        """
        threshold = float(self._agent._admin.grounding_semantic_threshold)
        # Threshold of 1.0+ means "exact-match only" — skip the fallback
        # and the embedding cost it incurs.
        if threshold > 1.0:
            return _UNKNOWN_VERDICT

        query = f"{subject} {attribute} {expected_value}".strip()
        if not query:
            return _UNKNOWN_VERDICT

        try:
            candidates = await self._agent._backend.search_facts(
                agent_id=self._agent._agent_id,
                query=query,
                limit=5,
            )
        except (NotImplementedError, ValueError):
            # Backend doesn't support fact search, or embedder dim
            # mismatch — degrade silently. Pass 1 already returned
            # "unknown"; we honor that.
            return _UNKNOWN_VERDICT
        except Exception:  # noqa: BLE001 — defensive, see docstring
            logger.debug(
                "verify_claim semantic fallback raised; returning unknown",
                extra={"subject": subject, "attribute": attribute},
                exc_info=True,
            )
            return _UNKNOWN_VERDICT

        if not candidates:
            return _UNKNOWN_VERDICT

        subject_norm = subject.strip().lower()
        for cand in candidates:
            similarity = cand.get("similarity")
            if similarity is None or float(similarity) < threshold:
                # Candidates are returned ranked-best-first; once we
                # drop below the threshold every later candidate is
                # also below.
                break

            cand_subject = str(cand.get("subject", "")).strip().lower()
            if not cand_subject or not subject_norm:
                continue
            # Subject containment guard — without this, "John lives in
            # Austin" could verify "Sarah lives in Austin" because the
            # location term dominates the embedding.
            if (
                subject_norm not in cand_subject
                and cand_subject not in subject_norm
            ):
                continue

            stored_raw = cand.get("value")
            if stored_raw is None:
                continue
            stored = str(stored_raw).strip()
            if not stored:
                continue

            return _build_verdict(
                stored=stored,
                expected=expected_value,
                source_memory_id=cand.get("source_memory_id"),
                match_source="semantic",
                similarity=round(float(similarity), 4),
            )

        return _UNKNOWN_VERDICT


# ---------------------------------------------------------------------------
# verify_claim helpers — module-level so the verdict shape stays in one
# place and both passes (exact + semantic) construct identical envelopes.
# ---------------------------------------------------------------------------


_UNKNOWN_VERDICT: dict[str, object] = {
    "verified": False,
    "match_type": "unknown",
    "stored_value": None,
    "source_memory_id": None,
    "match_source": None,
    "similarity": None,
}


def _build_verdict(
    *,
    stored: str,
    expected: str,
    source_memory_id: object,
    match_source: str,
    similarity: float | None,
) -> dict[str, object]:
    """Compare ``stored`` against ``expected`` and assemble the verdict envelope.

    Centralised here so Pass 1 (exact-attribute) and Pass 2 (semantic
    fallback) produce structurally identical results — the only
    differences are the ``match_source`` tag and the optional
    ``similarity`` score.
    """
    expected_clean = expected.strip()
    if stored.lower() == expected_clean.lower():
        match_type = "exact"
        verified = True
    elif (
        expected_clean.lower() in stored.lower()
        or stored.lower() in expected_clean.lower()
    ):
        match_type = "substring"
        verified = True
    else:
        match_type = "contradicts"
        verified = False

    return {
        "verified": verified,
        "match_type": match_type,
        "stored_value": stored,
        "source_memory_id": source_memory_id,
        "match_source": match_source,
        "similarity": similarity,
    }


# ---------------------------------------------------------------------------
# Helpers used by both the on-demand path and the background subscriber.
# Kept module-level (not methods) so they can be unit-tested without an
# agent instance and so the agent.py wiring stays small.
# ---------------------------------------------------------------------------


async def extract_facts_for_memory(
    agent: WisdomAgent,
    memory_id: str,
) -> list[dict[str, object]]:
    """Fetch a memory, run extraction, and persist the resulting facts.

    Returns the list of persisted fact dicts (each carries the
    generated ``id`` so callers can correlate). Returns an empty list
    if the memory does not exist, has no text body, or yields no
    extractable claims. All errors are swallowed and logged — fact
    extraction must never break the main capture path.

    Centralised here so the synchronous ``FactsInterface.extract`` and
    the background ``memory.captured`` subscriber share a single
    implementation.
    """
    try:
        rows = await agent._backend.get_memories_by_ids(
            agent_id=agent._agent_id,
            memory_ids=[memory_id],
        )
    except Exception:  # noqa: BLE001 — defensive, see docstring
        logger.warning(
            "fact_extraction: failed to load source memory",
            extra={"memory_id": memory_id},
            exc_info=True,
        )
        return []

    if not rows:
        return []
    memory = rows[0]

    content = memory.get("content")
    text = _coerce_memory_text(content)
    if not text:
        return []

    role = _coerce_memory_role(memory)
    admin = agent._admin

    system, messages = build_extraction_prompt(
        memory_content=text,
        max_facts=admin.fact_extraction_max_per_memory,
        role=role,
    )

    try:
        response = await agent._model.generate(
            system=system,
            messages=messages,
            temperature=admin.fact_extraction_temperature,
        )
    except Exception:  # noqa: BLE001 — see docstring
        logger.warning(
            "fact_extraction: LLM call failed",
            extra={"memory_id": memory_id},
            exc_info=True,
        )
        return []

    parsed = parse_extraction_output(response)
    if not parsed:
        return []

    created_at = agent._clock.now().isoformat()
    persisted: list[dict[str, object]] = []
    for entry in parsed:
        fact_id = uuid.uuid4().hex[:12]
        try:
            await agent._backend.store_fact(
                fact_id=fact_id,
                agent_id=agent._agent_id,
                subject=str(entry["subject"]),
                attribute=str(entry["attribute"]),
                value=str(entry["value"]),
                source_memory_id=memory_id,
                confidence=float(cast("float", entry["confidence"])),
                decay_rate=0.95,
                created_at=created_at,
            )
        except Exception:  # noqa: BLE001 — see docstring
            logger.warning(
                "fact_extraction: failed to persist fact",
                extra={"memory_id": memory_id, "fact_id": fact_id},
                exc_info=True,
            )
            continue

        persisted.append(
            {
                "id": fact_id,
                "subject": entry["subject"],
                "attribute": entry["attribute"],
                "value": entry["value"],
                "confidence": entry["confidence"],
                "source_memory_id": memory_id,
            }
        )

    if persisted:
        await agent._emit(
            "fact.extracted",
            data={
                "memory_id": memory_id,
                "fact_count": len(persisted),
            },
            entity_type="memory",
            entity_id=memory_id,
        )

    return persisted


def _coerce_memory_text(content: object) -> str:
    """Pull a flat text body out of a captured memory's content payload.

    Captures store ``content`` as a free-form dict; the prompt needs a
    single string. Prefers common keys (``text``, ``message``,
    ``content``) and falls back to a JSON-stringified view so the LLM
    still has something to work with for unusual shapes.
    """
    import json

    if isinstance(content, str):
        return content.strip()
    if not isinstance(content, dict):
        return ""

    for key in ("text", "message", "content", "body", "utterance"):
        value = content.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    try:
        return json.dumps(content, default=str, sort_keys=True)
    except (TypeError, ValueError):
        return ""


def _coerce_memory_role(memory: dict[str, object]) -> str:
    """Return a role tag suitable for the extraction prompt header."""
    content = memory.get("content")
    if isinstance(content, dict):
        role = content.get("role")
        if isinstance(role, str) and role.strip():
            return role.strip()
    event_type = memory.get("event_type")
    if isinstance(event_type, str) and event_type.strip():
        return event_type.strip()
    return "user"
