"""Unified event emitter for the Wisdom Layer SDK.

One bus per agent. Subsystems emit events via ``agent._emit(name, payload)``;
customers subscribe via ``agent.on(event_name, handler)``. Sync and async
handlers are both supported. Handler exceptions are isolated — they never
break the emit loop.

Doc reference: ``14_observability_events.md``.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import uuid
from collections import defaultdict
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from wisdom_layer.clock import Clock

logger = logging.getLogger("wisdom_layer.event")
obs_logger = logging.getLogger("wisdom_layer.observability")

# Keys that shadow built-in LogRecord attributes — passing any of these via
# ``extra={}`` triggers "Attempt to overwrite '...' in LogRecord" at emit
# time. Filter them out of structured-log payloads instead of crashing.
_LOGRECORD_RESERVED: frozenset[str] = frozenset({
    "name", "msg", "args", "created", "filename", "funcName",
    "levelname", "levelno", "lineno", "message", "module", "msecs",
    "pathname", "process", "processName", "relativeCreated",
    "stack_info", "thread", "threadName", "exc_info", "exc_text",
})

# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

EventName = str
Handler = Callable[["Event"], Awaitable[None] | None]


class EventPriority(IntEnum):
    """Delivery priority — controls drop order under back-pressure.

    T3 (baked-in): customers cannot add new levels.
    """

    CRITICAL = 0
    NORMAL = 1
    DEBUG = 2


@dataclass(frozen=True)
class Event:
    """Base envelope for every cognition event.

    All payloads carry these fields. Subsystem-specific events extend
    this with additional attributes via keyword arguments stored in
    ``data``.
    """

    name: str
    schema_version: int = 1
    agent_id: str = ""
    cycle_id: str | None = None
    timestamp: Any = None  # datetime — typed as Any to avoid import cycle
    trace_id: str | None = None
    span_id: str | None = None
    priority: EventPriority = EventPriority.NORMAL
    data: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SubscriptionToken:
    """Opaque handle returned by ``on`` / ``once``.

    Doubles as a context manager so customers can scope subscriptions::

        with agent.on("memory.captured", handler) as tok:
            await agent.memory.capture(...)
        # handler automatically unsubscribed on exit
    """

    event: EventName
    id: str
    _emitter: EventEmitter | None = field(default=None, repr=False, compare=False)

    def __enter__(self) -> SubscriptionToken:
        return self

    def __exit__(self, *exc: object) -> None:
        if self._emitter is not None:
            self._emitter.off(self)


# ---------------------------------------------------------------------------
# Quarantine tracking
# ---------------------------------------------------------------------------

_QUARANTINE_WINDOW_SECONDS: float = 60.0
_QUARANTINE_THRESHOLD: int = 3


@dataclass
class _HandlerRecord:
    """Internal bookkeeping for a single handler subscription."""

    handler: Handler
    event: EventName
    token: SubscriptionToken
    once: bool = False
    is_async: bool = False
    # Quarantine tracking
    error_timestamps: list[float] = field(default_factory=list)
    quarantined: bool = False


# ---------------------------------------------------------------------------
# Emitter stats
# ---------------------------------------------------------------------------


@dataclass
class EmitterStats:
    """Diagnostic counters exposed via ``emitter.stats()``."""

    total_emitted: int = 0
    total_delivered: int = 0
    handler_errors_total: int = 0
    handlers_quarantined: int = 0
    subscriptions_active: int = 0


# ---------------------------------------------------------------------------
# EventEmitter
# ---------------------------------------------------------------------------


class EventEmitter:
    """In-process event bus — one per :class:`WisdomAgent`.

    Design principles (from doc 14):
    - Named events (dotted strings), not class hierarchies.
    - Handlers never block the cognition path.
    - Handler exceptions are isolated (logged, not propagated).
    - Sync handlers run on a thread executor.
    - Quarantine after ``_QUARANTINE_THRESHOLD`` failures in
      ``_QUARANTINE_WINDOW_SECONDS``.

    Phase 0.6 scope: ``on``, ``off``, ``once``, ``_emit``.
    ``on_pattern`` (wildcard subscriptions) is Phase 0.6.x — not in scope.
    """

    def __init__(self, *, clock: Clock | None = None) -> None:
        from wisdom_layer.clock import SystemClock

        self._clock: Clock = clock or SystemClock()
        self._handlers: dict[EventName, list[_HandlerRecord]] = defaultdict(list)
        self._stats = EmitterStats()

    # -- public subscription API -------------------------------------------

    def on(self, event: EventName, handler: Handler) -> SubscriptionToken:
        """Subscribe ``handler`` to all future emissions of ``event``.

        Args:
            event: Dotted event name (e.g. ``"memory.captured"``).
            handler: Sync or async callable accepting an :class:`Event`.

        Returns:
            A :class:`SubscriptionToken` usable as a context manager.
        """
        return self._register(event, handler, once=False)

    def once(self, event: EventName, handler: Handler) -> SubscriptionToken:
        """Subscribe ``handler`` for a single emission of ``event``.

        The handler is automatically unsubscribed after it fires once.
        """
        return self._register(event, handler, once=True)

    def off(self, token: SubscriptionToken) -> None:
        """Unsubscribe the handler identified by ``token``.

        Idempotent — calling ``off`` on an already-removed token is a no-op.
        """
        handlers = self._handlers.get(token.event)
        if handlers is None:
            return
        before = len(handlers)
        self._handlers[token.event] = [
            h for h in handlers if h.token.id != token.id
        ]
        removed = before - len(self._handlers[token.event])
        self._stats.subscriptions_active -= removed
        # Clean up empty lists
        if not self._handlers[token.event]:
            del self._handlers[token.event]

    def subscriber_count(self, event: EventName | None = None) -> int:
        """Return the number of active (non-quarantined) subscribers.

        Args:
            event: If given, count only subscribers for this event.
                   If ``None``, count across all events.
        """
        if event is not None:
            return sum(
                1 for h in self._handlers.get(event, []) if not h.quarantined
            )
        return sum(
            1
            for handlers in self._handlers.values()
            for h in handlers
            if not h.quarantined
        )

    def stats(self) -> EmitterStats:
        """Return a snapshot of emitter diagnostics."""
        # Refresh the live subscription count
        self._stats.subscriptions_active = sum(
            len(hs) for hs in self._handlers.values()
        )
        return EmitterStats(
            total_emitted=self._stats.total_emitted,
            total_delivered=self._stats.total_delivered,
            handler_errors_total=self._stats.handler_errors_total,
            handlers_quarantined=self._stats.handlers_quarantined,
            subscriptions_active=self._stats.subscriptions_active,
        )

    # -- internal emit API -------------------------------------------------

    async def emit(self, event: Event) -> None:
        """Dispatch ``event`` to all matching subscribers.

        This is the internal firing method. Subsystems call
        ``await agent._emit(name, data)`` which delegates here.

        Handler exceptions are caught and logged — they never propagate
        to the emitter caller.
        """
        self._stats.total_emitted += 1

        # Mirror to structured logger
        log_extra: dict[str, Any] = {
            "event": event.name,
            "schema_version": event.schema_version,
            "agent_id": event.agent_id,
            "cycle_id": event.cycle_id,
        }
        log_extra.update({k: v for k, v in event.data.items() if k not in _LOGRECORD_RESERVED})
        logger.info("wisdom_layer.event", extra=log_extra)

        handlers = list(self._handlers.get(event.name, []))
        to_remove: list[SubscriptionToken] = []

        for record in handlers:
            if record.quarantined:
                continue

            try:
                if record.is_async:
                    result = record.handler(event)
                    if result is not None:
                        await result
                else:
                    # Run sync handler in thread executor so it cannot
                    # block the event loop.
                    loop = asyncio.get_running_loop()
                    await loop.run_in_executor(None, record.handler, event)
                self._stats.total_delivered += 1
            except Exception:
                self._stats.handler_errors_total += 1
                obs_logger.exception(
                    "Handler error for event '%s'",
                    event.name,
                    extra={
                        "event": event.name,
                        "handler": _handler_name(record.handler),
                        "agent_id": event.agent_id,
                    },
                )
                self._maybe_quarantine(record)

            if record.once:
                to_remove.append(record.token)

        for tok in to_remove:
            self.off(tok)

    # -- private helpers ---------------------------------------------------

    def _register(
        self,
        event: EventName,
        handler: Handler,
        *,
        once: bool,
    ) -> SubscriptionToken:
        token = SubscriptionToken(
            event=event,
            id=uuid.uuid4().hex,
            _emitter=self,
        )
        record = _HandlerRecord(
            handler=handler,
            event=event,
            token=token,
            once=once,
            is_async=inspect.iscoroutinefunction(handler),
        )
        self._handlers[event].append(record)
        self._stats.subscriptions_active += 1
        return token

    def _maybe_quarantine(self, record: _HandlerRecord) -> None:
        """Check whether the handler has hit the quarantine threshold."""
        now_mono = self._clock.monotonic()
        record.error_timestamps.append(now_mono)

        # Trim timestamps outside the window
        cutoff = now_mono - _QUARANTINE_WINDOW_SECONDS
        record.error_timestamps = [
            t for t in record.error_timestamps if t >= cutoff
        ]

        if len(record.error_timestamps) >= _QUARANTINE_THRESHOLD:
            record.quarantined = True
            self._stats.handlers_quarantined += 1
            obs_logger.warning(
                "Handler quarantined after %d errors in %.0fs",
                _QUARANTINE_THRESHOLD,
                _QUARANTINE_WINDOW_SECONDS,
                extra={
                    "event": record.event,
                    "handler": _handler_name(record.handler),
                },
            )


def _handler_name(handler: Handler) -> str:
    """Best-effort human-readable name for a handler."""
    qualname: str | None = getattr(handler, "__qualname__", None)
    if qualname is not None:
        return qualname
    name: str | None = getattr(handler, "__name__", None)
    return name if name is not None else repr(handler)
