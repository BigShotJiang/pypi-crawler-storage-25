"""Observability subsystem — event emitter, structured logging, OTel bridge.

This package is the single event bus for a :class:`WisdomAgent` instance.
Subsystems never expose their own callback registries — all subscriptions
go through ``agent.on(event_name, handler)``.

Doc reference: ``14_observability_events.md``.
"""

from wisdom_layer.observability.events import (
    Event,
    EventEmitter,
    EventPriority,
    SubscriptionToken,
)

__all__ = [
    "Event",
    "EventEmitter",
    "EventPriority",
    "SubscriptionToken",
]
