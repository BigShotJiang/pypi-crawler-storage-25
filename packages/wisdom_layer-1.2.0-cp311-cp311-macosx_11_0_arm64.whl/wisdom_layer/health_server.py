"""Optional HTTP health endpoint for the Wisdom Layer agent.

Requires the ``health`` extra: ``pip install wisdom-layer[health]``
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

try:
    from aiohttp import web
except ImportError as _exc:
    _import_error = _exc

    class _Placeholder:
        """Raise a helpful error when aiohttp is not installed."""

        def __getattr__(self, name: str) -> Any:
            raise ImportError(
                "aiohttp is required for the health server. "
                "Install with: pip install wisdom-layer[health]"
            ) from _import_error

    web = _Placeholder()  # type: ignore[assignment]


class HealthServer:
    """Lightweight HTTP health/readiness server for an agent.

    Args:
        agent: The WisdomAgent instance to monitor.
        host: Bind address. Defaults to ``"0.0.0.0"``.
        port: Bind port. Defaults to ``8741``.
    """

    def __init__(
        self,
        agent: WisdomAgent,
        *,
        host: str = "0.0.0.0",
        port: int = 8741,
    ) -> None:
        self._agent = agent
        self._host = host
        self._port = port
        self._runner: web.AppRunner | None = None

    def app(self) -> web.Application:
        """Build and return the aiohttp ``Application``.

        Useful for embedding into an existing aiohttp server.
        """
        application = web.Application()
        application.router.add_get("/healthz", self._handle_healthz)
        application.router.add_get("/readyz", self._handle_readyz)
        application.router.add_get("/version", self._handle_version)
        return application

    async def start(self) -> None:
        """Start the HTTP server in the background."""
        runner = web.AppRunner(self.app())
        await runner.setup()
        site = web.TCPSite(runner, self._host, self._port)
        await site.start()
        self._runner = runner
        logger.info(
            "Health server listening on %s:%d",
            self._host,
            self._port,
            extra={"agent_id": self._agent._agent_id},
        )

    async def stop(self) -> None:
        """Gracefully stop the HTTP server."""
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None

    async def _handle_healthz(self, _request: web.Request) -> web.Response:
        return web.Response(
            text=json.dumps({"status": "ok"}),
            content_type="application/json",
        )

    async def _handle_readyz(self, _request: web.Request) -> web.Response:
        checks: dict[str, str] = {}

        try:
            backend = self._agent._backend
            has_conn = getattr(backend, "_conn", None) is not None
            has_pool = getattr(backend, "_pool", None) is not None
            backend_ok = has_conn or has_pool
            checks["backend"] = "ok" if backend_ok else "not_initialized"
        except Exception:
            checks["backend"] = "error"

        try:
            scheduler = self._agent.dreams._scheduler
            checks["scheduler"] = "ok" if scheduler is not None else "not_wired"
        except Exception:
            checks["scheduler"] = "error"

        all_ok = all(v == "ok" for v in checks.values())
        status_code = 200 if all_ok else 503
        return web.Response(
            text=json.dumps({"ready": all_ok, "checks": checks}),
            content_type="application/json",
            status=status_code,
        )

    async def _handle_version(self, _request: web.Request) -> web.Response:
        import wisdom_layer

        return web.Response(
            text=json.dumps({
                "sdk_version": wisdom_layer.__version__,
                "agent_id": self._agent._agent_id,
                "agent_name": self._agent._config.name,
            }),
            content_type="application/json",
        )
