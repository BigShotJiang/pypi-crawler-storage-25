"""Async/sync bridge primitives for the Wisdom Layer SDK.

Every public async method on :class:`wisdom_layer.WisdomAgent` ships with
a ``_sync`` twin so customers on Django, Flask, Celery, AWS Lambda, and
other blocking runtimes can adopt the SDK without rewriting their stack
around asyncio.

The core primitives are:

- :func:`run_sync` — three-case dispatch (pure sync / worker thread of
  async / main thread of async) so a sync caller either gets a result
  or a loud :class:`~wisdom_layer.errors.SyncInAsyncError`.
- :func:`sync_twin` — class-body decorator that attaches a ``_sync``
  sibling to any ``async def`` method.
- :class:`PortalRegistry` — holds an optional ``anyio.from_thread.BlockingPortal``
  so worker threads inside an async program can marshal back to the
  loop that owns the agent's backend.

Doc references: ``06_extraction_plan.md`` §0.5;
``11_integration_ergonomics_resolutions.md`` §4 ("Async-only cuts half
the market").
"""

from __future__ import annotations

from wisdom_layer.asyncutils.sync_bridge import (
    PortalRegistry,
    run_sync,
    sync_twin,
)

__all__ = [
    "PortalRegistry",
    "run_sync",
    "sync_twin",
]
