"""Sync bridge: run async code from sync callers with three-case dispatch.

The :func:`run_sync` primitive detects the caller environment and picks
the correct runner:

========================================  =======================================
Caller environment                        Runner
========================================  =======================================
Pure sync (no event loop at all)          Fresh :class:`asyncio.Runner`
Worker thread of a running async program  ``anyio.from_thread.BlockingPortal.call``
Main thread of a running async program    Raises :class:`SyncInAsyncError`
========================================  =======================================

The third case is the silent-deadlock trap — we refuse loudly instead of
spinning a daemon loop or monkey-patching via ``nest_asyncio``. See
``11_integration_ergonomics_resolutions.md`` §4 for the full rationale
and the list of anti-patterns we explicitly refuse.

The :func:`sync_twin` decorator is the ergonomic entry point: apply it
to an ``async def`` method in a class body and the owning class gains a
sibling ``<name>_sync`` method that delegates to :func:`run_sync`. The
original async method keeps its signature untouched so static type
checkers see the coroutine function, not an opaque descriptor.
"""

from __future__ import annotations

import asyncio
import functools
import logging
import threading
from collections.abc import Callable, Coroutine
from typing import TYPE_CHECKING, Any, TypeVar, cast

from wisdom_layer.errors import SyncInAsyncError

if TYPE_CHECKING:
    import anyio.from_thread

logger = logging.getLogger(__name__)

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Coroutine[Any, Any, Any]])


class PortalRegistry:
    """Holds an optional :class:`anyio.from_thread.BlockingPortal`.

    Customers running the SDK inside an async program who want worker
    threads to call ``_sync`` methods register a portal once at agent
    init time via ``agent.portal_scope()`` (Phase A). Pure-sync customers
    never touch this object — they hit :func:`run_sync`'s Case 1 path.

    The registry is thread-safe so multiple worker threads spawned from
    the same async program can read the current portal concurrently.
    """

    def __init__(self) -> None:
        self._portal: anyio.from_thread.BlockingPortal | None = None
        self._lock = threading.Lock()

    def set(self, portal: anyio.from_thread.BlockingPortal | None) -> None:
        """Register (or clear) the active BlockingPortal."""
        with self._lock:
            self._portal = portal

    def current(self) -> anyio.from_thread.BlockingPortal | None:
        """Return the active BlockingPortal, if any."""
        with self._lock:
            return self._portal


def run_sync(
    async_callable: Callable[..., Coroutine[Any, Any, T]],
    *args: Any,
    _portal_registry: PortalRegistry | None = None,
    **kwargs: Any,
) -> T:
    """Execute an async callable synchronously from any caller environment.

    Three-case dispatch:

    1. **Pure sync** — no running loop, no portal. Spin a fresh
       :class:`asyncio.Runner`, run the coroutine, dispose. This is the
       common case for Django sync views, Flask handlers, Celery tasks,
       AWS Lambda, and one-off scripts.
    2. **Worker thread of a running async program** — ``_portal_registry``
       holds a :class:`~anyio.from_thread.BlockingPortal` bound to the
       loop thread. Marshal the call onto the loop via ``portal.call``.
    3. **Main thread of a running async program** — deadlock trap.
       Raise :class:`~wisdom_layer.errors.SyncInAsyncError` so the
       caller sees the mistake instead of a hung process.

    Args:
        async_callable: The async function or bound method to run.
        *args: Positional arguments forwarded to ``async_callable``.
        _portal_registry: Optional :class:`PortalRegistry` holding a
            BlockingPortal. When set and non-empty, Case 2 is selected.
        **kwargs: Keyword arguments forwarded to ``async_callable``.

    Returns:
        Whatever the awaited coroutine returns.

    Raises:
        SyncInAsyncError: If called from inside a running event loop
            on the same thread as the loop.
    """
    # Case 3: main-thread-of-async is the deadlock case. Check first.
    try:
        running: asyncio.AbstractEventLoop | None = asyncio.get_running_loop()
    except RuntimeError:
        running = None

    if running is not None:
        method_name = getattr(async_callable, "__name__", None)
        raise SyncInAsyncError(method_name)

    # Case 2: worker thread of async program, portal registered.
    portal = _portal_registry.current() if _portal_registry is not None else None
    if portal is not None:
        def _invoke() -> Coroutine[Any, Any, T]:
            return async_callable(*args, **kwargs)

        result: T = portal.call(_invoke)
        return result

    # Case 1: pure sync. Spin a short-lived Runner and dispose it.
    # Python 3.11+ is required by pyproject.toml, so asyncio.Runner is
    # always available — no fallback branch needed.
    with asyncio.Runner() as runner:
        return runner.run(async_callable(*args, **kwargs))


class _SyncTwinDescriptor:
    """Class-body descriptor that installs both async and ``_sync`` attrs.

    When :func:`sync_twin` wraps an ``async def`` in a class body, it
    returns an instance of this descriptor. Python then calls
    :meth:`__set_name__` during class creation, which is our hook to
    (a) replace the descriptor on the class with the original async
    method, preserving its signature for static type checkers, and
    (b) install a sibling ``<name>_sync`` attribute that delegates to
    :func:`run_sync`.

    This is an implementation detail. Users should only touch
    :func:`sync_twin`.
    """

    def __init__(
        self, async_method: Callable[..., Coroutine[Any, Any, Any]]
    ) -> None:
        self._async_method = async_method

    def __set_name__(self, owner: type, name: str) -> None:
        async_method = self._async_method

        @functools.wraps(async_method)
        def _twin(self: Any, *args: Any, **kwargs: Any) -> Any:
            registry = getattr(self, "_portal_registry", None)
            bound_method = async_method.__get__(self, type(self))
            return run_sync(
                bound_method,
                *args,
                _portal_registry=registry,
                **kwargs,
            )

        twin_name = f"{name}_sync"
        _twin.__name__ = twin_name
        _twin.__qualname__ = f"{owner.__qualname__}.{twin_name}"
        _twin.__doc__ = (
            f"Synchronous twin of :meth:`{name}`. "
            f"Dispatches via :func:`wisdom_layer.asyncutils.run_sync`.\n\n"
            f"{async_method.__doc__ or ''}"
        )

        # Install the original async method under its declared name and
        # the sync twin under <name>_sync. The descriptor itself is
        # discarded — after __set_name__ returns, neither mypy nor the
        # Python runtime ever sees _SyncTwinDescriptor again on owner.
        setattr(owner, name, async_method)
        setattr(owner, twin_name, _twin)


def sync_twin(async_method: F) -> F:
    """Class-body decorator: attach a ``_sync`` twin to an async method.

    Usage::

        class MemoryInterface:
            @sync_twin
            async def capture(self, event_type: str, content: dict) -> str:
                ...

    After class creation, ``MemoryInterface.capture`` is the original
    ``async def capture`` (type checkers see its signature unchanged),
    and ``MemoryInterface.capture_sync`` is a synchronous wrapper that
    calls :func:`run_sync` internally. Static type checkers will not
    see ``capture_sync`` unless the class declares it in a
    ``TYPE_CHECKING`` block — that is a deliberate tradeoff to keep the
    decorator syntactically trivial at the call site.

    If the decorated class's instances carry a ``_portal_registry``
    attribute (a :class:`PortalRegistry`), the sync twin will use it
    for the Case 2 worker-thread-of-async path. Otherwise it falls
    through to Case 1 (fresh runner) or Case 3 (``SyncInAsyncError``).

    Args:
        async_method: An ``async def`` method. Non-async callables
            are not validated here — misuse will manifest as a
            ``TypeError`` when the sync twin tries to await a
            non-awaitable return value.

    Returns:
        The original async method, unchanged at runtime. The return
        type annotation intentionally preserves ``F`` so that callers
        see the untouched async signature.
    """
    descriptor = _SyncTwinDescriptor(async_method)
    # We return the descriptor, but cast it to F so static type
    # checkers see the original coroutine function. At runtime, the
    # descriptor's __set_name__ replaces itself on the owning class
    # with the actual async method, so the runtime shape matches the
    # type-checker shape.
    return cast("F", descriptor)
