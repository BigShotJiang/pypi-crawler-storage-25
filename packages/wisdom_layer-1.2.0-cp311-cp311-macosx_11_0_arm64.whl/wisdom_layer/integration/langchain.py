"""LangChain/LangGraph integration — Wisdom Layer as a LangGraph Store.

.. deprecated:: LangChain ``BaseMemory``
    ``BaseMemory`` is deprecated since langchain-core 0.3.3 and will be
    removed in LangChain 1.0.0. The recommended approach is LangGraph
    persistence via ``BaseStore``. This module provides both:

    - ``WisdomStore`` — a LangGraph ``BaseStore`` implementation backed
      by the Wisdom Layer SDK (recommended for new projects)
    - ``WisdomLayerMemory`` — legacy ``BaseMemory`` adapter for existing
      LangChain chains that haven't migrated yet

Install: ``pip install "wisdom-layer[langchain]"``

Example (modern LangGraph store)::

    from langgraph.store.base import InMemoryStore
    from wisdom_layer.integration.langchain import WisdomStore

    store = WisdomStore(agent)
    # Pass to graph.compile(store=store) for cross-thread memory

Example (legacy LangChain memory)::

    from wisdom_layer.integration.langchain import WisdomLayerMemory

    memory = WisdomLayerMemory(agent=agent)
    # Use with legacy LLMChain or RunnableWithMessageHistory
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)


def _run_async(coro: Any) -> Any:
    """Run an async coroutine from sync context, handling nested loops."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(asyncio.run, coro).result()


# ── Modern: LangGraph BaseStore ────────────────────────────────────


class WisdomStore:
    """LangGraph-compatible store backed by a WisdomAgent.

    Implements the key methods LangGraph nodes use to interact with
    cross-thread persistent memory: ``search()``, ``put()``, ``get()``.

    This is the recommended integration point for new LangGraph projects.
    Pass it to ``graph.compile(store=store)`` and access it in nodes via
    ``store: BaseStore`` parameter injection.

    Args:
        agent: An initialized WisdomAgent instance.
        default_limit: Default number of results for searches.
    """

    def __init__(self, agent: WisdomAgent, *, default_limit: int = 5) -> None:
        self._agent = agent
        self._default_limit = default_limit

    async def asearch(
        self,
        namespace: tuple[str, ...],
        *,
        query: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Search for memories matching a query.

        Args:
            namespace: Tuple of namespace segments (used for scoping).
            query: Semantic search query.
            limit: Maximum results to return.

        Returns:
            List of dicts with ``key``, ``value``, ``namespace`` fields.
        """
        if not query:
            return []

        results = await self._agent.memory.search(
            query, limit=limit or self._default_limit,
        )
        return [
            {
                "key": str(r.get("id", uuid.uuid4().hex)),
                "value": {
                    "content": str(r.get("content", r.get("text", ""))),
                    "tier": r.get("tier"),
                    "salience": r.get("salience"),
                },
                "namespace": namespace,
            }
            for r in results
        ]

    def search(
        self,
        namespace: tuple[str, ...],
        *,
        query: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Sync wrapper for ``asearch``."""
        return _run_async(self.asearch(namespace, query=query, limit=limit))

    async def aput(
        self,
        namespace: tuple[str, ...],
        key: str,
        value: dict[str, Any],
    ) -> None:
        """Store a memory.

        Args:
            namespace: Tuple of namespace segments.
            key: Unique key for this memory.
            value: Dict containing the memory content.
        """
        content = value.get("content", value.get("text", str(value)))
        await self._agent.memory.capture(
            event_type="langgraph_store",
            content={"text": content, "store_key": key, "namespace": "/".join(namespace)},
        )

    def put(
        self,
        namespace: tuple[str, ...],
        key: str,
        value: dict[str, Any],
    ) -> None:
        """Sync wrapper for ``aput``."""
        _run_async(self.aput(namespace, key, value))

    async def aget(
        self,
        namespace: tuple[str, ...],
        key: str,
    ) -> dict[str, Any] | None:
        """Retrieve a specific memory by key.

        Args:
            namespace: Tuple of namespace segments.
            key: The memory key to look up.

        Returns:
            Dict with ``key``, ``value``, ``namespace`` or None.
        """
        results = await self._agent.memory.search(key, limit=1)
        if not results:
            return None
        r = results[0]
        return {
            "key": key,
            "value": {
                "content": str(r.get("content", r.get("text", ""))),
                "tier": r.get("tier"),
                "salience": r.get("salience"),
            },
            "namespace": namespace,
        }

    def get(
        self,
        namespace: tuple[str, ...],
        key: str,
    ) -> dict[str, Any] | None:
        """Sync wrapper for ``aget``."""
        return _run_async(self.aget(namespace, key))


# ── Legacy: LangChain BaseMemory ───────────────────────────────────


class WisdomLayerMemory:
    """LangChain-compatible memory backed by a WisdomAgent.

    .. deprecated::
        Use ``WisdomStore`` with LangGraph persistence instead.
        ``BaseMemory`` will be removed in LangChain 1.0.0.

    Implements the interface expected by LangChain's legacy memory system:
    ``memory_variables``, ``load_memory_variables()``, ``save_context()``,
    and ``clear()``.

    Args:
        agent: An initialized WisdomAgent instance.
        memory_key: The key used to inject memory into prompts.
        input_key: The key for human input in chain inputs.
        output_key: The key for AI output in chain outputs.
        limit: Maximum number of memories to retrieve per query.
        event_type: Event type for captured interactions.
        return_messages: If True, return as message dicts instead of string.
    """

    memory_key: str
    input_key: str
    output_key: str

    def __init__(
        self,
        agent: WisdomAgent,
        *,
        memory_key: str = "wisdom_context",
        input_key: str = "input",
        output_key: str = "output",
        limit: int = 5,
        event_type: str = "interaction",
        return_messages: bool = False,
    ) -> None:
        self._agent = agent
        self.memory_key = memory_key
        self.input_key = input_key
        self.output_key = output_key
        self._limit = limit
        self._event_type = event_type
        self._return_messages = return_messages

    @property
    def memory_variables(self) -> list[str]:
        """Keys this memory injects into the chain."""
        return [self.memory_key]

    def load_memory_variables(
        self, inputs: dict[str, Any],
    ) -> dict[str, Any]:
        """Search wisdom memory for context relevant to the input."""
        query = str(inputs.get(self.input_key, ""))
        if not query:
            return {self.memory_key: "" if not self._return_messages else []}

        results = _run_async(
            self._agent.memory.search(query, limit=self._limit),
        )

        if self._return_messages:
            return {
                self.memory_key: [
                    {
                        "content": str(r.get("content", r.get("text", ""))),
                        "tier": r.get("tier"),
                        "salience": r.get("salience"),
                    }
                    for r in results
                ],
            }

        formatted = "\n".join(
            f"- {r.get('content', r.get('text', ''))}" for r in results
        )
        return {self.memory_key: formatted}

    def save_context(
        self,
        inputs: dict[str, Any],
        outputs: dict[str, str],
    ) -> None:
        """Capture an interaction as a wisdom memory."""
        human_input = str(inputs.get(self.input_key, ""))
        ai_output = str(outputs.get(self.output_key, ""))

        if not human_input:
            return

        content: dict[str, Any] = {"user_message": human_input}
        if ai_output:
            content["agent_response"] = ai_output

        _run_async(
            self._agent.memory.capture(
                event_type=self._event_type,
                content=content,
            ),
        )
        logger.info(
            "Wisdom memory saved from LangChain context",
            extra={"input_len": len(human_input)},
        )

    def clear(self) -> None:
        """No-op — wisdom memories are persistent by design."""
