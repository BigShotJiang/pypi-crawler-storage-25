"""LangGraph integration — Wisdom Layer nodes for StateGraph pipelines.

Provides three reusable nodes that drop into any LangGraph ``StateGraph``:

- ``WisdomCaptureNode`` — captures messages into wisdom memory
- ``WisdomRecallNode`` — searches memory and injects context
- ``WisdomDreamNode`` — triggers a dream cycle for scheduled graphs

Install: ``pip install "wisdom-layer[langgraph]"``

Example::

    from langgraph.graph import StateGraph
    from wisdom_layer.integration.langgraph import (
        WisdomCaptureNode,
        WisdomRecallNode,
    )

    recall = WisdomRecallNode(agent)
    capture = WisdomCaptureNode(agent)

    graph = StateGraph(AgentState)
    graph.add_node("recall", recall)
    graph.add_node("llm", call_llm)
    graph.add_node("capture", capture)
    graph.add_edge("recall", "llm")
    graph.add_edge("llm", "capture")
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)


@dataclass
class WisdomRecallNode:
    """LangGraph node that searches wisdom memory and injects context.

    Reads the ``messages`` key from state (last human message), searches
    the agent's memory, and writes results to ``wisdom_context``.

    Args:
        agent: Initialized WisdomAgent instance.
        limit: Maximum number of memories to retrieve.
        context_key: State key to write retrieved context into.
        message_key: State key to read the query from.
    """

    agent: WisdomAgent
    limit: int = 5
    context_key: str = "wisdom_context"
    message_key: str = "messages"

    async def __call__(self, state: dict[str, Any]) -> dict[str, Any]:
        """Search memory for context relevant to the latest message."""
        query = _extract_query(state, self.message_key)
        if not query:
            return {self.context_key: []}

        results = await self.agent.memory.search(query, limit=self.limit)
        context = [
            {
                "content": str(r.get("content", r.get("text", ""))),
                "tier": r.get("tier"),
                "salience": r.get("salience"),
                "memory_id": r.get("id"),
            }
            for r in results
        ]
        logger.info(
            "Wisdom recall complete",
            extra={"query_len": len(query), "results": len(context)},
        )
        return {self.context_key: context}


@dataclass
class WisdomCaptureNode:
    """LangGraph node that captures interaction into wisdom memory.

    Reads the latest human message and AI response from state, then
    captures them as a memory via ``agent.memory.capture()``.

    Args:
        agent: Initialized WisdomAgent instance.
        event_type: Event type string for the captured memory.
        message_key: State key to read messages from.
    """

    agent: WisdomAgent
    event_type: str = "interaction"
    message_key: str = "messages"

    async def __call__(self, state: dict[str, Any]) -> dict[str, Any]:
        """Capture the latest interaction as a wisdom memory."""
        messages = state.get(self.message_key, [])
        if not messages:
            return {}

        human_msg, ai_msg = _extract_last_exchange(messages)
        if not human_msg:
            return {}

        content: dict[str, Any] = {"user_message": human_msg}
        if ai_msg:
            content["agent_response"] = ai_msg

        result = await self.agent.memory.capture(
            event_type=self.event_type,
            content=content,
        )
        mem_id = result.get("memory_id") if isinstance(result, dict) else None
        logger.info(
            "Wisdom capture complete",
            extra={"memory_id": mem_id},
        )
        return {}


@dataclass
class WisdomDreamNode:
    """LangGraph node that triggers a dream cycle.

    Useful in scheduled graphs or end-of-session flows to run
    the agent's reflection pipeline.

    Args:
        agent: Initialized WisdomAgent instance.
        result_key: State key to write the dream result into.
    """

    agent: WisdomAgent
    result_key: str = "dream_result"

    async def __call__(self, state: dict[str, Any]) -> dict[str, Any]:
        """Trigger a dream cycle and return the result."""
        result = await self.agent.dreams.trigger()
        logger.info(
            "Wisdom dream complete",
            extra={"cycle_id": result.get("cycle_id")},
        )
        return {self.result_key: result}


@dataclass
class WisdomDirectivesNode:
    """LangGraph node that retrieves active directives as system context.

    Fetches the agent's active behavioral directives and writes them
    to state so downstream LLM nodes can include them in prompts.

    Args:
        agent: Initialized WisdomAgent instance.
        context_key: State key to write directives into.
    """

    agent: WisdomAgent
    context_key: str = "wisdom_directives"

    async def __call__(self, state: dict[str, Any]) -> dict[str, Any]:
        """Retrieve active directives for prompt injection."""
        directives = await self.agent.directives.active()
        texts = [d.text if hasattr(d, "text") else str(d) for d in directives]
        return {self.context_key: texts}


def _extract_query(state: dict[str, Any], message_key: str) -> str:
    """Extract a search query from the latest human message in state."""
    messages = state.get(message_key, [])
    if not messages:
        return ""

    last = messages[-1]
    if isinstance(last, dict):
        return str(last.get("content", ""))
    if hasattr(last, "content"):
        return str(last.content)
    return str(last)


def _extract_last_exchange(
    messages: list[Any],
) -> tuple[str, str | None]:
    """Extract the last human message and optional AI response."""
    human_msg = ""
    ai_msg: str | None = None

    for msg in reversed(messages):
        role = _get_role(msg)
        content = _get_content(msg)

        if role == "ai" and ai_msg is None:
            ai_msg = content
        elif role == "human" and not human_msg:
            human_msg = content
            break

    return human_msg, ai_msg


def _get_role(msg: Any) -> str:
    if isinstance(msg, dict):
        role = str(msg.get("role", msg.get("type", "")))
    elif hasattr(msg, "type"):
        role = str(msg.type)
    elif hasattr(msg, "role"):
        role = str(msg.role)
    else:
        return "unknown"

    role_map = {"user": "human", "assistant": "ai", "system": "system"}
    return role_map.get(role, role)


def _get_content(msg: Any) -> str:
    if isinstance(msg, dict):
        return str(msg.get("content", ""))
    if hasattr(msg, "content"):
        return str(msg.content)
    return str(msg)
