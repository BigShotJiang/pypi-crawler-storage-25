"""respond_loop() — reference integration helper.

# Reference integration — not a stable SDK surface

This is the canonical stitching of:
    snapshot → compose → LLM → executive veto → post-hoc critic → event emission.

Customers are free to:
- Use it verbatim for greenfield integrations
- Fork it as a starting point and customize
- Ignore it entirely and drive primitives directly

Behavior changes are allowed within a minor version; the primitives
it wraps are not. Customers who want to pin behavior should fork
``respond.py`` into their own repo.

Doc reference: ``06_extraction_plan.md`` §0.10,
``11_integration_ergonomics_resolutions.md`` §"Hybrid Mode".
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from wisdom_layer.context.composer import ContextComposer
from wisdom_layer.runtime.snapshot import SnapshotScope

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)


@dataclass
class RespondResult:
    """Result of a single respond_loop invocation.

    Attributes:
        response: The LLM-generated text response.
        snapshot_id: ID of the snapshot scope used for this response.
        composed_chars: Total character count of the composed context.
        truncated_layers: Names of layers that were truncated.
        memories_used: Number of memories included in context.
        metadata: Additional metadata from the composition/LLM call.
    """

    response: str = ""
    snapshot_id: str = ""
    composed_chars: int = 0
    truncated_layers: list[str] = field(default_factory=list)
    memories_used: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


async def respond_loop(
    agent: WisdomAgent,
    prompt: str,
    *,
    hard_constraints: str = "",
    session_context: list[dict[str, str]] | None = None,
    memory_limit: int = 5,
    min_salience: float = 0.0,
    max_context_chars: int = 100_000,
) -> RespondResult:
    """Reference integration: snapshot → compose → LLM → respond.

    This helper stitches the core primitives into a single call for
    common use cases. It is **not** a stable SDK surface — fork it
    for production use.

    Args:
        agent: The WisdomAgent instance.
        prompt: The user's input text.
        hard_constraints: Identity axioms / safety rails for layer 0.
        session_context: Recent session messages for layer 4.
        memory_limit: Max memories to retrieve for layer 3.
        min_salience: Minimum salience for memory search.
        max_context_chars: Character budget for composition.

    Returns:
        A :class:`RespondResult` with the LLM response and metadata.
    """
    scope = SnapshotScope(
        clock=agent._clock,
        max_snapshot_seconds=agent._config.resource_limits.max_snapshot_seconds,
    )

    async with scope as snap:
        # 1. Retrieve memories
        memories = await agent._backend.search_memories(
            agent_id=agent._agent_id,
            query=prompt,
            limit=memory_limit,
            min_salience=min_salience,
        )

        # 2. Retrieve active directives
        directives_raw = await agent._backend.list_directives(
            agent_id=agent._agent_id,
        )
        directive_texts = [
            d["text"] if isinstance(d, dict) else str(d)
            for d in directives_raw
        ]

        # 3. Compose context
        composer = ContextComposer(
            agent._config,
            max_context_chars=max_context_chars,
        )
        composed = composer.compose(
            raw_prompt=prompt,
            hard_constraints=hard_constraints,
            active_directives=directive_texts,
            relevant_memories=memories,
            session_context=session_context,
        )

        # 4. Build messages for LLM
        system_parts = []
        for layer_name in [
            "hard_constraints",
            "active_directives",
            "personality",
            "relevant_memories",
            "session_context",
            "critic_guidance",
        ]:
            text = composed.layers.get(layer_name, "")
            if text:
                system_parts.append(f"[{layer_name}]\n{text}")

        system_msg = "\n\n".join(system_parts)
        user_msg = composed.layers.get("raw_prompt", prompt)

        # 5. LLM call
        response_text = await agent._model.generate(
            messages=[{"role": "user", "content": user_msg}],
            system=system_msg,
        )
        await agent._record_llm_usage(category="respond", purpose="respond_loop")

        # 6. Emit event
        await agent._emit(
            "respond.completed",
            data={
                "snapshot_id": snap.snapshot_id,
                "composed_chars": composed.total_chars,
                "memories_used": len(memories),
                "truncated_layers": composed.truncated_layers,
            },
        )

        return RespondResult(
            response=response_text,
            snapshot_id=snap.snapshot_id,
            composed_chars=composed.total_chars,
            truncated_layers=composed.truncated_layers,
            memories_used=len(memories),
            metadata=composed.metadata,
        )
