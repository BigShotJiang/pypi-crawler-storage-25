"""Integration helpers for the Wisdom Layer SDK.

Provides framework adapters for LangGraph, LangChain, and CrewAI,
plus the ``respond_loop`` reference integration.

Install framework-specific extras::

    pip install "wisdom-layer[langgraph]"
    pip install "wisdom-layer[langchain]"

Doc reference: ``06_extraction_plan.md`` §0.10,
``11_integration_ergonomics_resolutions.md`` §"Hybrid Mode".
"""

from wisdom_layer.integration.respond import respond_loop

__all__ = ["respond_loop"]
