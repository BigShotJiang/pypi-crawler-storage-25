"""Ollama LLM adapter — local / self-hosted models.

Talks to an Ollama server over ``/api/chat`` and ``/api/embeddings``.
Designed for the privacy-first / offline developer: no third-party
network calls, no API key, no vendored SDK. ``httpx`` is already a
runtime dependency so this adapter pulls nothing extra.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, cast

import httpx

from wisdom_layer.errors import ModelAdapterError
from wisdom_layer.llm._embedding_registry import lookup_dim
from wisdom_layer.llm.base import BaseLLMAdapter
from wisdom_layer.llm.errors import LLMRateLimitError, LLMServerError, LLMTimeoutError
from wisdom_layer.llm.types import AdapterUsage

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "http://localhost:11434"
DEFAULT_MODEL = "llama3.2"
DEFAULT_EMBED_MODEL = "nomic-embed-text"


class OllamaAdapter(BaseLLMAdapter):
    """LLM adapter for a locally running Ollama server.

    Args:
        base_url: Ollama server URL. Falls back to the
            ``OLLAMA_BASE_URL`` env var, then to
            ``http://localhost:11434``.
        model: Chat model name (default ``llama3.2``).
        embedding_model: Embedding model name (default
            ``nomic-embed-text``). The returned vector dimension is
            whatever the model emits — pick a single embed model per
            deployment to keep stored vectors consistent.
        timeout: Per-request timeout in seconds. Local inference can
            be slow; default 120s.
    """

    def __init__(
        self,
        *,
        base_url: str | None = None,
        model: str = DEFAULT_MODEL,
        embedding_model: str = DEFAULT_EMBED_MODEL,
        timeout: float = 120.0,
    ) -> None:
        resolved_url = (
            base_url if base_url is not None
            else os.environ.get("OLLAMA_BASE_URL", DEFAULT_BASE_URL)
        )
        self._base_url = resolved_url.rstrip("/")
        self._model = model
        self._embed_model = embedding_model
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None
        self.model_id = f"ollama:{model}"
        # Embedder identity — backend reads these via bind_embedder().
        # If unknown to the registry we keep a 384 placeholder; warmup()
        # probes the actual dim from a single network embed call.
        self.embedding_model_id = embedding_model
        self.embedding_dim = lookup_dim(embedding_model) or 384

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=self._timeout,
            )
        return self._client

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def warmup(self) -> None:
        """Probe :attr:`embedding_dim` if the embedder isn't in the registry.

        Ollama runs the embedding model server-side, so warmup is a single
        network embed call only when the dim isn't already known. Best-effort:
        network errors are logged and the first real embed call retries.
        """
        if lookup_dim(self._embed_model) is not None:
            return
        try:
            vec = await self.embed("warmup")
        except Exception:
            logger.warning(
                "Ollama embedder warmup probe failed; first embed() will retry",
                exc_info=True,
                extra={"model": self._embed_model},
            )
            return
        probed_dim = len(vec)
        if probed_dim != self.embedding_dim:
            logger.info(
                "Ollama embedder dim updated from probe",
                extra={
                    "model": self._embed_model,
                    "registry_dim": self.embedding_dim,
                    "probed_dim": probed_dim,
                },
            )
            self.embedding_dim = probed_dim

    def _wrap_transport_error(self, endpoint: str, exc: Exception) -> ModelAdapterError:
        return ModelAdapterError(
            f"Ollama is not reachable at {self._base_url}{endpoint} "
            f"({type(exc).__name__}: {exc}). "
            "Start it with `ollama serve` or pass base_url=... to "
            "OllamaAdapter."
        )

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Generate text via Ollama's ``/api/chat`` endpoint."""
        client = self._get_client()

        api_messages: list[dict[str, str]] = []
        if system:
            api_messages.append({"role": "system", "content": system})
        api_messages.extend(messages)

        payload: dict[str, Any] = {
            "model": self._model,
            "messages": api_messages,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }

        try:
            response = await client.post("/api/chat", json=payload)
        except (httpx.ConnectError, httpx.ConnectTimeout) as e:
            raise LLMServerError(
                f"Ollama is not reachable at {self._base_url}/api/chat "
                f"({type(e).__name__}: {e}). Start it with `ollama serve`."
            ) from e
        except httpx.ReadTimeout as e:
            raise LLMTimeoutError(f"Ollama chat timed out: {e}") from e
        except httpx.HTTPError as e:
            raise ModelAdapterError(f"Ollama chat request failed: {e}") from e

        if response.status_code == 404:
            raise ModelAdapterError(
                f"Ollama model '{self._model}' not found. "
                f"Pull it with `ollama pull {self._model}`."
            )
        if response.status_code == 429:
            raise LLMRateLimitError(f"Ollama rate limit (429): {response.text[:200]}")
        if response.status_code >= 500:
            raise LLMServerError(
                f"Ollama server error ({response.status_code}): {response.text[:200]}"
            )
        if response.status_code >= 400:
            raise ModelAdapterError(
                f"Ollama chat returned {response.status_code}: {response.text[:200]}"
            )

        body = response.json()
        text = body.get("message", {}).get("content", "")
        input_tokens = int(body.get("prompt_eval_count", 0) or 0)
        output_tokens = int(body.get("eval_count", 0) or 0)
        # Local inference — no per-token charge, but we still log tokens
        # so the ledger captures throughput.
        self.last_usage = AdapterUsage(
            model_id=self.model_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=0.0,
        )
        logger.info(
            "LLM generation complete",
            extra={
                "model": self._model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
        )
        return cast("str", text)

    async def generate_structured(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        schema: dict[str, Any],
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Generate JSON output using Ollama's ``format: "json"`` mode.

        One retry on malformed JSON with a stricter reminder prompt.
        """
        client = self._get_client()

        schema_str = json.dumps(schema, indent=2)
        structured_system = (
            f"{system}\n\n"
            f"Respond with valid JSON matching this schema:\n{schema_str}\n\n"
            "Output ONLY the JSON object, no other text."
        ).strip()

        api_messages: list[dict[str, str]] = [
            {"role": "system", "content": structured_system}
        ]
        api_messages.extend(messages)

        payload: dict[str, Any] = {
            "model": self._model,
            "messages": api_messages,
            "stream": False,
            "format": "json",
            "options": {"temperature": temperature},
        }

        raw_text = ""
        for attempt in range(2):
            try:
                response = await client.post("/api/chat", json=payload)
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.ConnectTimeout) as e:
                raise self._wrap_transport_error("/api/chat", e) from e
            except httpx.HTTPError as e:
                raise ModelAdapterError(
                    f"Ollama chat request failed: {e}"
                ) from e

            if response.status_code >= 400:
                raise ModelAdapterError(
                    f"Ollama chat returned {response.status_code}: "
                    f"{response.text[:200]}"
                )

            body = response.json()
            raw_text = body.get("message", {}).get("content", "")
            input_tokens = int(body.get("prompt_eval_count", 0) or 0)
            output_tokens = int(body.get("eval_count", 0) or 0)
            self.last_usage = AdapterUsage(
                model_id=self.model_id,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=0.0,
            )
            try:
                return cast("dict[str, Any]", json.loads(raw_text))
            except json.JSONDecodeError:
                if attempt == 0:
                    api_messages.append(
                        {
                            "role": "user",
                            "content": (
                                "Your previous output was not valid JSON. "
                                "Return only the JSON object, nothing else."
                            ),
                        }
                    )
                    continue
                raise ModelAdapterError(
                    "Failed to parse Ollama structured output as JSON after "
                    f"retry. Raw output: {raw_text[:200]}"
                ) from None

        raise ModelAdapterError(
            f"Failed to parse Ollama structured output. Raw: {raw_text[:200]}"
        )

    async def embed(self, text: str) -> list[float]:
        """Embed text via Ollama's ``/api/embeddings`` endpoint."""
        client = self._get_client()
        payload = {"model": self._embed_model, "prompt": text}

        try:
            response = await client.post("/api/embeddings", json=payload)
        except (httpx.ConnectError, httpx.ConnectTimeout) as e:
            raise LLMServerError(
                f"Ollama is not reachable at {self._base_url}/api/embeddings "
                f"({type(e).__name__}: {e}). Start it with `ollama serve`."
            ) from e
        except httpx.ReadTimeout as e:
            raise LLMTimeoutError(f"Ollama embeddings timed out: {e}") from e
        except httpx.HTTPError as e:
            raise ModelAdapterError(f"Ollama embeddings request failed: {e}") from e

        if response.status_code == 404:
            raise ModelAdapterError(
                f"Ollama embedding model '{self._embed_model}' not found. "
                f"Pull it with `ollama pull {self._embed_model}`."
            )
        if response.status_code >= 500:
            raise LLMServerError(
                f"Ollama server error ({response.status_code}): {response.text[:200]}"
            )
        if response.status_code >= 400:
            raise ModelAdapterError(
                f"Ollama embeddings returned {response.status_code}: {response.text[:200]}"
            )

        body = response.json()
        vector = body.get("embedding")
        if not isinstance(vector, list) or not vector:
            raise ModelAdapterError(
                f"Ollama embeddings returned no vector. Body: {body!r}"
            )
        return cast("list[float]", vector)

    async def health_check(self) -> bool:
        """Probe the server root — Ollama returns 200 on ``/``."""
        try:
            client = self._get_client()
            response = await client.get("/")
            return response.status_code == 200
        except httpx.HTTPError:
            return False
