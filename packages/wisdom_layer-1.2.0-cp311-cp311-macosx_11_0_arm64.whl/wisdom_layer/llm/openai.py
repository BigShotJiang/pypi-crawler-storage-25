"""OpenAI LLM adapter — GPT models."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, cast

from wisdom_layer.cost.pricing import PricingTable
from wisdom_layer.errors import ModelAdapterError
from wisdom_layer.llm._embedding_registry import lookup_dim
from wisdom_layer.llm.base import BaseLLMAdapter
from wisdom_layer.llm.errors import (
    LLMAuthError,
    LLMBadRequestError,
    LLMRateLimitError,
    LLMServerError,
    LLMTimeoutError,
)
from wisdom_layer.llm.types import AdapterUsage

logger = logging.getLogger(__name__)

EMBEDDING_DIM = 384


def _raise_openai_error(exc: Exception) -> None:
    """Map an OpenAI SDK exception to a Wisdom Layer typed error and re-raise.

    Lazy-imports ``openai`` so this module stays importable even when the
    optional ``openai`` package isn't installed (tests that fully mock the
    client never load the SDK). If the SDK isn't available we fall through
    to ``ModelAdapterError`` — there's nothing else useful we can dispatch
    on. Never returns.
    """
    try:
        import openai as _openai
    except ImportError:
        raise ModelAdapterError(
            f"OpenAI API error: {exc}. "
            "Check your API key and endpoint configuration."
        ) from exc

    if isinstance(exc, _openai.RateLimitError):
        raise LLMRateLimitError(f"OpenAI rate limit (429): {exc}") from exc
    if isinstance(exc, _openai.APITimeoutError):
        raise LLMTimeoutError(f"OpenAI request timed out: {exc}") from exc
    if isinstance(exc, _openai.APIConnectionError):
        raise LLMTimeoutError(f"OpenAI connection error: {exc}") from exc
    if isinstance(exc, _openai.InternalServerError):
        raise LLMServerError(f"OpenAI internal server error (500): {exc}") from exc
    if isinstance(exc, _openai.APIStatusError):
        status = exc.status_code
        if status >= 500:
            raise LLMServerError(f"OpenAI server error ({status}): {exc}") from exc
        if status in (401, 403):
            raise LLMAuthError(f"OpenAI auth error ({status}): {exc}") from exc
        if status == 400:
            raise LLMBadRequestError(f"OpenAI bad request: {exc}") from exc
        raise ModelAdapterError(f"OpenAI API error ({status}): {exc}") from exc
    raise ModelAdapterError(
        f"OpenAI API error: {exc}. "
        "Check your API key and endpoint configuration."
    ) from exc


class OpenAIAdapter(BaseLLMAdapter):
    """LLM adapter for OpenAI GPT models.

    Uses the OpenAI Python SDK for text generation and
    sentence-transformers for local embeddings (384-dim,
    consistent with all other adapters).

    Args:
        api_key: OpenAI API key.
        model: Model ID for text generation (default: gpt-4.1-nano).
        embedding_model: Local embedding model name (default: all-MiniLM-L6-v2).
    """

    def __init__(
        self,
        *,
        api_key: str,
        model: str = "gpt-4.1-nano",
        embedding_model: str = "all-MiniLM-L6-v2",
    ) -> None:
        self._api_key = api_key
        self._model = model
        self.model_id = model
        self._embedding_model_name = embedding_model
        self._client: Any = None
        self._embedder: Any = None
        self._pricing = PricingTable()
        # Embedder identity — backend reads these via bind_embedder().
        self.embedding_model_id = embedding_model
        self.embedding_dim = lookup_dim(embedding_model) or 384

    def _get_client(self) -> Any:
        """Lazy-initialize the OpenAI client."""
        if self._client is None:
            try:
                from openai import AsyncOpenAI
            except ImportError as e:
                raise ModelAdapterError(
                    "openai package required. Install with: "
                    "pip install wisdom-layer[openai]"
                ) from e
            # max_retries=0: WL's RetryPolicy owns the retry loop.
            self._client = AsyncOpenAI(api_key=self._api_key, max_retries=0)
        return self._client

    def _get_embedder(self) -> Any:
        """Lazy-initialize the sentence-transformers model."""
        if self._embedder is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as e:
                raise ModelAdapterError(
                    "sentence-transformers required for embeddings. Install with: "
                    "pip install sentence-transformers"
                ) from e
            self._embedder = SentenceTransformer(self._embedding_model_name)
            logger.info(
                "Embedding model loaded",
                extra={"model": self._embedding_model_name},
            )
        return self._embedder

    async def warmup(self) -> None:
        """Eagerly load the embedding model + warm its first-encode path.

        See :meth:`BaseLLMAdapter.warmup` — pays the multi-second
        sentence-transformers load + first-encode cost up front so
        ``memory.search()`` doesn't stall on first use. Best-effort:
        missing optional deps are logged, not raised. Also probes
        :attr:`embedding_dim` from the result so backends bound after
        warmup see the correct vector shape for non-registry models.
        """
        probed_dim: int | None = None

        def _load_and_prime() -> int:
            embedder = self._get_embedder()
            vec = embedder.encode("warmup", normalize_embeddings=True)
            return int(len(vec))

        try:
            probed_dim = await asyncio.to_thread(_load_and_prime)
        except ModelAdapterError:
            logger.warning(
                "Embedder warmup skipped: sentence-transformers not installed",
                extra={"model": self._embedding_model_name},
            )
        except Exception:
            logger.warning(
                "Embedder warmup failed; first embed() call will retry",
                exc_info=True,
                extra={"model": self._embedding_model_name},
            )

        if probed_dim is not None and probed_dim != self.embedding_dim:
            logger.info(
                "Embedder dim updated from probe",
                extra={
                    "model": self._embedding_model_name,
                    "registry_dim": self.embedding_dim,
                    "probed_dim": probed_dim,
                },
            )
            self.embedding_dim = probed_dim

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Generate text using an OpenAI model."""
        client = self._get_client()

        api_messages: list[dict[str, str]] = []
        if system:
            api_messages.append({"role": "system", "content": system})
        api_messages.extend(messages)

        try:
            response = await client.chat.completions.create(
                model=self._model,
                messages=api_messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
        except Exception as e:
            _raise_openai_error(e)
            raise  # unreachable, satisfies type checker

        text = response.choices[0].message.content or ""
        input_tokens = int(getattr(response.usage, "prompt_tokens", 0) or 0)
        output_tokens = int(getattr(response.usage, "completion_tokens", 0) or 0)
        self.last_usage = AdapterUsage(
            model_id=self._model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=self._pricing.compute_cost(
                self._model, input_tokens, output_tokens,
            ),
        )
        logger.info(
            "LLM generation complete",
            extra={
                "model": self._model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
        )
        return cast("str", text)

    async def embed(self, text: str) -> list[float]:
        """Generate embedding using local sentence-transformers model."""
        embedder = self._get_embedder()
        vec = embedder.encode(text, normalize_embeddings=True)
        return cast("list[float]", vec.tolist())

    async def generate_structured(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        schema: dict[str, Any],
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Generate structured JSON output using OpenAI's native JSON mode."""
        client = self._get_client()

        api_messages: list[dict[str, str]] = []
        schema_str = json.dumps(schema, indent=2)
        structured_system = (
            f"{system}\n\n"
            f"Respond with valid JSON matching this schema:\n{schema_str}"
        ).strip()
        api_messages.append({"role": "system", "content": structured_system})
        api_messages.extend(messages)

        try:
            response = await client.chat.completions.create(
                model=self._model,
                messages=api_messages,
                temperature=temperature,
                response_format={"type": "json_object"},
            )
        except Exception as e:
            _raise_openai_error(e)
            raise  # unreachable, satisfies type checker

        text = response.choices[0].message.content or ""
        input_tokens = int(getattr(response.usage, "prompt_tokens", 0) or 0)
        output_tokens = int(getattr(response.usage, "completion_tokens", 0) or 0)
        self.last_usage = AdapterUsage(
            model_id=self._model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=self._pricing.compute_cost(
                self._model, input_tokens, output_tokens,
            ),
        )
        logger.info(
            "LLM structured generation complete",
            extra={
                "model": self._model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
        )
        try:
            return cast("dict[str, Any]", json.loads(text))
        except json.JSONDecodeError as e:
            raise ModelAdapterError(
                f"Failed to parse OpenAI structured output as JSON: {e}\n"
                f"Raw output: {text[:200]}"
            ) from e
