"""LLM router error classification.

Doc reference: ``12_llm_routing.md`` §"Error Classification".
"""

from __future__ import annotations

from wisdom_layer.errors import ModelAdapterError


class LLMRouterError(ModelAdapterError):
    """Base for all router-level LLM errors."""


# --- High-level routing errors ---


class NoAvailableModelError(LLMRouterError):
    """No adapter available at the requested tier (all open / rate-limited)."""

    def __init__(self, tier: str, reason: str = "") -> None:
        self.tier = tier
        msg = f"No available model at tier '{tier}'"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class StructuredOutputTierError(LLMRouterError):
    """Structured output requested but no adapter meets the required tier."""

    def __init__(self, required_tier: str, available_tiers: list[str]) -> None:
        self.required_tier = required_tier
        self.available_tiers = available_tiers
        super().__init__(
            f"Structured output requires tier '{required_tier}' or higher, "
            f"but only {available_tiers} available"
        )


# --- Transient (counted toward circuit breaker) ---


class LLMTransientError(LLMRouterError):
    """Transient provider failure — retry or circuit-break."""


class LLMRateLimitError(LLMTransientError):
    """HTTP 429 from provider."""


class LLMTimeoutError(LLMTransientError):
    """Request timed out."""


class LLMServerError(LLMTransientError):
    """HTTP 5xx from provider."""


# --- Terminal (NOT counted toward circuit breaker) ---


class LLMAuthError(LLMRouterError):
    """HTTP 401/403 from provider."""


class LLMBadRequestError(LLMRouterError):
    """HTTP 400 from provider."""


class LLMContentFilterError(LLMRouterError):
    """Content filter triggered by provider."""
