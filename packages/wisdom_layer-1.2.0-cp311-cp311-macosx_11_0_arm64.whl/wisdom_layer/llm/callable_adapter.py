"""CallableAdapter — escape hatch for customer-provided inference.

Doc reference: ``12_llm_routing.md`` §"CallableAdapter".
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from wisdom_layer.errors import ModelAdapterError
from wisdom_layer.llm.base import BaseLLMAdapter
from wisdom_layer.llm.types import (
    AdapterUsage,
    CompletionResult,
    Message,
    ModelTier,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable


class CallableAdapter(BaseLLMAdapter):
    """Adapter that wraps a customer-provided async callable.

    This is the only sanctioned way to bring custom inference into the
    Wisdom Layer — no plugin discovery, no entry points, no dynamic imports.

    Example::

        async def my_inference(messages, *, temperature, max_tokens, **kw):
            return {"text": "...", "input_tokens": 10, "output_tokens": 5, "cost_usd": 0.0}

        adapter = CallableAdapter(
            model_id="acme-llama3-70b",
            tier="high",
            fn=my_inference,
        )
    """

    def __init__(
        self,
        *,
        model_id: str,
        tier: ModelTier,
        fn: Callable[..., Awaitable[dict[str, Any]]],
        supports_structured_json: bool = False,
        supports_tool_calls: bool = False,
        input_rate_per_mtok: float = 0.0,
        output_rate_per_mtok: float = 0.0,
    ) -> None:
        self.model_id = model_id
        self.tier = tier
        self._fn = fn
        self.supports_structured_json = supports_structured_json
        self.supports_tool_calls = supports_tool_calls
        self.input_rate_per_mtok = input_rate_per_mtok
        self.output_rate_per_mtok = output_rate_per_mtok

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Delegate to the wrapped callable."""
        try:
            result = await self._fn(
                messages, system=system, temperature=temperature, max_tokens=max_tokens
            )
        except ModelAdapterError:
            raise
        except Exception as exc:
            raise ModelAdapterError(
                f"CallableAdapter '{self.model_id}' failed: {exc}. "
                f"Check that your model server is running and reachable."
            ) from exc
        self.last_usage = AdapterUsage(
            model_id=self.model_id,
            input_tokens=int(result.get("input_tokens", 0) or 0),
            output_tokens=int(result.get("output_tokens", 0) or 0),
            cost_usd=float(result.get("cost_usd", 0.0) or 0.0),
        )
        return str(result.get("text", ""))

    async def embed(self, text: str) -> list[float]:
        """CallableAdapter does not support embeddings by default."""
        raise NotImplementedError(
            f"CallableAdapter '{self.model_id}' does not provide embeddings. "
            f"Register a BaseEmbeddingAdapter instead."
        )

    async def generate_structured(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        schema: dict[str, Any],
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Delegate to the wrapped callable with schema hint."""
        result = await self._fn(
            messages,
            system=system,
            temperature=temperature,
            schema=schema,
        )
        if isinstance(result, dict):
            self.last_usage = AdapterUsage(
                model_id=self.model_id,
                input_tokens=int(result.get("input_tokens", 0) or 0),
                output_tokens=int(result.get("output_tokens", 0) or 0),
                cost_usd=float(result.get("cost_usd", 0.0) or 0.0),
            )
        return result

    async def complete(
        self,
        messages: list[Message],
        *,
        temperature: float = 0.7,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        request_id: str | None = None,
    ) -> CompletionResult:
        """Router-facing completion via the wrapped callable."""
        legacy_msgs = [{"role": m.role, "content": m.content} for m in messages]
        try:
            result = await self._fn(
                legacy_msgs,
                temperature=temperature,
                max_tokens=max_tokens or self.max_output_tokens,
            )
        except ModelAdapterError:
            raise
        except Exception as exc:
            raise ModelAdapterError(
                f"CallableAdapter '{self.model_id}' failed: {exc}. "
                f"Check that your model server is running and reachable."
            ) from exc
        return CompletionResult(
            text=str(result.get("text", "")),
            input_tokens=int(result.get("input_tokens", 0)),
            output_tokens=int(result.get("output_tokens", 0)),
            cost_usd=float(result.get("cost_usd", 0.0)),
            finish_reason="stop",
            model_id=self.model_id,
        )
