"""Anthropic LLM adapter — Claude models."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, cast

from wisdom_layer.cost.pricing import PricingTable
from wisdom_layer.errors import ModelAdapterError
from wisdom_layer.llm._embedding_registry import lookup_dim
from wisdom_layer.llm.base import BaseLLMAdapter
from wisdom_layer.llm.errors import (
    LLMAuthError,
    LLMBadRequestError,
    LLMRateLimitError,
    LLMServerError,
    LLMTimeoutError,
)
from wisdom_layer.llm.types import AdapterUsage

logger = logging.getLogger(__name__)

# Default embedding dimensions for internal use
EMBEDDING_DIM = 384


def _raise_anthropic_error(exc: Exception) -> None:
    """Map an Anthropic SDK exception to a Wisdom Layer typed error and re-raise.

    Lazy-imports ``anthropic`` so this module stays importable even when the
    optional ``anthropic`` package isn't installed (tests that fully mock the
    client never load the SDK). If the SDK isn't available we fall through
    to ``ModelAdapterError``. Never returns.
    """
    try:
        import anthropic as _anthropic
    except ImportError:
        raise ModelAdapterError(f"Anthropic API error: {exc}") from exc

    if isinstance(exc, _anthropic.RateLimitError):
        raise LLMRateLimitError(f"Anthropic rate limit (429): {exc}") from exc
    if isinstance(exc, _anthropic.APITimeoutError):
        raise LLMTimeoutError(f"Anthropic request timed out: {exc}") from exc
    if isinstance(exc, _anthropic.APIConnectionError):
        raise LLMTimeoutError(f"Anthropic connection error: {exc}") from exc
    if isinstance(exc, _anthropic.InternalServerError):
        raise LLMServerError(f"Anthropic internal server error (500): {exc}") from exc
    if isinstance(exc, _anthropic.APIStatusError):
        status = exc.status_code
        if status >= 500:
            raise LLMServerError(f"Anthropic server error ({status}): {exc}") from exc
        if status in (401, 403):
            raise LLMAuthError(f"Anthropic auth error ({status}): {exc}") from exc
        if status == 400:
            raise LLMBadRequestError(f"Anthropic bad request: {exc}") from exc
        raise ModelAdapterError(f"Anthropic API error ({status}): {exc}") from exc
    raise ModelAdapterError(f"Anthropic API error: {exc}") from exc


class AnthropicAdapter(BaseLLMAdapter):
    """LLM adapter for Anthropic Claude models.

    Uses the Anthropic Python SDK for text generation and
    sentence-transformers for local embeddings.

    Args:
        api_key: Anthropic API key.
        model: Model ID for text generation (default: claude-haiku-4-5-20251001).
        embedding_model: Local embedding model name (default: all-MiniLM-L6-v2).
    """

    def __init__(
        self,
        *,
        api_key: str,
        model: str = "claude-haiku-4-5-20251001",
        embedding_model: str = "all-MiniLM-L6-v2",
        base_url: str = "https://api.anthropic.com",
    ) -> None:
        self._api_key = api_key
        self._model = model
        self.model_id = model
        self._embedding_model_name = embedding_model
        self._base_url = base_url
        self._client: Any = None
        self._embedder: Any = None
        self._pricing = PricingTable()
        # Embedder identity — backend reads these via bind_embedder().
        # If the model is unknown to the registry we keep the 384 default
        # and let warmup() probe the actual dim from a single embed call.
        self.embedding_model_id = embedding_model
        self.embedding_dim = lookup_dim(embedding_model) or 384

    def _get_client(self) -> Any:
        """Lazy-initialize the Anthropic client."""
        if self._client is None:
            try:
                import anthropic
            except ImportError as e:
                raise ModelAdapterError(
                    "anthropic package required. Install with: "
                    "pip install wisdom-layer[anthropic]"
                ) from e
            # max_retries=0: disable Anthropic SDK's built-in retries so
            # wisdom-layer's RetryPolicy owns the full retry loop for dream
            # steps and other idempotent LLM operations.
            self._client = anthropic.Anthropic(
                api_key=self._api_key,
                base_url=self._base_url,
                max_retries=0,
            )
        return self._client

    def _get_embedder(self) -> Any:
        """Lazy-initialize the sentence-transformers model."""
        if self._embedder is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as e:
                raise ModelAdapterError(
                    "sentence-transformers required for embeddings. Install with: "
                    "pip install sentence-transformers"
                ) from e
            self._embedder = SentenceTransformer(self._embedding_model_name)
            logger.info(
                "Embedding model loaded",
                extra={"model": self._embedding_model_name},
            )
        return self._embedder

    async def warmup(self) -> None:
        """Eagerly load the embedding model + warm its first-encode path.

        sentence-transformers' model load (10-30 s for medium models) plus the
        first ``encode()`` call (torch graph compilation, ~1-3 s) must not
        land on the user's first ``memory.search()``. We pay both costs in a
        worker thread during agent init. The probe vector is also used to
        update :attr:`embedding_dim` when the model isn't in the registry,
        so backends bound after warmup see the correct shape.

        Best-effort: if sentence-transformers is not installed (the user may
        be running directives-only) we log and continue; the first real
        embed call will surface :class:`ModelAdapterError` with the install
        instructions.
        """
        probed_dim: int | None = None

        def _load_and_prime() -> int:
            embedder = self._get_embedder()
            vec = embedder.encode("warmup", normalize_embeddings=True)
            return int(len(vec))

        try:
            probed_dim = await asyncio.to_thread(_load_and_prime)
        except ModelAdapterError:
            logger.warning(
                "Embedder warmup skipped: sentence-transformers not installed",
                extra={"model": self._embedding_model_name},
            )
        except Exception:
            logger.warning(
                "Embedder warmup failed; first embed() call will retry",
                exc_info=True,
                extra={"model": self._embedding_model_name},
            )

        if probed_dim is not None and probed_dim != self.embedding_dim:
            logger.info(
                "Embedder dim updated from probe",
                extra={
                    "model": self._embedding_model_name,
                    "registry_dim": self.embedding_dim,
                    "probed_dim": probed_dim,
                },
            )
            self.embedding_dim = probed_dim

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Generate text using Claude."""
        client = self._get_client()

        kwargs: dict[str, Any] = {
            "model": self._model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system

        try:
            response = client.messages.create(**kwargs)
        except Exception as e:
            _raise_anthropic_error(e)
            raise  # unreachable, satisfies type checker

        text = response.content[0].text
        input_tokens = int(response.usage.input_tokens)
        output_tokens = int(response.usage.output_tokens)
        self.last_usage = AdapterUsage(
            model_id=self._model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=self._pricing.compute_cost(
                self._model, input_tokens, output_tokens,
            ),
        )
        logger.info(
            "LLM generation complete",
            extra={
                "model": self._model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
        )
        return cast("str", text)

    async def embed(self, text: str) -> list[float]:
        """Generate embedding using local sentence-transformers model."""
        embedder = self._get_embedder()
        vec = embedder.encode(text, normalize_embeddings=True)
        return cast("list[float]", vec.tolist())

    async def generate_structured(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        schema: dict[str, Any],
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Generate structured JSON output from Claude."""
        schema_str = json.dumps(schema, indent=2)
        structured_system = (
            f"{system}\n\n"
            f"Respond with valid JSON matching this schema:\n{schema_str}\n\n"
            f"Output ONLY the JSON object, no other text."
        )

        text = await self.generate(
            messages=messages,
            system=structured_system,
            temperature=temperature,
        )

        # Strip markdown code fences if present
        cleaned = text.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            cleaned = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])

        try:
            return cast("dict[str, Any]", json.loads(cleaned))
        except json.JSONDecodeError as e:
            raise ModelAdapterError(
                f"Failed to parse structured output as JSON: {e}\nRaw output: {text[:200]}"
            ) from e
