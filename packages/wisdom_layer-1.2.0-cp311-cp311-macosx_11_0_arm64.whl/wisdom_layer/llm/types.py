"""Shared types for the LLM routing subsystem.

Doc reference: ``12_llm_routing.md``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

# ---------------------------------------------------------------------------
# Tier ordering
# ---------------------------------------------------------------------------

ModelTier = Literal["sota", "high", "mid", "cheap"]

TIER_ORDER: dict[ModelTier, int] = {"sota": 0, "high": 1, "mid": 2, "cheap": 3}
"""Lower number == higher priority. Fallback walks downward only."""


# ---------------------------------------------------------------------------
# Message & result shapes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Message:
    """Provider-agnostic message shape.

    Adapters translate this into provider-specific format.
    """

    role: Literal["system", "user", "assistant", "tool"]
    content: str
    name: str | None = None
    tool_call_id: str | None = None


@dataclass(frozen=True)
class CompletionResult:
    """Result from a text completion call."""

    text: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    finish_reason: Literal["stop", "length", "tool_call", "content_filter", "error"]
    model_id: str
    raw_provider_payload: dict[str, Any] | None = None


@dataclass(frozen=True)
class AdapterUsage:
    """Per-call token + cost footprint populated on ``BaseLLMAdapter``.

    Adapters set ``self.last_usage`` after every ``generate()`` or
    ``generate_structured()`` so callers (WisdomAgent) can record the
    call to the cost ledger without changing the legacy string return.

    ``cost_usd`` is computed from :class:`PricingTable` when the adapter
    knows its own ``model_id`` and the table has an entry; otherwise
    ``0.0``. Local inference (Ollama) intentionally reports ``0.0``.
    """

    model_id: str
    input_tokens: int
    output_tokens: int
    cost_usd: float = 0.0


@dataclass(frozen=True)
class StructuredResult:
    """Result from a structured (JSON) completion call."""

    parsed: Any
    raw_text: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    repair_attempts: int
    model_id: str


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class LLMRoutingConfig:
    """Configuration for the model router. All fields are T1 (customer-facing)."""

    # Resilience
    circuit_breaker_consecutive_failures: int = 2
    circuit_breaker_cooldown_seconds: int = 300
    request_timeout_seconds: float = 60.0
    request_max_retries: int = 0

    # Tier enforcement
    structured_required_tier: ModelTier = "high"

    # Fallback behavior
    fallback_enabled_default: bool = True


# ---------------------------------------------------------------------------
# Circuit breaker state
# ---------------------------------------------------------------------------


@dataclass
class CircuitBreakerState:
    """Per-adapter circuit breaker state machine."""

    model_id: str
    consecutive_failures: int = 0
    state: Literal["closed", "open", "half_open"] = "closed"
    opened_at_mono: float | None = None
    last_error: str | None = None
