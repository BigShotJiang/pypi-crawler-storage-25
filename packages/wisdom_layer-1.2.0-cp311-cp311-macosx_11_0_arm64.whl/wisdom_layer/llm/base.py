"""Abstract LLM adapter interface.

Doc reference: ``12_llm_routing.md`` §"BaseLLMAdapter".
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from wisdom_layer.llm.types import (
    AdapterUsage,
    CompletionResult,
    Message,
    ModelTier,
    StructuredResult,
)


class BaseLLMAdapter(ABC):
    """Abstract base class for LLM adapters.

    All LLM interactions in the SDK go through this interface,
    making the system model-agnostic. Each adapter instance
    represents one provider connection (one model_id, one API key).

    Subclasses must set the class-level metadata fields so the
    :class:`ModelRouter` can perform tier resolution and circuit
    breaking without inspecting the adapter at call time.

    v0.5 Phase 4: After each successful ``generate()`` /
    ``generate_structured()``, adapters set ``self.last_usage`` to an
    :class:`AdapterUsage` describing the call's token + cost footprint.
    ``WisdomAgent`` reads this immediately after each call to write a
    row to the cost ledger. The field is intentionally per-instance
    (not a thread-local) — adapters are expected to be used by one
    agent at a time; concurrent use across agents is a caller concern.
    """

    # --- Metadata (set by subclasses at init) ---
    model_id: str = "unknown"
    tier: ModelTier = "mid"
    supports_structured_json: bool = False
    supports_tool_calls: bool = False
    max_input_tokens: int = 4096
    max_output_tokens: int = 4096
    input_rate_per_mtok: float = 0.0
    output_rate_per_mtok: float = 0.0

    # --- Embedder identity (consumed by storage backends at bind_embedder) ---
    #: Stable identifier of the embedding model the adapter produces vectors
    #: for. Persisted with every memory row so vector search can refuse to
    #: compare across models. Adapters set this from their constructor.
    embedding_model_id: str = "unknown"
    #: Output vector length. Set from the registry at construction when the
    #: model is known; otherwise probed during ``warmup()`` by running one
    #: embed call and reading ``len(result)``.
    embedding_dim: int = 384

    # --- Per-call usage footprint (v0.5 Phase 4) ---
    #: Populated by generate()/generate_structured() on each successful
    #: call. None when the adapter has not been used yet or did not
    #: provide usage info.
    last_usage: AdapterUsage | None = None

    async def warmup(self) -> None:
        """Eagerly load expensive non-idempotent resources.

        Called from :meth:`WisdomAgent.initialize` so first-request latency
        is paid up-front rather than on the user's hot path. The default
        implementation is a no-op; adapters that lazy-load heavy resources
        (e.g., sentence-transformers embedding models) override this to
        load and prime them in a worker thread.

        Implementations must be idempotent (safe to call multiple times)
        and best-effort (a transient warmup failure should be logged but
        must not abort agent startup — the first real call will still
        surface the underlying error in context).
        """
        return None

    # --- Legacy API (kept for backward compatibility until Phase A) ---

    @abstractmethod
    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Generate a text response.

        Args:
            messages: Conversation messages in [{role, content}] format.
            system: Optional system prompt.
            temperature: Sampling temperature.
            max_tokens: Maximum tokens in response.

        Returns:
            The generated text response.
        """

    @abstractmethod
    async def embed(self, text: str) -> list[float]:
        """Generate an embedding vector for text.

        Args:
            text: The text to embed.

        Returns:
            Embedding vector as a list of floats.
        """

    @abstractmethod
    async def generate_structured(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        schema: dict[str, Any],
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Generate a structured (JSON) response matching a schema.

        Args:
            messages: Conversation messages.
            system: Optional system prompt.
            schema: JSON schema the response must match.
            temperature: Sampling temperature (lower for structured output).

        Returns:
            Parsed response matching the schema.
        """

    # --- New router-compatible API ---

    async def complete(
        self,
        messages: list[Message],
        *,
        temperature: float = 0.7,
        max_tokens: int | None = None,
        stop: list[str] | None = None,
        request_id: str | None = None,
    ) -> CompletionResult:
        """Router-facing completion entry point.

        Default implementation bridges to the legacy ``generate`` method.
        Adapters may override for richer token/cost reporting.
        """
        system_msgs = [m.content for m in messages if m.role == "system"]
        non_system = [m for m in messages if m.role != "system"]
        system = system_msgs[0] if system_msgs else ""
        user_msgs = [{"role": m.role, "content": m.content} for m in non_system]

        text = await self.generate(
            messages=user_msgs,
            system=system,
            temperature=temperature,
            max_tokens=max_tokens or self.max_output_tokens,
        )
        return CompletionResult(
            text=text,
            input_tokens=0,
            output_tokens=0,
            cost_usd=0.0,
            finish_reason="stop",
            model_id=self.model_id,
        )

    async def complete_structured(
        self,
        messages: list[Message],
        *,
        schema: dict[str, Any],
        temperature: float = 0.0,
        max_tokens: int | None = None,
        request_id: str | None = None,
    ) -> StructuredResult:
        """Router-facing structured completion.

        Default implementation bridges to the legacy ``generate_structured``.
        """
        system_msgs = [m.content for m in messages if m.role == "system"]
        non_system = [m for m in messages if m.role != "system"]
        system = system_msgs[0] if system_msgs else ""
        user_msgs = [{"role": m.role, "content": m.content} for m in non_system]

        parsed = await self.generate_structured(
            messages=user_msgs,
            system=system,
            schema=schema,
            temperature=temperature,
        )
        return StructuredResult(
            parsed=parsed,
            raw_text="",
            input_tokens=0,
            output_tokens=0,
            cost_usd=0.0,
            repair_attempts=0,
            model_id=self.model_id,
        )

    async def health_check(self) -> bool:
        """Check if the adapter can reach its provider. Override for real checks."""
        return True

    async def close(self) -> None:  # noqa: B027
        """Release resources. Override if the adapter holds connections."""


class BaseEmbeddingAdapter(ABC):
    """Abstract base for embedding-only adapters.

    Doc reference: ``12_llm_routing.md`` §"BaseEmbeddingAdapter".
    """

    model_id: str = "unknown-embed"
    embedding_dim: int = 384
    max_input_chars: int = 8192
    rate_per_mtok: float = 0.0

    @abstractmethod
    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts.

        Args:
            texts: Texts to embed.

        Returns:
            List of embedding vectors (len == len(texts)).
        """

    async def embed_one(self, text: str) -> list[float]:
        """Convenience for single inputs."""
        results = await self.embed([text])
        return results[0]
