"""LiteLLM LLM adapter — 100+ providers via one interface.

LiteLLM normalizes the OpenAI chat-completion schema across Bedrock,
Azure, Cohere, Mistral, Perplexity, Together, and everything else in
its catalog. Provider-specific kwargs pass through ``extra_params``.

Model strings follow LiteLLM's provider-prefixed format, e.g.::

    bedrock/anthropic.claude-3-sonnet
    azure/gpt-4
    cohere/command-r
    together_ai/meta-llama/Meta-Llama-3-70B-Instruct

API keys resolve through LiteLLM's standard env-var conventions
(``AWS_*``, ``AZURE_*``, ``COHERE_API_KEY``, etc.); this adapter does
not re-invent that.
"""

from __future__ import annotations

import json
import logging
from typing import Any, cast

from wisdom_layer.cost.pricing import PricingTable
from wisdom_layer.errors import ConfigError, ModelAdapterError
from wisdom_layer.llm._embedding_registry import lookup_dim
from wisdom_layer.llm.base import BaseLLMAdapter
from wisdom_layer.llm.errors import (
    LLMAuthError,
    LLMBadRequestError,
    LLMRateLimitError,
    LLMServerError,
    LLMTimeoutError,
)
from wisdom_layer.llm.types import AdapterUsage

logger = logging.getLogger(__name__)


def _raise_litellm_error(litellm: Any, exc: Exception, model: str) -> None:
    """Map litellm exception types to WL typed errors and re-raise.

    litellm normalises provider errors into its own hierarchy. We map
    them here so WL's RetryPolicy can act on transient failures.
    Never returns — always raises.
    """
    try:
        if isinstance(exc, litellm.RateLimitError):
            raise LLMRateLimitError(f"LiteLLM rate limit for {model}: {exc}") from exc
        if isinstance(exc, litellm.Timeout):
            raise LLMTimeoutError(f"LiteLLM timeout for {model}: {exc}") from exc
        if isinstance(exc, litellm.APIConnectionError):
            raise LLMTimeoutError(f"LiteLLM connection error for {model}: {exc}") from exc
        if isinstance(exc, litellm.ServiceUnavailableError):
            raise LLMServerError(f"LiteLLM service unavailable for {model}: {exc}") from exc
        if isinstance(exc, litellm.AuthenticationError):
            raise LLMAuthError(f"LiteLLM auth error for {model}: {exc}") from exc
        if isinstance(exc, litellm.BadRequestError):
            raise LLMBadRequestError(f"LiteLLM bad request for {model}: {exc}") from exc
    except AttributeError:
        pass  # litellm version doesn't have this exception type — fall through
    raise ModelAdapterError(
        f"LiteLLM error for model {model}: {exc}. "
        "Check provider credentials (env vars) and model string."
    ) from exc


class LiteLLMAdapter(BaseLLMAdapter):
    """LLM adapter wrapping ``litellm.acompletion`` / ``aembedding``.

    Args:
        model: Provider-prefixed model string, e.g.
            ``"bedrock/anthropic.claude-3-sonnet"``.
        embedding_model: Provider-prefixed embedding model, e.g.
            ``"bedrock/amazon.titan-embed-text-v2"`` or
            ``"text-embedding-3-small"``. Required — LiteLLM has no
            sensible cross-provider default since the right embedder
            depends on which API keys you have in env. Pass an explicit
            value at construction so vector dimensions stay consistent
            within a deployment.
        api_key: Optional explicit API key. If omitted LiteLLM resolves
            via the provider's standard env vars.
        api_base: Optional override for self-hosted / compatible
            endpoints (e.g. vLLM, LM Studio, OpenRouter).
        extra_params: Provider-specific kwargs forwarded verbatim to
            ``litellm.acompletion`` (e.g. ``aws_region_name``).

    Raises:
        ConfigError: If ``embedding_model`` is empty.
    """

    def __init__(
        self,
        *,
        model: str,
        embedding_model: str,
        api_key: str | None = None,
        api_base: str | None = None,
        extra_params: dict[str, Any] | None = None,
    ) -> None:
        if not embedding_model:
            raise ConfigError(
                "LiteLLMAdapter requires embedding_model= at construction "
                "(e.g. 'text-embedding-3-small' or "
                "'bedrock/amazon.titan-embed-text-v2'). LiteLLM has no "
                "default embedder — pick one explicitly so vector "
                "dimensions stay consistent."
            )
        self._model = model
        self._embed_model = embedding_model
        self._api_key = api_key
        self._api_base = api_base
        self._extra_params = extra_params or {}
        self._litellm: Any = None
        self.model_id = f"litellm:{model}"
        self._pricing = PricingTable()
        # Embedder identity — backend reads these via bind_embedder().
        # If unknown to the registry we keep 384 as a placeholder; the
        # first embed() call will probe and update via warmup().
        self.embedding_model_id = embedding_model
        self.embedding_dim = lookup_dim(embedding_model) or 384

    def _get_litellm(self) -> Any:
        if self._litellm is None:
            try:
                import litellm
            except ImportError as e:
                raise ModelAdapterError(
                    "litellm package required. Install with: "
                    "pip install wisdom-layer[litellm]"
                ) from e
            self._litellm = litellm
        return self._litellm

    def _base_kwargs(self) -> dict[str, Any]:
        kwargs: dict[str, Any] = dict(self._extra_params)
        if self._api_key is not None:
            kwargs["api_key"] = self._api_key
        if self._api_base is not None:
            kwargs["api_base"] = self._api_base
        return kwargs

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Generate text via ``litellm.acompletion``."""
        litellm = self._get_litellm()

        api_messages: list[dict[str, str]] = []
        if system:
            api_messages.append({"role": "system", "content": system})
        api_messages.extend(messages)

        try:
            response = await litellm.acompletion(
                model=self._model,
                messages=api_messages,
                temperature=temperature,
                max_tokens=max_tokens,
                **self._base_kwargs(),
            )
        except Exception as e:
            _raise_litellm_error(litellm, e, self._model)

        text = response.choices[0].message.content or ""
        usage = getattr(response, "usage", None)
        input_tokens = int(getattr(usage, "prompt_tokens", 0) or 0)
        output_tokens = int(getattr(usage, "completion_tokens", 0) or 0)
        # LiteLLM often attaches response_cost; fall back to the pricing
        # table when it's absent so local/router configs still get cost.
        reported_cost = getattr(response, "_hidden_params", {})
        cost_usd = 0.0
        if isinstance(reported_cost, dict):
            cost_usd = float(reported_cost.get("response_cost") or 0.0)
        if cost_usd <= 0.0:
            cost_usd = self._pricing.compute_cost(
                self.model_id, input_tokens, output_tokens,
            )
        self.last_usage = AdapterUsage(
            model_id=self.model_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost_usd,
        )
        logger.info(
            "LLM generation complete",
            extra={
                "model": self._model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
        )
        return cast("str", text)

    async def generate_structured(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        schema: dict[str, Any],
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Generate JSON output using ``response_format`` when supported.

        Falls back to JSON-prefixed prompting with one parse retry for
        providers that reject ``response_format``.
        """
        litellm = self._get_litellm()

        schema_str = json.dumps(schema, indent=2)
        structured_system = (
            f"{system}\n\n"
            f"Respond with valid JSON matching this schema:\n{schema_str}\n\n"
            "Output ONLY the JSON object, no other text."
        ).strip()

        api_messages: list[dict[str, str]] = [
            {"role": "system", "content": structured_system}
        ]
        api_messages.extend(messages)

        kwargs = self._base_kwargs()
        kwargs["response_format"] = {"type": "json_object"}

        raw_text = ""
        for attempt in range(2):
            try:
                response = await litellm.acompletion(
                    model=self._model,
                    messages=api_messages,
                    temperature=temperature,
                    **kwargs,
                )
            except TypeError:
                # Provider rejected response_format — retry without it.
                kwargs.pop("response_format", None)
                continue
            except Exception as e:
                _raise_litellm_error(litellm, e, self._model)

            raw_text = response.choices[0].message.content or ""
            usage = getattr(response, "usage", None)
            input_tokens = int(getattr(usage, "prompt_tokens", 0) or 0)
            output_tokens = int(getattr(usage, "completion_tokens", 0) or 0)
            reported_cost = getattr(response, "_hidden_params", {})
            cost_usd = 0.0
            if isinstance(reported_cost, dict):
                cost_usd = float(reported_cost.get("response_cost") or 0.0)
            if cost_usd <= 0.0:
                cost_usd = self._pricing.compute_cost(
                    self.model_id, input_tokens, output_tokens,
                )
            self.last_usage = AdapterUsage(
                model_id=self.model_id,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=cost_usd,
            )
            try:
                return cast("dict[str, Any]", json.loads(raw_text))
            except json.JSONDecodeError:
                if attempt == 0:
                    api_messages.append(
                        {
                            "role": "user",
                            "content": (
                                "Your previous output was not valid JSON. "
                                "Return only the JSON object, nothing else."
                            ),
                        }
                    )
                    continue
                raise ModelAdapterError(
                    "Failed to parse LiteLLM structured output as JSON after "
                    f"retry. Raw output: {raw_text[:200]}"
                ) from None

        raise ModelAdapterError(
            f"Failed to parse LiteLLM structured output. Raw: {raw_text[:200]}"
        )

    async def embed(self, text: str) -> list[float]:
        """Embed text via ``litellm.aembedding``."""
        litellm = self._get_litellm()

        try:
            response = await litellm.aembedding(
                model=self._embed_model,
                input=[text],
                **self._base_kwargs(),
            )
        except Exception as e:
            _raise_litellm_error(litellm, e, self._embed_model)

        data = response.data if hasattr(response, "data") else response["data"]
        first = data[0]
        vector = first["embedding"] if isinstance(first, dict) else first.embedding
        return cast("list[float]", list(vector))

    async def warmup(self) -> None:
        """Probe :attr:`embedding_dim` if the embedder isn't in the registry.

        Unlike the cloud + sentence-transformers adapters there's no local
        model to load, so warmup is a single network embed call only when
        we don't already know the output dim. Best-effort: network errors
        are logged and the first real embed call retries.
        """
        if lookup_dim(self._embed_model) is not None:
            return
        try:
            vec = await self.embed("warmup")
        except Exception:
            logger.warning(
                "LiteLLM embedder warmup probe failed; first embed() will retry",
                exc_info=True,
                extra={"model": self._embed_model},
            )
            return
        probed_dim = len(vec)
        if probed_dim != self.embedding_dim:
            logger.info(
                "LiteLLM embedder dim updated from probe",
                extra={
                    "model": self._embed_model,
                    "registry_dim": self.embedding_dim,
                    "probed_dim": probed_dim,
                },
            )
            self.embedding_dim = probed_dim
