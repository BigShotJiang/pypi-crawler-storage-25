"""Google Gemini LLM adapter."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, cast

from wisdom_layer.cost.pricing import PricingTable
from wisdom_layer.errors import ModelAdapterError
from wisdom_layer.llm._embedding_registry import lookup_dim
from wisdom_layer.llm.base import BaseLLMAdapter
from wisdom_layer.llm.errors import (
    LLMAuthError,
    LLMBadRequestError,
    LLMRateLimitError,
    LLMServerError,
    LLMTimeoutError,
)
from wisdom_layer.llm.types import AdapterUsage

logger = logging.getLogger(__name__)

EMBEDDING_DIM = 384


class GeminiAdapter(BaseLLMAdapter):
    """LLM adapter for Google Gemini models.

    Uses the google-genai SDK for text generation and
    sentence-transformers for local embeddings (384-dim,
    consistent with all other adapters).

    Args:
        api_key: Google AI API key.
        model: Model ID for text generation (default: gemini-2.0-flash).
        embedding_model: Local embedding model name (default: all-MiniLM-L6-v2).
    """

    def __init__(
        self,
        *,
        api_key: str,
        model: str = "gemini-2.0-flash",
        embedding_model: str = "all-MiniLM-L6-v2",
    ) -> None:
        self._api_key = api_key
        self._model = model
        self.model_id = model
        self._embedding_model_name = embedding_model
        self._client: Any = None
        self._embedder: Any = None
        self._genai_types: Any = None
        self._pricing = PricingTable()
        # Embedder identity — backend reads these via bind_embedder().
        self.embedding_model_id = embedding_model
        self.embedding_dim = lookup_dim(embedding_model) or 384

    def _get_client(self) -> Any:
        """Lazy-initialize the Google GenAI client."""
        if self._client is None:
            try:
                from google import genai
                from google.genai import types as genai_types
            except ImportError as e:
                raise ModelAdapterError(
                    "google-genai package required. Install with: "
                    "pip install wisdom-layer[gemini]"
                ) from e
            self._client = genai.Client(api_key=self._api_key)
            self._genai_types = genai_types
        return self._client

    def _get_embedder(self) -> Any:
        """Lazy-initialize the sentence-transformers model."""
        if self._embedder is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as e:
                raise ModelAdapterError(
                    "sentence-transformers required for embeddings. Install with: "
                    "pip install sentence-transformers"
                ) from e
            self._embedder = SentenceTransformer(self._embedding_model_name)
            logger.info(
                "Embedding model loaded",
                extra={"model": self._embedding_model_name},
            )
        return self._embedder

    async def warmup(self) -> None:
        """Eagerly load the embedding model + warm its first-encode path.

        See :meth:`BaseLLMAdapter.warmup` — pays the multi-second
        sentence-transformers load + first-encode cost up front so
        ``memory.search()`` doesn't stall on first use. Best-effort:
        missing optional deps are logged, not raised. Also probes
        :attr:`embedding_dim` from the result so backends bound after
        warmup see the correct vector shape for non-registry models.
        """
        probed_dim: int | None = None

        def _load_and_prime() -> int:
            embedder = self._get_embedder()
            vec = embedder.encode("warmup", normalize_embeddings=True)
            return int(len(vec))

        try:
            probed_dim = await asyncio.to_thread(_load_and_prime)
        except ModelAdapterError:
            logger.warning(
                "Embedder warmup skipped: sentence-transformers not installed",
                extra={"model": self._embedding_model_name},
            )
        except Exception:
            logger.warning(
                "Embedder warmup failed; first embed() call will retry",
                exc_info=True,
                extra={"model": self._embedding_model_name},
            )

        if probed_dim is not None and probed_dim != self.embedding_dim:
            logger.info(
                "Embedder dim updated from probe",
                extra={
                    "model": self._embedding_model_name,
                    "registry_dim": self.embedding_dim,
                    "probed_dim": probed_dim,
                },
            )
            self.embedding_dim = probed_dim

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Generate text using a Gemini model."""
        client = self._get_client()
        genai_types = self._genai_types

        # Collect system messages from the messages list and merge with system kwarg
        system_parts: list[str] = []
        if system:
            system_parts.append(system)

        contents: list[Any] = []
        for msg in messages:
            role = msg["role"]
            if role == "system":
                system_parts.append(msg["content"])
                continue
            gemini_role = "model" if role == "assistant" else "user"
            contents.append(
                genai_types.Content(
                    role=gemini_role,
                    parts=[genai_types.Part(text=msg["content"])],
                )
            )

        config = genai_types.GenerateContentConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
        )
        if system_parts:
            config.system_instruction = "\n\n".join(system_parts)

        try:
            response = await client.aio.models.generate_content(
                model=self._model,
                contents=contents,
                config=config,
            )
            text = response.text or ""
            usage = getattr(response, "usage_metadata", None)
            input_tokens = int(getattr(usage, "prompt_token_count", 0) or 0)
            output_tokens = int(
                getattr(usage, "candidates_token_count", 0) or 0
            )
            self.last_usage = AdapterUsage(
                model_id=self._model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                cost_usd=self._pricing.compute_cost(
                    self._model, input_tokens, output_tokens,
                ),
            )
            logger.info(
                "LLM generation complete",
                extra={
                    "model": self._model,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                },
            )
            return text
        except Exception as e:
            # google.api_core.exceptions is the stable error hierarchy for all
            # Google Cloud / GenAI SDK calls. Import lazily so google-genai
            # remains an optional dependency.
            try:
                from google.api_core import exceptions as _gapi
                if isinstance(e, _gapi.ResourceExhausted):
                    raise LLMRateLimitError(f"Gemini rate limit (429): {e}") from e
                if isinstance(e, _gapi.DeadlineExceeded):
                    raise LLMTimeoutError(f"Gemini request timed out: {e}") from e
                if isinstance(e, (_gapi.InternalServerError, _gapi.ServiceUnavailable)):
                    raise LLMServerError(f"Gemini server error: {e}") from e
                if isinstance(e, (_gapi.Unauthenticated, _gapi.PermissionDenied)):
                    raise LLMAuthError(f"Gemini auth error: {e}") from e
                if isinstance(e, _gapi.InvalidArgument):
                    raise LLMBadRequestError(f"Gemini bad request: {e}") from e
            except ImportError:
                pass
            raise ModelAdapterError(
                f"Gemini API error: {e}. Check your API key and endpoint configuration."
            ) from e

    async def embed(self, text: str) -> list[float]:
        """Generate embedding using local sentence-transformers model."""
        embedder = self._get_embedder()
        vec = embedder.encode(text, normalize_embeddings=True)
        return cast("list[float]", vec.tolist())

    async def generate_structured(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        schema: dict[str, Any],
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Generate structured JSON output from Gemini."""
        schema_str = json.dumps(schema, indent=2)
        structured_system = (
            f"{system}\n\n"
            f"Respond with valid JSON matching this schema:\n{schema_str}\n\n"
            f"Output ONLY the JSON object, no other text."
        ).strip()

        text = await self.generate(
            messages=messages,
            system=structured_system,
            temperature=temperature,
        )

        # Strip markdown code fences if present
        cleaned = text.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            cleaned = "\n".join(
                lines[1:-1] if lines[-1].strip() == "```" else lines[1:]
            )

        try:
            return cast("dict[str, Any]", json.loads(cleaned))
        except json.JSONDecodeError as e:
            raise ModelAdapterError(
                f"Failed to parse Gemini structured output as JSON: {e}\n"
                f"Raw output: {text[:200]}"
            ) from e
