"""Known embedding model -> dimension lookups.

Used by adapters to set ``embedding_dim`` at construction without paying
the model load. For models not in the registry, adapters fall back to the
default 384 and may probe the actual dim during ``warmup()`` (calling
``embed("probe")`` once and reading ``len(result)``).

Keep this list focused on commonly-used local sentence-transformers and
the cloud embedding APIs we ship cost rows for. Unknown models still
work — they just rely on warmup-time probing rather than upfront knowledge.
"""

from __future__ import annotations

#: Map of stable model identifier -> output vector dimension.
KNOWN_EMBEDDING_DIMS: dict[str, int] = {
    # sentence-transformers (local, ship with [anthropic] / [openai] / [gemini])
    "all-MiniLM-L6-v2": 384,
    "all-MiniLM-L12-v2": 384,
    "all-mpnet-base-v2": 768,
    "BAAI/bge-small-en-v1.5": 384,
    "BAAI/bge-base-en-v1.5": 768,
    "BAAI/bge-large-en-v1.5": 1024,
    "intfloat/e5-small-v2": 384,
    "intfloat/e5-base-v2": 768,
    "intfloat/e5-large-v2": 1024,
    # OpenAI hosted embeddings
    "text-embedding-3-small": 1536,
    "text-embedding-3-large": 3072,
    "text-embedding-ada-002": 1536,
    # Cohere (via LiteLLM)
    "cohere/embed-english-v3.0": 1024,
    "cohere/embed-multilingual-v3.0": 1024,
    # Voyage (via LiteLLM)
    "voyage/voyage-2": 1024,
    "voyage/voyage-large-2": 1536,
    # Ollama defaults
    "nomic-embed-text": 768,
    "mxbai-embed-large": 1024,
}


def lookup_dim(model_id: str) -> int | None:
    """Return the known output dimension for ``model_id``, or ``None``.

    A ``None`` result means the adapter must probe the dim at warmup time
    by running a single embed call.
    """
    return KNOWN_EMBEDDING_DIMS.get(model_id)
