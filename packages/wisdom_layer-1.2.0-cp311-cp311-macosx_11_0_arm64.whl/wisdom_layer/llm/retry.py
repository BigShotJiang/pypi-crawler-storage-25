"""LLM retry policy — exponential/linear backoff with jitter.

Applied selectively to idempotent LLM operations (consolidation,
journal synthesis, directive evolution). Side-effect calls (critic
audit, coherence checks) are not retried.
"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import TYPE_CHECKING, Any, TypeVar

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

from pydantic import BaseModel, Field

from wisdom_layer.llm.errors import (
    LLMRateLimitError,
    LLMServerError,
    LLMTimeoutError,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")

_DEFAULT_RETRY_ON: frozenset[type[Exception]] = frozenset({
    LLMRateLimitError,
    LLMTimeoutError,
    LLMServerError,
})


class RetryPolicy(BaseModel):
    """Configuration for LLM call retry behavior."""

    max_attempts: int = Field(default=3, ge=1, le=10)
    initial_delay_s: float = Field(default=1.0, ge=0.1, le=30.0)
    max_delay_s: float = Field(default=60.0, ge=1.0, le=900.0)
    backoff: str = Field(default="exponential")
    jitter: bool = True

    model_config = {"frozen": True}

    def _compute_delay(self, attempt: int) -> float:
        if self.backoff == "linear":
            delay = self.initial_delay_s * (attempt + 1)
        else:
            delay = self.initial_delay_s * (2 ** attempt)
        delay = min(delay, self.max_delay_s)
        if self.jitter:
            delay += random.uniform(0, delay * 0.25)  # noqa: S311
        return delay

    def is_retryable(self, exc: Exception) -> bool:
        """Check if an exception should trigger a retry."""
        return isinstance(exc, tuple(_DEFAULT_RETRY_ON))


async def with_retry(
    policy: RetryPolicy,
    fn: Callable[[], Awaitable[T]],
    *,
    emit: Callable[..., Awaitable[Any]] | None = None,
) -> T:
    """Execute ``fn()`` with retry according to ``policy``.

    Args:
        policy: Retry configuration.
        fn: Zero-arg async callable to attempt. Must be idempotent.
        emit: Optional event emitter for retry telemetry.

    Returns:
        The result of ``fn()`` on success.

    Raises:
        The last exception if all attempts are exhausted.
    """
    last_exc: Exception | None = None

    for attempt in range(policy.max_attempts):
        try:
            return await fn()
        except Exception as exc:
            if not policy.is_retryable(exc) or attempt == policy.max_attempts - 1:
                raise
            last_exc = exc
            delay = policy._compute_delay(attempt)
            logger.warning(
                "LLM call failed, retrying (attempt %d/%d, delay=%.1fs, %s: %s)",
                attempt + 1,
                policy.max_attempts,
                delay,
                type(exc).__name__,
                str(exc)[:200],
                extra={
                    "attempt": attempt + 1,
                    "max_attempts": policy.max_attempts,
                    "delay_s": round(delay, 2),
                    "error_type": type(exc).__name__,
                    "error_msg": str(exc)[:200],
                },
            )
            if emit is not None:
                await emit(
                    "retry.attempted",
                    data={
                        "attempt": attempt + 1,
                        "delay_s": round(delay, 2),
                        "error_type": type(exc).__name__,
                    },
                )
            await asyncio.sleep(delay)

    raise last_exc  # type: ignore[misc]
