"""ModelRouter — tier-ordered LLM dispatch with circuit breaker.

Subsystems request a *tier*, never a model id. The router resolves
the best available adapter, manages circuit breaker state, and emits
events through the agent's event bus.

Doc reference: ``12_llm_routing.md``.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from wisdom_layer.llm.base import BaseLLMAdapter  # noqa: TC001
from wisdom_layer.llm.errors import (
    LLMTransientError,
    NoAvailableModelError,
    StructuredOutputTierError,
)
from wisdom_layer.llm.types import (
    TIER_ORDER,
    CircuitBreakerState,
    CompletionResult,
    LLMRoutingConfig,
    Message,
    ModelTier,
    StructuredResult,
)

if TYPE_CHECKING:
    from wisdom_layer.clock import Clock
    from wisdom_layer.observability.events import EventEmitter

logger = logging.getLogger("wisdom_layer.llm")


class ModelRouter:
    """Tier-ordered LLM dispatch with circuit breaker and fallback.

    One router per agent. Adapters are registered at construction time;
    the router resolves the best available adapter for each request
    based on the requested tier and circuit breaker state.
    """

    def __init__(
        self,
        adapters: list[BaseLLMAdapter],
        *,
        clock: Clock | None = None,
        events: EventEmitter | None = None,
        config: LLMRoutingConfig | None = None,
    ) -> None:
        from wisdom_layer.clock import SystemClock

        self._clock: Clock = clock or SystemClock()
        self._events = events
        self._config = config or LLMRoutingConfig()

        # Sort adapters by tier priority (sota first)
        self._adapters = sorted(
            adapters, key=lambda a: TIER_ORDER.get(a.tier, 99)
        )

        # Circuit breaker state per model_id
        self._breakers: dict[str, CircuitBreakerState] = {
            a.model_id: CircuitBreakerState(model_id=a.model_id)
            for a in self._adapters
        }

    # -- Public API --------------------------------------------------------

    async def complete(
        self,
        messages: list[Message],
        *,
        tier: ModelTier,
        temperature: float = 0.7,
        max_tokens: int | None = None,
        allow_fallback: bool = True,
        purpose: str | None = None,
    ) -> CompletionResult:
        """Route a completion to the best available adapter at ``tier``.

        Args:
            messages: Conversation messages.
            tier: Minimum quality tier required.
            temperature: Sampling temperature.
            max_tokens: Max output tokens.
            allow_fallback: If True, walk down tiers on failure.
            purpose: Cost attribution label.

        Returns:
            CompletionResult from the chosen adapter.

        Raises:
            NoAvailableModelError: No adapter available at the tier.
        """
        candidates = self._resolve_candidates(tier, allow_fallback=allow_fallback)
        if not candidates:
            raise NoAvailableModelError(tier, "all models circuit-broken or unavailable")

        last_error: Exception | None = None
        for adapter in candidates:
            try:
                result = await adapter.complete(
                    messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                self._record_success(adapter.model_id)
                return result
            except LLMTransientError as e:
                last_error = e
                self._record_failure(adapter.model_id, str(e))
                continue
            except Exception:
                # Terminal errors — don't circuit-break, just raise
                raise

        raise NoAvailableModelError(
            tier,
            f"all candidates exhausted (last_error={last_error})",
        )

    async def complete_structured(
        self,
        messages: list[Message],
        *,
        schema: dict[str, Any],
        tier: ModelTier,
        temperature: float = 0.0,
        max_tokens: int | None = None,
        allow_fallback: bool = True,
        purpose: str | None = None,
    ) -> StructuredResult:
        """Route a structured completion with tier enforcement.

        Raises:
            StructuredOutputTierError: No adapter at the required tier
                supports structured output.
        """
        required = self._config.structured_required_tier
        candidates = self._resolve_candidates(
            tier, allow_fallback=allow_fallback, require_structured=True
        )

        # Tier enforcement: at least one candidate must be at or above required tier
        if candidates:
            best_tier = candidates[0].tier
            if TIER_ORDER.get(best_tier, 99) > TIER_ORDER.get(required, 1):
                raise StructuredOutputTierError(
                    required, [a.tier for a in candidates]
                )
        else:
            raise StructuredOutputTierError(required, [])

        last_error: Exception | None = None
        for adapter in candidates:
            try:
                result = await adapter.complete_structured(
                    messages,
                    schema=schema,
                    temperature=temperature,
                    max_tokens=max_tokens,
                )
                self._record_success(adapter.model_id)
                return result
            except LLMTransientError as e:
                last_error = e
                self._record_failure(adapter.model_id, str(e))
                continue
            except Exception:
                raise

        raise NoAvailableModelError(
            tier,
            f"structured candidates exhausted (last_error={last_error})",
        )

    def available_tiers(self) -> set[ModelTier]:
        """Return the set of tiers with at least one healthy adapter."""
        tiers: set[ModelTier] = set()
        for adapter in self._adapters:
            breaker = self._breakers[adapter.model_id]
            if breaker.state != "open":
                tiers.add(adapter.tier)
        return tiers

    def model_for(self, tier: ModelTier) -> str | None:
        """Return the model_id of the first healthy adapter at ``tier``."""
        for adapter in self._adapters:
            if adapter.tier == tier:
                breaker = self._breakers[adapter.model_id]
                if breaker.state != "open":
                    return adapter.model_id
        return None

    def health(self) -> dict[str, CircuitBreakerState]:
        """Return circuit breaker state for all adapters."""
        return dict(self._breakers)

    async def close(self) -> None:
        """Close all adapters."""
        for adapter in self._adapters:
            await adapter.close()

    # -- Private -----------------------------------------------------------

    def _resolve_candidates(
        self,
        tier: ModelTier,
        *,
        allow_fallback: bool = True,
        require_structured: bool = False,
    ) -> list[BaseLLMAdapter]:
        """Build the ordered candidate list for a request.

        Walks the adapter list (already sorted by tier), filters by
        circuit breaker state, tier eligibility, and optional structured
        support. If ``allow_fallback`` is True, includes lower tiers.
        """
        self._check_half_open_transitions()

        tier_threshold = TIER_ORDER.get(tier, 99)
        candidates: list[BaseLLMAdapter] = []

        for adapter in self._adapters:
            adapter_tier_rank = TIER_ORDER.get(adapter.tier, 99)

            # Only same tier or lower (higher number) if fallback allowed
            if adapter_tier_rank < tier_threshold:
                continue
            if not allow_fallback and adapter_tier_rank > tier_threshold:
                continue

            # Circuit breaker check
            breaker = self._breakers[adapter.model_id]
            if breaker.state == "open":
                continue

            # Structured support filter
            if require_structured and not adapter.supports_structured_json:
                continue

            candidates.append(adapter)

        return candidates

    def _check_half_open_transitions(self) -> None:
        """Transition open breakers to half_open if cooldown has elapsed."""
        now_mono = self._clock.monotonic()
        cooldown = self._config.circuit_breaker_cooldown_seconds

        for breaker in self._breakers.values():
            if (
                breaker.state == "open"
                and breaker.opened_at_mono is not None
                and (now_mono - breaker.opened_at_mono) >= cooldown
            ):
                breaker.state = "half_open"
                logger.info(
                    "Circuit breaker half-open",
                    extra={"model_id": breaker.model_id},
                )

    def _record_success(self, model_id: str) -> None:
        """Reset circuit breaker on success."""
        breaker = self._breakers.get(model_id)
        if breaker is None:
            return
        was_open = breaker.state in ("open", "half_open")
        breaker.consecutive_failures = 0
        breaker.state = "closed"
        breaker.opened_at_mono = None
        breaker.last_error = None

        if was_open:
            logger.info(
                "Circuit breaker closed",
                extra={"model_id": model_id},
            )

    def _record_failure(self, model_id: str, error: str) -> None:
        """Increment circuit breaker on transient failure."""
        breaker = self._breakers.get(model_id)
        if breaker is None:
            return
        breaker.consecutive_failures += 1
        breaker.last_error = error

        threshold = self._config.circuit_breaker_consecutive_failures
        if breaker.consecutive_failures >= threshold:
            breaker.state = "open"
            breaker.opened_at_mono = self._clock.monotonic()
            logger.warning(
                "Circuit breaker opened",
                extra={
                    "model_id": model_id,
                    "consecutive_failures": breaker.consecutive_failures,
                    "last_error": error,
                },
            )
