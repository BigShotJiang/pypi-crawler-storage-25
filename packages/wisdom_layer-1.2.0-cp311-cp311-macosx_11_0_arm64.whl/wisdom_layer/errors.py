"""Exception hierarchy for the Wisdom Layer SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from datetime import datetime


class WisdomLayerError(Exception):
    """Base exception for all Wisdom Layer errors."""


class LicenseError(WisdomLayerError):
    """License validation failure."""


class LicenseExpiredError(LicenseError):
    """License has expired."""


class LicenseInvalidError(LicenseError):
    """License key is invalid or revoked."""


# Feature-specific upgrade hints surface what the gated feature actually
# does so the error nudges curiosity rather than just refusing access.
# Keep these short — one sentence — and outcome-oriented.
_FEATURE_HINTS: dict[str, str] = {
    "critic": (
        "The critic scores each directive your agents form and refines them "
        "automatically over time."
    ),
    "directive_evolution": (
        "Directive evolution lets your agents promote, deactivate, and "
        "rewrite their own behavioral rules as they learn."
    ),
    "dream_cycles": (
        "Dream cycles consolidate raw memories into durable insights "
        "between sessions, the way sleep does for humans."
    ),
    "scheduled_dreams": (
        "Scheduled dreams run consolidation on a cron-like cadence so your "
        "agents keep maturing without manual intervention."
    ),
    "semantic_search": (
        "Semantic search retrieves memories by meaning rather than keyword "
        "match, using vector embeddings."
    ),
    "tier2_memory": (
        "Tier-2 memory holds reflective summaries and patterns distilled "
        "from raw captures."
    ),
    "tier3_memory": (
        "Tier-3 memory holds the long-horizon directives and identity "
        "axioms that shape how an agent reasons."
    ),
    "provenance": (
        "Provenance gives you an append-only audit log of every memory, "
        "directive, and decision your agents make."
    ),
    "provenance_trace": (
        "Provenance trace surfaces the chain of evidence behind any single "
        "memory or insight."
    ),
    "provenance_explain": (
        "Provenance explain narrates the chain of evidence in natural "
        "language for compliance and review."
    ),
    "provenance_export": (
        "Provenance export streams the full audit log out in JSON for "
        "external storage or analysis."
    ),
    "advanced_analytics": (
        "Advanced analytics expose drift, coherence, and trajectory "
        "metrics across an agent's full lifecycle."
    ),
    "cost_visibility": (
        "Cost visibility surfaces per-cycle and per-agent LLM spend so you "
        "can budget reflection accurately."
    ),
    "cost_budget": (
        "Cost budgets cap reflection spend per cycle and per day so a "
        "runaway agent cannot blow your bill."
    ),
    "cost_export": (
        "Cost export streams per-cycle billing detail for chargeback or "
        "accounting reconciliation."
    ),
    "multi_agent_mesh": (
        "Multi-agent mesh lets a fleet of agents share a memory pool and "
        "coordinate through shared directives."
    ),
    "cross_agent_memory": (
        "Cross-agent memory lets agents read from a shared pool while "
        "keeping their own private layer."
    ),
}


def _tier_signup_url(required_tier: str) -> str:
    """Map a human-readable tier name to a deep-linked signup URL."""
    slug = required_tier.strip().lower()
    if slug in {"reflect", "pro"}:
        return "https://wisdomlayer.ai/signup?tier=pro"
    if slug in {"wisdom", "enterprise"}:
        return "https://wisdomlayer.ai/signup?tier=enterprise"
    return "https://wisdomlayer.ai/pricing"


# Cap-violation message templates. Each placeholder is filled at construction
# time. ``messages_30d`` carries an optional ``reset_clause`` so the message
# can include the rolling-window reset timestamp when provided.
_CAP_TEMPLATES: dict[str, str] = {
    "agents": (
        "Free tier supports {limit} agents; you have {current}. "
        "Cannot create another agent. Delete an existing agent or upgrade "
        "to Pro for unlimited agents."
    ),
    "memories": (
        "Free tier supports {limit} memories per agent; this agent has "
        "{current}. New memories will not be captured until you prune "
        "existing memories or upgrade to Pro for unlimited memories."
    ),
    "messages_30d": (
        "Free tier supports {limit} messages per 30-day window; you have "
        "used {current}. Throughput is throttled{reset_clause}. Upgrade to "
        "Pro for unlimited throughput."
    ),
}

CapKind = Literal["agents", "memories", "messages_30d"]

# Single source of truth for cap-kind tags. Used as keys in
# ``WisdomAgent._cap_warning_emitted`` and as the ``cap_kind`` argument
# to :class:`TierRestrictionError` and ``feature_gate.require_cap``. If
# you add a new cap kind here, update :data:`CapKind`, ``_CAP_TEMPLATES``,
# ``feature_gate._VALID_CAP_KINDS``, and the cap-violation error tests.
CAP_KIND_AGENTS: CapKind = "agents"
CAP_KIND_MEMORIES: CapKind = "memories"
CAP_KIND_MESSAGES_30D: CapKind = "messages_30d"


class TierRestrictionError(WisdomLayerError):
    """Feature or capacity limit not available in the current license tier.

    Two modes:

    1. **Feature-gate violation** — the tier itself lacks a capability
       (e.g., a Free user calls ``agent.dreams.trigger()``). Pass
       ``feature=`` and ``required_tier=`` (the historical positional
       form). The message embeds a feature-specific one-liner and a
       deep-linked signup URL.
    2. **Cap violation** — the tier supports the operation but the
       Free-tier capacity cap has been reached. Pass ``cap_kind=``,
       ``current=``, ``limit=``, and (for ``messages_30d``) optionally
       ``reset_at=``. The message tells the user which cap fired, what
       the numbers are, and what they can do about it.

    Existing positional callers (``TierRestrictionError("feature",
    "Pro")``) are unchanged.
    """

    def __init__(
        self,
        feature: str | None = None,
        required_tier: str | None = None,
        *,
        cap_kind: CapKind | None = None,
        current: int | None = None,
        limit: int | None = None,
        reset_at: datetime | None = None,
        upgrade_url: str | None = None,
    ) -> None:
        self.feature = feature
        self.required_tier = required_tier
        self.cap_kind = cap_kind
        self.current = current
        self.limit = limit
        self.reset_at = reset_at

        if cap_kind is not None:
            # Cap-violation path.
            if current is None or limit is None:
                raise ValueError(
                    "TierRestrictionError(cap_kind=...) requires both "
                    "`current` and `limit` to be provided."
                )
            url = upgrade_url or "https://wisdomlayer.ai/pricing"
            self.upgrade_url = url
            self.signup_url = url  # back-compat alias
            template = _CAP_TEMPLATES[cap_kind]
            reset_clause = ""
            if cap_kind == "messages_30d" and reset_at is not None:
                reset_clause = f" until {reset_at.isoformat()}"
            body = template.format(
                limit=f"{limit:,}",
                current=f"{current:,}",
                reset_clause=reset_clause,
            )
            super().__init__(f"{body} Upgrade at {url}")
            return

        # Feature-gate path — historical behavior preserved.
        if feature is None or required_tier is None:
            raise ValueError(
                "TierRestrictionError requires either "
                "(feature, required_tier) for a feature-gate violation or "
                "cap_kind=... (with current=, limit=) for a cap violation."
            )
        url = upgrade_url or _tier_signup_url(required_tier)
        self.signup_url = url
        self.upgrade_url = url  # forward-compat alias
        hint = _FEATURE_HINTS.get(feature)
        parts = [f"'{feature}' requires the {required_tier} tier."]
        if hint:
            parts.append(hint)
        parts.append(f"Upgrade at {url}")
        super().__init__(" ".join(parts))


class FeatureDisabledError(WisdomLayerError):
    """Feature is available at this tier but disabled via FeatureFlags.

    Raised by ``_require_feature`` when the tier grants access but the
    user has explicitly opted out of the feature via
    ``AgentConfig.feature_flags``. Distinct from ``TierRestrictionError``
    (which means the tier itself lacks the feature).
    """

    def __init__(self, feature: str, flag_name: str) -> None:
        self.feature = feature
        self.flag_name = flag_name
        super().__init__(
            f"'{feature}' is disabled via feature_flags.{flag_name}. "
            f"Set feature_flags.{flag_name} = True to enable."
        )


class StorageError(WisdomLayerError):
    """Storage backend failure."""


class BackendNotInitializedError(StorageError, RuntimeError):
    """Backend method invoked before ``initialize()`` (or after ``close()``).

    Raised by storage backends when an operation is attempted while no
    underlying connection / pool is open. This is distinct from a transient
    failure: the caller has misordered the lifecycle (forgot ``initialize``)
    or is racing a shutdown. Fire-and-forget background writes
    (e.g., post-search reinforcement) catch this specifically and no-op,
    since it is the expected outcome of agent shutdown mid-flight.

    Inherits :class:`RuntimeError` for backward compatibility — historical
    callers (pre-1.0) catch ``RuntimeError`` and that contract is preserved.
    New code should catch :class:`BackendNotInitializedError` explicitly.
    """


class StorageBusyError(StorageError):
    """SQLITE_BUSY after busy_timeout exhausted.

    Raised when the storage backend cannot acquire a write lock within
    the configured ``busy_timeout`` (default 5 000 ms). This typically
    means a concurrent dream cycle phase or a long-running snapshot scope
    is holding the WAL write lock. Callers should retry or reduce
    concurrency.
    """


class StorageIntegrityError(StorageError):
    """Foreign-key or unique constraint violation.

    Raised when an INSERT / UPDATE violates a schema constraint. Common
    triggers: duplicate memory IDs (hash collision on short hex IDs),
    orphaned directive proposals (referenced directive deleted
    concurrently), or a migration bug that drops a parent table.
    """


class StorageMigrationError(StorageError):
    """A schema migration could not be parsed or failed to apply.

    Raised by :class:`wisdom_layer.storage._migrations.MigrationRunner` when
    a migration file is malformed (missing ``-- up`` / ``-- down`` marker,
    non-numeric prefix, empty up block) or when the underlying SQLite
    connection rejects the DDL. See ``06_extraction_plan.md`` §0.2.
    """


class ModelAdapterError(WisdomLayerError):
    """LLM adapter failure."""


class EmbeddingDimensionMismatchError(WisdomLayerError):
    """Stored embedding dimension differs from the adapter's dimension.

    Raised when the embedding adapter produces vectors of a different
    dimensionality than what the storage backend has on record for
    this agent. This prevents silent cosine-similarity corruption when
    an embedder model is swapped without re-embedding existing memories.

    See ``11_integration_ergonomics_resolutions.md`` §2.
    """

    def __init__(
        self,
        *,
        stored_dim: int,
        adapter_dim: int,
        model_id: str | None = None,
    ) -> None:
        self.stored_dim = stored_dim
        self.adapter_dim = adapter_dim
        self.model_id = model_id
        detail = (
            f"Embedding dimension mismatch: storage has {stored_dim}-d vectors, "
            f"adapter produces {adapter_dim}-d vectors"
        )
        if model_id:
            detail += f" (model={model_id})"
        detail += (
            ". Re-embed existing memories with a matching embedder, or "
            "revert to the previous embedding model."
        )
        super().__init__(detail)


class EventHandlerQuarantinedError(WisdomLayerError):
    """An event handler was quarantined after repeated failures.

    Raised (or logged, depending on caller policy) when an event handler
    crosses the quarantine threshold (default: 3 failures within 60 s).
    The handler is automatically unsubscribed to prevent cascading
    failures from blocking event delivery to healthy subscribers.

    See ``14_observability_events.md`` §"Quarantine policy".
    """

    def __init__(
        self,
        *,
        handler_name: str,
        event_name: str,
        failure_count: int,
    ) -> None:
        self.handler_name = handler_name
        self.event_name = event_name
        self.failure_count = failure_count
        super().__init__(
            f"Handler '{handler_name}' quarantined on event '{event_name}': "
            f"{failure_count} consecutive failures"
        )


class ModelTierUnavailableError(WisdomLayerError):
    """No model is registered at the requested tier.

    Raised by ``ModelRouter`` when the caller requests a tier that has
    no adapter registered and ``allow_fallback=False``, or when all
    lower tiers are also exhausted during downward fallback.

    See ``12_llm_routing.md`` §"Tier selection".
    """

    def __init__(self, tier: str, *, available_tiers: list[str] | None = None) -> None:
        self.tier = tier
        self.available_tiers = available_tiers or []
        detail = f"No model available at tier '{tier}'"
        if self.available_tiers:
            detail += f" (available: {', '.join(self.available_tiers)})"
        super().__init__(detail)


class DreamCycleError(WisdomLayerError):
    """Error during dream cycle execution."""


class CriticError(WisdomLayerError):
    """Error during critic evaluation."""


class EmbeddingConfigMismatchError(WisdomLayerError):
    """Adapter and backend disagree on the embedding model identity.

    Raised at ``agent.initialize()`` when the user explicitly set
    ``embedding_model_id`` or ``embedding_dim`` on the backend AND those
    values disagree with what the LLM adapter advertises. The fix is to
    drop the explicit override and let the agent thread the adapter's
    values to the backend automatically.

    This is distinct from :class:`EmbeddingDimensionMismatchError`, which
    fires at write/read time when an embedding vector is the wrong shape
    for the live backend (typically caused by changing the embedder
    underneath an existing database).
    """


class ConfigError(WisdomLayerError):
    """Invalid configuration."""


class PermissionDeniedError(WisdomLayerError):
    """The PermissionManager gateway rejected a mutation.

    Raised by the centralized enforcement point when a subsystem attempts
    to mutate a domain (memory, directives, goals) that is currently
    locked by ``LockConfig``, ``SessionConfig``, or a combination thereof
    (strictest-mode-wins).
    """

    def __init__(self, domain: str, required_mode: str, current_mode: str) -> None:
        self.domain = domain
        self.required_mode = required_mode
        self.current_mode = current_mode
        super().__init__(
            f"Permission denied for '{domain}' mutation: "
            f"requires mode '{required_mode}', current mode is '{current_mode}'"
        )


class AgentLockedError(PermissionDeniedError):
    """The agent is locked and cannot accept the requested mutation.

    Raised when ``LockConfig`` at the agent level blocks a write operation.
    Locked agents must be replaced via ``agent.snapshot()`` +
    ``WisdomAgent.from_snapshot()`` rather than unlocked at runtime.
    """


class DirectiveLockedError(AgentLockedError):
    """Directive mutation blocked because evolution is locked.

    Raised by ``DirectivesInterface.add/remove/deactivate/approve/reject/promote``
    when ``LockConfig.directive_evolution_mode == "locked"``.
    """

    def __init__(self, directive_id: str | None = None) -> None:
        self.directive_id = directive_id
        target = f"directive '{directive_id}'" if directive_id else "directives"
        super().__init__(
            domain="directives",
            required_mode="active",
            current_mode="locked",
        )
        # Re-assign message with directive context
        self.args = (
            f"Cannot mutate {target}: directive_evolution_mode is 'locked'. "
            f"Replace the agent via snapshot() + from_snapshot() to retrain.",
        )


class DirectiveCapacityError(WisdomLayerError):
    """Directive volume limit reached.

    Raised when ``DirectiveManager.add()`` is called but the agent already
    has ``DIRECTIVE_MAX_VOLUME`` non-inactive directives. No eviction is
    performed — the caller must deactivate existing directives first.
    """

    def __init__(self, current_count: int, max_volume: int) -> None:
        self.current_count = current_count
        self.max_volume = max_volume
        super().__init__(
            f"Directive capacity reached: {current_count}/{max_volume} active. "
            f"Deactivate existing directives before adding new ones."
        )


class DirectiveDuplicateError(WisdomLayerError):
    """Semantically duplicate directive already exists.

    Raised when ``DirectiveManager.add()`` detects that an existing
    directive has cosine similarity >= ``DIRECTIVE_DEDUP_COSINE_THRESHOLD``
    to the proposed content. The ``existing_id`` field lets the caller
    reference the existing directive instead.
    """

    def __init__(self, existing_id: str, similarity: float) -> None:
        self.existing_id = existing_id
        self.similarity = similarity
        super().__init__(
            f"Duplicate directive: existing '{existing_id}' has "
            f"similarity {similarity:.3f} >= dedup threshold. "
            f"Use the existing directive or deactivate it first."
        )


class MemoryFrozenError(AgentLockedError):
    """Memory mutation blocked because memory_mode forbids writes.

    Raised when ``LockConfig.memory_mode == "read_only"`` or
    ``"append_only"`` and a caller attempts an incompatible operation
    (e.g., reinforcement on ``read_only``, decay on ``freeze_decay=True``).
    """

    def __init__(self, operation: str, memory_mode: str) -> None:
        self.operation = operation
        self.memory_mode = memory_mode
        super().__init__(
            domain="memory",
            required_mode="learning",
            current_mode=memory_mode,
        )
        self.args = (
            f"Cannot perform '{operation}' on memory: memory_mode is '{memory_mode}'.",
        )


class SessionRequiredError(WisdomLayerError):
    """Bare capture() call made while ``require_session_for_capture=True``.

    Raised when ``SessionConfig.require_session_for_capture`` is enabled
    and a caller invokes ``agent.memory.capture(...)`` outside an
    ``async with agent.session(...)`` context manager.
    """

    def __init__(self) -> None:
        super().__init__(
            "capture() called outside an agent.session() context, but "
            "SessionConfig.require_session_for_capture is True. "
            "Wrap the call in: async with agent.session() as s: await s.capture(...)"
        )


class BudgetExceededError(WisdomLayerError):
    """Cost guard blocked an operation due to budget cap.

    Raised by ``BudgetGuard`` when a pre-flight estimate exceeds
    ``max_cost_per_cycle_usd``, or when daily spend crosses the
    cooldown threshold (1.20 * daily cap by default). Carries enough
    context for callers to surface actionable error messages.
    """

    def __init__(
        self,
        *,
        spent_usd: float,
        cap_usd: float,
        period: str,
        cycle_id: str | None = None,
    ) -> None:
        self.spent_usd = spent_usd
        self.cap_usd = cap_usd
        self.period = period
        self.cycle_id = cycle_id
        super().__init__(
            f"Budget exceeded for {period}: "
            f"${spent_usd:.4f} >= ${cap_usd:.4f}"
            + (f" (cycle_id={cycle_id})" if cycle_id else "")
        )


class CriticVetoError(WisdomLayerError):
    """Critic vetoed an action as incompatible with active directives.

    Raised by the executive veto stack when an evaluated action falls
    below ``coherence_threshold`` (default 0.6). Carries the coherence
    score and the directive that triggered the veto, if identifiable.
    """

    def __init__(
        self,
        reason: str,
        *,
        coherence_score: float | None = None,
        blocking_directive_id: str | None = None,
    ) -> None:
        self.reason = reason
        self.coherence_score = coherence_score
        self.blocking_directive_id = blocking_directive_id
        detail = reason
        if coherence_score is not None:
            detail += f" (coherence={coherence_score:.2f})"
        if blocking_directive_id:
            detail += f" [directive={blocking_directive_id}]"
        super().__init__(f"Critic veto: {detail}")


class LLMFailureError(ModelAdapterError):
    """All models in the requested tier failed.

    Raised by ``ModelRouter`` when every adapter at the requested tier
    is either in circuit-breaker state, rate-limited, or errored out
    within the retry budget. Downstream callers should either downgrade
    the tier (if ``allow_fallback=True``) or propagate the failure.
    """

    def __init__(
        self,
        tier: str,
        attempted_models: list[str],
        *,
        last_error: str | None = None,
    ) -> None:
        self.tier = tier
        self.attempted_models = attempted_models
        self.last_error = last_error
        msg = f"All models in tier '{tier}' failed: {', '.join(attempted_models)}"
        if last_error:
            msg += f" (last_error={last_error})"
        super().__init__(msg)


class ContextOverflowError(WisdomLayerError):
    """Composed prompt exceeds the model's context window.

    Raised by ``ContextComposer`` when the fully-assembled prompt cannot
    fit in the configured model's context budget and the overflow lands
    in a non-truncatable layer — Layer 0 (``hard_constraints``) or
    Layer 6 (``raw_prompt``). See ``03_critic_directives.md`` §"Context
    Composition Order" for the layer hierarchy and truncation policy.

    This is raised *before* any LLM request is made; silently dropping
    part of the user's prompt or an identity axiom is never acceptable.
    Callers typically surface this as a 413-equivalent to their users
    and should not retry without shrinking the input.
    """

    def __init__(
        self,
        *,
        layer: str,
        tokens_used: int,
        tokens_available: int,
        model: str | None = None,
    ) -> None:
        self.layer = layer
        self.tokens_used = tokens_used
        self.tokens_available = tokens_available
        self.model = model
        detail = (
            f"Context overflow in non-truncatable layer '{layer}': "
            f"{tokens_used} tokens required, {tokens_available} available"
        )
        if model:
            detail += f" (model={model})"
        super().__init__(detail)


class SyncInAsyncError(WisdomLayerError):
    """A ``_sync`` method was called from inside a running event loop.

    Raised by :func:`wisdom_layer.asyncutils.run_sync` when it detects
    that the caller is on the same thread as a running ``asyncio``
    event loop. Spinning a fresh runner here would deadlock the outer
    loop, and transparently scheduling via ``anyio.from_thread.run``
    without an explicit portal would violate structured concurrency.

    The fix is always caller-side: use ``await`` on the async variant,
    or (for legacy blocking drivers inside an async program) dispatch
    the async method to a worker thread via ``asyncio.to_thread(...)``
    and call the ``_sync`` variant from there.

    See ``06_extraction_plan.md`` §0.5 and
    ``11_integration_ergonomics_resolutions.md`` §4.
    """

    def __init__(self, method_name: str | None = None) -> None:
        self.method_name = method_name
        target = (
            f"'{method_name}_sync'" if method_name else "a *_sync method"
        )
        super().__init__(
            f"{target} was called from inside a running event loop. "
            f"Use `await` on the async variant instead. "
            f"If you must bridge across threads, call the async method "
            f"from a worker thread via `asyncio.to_thread(...)`, or "
            f"register a BlockingPortal via `agent.portal_scope()` and "
            f"call `_sync` from a worker thread spawned inside it."
        )


class MessageRateLimitExceededError(WisdomLayerError):
    """Workspace messaging throttle blocked a send.

    Raised by :class:`MessageBus` when a sender has exceeded the
    rolling-hour cap on messages — either the per-agent total
    (``max_messages_per_agent_per_hour``, default 100) or the
    broadcast-only sub-cap (``broadcast_rate_limit_per_hour``, default
    10). The throttle is workspace-local safety; it is not a
    tier-billing cap (those raise :class:`TierRestrictionError`). The
    sender should pause and retry after the window rolls; the SDK does
    not auto-retry because a fan-out storm is the exact failure mode
    the cap exists to interrupt.

    Carries enough structured context for an operator dashboard or
    LLM tool surface to render an actionable error without
    re-querying the bus.
    """

    def __init__(
        self,
        *,
        sender_id: str,
        limit_kind: str,
        current: int,
        limit: int,
        window_seconds: int = 3600,
    ) -> None:
        self.sender_id = sender_id
        self.limit_kind = limit_kind
        self.current = current
        self.limit = limit
        self.window_seconds = window_seconds
        super().__init__(
            f"Message rate limit exceeded for sender {sender_id!r} "
            f"({limit_kind}): {current} sent in last {window_seconds}s "
            f">= cap {limit}. Pause and retry after the window rolls."
        )


class SnapshotExpiredError(WisdomLayerError):
    """Snapshot scope exceeded its ``max_snapshot_seconds`` lifetime.

    Raised when a read issued against a snapshot handle discovers that
    the underlying backend transaction has been force-closed because the
    snapshot scope (``respond`` helper call, explicit ``agent.snapshot()``
    block, or dream cycle phase group) ran longer than
    ``ResourceLimits.max_snapshot_seconds``.

    See ``02_dream_cycles.md`` §"State Visibility Model" for the
    snapshot lifecycle. The timeout exists to prevent a hung caller
    from holding a read transaction open indefinitely and blocking
    WAL checkpoint / vacuum in the storage backend.
    """

    def __init__(
        self,
        *,
        snapshot_id: str,
        age_seconds: float,
        limit_seconds: float,
    ) -> None:
        self.snapshot_id = snapshot_id
        self.age_seconds = age_seconds
        self.limit_seconds = limit_seconds
        super().__init__(
            f"Snapshot '{snapshot_id}' expired: "
            f"age {age_seconds:.1f}s >= limit {limit_seconds:.1f}s. "
            f"Exit the snapshot scope and re-enter to obtain a fresh view."
        )
