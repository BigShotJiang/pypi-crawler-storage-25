"""Anonymous usage telemetry subsystem.

What this module does
---------------------
- Generates and persists a stable per-install UUID at
  ``~/.wisdom_layer/install_id``.
- Decides whether telemetry is enabled, given the user's tier and
  environment (``WL_TELEMETRY`` env override).
- Builds a payload of *aggregate counts only* — agents, memories, 30-
  day messages, facts, dream cycles, directives — and posts it to a
  configurable endpoint via async fire-and-forget.
- Emits a one-time first-run INFO disclosure so telemetry never
  starts silently.

What this module does NOT do
----------------------------
- Send any content (memory text, LLM prompts/responses, agent names,
  user names, file paths, host names).
- Send any PII.
- Block any agent operation. Failures are silent and never raise.
- Run on Pro / Enterprise tiers unless ``WL_TELEMETRY=1`` is set
  explicitly.

This module is intentionally NOT Cython-compiled — users should be
able to read the source and verify exactly what is sent. Transparency
is part of the privacy story; obfuscation would undercut it.

See ``BUSINESSFY/05_TELEMETRY_SUBSYSTEM.md`` for the design rationale
and ``docs/telemetry.md`` (public-repo) for the user-facing
disclosure.
"""

from __future__ import annotations

import logging
import os
import sys
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from collections.abc import Mapping
    from datetime import datetime

    from wisdom_layer.clock import Clock

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants — wire format and defaults
# ---------------------------------------------------------------------------

PAYLOAD_VERSION: int = 1
"""Schema version for the telemetry payload. Lets the ingest endpoint
parse known shapes; lets the SDK evolve the payload without breaking
older clients. Bump when adding fields. Never remove a field within a
version — only add."""

DEFAULT_ENDPOINT: str = "https://api.wisdomlayer.ai/v1/telemetry"
"""Public ingest endpoint. Override with ``WL_TELEMETRY_ENDPOINT`` for
local development or self-hosted deployments."""

DEFAULT_INSTALL_ID_DIR: Path = Path.home() / ".wisdom_layer"
INSTALL_ID_FILENAME: str = "install_id"

ENV_TELEMETRY: str = "WL_TELEMETRY"
ENV_ENDPOINT: str = "WL_TELEMETRY_ENDPOINT"


# ---------------------------------------------------------------------------
# Payload schema
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TelemetrySnapshot:
    """One telemetry batch. Pinned wire format.

    Aggregate counts only — no content, no PII. The serialized payload
    keys are the wire-format names (``os`` rather than ``os_name``);
    the dataclass field is ``os_name`` to avoid shadowing the stdlib
    ``os`` module in this file.
    """

    install_id: str
    ts: datetime
    version: str
    tier: str
    agent_count: int
    memory_count: int
    msg_count_30d: int
    fact_count: int
    dream_cycles_count: int
    directive_count: int
    os_name: str
    python_version: str

    def to_payload(self) -> dict[str, object]:
        """Serialize to the wire format. Pinned schema — every field
        listed here is documented in ``docs/telemetry.md`` and any
        change requires a ``payload_version`` bump."""
        return {
            "payload_version": PAYLOAD_VERSION,
            "install_id": self.install_id,
            "ts": self.ts.isoformat(),
            "version": self.version,
            "tier": self.tier,
            "agent_count": self.agent_count,
            "memory_count": self.memory_count,
            "msg_count_30d": self.msg_count_30d,
            "fact_count": self.fact_count,
            "dream_cycles_count": self.dream_cycles_count,
            "directive_count": self.directive_count,
            "os": self.os_name,
            "python_version": self.python_version,
        }


@dataclass(frozen=True)
class CountSnapshot:
    """Tier-agnostic counter view that callers populate once per
    batch. Kept distinct from :class:`TelemetrySnapshot` so the
    install-id / version / tier / system-info plumbing happens in one
    place rather than at every call site."""

    agent_count: int = 0
    memory_count: int = 0
    msg_count_30d: int = 0
    fact_count: int = 0
    dream_cycles_count: int = 0
    directive_count: int = 0


# ---------------------------------------------------------------------------
# Defaults — opt-out on Free, opt-in on Pro/Enterprise
# ---------------------------------------------------------------------------


def should_enable(
    tier: str, env: Mapping[str, str] | None = None
) -> bool:
    """Compute the effective telemetry-enable state.

    Defaults:
        - Anonymous (``tier == ""``) and Free: **on** (opt-out).
        - Pro and Enterprise: **off** (opt-in).

    Override via ``WL_TELEMETRY`` env var:
        - ``"0"`` / ``"false"`` / ``"no"`` → off
        - ``"1"`` / ``"true"`` / ``"yes"`` → on

    Any other value is ignored and the per-tier default applies. The
    permissive parsing exists so users typing ``export WL_TELEMETRY=
    false`` from a shell don't get a counter-intuitive result.
    """
    environ = env if env is not None else os.environ
    override = environ.get(ENV_TELEMETRY)
    if override is not None:
        normalized = override.strip().lower()
        if normalized in {"0", "false", "no", "off"}:
            return False
        if normalized in {"1", "true", "yes", "on"}:
            return True
        # Unknown override — fall through to per-tier default.
    return tier in {"", "free"}


def get_endpoint(env: Mapping[str, str] | None = None) -> str:
    """Return the telemetry ingest URL, honoring ``WL_TELEMETRY_ENDPOINT``."""
    environ = env if env is not None else os.environ
    return environ.get(ENV_ENDPOINT, DEFAULT_ENDPOINT)


# ---------------------------------------------------------------------------
# Install ID — stable per-install UUID
# ---------------------------------------------------------------------------


def read_or_create_install_id(
    install_id_dir: Path | None = None,
) -> tuple[str, bool]:
    """Read the stable install UUID, generating one on first run.

    Returns ``(install_id, is_new)``. ``is_new`` is True only when the
    file was just created. Callers use it to gate the first-run
    disclosure so telemetry cannot start silently.

    The file is created with the user's default permissions; we don't
    chmod it tighter because (a) it's a UUID, not a secret, and (b)
    operating-system-specific permission policies are the user's
    responsibility.
    """
    target_dir = install_id_dir or DEFAULT_INSTALL_ID_DIR
    target_dir.mkdir(parents=True, exist_ok=True)
    path = target_dir / INSTALL_ID_FILENAME
    if path.exists():
        existing = path.read_text(encoding="utf-8").strip()
        if existing:
            return existing, False
        # File exists but is empty / whitespace — treat as fresh.
    new_id = str(uuid.uuid4())
    path.write_text(new_id, encoding="utf-8")
    return new_id, True


def emit_first_run_disclosure(
    *,
    tier: str = "",
    env: Mapping[str, str] | None = None,
) -> None:
    """Log the one-time first-run INFO disclosure.

    Three states, one per branch:

    * **Telemetry will fire** (Free with no opt-out, or any tier with
      ``WL_TELEMETRY=1``): emit the standard "telemetry enabled"
      message with the opt-out instructions.
    * **Telemetry explicitly disabled** by ``WL_TELEMETRY=0`` /
      ``false`` / ``no`` / ``off``: emit a confirmation that the
      opt-out was honored, so a privacy-conscious user who set the
      env var before first launch sees their choice acknowledged
      instead of a contradictory "telemetry enabled" line.
    * **Telemetry off by tier default** (Pro / Enterprise without an
      explicit ``WL_TELEMETRY=1``): stay silent. Nothing is enabled,
      nothing is being sent, nothing surprising — adding a log line
      here would just be noise.

    Called from :func:`read_or_create_install_id_with_disclosure` when
    a new install_id was just generated. Coupling the disclosure to
    install_id creation is what makes "telemetry never starts silently"
    a structural property rather than a documentation hope.
    """
    environ = env if env is not None else os.environ
    enabled = should_enable(tier, environ)
    explicit_override = environ.get(ENV_TELEMETRY) is not None

    if enabled:
        logger.info(
            "First run — anonymous usage telemetry enabled (counts only, "
            "no content, no PII). Disable with WL_TELEMETRY=0. Details: "
            "https://wisdomlayer.ai/docs/telemetry",
            extra={
                "telemetry_enabled": True,
                "first_run": True,
            },
        )
    elif explicit_override:
        # Privacy-conscious user set WL_TELEMETRY=0 (or equivalent)
        # before first launch — confirm the opt-out so they see their
        # choice acknowledged rather than a contradictory message.
        logger.info(
            "First run — anonymous usage telemetry disabled by "
            "WL_TELEMETRY env override. No payloads will be sent.",
            extra={
                "telemetry_enabled": False,
                "first_run": True,
            },
        )
    # else: tier-default off (Pro / Enterprise) — silent.


def read_or_create_install_id_with_disclosure(
    install_id_dir: Path | None = None,
    *,
    tier: str = "",
    env: Mapping[str, str] | None = None,
) -> str:
    """Convenience wrapper: get the install UUID and emit the
    disclosure on first run. The recommended call site for agent code
    so the disclosure cannot be forgotten.

    Args:
        install_id_dir: Where to read/write the ``install_id`` file.
            Defaults to ``~/.wisdom_layer``.
        tier: The agent's effective tier (``""`` for anonymous Free,
            or ``"free"`` / ``"pro"`` / ``"enterprise"``). Used to
            decide which first-run message to emit so the disclosure
            never contradicts the actual telemetry state.
        env: Environment mapping to consult for ``WL_TELEMETRY``.
            Defaults to ``os.environ``. Test injection point.
    """
    install_id, is_new = read_or_create_install_id(install_id_dir)
    if is_new:
        emit_first_run_disclosure(tier=tier, env=env)
    return install_id


# ---------------------------------------------------------------------------
# Snapshot construction
# ---------------------------------------------------------------------------


def _detect_os() -> str:
    """Return a coarse OS family string. ``linux`` / ``darwin`` /
    ``win32`` / ``other``. No version detail."""
    plat = sys.platform
    if plat.startswith("linux"):
        return "linux"
    if plat == "darwin":
        return "darwin"
    if plat.startswith("win"):
        return "win32"
    return "other"


def _detect_python_version() -> str:
    """Major.minor only (e.g., ``"3.11"``)."""
    return f"{sys.version_info.major}.{sys.version_info.minor}"


def build_snapshot(
    *,
    install_id: str,
    version: str,
    tier: str,
    counts: CountSnapshot,
    clock: Clock,
) -> TelemetrySnapshot:
    """Construct a :class:`TelemetrySnapshot` from the current agent
    state. The ``os`` and ``python_version`` fields are detected from
    the running interpreter — no caller input needed.
    """
    return TelemetrySnapshot(
        install_id=install_id,
        ts=clock.now(),
        version=version,
        tier=tier,
        agent_count=counts.agent_count,
        memory_count=counts.memory_count,
        msg_count_30d=counts.msg_count_30d,
        fact_count=counts.fact_count,
        dream_cycles_count=counts.dream_cycles_count,
        directive_count=counts.directive_count,
        os_name=_detect_os(),
        python_version=_detect_python_version(),
    )


# ---------------------------------------------------------------------------
# Async client — fire-and-forget
# ---------------------------------------------------------------------------


@dataclass
class TelemetryClient:
    """Async fire-and-forget telemetry sender. Never raises.

    The :meth:`send_batch` coroutine is intended to be scheduled via
    ``asyncio.ensure_future()`` and the future discarded. Any failure
    — connection refused, DNS, 5xx, malformed response — is swallowed
    and logged at DEBUG. Telemetry must never block or break the agent
    loop.

    The ``http_client`` field is exposed so tests can inject a stub
    transport. Production callers leave it as ``None`` and the client
    creates an ad-hoc :class:`httpx.AsyncClient` per send.
    """

    endpoint: str = DEFAULT_ENDPOINT
    timeout_seconds: float = 5.0
    http_client: httpx.AsyncClient | None = field(default=None)

    async def send_batch(self, snapshot: TelemetrySnapshot) -> None:
        """Post a snapshot. Always returns None. Never raises."""
        try:
            payload = snapshot.to_payload()
            if self.http_client is not None:
                response = await self.http_client.post(
                    self.endpoint, json=payload, timeout=self.timeout_seconds
                )
            else:
                async with httpx.AsyncClient(
                    timeout=self.timeout_seconds
                ) as client:
                    response = await client.post(self.endpoint, json=payload)
            if response.status_code >= 400:
                logger.debug(
                    "telemetry endpoint returned non-2xx",
                    extra={
                        "status_code": response.status_code,
                        "endpoint": self.endpoint,
                    },
                )
        except Exception as exc:  # noqa: BLE001 — fail-silent by design
            logger.debug(
                "telemetry send failed",
                extra={
                    "error_type": type(exc).__name__,
                    "endpoint": self.endpoint,
                },
            )


__all__ = [
    "PAYLOAD_VERSION",
    "DEFAULT_ENDPOINT",
    "ENV_TELEMETRY",
    "ENV_ENDPOINT",
    "CountSnapshot",
    "TelemetrySnapshot",
    "TelemetryClient",
    "build_snapshot",
    "should_enable",
    "get_endpoint",
    "read_or_create_install_id",
    "read_or_create_install_id_with_disclosure",
    "emit_first_run_disclosure",
]
