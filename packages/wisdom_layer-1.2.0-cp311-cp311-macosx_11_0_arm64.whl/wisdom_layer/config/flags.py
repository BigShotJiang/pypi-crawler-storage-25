"""FeatureFlags — independently toggleable pro features.

Every feature is gated by BOTH tier (paid vs free) AND user preference
(opted-in vs opted-out). These flags represent the user preference layer.

Doc reference: ``07_config_architecture.md`` §"FeatureFlags".
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class FeatureFlags:
    """Per-agent feature toggles (T1 — customer-facing).

    Each flag defaults to True. Tier gating is applied separately
    by the license module — these flags allow a paying customer to
    opt OUT of features they don't want.
    """

    dreams: bool = True
    scheduled_dreams: bool = True
    reconsolidation: bool = True
    journals: bool = True
    directives: bool = True
    critic: bool = True
    goals: bool = True
    emotional_tracking: bool = True
    health_analytics: bool = True
    provenance: bool = True
    # v0.5 Phase 2: granular provenance surface. The umbrella
    # ``provenance`` flag above keeps the legacy source-id chain
    # accessible; these three gate the v0.5 event-log APIs
    # independently so operators can turn off narration without
    # losing the raw trace, etc.
    provenance_trace: bool = True
    provenance_explain: bool = True
    provenance_export: bool = True
    # v0.5 Phase 4: cost-visibility surface. ``cost_visibility`` gates
    # ``agent.cost.summary()`` and ``estimate_dream()``; ``cost_budget``
    # gates BudgetGuard enforcement hooks; ``cost_export`` gates the
    # Enterprise-only CSV export.
    cost_visibility: bool = True
    cost_budget: bool = True
    cost_export: bool = True
