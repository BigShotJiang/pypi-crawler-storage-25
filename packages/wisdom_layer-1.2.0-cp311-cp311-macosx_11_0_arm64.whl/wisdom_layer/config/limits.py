"""ResourceLimits — tunable resource caps.

Doc reference: ``07_config_architecture.md`` §"ResourceLimits",
``11_integration_ergonomics_resolutions.md`` §"ResourceLimits invariants".
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ResourceLimits:
    """Per-agent resource caps (T1 — customer-facing).

    Each field carries a unit in its docstring so developers know what
    knob they are turning. Pick a preset factory (:meth:`for_cloud`,
    :meth:`for_local`, :meth:`for_small_model`) unless you have a
    specific reason to tune individually.
    """

    # -- Memory -----------------------------------------------------------

    max_memories_per_agent: int = 100_000
    """Hard cap on non-archived memories per agent (count)."""

    max_memory_content_chars: int = 10_000
    """Reject a single memory whose serialized content exceeds this (chars)."""

    memory_dedup_threshold: float = 0.92
    """Cosine similarity at which near-duplicate capture is merged (0.0–1.0)."""

    # -- Dreams -----------------------------------------------------------

    max_dream_phases: int = 6
    """Hard cap on phases run per dream cycle (count)."""

    dreams_phase_timeout_seconds: int = 600
    """Per-phase timeout inside a dream cycle (seconds)."""

    # -- Events -----------------------------------------------------------

    event_queue_depth_per_subscription: int = 1024
    """In-flight event buffer per subscriber before back-pressure (count)."""

    # -- Snapshots --------------------------------------------------------

    max_snapshot_seconds: int = 300
    """Max lifetime of a snapshot scope before reads are force-closed (seconds)."""

    # -- LLM --------------------------------------------------------------

    max_concurrent_llm_calls: int = 4
    """Upper bound on simultaneous LLM requests from this agent (count)."""

    # -- Tier caps (Free) -------------------------------------------------
    #
    # These caps are tier-bound, not deployment-bound — they apply on the
    # Free tier regardless of which preset (cloud/local/small_model) is
    # active. Pro and Enterprise tiers ignore these values; tier
    # enforcement happens in the compiled feature gate, not here.

    max_agents_free: int = 3
    """Hard cap on agents per license at Free tier (count)."""

    max_memories_free: int = 1_000
    """Hard cap on non-archived memories per agent at Free tier (count)."""

    max_messages_per_30d_free: int = 1_500
    """Rolling 30-day message ingress cap at Free tier (count)."""

    # -- Presets -----------------------------------------------------------

    @classmethod
    def for_cloud(cls) -> ResourceLimits:
        """Generous limits for cloud deployments with hosted LLMs.

        Use when running on infra where LLM latency is bounded and
        memory storage is cheap — matches the library defaults.
        """
        return cls()

    @classmethod
    def for_local(cls) -> ResourceLimits:
        """Moderate limits for a developer laptop running a local model.

        Tuned for Ollama / LM Studio setups on workstation-class hardware:
        smaller memory footprint, lower LLM parallelism, and shorter
        per-phase budgets than cloud defaults.
        """
        return cls(
            max_memories_per_agent=10_000,
            max_concurrent_llm_calls=2,
            dreams_phase_timeout_seconds=300,
        )

    @classmethod
    def for_small_model(cls) -> ResourceLimits:
        """Tight limits for 7B-class models where context is expensive.

        Assumes a short context window and serial inference. Memory cap,
        dream concurrency, and phase timeouts are all trimmed so a
        small model is not asked to chew through cloud-sized batches.
        """
        return cls(
            max_memories_per_agent=2_000,
            max_concurrent_llm_calls=1,
            dreams_phase_timeout_seconds=180,
            max_memory_content_chars=4_000,
        )
