"""Configuration for the Wisdom Layer SDK.

Phase 0.9 additions: ``FeatureFlags``, ``ResourceLimits``, ``LockConfig``,
and ``SessionConfig`` are first-class fields on :class:`AgentConfig`.

Doc reference: ``07_config_architecture.md``, ``11_integration_ergonomics_resolutions.md`` §16.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from wisdom_layer._internal.admin_defaults import AdminDefaults
from wisdom_layer.config.flags import FeatureFlags
from wisdom_layer.config.limits import ResourceLimits
from wisdom_layer.config.lock import LockConfig
from wisdom_layer.config.session import SessionConfig
from wisdom_layer.llm.retry import RetryPolicy  # noqa: TC001  (Pydantic needs runtime access)


class PersonalityConfig(BaseModel):
    """Agent personality parameters (0.0–1.0 scale)."""

    curiosity: float = Field(default=0.5, ge=0.0, le=1.0)
    empathy: float = Field(default=0.5, ge=0.0, le=1.0)
    rigor: float = Field(default=0.5, ge=0.0, le=1.0)
    creativity: float = Field(default=0.5, ge=0.0, le=1.0)
    assertiveness: float = Field(default=0.5, ge=0.0, le=1.0)


class DreamConfig(BaseModel):
    """Dream cycle configuration."""

    schedule: str = "0 2 * * *"  # Cron expression, default 2 AM daily
    phases: list[str] = Field(
        default_factory=lambda: [
            "reconsolidation",
            "criticism",
            "synthesis",
            "entropy",
            "journal",
        ]
    )
    intensity: str = "standard"  # "light", "standard", "deep"
    evolve_directives: bool = True  # Enable/disable the evolve_directives dream step


class AgentConfig(BaseModel):
    """Configuration for a WisdomAgent instance.

    Most users pick a preset — :meth:`for_dev`, :meth:`for_prod`,
    :meth:`for_testing` — and optionally compose an archetype via
    ``admin_defaults=AdminDefaults.for_research()``. That covers ~95%
    of integrations. The raw constructor is available for finer tuning.
    Use :meth:`template_mode` for one-call locked production setup.
    """

    name: str
    role: str = ""
    directives: list[str] = Field(default_factory=list)
    personality: PersonalityConfig = Field(default_factory=PersonalityConfig)
    dreams: DreamConfig = Field(default_factory=DreamConfig)

    # License
    api_key: str = ""  # wl_free_xxx, wl_pro_xxx, wl_ent_xxx

    # LLM
    model_config_extra: dict[str, Any] = Field(default_factory=dict)

    # Phase 0.9 — config subsystem
    feature_flags: FeatureFlags = Field(default_factory=FeatureFlags)
    resource_limits: ResourceLimits = Field(default_factory=ResourceLimits)
    lock: LockConfig = Field(default_factory=LockConfig)
    session: SessionConfig = Field(default_factory=SessionConfig)

    # v0.3 — T2 archetype profile. Most users leave this as the default
    # (``balanced``). Specialized agents pick an archetype factory:
    # ``AdminDefaults.for_research()``, ``.for_coding_assistant()``,
    # ``.for_consumer_support()``, ``.for_strategic_advisors()``,
    # ``.for_lightweight_local()``.
    admin_defaults: AdminDefaults = Field(default_factory=AdminDefaults)

    # v0.6 — reliability. As of v1.1.0, the default is a real
    # ``RetryPolicy()`` (max_attempts=3, exponential backoff with jitter)
    # rather than ``None``. Pre-1.1 the default was ``None``, which
    # silently meant "no retries" — a production footgun. Callers that
    # explicitly want zero retries should pass
    # ``retry_policy=RetryPolicy(max_attempts=1)``; passing ``None`` is
    # still accepted and continues to mean "no retry wrapper installed".
    retry_policy: RetryPolicy | None = Field(default_factory=RetryPolicy)
    shutdown_timeout_s: float = Field(default=30.0, ge=1.0, le=300.0)

    # v1.0 — retrieval mix tuning. Reserves a fraction of every
    # ``memory.search()`` result slot for ``reconsolidated_insight``
    # entries (dream-cycle outputs), so distilled knowledge surfaces
    # alongside raw conversations even when raw events out-rank the
    # insights by similarity. ``0.0`` (default) preserves the v0.x
    # behavior — purely similarity-ordered, no reservation. Recommended
    # values are in the 0.20–0.40 range when insights are sparse but
    # high-signal. The reservation only kicks in when the caller does
    # not pass an explicit ``kinds=`` filter to ``memory.search()``.
    search_insight_ratio: float = Field(default=0.0, ge=0.0, le=1.0)

    model_config = {"extra": "forbid", "arbitrary_types_allowed": True}

    # -- Presets ----------------------------------------------------------

    @classmethod
    def for_dev(
        cls,
        *,
        name: str = "dev-agent",
        admin_defaults: AdminDefaults | None = None,
        **kwargs: Any,
    ) -> AgentConfig:
        """Preset for local development.

        Verbose feature flags on, short dream cadence, small memory
        footprint. Use this while iterating on an agent locally; swap
        to :meth:`for_prod` before shipping.
        """
        return cls(
            name=name,
            dreams=DreamConfig(schedule="*/30 * * * *", intensity="light"),
            feature_flags=FeatureFlags(),
            resource_limits=ResourceLimits.for_local(),
            lock=LockConfig(),
            admin_defaults=admin_defaults or AdminDefaults.balanced(),
            **kwargs,
        )

    @classmethod
    def for_prod(
        cls,
        *,
        name: str,
        admin_defaults: AdminDefaults | None = None,
        **kwargs: Any,
    ) -> AgentConfig:
        """Preset for production deployment.

        Daily dream cadence, cloud-sized resource limits, full feature
        set except experimental. Not locked by default — combine with
        :meth:`template_mode` or a custom ``LockConfig`` when freezing
        behavior before a customer release.
        """
        return cls(
            name=name,
            dreams=DreamConfig(schedule="0 2 * * *", intensity="standard"),
            feature_flags=FeatureFlags(),
            resource_limits=ResourceLimits.for_cloud(),
            lock=LockConfig(),
            admin_defaults=admin_defaults or AdminDefaults.balanced(),
            **kwargs,
        )

    @classmethod
    def for_testing(
        cls,
        *,
        name: str = "test-agent",
        admin_defaults: AdminDefaults | None = None,
        **kwargs: Any,
    ) -> AgentConfig:
        """Preset for deterministic unit and integration tests.

        Minimal memory, no background work (dreams off), no session
        requirement. Combine with ``FrozenClock`` + ``FakeLLMAdapter``
        from ``wisdom_layer.testing`` for fully reproducible runs.
        """
        return cls(
            name=name,
            dreams=DreamConfig(schedule="0 0 1 1 *", intensity="light"),
            feature_flags=FeatureFlags(dreams=False),
            resource_limits=ResourceLimits.for_small_model(),
            lock=LockConfig(),
            session=SessionConfig(),
            admin_defaults=admin_defaults or AdminDefaults.balanced(),
            **kwargs,
        )

    @classmethod
    def template_mode(
        cls,
        *,
        name: str,
        role: str = "",
        directives: list[str] | None = None,
        api_key: str = "",
        **kwargs: Any,
    ) -> AgentConfig:
        """One-call preset for locked production agents.

        Sets ``lock.directive_evolution_mode="locked"``,
        ``lock.memory_mode="read_only"``, ``lock.freeze_decay=True``,
        and ``features.dreams=False``.

        Doc reference: ``07_config_architecture.md`` §"AgentConfig.template_mode()".
        """
        return cls(
            name=name,
            role=role,
            directives=directives or [],
            api_key=api_key,
            lock=LockConfig(
                directive_evolution_mode="locked",
                memory_mode="read_only",
                freeze_decay=True,
            ),
            feature_flags=FeatureFlags(dreams=False),
            **kwargs,
        )


__all__ = [
    "AdminDefaults",
    "AgentConfig",
    "DreamConfig",
    "FeatureFlags",
    "LockConfig",
    "PersonalityConfig",
    "ResourceLimits",
    "SessionConfig",
]
