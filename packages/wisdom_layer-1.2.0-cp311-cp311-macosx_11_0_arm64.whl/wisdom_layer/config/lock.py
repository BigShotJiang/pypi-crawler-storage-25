"""LockConfig — drift prevention for production agents.

No ``unlock()`` method, no runtime mutation. Locked agents must be
replaced via ``agent.snapshot()`` + ``WisdomAgent.from_snapshot()``.

Doc reference: ``07_config_architecture.md`` §"LockConfig",
``11_integration_ergonomics_resolutions.md`` §16.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class LockConfig:
    """Immutable lock configuration for an agent (T1).

    ``frozen=True`` ensures these values cannot be mutated after
    construction. If ``agent.unlock()`` existed, prompt injection
    would have a target.

    Attributes:
        directive_evolution_mode: Controls whether directives can be
            added/modified/removed.
            - "active": full evolution (default for training).
            - "advisory": proposals are logged but not applied.
            - "locked": all mutation rejected with ``DirectiveLockedError``.
        memory_mode: Controls write behavior for the memory subsystem.
            - "learning": full read/write (default).
            - "append_only": capture allowed, no reinforce/decay/delete.
            - "read_only": search only, all writes rejected.
        freeze_decay: If True, salience decay is disabled even if
            dreams are running. Useful for locked production agents
            whose memory salience was tuned during training.
    """

    directive_evolution_mode: Literal["active", "advisory", "locked"] = "active"
    memory_mode: Literal["learning", "append_only", "read_only"] = "learning"
    freeze_decay: bool = False
