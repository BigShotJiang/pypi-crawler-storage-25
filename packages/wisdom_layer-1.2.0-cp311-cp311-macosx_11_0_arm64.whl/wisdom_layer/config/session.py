"""SessionConfig — session-level defaults for agent.session() context manager.

Doc reference: ``07_config_architecture.md`` §"SessionConfig",
``11_integration_ergonomics_resolutions.md`` §16.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SessionConfig:
    """Per-agent session defaults (T1).

    Attributes:
        ephemeral_default: If True, ``agent.session()`` defaults to
            ephemeral mode (no capture, no reinforce, no dedup-merge,
            no Critic write paths — search is still allowed).
        default_scope: Default scope label for session-scoped captures.
        default_ttl_hours: Default session TTL in hours (0 = no expiry).
        require_session_for_capture: If True, bare ``capture()`` calls
            outside an ``agent.session()`` block raise ``SessionRequiredError``.
    """

    ephemeral_default: bool = False
    default_scope: str = ""
    default_ttl_hours: int = 0
    require_session_for_capture: bool = False
