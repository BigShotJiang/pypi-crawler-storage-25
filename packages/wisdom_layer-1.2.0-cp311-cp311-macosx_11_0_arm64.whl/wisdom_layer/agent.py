"""WisdomAgent — the primary entry point for the Wisdom Layer SDK."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
from collections.abc import Sequence  # noqa: TC003  (public signatures)
from datetime import UTC, datetime, time, timedelta  # noqa: TC003  (public signatures)
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, TypedDict, cast

from wisdom_layer import _telemetry
from wisdom_layer._internal.agent_registry import AgentRegistry
from wisdom_layer._internal.feature_gate import require_cap
from wisdom_layer._internal.health import (
    classify_cognitive_health,
    compute_wisdom_score,
    remedy_url_for,
)
from wisdom_layer._internal.usage_counter import UsageCounter
from wisdom_layer.asyncutils import sync_twin
from wisdom_layer.clock import SystemClock
from wisdom_layer.dreams.scheduler import DreamScheduler, ScheduleStatus
from wisdom_layer.errors import (
    CAP_KIND_AGENTS,
    CAP_KIND_MEMORIES,
    CAP_KIND_MESSAGES_30D,
    ConfigError,
    DirectiveCapacityError,
    DirectiveDuplicateError,
    FeatureDisabledError,
    MemoryFrozenError,
    SessionRequiredError,
    TierRestrictionError,
)
from wisdom_layer.facts import FactsInterface, extract_facts_for_memory
from wisdom_layer.license import (
    Tier,
    get_tier_features,
    has_feature,
    parse_key_tier,
    validate_license_full,
)
from wisdom_layer.memory.types import DeleteReport
from wisdom_layer.observability.events import (
    Event,
    EventEmitter,
    EventPriority,
    SubscriptionToken,
)
from wisdom_layer.session import SessionHandle
from wisdom_layer.types import (
    CostStats,
    DirectiveStats,
    DreamStats,
    HealthReport,
    MemoryStats,
)
from wisdom_layer.workspace.types import MessagePurpose, ThreadCloseReason, Visibility

if TYPE_CHECKING:
    from types import EllipsisType

    from wisdom_layer._internal.entitlements import EntitlementClaims
    from wisdom_layer.clock import Clock
    from wisdom_layer.config import AgentConfig
    from wisdom_layer.cost.budgets import BudgetGuard
    from wisdom_layer.llm.base import BaseLLMAdapter
    from wisdom_layer.observability.events import Handler
    from wisdom_layer.storage.base import BaseBackend
    from wisdom_layer.workspace.core import Workspace
    from wisdom_layer.workspace.directory import AgentRecord
    from wisdom_layer.workspace.types import (
        AgentMessage,
        TeamInsightProvenance,
        ThreadClosedResult,
    )

logger = logging.getLogger(__name__)

ENV_DATA_DIR: str = "WL_DATA_DIR"
"""Override for the on-disk root that holds ``install_id``, ``agents/``,
and ``usage/`` subdirs. Defaults to ``~/.wisdom_layer/`` when unset."""


def _resolve_kinds_alias(
    *,
    kinds: Sequence[str] | None,
    event_types: Sequence[str] | None,
) -> Sequence[str] | None:
    """Resolve ``kinds=`` / ``event_types=`` into a single value.

    ``event_types=`` is the more literal alias for ``kinds=`` — both
    filter by the ``event_type`` column. Callers may pass at most one.
    Returns the chosen value (or ``None`` when neither was passed).

    Raises:
        ValueError: If both ``kinds`` and ``event_types`` are non-None.
    """
    if kinds is not None and event_types is not None:
        msg = (
            "Pass either kinds= or event_types=, not both. They are "
            "aliases for the same filter."
        )
        raise ValueError(msg)
    return kinds if kinds is not None else event_types


def _resolve_data_dir() -> Path:
    """Return the SDK data root, honoring :data:`ENV_DATA_DIR`.

    Single source of truth for where install_id, the per-license agent
    registry, and the rolling-30-day usage counter SQLite live. Tests
    set ``WL_DATA_DIR=<tmp_path>`` to isolate; production deployments
    leave it unset.
    """
    raw = os.environ.get(ENV_DATA_DIR)
    if raw:
        return Path(raw).expanduser()
    return Path.home() / ".wisdom_layer"


def _render_fact_line(fact: dict[str, object]) -> str:
    """Render a single fact for the ``compose_context`` Known facts block.

    Format: ``- subject / attribute: value (as of YYYY-MM-DD)``. The
    date suffix lets the answer LLM weigh fact recency against any
    conflicting dialogue snippets in the same prompt — without the
    annotation, an outdated value extracted earlier would look the
    same as a value just captured this session. When ``created_at``
    is missing or unparseable the suffix is omitted (the fact is
    still rendered).
    """
    subject = str(fact.get("subject", ""))
    attribute = str(fact.get("attribute", ""))
    value = str(fact.get("value", ""))
    base = f"- {subject} / {attribute}: {value}"
    raw_ts = fact.get("created_at")
    if not raw_ts:
        return base
    try:
        # Accept ISO strings or datetime objects; render the date only.
        if hasattr(raw_ts, "date"):
            day = raw_ts.date().isoformat()
        else:
            day = str(raw_ts)[:10]
            # Validate it actually looks like a date to avoid emitting
            # garbage like "(as of nope-bad)".
            from datetime import date as _date

            _date.fromisoformat(day)
    except (ValueError, TypeError):
        return base
    return f"{base} (as of {day})"


def _render_memory_block(memories: list[dict[str, object]]) -> str:
    """Render search results as a ``## Relevant past interactions`` block.

    Used by :meth:`WisdomAgent.compose_system_prompt`. Two memory shapes
    are recognized:

    * ``reconsolidated_insight`` (Tier 2 dream output) — rendered as
      ``- Learned pattern: <insight>`` so the model treats it as a
      distilled rule, not a one-off event.
    * Everything else — rendered as a User/Agent/Outcome triple when
      those keys exist, falling back to ``content.text`` or a JSON dump.

    Returns the empty string when ``memories`` is empty so callers can
    join sections without filtering.
    """
    if not memories:
        return ""
    lines: list[str] = []
    for mem in memories:
        event_type = str(mem.get("event_type", ""))
        content = mem.get("content")
        c: dict[str, object] = content if isinstance(content, dict) else {}
        if event_type == "reconsolidated_insight":
            insight = str(c.get("insight", "")).strip()
            if insight:
                lines.append(f"- Learned pattern: {insight}")
            continue
        user = str(c.get("user", "")).strip()
        agent_text = str(c.get("agent", "")).strip()
        outcome = str(c.get("outcome", "")).strip()
        if user or agent_text or outcome:
            parts = []
            if user:
                parts.append(f"User: {user}")
            if agent_text:
                parts.append(f"Agent: {agent_text}")
            if outcome:
                parts.append(f"Outcome: {outcome}")
            lines.append("- " + " | ".join(parts))
            continue
        text = str(c.get("text", "")).strip()
        if text:
            lines.append(f"- {text}")
    if not lines:
        return ""
    return (
        "## Relevant past interactions (use to inform — do not invent specifics not present here)\n"
        + "\n".join(lines)
    )


def _empty_grounding_report() -> dict[str, object]:
    """Return a no-claims grounding report.

    Shared by ``_verify_grounding_internal`` early-exit paths (LLM call
    failure, no claims extracted) so the report shape stays uniform
    across success and degenerate cases.
    """
    return {
        "grounding_score": 1.0,
        "verified": [],
        "unverified": [],
        "contradicted": [],
        "verified_count": 0,
        "unverified_count": 0,
        "contradicted_count": 0,
        "claim_count": 0,
        "verified_exact_count": 0,
        "verified_semantic_count": 0,
    }


def _default_config(*, name: str | None) -> AgentConfig:
    """Pick a sensible AgentConfig preset based on environment.

    ``ENV=production`` (or ``WISDOM_LAYER_ENV=production``) selects
    :meth:`AgentConfig.for_prod`; anything else selects
    :meth:`AgentConfig.for_dev`. Called only when the caller did not
    pass an explicit ``config=``.
    """
    from wisdom_layer.config import AgentConfig as _AgentConfig

    env = os.environ.get("WISDOM_LAYER_ENV") or os.environ.get("ENV") or ""
    effective_name = name or ("prod-agent" if env.lower() == "production" else "dev-agent")
    if env.lower() == "production":
        return _AgentConfig.for_prod(name=effective_name)
    return _AgentConfig.for_dev(name=effective_name)


def _validate_agent_wiring(
    *,
    config: AgentConfig,
    llm: BaseLLMAdapter,
    tier: Tier,
) -> None:
    """Surface wiring mistakes synchronously in ``__init__``.

    Init-time validation is deliberately narrow. Defaulted permissive
    flags (``FeatureFlags(dreams=True, ...)``) on a locked or free-tier
    agent are legal — the runtime ``_require_feature`` path raises
    :class:`TierRestrictionError` / :class:`MemoryFrozenError` when the
    feature is actually invoked. Only unambiguous wiring errors fail
    here, so construction stays forgiving while misuse still surfaces
    with an actionable message at the point of use.
    """
    if config.feature_flags.dreams and not hasattr(llm, "generate"):
        raise ConfigError(
            "dream cycles require an LLM adapter with a ``generate`` method; "
            "pass llm=... or disable config.feature_flags.dreams."
        )


class _DreamStepResult(TypedDict, total=False):
    """Return shape of every ``_run_*`` dream step runner.

    Only ``status`` is guaranteed present; ``error`` / ``reason`` /
    ``result`` are populated per-step as applicable.
    """

    status: str
    error: str | None
    reason: str | None
    result: dict[str, Any] | None


class _DreamStepRecord(TypedDict):
    """Persisted step record in the dream report's ``steps`` list."""

    step_index: int
    name: str
    status: str
    duration_ms: int
    error: str | None
    reason: str | None
    result: dict[str, Any] | None


class MemoryInterface:
    """Public memory API — capture, search, consolidate, reflect."""

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    @sync_twin
    async def capture(
        self,
        event_type: str,
        content: dict[str, object],
        *,
        emotional_intensity: float = 0.0,
        created_at: datetime | None = None,
    ) -> str:
        """Capture a Tier 1 raw event (bare capture, outside a session).

        Args:
            event_type: Category of event (conversation, action, observation, etc.)
            content: Event payload.
            emotional_intensity: Optional emotional weight (0.0–1.0).
            created_at: Optional timestamp override. ``None`` (default)
                stamps the memory with the agent's clock now — the
                expected path for live captures. Set this **only when
                importing historical data** with preserved timestamps;
                passing it for live capture corrupts the temporal model
                and breaks recency-weighted retrieval and dream-cycle
                lookback windows.

                Must be timezone-aware (UTC recommended), in the past,
                and within the last 10 years. Naive datetimes, future
                timestamps, and timestamps older than 10 years raise
                ``ValueError``.

        Returns:
            The memory ID of the captured event.

        Raises:
            MemoryFrozenError: If ``memory_mode`` is ``read_only``.
            SessionRequiredError: If ``require_session_for_capture`` is True
                and no session is active.
            ValueError: If ``created_at`` is naive, in the future, or
                older than the supported historical bound.
        """
        # Session-required enforcement
        if self._agent._config.session.require_session_for_capture:
            raise SessionRequiredError()

        if created_at is not None:
            self._agent._validate_created_at(created_at)

        mode = self._agent._config.lock.memory_mode
        if mode == "read_only":
            await self._agent._emit(
                "memory.capture_suppressed",
                data={
                    "memory_type": event_type,
                    "reason": "memory_mode is read_only",
                },
            )
            raise MemoryFrozenError("capture", mode)

        return await self._agent._do_capture(
            event_type=event_type,
            content=content,
            emotional_intensity=emotional_intensity,
            created_at=created_at,
        )

    @sync_twin
    async def search(
        self,
        query: str,
        *,
        limit: int = 5,
        min_salience: float = 0.0,
        kinds: Sequence[str] | None = None,
        event_types: Sequence[str] | None = None,
    ) -> list[dict[str, object]]:
        """Search memories by semantic similarity.

        Reinforcement is async-after-return: results are returned
        immediately, and a background task nudges salience for accessed
        memories. Reinforcement is skipped when ``memory_mode`` is
        ``read_only`` or ``append_only``.

        When :attr:`AgentConfig.search_insight_ratio` is set above
        ``0.0`` and the caller does not pass an explicit ``kinds=``
        filter, a fraction of the result slots is reserved for
        ``reconsolidated_insight`` rows (dream-cycle outputs) so distilled
        knowledge surfaces alongside raw events. With ``kinds=`` set, the
        caller is already steering retrieval and the reservation is
        skipped to honor the explicit filter.

        Args:
            query: Natural language search query.
            limit: Maximum results to return.
            min_salience: Minimum salience threshold.
            kinds: Optional list of ``event_type`` values to restrict the
                search to (e.g., ``["reconsolidated_insight"]`` to surface
                only dream-cycle insights, ``["conversation"]`` for raw
                events, or ``["session_record"]`` to retrieve session
                history without semantic-rank fragility). ``None``
                (default) returns all kinds — preserves existing
                behavior. The text-LIKE fallback honors the same filter
                so cross-model legacy rows respect it too. Passing an
                explicit value disables the ``search_insight_ratio``
                reservation.
            event_types: Alias for ``kinds=`` for callers who reach for
                a more literal name. Pass at most one of the two; both
                set raises ``ValueError``.

        Returns:
            List of matching memories with similarity scores.

        Raises:
            ValueError: If both ``kinds=`` and ``event_types=`` are
                provided.
        """
        kinds = _resolve_kinds_alias(kinds=kinds, event_types=event_types)
        if not has_feature(
            self._agent._tier, "semantic_search"
        ) and not has_feature(self._agent._tier, "basic_search"):
            raise TierRestrictionError("memory search", "Capture")

        ratio = self._agent._config.search_insight_ratio
        if ratio > 0 and kinds is None and limit > 0:
            results = await self._search_with_insight_reservation(
                query=query,
                limit=limit,
                min_salience=min_salience,
                ratio=ratio,
            )
        else:
            results = await self._agent._backend.search_memories(
                agent_id=self._agent._agent_id,
                query=query,
                limit=limit,
                min_salience=min_salience,
                kinds=kinds,
            )
        await self._agent._emit(
            "memory.searched",
            priority=EventPriority.DEBUG,
            data={
                "query_preview": query[:200],
                "result_count": len(results),
            },
        )

        # Async-after-return reinforcement: tracked background task.
        # Only in "learning" mode — append_only and read_only skip reinforcement.
        # The task is registered on the agent so close() can await it; if the
        # backend is already closed by the time the task wakes (user called
        # close() between search() returning and the loop scheduling us),
        # the typed BackendNotInitializedError is silently swallowed since
        # reinforcement is best-effort and shutdown is the expected outcome.
        mode = self._agent._config.lock.memory_mode
        if mode == "learning" and results:
            from wisdom_layer.errors import BackendNotInitializedError

            memory_ids = [cast("str", r["id"]) for r in results]
            agent = self._agent

            async def _reinforce() -> None:
                try:
                    await agent._backend.reinforce_memories(
                        agent_id=agent._agent_id,
                        memory_ids=memory_ids,
                    )
                except BackendNotInitializedError:
                    # Backend was closed mid-flight — expected during shutdown.
                    return
                except Exception:
                    logger.warning(
                        "Background reinforcement failed",
                        exc_info=True,
                        extra={
                            "subsystem": "agent.memory",
                            "agent_id": agent._agent_id,
                            "memory_count": len(memory_ids),
                        },
                    )

            task = asyncio.ensure_future(_reinforce())
            agent._active_reinforce_tasks.add(task)
            task.add_done_callback(agent._active_reinforce_tasks.discard)

        return results

    async def _search_with_insight_reservation(
        self,
        *,
        query: str,
        limit: int,
        min_salience: float,
        ratio: float,
    ) -> list[dict[str, object]]:
        """Reserve a fraction of result slots for reconsolidated insights.

        Issues two backend searches in parallel:
        - one restricted to ``reconsolidated_insight`` for the reserved
          slots (``ceil(limit * ratio)``, capped at ``limit``);
        - one unrestricted, post-filtered to drop duplicates and any
          insight rows so non-insight events fill the remaining slots.

        Results are merged in ``(insights, non-insights)`` order then
        re-sorted by descending similarity so callers still see the most
        relevant entries first. The reservation only kicks in when at
        least one insight matches; otherwise the unrestricted result is
        returned untouched (graceful degradation when no insights exist).
        """
        import math

        insight_slots = min(limit, max(1, math.ceil(limit * ratio)))
        non_insight_slots = limit - insight_slots
        backend = self._agent._backend
        agent_id = self._agent._agent_id

        # Over-fetch the unrestricted slice so we have enough non-insight
        # candidates even if the top of the unrestricted ranking is
        # dominated by insights we'll dedupe against.
        overfetch = limit + insight_slots
        insights_task = backend.search_memories(
            agent_id=agent_id,
            query=query,
            limit=insight_slots,
            min_salience=min_salience,
            kinds=["reconsolidated_insight"],
        )
        unrestricted_task = backend.search_memories(
            agent_id=agent_id,
            query=query,
            limit=overfetch,
            min_salience=min_salience,
            kinds=None,
        )
        insights, unrestricted = await asyncio.gather(
            insights_task, unrestricted_task
        )

        if not insights:
            return unrestricted[:limit]

        seen_ids = {cast("str", r["id"]) for r in insights}
        non_insights: list[dict[str, object]] = []
        if non_insight_slots > 0:
            for r in unrestricted:
                if r.get("event_type") == "reconsolidated_insight":
                    continue
                if r["id"] in seen_ids:
                    continue
                non_insights.append(r)
                if len(non_insights) >= non_insight_slots:
                    break

        merged = list(insights[:insight_slots]) + non_insights
        merged.sort(
            key=lambda r: float(cast("float", r.get("similarity", 0.0))),
            reverse=True,
        )
        return merged[:limit]

    @sync_twin
    async def reflections(
        self,
        *,
        topic: str = "",
        limit: int = 5,
    ) -> list[dict[str, object]]:
        """Retrieve Tier 3 reflective journal entries.

        Args:
            topic: Optional topic filter.
            limit: Maximum results.

        Returns:
            List of reflection entries.
        """
        self._agent._require_feature("tier3_memory", "Pro")
        return await self._agent._backend.get_reflections(
            agent_id=self._agent._agent_id, topic=topic, limit=limit
        )

    @sync_twin
    async def provenance(self, memory_id: str) -> list[dict[str, object]]:
        """Trace a memory back to its raw sources.

        Args:
            memory_id: The memory to trace.

        Returns:
            Provenance chain from insight back to raw events.
        """
        self._agent._require_feature("provenance", "Pro")
        return await self._agent._backend.get_provenance(
            memory_id, agent_id=self._agent._agent_id
        )

    @sync_twin
    async def forget_subject(
        self,
        subject_id: str,
    ) -> dict[str, object]:
        """GDPR Article 17 — erase all memories mentioning a data subject.

        Searches all memories for the agent and deletes any whose content
        contains ``subject_id`` (case-insensitive text match).

        Args:
            subject_id: Identifier for the data subject (name, email, user ID).

        Returns:
            Dict with ``deleted_count`` and ``memory_ids`` of erased records.
        """
        all_memories = await self._agent._backend.export_memories(
            agent_id=self._agent._agent_id,
        )
        needle = subject_id.lower()
        matches = [
            m for m in all_memories
            if needle in str(m.get("content", "")).lower()
            or needle in str(m.get("metadata", "")).lower()
        ]

        deleted_ids: list[str] = []
        for m in matches:
            mid = m.get("id", "")
            if mid:
                await self._agent._backend.delete_memory(
                    agent_id=self._agent._agent_id,
                    memory_id=mid,
                )
                deleted_ids.append(mid)

        await self._agent._emit(
            "memory.subject_forgotten",
            data={"subject_id": subject_id, "deleted_count": len(deleted_ids)},
        )

        return {"deleted_count": len(deleted_ids), "memory_ids": deleted_ids}

    @sync_twin
    async def export_subject(
        self,
        subject_id: str,
    ) -> list[dict[str, object]]:
        """GDPR Articles 15/20 — export all memories mentioning a data subject.

        Searches all memories for the agent and returns any whose content
        contains ``subject_id`` (case-insensitive text match).

        Args:
            subject_id: Identifier for the data subject (name, email, user ID).

        Returns:
            List of memory dicts matching the subject.
        """
        all_memories = await self._agent._backend.export_memories(
            agent_id=self._agent._agent_id,
        )
        needle = subject_id.lower()
        return [
            m for m in all_memories
            if needle in str(m.get("content", "")).lower()
            or needle in str(m.get("metadata", "")).lower()
        ]

    @sync_twin
    async def consolidate(
        self,
        *,
        limit: int = 0,
        min_salience: float = 0.0,
        lookback_days: int | None = None,
    ) -> dict[str, object]:
        """Synthesize raw memories into a Tier 2 consolidated insight.

        Explicit-only — never called automatically from capture, search,
        or any hot path. The caller must invoke this directly.

        Selects high-value Tier 1 memories (ordered by reinforcement,
        salience, recency), sends them to the LLM for pattern synthesis,
        dedup-checks the output against existing insights, and stores the
        result as a Tier 2 memory with provenance linking.

        If the consolidation fails partway through, all memories written
        during this cycle are atomically rolled back via ``cycle_id``.

        Args:
            limit: Max memories to consolidate. 0 = use
                ``AdminDefaults.consolidation_max_inputs`` for the agent.
            min_salience: Minimum salience for candidate selection. 0 = use
                ``AdminDefaults.consolidation_min_salience`` for the agent.
            lookback_days: Optional age window — only memories with
                ``created_at`` newer than ``now - lookback_days`` are
                considered. ``None`` (default) preserves existing
                behavior (no time filter). Useful when historical data
                was imported with preserved timestamps and you want the
                cycle to attend only to recent activity.

        Returns:
            Dict with ``memory_id``, ``insight``, ``source_ids``,
            ``cycle_id``, and ``dedup_of`` (None if original).

        Raises:
            TierRestrictionError: If the current tier lacks ``dream_cycles``.
            MemoryFrozenError: If ``memory_mode`` is ``read_only``.
            ValueError: If ``lookback_days`` is non-positive.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        mode = self._agent._config.lock.memory_mode
        if mode == "read_only":
            raise MemoryFrozenError("consolidate", mode)
        if lookback_days is not None and lookback_days <= 0:
            raise ValueError(
                f"lookback_days must be positive; got {lookback_days}."
            )
        return await self._agent._do_consolidate(
            limit=limit,
            min_salience=min_salience,
            lookback_days=lookback_days,
        )

    @sync_twin
    async def export(
        self,
        *,
        redact_embeddings: bool = False,
        include_session_memories: bool = True,
        tier_filter: str | None = None,
        kinds: Sequence[str] | None = None,
        event_types: Sequence[str] | None = None,
        redact: Any | None = None,
        include_provenance: bool = False,
        output_format: str = "json",
    ) -> dict[str, object] | bytes:
        """Export memories as a portable bundle.

        Args:
            redact_embeddings: Embeddings excluded (always True in v1).
            include_session_memories: If False, exclude session-scoped.
            tier_filter: Only export memories of this tier.
            kinds: Optional list of ``event_type`` values to restrict
                the export to (e.g., ``["session_record"]`` for backups
                of session histories only). ``None`` (default) exports
                every event type. Same semantics as the ``kinds=``
                parameter on :meth:`MemoryInterface.search`.
            event_types: Alias for ``kinds=``. Pass at most one of the
                two; passing both raises ``ValueError``.
            redact: Content redaction — a ``Callable[[str], str]`` or a
                list of regex pattern strings. When a list, each pattern
                is replaced with ``[REDACTED]`` in memory content text.
            include_provenance: Attach provenance events for exported
                memory IDs.
            output_format: ``"json"`` (default, returns dict) or
                ``"msgpack"`` (returns bytes; requires ``msgpack``).

        Returns:
            Dict bundle when ``output_format="json"``, bytes when
            ``"msgpack"``.

        Raises:
            ValueError: If both ``kinds=`` and ``event_types=`` are
                provided.
        """
        import re as _re

        import wisdom_layer as _wl

        self._agent._require_feature("provenance", "Pro")

        effective_kinds = _resolve_kinds_alias(
            kinds=kinds, event_types=event_types
        )

        memories = await self._agent._backend.export_memories(
            agent_id=self._agent._agent_id,
            include_session_memories=include_session_memories,
            tier_filter=tier_filter,
        )

        if effective_kinds is not None:
            kinds_set = set(effective_kinds)
            memories = [
                m for m in memories if m.get("event_type") in kinds_set
            ]

        if redact is not None:
            memories = self._apply_redaction(memories, redact, _re)

        bundle: dict[str, object] = {
            "schema_version": 1,
            "sdk_version": _wl.__version__,
            "embedding_model": getattr(
                self._agent._backend, "_embedding_model_id", ""
            ),
            "agent_id": self._agent._agent_id,
            "exported_at": self._agent._clock.now().isoformat(),
            "count": len(memories),
            "memories": memories,
        }

        if include_provenance:
            prov_events: list[dict[str, Any]] = []
            for mem in memories:
                events = (
                    await self._agent._backend
                    .query_provenance_events_by_entity(
                        agent_id=self._agent._agent_id,
                        entity_id=mem["id"],
                    )
                )
                prov_events.extend(events)
            bundle["provenance_events"] = prov_events

        await self._agent._emit(
            "memory.exported",
            data={
                "count": len(memories),
                "redact_embeddings": redact_embeddings,
                "include_session_memories": include_session_memories,
                "tier_filter": tier_filter,
                "include_provenance": include_provenance,
                "output_format": output_format,
            },
        )

        if output_format == "msgpack":
            try:
                import msgpack
            except ImportError as exc:
                msg = (
                    "msgpack format requires the 'msgpack' package. "
                    "Install with: pip install msgpack"
                )
                raise ImportError(msg) from exc
            return bytes(msgpack.packb(bundle, use_bin_type=True))

        return bundle

    @staticmethod
    def _apply_redaction(
        memories: list[dict[str, Any]],
        redact: Any,
        _re: Any,
    ) -> list[dict[str, Any]]:
        """Apply redaction to memory content fields."""
        import json as _json

        def _redact_text(text: str) -> str:
            if callable(redact):
                return str(redact(text))
            for pattern in redact:
                text = _re.sub(pattern, "[REDACTED]", text)
            return text

        redacted: list[dict[str, Any]] = []
        for mem in memories:
            mem = dict(mem)
            content = mem.get("content")
            if isinstance(content, dict):
                mem["content"] = _json.loads(
                    _redact_text(_json.dumps(content, default=str))
                )
            elif isinstance(content, str):
                mem["content"] = _redact_text(content)
            redacted.append(mem)
        return redacted

    @sync_twin
    async def import_(
        self,
        data: dict[str, object],
        *,
        re_embed: bool = False,
        mode: str = "append",
    ) -> dict[str, object]:
        """Import memories from an exported bundle.

        Args:
            data: Export bundle (must have ``schema_version`` and
                ``memories`` keys).
            re_embed: If True, recompute embeddings for each memory
                using the current model instead of importing without
                embeddings.
            mode: Import strategy.

                * ``"append"`` — add to existing memories (default).
                * ``"replace"`` — delete all existing memories first.
                * ``"merge"`` — import then dedup against existing.

        Returns:
            Import report with ``imported``, ``skipped_duplicates``,
            ``skipped_invalid``, ``skipped_dim_mismatch``, and
            ``memory_ids``.

        Raises:
            MemoryFrozenError: If ``memory_mode`` is ``read_only``.
            ValueError: If ``schema_version`` is missing or unsupported.
        """
        if mode not in ("append", "replace", "merge"):
            msg = f"Invalid import mode '{mode}'. Must be 'append', 'replace', or 'merge'."
            raise ValueError(msg)

        self._agent._require_feature("provenance", "Pro")
        mem_mode = self._agent._config.lock.memory_mode
        if mem_mode == "read_only":
            raise MemoryFrozenError("import", mem_mode)

        if "schema_version" not in data:
            msg = "Export bundle missing required 'schema_version' field."
            raise ValueError(msg)

        schema_version = data["schema_version"]
        if schema_version not in (1,):
            msg = (
                f"Unsupported schema_version {schema_version}. "
                f"Supported versions: [1]."
            )
            raise ValueError(msg)

        bundle_model = data.get("embedding_model")
        backend_model = getattr(
            self._agent._backend, "_embedding_model_id", ""
        )
        if (
            bundle_model
            and backend_model
            and bundle_model != backend_model
            and not re_embed
        ):
            msg = (
                f"Embedding model mismatch: bundle uses '{bundle_model}' "
                f"but backend uses '{backend_model}'. "
                f"Pass re_embed=True to recompute embeddings."
            )
            raise ValueError(msg)

        bundle_sdk = data.get("sdk_version")
        if bundle_sdk and isinstance(bundle_sdk, str):
            import wisdom_layer as _wl

            current_major = _wl.__version__.split(".")[0]
            bundle_major = bundle_sdk.split(".")[0]
            if current_major != bundle_major:
                logger.warning(
                    "SDK major version mismatch on import",
                    extra={
                        "bundle_sdk_version": bundle_sdk,
                        "current_sdk_version": _wl.__version__,
                    },
                )

        raw_memories = data.get("memories", [])
        if not isinstance(raw_memories, list):
            msg = "Export bundle 'memories' must be a list."
            raise ValueError(msg)

        if mode == "replace":
            deleted = await self._agent._backend.delete_all_memories(
                agent_id=self._agent._agent_id,
            )
            logger.info(
                "Memories cleared for replace import",
                extra={
                    "agent_id": self._agent._agent_id,
                    "deleted": deleted,
                },
            )

        force_dedup = mode == "merge"
        return await self._agent._do_import(
            memories=raw_memories,
            re_embed=re_embed or force_dedup,
        )

    @sync_twin
    async def run_decay_pass(self) -> dict[str, object]:
        """Run a single deterministic decay pass over all memories.

        Explicit-only — never called from capture, search, or respond
        paths. The caller decides when to invoke decay.

        Performs rescore → archive OR weaken (mutually exclusive per
        memory). Immune memories (high emotional intensity or exempt
        event types) are rescored but never weakened or archived.

        Blocked by ``freeze_decay=True`` in LockConfig — salience
        decay is disabled even though the method is available.

        Returns:
            Dict with ``rescored``, ``weakened``, ``archived``,
            ``skipped_immune``, ``total_examined``, and ``event_id``.

        Raises:
            TierRestrictionError: If the current tier lacks ``dream_cycles``.
            MemoryFrozenError: If ``memory_mode`` is ``read_only`` or
                ``append_only``, or if ``freeze_decay`` is ``True``.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        mode = self._agent._config.lock.memory_mode
        if mode != "learning":
            raise MemoryFrozenError("run_decay_pass", mode)
        if self._agent._config.lock.freeze_decay:
            raise MemoryFrozenError("run_decay_pass", "freeze_decay")

        result = await self._agent._backend.run_decay_pass(
            agent_id=self._agent._agent_id,
            admin_defaults=self._agent._admin,
        )

        event = await self._agent._emit_returning(
            "memory.decay_pass_completed",
            data={
                "rescored": result["rescored"],
                "weakened": result["weakened"],
                "archived": result["archived"],
                "skipped_immune": result["skipped_immune"],
                "total_examined": result["total_examined"],
            },
            entity_type="agent",
            entity_id=self._agent._agent_id,
        )

        return {
            **result,
            "event_id": event.data["event_id"],
        }

    @sync_twin
    async def prune_expired_sessions(self) -> dict[str, object]:
        """Delete session-scoped memories whose TTL has expired.

        Unconditional — runs even when ``freeze_decay=True`` because
        session TTL is a hard contract, not a decay heuristic.
        Explicit-only — never called automatically.

        Returns:
            Dict with ``pruned_count``, ``pruned_ids``, and ``event_id``.

        Raises:
            TierRestrictionError: If the current tier lacks ``dream_cycles``.
            MemoryFrozenError: If ``memory_mode`` is ``read_only`` or
                ``append_only``.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        mode = self._agent._config.lock.memory_mode
        if mode != "learning":
            raise MemoryFrozenError("prune_expired_sessions", mode)

        result = await self._agent._backend.prune_expired_sessions(
            agent_id=self._agent._agent_id,
        )

        event = await self._agent._emit_returning(
            "memory.session_pruned",
            data={
                "pruned_count": result["pruned_count"],
                "pruned_ids": result["pruned_ids"],
            },
            entity_type="agent",
            entity_id=self._agent._agent_id,
        )

        return {
            "pruned_count": result["pruned_count"],
            "pruned_ids": result["pruned_ids"],
            "event_id": event.data["event_id"],
        }

    @sync_twin
    async def delete(self, memory_id: str) -> DeleteReport:
        """Hard-delete a single memory by id.

        Args:
            memory_id: The memory to delete.

        Returns:
            DeleteReport with deletion count and event_id.

        Raises:
            MemoryFrozenError: If ``memory_mode`` is ``read_only`` or
                ``append_only``.
        """
        mode = self._agent._config.lock.memory_mode
        if mode != "learning":
            raise MemoryFrozenError("delete", mode)

        deleted = await self._agent._backend.delete_memory(
            agent_id=self._agent._agent_id,
            memory_id=memory_id,
        )
        event = await self._agent._emit_returning(
            "memory.deleted",
            data={
                "memory_id": memory_id,
                "deleted": deleted,
            },
            entity_type="memory",
            entity_id=memory_id,
        )
        return DeleteReport(
            deleted=deleted,
            per_table={"memories": deleted},
            agent_id=self._agent._agent_id,
            event_id=event.data["event_id"],
        )

    async def reembed(
        self,
        *,
        batch_size: int = 100,
    ) -> Any:
        """Re-embed all memories using the current embedding model.

        Walks every memory whose ``embedding_model_id`` differs from
        the backend's current model, recomputes the embedding, and
        writes it back. Yields progress dicts for monitoring.

        Usage::

            async for progress in agent.memory.reembed():
                print(f"Batch {progress['batch']}: {progress['processed']} done")

        Args:
            batch_size: Number of memories per batch.

        Yields:
            Dict with ``batch``, ``processed``, ``updated``, ``failed``.
        """
        import json as _json

        self._agent._require_feature("provenance", "Pro")
        mode = self._agent._config.lock.memory_mode
        if mode == "read_only":
            raise MemoryFrozenError("reembed", mode)

        embed_fn = getattr(self._agent._backend, "_embed_fn", None)
        if embed_fn is None:
            msg = "No embedding function configured on the backend."
            raise ValueError(msg)

        model_id: str = getattr(
            self._agent._backend, "_embedding_model_id", "",
        )
        embed_dim: int = getattr(
            self._agent._backend, "_embedding_dim", 384,
        )

        batch_num = 0
        total_processed = 0
        total_updated = 0

        while True:
            batch = await self._agent._backend.iter_memories_for_reembed(
                agent_id=self._agent._agent_id,
                current_model_id=model_id,
                batch_size=batch_size,
                offset=0,
            )
            if not batch:
                break

            batch_num += 1
            batch_updated = 0
            batch_failed = 0

            for mem in batch:
                total_processed += 1
                try:
                    content_str = _json.dumps(
                        mem["content"], default=str,
                    )
                    vec = await embed_fn(content_str)
                    if len(vec) != embed_dim:
                        batch_failed += 1
                        continue

                    updated = (
                        await self._agent._backend
                        .update_memory_embedding(
                            agent_id=self._agent._agent_id,
                            memory_id=mem["id"],
                            embedding=vec,
                            embedding_model_id=model_id,
                            embedding_dim=embed_dim,
                        )
                    )
                    if updated:
                        batch_updated += 1
                        total_updated += 1
                        await self._agent._emit(
                            "memory.reembedded",
                            priority=EventPriority.DEBUG,
                            data={
                                "memory_id": mem["id"],
                                "model_id": model_id,
                            },
                            entity_type="memory",
                            entity_id=mem["id"],
                        )
                except Exception:
                    batch_failed += 1
                    logger.exception(
                        "Re-embed failed for memory",
                        extra={
                            "memory_id": mem["id"],
                            "agent_id": self._agent._agent_id,
                        },
                    )

            yield {
                "batch": batch_num,
                "processed": total_processed,
                "updated": total_updated,
                "batch_updated": batch_updated,
                "batch_failed": batch_failed,
            }

            if len(batch) < batch_size:
                break

        logger.info(
            "Re-embed complete",
            extra={
                "agent_id": self._agent._agent_id,
                "total_processed": total_processed,
                "total_updated": total_updated,
                "model_id": model_id,
            },
        )

    @sync_twin
    async def delete_session(self, session_id: str) -> DeleteReport:
        """Hard-delete all memories tagged with ``session_id``.

        Args:
            session_id: The session whose memories to purge.

        Returns:
            DeleteReport with deletion count and event_id.

        Raises:
            MemoryFrozenError: If ``memory_mode`` is ``read_only`` or
                ``append_only``.
        """
        mode = self._agent._config.lock.memory_mode
        if mode != "learning":
            raise MemoryFrozenError("delete_session", mode)

        deleted = await self._agent._backend.delete_session_memories(
            agent_id=self._agent._agent_id,
            session_id=session_id,
        )
        event = await self._agent._emit_returning(
            "memory.session_deleted",
            data={
                "session_id": session_id,
                "deleted": deleted,
            },
            entity_type="memory",
            entity_id=session_id,
        )
        return DeleteReport(
            deleted=deleted,
            per_table={"memories": deleted},
            agent_id=self._agent._agent_id,
            event_id=event.data["event_id"],
        )

    @sync_twin
    async def delete_all(self) -> DeleteReport:
        """Full erasure of all data for this agent.

        Returns:
            DeleteReport with per-table deletion counts and event_id.

        Raises:
            MemoryFrozenError: If ``memory_mode`` is ``read_only`` or
                ``append_only``.
        """
        mode = self._agent._config.lock.memory_mode
        if mode != "learning":
            raise MemoryFrozenError("delete_all", mode)

        counts = await self._agent._backend.delete_all_for_agent(
            agent_id=self._agent._agent_id,
        )
        total = sum(counts.values())
        event = await self._agent._emit_returning(
            "memory.agent_deleted",
            priority=EventPriority.CRITICAL,
            data={
                "per_table": counts,
                "total_deleted": total,
            },
            entity_type="agent",
            entity_id=self._agent._agent_id,
        )
        return DeleteReport(
            deleted=total,
            per_table=counts,
            agent_id=self._agent._agent_id,
            event_id=event.data["event_id"],
        )

    @sync_twin
    async def share(
        self,
        memory_id: str,
        *,
        visibility: Visibility = Visibility.TEAM,
        reason: str = "",
    ) -> str:
        """Promote one of *this agent's* memories into the workspace pool.

        Bridge between the per-agent backend (where the memory lives) and
        the workspace's :class:`SharedMemoryPool` (where it becomes
        visible to other agents). The id-based contract — not
        object-based — preserves the patent-defensible isolation
        invariant: callers never hand a private memory dict around the
        SDK; they reference an id that this method tenant-checks against
        the agent's own backend before promotion.

        The bridge enforces three things at the boundary:

        1. **Workspace registration.** The agent must have been registered
           to a workspace via :meth:`Workspace.register_agent`. Calling
           ``share()`` on an unregistered agent raises
           :class:`RuntimeError` pointing at the fix.
        2. **Tenancy guard.** ``memory_id`` must belong to this agent.
           The bridge calls :meth:`BaseBackend.get_memories_by_ids` with
           ``agent_id=self._agent.agent_id`` so an attempt to share
           another agent's memory id (collision or attack) returns an
           empty row list and the bridge raises :class:`ValueError`. The
           workspace pool is never touched in that case.
        3. **Idempotency.** The pool's ``promote()`` derives a
           deterministic ``shared_memory_id`` from
           ``(contributor_id, source_memory_id)``; re-sharing the same
           memory yields the same id and the backend's
           ``ON CONFLICT DO NOTHING`` collapses the duplicate. Safe to
           call repeatedly.

        Args:
            memory_id: The agent's own per-agent memory id. The
                workspace stores this as ``source_memory_id`` —
                an opaque back-reference that only the contributor
                (this agent) can dereference via
                ``agent.memory.get(memory_id)``. Compromising
                ``workspace.db`` never exposes the private content
                behind this id.
            visibility: ``TEAM`` (default — visible to all workspace
                agents) or ``PUBLIC`` (visible workspace-wide and
                surfaced regardless of contributor-exclusion filters).
                ``PRIVATE`` raises :class:`ValueError` at the pool
                boundary — by definition a memory in the pool is not
                private.
            reason: Free-form rationale ("why am I sharing this").
                Surfaces in dashboards and the cross-agent provenance
                log.

        Returns:
            The deterministic ``shared_memory_id`` (16-char hex) of the
            row in :class:`SharedMemoryPool`. Re-sharing the same
            ``memory_id`` returns the same id.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
                Fix: ``await workspace.register_agent(agent)``.
            ValueError: If ``memory_id`` does not exist in this agent's
                backend or belongs to another agent (tenancy guard
                rejection), or if ``visibility`` is
                :attr:`Visibility.PRIVATE`.
        """
        workspace = self._agent._workspace
        if workspace is None:
            raise RuntimeError(
                "Agent is not registered to a workspace. "
                "Call `await workspace.register_agent(agent)` before "
                "agent.memory.share(). Multi-agent features are "
                "Enterprise-tier; see Workspace docs.",
            )

        rows = await self._agent._backend.get_memories_by_ids(
            agent_id=self._agent._agent_id,
            memory_ids=[memory_id],
        )
        if not rows:
            raise ValueError(
                f"Memory {memory_id!r} does not exist in this agent's "
                "backend or belongs to another agent. Only the owning "
                "agent can share its own memories.",
            )
        row = rows[0]
        content = row.get("content")
        if not isinstance(content, str):
            # Memory rows historically store ``content`` as a JSON-encoded
            # string at the storage layer; the row dict is the
            # SDK-facing shape so a non-string here is a contract bug.
            content = "" if content is None else str(content)
        base_score_raw = row.get("salience", 0.0)
        try:
            base_score = float(base_score_raw)
        except (TypeError, ValueError):
            base_score = 0.0

        return await workspace.pool.promote(
            contributor_id=self._agent._agent_id,
            source_memory_id=memory_id,
            content=content,
            visibility=visibility,
            reason=reason,
            base_score=base_score,
        )


class DreamsInterface:
    """Public dream cycle API — configure, trigger, review."""

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent
        # Scheduler is lazily wired by WisdomAgent.initialize() so it can
        # reload persisted state before the background task starts.
        self._scheduler: DreamScheduler | None = None

    def configure(
        self,
        *,
        schedule: str | None = None,
        phases: list[str] | None = None,
        intensity: str | None = None,
    ) -> None:
        """Configure dream cycle parameters.

        Args:
            schedule: Cron expression for automatic cycles.
            phases: Ordered list of phases to execute.
            intensity: "light", "standard", or "deep".
        """
        self._agent._require_feature("dream_cycles", "Pro")
        if schedule is not None:
            self._agent._config.dreams.schedule = schedule
        if phases is not None:
            self._agent._config.dreams.phases = phases
        if intensity is not None:
            self._agent._config.dreams.intensity = intensity

    @sync_twin
    async def estimate_cost(
        self,
        *,
        depth: str | None = None,
        lookback_days: int = 14,
    ) -> Any:
        """Pre-flight estimate of the next dream cycle's cost.

        Thin wrapper over :meth:`CostInterface.estimate_dream` that
        defaults ``depth`` to the configured dream intensity.

        Raises:
            TierRestrictionError: current tier lacks ``cost_visibility``.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        effective_depth = depth or self._agent._config.dreams.intensity
        return await self._agent.cost.estimate_dream(
            depth=effective_depth,
            lookback_days=lookback_days,
        )

    @sync_twin
    async def resume_pending(self) -> dict[str, object] | None:
        """Check for and return a pending dream checkpoint.

        Returns:
            Checkpoint dict (``cycle_id``, ``last_completed_phase``,
            ``state_blob``, ``created_at``) if one exists, else ``None``.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        return await self._agent._backend.load_dream_checkpoint(
            agent_id=self._agent._agent_id,
        )

    #: The five canonical dream-cycle step names, in fixed execution order.
    #: Used for ``phases=`` validation in :meth:`trigger`.
    _VALID_PHASES: ClassVar[tuple[str, ...]] = (
        "reconsolidate",
        "evolve_directives",
        "critic_audit",
        "directive_decay",
        "journal_synthesis",
    )

    @sync_twin
    async def trigger(
        self,
        *,
        phases: Sequence[str] | None = None,
        lookback_days: int | None = None,
    ) -> dict[str, object]:
        """Execute a dream cycle: reconsolidate → evolve_directives → audit → decay → journal.

        Each step runs independently — failure in one step logs the error
        and continues to the next. No step depends on mutated in-memory
        state from a prior step; all inter-step data flows through the
        persisted backend.

        Args:
            phases: Optional subset of step names to run, in fixed order.
                Valid names: ``"reconsolidate"``, ``"evolve_directives"``,
                ``"critic_audit"``, ``"directive_decay"``,
                ``"journal_synthesis"``. ``None`` (default) runs all five.
                Useful for lightweight passes — e.g. ``phases=["reconsolidate"]``
                to consolidate without spending on directive evolution or
                journal synthesis.
            lookback_days: Optional time window restricting which raw
                memories the ``reconsolidate`` step considers. ``None``
                (default) preserves existing behavior — no time filter,
                consolidation ranks by reinforcement and salience over
                all candidates. Set this when importing historical data
                whose ``created_at`` was preserved with the migration
                shim, OR when you want the cycle to attend only to recent
                activity to bound LLM cost. Mirrors the parameter on
                :meth:`estimate_cost`. No-op for steps other than
                ``reconsolidate``.

        Returns:
            Dict with:

            - ``cycle_id``: unique ID for this dream run
            - ``started_at``: ISO 8601
            - ``completed_at``: ISO 8601
            - ``duration_ms``: int total cycle duration
            - ``status``: ``"success"`` | ``"partial"`` | ``"failed"``
            - ``summary``: multi-line narrative built from step results
            - ``steps``: list of step dicts, each with:
              - ``step_index``: int (0-based)
              - ``name``: str
              - ``status``: ``"success"`` | ``"failed"`` | ``"skipped"``
              - ``duration_ms``: int (may be 0 under FrozenClock)
              - ``error``: str or ``None``
              - ``reason``: str or ``None`` (for skipped steps)
              - ``result``: dict or ``None``
            - ``cost_breakdown``: list of per-phase cost dicts (best-effort)
            - ``total_tokens``: int sum of input + output tokens across phases
            - ``total_usd``: float sum of phase costs
            - ``total_duration_ms``: int alias of ``duration_ms``

        Raises:
            TierRestrictionError: If tier lacks ``dream_cycles`` feature.
            ValueError: If ``phases`` contains an unknown step name, is an
                empty sequence, or ``lookback_days`` is non-positive.
        """
        import logging
        import uuid

        _logger = logging.getLogger(__name__)

        self._agent._require_feature("dream_cycles", "Pro")

        # Validate phases= early so callers see a clean error before any
        # state mutation, event emission, or LLM cost.
        if phases is not None:
            phase_list = list(phases)
            if not phase_list:
                raise ValueError(
                    "phases= must be a non-empty sequence or None; "
                    "to skip the dream cycle, simply do not call trigger()."
                )
            unknown = [p for p in phase_list if p not in self._VALID_PHASES]
            if unknown:
                raise ValueError(
                    f"Unknown dream phase(s): {unknown}. "
                    f"Valid names are: {list(self._VALID_PHASES)}."
                )
            phase_set: set[str] | None = set(phase_list)
        else:
            phase_set = None

        if lookback_days is not None and lookback_days <= 0:
            raise ValueError(
                f"lookback_days must be positive; got {lookback_days}."
            )

        cycle_id = uuid.uuid4().hex[:12]
        started_at = self._agent._clock.now()
        self._agent._active_cycle_id = cycle_id

        await self._agent._emit(
            "dream.started",
            cycle_id=cycle_id,
            data={
                "cycle_id": cycle_id,
                "phases": list(phase_set) if phase_set else None,
                "lookback_days": lookback_days,
            },
            entity_type="dream_cycle",
            entity_id=cycle_id,
        )

        # --- Step definitions (fixed order) ---
        all_step_defs: list[tuple[str, Any]] = [
            ("reconsolidate", lambda: self._run_reconsolidate(lookback_days=lookback_days)),
            # closure binds cycle_id so _run_evolve_directives can query
            # insights produced in THIS cycle without changing the loop signature
            ("evolve_directives", lambda: self._run_evolve_directives(cycle_id)),
            ("critic_audit", self._run_critic_audit),
            ("directive_decay", self._run_directive_decay),
            ("journal_synthesis", self._run_journal_synthesis),
        ]
        step_defs = (
            [s for s in all_step_defs if s[0] in phase_set]
            if phase_set is not None
            else all_step_defs
        )

        steps: list[_DreamStepRecord] = []

        for step_index, (step_name, step_fn) in enumerate(step_defs):
            step_start = self._agent._clock.now()
            status: str = "success"
            error: str | None = None
            reason: str | None = None
            result: dict[str, Any] | None = None

            try:
                step_result = await step_fn()
                status = step_result["status"]
                error = step_result.get("error")
                reason = step_result.get("reason")
                result = step_result.get("result")
            except Exception as exc:
                status = "failed"
                error = str(exc)
                _logger.warning(
                    "Dream step failed",
                    extra={
                        "cycle_id": cycle_id,
                        "step": step_name,
                        "error": error,
                    },
                )

            step_end = self._agent._clock.now()
            duration_ms = int(
                (step_end - step_start).total_seconds() * 1000
            )

            await self._agent._emit(
                "dream.step_completed",
                cycle_id=cycle_id,
                data={
                    "cycle_id": cycle_id,
                    "step_index": step_index,
                    "step": step_name,
                    "status": status,
                },
                entity_type="dream_cycle",
                entity_id=cycle_id,
            )

            steps.append({
                "step_index": step_index,
                "name": step_name,
                "status": status,
                "duration_ms": duration_ms,
                "error": error,
                "reason": reason,
                "result": result,
            })

            # Checkpoint after each step (best-effort)
            try:
                import json as _json
                await self._agent._backend.save_dream_checkpoint(
                    cycle_id=cycle_id,
                    agent_id=self._agent._agent_id,
                    last_completed_phase=step_name,
                    state_blob=_json.dumps(steps),
                    created_at=self._agent._clock.now().isoformat(),
                )
            except Exception:
                _logger.debug(
                    "Dream checkpoint save failed",
                    extra={"cycle_id": cycle_id, "step": step_name},
                )

        # --- Derive overall status ---
        statuses = [s["status"] for s in steps]
        if all(s == "success" for s in statuses):
            overall_status = "success"
        elif all(s == "failed" for s in statuses):
            overall_status = "failed"
        else:
            overall_status = "partial"

        completed_at = self._agent._clock.now()

        await self._agent._emit(
            "dream.completed",
            cycle_id=cycle_id,
            data={
                "cycle_id": cycle_id,
                "status": overall_status,
                "step_count": len(steps),
            },
            entity_type="dream_cycle",
            entity_id=cycle_id,
        )

        duration_ms = int(
            (completed_at - started_at).total_seconds() * 1000
        )

        # --- Persist report (best-effort) ---
        try:
            await self._persist_report(
                cycle_id=cycle_id,
                started_at=started_at.isoformat(),
                completed_at=completed_at.isoformat(),
                status=overall_status,
                steps=steps,
                duration_ms=duration_ms,
            )
        except Exception:
            _logger.warning(
                "Dream report persistence failed",
                extra={"cycle_id": cycle_id},
            )

        # Clean up checkpoint on completion
        try:
            await self._agent._backend.delete_dream_checkpoint(
                cycle_id=cycle_id,
                agent_id=self._agent._agent_id,
            )
        except Exception:
            _logger.debug(
                "Dream checkpoint cleanup failed",
                extra={"cycle_id": cycle_id},
            )

        summary = self._build_dream_summary(steps=steps)

        # --- Aggregate cost_breakdown from the ledger (best-effort) ---
        cost_breakdown: list[dict[str, Any]] = []
        total_tokens = 0
        total_usd = 0.0
        try:
            rows = await self._agent._backend.sum_cost_by_cycle(
                agent_id=self._agent._agent_id,
                cycle_id=cycle_id,
            )
            # Map category → step duration for roll-up (best-effort).
            step_duration_by_category = {
                "dream.evolve_directives": next(
                    (int(s["duration_ms"]) for s in steps
                     if s.get("name") == "evolve_directives"), 0,
                ),
                "dream.critic_audit": next(
                    (int(s["duration_ms"]) for s in steps
                     if s.get("name") == "critic_audit"), 0,
                ),
                "dream.journal_synthesis": next(
                    (int(s["duration_ms"]) for s in steps
                     if s.get("name") == "journal_synthesis"), 0,
                ),
                "dream.reconsolidate": next(
                    (int(s["duration_ms"]) for s in steps
                     if s.get("name") == "reconsolidate"), 0,
                ),
            }
            for row in rows:
                entry = {
                    "phase": row["category"] or "dream.unknown",
                    "model": row["model_id"] or "",
                    "tokens_in": int(row["input_tokens"]),
                    "tokens_out": int(row["output_tokens"]),
                    "usd": float(row["cost_usd"]),
                    "duration_ms": int(
                        step_duration_by_category.get(row["category"] or "", 0)
                    ),
                    "calls": int(row["calls"]),
                }
                cost_breakdown.append(entry)
                total_tokens += int(entry["tokens_in"]) + int(entry["tokens_out"])
                total_usd += float(entry["usd"])
        except Exception:
            _logger.warning(
                "Dream cost_breakdown aggregation failed",
                extra={"cycle_id": cycle_id},
            )

        self._agent._active_cycle_id = None

        return {
            "cycle_id": cycle_id,
            "started_at": started_at.isoformat(),
            "completed_at": completed_at.isoformat(),
            "steps": steps,
            "status": overall_status,
            "duration_ms": duration_ms,
            "summary": summary,
            "cost_breakdown": cost_breakdown,
            "total_tokens": total_tokens,
            "total_usd": total_usd,
            "total_duration_ms": duration_ms,
        }

    @staticmethod
    def _build_dream_summary(*, steps: list[_DreamStepRecord]) -> str:
        """Build a human-readable narrative from dream step results.

        Reads each step's ``result`` dict to extract insight text,
        directive promotions, critic findings, and decay actions.
        Returns a multi-line string suitable for terminal display.

        Args:
            steps: The steps list from a dream trigger result.

        Returns:
            Multi-line narrative summarizing what the dream cycle produced.
        """
        lines: list[str] = []

        for step in steps:
            name = step.get("name")
            status = step.get("status")
            result = step.get("result") or {}

            if name == "reconsolidate":
                if status == "success" and result.get("insight"):
                    lines.append("Reconsolidated memories into insight:")
                    lines.append(f'  \u2192 "{result["insight"]}"')
                elif status == "success" and result.get("skipped"):
                    pass  # Not enough candidates — silent
                elif status == "failed":
                    lines.append("Reconsolidation: failed")

            elif name == "evolve_directives":
                if status == "success":
                    created = result.get("created", 0)
                    advisory = result.get("advisory", 0)
                    blocked = int(result.get("deduped", 0)) + int(
                        result.get("capacity_blocked", 0)
                    )
                    if created:
                        lines.append(
                            f"Evolved {created} new "
                            f"directive{'s' if created != 1 else ''} "
                            "from recent insights"
                        )
                    elif advisory:
                        lines.append(
                            f"Proposed {advisory} "
                            f"directive{'s' if advisory != 1 else ''} "
                            "for review (advisory mode)"
                        )
                    elif blocked:
                        lines.append(
                            f"No new directives created "
                            f"({blocked} blocked by dedup/capacity)"
                        )
                    else:
                        lines.append("No new directive patterns identified")
                elif status == "skipped":
                    reason = step.get("reason") or ""
                    # no_cycle_insights is normal operation (reconsolidate
                    # produced nothing) — silent, not actionable.
                    if reason != "no_cycle_insights":
                        lines.append(f"Directive evolution skipped ({reason})")
                elif status == "failed":
                    lines.append("Directive evolution: failed")

            elif name == "critic_audit":
                if status == "success":
                    contradictions = result.get("contradictions", [])
                    score = result.get("coherence_score")
                    n_contra = len(contradictions) if isinstance(
                        contradictions, list
                    ) else 0
                    if n_contra:
                        lines.append(
                            f"Critic flagged {n_contra} "
                            f"contradiction{'s' if n_contra != 1 else ''}"
                        )
                    elif score is not None:
                        lines.append(
                            f"Critic: coherent (score: {score})"
                        )
                elif status == "failed":
                    lines.append("Critic audit: failed")

            elif name == "directive_decay":
                if status == "success":
                    count = result.get("deactivated_count", 0)
                    if count:
                        lines.append(
                            f"Decayed {count} unused "
                            f"directive{'s' if count != 1 else ''}"
                        )
                elif status == "failed":
                    lines.append("Directive decay: failed")

            elif name == "journal_synthesis":
                if status == "success":
                    lines.append("Journal entry synthesized")
                elif status == "skipped":
                    pass  # Insufficient candidates — silent

        if not lines:
            return "Dream cycle completed (no notable changes)"

        return "\n".join(lines)

    # --- Dream step runners (private) ---

    async def _run_reconsolidate(
        self,
        *,
        lookback_days: int | None = None,
    ) -> _DreamStepResult:
        """Run the reconsolidate step."""
        result = await self._agent.memory.consolidate(lookback_days=lookback_days)
        return {"status": "success", "result": result}

    async def _run_critic_audit(self) -> _DreamStepResult:
        """Run the critic audit step."""
        result = await self._agent.critic.audit()
        return {"status": "success", "result": result}

    async def _run_directive_decay(self) -> _DreamStepResult:
        """Run the directive decay step."""
        result = await self._agent.directives.run_decay()
        return {"status": "success", "result": result}

    async def _run_journal_synthesis(self) -> _DreamStepResult:
        """Run the journal synthesis step (candidates → synthesize)."""
        min_memories = self._agent._admin.journal_min_memories

        candidates = await self._agent.journals.candidates()

        if len(candidates) < min_memories:
            return {
                "status": "skipped",
                "reason": "insufficient_candidates",
                "result": {"candidate_count": len(candidates)},
            }

        ids = [cast("str", c["id"]) for c in candidates]
        result = await self._agent.journals.synthesize(ids)
        return {"status": "success", "result": result}

    async def _run_evolve_directives(self, cycle_id: str) -> _DreamStepResult:
        """Run the evolve_directives step.

        Derives new provisional directives from insights produced in the
        current dream cycle. Respects governance gates before any LLM work.

        Args:
            cycle_id: The current dream cycle ID. Used to fetch only the
                insights produced in this cycle (not all historical insights).

        Returns:
            Step result dict with ``status`` and ``result``.
        """
        import json
        import logging

        from wisdom_layer._internal.evolution import (
            build_evolution_prompt,
            parse_evolution_output,
        )
        from wisdom_layer.errors import DirectiveCapacityError, DirectiveDuplicateError

        admin = self._agent._admin
        evolve_max = admin.dream_evolve_max_per_cycle
        evolve_temp = admin.dream_evolve_temperature

        _logger = logging.getLogger(__name__)

        _empty_result: dict[str, object] = {
            "proposed": 0,
            "created": 0,
            "advisory": 0,
            "deduped": 0,
            "capacity_blocked": 0,
            "diversity_blocked": 0,
            "domain_tags": [],
            "domain_counts": {},
            "generation_failed": False,
            "directive_ids": [],
            "source_insight_ids": [],
        }

        # Gate 1: directives feature disabled
        if not self._agent._config.feature_flags.directives:
            return {
                "status": "skipped",
                "reason": "feature_disabled",
                "result": dict(_empty_result),
            }

        # Gate 2: governance hard-lock
        mode = self._agent._config.lock.directive_evolution_mode
        if mode == "locked":
            return {
                "status": "skipped",
                "reason": "governance_locked",
                "result": dict(_empty_result),
            }

        # Gate 3: dream-step toggle
        if not self._agent._config.dreams.evolve_directives:
            return {
                "status": "skipped",
                "reason": "step_disabled",
                "result": dict(_empty_result),
            }

        # Gate 4: require insights from this cycle
        raw_insights = await self._agent._backend.get_cycle_insights(
            agent_id=self._agent._agent_id,
            cycle_id=cycle_id,
        )
        if not raw_insights:
            return {
                "status": "skipped",
                "reason": "no_cycle_insights",
                "result": dict(_empty_result),
            }

        insights = [
            {"id": r["id"], "text": json.loads(r["content"])["insight"]}
            for r in raw_insights
        ]
        source_insight_ids = [i["id"] for i in insights]

        # Fetch active directives for context (to avoid restating existing rules)
        active_directives = await self._agent.directives.active()
        directive_texts = [cast("str", d["text"]) for d in active_directives]

        # LLM call
        system, messages = build_evolution_prompt(
            insights=insights,
            directives=directive_texts,
            max_per_cycle=evolve_max,
            style_guidance=admin.dream_evolve_style_guidance,
        )
        try:
            response = await self._agent._retryable_generate(
                system=system,
                messages=messages,
                temperature=evolve_temp,
            )
        except Exception as exc:
            _logger.warning(
                "evolve_directives LLM call failed",
                extra={"error": str(exc)},
            )
            return {
                "status": "failed",
                "error": str(exc),
                "result": {**_empty_result, "generation_failed": True},
            }
        await self._agent._record_llm_usage(
            category="dream.evolve_directives",
            cycle_id=cycle_id,
            purpose="evolve_directives",
        )

        proposals = parse_evolution_output(
            response,
            insight_ids={i["id"] for i in insights},
        )[:evolve_max]

        # Fix C: tighter dedup + diversity pressure during the dream cycle.
        # ``directives.add()`` enforces the contractual 0.95 dedup
        # threshold; here we apply a stricter 0.85 floor against active
        # directives to catch paraphrased clones the LLM tends to emit
        # in batches, and we tag each proposal with a domain so we can
        # cap the per-domain count for this cycle. Both checks are
        # advisory at the dream-step layer — anything that survives
        # still goes through the regular ``add()`` validation.
        from wisdom_layer._internal.directive_taxonomy import (
            DOMAIN_GENERAL,
            EVOLVE_DEDUP_THRESHOLD,
            EVOLVE_MAX_PER_DOMAIN,
            classify_directive_domain,
        )

        backend = self._agent._backend
        embed_fn = backend._embed_fn  # type: ignore[attr-defined]

        created_ids: list[str] = []
        advisory_count: int = 0
        deduped: int = 0
        capacity_blocked: int = 0
        diversity_blocked: int = 0
        domain_counts: dict[str, int] = {}
        domain_tags: list[str] = []

        for proposal in proposals:
            text = proposal["text"]
            domain = classify_directive_domain(text)
            domain_tags.append(domain)

            # Diversity pressure: cap per-domain proposals. ``general``
            # is exempt because it is a fallback bucket, not a coherent
            # topic.
            if (
                domain != DOMAIN_GENERAL
                and domain_counts.get(domain, 0) >= EVOLVE_MAX_PER_DOMAIN
            ):
                diversity_blocked += 1
                continue

            # Stricter pre-dedup at 0.85. Skipped when no embed_fn is
            # wired (text-only backends still get 0.95 exact-hash dedup
            # via ``directives.add`` itself).
            if embed_fn is not None:
                pre_embedding = await embed_fn(text)
                pre_id, _pre_sim = await backend.find_similar_directive(
                    agent_id=self._agent._agent_id,
                    embedding=pre_embedding,
                    threshold=EVOLVE_DEDUP_THRESHOLD,
                )
                if pre_id is not None:
                    deduped += 1
                    continue

            try:
                add_result = await self._agent.directives.add(text)
                if "directive_id" in add_result:
                    created_ids.append(str(add_result["directive_id"]))
                    domain_counts[domain] = domain_counts.get(domain, 0) + 1
                elif "proposal_id" in add_result:
                    advisory_count += 1
                    domain_counts[domain] = domain_counts.get(domain, 0) + 1
            except DirectiveDuplicateError:
                deduped += 1
            except DirectiveCapacityError:
                capacity_blocked += 1
            except Exception as exc:
                _logger.warning(
                    "evolve_directives: directive add failed",
                    extra={
                        "text_preview": text[:60],
                        "error": str(exc),
                    },
                )

        result: dict[str, object] = {
            "proposed": len(proposals),
            "created": len(created_ids),
            "advisory": advisory_count,
            "deduped": deduped,
            "capacity_blocked": capacity_blocked,
            "diversity_blocked": diversity_blocked,
            "domain_tags": domain_tags,
            "domain_counts": domain_counts,
            "generation_failed": False,
            "directive_ids": created_ids,
            "source_insight_ids": source_insight_ids,
        }

        await self._agent._emit(
            "directive.evolution_completed",
            cycle_id=cycle_id,
            data=result,
            entity_type="dream_cycle",
            entity_id=cycle_id,
        )

        return {"status": "success", "result": result}

    # --- Persistence (private) ---

    async def _persist_report(
        self,
        *,
        cycle_id: str,
        started_at: str,
        completed_at: str,
        status: str,
        steps: list[_DreamStepRecord],
        duration_ms: int,
    ) -> None:
        """Validate and persist a dream report. Best-effort — logs on failure."""
        import json
        import logging
        import uuid

        from wisdom_layer._internal._invariants import DREAM_VALID_STATUSES

        _logger = logging.getLogger(__name__)
        max_steps_size = self._agent._admin.dream_max_steps_size

        # --- Validate status ---
        if status not in DREAM_VALID_STATUSES:
            _logger.warning(
                "Invalid dream report status, skipping persistence",
                extra={"cycle_id": cycle_id, "status": status},
            )
            return

        # --- Validate step schema ---
        required_step_keys = {
            "step_index", "name", "status", "duration_ms",
            "error", "reason", "result",
        }
        for step in steps:
            if not isinstance(step, dict) or set(step.keys()) != required_step_keys:
                _logger.warning(
                    "Invalid step schema, skipping persistence",
                    extra={"cycle_id": cycle_id, "step": step},
                )
                return

        # --- Serialize + cap ---
        steps_json = json.dumps(steps, default=str)
        if len(steps_json) > max_steps_size:
            _logger.warning(
                "Steps JSON exceeds size cap, truncating to empty",
                extra={
                    "cycle_id": cycle_id,
                    "size": len(steps_json),
                    "cap": max_steps_size,
                },
            )
            steps_json = "[]"

        report_id = uuid.uuid4().hex

        try:
            await self._agent._backend.store_dream_report(
                agent_id=self._agent._agent_id,
                report_id=report_id,
                cycle_id=cycle_id,
                started_at=started_at,
                completed_at=completed_at,
                status=status,
                steps=steps_json,
                duration_ms=duration_ms,
            )
        except Exception as exc:
            _logger.warning(
                "Failed to persist dream report",
                extra={"cycle_id": cycle_id, "error": str(exc)},
            )

    # --- Read methods ---

    @sync_twin
    async def get(self, cycle_id: str) -> dict[str, object] | None:
        """Retrieve a single dream report by ``cycle_id``.

        Args:
            cycle_id: The 12-char hex cycle identifier.

        Returns:
            Report dict or ``None`` if not found.

        Raises:
            TierRestrictionError: If tier lacks ``dream_cycles`` feature.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        return await self._agent._backend.get_dream_report(
            agent_id=self._agent._agent_id, cycle_id=cycle_id
        )

    @sync_twin
    async def history(self, *, limit: int = 30) -> list[dict[str, object]]:
        """Retrieve past dream cycle reports, most recent first.

        Ordering: ``started_at DESC, id DESC``.

        Args:
            limit: Maximum reports to return.

        Returns:
            List of dream report dicts.

        Raises:
            TierRestrictionError: If tier lacks ``dream_cycles`` feature.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        return await self._agent._backend.get_dream_history(
            agent_id=self._agent._agent_id, limit=limit
        )

    # -- Scheduling (v0.5 Phase 1) ------------------------------------------

    def _require_scheduler(self) -> DreamScheduler:
        """Return the scheduler; raise if not yet wired.

        The scheduler is created in ``WisdomAgent.initialize`` so that it
        can restore persisted state before accepting mutations.
        """
        if self._scheduler is None:
            raise RuntimeError(
                "Dream scheduler is not available until after "
                "`await agent.initialize()`."
            )
        return self._scheduler

    @sync_twin
    async def schedule(
        self,
        *,
        interval_hours: float,
        at: time | None = None,
        ignore_budget: bool = False,
    ) -> ScheduleStatus:
        """Register a recurring dream cycle.

        Args:
            interval_hours: Cadence of the recurring run, in hours. Must
                be positive. When ``at`` is set, must divide 24 evenly
                (allowed values: 1, 2, 3, 4, 6, 8, 12, 24).
            at: Optional UTC time-of-day anchor. ``at=time(3, 0)`` means
                the scheduler fires at 03:00 UTC on the ``interval_hours``
                grid starting from that anchor. When ``None``, the next
                run is simply ``interval_hours`` after the last run.
            ignore_budget: When True, scheduled runs bypass the
                ``BudgetGuard`` pre-flight check. Logs a warning on set;
                intended for testing.

        Returns:
            The :class:`ScheduleStatus` reflecting the new schedule.

        Raises:
            TierRestrictionError: If tier lacks ``scheduled_dreams`` feature.
            FeatureDisabledError: If ``FeatureFlags.scheduled_dreams`` is False.
            ValueError: If ``interval_hours`` is non-positive or
                incompatible with ``at``.
        """
        self._agent._require_feature("scheduled_dreams", "Pro")
        return await self._require_scheduler().schedule(
            interval_hours=interval_hours,
            at_time=at,
            ignore_budget=ignore_budget,
        )

    @sync_twin
    async def pause(self) -> ScheduleStatus:
        """Pause the current schedule without unscheduling it.

        A paused schedule keeps its ``next_run`` but the background
        task skips all fires until :meth:`resume` is called.
        """
        self._agent._require_feature("scheduled_dreams", "Pro")
        return await self._require_scheduler().pause()

    @sync_twin
    async def resume(self) -> ScheduleStatus:
        """Resume a paused schedule.

        If ``next_run`` is in the past (the schedule was paused through
        its firing window), it advances to the next slot so the
        scheduler does not fire immediately on resume.
        """
        self._agent._require_feature("scheduled_dreams", "Pro")
        return await self._require_scheduler().resume()

    @sync_twin
    async def unschedule(self) -> ScheduleStatus:
        """Clear the schedule entirely.

        Deletes the persisted row; the background task keeps running
        (cheaply, polling) in case a new schedule is installed.
        """
        self._agent._require_feature("scheduled_dreams", "Pro")
        return await self._require_scheduler().unschedule()

    @property
    def next_run(self) -> datetime | None:
        """Next scheduled dream firing time, or ``None`` if unscheduled."""
        if self._scheduler is None:
            return None
        return self._scheduler.next_run

    @property
    def last_run(self) -> datetime | None:
        """Most recent scheduled dream firing time, or ``None``."""
        if self._scheduler is None:
            return None
        return self._scheduler.last_run

    def schedule_status(self) -> ScheduleStatus:
        """Return a structured snapshot of the schedule state."""
        if self._scheduler is None:
            return ScheduleStatus(state="unscheduled")
        return self._scheduler.status()


class CriticInterface:
    """Public critic API — evaluate, review history, audit.

    Phase C Slice 1 ships ``evaluate()``, ``reviews()``, and
    ``get_review()``. ``audit()`` remains a stub for a future slice.

    ``evaluate()`` is strictly advisory — it returns a structured review
    but never blocks, vetoes, or mutates directives. ``pass_through`` is
    derived deterministically from ``risk_level``: ``none`` or ``low``
    → ``True``, everything else → ``False``.

    Flags are validated against ``CRITIC_FLAG_TAXONOMY`` (v1 fixed set).
    Unknown flags from the LLM are silently dropped.

    If the LLM call fails or returns invalid output, a safe default
    review is returned (``risk_level="high"``, ``pass_through=False``).
    """

    #: JSON schema for LLM structured output. ``pass_through`` is NOT
    #: requested from the LLM — it is derived deterministically from
    #: ``risk_level`` after the call.
    _REVIEW_SCHEMA: dict[str, object] = {
        "type": "object",
        "properties": {
            "risk_level": {
                "type": "string",
                "enum": ["none", "low", "medium", "high", "critical"],
            },
            "flags": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Identified concerns from: drift, contradiction, "
                    "safety, tone, scope, hallucination, off_topic"
                ),
            },
            "rationale": {
                "type": "string",
                "description": "Brief explanation of the assessment.",
            },
        },
        "required": ["risk_level", "flags", "rationale"],
    }

    _SYSTEM_PROMPT: str = (
        "You are a behavioral critic for an AI agent. Your job is to "
        "assess whether a proposed output complies with the agent's "
        "active directives.\n\n"
        "Rules:\n"
        "- Evaluate the output ONLY against the provided directives.\n"
        "- If no directives are relevant, risk_level should be 'none'.\n"
        "- flags must come from: drift, contradiction, safety, tone, "
        "scope, hallucination, off_topic.\n"
        "- Be concise in your rationale (1-2 sentences).\n"
        "- Err on the side of caution for safety concerns."
    )

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    @staticmethod
    def _derive_pass_through(risk_level: str) -> bool:
        """Deterministically derive pass_through from risk_level."""
        return risk_level in ("none", "low")

    @sync_twin
    async def evaluate(
        self,
        output: str,
        *,
        context: dict[str, object] | None = None,
    ) -> dict[str, object]:
        """Evaluate an agent output against active directives.

        Strictly advisory — returns a structured review but never
        blocks, vetoes, or mutates directives. Safe in all lock modes
        (reads directives only).

        ``pass_through`` is derived deterministically from
        ``risk_level``: ``none``/``low`` → ``True``, else ``False``.
        Flags are validated against ``CRITIC_FLAG_TAXONOMY``.

        If the LLM call fails or returns invalid output, a safe default
        review is returned (``risk_level="high"``, ``pass_through=False``).

        Args:
            output: The text to evaluate.
            context: Optional context dict for situational awareness.

        Returns:
            CriticReview dict with ``review_id``, ``risk_level``,
            ``flags``, ``rationale``, ``pass_through``, ``directive_ids``.
        """
        from wisdom_layer._internal._invariants import CRITIC_FLAG_TAXONOMY

        self._agent._require_feature("critic", "Pro")
        max_directives = self._agent._admin.critic_max_directives

        # 1. Read active directives (capped)
        all_directives = await self._agent._backend.list_directives(
            agent_id=self._agent._agent_id,
            include_inactive=False,
        )
        # Sort by usage_count descending, cap to critic_max_directives
        sorted_directives = sorted(
            all_directives,
            key=lambda d: d.get("usage_count", 0),
            reverse=True,
        )[:max_directives]

        directive_ids = [d["id"] for d in sorted_directives]

        # 2. Short-circuit if no directives
        if not sorted_directives:
            import uuid

            review_id = uuid.uuid4().hex[:12]
            now = self._agent._clock.now().isoformat()
            review: dict[str, object] = {
                "review_id": review_id,
                "risk_level": "none",
                "flags": [],
                "rationale": "No active directives to evaluate against.",
                "pass_through": True,
                "directive_ids": [],
            }
            await self._agent._backend.store_review(
                agent_id=self._agent._agent_id,
                review_id=review_id,
                output_text=output,
                context=context,
                risk_level="none",
                flags=[],
                rationale=cast("str", review["rationale"]),
                pass_through=True,
                directive_ids=[],
                created_at=now,
            )
            await self._agent._emit(
                "critic.review_completed",
                data={
                    "review_id": review_id,
                    "risk_level": "none",
                    "pass_through": True,
                    "flag_count": 0,
                },
                entity_type="critic_pass",
                entity_id=review_id,
            )
            return review

        # 3. Build prompt
        directive_block = "\n".join(
            f"- [{d['id']}] {d['text']}" for d in sorted_directives
        )
        context_block = ""
        if context:
            import json as _json

            context_block = f"\n\nCONTEXT:\n{_json.dumps(context, indent=2)}"

        user_message = (
            f"ACTIVE DIRECTIVES:\n{directive_block}\n\n"
            f"PROPOSED OUTPUT:\n{output}"
            f"{context_block}"
        )

        # 4. Call LLM (structured) — with failure safety
        risk_level: str
        flags: list[str]
        rationale: str

        try:
            llm_result = await self._agent._model.generate_structured(
                messages=[{"role": "user", "content": user_message}],
                system=self._SYSTEM_PROMPT,
                schema=self._REVIEW_SCHEMA,
                temperature=0.1,
            )
            await self._agent._record_llm_usage(
                category="critic.evaluate",
                purpose="critic_review",
            )

            # Validate risk_level
            raw_risk = llm_result.get("risk_level", "")
            valid_levels = {"none", "low", "medium", "high", "critical"}
            if raw_risk not in valid_levels:
                risk_level = "high"
                flags = []
                rationale = (
                    f"LLM returned invalid risk_level '{raw_risk}' "
                    "— treating as high risk."
                )
            else:
                risk_level = raw_risk
                # Validate flags against taxonomy
                raw_flags = llm_result.get("flags", [])
                if isinstance(raw_flags, list):
                    flags = [
                        f for f in raw_flags
                        if isinstance(f, str) and f in CRITIC_FLAG_TAXONOMY
                    ]
                else:
                    flags = []
                rationale = str(llm_result.get("rationale", ""))

        except Exception:
            # Safe default on any LLM failure
            logger.info(
                "Critic LLM call failed — returning safe default",
                extra={
                    "subsystem": "critic",
                    "agent_id": self._agent._agent_id,
                },
            )
            risk_level = "high"
            flags = []
            rationale = "Critic evaluation failed — treating as high risk."

        # 5. Derive pass_through deterministically
        pass_through = self._derive_pass_through(risk_level)

        # 6. Store review
        import uuid

        review_id = uuid.uuid4().hex[:12]
        now = self._agent._clock.now().isoformat()

        await self._agent._backend.store_review(
            agent_id=self._agent._agent_id,
            review_id=review_id,
            output_text=output,
            context=context,
            risk_level=risk_level,
            flags=flags,
            rationale=rationale,
            pass_through=pass_through,
            directive_ids=directive_ids,
            created_at=now,
        )

        # 7. Emit event
        await self._agent._emit(
            "critic.review_completed",
            data={
                "review_id": review_id,
                "risk_level": risk_level,
                "pass_through": pass_through,
                "flag_count": len(flags),
            },
            entity_type="critic_pass",
            entity_id=review_id,
        )

        result: dict[str, object] = {
            "review_id": review_id,
            "risk_level": risk_level,
            "flags": flags,
            "rationale": rationale,
            "pass_through": pass_through,
            "directive_ids": directive_ids,
        }

        # 8. Optional grounding pass (v1.0 Beta).
        # Opt-in via ``AdminDefaults.critic_verifies_grounding``. The
        # grounding result is appended to the returned dict so existing
        # callers see no shape change unless they read the new keys. A
        # contradiction detected here promotes ``risk_level`` to at least
        # "high" and forces ``pass_through=False`` — the agent has been
        # caught making an unsupported assertion against its own memory.
        if self._agent._admin.critic_verifies_grounding and has_feature(
            self._agent._tier, "grounding_verifier"
        ):
            grounding = await self._verify_grounding_internal(output)
            result["grounding"] = grounding
            contradicted_count = cast("int", grounding.get("contradicted_count", 0))
            if contradicted_count > 0:
                # Promote risk; the existing rationale stays first so logs
                # still reflect the directive evaluation, with a grounding
                # suffix appended for the audit trail.
                if risk_level not in ("high", "critical"):
                    result["risk_level"] = "high"
                result["pass_through"] = False
                result["rationale"] = (
                    f"{rationale} | Grounding: "
                    f"{contradicted_count} contradicted claim(s) vs. stored facts."
                )

        return result

    @sync_twin
    async def verify_grounding(self, output: str) -> dict[str, object]:
        """Verify a draft output's factual claims against the fact store.

        Extracts atomic claims from ``output`` and looks each one up
        against ``agent.facts``. Returns a structured grounding report
        the caller can use to decide whether to send the response,
        revise it, or surface the contradiction.

        Surface is deliberately separate from ``evaluate()`` so callers
        can run grounding without paying for the directive evaluation
        LLM call — useful for cheap pre-flight checks on responses that
        don't need behavioral review.

        Args:
            output: Draft response to verify.

        Returns:
            ``{"grounding_score": float, "verified": list, "unverified":
            list, "contradicted": list, "verified_count": int,
            "unverified_count": int, "contradicted_count": int,
            "claim_count": int, "verified_exact_count": int,
            "verified_semantic_count": int}``.

            Each per-claim entry in ``verified``, ``unverified``, and
            ``contradicted`` carries the underlying ``verify_claim``
            envelope — including ``match_source`` (``"exact"``,
            ``"semantic"``, or ``None``) and ``similarity`` (set when
            the claim was confirmed via the semantic fallback). The
            ``verified_exact_count`` / ``verified_semantic_count`` split
            is the audit drilldown for "verified 8/10 → 6 exact, 2
            semantic".

        Raises:
            TierRestrictionError: Caller's tier lacks
                ``grounding_verifier`` (Pro+).
        """
        self._agent._require_feature("grounding_verifier", "Pro")
        return await self._verify_grounding_internal(output)

    async def _verify_grounding_internal(
        self,
        output: str,
    ) -> dict[str, object]:
        """Shared grounding implementation — used by ``verify_grounding`` and ``evaluate``.

        Kept private so the public surface can carry the tier check and
        the ``evaluate`` hook can reuse it without re-checking the same
        feature flag the outer call already validated.
        """
        from wisdom_layer._internal.extraction import (
            build_claim_extraction_prompt,
            parse_claim_extraction_output,
        )

        admin = self._agent._admin
        max_claims = admin.grounding_max_claims

        system, messages = build_claim_extraction_prompt(
            output=output, max_claims=max_claims,
        )

        try:
            response = await self._agent._model.generate(
                system=system,
                messages=messages,
                temperature=0.1,
            )
            await self._agent._record_llm_usage(
                category="critic.grounding",
                purpose="claim_extraction",
            )
        except Exception:
            logger.info(
                "Grounding LLM call failed — returning empty grounding report",
                extra={
                    "subsystem": "critic",
                    "agent_id": self._agent._agent_id,
                },
            )
            return _empty_grounding_report()

        claims = parse_claim_extraction_output(response)
        if not claims:
            return _empty_grounding_report()

        verified: list[dict[str, object]] = []
        unverified: list[dict[str, object]] = []
        contradicted: list[dict[str, object]] = []

        for claim in claims:
            verdict = await self._agent.facts.verify_claim(
                subject=claim["subject"],
                attribute=claim["attribute"],
                expected_value=claim["value"],
            )
            entry = {**claim, **verdict}
            match_type = verdict.get("match_type")
            if match_type == "contradicts":
                contradicted.append(entry)
            elif match_type == "unknown":
                unverified.append(entry)
            else:  # exact, substring → verified
                verified.append(entry)

        total = len(claims)
        # Score: verified count out of total. Unverified neither helps
        # nor hurts beyond reducing the numerator — the agent is making
        # claims memory has no record of, which is informational, not
        # necessarily wrong. Contradictions hurt twice (subtracted from
        # numerator and emphasised in caller-visible counts).
        grounding_score = (
            (len(verified)) / total if total else 1.0
        )

        # Audit drilldown — split verified by which path confirmed
        # them. "Verified 8 / 10" reads more honestly as "6 exact, 2
        # semantic" when the semantic fallback fired.
        verified_exact = sum(
            1 for entry in verified if entry.get("match_source") == "exact"
        )
        verified_semantic = sum(
            1 for entry in verified if entry.get("match_source") == "semantic"
        )

        return {
            "grounding_score": grounding_score,
            "verified": verified,
            "unverified": unverified,
            "contradicted": contradicted,
            "verified_count": len(verified),
            "unverified_count": len(unverified),
            "contradicted_count": len(contradicted),
            "claim_count": total,
            "verified_exact_count": verified_exact,
            "verified_semantic_count": verified_semantic,
        }

    @sync_twin
    async def reviews(
        self,
        *,
        limit: int = 20,
        risk_level: str | None = None,
    ) -> list[dict[str, object]]:
        """Query stored critic reviews, most recent first.

        Args:
            limit: Maximum reviews to return.
            risk_level: If provided, filter to this level only.

        Returns:
            List of review dicts.
        """
        self._agent._require_feature("critic", "Pro")
        return await self._agent._backend.get_reviews(
            agent_id=self._agent._agent_id,
            limit=limit,
            risk_level=risk_level,
        )

    @sync_twin
    async def get_review(self, review_id: str) -> dict[str, object] | None:
        """Fetch a single critic review by ID.

        Args:
            review_id: The review to fetch.

        Returns:
            Review dict, or None if not found.
        """
        self._agent._require_feature("critic", "Pro")
        return await self._agent._backend.get_review(
            review_id,
            agent_id=self._agent._agent_id,
        )

    #: JSON schema for coherence audit LLM output.
    _COHERENCE_SCHEMA: dict[str, object] = {
        "type": "object",
        "properties": {
            "coherence_score": {
                "type": "number",
                "description": "0.0 (incoherent) to 1.0 (fully coherent).",
            },
            "contradictions": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "directive_a_id": {"type": "string"},
                        "directive_b_id": {"type": "string"},
                        "explanation": {"type": "string"},
                    },
                    "required": [
                        "directive_a_id",
                        "directive_b_id",
                        "explanation",
                    ],
                },
                "description": "Pairs of contradicting directives.",
            },
            "summary": {
                "type": "string",
                "description": "Brief coherence assessment (1-2 sentences).",
            },
        },
        "required": ["coherence_score", "contradictions", "summary"],
    }

    _COHERENCE_SYSTEM_PROMPT: str = (
        "You are a coherence auditor for an AI agent's directive set. "
        "Your job is to identify contradictions or tensions between "
        "active directives.\n\n"
        "Rules:\n"
        "- Assess whether any pair of directives contradicts or "
        "creates tension with another.\n"
        "- coherence_score: 1.0 = no contradictions, 0.0 = severe "
        "contradictions.\n"
        "- For each contradiction, provide the exact IDs of both "
        "directives (as shown in brackets) and a brief explanation.\n"
        "- If all directives are consistent, return coherence_score "
        "1.0 and an empty contradictions array.\n"
        "- Be concise in your summary (1-2 sentences)."
    )

    @sync_twin
    async def audit(self) -> dict[str, object]:
        """Check the active directive set for coherence.

        Reads active directives and uses a single structured LLM call
        to detect contradictions. Strictly advisory — no directive
        mutation, no proposal creation, no side effects.

        ``is_coherent`` is derived deterministically from
        ``coherence_score >= COHERENCE_THRESHOLD`` (0.6).
        ``coherence_score`` is clamped to [0.0, 1.0].
        Contradiction pairs are canonicalized (sorted) and deduplicated.

        Short-circuits with score=1.0 when ≤ 1 directive exists
        (no contradictions possible, no LLM call).

        If the LLM call fails: ``coherence_score=0.0``,
        ``is_coherent=False``, ``summary="Critic audit unavailable"``.

        Returns:
            AuditReport dict with ``audit_id``, ``coherence_score``,
            ``is_coherent``, ``contradictions``, ``summary``,
            ``directive_count``, ``directive_ids``.
        """
        import uuid

        self._agent._require_feature("critic", "Pro")
        admin = self._agent._admin
        max_directives = admin.critic_max_directives
        coherence_threshold = admin.coherence_threshold

        # 1. Read active directives (capped)
        all_directives = await self._agent._backend.list_directives(
            agent_id=self._agent._agent_id,
            include_inactive=False,
        )
        sorted_directives = sorted(
            all_directives,
            key=lambda d: d.get("usage_count", 0),
            reverse=True,
        )[:max_directives]

        directive_ids = [d["id"] for d in sorted_directives]
        valid_ids: set[str] = set(directive_ids)

        # 2. Short-circuit if ≤ 1 directive
        if len(sorted_directives) <= 1:
            audit_id = uuid.uuid4().hex[:12]
            now = self._agent._clock.now().isoformat()
            report: dict[str, object] = {
                "audit_id": audit_id,
                "coherence_score": 1.0,
                "is_coherent": True,
                "contradictions": [],
                "summary": (
                    "No contradictions possible with "
                    f"{len(sorted_directives)} directive(s)."
                ),
                "directive_count": len(sorted_directives),
                "directive_ids": directive_ids,
            }
            await self._agent._backend.store_audit(
                agent_id=self._agent._agent_id,
                audit_id=audit_id,
                coherence_score=1.0,
                is_coherent=True,
                contradictions=[],
                summary=cast("str", report["summary"]),
                directive_ids=directive_ids,
                directive_count=len(sorted_directives),
                created_at=now,
            )
            await self._agent._emit(
                "critic.audit_completed",
                data={
                    "audit_id": audit_id,
                    "coherence_score": 1.0,
                    "is_coherent": True,
                    "contradiction_count": 0,
                },
                entity_type="critic_pass",
                entity_id=audit_id,
            )
            return report

        # 3. Build prompt
        directive_block = "\n".join(
            f"- [{d['id']}] {d['text']}" for d in sorted_directives
        )
        user_message = (
            f"ACTIVE DIRECTIVES ({len(sorted_directives)}):\n"
            f"{directive_block}"
        )

        # 4. Call LLM (structured) — with failure safety
        coherence_score: float
        contradictions: list[dict[str, str]]
        summary: str

        try:
            llm_result = await self._agent._model.generate_structured(
                messages=[{"role": "user", "content": user_message}],
                system=self._COHERENCE_SYSTEM_PROMPT,
                schema=self._COHERENCE_SCHEMA,
                temperature=0.0,
            )
            await self._agent._record_llm_usage(
                category="dream.critic_audit"
                if self._agent._active_cycle_id
                else "critic.audit",
                purpose="coherence_audit",
            )

            # Validate + clamp coherence_score
            raw_score = llm_result.get("coherence_score")
            if isinstance(raw_score, (int, float)):
                coherence_score = max(0.0, min(1.0, float(raw_score)))
            else:
                coherence_score = 0.0

            summary = str(llm_result.get("summary", ""))

            # Validate contradictions — drop pairs with unknown IDs,
            # canonicalize order, deduplicate
            raw_contradictions = llm_result.get("contradictions", [])
            seen_pairs: set[tuple[str, str]] = set()
            contradictions = []

            if isinstance(raw_contradictions, list):
                for entry in raw_contradictions:
                    if not isinstance(entry, dict):
                        continue
                    a_id = str(entry.get("directive_a_id", ""))
                    b_id = str(entry.get("directive_b_id", ""))
                    explanation = str(entry.get("explanation", ""))

                    # Validate both IDs exist
                    if a_id not in valid_ids or b_id not in valid_ids:
                        continue

                    # Canonicalize: sorted order (2-tuple, not N-tuple)
                    sorted_pair = sorted((a_id, b_id))
                    canonical: tuple[str, str] = (sorted_pair[0], sorted_pair[1])
                    if canonical in seen_pairs:
                        continue
                    seen_pairs.add(canonical)

                    contradictions.append({
                        "directive_a_id": canonical[0],
                        "directive_b_id": canonical[1],
                        "explanation": explanation,
                    })

        except Exception:
            # Safe default on any LLM failure
            logger.info(
                "Critic audit LLM call failed — returning safe default",
                extra={
                    "subsystem": "critic",
                    "agent_id": self._agent._agent_id,
                },
            )
            coherence_score = 0.0
            contradictions = []
            summary = "Critic audit unavailable"

        # 5. Derive is_coherent deterministically
        is_coherent = coherence_score >= coherence_threshold

        # 6. Store audit
        audit_id = uuid.uuid4().hex[:12]
        now = self._agent._clock.now().isoformat()

        await self._agent._backend.store_audit(
            agent_id=self._agent._agent_id,
            audit_id=audit_id,
            coherence_score=coherence_score,
            is_coherent=is_coherent,
            contradictions=contradictions,
            summary=summary,
            directive_ids=directive_ids,
            directive_count=len(sorted_directives),
            created_at=now,
        )

        # 7. Emit event
        await self._agent._emit(
            "critic.audit_completed",
            data={
                "audit_id": audit_id,
                "coherence_score": coherence_score,
                "is_coherent": is_coherent,
                "contradiction_count": len(contradictions),
            },
            entity_type="critic_pass",
            entity_id=audit_id,
        )

        return {
            "audit_id": audit_id,
            "coherence_score": coherence_score,
            "is_coherent": is_coherent,
            "contradictions": contradictions,
            "summary": summary,
            "directive_count": len(sorted_directives),
            "directive_ids": directive_ids,
        }

    @sync_twin
    async def audits(
        self,
        *,
        limit: int = 20,
    ) -> list[dict[str, object]]:
        """Query stored coherence audits, most recent first.

        Args:
            limit: Maximum audits to return.

        Returns:
            List of audit dicts.
        """
        self._agent._require_feature("critic", "Pro")
        return await self._agent._backend.get_audits(
            agent_id=self._agent._agent_id,
            limit=limit,
        )

    @sync_twin
    async def get_audit(self, audit_id: str) -> dict[str, object] | None:
        """Fetch a single coherence audit by ID.

        Args:
            audit_id: The audit to fetch.

        Returns:
            Audit dict, or None if not found.
        """
        self._agent._require_feature("critic", "Pro")
        return await self._agent._backend.get_audit(
            audit_id,
            agent_id=self._agent._agent_id,
        )

    @sync_twin
    async def entropy(self) -> dict[str, object]:
        """Compute the directive entropy score — a point-in-time diagnostic.

        Pure arithmetic over directive metadata (counts, ages, usage).
        No LLM call, no persistence, no events emitted.

        Formula (doc 03 §"Directive Entropy Score")::

            entropy = churn * W_CHURN + volume * W_VOLUME + staleness * W_STALENESS

            churn     = changes_this_cycle / total_directives
            volume    = min(total_directives / VOLUME_CAP, 1.0)
            staleness = stale_count / total_directives

        Each component is clamped to [0.0, 1.0] before combining.
        The final score is clamped to [0.0, 1.0].

        ``changes_this_cycle`` counts unique directive IDs whose
        ``created_at`` falls within the last ``ENTROPY_CYCLE_HOURS``.
        ``stale_count`` counts directives with ``usage_count == 0``
        whose ``created_at`` is older than ``ENTROPY_STALE_DAYS``.

        Short-circuits with ``entropy_score=0.0``, ``level="healthy"``
        when there are zero directives.

        Returns:
            EntropyReport dict with ``entropy_score``, ``level``,
            ``components``, ``total_directives``, ``stale_count``,
            ``changes_count``, ``directive_ids``.
        """
        from datetime import timedelta

        self._agent._require_feature("critic", "Pro")
        admin = self._agent._admin

        # 1. Read active directives
        all_directives = await self._agent._backend.list_directives(
            agent_id=self._agent._agent_id,
            include_inactive=False,
        )

        total = len(all_directives)
        directive_ids = [d["id"] for d in all_directives]

        # 2. Short-circuit: no directives = no drift
        if total == 0:
            return {
                "entropy_score": 0.0,
                "level": "healthy",
                "components": {
                    "churn": 0.0,
                    "volume": 0.0,
                    "staleness": 0.0,
                },
                "total_directives": 0,
                "stale_count": 0,
                "changes_count": 0,
                "directive_ids": [],
            }

        # 3. Compute components using clock abstraction
        now = self._agent._clock.now()
        cycle_cutoff = now - timedelta(hours=admin.entropy_cycle_hours)
        stale_cutoff = now - timedelta(days=admin.entropy_stale_days)

        # changes_this_cycle: unique directive IDs created within
        # the cycle window
        changes_count = 0
        stale_count = 0
        seen_ids: set[str] = set()

        from datetime import datetime

        for d in all_directives:
            d_id = d["id"]
            created_str = d["created_at"]

            # Parse created_at — handle both aware and naive ISO strings
            if created_str.endswith("Z"):
                created_str = created_str[:-1] + "+00:00"
            created_at = datetime.fromisoformat(created_str)
            if created_at.tzinfo is None:
                created_at = created_at.replace(tzinfo=UTC)

            # Count unique changes in this cycle
            if created_at >= cycle_cutoff and d_id not in seen_ids:
                changes_count += 1
                seen_ids.add(d_id)

            # Count stale directives
            if d.get("usage_count", 0) == 0 and created_at < stale_cutoff:
                stale_count += 1

        # 4. Compute raw components
        raw_churn = changes_count / total
        raw_volume = min(total / admin.entropy_volume_cap, 1.0)
        raw_staleness = stale_count / total

        # 5. Clamp each component to [0.0, 1.0]
        churn = max(0.0, min(1.0, raw_churn))
        volume = max(0.0, min(1.0, raw_volume))
        staleness = max(0.0, min(1.0, raw_staleness))

        # 6. Combine with weights
        raw_score = (
            churn * admin.entropy_churn_weight
            + volume * admin.entropy_volume_weight
            + staleness * admin.entropy_staleness_weight
        )
        entropy_score = max(0.0, min(1.0, raw_score))

        # 7. Derive level
        if entropy_score < 0.3:
            level = "healthy"
        elif entropy_score < 0.6:
            level = "moderate"
        elif entropy_score < 0.8:
            level = "high"
        else:
            level = "alert"

        return {
            "entropy_score": entropy_score,
            "level": level,
            "components": {
                "churn": churn,
                "volume": volume,
                "staleness": staleness,
            },
            "total_directives": total,
            "stale_count": stale_count,
            "changes_count": changes_count,
            "directive_ids": directive_ids,
        }


class DirectivesInterface:
    """Public directives API — full Phase E CRUD with state machine.

    All retrieval methods are strictly read-only. Mutations (``add``,
    ``promote``, ``deactivate``, ``reinforce``, ``run_decay``) check
    tier access and are gated by ``LockConfig.directive_evolution_mode``:

    - ``"active"``: mutations execute directly (default).
    - ``"advisory"``: governable mutations (``add``, ``promote``,
      ``deactivate``) create proposals instead of executing.
      Autonomous mutations (``reinforce``, ``run_decay``) are blocked.
    - ``"locked"``: all mutations blocked with ``DirectiveLockedError``.

    State machine:
        provisional → active (via ``promote()``, requires usage_count ≥ 1)
        active → permanent (via ``promote()``)
        active → inactive (via ``deactivate()`` or ``run_decay()``)
        provisional → inactive (via ``deactivate()`` or ``run_decay()``)
        permanent → inactive (via ``deactivate()`` only — immune to decay)
    """

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    # --- Lock enforcement (follows memory_mode pattern) ---

    async def _check_directive_lock(self, method: str) -> str:
        """Check directive_evolution_mode and return the current mode.

        If locked, emits ``directive.write_blocked`` event and raises
        ``DirectiveLockedError``. Otherwise returns the mode string
        so callers can branch on ``"advisory"`` vs ``"active"``.
        """
        from wisdom_layer.errors import DirectiveLockedError

        mode = self._agent._config.lock.directive_evolution_mode
        if mode == "locked":
            await self._agent._emit(
                "directive.write_blocked",
                data={"method": method, "reason": "locked"},
            )
            raise DirectiveLockedError()
        return mode

    @sync_twin
    async def add(self, text: str) -> dict[str, object]:
        """Add a new directive.

        In ``active`` mode, creates a ``provisional`` directive directly.
        In ``advisory`` mode, creates a proposal instead.
        Both modes run capacity and dedup checks first.

        Args:
            text: Directive content.

        Returns:
            Dict that always carries an ``id`` key (canonical) plus a
            mode-specific alias for backward compatibility:

            - active mode  → ``{"id", "directive_id", "status"}``
            - advisory mode → ``{"id", "proposal_id", "mode", "action"}``

            Callers should prefer ``result["id"]`` when they only need
            the new entity's identifier and don't care which mode is
            active.

        Raises:
            DirectiveLockedError: If ``directive_evolution_mode`` is ``locked``.
            DirectiveCapacityError: At ``DIRECTIVE_MAX_VOLUME``.
            DirectiveDuplicateError: Semantic duplicate found (returns
                ``existing_id`` on the exception).
            TierRestrictionError: Feature not available at tier.
        """
        import hashlib
        import uuid

        from wisdom_layer._internal._invariants import DIRECTIVE_DEDUP_COSINE_THRESHOLD

        self._agent._require_feature("directive_evolution", "Pro")
        mode = await self._check_directive_lock("add")
        max_volume = self._agent._admin.directive_max_volume

        # 1. Capacity check (runs in both active and advisory modes)
        count = await self._agent._backend.count_active_directives(
            agent_id=self._agent._agent_id,
        )
        if count >= max_volume:
            raise DirectiveCapacityError(count, max_volume)

        # 2. Semantic dedup (if embeddings available)
        embedding: list[float] | None = None
        if self._agent._backend._embed_fn is not None:  # type: ignore[attr-defined]
            embedding = await self._agent._backend._embed_fn(text)  # type: ignore[attr-defined]
            existing_id, similarity = await self._agent._backend.find_similar_directive(
                agent_id=self._agent._agent_id,
                embedding=embedding,
                threshold=DIRECTIVE_DEDUP_COSINE_THRESHOLD,
            )
            if existing_id is not None:
                raise DirectiveDuplicateError(existing_id, similarity)

        content_hash = hashlib.sha256(text.strip().lower().encode()).hexdigest()

        # 3. Advisory mode → create proposal instead
        if mode == "advisory":
            proposal_id = uuid.uuid4().hex[:12]
            await self._agent._backend.store_proposal(
                agent_id=self._agent._agent_id,
                proposal_id=proposal_id,
                action="add",
                text=text,
                content_hash=content_hash,
                proposed_status="provisional",
            )
            await self._agent._emit(
                "directive.proposed",
                data={
                    "proposal_id": proposal_id,
                    "action": "add",
                    "content_preview": text[:200],
                },
                entity_type="directive",
                entity_id=proposal_id,
            )
            return {
                "id": proposal_id,
                "proposal_id": proposal_id,
                "mode": "advisory",
                "action": "add",
            }

        # 4. Active mode → store directive directly
        directive_id = uuid.uuid4().hex[:12]

        await self._agent._backend.store_directive(
            agent_id=self._agent._agent_id,
            directive_id=directive_id,
            text=text,
            content_hash=content_hash,
            status="provisional",
            embedding=embedding,
        )

        await self._agent._emit(
            "directive.added",
            data={
                "directive_id": directive_id,
                "content_preview": text[:200],
                "status": "provisional",
            },
            entity_type="directive",
            entity_id=directive_id,
        )

        return {
            "id": directive_id,
            "directive_id": directive_id,
            "status": "provisional",
        }

    @sync_twin
    async def get(self, directive_id: str) -> dict[str, object] | None:
        """Fetch a single directive by ID. Read-only.

        Available on the Free tier under the ``directive_view`` feature.
        Mutation methods (``add``, ``promote``, ``deactivate``, etc.)
        require ``directive_evolution`` (Pro/Enterprise).

        Args:
            directive_id: The directive to fetch.

        Returns:
            Directive dict, or ``None`` if not found.
        """
        self._agent._require_feature("directive_view", "Free")
        return await self._agent._backend.get_directive(
            agent_id=self._agent._agent_id,
            directive_id=directive_id,
        )

    @sync_twin
    async def active(self) -> list[dict[str, object]]:
        """List all non-inactive directives. Read-only.

        Returns provisional, active, and permanent directives. Available
        on the Free tier under the ``directive_view`` feature.
        """
        self._agent._require_feature("directive_view", "Free")
        return await self._agent._backend.list_directives(
            agent_id=self._agent._agent_id
        )

    @sync_twin
    async def all(self) -> list[dict[str, object]]:
        """List all directives including inactive. Read-only.

        Available on the Free tier under the ``directive_view`` feature.
        """
        self._agent._require_feature("directive_view", "Free")
        return await self._agent._backend.list_directives(
            agent_id=self._agent._agent_id,
            include_inactive=True,
        )

    @sync_twin
    async def relevant(
        self,
        query: str,
        *,
        limit: int = 5,
        min_similarity: float = 0.0,
        track_usage: bool = True,
    ) -> list[dict[str, object]]:
        """Search for directives relevant to a query.

        Returns directives ranked by cosine similarity to ``query``,
        optionally filtered by ``min_similarity`` to suppress weak
        matches. Inactive directives are always excluded; permanent,
        active, and provisional directives all participate.

        **Auto-tracking (v1.0.x):** when ``track_usage=True`` (default)
        and the agent has the ``directive_evolution`` feature with mode
        ``active``, ``usage_count`` is fire-and-forget incremented for
        every returned directive. This mirrors phoenix-core's render-time
        tracking and ensures the directive lifecycle (provisional →
        active → permanent) actually advances as directives are
        retrieved. Set ``track_usage=False`` for deterministic counter
        behavior in tests, or when the consumer prefers explicit
        ``reinforce()`` calls. Auto-tracking silently no-ops on Free
        tier or in ``advisory``/``locked`` modes — those callers see
        purely read-only behavior.

        Available on the Free tier under the ``directive_view`` feature.

        Args:
            query: Natural language query.
            limit: Maximum results.
            min_similarity: Floor for the cosine similarity score. Results
                below this are dropped. ``0.0`` (default) disables the
                filter entirely (preserves legacy behavior — even weakly
                or anti-similar matches are returned). Recommended values
                are in the 0.40–0.50 range for tighter relevance gating;
                0.45 is the value used by ``compose_context()``.
            track_usage: When ``True`` (default), fire-and-forget bumps
                ``usage_count`` for the returned directives. No effect on
                Free tier or in advisory/locked modes.

        Returns:
            List of directive dicts with ``similarity`` scores,
            ordered by relevance.
        """
        self._agent._require_feature("directive_view", "Free")

        if self._agent._backend._embed_fn is None:  # type: ignore[attr-defined]
            # Text fallback: substring match on directive text
            all_directives = await self._agent._backend.list_directives(
                agent_id=self._agent._agent_id,
            )
            query_lower = query.lower()
            matched = [
                {**d, "similarity": 1.0}
                for d in all_directives
                if query_lower in d.get("text", "").lower()
            ]
            results = matched[:limit]
            if track_usage and results:
                self._fire_and_forget_track_usage([r["id"] for r in results])
            return results

        # Semantic search via embeddings
        query_vec = await self._agent._backend._embed_fn(query)  # type: ignore[attr-defined]
        from wisdom_layer.storage.sqlite import _cosine_similarity, _unpack_embedding

        db = self._agent._backend._db()  # type: ignore[attr-defined]
        rows = db.execute(
            """SELECT id, agent_id, text, content_hash, status, priority,
                      usage_count, embedding, created_at, updated_at,
                      last_used, promoted_at
               FROM directives
               WHERE agent_id = ?
                 AND status != 'inactive'
                 AND embedding IS NOT NULL
                 AND embedding_model_id = ?
                 AND embedding_dim = ?""",
            (
                self._agent._agent_id,
                self._agent._backend._embedding_model_id,  # type: ignore[attr-defined]
                self._agent._backend._embedding_dim,  # type: ignore[attr-defined]
            ),
        ).fetchall()

        scored: list[tuple[float, dict[str, object]]] = []
        for row in rows:
            dir_vec = _unpack_embedding(row["embedding"])
            sim = _cosine_similarity(query_vec, dir_vec)
            if min_similarity > 0 and sim < min_similarity:
                continue
            scored.append((
                sim,
                {
                    "id": row["id"],
                    "text": row["text"],
                    "status": row["status"],
                    "usage_count": row["usage_count"],
                    "created_at": row["created_at"],
                    "similarity": round(sim, 4),
                },
            ))

        scored.sort(key=lambda x: x[0], reverse=True)
        results = [entry for _, entry in scored[:limit]]
        if track_usage and results:
            self._fire_and_forget_track_usage(
                [cast("str", r["id"]) for r in results]
            )
        return results

    def _fire_and_forget_track_usage(self, directive_ids: list[str]) -> None:
        """Schedule a non-blocking ``usage_count`` increment.

        Silently no-ops when the tier lacks ``directive_evolution`` or
        when ``directive_evolution_mode`` is ``advisory`` / ``locked`` —
        the caller is using ``relevant()`` for read access and we must
        not raise into a hot retrieval path. Errors during the
        background increment are logged at WARNING and swallowed.

        Pattern mirrors :meth:`MemoryAPI.search`'s async-after-return
        reinforcement (see :pep:`PEP-3156` ``ensure_future``).
        """
        if not has_feature(self._agent._tier, "directive_evolution"):
            return
        if self._agent._config.lock.directive_evolution_mode != "active":
            return

        from wisdom_layer.errors import BackendNotInitializedError

        agent = self._agent
        ids = list(directive_ids)

        async def _track() -> None:
            try:
                await agent._backend.increment_directive_usage(
                    agent_id=agent._agent_id,
                    directive_ids=ids,
                )
            except BackendNotInitializedError:
                # Backend closed mid-flight during shutdown — expected.
                return
            except Exception:
                logger.warning(
                    "Background directive usage tracking failed",
                    exc_info=True,
                    extra={
                        "subsystem": "agent.directives",
                        "agent_id": agent._agent_id,
                        "directive_count": len(ids),
                    },
                )

        task = asyncio.ensure_future(_track())
        # Reuse the agent's reinforce-task set so close() awaits it.
        agent._active_reinforce_tasks.add(task)
        task.add_done_callback(agent._active_reinforce_tasks.discard)

    @sync_twin
    async def compose_context(
        self,
        query: str,
        *,
        limit: int = 5,
        min_similarity: float = 0.45,
        track_usage: bool = True,
    ) -> dict[str, object]:
        """Build a structured prompt fragment for the current query.

        Implements the phoenix-core Hybrid Directive Retrieval pattern:
        permanent directives are always included (they encode the
        agent's stable identity), and active/provisional directives are
        relevance-filtered against ``query`` (they encode evolving
        guidance). The returned ``text`` block is ready to splice into
        a system prompt.

        Provisional directives are explicitly labeled as "*(provisional
        — under review)*" so the LLM weights them differently from
        active ones, and so a downstream eval judge can tell which
        guidance the consumer was tentatively trying.

        Auto-tracking semantics match :meth:`relevant`: every directive
        included in the returned block has its ``usage_count`` bumped
        fire-and-forget when ``track_usage=True`` and the tier/mode
        permit. ``relevant()`` is called internally with
        ``track_usage=False`` to avoid double-counting.

        Available on the Free tier under the ``directive_view`` feature.

        Args:
            query: The user message or task description.
            limit: Maximum number of contextual (active/provisional)
                directives to include. Permanent directives are not
                counted against this limit.
            min_similarity: Cosine similarity floor for contextual
                directives. Default 0.45 matches phoenix-core's tuning
                — high enough to suppress unrelated guidance, low
                enough to surface borderline matches.
            track_usage: When ``True``, fire-and-forget increments
                ``usage_count`` for every directive in the returned
                block (permanent + contextual + provisional).

        Returns:
            ``{"text": <formatted block>, "permanent": [...],
            "contextual": [...], "provisional": [...], "all_ids": [...]}``.
            Each directive entry includes ``id``, ``text``, ``status``,
            and (for contextual/provisional) ``similarity``.
        """
        self._agent._require_feature("directive_view", "Free")

        all_directives = await self._agent._backend.list_directives(
            agent_id=self._agent._agent_id,
        )
        permanent = [
            {"id": d["id"], "text": d["text"], "status": "permanent"}
            for d in all_directives
            if d.get("status") == "permanent"
        ]

        relevant = await self.relevant(
            query,
            limit=limit,
            min_similarity=min_similarity,
            track_usage=False,
        )
        contextual = [
            {
                "id": d["id"],
                "text": d["text"],
                "status": d["status"],
                "similarity": d.get("similarity"),
            }
            for d in relevant
            if d.get("status") == "active"
        ]
        provisional = [
            {
                "id": d["id"],
                "text": d["text"],
                "status": d["status"],
                "similarity": d.get("similarity"),
            }
            for d in relevant
            if d.get("status") == "provisional"
        ]

        # v1.0 Beta: optional facts slot. Only populated when the user
        # has opted in via ``enable_fact_extraction`` AND the tier carries
        # the feature. Free-tier callers and Pro callers who haven't
        # opted in see no behavior change — the returned dict still has
        # the ``facts`` key (always), but it's empty.
        facts: list[dict[str, object]] = []
        if (
            self._agent._admin.enable_fact_extraction
            and has_feature(self._agent._tier, "fact_extraction")
        ):
            facts = await self._collect_facts_for_context(query)

        sections: list[str] = []
        if permanent:
            sections.append(
                "## Core directives (always apply)\n"
                + "\n".join(f"- {d['text']}" for d in permanent)
            )
        if contextual:
            sections.append(
                "## Contextual directives (relevant to this query)\n"
                + "\n".join(f"- {d['text']}" for d in contextual)
            )
        if provisional:
            sections.append(
                "## Provisional directives (under review — apply only if clearly relevant)\n"
                + "\n".join(f"- {d['text']}" for d in provisional)
            )
        if facts:
            fact_lines = [_render_fact_line(f) for f in facts]
            sections.append(
                "## Known facts (verified — cite specific values when relevant to your response)\n"
                + "\n".join(fact_lines)
            )
        text = "\n\n".join(sections)

        all_ids = (
            [cast("str", d["id"]) for d in permanent]
            + [cast("str", d["id"]) for d in contextual]
            + [cast("str", d["id"]) for d in provisional]
        )
        if track_usage and all_ids:
            self._fire_and_forget_track_usage(all_ids)

        return {
            "text": text,
            "permanent": permanent,
            "contextual": contextual,
            "provisional": provisional,
            "facts": facts,
            "all_ids": all_ids,
        }

    async def _collect_facts_for_context(
        self,
        query: str,
    ) -> list[dict[str, object]]:
        """Fetch facts relevant to ``query``, dedup, trim to slot budget.

        Two correctness guarantees layered on top of raw search:

        * **Last-write-wins dedup** on ``(subject, attribute)``. The
          backend retains older rows for history; only the newest
          surfaces in the composed context so the LLM never sees both
          ``email = old@x`` and ``email = new@x`` in the same prompt.
          We sort by ``created_at DESC`` before dedup so the rule holds
          regardless of whether the backend ranked candidates by
          similarity or by recency.
        * **Slot budget** — stops once the next entry would push the
          rendered slot past ``AdminDefaults.facts_context_slot_chars``.

        Failures are swallowed — fact recall must never break context
        composition.
        """
        admin = self._agent._admin
        budget = admin.facts_context_slot_chars
        try:
            candidates = await self._agent._backend.search_facts(
                agent_id=self._agent._agent_id,
                query=query,
                limit=20,
            )
        except Exception:
            logger.debug(
                "compose_context: fact lookup failed; skipping facts slot",
                extra={"agent_id": self._agent._agent_id},
                exc_info=True,
            )
            return []

        # Dedup by (subject, attribute) keeping the newest. Sort newest-
        # first explicitly so the rule holds for both substring (newest-
        # first by SQL) and semantic (similarity-first) backends.
        candidates_by_recency = sorted(
            candidates,
            key=lambda f: str(f.get("created_at", "")),
            reverse=True,
        )
        seen: set[tuple[str, str]] = set()
        deduped: list[dict[str, object]] = []
        for fact in candidates_by_recency:
            key = (
                str(fact.get("subject", "")),
                str(fact.get("attribute", "")),
            )
            if key in seen:
                continue
            seen.add(key)
            deduped.append(fact)

        chosen: list[dict[str, object]] = []
        used = 0
        for fact in deduped:
            line_len = len(_render_fact_line(fact)) + 1  # newline overhead
            if used + line_len > budget and chosen:
                break
            chosen.append(fact)
            used += line_len
        return chosen

    @sync_twin
    async def promote(self, directive_id: str) -> dict[str, object]:
        """Promote a directive to the next lifecycle stage.

        - ``provisional`` → ``active`` (requires ``usage_count >= 1``)
        - ``active`` → ``permanent``

        In ``advisory`` mode, creates a proposal instead of executing.

        Args:
            directive_id: The directive to promote.

        Returns:
            Dict with ``directive_id``, ``old_status``, ``new_status``
            (active mode) or ``proposal_id``, ``mode``, ``action``
            (advisory mode).

        Raises:
            DirectiveLockedError: If ``directive_evolution_mode`` is ``locked``.
            ValueError: If directive not found, already permanent/inactive,
                or provisional with no usage signal.
        """
        self._agent._require_feature("directive_evolution", "Pro")
        mode = await self._check_directive_lock("promote")

        directive = await self._agent._backend.get_directive(
            agent_id=self._agent._agent_id,
            directive_id=directive_id,
        )
        if directive is None:
            msg = f"Directive '{directive_id}' not found."
            raise ValueError(msg)

        old_status = directive["status"]
        if old_status == "provisional":
            if directive.get("usage_count", 0) < 1:
                msg = (
                    f"Cannot promote provisional directive '{directive_id}': "
                    f"usage_count must be >= 1 (currently {directive.get('usage_count', 0)})."
                )
                raise ValueError(msg)
            new_status = "active"
            promoted_at = None
        elif old_status == "active":
            new_status = "permanent"
            promoted_at = self._agent._clock.now().isoformat()
        else:
            msg = (
                f"Cannot promote directive '{directive_id}': "
                f"status is '{old_status}' (must be 'provisional' or 'active')."
            )
            raise ValueError(msg)

        # Advisory mode → create proposal
        if mode == "advisory":
            import hashlib
            import uuid

            proposal_id = uuid.uuid4().hex[:12]
            text = directive.get("text", "")
            content_hash = hashlib.sha256(
                str(text).strip().lower().encode()
            ).hexdigest()

            await self._agent._backend.store_proposal(
                agent_id=self._agent._agent_id,
                proposal_id=proposal_id,
                action="promote",
                text=str(text),
                content_hash=content_hash,
                proposed_status=new_status,
                target_directive_id=directive_id,
            )
            await self._agent._emit(
                "directive.proposed",
                data={
                    "proposal_id": proposal_id,
                    "action": "promote",
                    "target_directive_id": directive_id,
                    "proposed_status": new_status,
                },
                entity_type="directive",
                entity_id=directive_id,
            )
            return {
                "proposal_id": proposal_id,
                "mode": "advisory",
                "action": "promote",
            }

        # Active mode → execute directly
        await self._agent._backend.update_directive_status(
            agent_id=self._agent._agent_id,
            directive_id=directive_id,
            new_status=new_status,
            promoted_at=promoted_at,
        )

        await self._agent._emit(
            "directive.promoted",
            data={
                "directive_id": directive_id,
                "from_status": old_status,
                "to_status": new_status,
            },
            entity_type="directive",
            entity_id=directive_id,
        )

        return {
            "directive_id": directive_id,
            "old_status": old_status,
            "new_status": new_status,
        }

    @sync_twin
    async def deactivate(self, directive_id: str) -> dict[str, object]:
        """Deactivate a directive (any non-inactive status → inactive).

        In ``advisory`` mode, creates a proposal instead of executing.

        Args:
            directive_id: The directive to deactivate.

        Returns:
            Dict with ``directive_id``, ``old_status``, ``new_status``
            (active mode) or ``proposal_id``, ``mode``, ``action``
            (advisory mode).

        Raises:
            DirectiveLockedError: If ``directive_evolution_mode`` is ``locked``.
            ValueError: If directive not found or already inactive.
        """
        self._agent._require_feature("directive_evolution", "Pro")
        mode = await self._check_directive_lock("deactivate")

        directive = await self._agent._backend.get_directive(
            agent_id=self._agent._agent_id,
            directive_id=directive_id,
        )
        if directive is None:
            msg = f"Directive '{directive_id}' not found."
            raise ValueError(msg)

        old_status = directive["status"]
        if old_status == "inactive":
            msg = f"Directive '{directive_id}' is already inactive."
            raise ValueError(msg)

        # Advisory mode → create proposal
        if mode == "advisory":
            import hashlib
            import uuid

            proposal_id = uuid.uuid4().hex[:12]
            text = directive.get("text", "")
            content_hash = hashlib.sha256(
                str(text).strip().lower().encode()
            ).hexdigest()

            await self._agent._backend.store_proposal(
                agent_id=self._agent._agent_id,
                proposal_id=proposal_id,
                action="deactivate",
                text=str(text),
                content_hash=content_hash,
                proposed_status="inactive",
                target_directive_id=directive_id,
            )
            await self._agent._emit(
                "directive.proposed",
                data={
                    "proposal_id": proposal_id,
                    "action": "deactivate",
                    "target_directive_id": directive_id,
                },
                entity_type="directive",
                entity_id=directive_id,
            )
            return {
                "proposal_id": proposal_id,
                "mode": "advisory",
                "action": "deactivate",
            }

        # Active mode → execute directly
        await self._agent._backend.update_directive_status(
            agent_id=self._agent._agent_id,
            directive_id=directive_id,
            new_status="inactive",
        )

        await self._agent._emit(
            "directive.revoked",
            data={
                "directive_id": directive_id,
                "from_status": old_status,
            },
            entity_type="directive",
            entity_id=directive_id,
        )

        return {
            "directive_id": directive_id,
            "old_status": old_status,
            "new_status": "inactive",
        }

    @sync_twin
    async def reinforce(self, directive_ids: list[str]) -> None:
        """Explicitly signal that directives were used/applied.

        Increments ``usage_count`` for the given directives. This is
        the only path that mutates usage tracking — ``relevant()`` is
        read-only.

        Autonomous mutation — blocked in both ``locked`` and ``advisory``
        modes (not proposable).

        Args:
            directive_ids: IDs of directives that were applied.

        Raises:
            DirectiveLockedError: If ``directive_evolution_mode`` is
                ``locked`` or ``advisory``.
        """
        self._agent._require_feature("directive_evolution", "Pro")
        mode = await self._check_directive_lock("reinforce")
        if mode == "advisory":
            await self._agent._emit(
                "directive.write_blocked",
                data={"method": "reinforce", "reason": "advisory"},
            )
            from wisdom_layer.errors import DirectiveLockedError

            raise DirectiveLockedError()

        await self._agent._backend.increment_directive_usage(
            agent_id=self._agent._agent_id,
            directive_ids=directive_ids,
        )

    @sync_twin
    async def run_decay(self) -> dict[str, object]:
        """Run directive decay: deactivate low-usage, old directives.

        Permanent directives are exempt. Only ``provisional`` and
        ``active`` directives with ``usage_count`` below threshold
        and age exceeding ``DIRECTIVE_DECAY_AGE_DAYS`` are deactivated.

        Autonomous mutation — blocked in both ``locked`` and ``advisory``
        modes (not proposable).

        Returns:
            Dict with ``deactivated_count``, ``deactivated_ids``,
            and ``event_id``.

        Raises:
            DirectiveLockedError: If ``directive_evolution_mode`` is
                ``locked`` or ``advisory``.
        """
        self._agent._require_feature("directive_evolution", "Pro")
        mode = await self._check_directive_lock("run_decay")
        if mode == "advisory":
            await self._agent._emit(
                "directive.write_blocked",
                data={"method": "run_decay", "reason": "advisory"},
            )
            from wisdom_layer.errors import DirectiveLockedError

            raise DirectiveLockedError()

        admin = self._agent._admin
        result = await self._agent._backend.run_directive_decay(
            agent_id=self._agent._agent_id,
            usage_threshold=admin.directive_decay_usage_threshold,
            age_days=admin.directive_decay_age_days,
        )

        event = await self._agent._emit_returning(
            "directive.decay_completed",
            data={
                "deactivated_count": result["deactivated_count"],
                "deactivated_ids": result["deactivated_ids"],
            },
            entity_type="agent",
            entity_id=self._agent._agent_id,
        )

        return {
            **result,
            "event_id": event.data["event_id"],
        }

    # --- Proposal API (Phase E Slice 2) ---

    @sync_twin
    async def proposals(self) -> list[dict[str, object]]:
        """List pending directive proposals. Read-only.

        Returns:
            List of pending DirectiveProposal records.
        """
        self._agent._require_feature("directive_evolution", "Pro")
        return await self._agent._backend.list_proposals(
            agent_id=self._agent._agent_id
        )

    @sync_twin
    async def approve(
        self,
        proposal_id: str,
        *,
        resolved_by: str = "",
    ) -> dict[str, object]:
        """Approve a directive proposal with constraint re-validation.

        Re-runs all constraints at approval time:

        - For ``add`` proposals: checks capacity and semantic dedup
          (embedding computed fresh, not stored on proposal).
        - For ``promote``/``deactivate`` proposals: validates target
          directive still exists and is in a valid state (handled
          atomically by the backend).

        Args:
            proposal_id: The proposal to approve.
            resolved_by: Structured JSON string describing who/what
                approved. Defaults to ``{"actor":"operator","method":"manual"}``.

        Returns:
            Dict with ``action``, ``directive_id``, ``status`` describing
            what was executed.

        Raises:
            DirectiveCapacityError: If an ``add`` proposal would exceed
                ``DIRECTIVE_MAX_VOLUME`` (checked fresh at approve time).
            DirectiveDuplicateError: If an ``add`` proposal's text is now
                a semantic duplicate (embedding computed fresh).
            ValueError: If proposal not found, already resolved, or
                target directive is in an invalid state.
        """
        import uuid

        from wisdom_layer._internal._invariants import DIRECTIVE_DEDUP_COSINE_THRESHOLD

        self._agent._require_feature("directive_evolution", "Pro")
        max_volume = self._agent._admin.directive_max_volume

        # Fetch proposal to determine action (for add-specific checks)
        proposal = await self._agent._backend.get_proposal(
            agent_id=self._agent._agent_id,
            proposal_id=proposal_id,
        )
        if proposal is None:
            msg = f"Proposal '{proposal_id}' not found."
            raise ValueError(msg)
        if proposal["status"] != "pending":
            msg = (
                f"Proposal '{proposal_id}' is already resolved "
                f"(status='{proposal['status']}')."
            )
            raise ValueError(msg)

        directive_id = uuid.uuid4().hex[:12]
        embedding: list[float] | None = None

        # Re-run constraints for "add" proposals at approval time
        if proposal["action"] == "add":
            # Capacity re-check
            count = await self._agent._backend.count_active_directives(
                agent_id=self._agent._agent_id,
            )
            if count >= max_volume:
                raise DirectiveCapacityError(count, max_volume)

            # Semantic dedup re-check (fresh embedding)
            if self._agent._backend._embed_fn is not None:  # type: ignore[attr-defined]
                embedding = await self._agent._backend._embed_fn(  # type: ignore[attr-defined]
                    proposal["text"]
                )
                existing_id, similarity = (
                    await self._agent._backend.find_similar_directive(
                        agent_id=self._agent._agent_id,
                        embedding=embedding,
                        threshold=DIRECTIVE_DEDUP_COSINE_THRESHOLD,
                    )
                )
                if existing_id is not None:
                    raise DirectiveDuplicateError(existing_id, similarity)

        # Delegate atomic approve to backend
        result = await self._agent._backend.approve_proposal(
            proposal_id,
            agent_id=self._agent._agent_id,
            directive_id=directive_id,
            embedding=embedding,
            resolved_by=resolved_by,
        )

        await self._agent._emit(
            "directive.proposal_approved",
            data={
                "proposal_id": proposal_id,
                "action": result["action"],
                "directive_id": result["directive_id"],
                "status": result["status"],
            },
            entity_type="directive",
            entity_id=str(result.get("directive_id") or proposal_id),
        )

        return result

    @sync_twin
    async def reject(
        self,
        proposal_id: str,
        *,
        reason: str = "",
        resolved_by: str = "",
    ) -> None:
        """Reject a directive proposal.

        Args:
            proposal_id: The proposal to reject.
            reason: Optional rejection reason.
            resolved_by: Structured JSON string describing who/what
                rejected. Defaults to ``{"actor":"operator","method":"manual"}``.

        Raises:
            ValueError: If proposal not found or already resolved.
        """
        self._agent._require_feature("directive_evolution", "Pro")
        await self._agent._backend.reject_proposal(
            proposal_id,
            agent_id=self._agent._agent_id,
            reason=reason,
            resolved_by=resolved_by,
        )

        await self._agent._emit(
            "directive.proposal_rejected",
            data={
                "proposal_id": proposal_id,
                "reason": reason,
            },
            entity_type="directive",
            entity_id=proposal_id,
        )

    # --- Portability (Phase E Slice 3) ---

    #: Bundle schema version for directive export/import.
    DIRECTIVE_SCHEMA_VERSION: int = 1

    @sync_twin
    async def export(
        self,
        *,
        include_inactive: bool = True,
    ) -> dict[str, object]:
        """Export all directives as a portable JSON bundle.

        Read-only — works in any ``directive_evolution_mode``.

        Args:
            include_inactive: If False, exclude inactive directives.

        Returns:
            Bundle with ``directive_schema_version``, ``agent_id``,
            ``exported_at``, ``count``, and ``directives`` list.
            Each directive includes ``content_hash`` for import dedup.
        """
        self._agent._require_feature("directive_evolution", "Pro")

        directives = await self._agent._backend.export_directives(
            agent_id=self._agent._agent_id,
            include_inactive=include_inactive,
        )

        bundle: dict[str, object] = {
            "directive_schema_version": self.DIRECTIVE_SCHEMA_VERSION,
            "agent_id": self._agent._agent_id,
            "exported_at": self._agent._clock.now().isoformat(),
            "count": len(directives),
            "directives": directives,
        }

        await self._agent._emit(
            "directive.exported",
            data={
                "count": len(directives),
                "include_inactive": include_inactive,
            },
        )
        return bundle

    @sync_twin
    async def import_(
        self,
        data: dict[str, object],
        *,
        re_embed: bool = False,
    ) -> dict[str, object]:
        """Import directives from an exported bundle.

        Per-entry validation:
        - Requires ``text`` field.
        - Requires ``content_hash`` field.
        - Recomputes ``hash(text)`` and rejects on mismatch.
        - Skips entries whose ``content_hash`` already exists for this agent.

        All imported directives enter as ``provisional`` regardless of
        source status — no status smuggling.

        Args:
            data: Export bundle (must have ``directive_schema_version``
                and ``directives``).
            re_embed: If True, compute embeddings for each directive
                using the current model.

        Returns:
            Import report with ``imported``, ``skipped_duplicates``,
            ``skipped_invalid``, ``skipped_hash_mismatch``,
            and ``directive_ids``.

        Raises:
            DirectiveLockedError: If ``directive_evolution_mode`` is ``locked``.
            ValueError: If ``directive_schema_version`` is missing or
                unsupported.
        """
        import hashlib

        self._agent._require_feature("directive_evolution", "Pro")
        await self._check_directive_lock("import")

        # Validate schema version
        schema_version = data.get("directive_schema_version")
        if schema_version is None:
            msg = "Export bundle missing required 'directive_schema_version' field."
            raise ValueError(msg)
        if schema_version != self.DIRECTIVE_SCHEMA_VERSION:
            msg = (
                f"Unsupported directive_schema_version: {schema_version} "
                f"(expected {self.DIRECTIVE_SCHEMA_VERSION})."
            )
            raise ValueError(msg)

        raw_directives = data.get("directives", [])
        if not isinstance(raw_directives, list):
            msg = "Export bundle 'directives' must be a list."
            raise ValueError(msg)

        # Fetch existing content_hashes for dedup
        existing = await self._agent._backend.list_directives(
            agent_id=self._agent._agent_id,
            include_inactive=True,
        )
        existing_hashes: set[str] = {
            d.get("content_hash", "") for d in existing
        }

        valid_entries: list[dict[str, object]] = []
        skipped_invalid = 0
        skipped_duplicates = 0
        skipped_hash_mismatch = 0

        for entry in raw_directives:
            if not isinstance(entry, dict):
                skipped_invalid += 1
                continue
            text = entry.get("text")
            content_hash = entry.get("content_hash")
            if not text or not isinstance(text, str):
                skipped_invalid += 1
                continue
            if not content_hash or not isinstance(content_hash, str):
                skipped_invalid += 1
                continue

            # Verify content_hash integrity
            expected_hash = hashlib.sha256(
                str(text).strip().lower().encode()
            ).hexdigest()
            if content_hash != expected_hash:
                skipped_hash_mismatch += 1
                continue

            # Exact-dedup by content_hash
            if content_hash in existing_hashes:
                skipped_duplicates += 1
                continue

            validated: dict[str, object] = {
                "text": text,
                "content_hash": content_hash,
                "priority": entry.get("priority", "contextual"),
                "created_at": entry.get("created_at"),
            }

            # Optionally re-embed
            if re_embed and self._agent._backend._embed_fn is not None:  # type: ignore[attr-defined]
                vec = await self._agent._backend._embed_fn(text)  # type: ignore[attr-defined]
                validated["_embedding"] = vec

            valid_entries.append(validated)
            # Track hash so subsequent entries in the same import batch
            # are deduped against each other
            existing_hashes.add(content_hash)

        directive_ids: list[str] = []
        if valid_entries:
            directive_ids = await self._agent._backend.import_directives(
                agent_id=self._agent._agent_id,
                directives=valid_entries,
            )

        await self._agent._emit(
            "directive.imported",
            data={
                "imported": len(directive_ids),
                "skipped_duplicates": skipped_duplicates,
                "skipped_invalid": skipped_invalid,
                "skipped_hash_mismatch": skipped_hash_mismatch,
                "directive_ids": directive_ids,
            },
            entity_type="agent",
            entity_id=self._agent._agent_id,
        )

        return {
            "imported": len(directive_ids),
            "skipped_duplicates": skipped_duplicates,
            "skipped_invalid": skipped_invalid,
            "skipped_hash_mismatch": skipped_hash_mismatch,
            "directive_ids": directive_ids,
        }

    @sync_twin
    async def reset(self) -> dict[str, object]:
        """Hard-delete all directives and proposals for this agent.

        Atomic — both tables cleared in a single transaction.
        Not proposable — blocked in ``locked`` mode but executes
        directly in both ``active`` and ``advisory`` modes (reset is
        an explicit operator action, not a governable mutation).

        Returns:
            Dict with per-table counts and ``event_id``.

        Raises:
            DirectiveLockedError: If ``directive_evolution_mode`` is ``locked``.
        """
        self._agent._require_feature("directive_evolution", "Pro")
        # Lock check — block in locked mode only. Advisory mode
        # does NOT reroute to proposal — reset is not proposable.
        mode = self._agent._config.lock.directive_evolution_mode
        if mode == "locked":
            await self._agent._emit(
                "directive.write_blocked",
                data={"method": "reset", "reason": "locked"},
            )
            from wisdom_layer.errors import DirectiveLockedError

            raise DirectiveLockedError()

        counts = await self._agent._backend.reset_directives(
            agent_id=self._agent._agent_id,
        )

        event = await self._agent._emit_returning(
            "directive.reset",
            priority=EventPriority.CRITICAL,
            data={
                "per_table": counts,
                "total_deleted": sum(counts.values()),
            },
            entity_type="agent",
            entity_id=self._agent._agent_id,
        )

        return {
            **counts,
            "event_id": event.data["event_id"],
        }


class AnalyticsInterface:
    """Public analytics API — trajectory, health, export."""

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    @sync_twin
    async def trajectory(
        self,
        *,
        time_range: str = "last_90_days",
        resolution: str = "weekly",
    ) -> dict[str, object]:
        """Get agent development trajectory.

        Args:
            time_range: Period to analyze.
            resolution: Data point granularity.

        Returns:
            Trajectory with wisdom score, self-correction rate, etc.
        """
        self._agent._require_feature("standard_analytics", "Pro")
        raise NotImplementedError("Trajectory analytics — coming in v0.3")

    @sync_twin
    async def health(self) -> HealthReport:
        """Get a rich cognitive health report.

        Alias for ``agent.health()``. Returns a :class:`HealthReport`
        with memory/directive/dream/cost stats and, for Pro+ tiers,
        wisdom score and cognitive health classification.
        """
        return await self._agent._build_health_report()


class JournalsInterface:
    """Public journals API — write, synthesize, history, get.

    ``write()`` stores a journal entry and atomically marks the source
    memories as journaled. ``synthesize()`` generates a journal entry
    via the LLM and persists it using ``write()``. ``history()`` and
    ``get()`` retrieve stored journals.
    """

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    @sync_twin
    async def write(
        self,
        content: str,
        memory_ids: list[str],
    ) -> dict[str, object]:
        """Persist a journal entry and mark source memories as journaled.

        Args:
            content: Journal text content.
            memory_ids: Memory IDs covered by this journal. All must exist
                and belong to this agent. Duplicates are rejected.

        Returns:
            Dict with ``journal_id``, ``memory_count``, ``event_id``.

        Raises:
            TierRestrictionError: If tier lacks ``dream_cycles`` feature.
            ValueError: If ``content`` exceeds ``JOURNAL_MAX_CONTENT_SIZE``,
                ``memory_ids`` is empty, contains duplicates, or references
                non-existent / wrong-agent memories.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        max_content_size = self._agent._admin.journal_max_content_size

        # --- Validate content size ---
        if len(content) > max_content_size:
            msg = (
                f"Journal content length {len(content)} exceeds "
                f"maximum {max_content_size}"
            )
            raise ValueError(msg)

        if not content.strip():
            msg = "Journal content must not be empty"
            raise ValueError(msg)

        # --- Validate memory_ids ---
        if not memory_ids:
            msg = "memory_ids must not be empty"
            raise ValueError(msg)

        if len(memory_ids) != len(set(memory_ids)):
            msg = "memory_ids must not contain duplicates"
            raise ValueError(msg)

        # Validate all IDs exist and belong to this agent
        found_ids = await self._agent._backend.validate_memory_ids(
            agent_id=self._agent._agent_id,
            memory_ids=memory_ids,
        )
        missing = set(memory_ids) - found_ids
        if missing:
            msg = f"memory_ids not found or not owned by agent: {sorted(missing)}"
            raise ValueError(msg)

        # Deterministic ordering
        sorted_ids = sorted(memory_ids)

        import uuid

        journal_id = uuid.uuid4().hex[:12]
        created_at = self._agent._clock.now().isoformat()

        await self._agent._backend.store_journal(
            agent_id=self._agent._agent_id,
            journal_id=journal_id,
            content=content,
            memory_ids=sorted_ids,
            created_at=created_at,
        )

        event = await self._agent._emit_returning(
            "journal.written",
            data={
                "journal_id": journal_id,
                "memory_count": len(sorted_ids),
                "memory_ids": sorted_ids,
            },
            entity_type="journal",
            entity_id=journal_id,
        )

        return {
            "journal_id": journal_id,
            "memory_count": len(sorted_ids),
            "event_id": event.data["event_id"],
        }

    @sync_twin
    async def synthesize(
        self,
        memory_ids: list[str],
    ) -> dict[str, object]:
        """Generate a journal entry from the given memories via LLM.

        Fetches memory content, builds a prompt, calls the LLM to
        generate a narrative synthesis, then persists via ``write()``.

        Args:
            memory_ids: Memory IDs to synthesize. All must exist and
                belong to this agent. Minimum ``JOURNAL_MIN_MEMORIES``,
                maximum ``JOURNAL_MAX_MEMORIES``.

        Returns:
            Dict with ``journal_id``, ``memory_count``, ``event_id``,
            ``synthesized`` (``True``).

        Raises:
            TierRestrictionError: If tier lacks ``dream_cycles`` feature.
            ValueError: If ``memory_ids`` is empty, contains duplicates,
                exceeds ``JOURNAL_MAX_MEMORIES``, is below
                ``JOURNAL_MIN_MEMORIES``, references non-existent /
                wrong-agent memories, or if any memory has empty content.
            ModelAdapterError: If LLM call fails (no journal written).
        """
        import logging

        from wisdom_layer._internal.journal import (
            build_journal_prompt,
            parse_journal_output,
        )

        _logger = logging.getLogger(__name__)

        self._agent._require_feature("dream_cycles", "Pro")
        admin = self._agent._admin
        max_content_size = admin.journal_max_content_size
        max_memories = admin.journal_max_memories
        min_memories = admin.journal_min_memories

        # --- Validate memory_ids ---
        if not memory_ids:
            msg = "memory_ids must not be empty"
            raise ValueError(msg)

        if len(memory_ids) != len(set(memory_ids)):
            msg = "memory_ids must not contain duplicates"
            raise ValueError(msg)

        if len(memory_ids) < min_memories:
            msg = (
                f"memory_ids count {len(memory_ids)} is below "
                f"minimum {min_memories}"
            )
            raise ValueError(msg)

        if len(memory_ids) > max_memories:
            msg = (
                f"memory_ids count {len(memory_ids)} exceeds "
                f"maximum {max_memories}"
            )
            raise ValueError(msg)

        # --- Fetch memories (validate + fetch in one pass) ---
        memories = await self._agent._backend.get_memories_by_ids(
            agent_id=self._agent._agent_id,
            memory_ids=memory_ids,
        )

        found_ids = {m["id"] for m in memories}
        missing = set(memory_ids) - found_ids
        if missing:
            msg = f"memory_ids not found or not owned by agent: {sorted(missing)}"
            raise ValueError(msg)

        # --- Validate memory content is non-empty ---
        for mem in memories:
            content = mem.get("content")
            if content is None:
                msg = f"memory {mem['id']} has no content"
                raise ValueError(msg)
            content_str = (
                str(content) if not isinstance(content, dict)
                else str(content)
            )
            if not content_str.strip() or content_str.strip() == "{}":
                msg = f"memory {mem['id']} has empty content"
                raise ValueError(msg)

        # --- Sort memories by created_at for deterministic prompt ---
        memories.sort(key=lambda m: m.get("created_at", ""))

        # --- Build prompt and call LLM ---
        system_prompt, messages = build_journal_prompt(memories)
        raw_response = await self._agent._retryable_generate(
            system=system_prompt,
            messages=messages,
            max_tokens=2048,
        )
        await self._agent._record_llm_usage(
            category="dream.journal_synthesis"
            if self._agent._active_cycle_id
            else "journal",
            purpose="journal_synthesis",
        )

        content = parse_journal_output(raw_response)

        if not content.strip():
            msg = "LLM returned empty journal content"
            raise ValueError(msg)

        # --- Clamp to max content size ---
        if len(content) > max_content_size:
            _logger.warning(
                "Journal synthesis output truncated",
                extra={
                    "original_length": len(content),
                    "max_length": max_content_size,
                },
            )
            content = content[:max_content_size]

        # --- Persist via write() (reuses Slice 1 path) ---
        result = await self.write(content, memory_ids)

        # --- Emit synthesis-specific event ---
        await self._agent._emit(
            "journal.synthesized",
            data={
                "journal_id": result["journal_id"],
                "memory_count": result["memory_count"],
                "memory_ids": sorted(memory_ids),
            },
            entity_type="journal",
            entity_id=str(result["journal_id"]),
        )

        return {
            "journal_id": result["journal_id"],
            "memory_count": result["memory_count"],
            "event_id": result["event_id"],
            "synthesized": True,
        }

    @sync_twin
    async def candidates(
        self,
        *,
        since: str | None | EllipsisType = ...,
        limit: int | None = None,
    ) -> list[dict[str, object]]:
        """Return unjournaled memories eligible for synthesis.

        This is a read-only, point-in-time snapshot — no memories are
        modified, no journal is created. The caller inspects the result
        and decides whether to call ``synthesize()``.

        Note: ``synthesize()`` re-validates all memory IDs at write
        time. A memory returned by ``candidates()`` could be journaled
        by a concurrent call between the two steps. This is safe —
        ``write()`` treats already-journaled memories as valid (the
        ``journaled`` flag is write-once and non-exclusive).

        Args:
            since: ISO 8601 lower bound on ``created_at`` (inclusive).
                Defaults to midnight UTC of the current day (agent
                clock). Pass ``None`` explicitly for all-time.
            limit: Maximum results. Defaults to ``JOURNAL_MAX_MEMORIES``.
                Clamped to ``JOURNAL_MAX_MEMORIES`` regardless of input.

        Returns:
            List of memory dicts (``id``, ``content``, ``event_type``,
            ``salience``, ``created_at``) ordered by ``created_at ASC,
            id ASC``.

        Raises:
            TierRestrictionError: If tier lacks ``dream_cycles`` feature.
            ValueError: If ``since`` is not valid ISO 8601.
        """
        from datetime import datetime

        self._agent._require_feature("dream_cycles", "Pro")
        max_memories = self._agent._admin.journal_max_memories

        # --- Resolve default since: midnight UTC today ---
        # sentinel ... means "use default" (distinct from None = all-time)
        if since is ...:
            now = self._agent._clock.now()
            since = now.replace(
                hour=0, minute=0, second=0, microsecond=0,
            ).isoformat()
        elif since is not None:
            # Validate ISO 8601
            try:
                datetime.fromisoformat(since)
            except (ValueError, TypeError) as exc:
                msg = f"since must be valid ISO 8601, got: {since!r}"
                raise ValueError(msg) from exc

        # --- Clamp limit ---
        effective_limit = min(
            limit if limit is not None else max_memories,
            max_memories,
        )

        return await self._agent._backend.get_unjournaled_memories(
            agent_id=self._agent._agent_id,
            since=since,
            limit=effective_limit,
            max_memories_cap=max_memories,
        )

    @sync_twin
    async def history(
        self,
        *,
        limit: int = 20,
    ) -> list[dict[str, object]]:
        """Retrieve journal history, most recent first.

        Args:
            limit: Maximum number of journals to return.

        Returns:
            List of journal dicts.

        Raises:
            TierRestrictionError: If tier lacks ``dream_cycles`` feature.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        return await self._agent._backend.get_journals(
            agent_id=self._agent._agent_id,
            limit=limit,
        )

    @sync_twin
    async def get(self, journal_id: str) -> dict[str, object] | None:
        """Fetch a single journal by ID.

        Args:
            journal_id: The journal to fetch.

        Returns:
            Journal dict, or ``None`` if not found.

        Raises:
            TierRestrictionError: If tier lacks ``dream_cycles`` feature.
        """
        self._agent._require_feature("dream_cycles", "Pro")
        return await self._agent._backend.get_journal(
            journal_id,
            agent_id=self._agent._agent_id,
        )


class ProvenanceInterface:
    """Public provenance API — trace and explain auditable learning history.

    Backs the patent's "auditable learning" claim by letting a caller
    reconstruct the lineage of any memory, directive, journal, critic
    pass, insight, or dream cycle from the append-only event log.

    - ``trace(entity_id)`` returns the raw chain of events that touched
      the entity, oldest-first. This is the evidence trail.
    - ``explain(entity_id)`` narrates that trace via the agent's LLM
      adapter and caches the narration by trace-hash so repeated calls
      on an unchanged trace are free after the first.
    - ``export(...)`` dumps a time-windowed slice of the log as a
      portable JSON bundle for compliance archival.

    All three gate on the ``provenance`` tier feature plus their own
    ``provenance_trace`` / ``provenance_explain`` / ``provenance_export``
    sub-flag so operators can opt in or out independently.
    """

    #: Bound on the in-memory explain cache. The cache key is the trace
    #: hash, so a single long-lived agent never exceeds (entities × 1)
    #: distinct keys unless traces are re-narrated after new events land.
    #: 256 is generous for an interactive session; serialize externally
    #: if you need persistence across restarts.
    _EXPLAIN_CACHE_MAX: int = 256

    _EXPLAIN_SYSTEM_PROMPT: str = (
        "You are the audit narrator for a Wisdom Layer agent. Given an "
        "ordered provenance event log for a single entity, write a "
        "concise plain-English narrative describing what happened to "
        "the entity, in the order events occurred. Do NOT speculate "
        "about anything not in the log. Do NOT invent entity IDs. "
        "Reference events by their event_type, not their event_id."
    )

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent
        self._explain_cache: dict[str, str] = {}

    @sync_twin
    async def trace(
        self,
        entity_id: str,
        *,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        """Return the provenance event chain for ``entity_id``.

        Events are returned oldest-first so the caller can read the
        chain top-down. Each event dict has the fields from
        :meth:`BaseBackend.append_provenance_event` with ``payload``
        decoded from JSON.

        Args:
            entity_id: The memory / directive / journal / critic_pass /
                insight / dream_cycle / agent id to trace. Tenant isolation
                is enforced — events belonging to another agent are never
                returned even if ``entity_id`` collides.
            limit: Hard cap on the number of events returned (default
                200). Older events beyond the cap are not returned.

        Returns:
            List of event dicts. Empty list when the entity has no
            logged events (e.g. provenance flag was off at the time of
            the mutation, or the id does not exist).

        Raises:
            TierRestrictionError: If tier lacks ``provenance_trace``.
            FeatureDisabledError: If ``feature_flags.provenance_trace``
                is False.
        """
        self._agent._require_feature("provenance_trace", "Pro")
        return await self._agent._backend.query_provenance_events_by_entity(
            agent_id=self._agent._agent_id,
            entity_id=entity_id,
            limit=limit,
        )

    @sync_twin
    async def explain(
        self,
        entity_id: str,
        *,
        limit: int = 200,
    ) -> dict[str, Any]:
        """Return an LLM-narrated explanation of an entity's trace.

        Calls :meth:`trace` first, hashes the resulting event_id
        sequence, and either returns a cached narration or asks the
        agent's LLM adapter to generate a new one. Cache hits cost zero
        LLM tokens; cache misses produce and store a fresh narration.

        Args:
            entity_id: The entity whose lineage to narrate.
            limit: Max events to include in the trace (passed to
                :meth:`trace`).

        Returns:
            Dict with:

            - ``entity_id``: the id passed in
            - ``narrative``: the LLM-generated explanation (str)
            - ``trace_hash``: sha256 of the ordered event_ids
            - ``event_count``: number of events in the trace
            - ``cached``: True when served from cache

            When the trace is empty, returns a narrative saying so
            without calling the LLM.

        Raises:
            TierRestrictionError: If tier lacks ``provenance_explain``.
            FeatureDisabledError: If ``feature_flags.provenance_explain``
                is False.
        """
        import hashlib
        import json as _json

        self._agent._require_feature("provenance_explain", "Enterprise")

        events = await self._agent._backend.query_provenance_events_by_entity(
            agent_id=self._agent._agent_id,
            entity_id=entity_id,
            limit=limit,
        )

        event_ids = [str(e.get("event_id", "")) for e in events]
        trace_hash = hashlib.sha256(
            "|".join(event_ids).encode("utf-8")
        ).hexdigest()

        if not events:
            return {
                "entity_id": entity_id,
                "narrative": (
                    f"No provenance events recorded for entity "
                    f"'{entity_id}'."
                ),
                "trace_hash": trace_hash,
                "event_count": 0,
                "cached": False,
            }

        cached = self._explain_cache.get(trace_hash)
        if cached is not None:
            return {
                "entity_id": entity_id,
                "narrative": cached,
                "trace_hash": trace_hash,
                "event_count": len(events),
                "cached": True,
            }

        user_message = (
            f"Entity: {entity_id}\n\n"
            f"Event log ({len(events)} events, oldest first):\n"
            f"{_json.dumps(events, default=str, indent=2)}"
        )

        llm_result = await self._agent._retryable_generate(
            messages=[{"role": "user", "content": user_message}],
            system=self._EXPLAIN_SYSTEM_PROMPT,
            temperature=0.2,
        )
        await self._agent._record_llm_usage(
            category="explain",
            event_id=entity_id,
            purpose="provenance_explain",
        )
        narrative = str(llm_result).strip()

        if len(self._explain_cache) >= self._EXPLAIN_CACHE_MAX:
            # FIFO eviction — oldest key first. Python 3.7+ dicts are
            # insertion-ordered, so next(iter(...)) is the oldest.
            oldest = next(iter(self._explain_cache))
            self._explain_cache.pop(oldest, None)
        self._explain_cache[trace_hash] = narrative

        return {
            "entity_id": entity_id,
            "narrative": narrative,
            "trace_hash": trace_hash,
            "event_count": len(events),
            "cached": False,
        }

    @sync_twin
    async def export(
        self,
        *,
        since: str | None = None,
        until: str | None = None,
        limit: int = 500,
    ) -> dict[str, Any]:
        """Export a time-windowed slice of the provenance log.

        The export bundle is a JSON-serializable dict designed for
        compliance archival. Events are returned oldest-first and
        include the full payload so downstream systems can reconstruct
        the audit trail without calling the agent.

        Args:
            since: ISO 8601 UTC timestamp. Events with ``created_at``
                strictly older than this are excluded. ``None`` means
                no lower bound.
            until: ISO 8601 UTC timestamp. Events with ``created_at``
                strictly newer than this are excluded. ``None`` means
                no upper bound.
            limit: Hard cap on number of events in the bundle.

        Returns:
            Dict with ``schema_version``, ``agent_id``, ``exported_at``,
            ``since``, ``until``, ``count``, and ``events`` list.

        Raises:
            TierRestrictionError: If tier lacks ``provenance_export``.
            FeatureDisabledError: If ``feature_flags.provenance_export``
                is False.
        """
        self._agent._require_feature("provenance_export", "Enterprise")

        events = await self._agent._backend.query_provenance_events_by_time(
            agent_id=self._agent._agent_id,
            since=since,
            until=until,
            limit=limit,
        )

        return {
            "schema_version": 1,
            "agent_id": self._agent._agent_id,
            "exported_at": self._agent._clock.now().isoformat(),
            "since": since,
            "until": until,
            "count": len(events),
            "events": events,
        }

    @sync_twin
    async def walk_xagent(
        self,
        team_insight_id: str,
    ) -> TeamInsightProvenance:
        """Walk the cross-agent provenance edge for a team insight.

        Surfaces the workspace-side terminator of the patent-defensible
        provenance walk: returns the team insight, the contributing
        :class:`SharedMemory` rows, and each contribution's
        ``source_memory_id`` back-pointer into the contributor's
        per-agent backend.

        **The walk does not — and cannot — dereference any
        ``source_memory_id``.** Only the contributing agent itself, who
        holds a handle to its own per-agent backend, can resolve those
        ids via its own ``agent.memory.get(memory_id)``. This bridge
        method delegates straight to
        :meth:`SharedMemoryPool.walk_provenance` without ever opening
        another agent's backend.

        Args:
            team_insight_id: The id of the team insight to walk.

        Returns:
            :class:`TeamInsightProvenance` with the insight and the
            ordered list of :class:`ProvenanceContribution` records.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
                Fix: ``await workspace.register_agent(agent)``.
            LookupError: If ``team_insight_id`` does not resolve in the
                workspace pool.
        """
        workspace = self._agent._workspace
        if workspace is None:
            raise RuntimeError(
                "Agent is not registered to a workspace. "
                "Call `await workspace.register_agent(agent)` before "
                "agent.provenance.walk_xagent(). Multi-agent features "
                "are Enterprise-tier; see Workspace docs.",
            )
        return await workspace.pool.walk_provenance(team_insight_id)


class MessagesInterface:
    """Per-agent bridge into the workspace :class:`MessageBus` — Multi-C.

    Public surface:

    * :meth:`send` — direct message to one agent.
    * :meth:`broadcast` — capability-filtered announcement.
    * :meth:`reply` — reply in an existing thread.
    * :meth:`check_inbox` — read messages addressed to this agent.
    * :meth:`list_thread` — full conversation walk.
    * :meth:`list_agents` — directory of registered peers (so the LLM
      knows who it can address).
    * :meth:`mark_read` — explicit ack on a fetched message.
    * :meth:`close_thread` — operator-driven thread closure.

    All methods raise :class:`RuntimeError` if the agent has not been
    registered to a workspace via :meth:`Workspace.register_agent`,
    matching the pattern set by :meth:`MemoryInterface.share` and
    :meth:`ProvenanceInterface.walk_xagent`. The error message points
    at the fix.

    The bridge auto-fills two pieces of context the LLM should not have
    to thread through every call:

    1. ``sender_id`` is always ``self._agent.agent_id`` — the agent
       cannot impersonate a peer through this surface.
    2. ``recipient_capabilities`` for :meth:`check_inbox` is fetched
       from the workspace directory entry for *this* agent — the LLM
       does not pass its own capability list, so a stale local view
       cannot widen the broadcast match set.
    """

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    def _require_workspace(self, method_name: str) -> Workspace:
        """Return the bound workspace or raise a pointed RuntimeError.

        Centralised so every messaging method emits the same error
        shape — operators grepping logs see one signature, not five.
        """
        workspace = self._agent._workspace
        if workspace is None:
            raise RuntimeError(
                "Agent is not registered to a workspace. "
                "Call `await workspace.register_agent(agent)` before "
                f"agent.messages.{method_name}(). Multi-agent features "
                "are Enterprise-tier; see Workspace docs.",
            )
        return workspace

    @sync_twin
    async def send(
        self,
        *,
        recipient_id: str,
        content: str,
        purpose: MessagePurpose = MessagePurpose.QUESTION,
        related_memory_ids: list[str] | None = None,
        related_task_id: str | None = None,
        expects_reply: bool = True,
        reply_deadline: datetime | None = None,
    ) -> str:
        """Send a direct message; return the new ``message_id``.

        Auto-fills ``sender_id`` from this agent. The bus owns rate
        limiting, threading, and provenance event emission — see
        :meth:`MessageBus.send`.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
            MessageRateLimitExceededError: If sending would exceed the
                per-agent hourly cap (default 100/hr).
        """
        workspace = self._require_workspace("send")
        return await workspace.messages.send(
            sender_id=self._agent._agent_id,
            recipient_id=recipient_id,
            content=content,
            purpose=purpose,
            related_memory_ids=related_memory_ids,
            related_task_id=related_task_id,
            expects_reply=expects_reply,
            reply_deadline=reply_deadline,
        )

    @sync_twin
    async def broadcast(
        self,
        *,
        broadcast_capability: str,
        content: str,
        purpose: MessagePurpose = MessagePurpose.INFORMATION,
        related_memory_ids: list[str] | None = None,
        related_task_id: str | None = None,
        expects_reply: bool = False,
        reply_deadline: datetime | None = None,
    ) -> str:
        """Broadcast to every agent whose directory entry advertises
        ``broadcast_capability``; return the new ``message_id``.

        Counts against the broadcast sub-cap (default 10/hr) and the
        per-agent total. See :meth:`MessageBus.broadcast`.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
            MessageRateLimitExceededError: If sending would exceed the
                broadcast sub-cap or the per-agent total.
        """
        workspace = self._require_workspace("broadcast")
        return await workspace.messages.broadcast(
            sender_id=self._agent._agent_id,
            broadcast_capability=broadcast_capability,
            content=content,
            purpose=purpose,
            related_memory_ids=related_memory_ids,
            related_task_id=related_task_id,
            expects_reply=expects_reply,
            reply_deadline=reply_deadline,
        )

    @sync_twin
    async def reply(
        self,
        *,
        in_reply_to: str,
        content: str,
        purpose: MessagePurpose = MessagePurpose.INFORMATION,
        related_memory_ids: list[str] | None = None,
        related_task_id: str | None = None,
        expects_reply: bool = False,
        reply_deadline: datetime | None = None,
    ) -> str:
        """Reply to ``in_reply_to``; return the new ``message_id``.

        Inherits the parent's ``thread_id`` and addresses the original
        sender. Refuses to append to a closed thread or reply to a
        broadcast — see :meth:`MessageBus.reply`.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
            ValueError: If the parent does not exist, is a broadcast,
                or the thread is closed.
        """
        workspace = self._require_workspace("reply")
        return await workspace.messages.reply(
            sender_id=self._agent._agent_id,
            in_reply_to=in_reply_to,
            content=content,
            purpose=purpose,
            related_memory_ids=related_memory_ids,
            related_task_id=related_task_id,
            expects_reply=expects_reply,
            reply_deadline=reply_deadline,
        )

    @sync_twin
    async def check_inbox(
        self,
        *,
        unread_only: bool = True,
        include_broadcasts: bool = True,
        limit: int = 100,
    ) -> list[AgentMessage]:
        """Return messages addressed to this agent, newest-first.

        Capability list is read from the workspace directory entry for
        this agent — the LLM never passes its own capabilities, so it
        cannot widen the broadcast match set by lying about what it
        can do.

        Past-deadline pending messages lazy-expire on the read; with
        ``unread_only=True`` (default) they are filtered out of the
        returned list. See :meth:`MessageBus.list_inbox`.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
        """
        workspace = self._require_workspace("check_inbox")
        record = await workspace.directory.get(self._agent._agent_id)
        # Defensive: a workspace-bonded agent should always have a
        # directory row, but if the row was unregistered behind our
        # back the agent is no longer a participant — surface as an
        # explicit RuntimeError rather than returning a phantom inbox.
        if record is None or record.archived_at is not None:
            raise RuntimeError(
                "Agent is bonded to the workspace but no active "
                "directory entry was found. The workspace may have "
                "unregistered the agent. Re-register via "
                "`await workspace.register_agent(agent)`.",
            )
        return await workspace.messages.list_inbox(
            recipient_id=self._agent._agent_id,
            recipient_capabilities=list(record.capabilities),
            unread_only=unread_only,
            include_broadcasts=include_broadcasts,
            limit=limit,
        )

    @sync_twin
    async def list_thread(
        self,
        thread_id: str,
        *,
        limit: int = 200,
    ) -> list[AgentMessage]:
        """Return the full thread, oldest-first. See :meth:`MessageBus.list_thread`.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
        """
        workspace = self._require_workspace("list_thread")
        return await workspace.messages.list_thread(thread_id, limit=limit)

    @sync_twin
    async def list_agents(
        self,
        *,
        capability: str | None = None,
        include_archived: bool = False,
    ) -> list[AgentRecord]:
        """Return the workspace agent directory.

        The LLM uses this before :meth:`send` to discover valid
        ``recipient_id`` values. Defaults to active (non-archived)
        agents only; pass ``include_archived=True`` for the full roster.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
        """
        workspace = self._require_workspace("list_agents")
        return await workspace.directory.list(
            capability=capability,
            include_archived=include_archived,
        )

    @sync_twin
    async def mark_read(self, message_id: str) -> bool:
        """Acknowledge a message; return ``True`` on transition.

        For direct messages this transitions PENDING → READ. For
        broadcasts this records a per-reader ack row (the broadcast
        message itself remains PENDING because other recipients may
        still need to ack). See :meth:`MessageBus.mark_read`.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
        """
        workspace = self._require_workspace("mark_read")
        return await workspace.messages.mark_read(
            message_id=message_id,
            reader_agent_id=self._agent._agent_id,
        )

    @sync_twin
    async def close_thread(
        self,
        thread_id: str,
        *,
        reason: ThreadCloseReason = ThreadCloseReason.MANUAL,
        metadata: dict[str, Any] | None = None,
    ) -> ThreadClosedResult:
        """Close a thread; subsequent replies raise.

        Default reason is :attr:`ThreadCloseReason.MANUAL` — the
        deterministic / convergence gates fire from
        :class:`ThreadExitPolicy` (Chunk D), not this surface. See
        :meth:`MessageBus.close_thread`.

        Raises:
            RuntimeError: If the agent is not registered to a workspace.
        """
        workspace = self._require_workspace("close_thread")
        return await workspace.messages.close_thread(
            thread_id=thread_id,
            reason=reason,
            metadata=metadata,
        )


class HealthInterface:
    """Public health API — callable, plus trajectory and capture_snapshot.

    ``agent.health()`` returns the current :class:`HealthReport`
    (callable behavior). ``agent.health.trajectory(days=N)`` returns a
    time series of daily snapshots. ``agent.health.capture_snapshot()``
    forces a snapshot to be written to ``health_snapshots`` and emits
    a ``health.snapshot`` event.

    Trajectory and capture_snapshot gate on the ``standard_analytics``
    feature (Pro+) plus the ``health_analytics`` FeatureFlag. The
    callable `` agent.health()`` itself is available on every tier —
    free tier just sees stats with no composite or classifier. See
    :meth:`WisdomAgent._build_health_report` for the tier logic.

    Per-tier trajectory caps are enforced here, not at the backend:
        - Pro:        ``days`` ≤ 30
        - Enterprise: no cap
    """

    #: Enforced upper bound on trajectory lookback for Pro-tier callers.
    #: Enterprise tier bypasses this cap.
    _PRO_TRAJECTORY_DAYS_CAP: int = 30

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    def __call__(self) -> Any:
        """Return current :class:`HealthReport` (async).

        Usage::

            report = await agent.health()
        """
        return self._agent._build_health_report()

    async def trajectory(self, days: int = 30) -> list[HealthReport]:
        """Return daily :class:`HealthReport` snapshots over the last ``days``.

        Missing days (agent not running that day) are omitted from the
        returned list rather than zero-filled — callers see the gap.
        The list is ordered by ``snapshot_date`` ascending.

        Args:
            days: Lookback window in calendar days. Must be positive.
                Pro tier caps at 30; Enterprise is unbounded.

        Raises:
            TierRestrictionError: caller's tier lacks
                ``standard_analytics``.
            FeatureDisabledError: ``health_analytics`` flag is off.
            ValueError: ``days`` is not positive.
        """
        self._agent._require_feature("standard_analytics", "Pro")
        if days <= 0:
            msg = "trajectory days must be positive"
            raise ValueError(msg)
        if not has_feature(self._agent._tier, "advanced_analytics"):
            # Pro tier — cap silently at 30 days. A louder raise would
            # force callers to branch on tier which is exactly what the
            # SDK exists to avoid.
            days = min(days, self._PRO_TRAJECTORY_DAYS_CAP)

        now = self._agent._clock.now()
        since_date = (now - timedelta(days=days - 1)).date().isoformat()
        until_date = now.date().isoformat()
        rows = await self._agent._backend.query_health_snapshots(
            agent_id=self._agent._agent_id,
            since=since_date,
            until=until_date,
        )
        reports: list[HealthReport] = []
        for row in rows:
            try:
                reports.append(HealthReport.model_validate_json(row["payload"]))
            except (ValueError, TypeError):
                # Payload corruption is not fatal — skip the row so the
                # rest of the trajectory is still readable.
                logger.warning(
                    "Skipping corrupt health snapshot",
                    extra={
                        "subsystem": "health",
                        "agent_id": self._agent._agent_id,
                        "snapshot_date": row.get("snapshot_date"),
                    },
                )
                continue
        return reports

    async def capture_snapshot(self) -> HealthReport:
        """Capture a snapshot to ``health_snapshots`` and emit an event.

        Returns the snapshot that was written. Overwrites any existing
        snapshot for the same calendar day so a manual trigger late in
        the day refreshes the scheduler's earlier entry.

        Emits ``health.snapshot`` on the event bus with the serialized
        report in ``data``.

        Raises:
            TierRestrictionError: caller's tier lacks
                ``standard_analytics``.
            FeatureDisabledError: ``health_analytics`` flag is off.
        """
        self._agent._require_feature("standard_analytics", "Pro")
        report = await self._agent._build_health_report()
        now = self._agent._clock.now()
        await self._agent._backend.append_health_snapshot(
            agent_id=self._agent._agent_id,
            snapshot_date=now.date().isoformat(),
            payload=report.model_dump_json(),
            created_at=now.isoformat(),
        )
        event_data: dict[str, Any] = {
            "snapshot_date": now.date().isoformat(),
            "wisdom_score": report.wisdom_score,
            "cognitive_health": (
                report.cognitive_health.value
                if report.cognitive_health is not None
                else None
            ),
        }
        # Pool-less backends (SQLite) return {} and add no keys to the
        # event payload; Postgres attaches size/idle/in_use so operators
        # can correlate pool saturation with health dips.
        pool_stats = await self._agent._backend.pool_stats()
        if pool_stats:
            event_data["pool_stats"] = pool_stats
        await self._agent._emit(
            "health.snapshot",
            data=event_data,
            entity_type="agent",
            entity_id=self._agent._agent_id,
        )
        return report

    # -- Sync twins --------------------------------------------------------
    #
    # ``agent.health`` is not a method, so the ``@sync_twin`` class-body
    # decorator doesn't apply. The sync façade hand-wires these via
    # ``_SyncHealthProxy`` in ``sync_agent.py``; the twins below let a
    # caller who has a direct ``HealthInterface`` reference block on it
    # without importing the sync façade.

    def trajectory_sync(self, days: int = 30) -> list[HealthReport]:
        return asyncio.run(self.trajectory(days=days))

    def capture_snapshot_sync(self) -> HealthReport:
        return asyncio.run(self.capture_snapshot())


class CostInterface:
    """Public cost-visibility API for the v0.5 Phase 4 surface.

    - ``agent.cost.summary(window=...)`` — aggregate spend / tokens /
      calls over a window, broken down by category and model.
    - ``agent.cost.estimate_dream(depth=...)`` — pre-flight estimate
      for the next dream cycle based on recent history.
    - ``agent.cost.export(since=..., until=...)`` — CSV export of the
      full cost ledger (Enterprise only).

    Feature gating:
        ``summary``/``estimate_dream``: Pro+ via ``cost_visibility``.
        ``export``: Enterprise-only via ``cost_export``.
    """

    def __init__(self, agent: WisdomAgent) -> None:
        self._agent = agent

    @sync_twin
    async def summary(
        self,
        *,
        window: str | timedelta | None = None,
    ) -> Any:
        """Return an aggregate :class:`CostSummary` for the given window.

        Args:
            window: Either a :class:`timedelta` or a shorthand string
                (``"1d"`` / ``"7d"`` / ``"30d"`` / ``"all"``). ``None``
                defaults to ``"7d"``.

        Raises:
            TierRestrictionError: current tier lacks ``cost_visibility``.
            FeatureDisabledError: ``cost_visibility`` flag is off.
        """
        from wisdom_layer.types import CostBucket, CostSummary

        self._agent._require_feature("cost_visibility", "Pro")

        now = self._agent._clock.now()
        since, window_start = self._resolve_window(window, now)
        window_end = now

        agg = await self._agent._backend.cost_summary_aggregate(
            agent_id=self._agent._agent_id,
            since=since.isoformat() if since is not None else None,
            until=now.isoformat(),
        )

        def _bucket(row: dict[str, Any]) -> CostBucket:
            return CostBucket(
                cost_usd=float(row.get("cost_usd", 0.0)),
                input_tokens=int(row.get("input_tokens", 0)),
                output_tokens=int(row.get("output_tokens", 0)),
                calls=int(row.get("calls", 0)),
            )

        return CostSummary(
            total_usd=float(agg["total_cost_usd"]),
            total_tokens=int(agg["total_input_tokens"])
            + int(agg["total_output_tokens"]),
            total_input_tokens=int(agg["total_input_tokens"]),
            total_output_tokens=int(agg["total_output_tokens"]),
            total_calls=int(agg["total_calls"]),
            by_category={
                cat: _bucket(row) for cat, row in agg["by_category"].items()
            },
            by_model={
                model: _bucket(row) for model, row in agg["by_model"].items()
            },
            window_start=window_start,
            window_end=window_end,
        )

    @sync_twin
    async def estimate_dream(
        self,
        *,
        depth: str = "standard",
        lookback_days: int = 14,
    ) -> Any:
        """Estimate the USD / token footprint of the next dream cycle.

        Projects forward from the last ``lookback_days`` of dream cycles.
        Returns a :class:`CostEstimate` with a confidence tier that
        reflects sample size. Budget-aware callers should compare the
        ``estimated_usd`` against remaining budget before triggering.
        """
        from wisdom_layer.types import CostEstimate

        self._agent._require_feature("cost_visibility", "Pro")

        now = self._agent._clock.now()
        since = (now - timedelta(days=lookback_days)).isoformat()
        rows = await self._agent._backend.query_cost_records(
            agent_id=self._agent._agent_id,
            since=since,
        )
        # Group by cycle_id — cycles without one are ad-hoc calls we
        # don't want to roll into a dream average.
        per_cycle: dict[str, dict[str, float]] = {}
        for row in rows:
            cid = row.get("cycle_id")
            category = str(row.get("category") or "")
            if not cid or not category.startswith("dream."):
                continue
            bucket = per_cycle.setdefault(
                cid, {"usd": 0.0, "tokens": 0.0},
            )
            bucket["usd"] += float(row.get("cost_usd", 0.0))
            bucket["tokens"] += (
                float(row.get("input_tokens", 0))
                + float(row.get("output_tokens", 0))
            )

        sample = list(per_cycle.values())
        sample_size = len(sample)
        if sample_size == 0:
            return CostEstimate(
                estimated_usd=0.0,
                estimated_tokens=0,
                confidence="low",
                sample_size=0,
                window_days=lookback_days,
            )
        avg_usd = sum(b["usd"] for b in sample) / sample_size
        avg_tokens = int(sum(b["tokens"] for b in sample) / sample_size)
        confidence: str = "low"
        if sample_size >= 5:
            confidence = "high"
        elif sample_size >= 2:
            confidence = "medium"

        # Depth multiplier — "deep" runs cost more, "light" less. These
        # are coarse heuristics; callers who care should look at
        # cost_breakdown from recent reports.
        multipliers = {"light": 0.5, "standard": 1.0, "deep": 2.0}
        mult = multipliers.get(depth, 1.0)
        return CostEstimate(
            estimated_usd=avg_usd * mult,
            estimated_tokens=int(avg_tokens * mult),
            confidence=confidence,  # type: ignore[arg-type]
            sample_size=sample_size,
            window_days=lookback_days,
        )

    @sync_twin
    async def export(
        self,
        *,
        since: str | None = None,
        until: str | None = None,
    ) -> str:
        """Return the cost ledger as CSV text (Enterprise only).

        Header: ``created_at,model_id,category,input_tokens,output_tokens,
        cost_usd,cycle_id,event_id,purpose``.

        Raises:
            TierRestrictionError: current tier lacks ``cost_export``.
            FeatureDisabledError: ``cost_export`` flag is off.
        """
        self._agent._require_feature("cost_export", "Enterprise")

        import csv
        import io

        rows = await self._agent._backend.query_cost_records(
            agent_id=self._agent._agent_id,
            since=since,
            until=until,
        )
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow([
            "created_at", "model_id", "category",
            "input_tokens", "output_tokens", "cost_usd",
            "cycle_id", "event_id", "purpose",
        ])
        for row in rows:
            writer.writerow([
                row.get("created_at", ""),
                row.get("model_id", ""),
                row.get("category", ""),
                row.get("input_tokens", 0),
                row.get("output_tokens", 0),
                f'{float(row.get("cost_usd", 0.0)):.6f}',
                row.get("cycle_id") or "",
                row.get("event_id") or "",
                row.get("purpose", ""),
            ])
        return buf.getvalue()

    @staticmethod
    def _resolve_window(
        window: str | timedelta | None,
        now: datetime,
    ) -> tuple[datetime | None, datetime | None]:
        """Convert ``window`` into an (inclusive) since bound."""
        if window is None:
            delta = timedelta(days=7)
        elif isinstance(window, timedelta):
            delta = window
        else:
            if window == "all":
                return None, None
            shortcuts = {
                "1d": timedelta(days=1),
                "7d": timedelta(days=7),
                "30d": timedelta(days=30),
                "24h": timedelta(hours=24),
            }
            if window not in shortcuts:
                msg = (
                    f"Unknown cost window '{window}'. "
                    "Use '1d', '7d', '30d', 'all', or a timedelta."
                )
                raise ValueError(msg)
            delta = shortcuts[window]
        since = now - delta
        return since, since


class WisdomAgent:
    """A wisdom-capable AI agent.

    This is the primary entry point for the Wisdom Layer SDK.
    Initialize with an explicit ``agent_id``, an :class:`AgentConfig`,
    an LLM adapter, and a storage backend.

    ``agent_id`` is the deployment/tenancy identity — the stable key under
    which every memory, directive, proposal, and dream cycle is scoped.
    It is deliberately separate from :class:`AgentConfig`, which carries
    personality (name, role, directives). Two agents with the same config
    but different ``agent_id`` values are isolated tenants sharing no data.

    ``agent_id`` is required. There is no silent default — explicit identity
    at init time is the contract, because silent defaults hide observability
    and tenancy blindspots.

    Example::

        from wisdom_layer import WisdomAgent, AgentConfig
        from wisdom_layer.llm.anthropic import AnthropicAdapter
        from wisdom_layer.storage.sqlite import SQLiteBackend

        agent = WisdomAgent(
            agent_id="support-agent-prod",
            config=AgentConfig(
                name="Support Agent",
                role="Customer support specialist",
                directives=["Always verify identity before accessing accounts"],
                # Pro key required for directives. Get one at
                # https://wisdomlayer.ai/pricing.
                api_key=os.environ["WISDOM_LAYER_LICENSE"],
            ),
            model=AnthropicAdapter(api_key="sk-ant-..."),
            backend=SQLiteBackend("./agent.db"),
        )

        # Capture an event — scoped to agent_id="support-agent-prod"
        await agent.memory.capture("conversation", {"user": "...", "agent": "..."})

        # Search memories — only this agent's data
        results = await agent.memory.search("refund policy")

        # Evaluate output
        review = await agent.critic.evaluate("I'll process your refund...")
    """

    def __init__(
        self,
        *,
        agent_id: str | None = None,
        name: str | None = None,
        config: AgentConfig | None = None,
        llm: BaseLLMAdapter | None = None,
        model: BaseLLMAdapter | None = None,
        backend: BaseBackend | None = None,
        storage: BaseBackend | None = None,
        clock: Clock | None = None,
        budget_guard: BudgetGuard | None = None,
    ) -> None:
        # Resolve LLM (accept either ``llm=`` or ``model=``; ``llm=`` is
        # the canonical v0.4 name, ``model=`` is kept for back-compat).
        resolved_llm = llm if llm is not None else model
        if resolved_llm is None:
            msg = (
                "WisdomAgent requires an LLM adapter (llm=... or model=...). "
                "See examples/quickstart_local.py for how to wire one."
            )
            raise ValueError(msg)

        # Resolve config: explicit > for_prod when ENV=production > for_dev.
        resolved_config = config if config is not None else _default_config(name=name)
        if name is not None and not config:
            # When ``name=`` is the shortcut, honor it on the preset.
            resolved_config = resolved_config.model_copy(update={"name": name})

        # Resolve agent_id: explicit > config.name. Empty agent_id is a
        # deliberate rejection — silent defaults hide tenancy blindspots.
        if agent_id is not None and not agent_id:
            msg = (
                "WisdomAgent requires a non-empty agent_id. "
                "Silent defaults hide tenancy and observability blindspots."
            )
            raise ValueError(msg)
        resolved_agent_id = agent_id or resolved_config.name
        if not resolved_agent_id:
            msg = (
                "WisdomAgent requires an agent_id or a name. "
                "Silent defaults hide tenancy and observability blindspots."
            )
            raise ValueError(msg)

        # Resolve backend: explicit ``backend=`` > ``storage=`` > warn + :memory:.
        resolved_backend = backend if backend is not None else storage
        if resolved_backend is None:
            from wisdom_layer.storage.sqlite import SQLiteBackend

            logger.warning(
                "WisdomAgent started without a storage backend; using "
                "in-memory SQLite. Memories will NOT persist past this "
                "process. Pass storage=SQLiteBackend('./agent.db') to "
                "persist.",
            )
            # bind_embedder() in initialize() wires the adapter's embed
            # callable into the backend — no need to plumb embed_fn here.
            resolved_backend = SQLiteBackend(":memory:")

        self._agent_id = resolved_agent_id
        self._config = resolved_config
        self._admin = resolved_config.admin_defaults  # T2 profile (cached for hot-path reads)
        self._model = resolved_llm
        self._backend = resolved_backend
        self._clock: Clock = clock or SystemClock()
        # Tier storage — see ``_tier`` property. ``_tier_contract`` holds
        # the contracted tier (parsed from the key prefix at construction;
        # refreshed from cryptographically-verified claims in
        # ``initialize()``). ``_claims`` carries the full
        # :class:`EntitlementClaims` (signed tokens only) so the trial
        # mechanic — which makes the *effective* tier time-dependent —
        # can be honored without re-verifying the JWT on every call.
        self._tier_contract: Tier = parse_key_tier(resolved_config.api_key)
        self._claims: EntitlementClaims | None = None
        self._validated = False
        self._budget_guard: BudgetGuard | None = budget_guard
        # v0.5 Phase 4: ambient cycle_id set during dream.trigger so any
        # nested LLM calls (critic.audit, journal synthesis) attribute
        # their cost rows to the running cycle without threading the id
        # through every call site.
        self._active_cycle_id: str | None = None
        self._active_dream_tasks: set[asyncio.Task] = set()  # type: ignore[type-arg]
        self._active_reinforce_tasks: set[asyncio.Task] = set()  # type: ignore[type-arg]
        # v1.0 Beta: background fact extraction tasks. Spawned by the
        # ``memory.captured`` subscriber (see ``_subscribe_fact_extractor``)
        # when ``AdminDefaults.enable_fact_extraction`` is True. Drained
        # in ``close()`` so we never write through a closed backend.
        self._active_fact_tasks: set[asyncio.Task] = set()  # type: ignore[type-arg]
        # v1.2.0 Multi-B: workspace back-reference. Set by
        # :meth:`Workspace.register_agent` when this agent joins a
        # multi-agent workspace; cleared by :meth:`Workspace.unregister_agent`.
        # ``agent.memory.share()`` and ``agent.provenance.walk_xagent()``
        # check this slot and raise a clear error pointing at
        # ``workspace.register_agent(agent)`` when unset — never auto-bond,
        # never fail silently.
        self._workspace: Workspace | None = None
        # v0.4 init-time validation (raises ConfigError on mismatch).
        _validate_agent_wiring(config=resolved_config, llm=resolved_llm, tier=self._tier)

        # ----- BUSINESSFY 7.7 — tier-cap & telemetry plumbing -------------
        # Resolve the on-disk root once so install_id, the agent registry,
        # and the rolling-30-day usage counter all anchor to the same
        # location. ``WL_DATA_DIR`` overrides the default (used by tests
        # via ``tmp_path``).
        self._data_dir: Path = _resolve_data_dir()
        # One-shot guard for the per-cap "you're at N% of the Free cap"
        # warnings. Keys are the cap_kind constants from ``errors.py``
        # so a single source of truth governs both the warning side and
        # the error side. ``set[str]`` rather than per-threshold tracking
        # is the simplest contract that matches the doc: "warning at 80%
        # is one-shot per cap per session." Multiple thresholds get
        # de-duped via ``(cap_kind, threshold)`` tuples below.
        self._cap_warning_emitted: set[tuple[str, float]] = set()
        # Idempotency guard for ``close()``. Users routinely call
        # ``close()`` from a ``finally`` block AND from an explicit
        # shutdown path; a second invocation must be a clean no-op
        # rather than re-firing telemetry against a closed backend
        # (which would publish a zeroed snapshot) or re-emitting
        # ``agent.closed`` to subscribers.
        self._closed: bool = False
        # Lazily constructed in ``initialize()`` once we know the
        # final on-disk paths and have a chance to run async setup.
        self._usage_counter: UsageCounter | None = None
        self._telemetry_client: _telemetry.TelemetryClient | None = None
        self._install_id: str = ""
        # Anonymous Free / paid alike — every install gets a stable UUID
        # and (on first run only) a one-time INFO disclosure. Disclosure
        # is structurally coupled to file creation in
        # ``read_or_create_install_id_with_disclosure`` so it cannot
        # silently regress. Failures here are non-fatal — telemetry
        # never blocks agent construction.
        try:
            self._install_id = (
                _telemetry.read_or_create_install_id_with_disclosure(
                    install_id_dir=self._data_dir,
                    tier=self._tier_contract.value,
                )
            )
        except OSError:
            logger.debug(
                "Could not persist install_id; telemetry will be disabled",
                extra={"agent_id": resolved_agent_id},
            )
            self._install_id = ""
        # Per-license, per-machine roster of distinct agent IDs. Cap
        # check fires for Free + anonymous Free; Pro / Enterprise / Trial
        # tiers are unbounded. ``would_exceed_cap`` is idempotent — an
        # already-registered agent_id never raises, which means an
        # agent that already exists on disk can be re-constructed
        # safely (e.g., for a reload).
        registry_dir = self._data_dir / "agents"
        self._agent_registry = AgentRegistry(
            api_key=resolved_config.api_key,
            registry_dir=registry_dir,
        )
        if self._tier == Tier.FREE:
            limit = resolved_config.resource_limits.max_agents_free
            if self._agent_registry.would_exceed_cap(
                resolved_agent_id, limit=limit,
            ):
                current = self._agent_registry.count()
                raise TierRestrictionError(
                    cap_kind=CAP_KIND_AGENTS,
                    current=current,
                    limit=limit,
                    upgrade_url=(
                        "https://wisdomlayer.ai/pricing?from=cap_agents"
                    ),
                )
        # Always register — Pro/Enterprise/Trial agents still occupy a
        # slot so a downgrade later does not silently grant unlimited
        # legacy agents. Idempotent on re-registration.
        self._agent_registry.register(resolved_agent_id)
        # ----- end BUSINESSFY 7.7 init plumbing ---------------------------

        # Event bus — one per agent, all subscriptions go through here
        self._events = EventEmitter(clock=self._clock)

        # Public interfaces
        self.memory = MemoryInterface(self)
        self.dreams = DreamsInterface(self)
        self.critic = CriticInterface(self)
        self.directives = DirectivesInterface(self)
        self.journals = JournalsInterface(self)
        self.analytics = AnalyticsInterface(self)
        self.provenance = ProvenanceInterface(self)
        self.messages = MessagesInterface(self)
        self.health = HealthInterface(self)
        self.cost = CostInterface(self)
        self.facts = FactsInterface(self)

        # v1.0 Beta: subscribe the background fact extractor. The handler
        # itself checks ``enable_fact_extraction`` and the tier feature,
        # so subscribing unconditionally is cheap — no work runs unless
        # the user opted in.
        self._subscribe_fact_extractor()

        logger.info(
            "WisdomAgent initialized",
            extra={
                "subsystem": "agent",
                "agent_id": self._agent_id,
                "agent_name": resolved_config.name,
                "tier": self._tier.value,
                "role": resolved_config.role,
            },
        )

    @property
    def _tier(self) -> Tier:
        """Effective tier in force *right now*.

        Reads from cryptographically-verified
        :class:`EntitlementClaims` when available so the trial mechanic
        — which makes Pro features available until ``trial_ends_at``
        and then falls back to ``tier_at_expiry`` — is honored
        automatically at every gate. When no claims are present
        (anonymous Free, legacy random-hex keys, or pre-trial-mechanic
        signed tokens), returns the contracted tier parsed from the
        key prefix.

        Recomputed on each access against the injected
        :class:`Clock`, so a long-running process whose trial expires
        mid-session correctly downgrades on the next gated call (per
        ``BUSINESSFY/06_CAP_ENFORCEMENT_UX.md`` § "Trial expiry
        mid-task grace": entry-points re-check, in-flight calls do
        not).
        """
        if self._claims is None:
            return self._tier_contract
        return Tier(self._claims.effective_tier(self._clock.now()))

    @sync_twin
    async def initialize(self) -> None:
        """Validate license and initialize storage.

        Call this after construction to validate the license key
        and set up the storage backend. Emits ``agent.initialized``
        on success. Also wires up the dream scheduler, restoring any
        persisted schedule and spawning the background task.

        Eagerly warms the LLM adapter (e.g., loading the local embedding
        model used by Anthropic / OpenAI / Gemini adapters) so the first
        ``memory.capture`` / ``memory.search`` doesn't pay a 5-30 s
        cold-load cliff on the user's hot path. Adapters without lazy
        resources no-op the warmup call.

        After warmup, threads the adapter's ``embedding_model_id`` and
        ``embedding_dim`` into the backend via
        :meth:`BaseBackend.bind_embedder`. This is what couples
        ``model.embedding_model="..."`` to the storage layer's per-row
        identity tags so users do not have to keep three knobs in sync.
        Disagreement between an explicit backend override and the
        adapter raises :class:`EmbeddingConfigMismatchError` here, before
        a single memory is written.
        """
        # ``validate_license_full`` returns both the tier *and* the
        # parsed entitlement claims. Storing the claims is what enables
        # the trial mechanic: ``self._tier`` becomes a function of
        # ``claims.effective_tier(clock.now())`` rather than a static
        # tier captured at validate-time.
        contract_tier, claims = await validate_license_full(
            self._config.api_key,
        )
        self._tier_contract = contract_tier
        self._claims = claims
        self._validated = True
        await self._backend.initialize()
        await self._model.warmup()
        await self._backend.bind_embedder(self._model)

        # Rolling 30-day message-ingress counter. Anchored to the same
        # data dir as install_id and the agent registry, sharded by
        # license fingerprint so multiple licenses on the same machine
        # do not cross-pollute their counters.
        usage_dir = self._data_dir / "usage"
        usage_dir.mkdir(parents=True, exist_ok=True)
        from wisdom_layer._internal.agent_registry import fingerprint as _fp

        self._usage_counter = UsageCounter(
            db_path=usage_dir / f"{_fp(self._config.api_key)}.db",
            clock=self._clock,
        )

        # Telemetry client — opt-out on Free / anonymous, opt-in on
        # Pro / Enterprise. Construction is unconditional; the actual
        # send-on-close decision happens in ``close()`` based on
        # ``_telemetry.should_enable``. Failures during snapshot or
        # send are silent by design (see ``_telemetry.TelemetryClient``).
        self._telemetry_client = _telemetry.TelemetryClient(
            endpoint=_telemetry.get_endpoint(),
        )

        scheduler = DreamScheduler(
            self, budget_guard=self._budget_guard,
        )
        self.dreams._scheduler = scheduler
        await scheduler.initialize()

        logger.info(
            "WisdomAgent ready",
            extra={
                "subsystem": "agent",
                "agent_id": self._agent_id,
                "agent_name": self._config.name,
                "tier": self._tier.value,
            },
        )
        await self._emit(
            "agent.initialized",
            priority=EventPriority.CRITICAL,
            data={
                "backend": type(self._backend).__name__,
                "tier": self._tier.value,
            },
        )

    async def _retryable_generate(self, **kwargs: Any) -> str:
        """Call ``self._model.generate()`` with retry if configured."""
        from wisdom_layer.llm.retry import with_retry

        policy = self._config.retry_policy
        if policy is None:
            return await self._model.generate(**kwargs)
        return await with_retry(
            policy,
            lambda: self._model.generate(**kwargs),
            emit=self._emit,
        )

    async def _retryable_generate_structured(self, **kwargs: Any) -> dict[str, Any]:
        """Call ``self._model.generate_structured()`` with retry if configured."""
        from wisdom_layer.llm.retry import with_retry

        policy = self._config.retry_policy
        if policy is None:
            return await self._model.generate_structured(**kwargs)
        return await with_retry(
            policy,
            lambda: self._model.generate_structured(**kwargs),
            emit=self._emit,
        )

    @sync_twin
    async def close(self) -> None:
        """Shut down the agent gracefully.

        1. Cancel the dream scheduler.
        2. Wait for in-flight dream tasks (up to ``shutdown_timeout_s``).
        3. Close the backend connection.
        4. Emit ``agent.closed``.

        Safe to call multiple times — the second invocation short-circuits
        before sending telemetry or emitting events, since a closed
        backend cannot produce accurate counts and re-emitting
        ``agent.closed`` would double-fire on subscribers that watch
        for shutdown.
        """
        if self._closed:
            return
        self._closed = True
        # 1. Stop scheduler
        scheduler = self.dreams._scheduler
        self.dreams._scheduler = None
        if scheduler is not None:
            await scheduler.close()

        # 2. Wait for in-flight dreams
        if self._active_dream_tasks:
            timeout = self._config.shutdown_timeout_s
            done, pending = await asyncio.wait(
                self._active_dream_tasks, timeout=timeout,
            )
            if pending:
                logger.warning(
                    "Shutdown: %d dream tasks timed out after %.1fs",
                    len(pending),
                    timeout,
                    extra={"agent_id": self._agent_id},
                )
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
            self._active_dream_tasks.clear()

        # 2b. Drain in-flight reinforcement writes so they don't hit a closed
        # backend. These are short-lived best-effort writes; reuse the
        # configured shutdown timeout, capped at 5s so a slow reinforce can't
        # extend shutdown beyond what the dream drain already allowed.
        if self._active_reinforce_tasks:
            reinforce_timeout = min(self._config.shutdown_timeout_s, 5.0)
            done, pending = await asyncio.wait(
                self._active_reinforce_tasks, timeout=reinforce_timeout,
            )
            if pending:
                logger.warning(
                    "Shutdown: %d reinforce tasks timed out after %.1fs",
                    len(pending),
                    reinforce_timeout,
                    extra={"agent_id": self._agent_id},
                )
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
            self._active_reinforce_tasks.clear()

        # 2c. Drain in-flight fact extraction tasks for the same reason —
        # they're best-effort writes that must not be observed mid-flight
        # by a closed backend.
        if self._active_fact_tasks:
            fact_timeout = min(self._config.shutdown_timeout_s, 5.0)
            done, pending = await asyncio.wait(
                self._active_fact_tasks, timeout=fact_timeout,
            )
            if pending:
                logger.warning(
                    "Shutdown: %d fact extraction tasks timed out after %.1fs",
                    len(pending),
                    fact_timeout,
                    extra={"agent_id": self._agent_id},
                )
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
            self._active_fact_tasks.clear()

        # 2d. Telemetry batch — fire-and-forget aggregate counts.
        # Runs *before* backend close so the count queries still have a
        # live connection. The send itself is fire-and-forget: we wrap
        # it in a try/except that swallows everything (the client
        # already swallows network errors; this catches the snapshot
        # construction path too). The decision to actually send is
        # gated by ``_telemetry.should_enable`` against the *contract*
        # tier (not the trial-effective one) so trial users do not
        # silently flip to opt-in for the trial duration.
        await self._maybe_send_telemetry_batch()

        # 3. Close backend
        close_fn = getattr(self._backend, "close", None)
        if close_fn is not None:
            try:
                await close_fn()
            except Exception:
                logger.exception(
                    "WisdomAgent.close: backend close failed",
                    extra={"agent_id": self._agent_id},
                )

        # 4. Emit closed event
        with contextlib.suppress(Exception):
            await self._emit(
                "agent.closed",
                priority=EventPriority.CRITICAL,
                data={"agent_id": self._agent_id},
            )

    async def _maybe_send_telemetry_batch(self) -> None:
        """Build and send a single telemetry snapshot. Never raises.

        Called from :meth:`close` while the backend connection is still
        live. Skipped entirely when:

        * The telemetry client could not be constructed (init failed).
        * The install_id could not be persisted (disclosure could not
          fire — sending without disclosure would be a privacy
          regression).
        * :func:`_telemetry.should_enable` returns False for the
          contract tier (Pro / Enterprise without explicit
          ``WL_TELEMETRY=1``).

        Counts are collected best-effort: a per-source try/except
        prevents one missing surface (e.g. a backend that doesn't
        implement ``get_agent_counts``) from sinking the whole batch.
        """
        client = self._telemetry_client
        if client is None or not self._install_id:
            return
        if not _telemetry.should_enable(self._tier_contract.value):
            return

        # Best-effort per-surface count collection. The snapshot is
        # already an aggregate, so a missing surface degrades to zero
        # on that field rather than propagating the error.
        memory_count = 0
        directive_count = 0
        with contextlib.suppress(Exception):
            counts = await self._backend.get_agent_counts(
                agent_id=self._agent_id,
            )
            memory_count = int(counts.get("memories", 0))
            directive_count = int(counts.get("directives", 0))

        msg_count_30d = 0
        if self._usage_counter is not None:
            with contextlib.suppress(Exception):
                msg_count_30d = self._usage_counter.message_count_30d()

        agent_count = 0
        with contextlib.suppress(Exception):
            agent_count = self._agent_registry.count()

        from wisdom_layer import __version__ as _sdk_version

        snapshot = _telemetry.build_snapshot(
            install_id=self._install_id,
            version=_sdk_version,
            tier=self._tier_contract.value,
            counts=_telemetry.CountSnapshot(
                agent_count=agent_count,
                memory_count=memory_count,
                msg_count_30d=msg_count_30d,
                # fact_count and dream_cycles_count are not surfaced by
                # ``get_agent_counts`` today; they remain at zero until
                # the backend interface grows the counters. Telemetry
                # consumers tolerate zero rather than missing fields.
                fact_count=0,
                dream_cycles_count=0,
                directive_count=directive_count,
            ),
            clock=self._clock,
        )
        # Fire-and-forget. ``send_batch`` already swallows everything;
        # this contextlib.suppress is belt-and-braces against an
        # unexpected synchronous raise inside the build path.
        with contextlib.suppress(Exception):
            await client.send_batch(snapshot)

    async def _record_llm_usage(
        self,
        *,
        category: str,
        cycle_id: str | None = None,
        event_id: str | None = None,
        purpose: str = "",
    ) -> None:
        """Append the last LLM call's usage to the cost ledger.

        v0.5 Phase 4. Reads ``self._model.last_usage`` (populated by
        adapters after ``generate``/``generate_structured``) and writes
        one row to ``cost_records``. Best-effort — persistence failures
        are logged but do not propagate, because cost auditing must
        never break the primary pipeline.
        """
        usage = getattr(self._model, "last_usage", None)
        if usage is None:
            return
        effective_cycle_id = cycle_id if cycle_id is not None else self._active_cycle_id
        try:
            import uuid as _uuid

            await self._backend.append_cost_record(
                record_id=_uuid.uuid4().hex,
                agent_id=self._agent_id,
                model_id=usage.model_id,
                category=category,
                input_tokens=int(usage.input_tokens),
                output_tokens=int(usage.output_tokens),
                cost_usd=float(usage.cost_usd),
                cycle_id=effective_cycle_id,
                event_id=event_id,
                purpose=purpose,
                created_at=self._clock.now().isoformat(),
            )
        except Exception:
            logger.warning(
                "Cost ledger write failed",
                extra={
                    "agent_id": self._agent_id,
                    "category": category,
                    "cycle_id": cycle_id,
                },
            )
        # v0.5 Phase 4 — BudgetGuard enforcement. After the write we ask
        # the guard to re-evaluate daily / monthly totals against the
        # ledger. If a cap is blown, the guard trips cooldown and raises
        # so the caller sees the breach on the first over-cap call.
        guard = self._budget_guard
        if guard is not None:
            await guard.enforce_from_backend(
                agent_id=self._agent_id,
                backend=self._backend,
                clock_now=self._clock.now(),
            )

    # -- Fact extraction (v1.0 Beta) -----------------------------------------

    def _subscribe_fact_extractor(self) -> None:
        """Wire the background ``memory.captured`` → fact extraction handler.

        Always subscribes; the handler short-circuits when the feature
        is off so opt-in cost is exactly one event-bus dispatch with no
        LLM call. Spawns a background task per qualifying capture and
        tracks it in ``_active_fact_tasks`` so ``close()`` can drain it.
        """

        async def _handle_memory_captured(event: Event) -> None:
            # Cheapest checks first: opt-in flag, then tier feature.
            if not self._admin.enable_fact_extraction:
                return
            if not has_feature(self._tier, "fact_extraction"):
                return

            memory_id = event.data.get("memory_id")
            if not isinstance(memory_id, str) or not memory_id:
                return
            # Skip dedup'd captures — the canonical memory already produced
            # facts on its first sighting and re-extracting from the dup
            # would double-count without adding signal.
            if event.data.get("dedup_of"):
                return

            task = asyncio.create_task(self._extract_facts_for_memory(memory_id))
            self._active_fact_tasks.add(task)
            task.add_done_callback(self._active_fact_tasks.discard)

        self._events.on("memory.captured", _handle_memory_captured)

    async def _extract_facts_for_memory(
        self,
        memory_id: str,
    ) -> list[dict[str, object]]:
        """Run the fact extraction pipeline against ``memory_id``.

        Thin wrapper around :func:`wisdom_layer.facts.extract_facts_for_memory`
        — kept on the agent so callers (the on-demand
        ``FactsInterface.extract`` and the background subscriber) share
        a single integration point and so future overrides (mocking in
        tests, additional cost accounting) have one place to land.
        """
        return await extract_facts_for_memory(self, memory_id)

    # Feature string → FeatureFlags attribute name. One-directional:
    # only features that have a corresponding FeatureFlag are mapped.
    # Unmapped features (e.g. "tier3_memory", "basic_stats") skip
    # the flag check entirely.
    _FEATURE_TO_FLAG: dict[str, str] = {
        "dream_cycles": "dreams",
        "scheduled_dreams": "scheduled_dreams",
        "critic": "critic",
        "directive_evolution": "directives",
        "provenance": "provenance",
        "provenance_trace": "provenance_trace",
        "provenance_explain": "provenance_explain",
        "provenance_export": "provenance_export",
        "standard_analytics": "health_analytics",
        "cost_visibility": "cost_visibility",
        "cost_budget": "cost_budget",
        "cost_export": "cost_export",
    }

    def _require_feature(self, feature: str, required_tier: str) -> None:
        """Gate a feature behind tier + FeatureFlags check.

        Check order: tier first (are you allowed?), then flag (did you
        opt out?). This ensures error messages are accurate — a free-tier
        user sees ``TierRestrictionError``, not ``FeatureDisabledError``.

        Args:
            feature: Feature identifier from TIER_FEATURES.
            required_tier: Human-readable tier name for error message.

        Raises:
            TierRestrictionError: If the current tier lacks the feature.
            FeatureDisabledError: If the tier grants access but the user
                has opted out via ``feature_flags``.
        """
        if not has_feature(self._tier, feature):
            raise TierRestrictionError(feature, required_tier)
        flag_name = self._FEATURE_TO_FLAG.get(feature)
        if flag_name is not None and not getattr(
            self._config.feature_flags, flag_name, True
        ):
            raise FeatureDisabledError(feature, flag_name)

    def _maybe_emit_cap_warning(
        self, *, cap_kind: str, current: int, limit: int,
    ) -> None:
        """Emit a one-shot proactive warning as usage crosses a threshold.

        Driven by :attr:`AdminDefaults.cap_warning_thresholds` — a tuple
        of fractions (default ``(0.80,)``) at which the agent logs a
        single INFO line nudging the user toward upgrade. Each
        ``(cap_kind, threshold)`` fires at most once per process via
        :attr:`_cap_warning_emitted`, so a long-running agent does not
        spam the log on every capture once the threshold is crossed.

        Free / anonymous Free only — Pro / Enterprise / Trial skip the
        check entirely (their effective ``limit`` is unbounded so no
        threshold is ever met). When ``limit`` is zero or negative the
        helper short-circuits to avoid divide-by-zero on a misconfigured
        ResourceLimits.
        """
        if limit <= 0:
            return
        ratio = current / limit
        for threshold in self._admin.cap_warning_thresholds:
            if ratio < threshold:
                continue
            key = (cap_kind, threshold)
            if key in self._cap_warning_emitted:
                continue
            self._cap_warning_emitted.add(key)
            logger.info(
                "Approaching Free-tier %s cap (%d / %d, %.0f%%). "
                "Upgrade at https://wisdomlayer.ai/pricing?from=cap_%s",
                cap_kind,
                current,
                limit,
                ratio * 100.0,
                cap_kind,
                extra={
                    "agent_id": self._agent_id,
                    "cap_kind": cap_kind,
                    "current": current,
                    "limit": limit,
                    "threshold": threshold,
                },
            )

    # -- Sessions -------------------------------------------------------------

    async def session(
        self,
        session_id: str | None = None,
        *,
        ephemeral: bool | None = None,
        scope: str = "long_term",
        ttl_hours: int = 0,
    ) -> _SessionContextWrapper:
        """Create a session context manager.

        Usage::

            async with agent.session("chat-123") as s:
                await s.capture("conversation", {"text": "hello"})
                results = await s.search("hello")

        Sessions are optional by default. ``require_session_for_capture``
        must be explicitly enabled in ``SessionConfig``.

        Args:
            session_id: Unique session identifier. Auto-generated if ``None``.
            ephemeral: If True, captures are suppressed (no DB writes,
                no reinforcement). Defaults to ``SessionConfig.ephemeral_default``.
            scope: Scope label for captured memories (default ``long_term``).
            ttl_hours: TTL for session-scoped memories (0 = no expiry).
                Advisory only in Phase A — persisted but not yet enforced.

        Returns:
            An async context manager that yields a ``SessionHandle``.
        """
        import uuid

        sid = session_id or uuid.uuid4().hex[:12]
        eph = ephemeral if ephemeral is not None else self._config.session.ephemeral_default

        handle = SessionHandle(
            session_id=sid,
            ephemeral=eph,
            scope=scope,
            ttl_hours=ttl_hours,
            _agent=self,
        )

        # Emit session_started event
        await self._emit(
            "memory.session_started",
            data={
                "session_id": sid,
                "ephemeral": eph,
                "scope": scope,
            },
        )

        # Wrap the handle to emit session_ended on exit
        return _SessionContextWrapper(handle=handle, agent=self)

    #: Maximum age accepted by ``created_at=`` overrides on capture.
    #: Bounds the migration import use case — anything older than this
    #: is almost certainly a timezone or epoch error rather than real
    #: historical data, and we'd rather raise than silently corrupt
    #: the temporal model.
    _MAX_HISTORICAL_AGE_DAYS: ClassVar[int] = 365 * 10

    def _validate_created_at(self, created_at: datetime) -> datetime:
        """Validate a user-supplied ``created_at`` for memory.capture().

        Raises ``ValueError`` if naive, in the future (per the agent's
        clock), or older than ``_MAX_HISTORICAL_AGE_DAYS``. Returns the
        value unchanged on success so callers can use the result inline.
        """
        if created_at.tzinfo is None:
            msg = (
                "created_at= must be timezone-aware (UTC recommended). "
                "Naive datetimes are rejected to avoid timezone drift "
                "during migration imports."
            )
            raise ValueError(msg)
        now = self._clock.now()
        if created_at > now:
            msg = (
                f"created_at={created_at.isoformat()} is in the future "
                f"(now={now.isoformat()}). Future timestamps are rejected."
            )
            raise ValueError(msg)
        max_age = timedelta(days=self._MAX_HISTORICAL_AGE_DAYS)
        if now - created_at > max_age:
            msg = (
                f"created_at={created_at.isoformat()} is older than "
                f"{self._MAX_HISTORICAL_AGE_DAYS} days. Suspected "
                f"timezone or epoch error; rejected."
            )
            raise ValueError(msg)
        return created_at

    async def _do_capture(
        self,
        *,
        event_type: str,
        content: dict[str, object],
        emotional_intensity: float = 0.0,
        session_id: str | None = None,
        scope: str = "long_term",
        ttl_hours: int = 0,
        created_at: datetime | None = None,
    ) -> str:
        """Shared capture logic — used by both bare capture and session capture.

        Handles dedup check (gated behind ``FeatureFlags.reconsolidation``)
        and emits ``memory.captured`` / ``memory.dedup_marked`` events.

        On the Free tier this is also where the per-agent memory cap and
        the rolling-30-day message cap fire. Both run *before* the
        backend write so a capped agent never half-stores a memory.
        Pro / Enterprise / Trial skip both checks (their effective tier
        — see ``self._tier`` — exits the Free branch).
        """
        import json

        # ---- Free-tier cap enforcement -----------------------------------
        # Two caps gate ``_do_capture``: per-agent memory count and the
        # rolling 30-day message-ingress count. Both keyed off the
        # *effective* tier (``self._tier`` re-reads claims+clock so a
        # trial that expires mid-session correctly downgrades on the
        # next capture). The 80% warning fires through
        # ``_maybe_emit_cap_warning`` against the *pre-write* number; the
        # hard cap raises through ``require_cap`` which carries the
        # context-tagged upgrade URL.
        if self._tier == Tier.FREE:
            limits = self._config.resource_limits
            counts = await self._backend.get_agent_counts(
                agent_id=self._agent_id,
            )
            current_memories = int(counts.get("memories", 0))
            self._maybe_emit_cap_warning(
                cap_kind=CAP_KIND_MEMORIES,
                current=current_memories,
                limit=limits.max_memories_free,
            )
            require_cap(
                CAP_KIND_MEMORIES,
                current_memories,
                limits.max_memories_free,
                upgrade_url=(
                    "https://wisdomlayer.ai/pricing?from=cap_memories"
                ),
            )

            # Message cap — counter is constructed in ``initialize()``;
            # if missing (e.g. a caller invoked _do_capture pre-init,
            # which the public surface prevents), skip the check
            # rather than crash. The hard cap will fire on the next
            # initialized call.
            if self._usage_counter is not None:
                current_msgs = self._usage_counter.message_count_30d()
                msg_limit = limits.max_messages_per_30d_free
                self._maybe_emit_cap_warning(
                    cap_kind=CAP_KIND_MESSAGES_30D,
                    current=current_msgs,
                    limit=msg_limit,
                )
                require_cap(
                    CAP_KIND_MESSAGES_30D,
                    current_msgs,
                    msg_limit,
                    reset_at=self._usage_counter.reset_at(),
                    upgrade_url=(
                        "https://wisdomlayer.ai/pricing?from=cap_messages_30d"
                    ),
                )

        # Non-destructive dedup check (gated behind reconsolidation flag)
        dedup_of: str | None = None
        if (
            self._config.feature_flags.reconsolidation
            and self._backend._embed_fn is not None  # type: ignore[attr-defined]
        ):
            content_str = json.dumps(content, default=str)
            query_vec = await self._backend._embed_fn(content_str)  # type: ignore[attr-defined]
            dedup_of = await self._backend.find_near_duplicate(
                agent_id=self._agent_id,
                embedding=query_vec,
            )

        memory_id = await self._backend.store_memory(
            agent_id=self._agent_id,
            tier="raw",
            event_type=event_type,
            content=content,
            emotional_intensity=emotional_intensity,
            session_id=session_id,
            scope=scope,
            ttl_hours=ttl_hours,
            dedup_of=dedup_of,
            created_at=created_at,
        )

        # Record one message-ingress event in the rolling 30-day counter.
        # Runs for every tier (the cap only *fires* on Free, but the
        # counter still informs telemetry on Pro/Enterprise). Best-effort:
        # a counter write must never roll back a successful memory store.
        if self._usage_counter is not None:
            try:
                self._usage_counter.increment_message()
            except Exception:
                logger.debug(
                    "usage_counter.increment_message failed",
                    extra={"agent_id": self._agent_id},
                )

        await self._emit(
            "memory.captured",
            data={
                "memory_id": memory_id,
                "memory_type": event_type,
                "emotional_intensity": emotional_intensity,
                "session_id": session_id,
                "dedup_of": dedup_of,
            },
            entity_type="memory",
            entity_id=memory_id,
        )

        if dedup_of:
            await self._emit(
                "memory.dedup_marked",
                data={
                    "memory_id": memory_id,
                    "dedup_of": dedup_of,
                },
                entity_type="memory",
                entity_id=memory_id,
            )

        return memory_id

    async def _session_capture(
        self,
        *,
        event_type: str,
        content: dict[str, object],
        emotional_intensity: float = 0.0,
        session_id: str,
        scope: str = "long_term",
        ttl_hours: int = 0,
        created_at: datetime | None = None,
    ) -> str:
        """Internal: capture within a session context.

        Called by ``SessionHandle.capture()``. Applies memory_mode checks
        then delegates to ``_do_capture()``.
        """
        mode = self._config.lock.memory_mode
        if mode == "read_only":
            await self._emit(
                "memory.capture_suppressed",
                data={
                    "memory_type": event_type,
                    "reason": "memory_mode is read_only",
                    "session_id": session_id,
                },
            )
            raise MemoryFrozenError("capture", mode)

        return await self._do_capture(
            event_type=event_type,
            content=content,
            emotional_intensity=emotional_intensity,
            session_id=session_id,
            scope=scope,
            ttl_hours=ttl_hours,
            created_at=created_at,
        )

    async def _do_consolidate(
        self,
        *,
        limit: int = 0,
        min_salience: float = 0.0,
        lookback_days: int | None = None,
    ) -> dict[str, object]:
        """Internal: run the Tier 2 consolidation pipeline.

        1. Fetch candidates (recency + reinforcement ranked, hard-capped).
        2. Build consolidation prompt and call LLM.
        3. Dedup-check the insight against existing Tier 2 memories.
        4. Store as Tier 2 with provenance and cycle_id.
        5. On failure, rollback all writes for this cycle_id.
        """
        import uuid

        from wisdom_layer._internal.consolidation import (
            build_consolidation_prompt,
            parse_consolidation_output,
        )

        admin = self._admin
        effective_limit = limit or admin.consolidation_max_inputs
        effective_min_salience = min_salience or admin.consolidation_min_salience
        tier2_dedup_threshold = admin.tier2_dedup_threshold
        # Use the active dream cycle ID when called from the dream pipeline so
        # that evolve_directives can find these insights via get_cycle_insights.
        cycle_id = self._active_cycle_id or uuid.uuid4().hex[:12]

        await self._emit(
            "memory.consolidation_started",
            data={
                "cycle_id": cycle_id,
                "limit": effective_limit,
                "min_salience": effective_min_salience,
            },
        )

        try:
            # 1. Fetch candidates
            candidates = await self._backend.get_consolidation_candidates(
                agent_id=self._agent_id,
                limit=effective_limit,
                min_salience=effective_min_salience,
                lookback_days=lookback_days,
            )

            if len(candidates) < 2:
                await self._emit(
                    "memory.consolidation_failed",
                    data={
                        "cycle_id": cycle_id,
                        "reason": "insufficient_candidates",
                        "candidate_count": len(candidates),
                    },
                )
                return {
                    "memory_id": None,
                    "insight": None,
                    "source_ids": [],
                    "cycle_id": cycle_id,
                    "dedup_of": None,
                    "skipped": True,
                    "reason": "insufficient_candidates",
                }

            # 2. Build prompt and call LLM
            system_prompt, messages = build_consolidation_prompt(candidates)
            raw_response = await self._retryable_generate(
                system=system_prompt,
                messages=messages,
            )
            await self._record_llm_usage(
                category="dream.reconsolidate"
                if self._active_cycle_id
                else "reconsolidate",
                purpose="reconsolidate",
            )
            insight_text = parse_consolidation_output(raw_response)
            source_ids = [c["id"] for c in candidates]

            # 3. Dedup-check against existing Tier 2 insights
            dedup_of: str | None = None
            if (
                self._config.feature_flags.reconsolidation
                and self._backend._embed_fn is not None  # type: ignore[attr-defined]
            ):
                import json as _json

                insight_str = _json.dumps(
                    {"insight": insight_text}, default=str
                )
                insight_vec = await self._backend._embed_fn(insight_str)  # type: ignore[attr-defined]
                dedup_of = await self._backend.find_near_duplicate(
                    agent_id=self._agent_id,
                    embedding=insight_vec,
                    threshold=tier2_dedup_threshold,
                )

            # 4. Store as Tier 2 with provenance
            memory_id = await self._backend.store_memory(
                agent_id=self._agent_id,
                tier="consolidated",
                event_type="reconsolidated_insight",
                content={"insight": insight_text},
                source_ids=source_ids,
                cycle_id=cycle_id,
                dedup_of=dedup_of,
            )

            await self._emit(
                "memory.consolidated",
                cycle_id=cycle_id,
                data={
                    "memory_id": memory_id,
                    "cycle_id": cycle_id,
                    "source_count": len(source_ids),
                    "source_ids": source_ids,
                    "dedup_of": dedup_of,
                },
                entity_type="insight",
                entity_id=memory_id,
            )

            if dedup_of:
                await self._emit(
                    "memory.dedup_marked",
                    data={
                        "memory_id": memory_id,
                        "dedup_of": dedup_of,
                    },
                    entity_type="insight",
                    entity_id=memory_id,
                )

            return {
                "memory_id": memory_id,
                "insight": insight_text,
                "source_ids": source_ids,
                "cycle_id": cycle_id,
                "dedup_of": dedup_of,
            }

        except Exception:
            # 5. Rollback all writes for this cycle
            rolled_back = await self._backend.rollback_cycle(
                agent_id=self._agent_id,
                cycle_id=cycle_id,
            )
            await self._emit(
                "memory.consolidation_failed",
                data={
                    "cycle_id": cycle_id,
                    "reason": "exception",
                    "rolled_back": rolled_back,
                },
            )
            raise

    async def _do_import(
        self,
        *,
        memories: list[dict[str, object]],
        re_embed: bool = False,
    ) -> dict[str, object]:
        """Internal: validate, dedup-check, and import memory entries.

        Steps per entry:
        1. Validate required fields (event_type, content).
        2. Optionally re-embed via the backend's embed_fn.
        3. Dedup-check against existing memories.
        4. Store via backend.import_memories().

        Returns import report dict.
        """
        import json as _json

        valid_entries: list[dict[str, object]] = []
        skipped_invalid = 0
        skipped_duplicates = 0
        skipped_dim_mismatch = 0

        for mem in memories:
            # 1. Validate required fields
            if not isinstance(mem, dict):
                skipped_invalid += 1
                continue
            if "event_type" not in mem or "content" not in mem:
                skipped_invalid += 1
                continue
            if not isinstance(mem["content"], dict):
                skipped_invalid += 1
                continue

            # 2. Re-embed if requested
            embedding: list[float] | None = None
            if re_embed and self._backend._embed_fn is not None:  # type: ignore[attr-defined]
                content_str = _json.dumps(mem["content"], default=str)
                vec = await self._backend._embed_fn(content_str)  # type: ignore[attr-defined]
                if len(vec) != self._backend._embedding_dim:  # type: ignore[attr-defined]
                    skipped_dim_mismatch += 1
                    continue
                embedding = vec

            # 3. Dedup-check against existing memories
            if (
                embedding is not None
                and self._config.feature_flags.reconsolidation
            ):
                dup_id = await self._backend.find_near_duplicate(
                    agent_id=self._agent_id,
                    embedding=embedding,
                )
                if dup_id is not None:
                    skipped_duplicates += 1
                    continue

            entry: dict[str, object] = {
                "tier": mem.get("tier", "raw"),
                "event_type": mem["event_type"],
                "content": mem["content"],
                "salience": mem.get("salience", 0.5),
                "emotional_intensity": mem.get("emotional_intensity", 0.0),
                "source_ids": mem.get("source_ids", []),
                "session_id": mem.get("session_id"),
                "scope": mem.get("scope", "long_term"),
                "ttl_hours": mem.get("ttl_hours", 0),
                "created_at": mem.get("created_at"),
            }
            if embedding is not None:
                entry["_embedding"] = embedding
            valid_entries.append(entry)

        # 4. Bulk write
        memory_ids: list[str] = []
        if valid_entries:
            memory_ids = await self._backend.import_memories(
                agent_id=self._agent_id,
                memories=valid_entries,
            )

        await self._emit(
            "memory.imported",
            data={
                "imported": len(memory_ids),
                "skipped_duplicates": skipped_duplicates,
                "skipped_invalid": skipped_invalid,
                "skipped_dim_mismatch": skipped_dim_mismatch,
                "memory_ids": memory_ids,
            },
            entity_type="agent",
            entity_id=self._agent_id,
        )

        return {
            "imported": len(memory_ids),
            "skipped_duplicates": skipped_duplicates,
            "skipped_invalid": skipped_invalid,
            "skipped_dim_mismatch": skipped_dim_mismatch,
            "memory_ids": memory_ids,
        }

    @property
    def agent_id(self) -> str:
        """Stable tenancy identifier for this agent instance.

        Every memory, directive, proposal, and dream cycle stored by
        this agent is scoped to this value. It is set at construction
        and never mutated.
        """
        return self._agent_id

    @property
    def name(self) -> str:
        """Agent name."""
        return self._config.name

    @property
    def tier(self) -> Tier:
        """Current license tier."""
        return self._tier

    @sync_twin
    async def clone(
        self,
        new_agent_id: str,
        *,
        backend: BaseBackend | None = None,
    ) -> WisdomAgent:
        """Return a new :class:`WisdomAgent` sharing this agent's brain.

        When ``backend`` is ``None``, clones within the same storage
        backend using an optimized single-transaction path. When set,
        performs a cross-backend clone via export/import — useful for
        SQLite → Postgres migration or A/B testing across backends.

        Args:
            new_agent_id: Target agent ID. Must be non-empty.
            backend: Target backend for cross-backend clone. If ``None``,
                clones within the current backend.

        Returns:
            A fresh :class:`WisdomAgent` bound to ``new_agent_id``.

        Raises:
            ValueError: If ``new_agent_id`` is empty, equals the current
                agent_id (same-backend only), or already has data.
        """
        if not new_agent_id:
            msg = "clone() requires a non-empty new_agent_id"
            raise ValueError(msg)
        counts = await self._backend.clone_agent(
            src_agent_id=self._agent_id,
            tgt_agent_id=new_agent_id,
            tgt_backend=backend,
        )
        target_backend = backend or self._backend
        logger.info(
            "Agent cloned",
            extra={
                "subsystem": "agent",
                "src_agent_id": self._agent_id,
                "tgt_agent_id": new_agent_id,
                "cross_backend": backend is not None,
                "per_table": counts,
            },
        )
        return WisdomAgent(
            agent_id=new_agent_id,
            config=self._config,
            llm=self._model,
            storage=target_backend,
            clock=self._clock,
        )

    async def _build_health_report(self) -> HealthReport:
        """Compose a :class:`HealthReport` from backend aggregates.

        Internal helper — public callers go through ``agent.health()``
        (the :class:`HealthInterface` callable). Free tier receives
        stats only (no ``wisdom_score``, no ``cognitive_health``
        classification). Pro and Enterprise tiers receive the full
        composite and classifier, with a ``remedy_url`` pointing to
        troubleshooting when the classification is non-healthy.

        The FeatureFlag ``health_analytics`` gates the Pro/Ent surface
        — an operator who has opted out of analytics gets the same
        stats-only shape as free tier, without raising. This is
        consistent with the "opt out quietly" philosophy of the other
        flags (dreams, reconsolidation, etc.).
        """
        stats = await self._backend.get_health_report_stats(
            agent_id=self._agent_id,
        )
        memory = stats["memory"]
        directives = stats["directives"]
        dreams = stats["dreams"]
        cost = stats["cost"]

        memory_stats = MemoryStats(
            stream_count=memory["stream_count"],
            consolidated_count=memory["consolidated_count"],
            journal_count=memory["journal_count"],
            avg_salience=memory["avg_salience"],
            dedup_rate_7d=memory["dedup_rate_7d"],
        )
        directive_stats = DirectiveStats(
            provisional_count=directives["provisional_count"],
            active_count=directives["active_count"],
            permanent_count=directives["permanent_count"],
            demotion_rate_7d=directives["demotion_rate_7d"],
            avg_age_days=directives["avg_age_days"],
        )

        last_run_ago_hours: float | None = None
        last_run_iso = dreams.get("last_run_iso")
        if last_run_iso:
            try:
                last_run = datetime.fromisoformat(last_run_iso)
                if last_run.tzinfo is None:
                    last_run = last_run.replace(tzinfo=UTC)
                last_run_ago_hours = max(
                    (self._clock.now() - last_run).total_seconds() / 3600.0,
                    0.0,
                )
            except (ValueError, TypeError):
                last_run_ago_hours = None

        dream_stats = DreamStats(
            runs_7d=dreams["runs_7d"],
            success_rate_7d=dreams["success_rate_7d"],
            avg_duration_ms=dreams["avg_duration_ms"],
            last_run_ago_hours=last_run_ago_hours,
        )

        avg_tokens_per_dream = (
            cost["dream_tokens_7d"] / dreams["runs_7d"]
            if dreams["runs_7d"] > 0
            else 0.0
        )
        cost_stats = CostStats(
            tokens_7d=cost["tokens_7d"],
            usd_7d=cost["usd_7d"],
            avg_tokens_per_dream=avg_tokens_per_dream,
        )

        # Pro+ composite + classifier — gated by tier AND flag, but
        # silently degrades to free-shape when disabled (no raise).
        wisdom_score: float | None = None
        cognitive_health = None
        remedy_url: str | None = None
        if (
            has_feature(self._tier, "standard_analytics")
            and self._config.feature_flags.health_analytics
        ):
            wisdom_score = compute_wisdom_score(stats, self._admin)
            cognitive_health = classify_cognitive_health(
                stats, wisdom_score, self._admin
            )
            remedy_url = remedy_url_for(cognitive_health)

        return HealthReport(
            tier=self._tier.value,
            memory_stats=memory_stats,
            directive_stats=directive_stats,
            dream_stats=dream_stats,
            cost_stats=cost_stats,
            wisdom_score=wisdom_score,
            cognitive_health=cognitive_health,
            remedy_url=remedy_url,
        )

    @sync_twin
    async def status(self) -> dict[str, object]:
        """Return a runtime capability snapshot of this agent.

        Includes tier, validation state, effective features (tier features
        filtered by FeatureFlags), raw feature_flags, entity counts, and
        an evolution summary showing how the agent has changed over time.

        Returns:
            Dict with ``agent_id``, ``name``, ``tier``, ``validated``,
            ``features``, ``feature_flags``, ``counts``,
            ``evolution_summary``.
        """
        tier_features = get_tier_features(self._tier)
        # Filter by FeatureFlags: remove features the user has opted out of
        effective_features = set()
        for feature in tier_features:
            flag_name = self._FEATURE_TO_FLAG.get(feature)
            if flag_name is not None and not getattr(
                self._config.feature_flags, flag_name, True
            ):
                continue
            effective_features.add(feature)

        counts = await self._backend.get_agent_counts(
            agent_id=self._agent_id,
        )

        evolution = await self._backend.get_evolution_summary(
            agent_id=self._agent_id,
        )

        flags = self._config.feature_flags
        feature_flags_dict = {
            "dreams": flags.dreams,
            "scheduled_dreams": flags.scheduled_dreams,
            "reconsolidation": flags.reconsolidation,
            "journals": flags.journals,
            "directives": flags.directives,
            "critic": flags.critic,
            "goals": flags.goals,
            "emotional_tracking": flags.emotional_tracking,
            "health_analytics": flags.health_analytics,
            "provenance": flags.provenance,
            "provenance_trace": flags.provenance_trace,
            "provenance_explain": flags.provenance_explain,
            "provenance_export": flags.provenance_export,
        }

        return {
            "agent_id": self._agent_id,
            "name": self._config.name,
            "tier": self._tier.value,
            "validated": self._validated,
            "features": sorted(effective_features),
            "feature_flags": feature_flags_dict,
            "counts": counts,
            "evolution_summary": evolution,
        }

    @sync_twin
    async def status_display(self) -> str:
        """Return a human-readable formatted status for terminal output.

        Calls :meth:`status` and formats the result into a multi-line
        narrative showing agent identity, accumulation counts, and
        evolution milestones.

        Returns:
            Multi-line string suitable for printing to a terminal.
        """
        from datetime import datetime as _dt

        s = await self.status()
        evo = cast("dict[str, Any]", s.get("evolution_summary", {}))
        lines: list[str] = []

        # Header
        lines.append(f"Agent: {s['name']}")
        first_seen = evo.get("first_seen")
        if first_seen:
            try:
                dt = _dt.fromisoformat(str(first_seen))
                days = (self._clock.now() - dt).days
                lines.append(
                    f"Running since: {dt.strftime('%Y-%m-%d')} ({days} days)"
                )
            except (ValueError, TypeError):
                pass
        tier_label = str(s["tier"]).capitalize()
        validated_label = "validated" if s["validated"] else "unvalidated"
        lines.append(f"Tier: {tier_label} ({validated_label})")
        lines.append("")

        # Accumulation counts
        mem_tier = cast("dict[str, Any]", evo.get("memories_by_tier", {}))
        raw = mem_tier.get("raw", 0)
        consolidated = mem_tier.get("consolidated", 0)
        journal_count = evo.get("journal_count", 0)
        lines.append(
            f"Memories: {raw} captured "
            f"\u2192 {consolidated} consolidated "
            f"\u2192 {journal_count} journals"
        )

        dir_status = cast("dict[str, Any]", evo.get("directives_by_status", {}))
        prov = dir_status.get("provisional", 0)
        active = dir_status.get("active", 0)
        perm = dir_status.get("permanent", 0)
        total_active = prov + active + perm
        parts = []
        if prov:
            parts.append(f"{prov} provisional")
        if active:
            parts.append(f"{active} active")
        if perm:
            parts.append(f"{perm} permanent")
        dir_detail = ", ".join(parts) if parts else "none"
        lines.append(f"Directives: {total_active} ({dir_detail})")

        dream_count = evo.get("dream_count", 0)
        last_dream = evo.get("last_dream_at")
        dream_suffix = ""
        if last_dream:
            try:
                dt = _dt.fromisoformat(str(last_dream))
                hours_ago = (
                    self._clock.now() - dt
                ).total_seconds() / 3600
                if hours_ago < 1:
                    dream_suffix = " (last: <1 hour ago)"
                elif int(hours_ago) == 1:
                    dream_suffix = " (last: 1 hour ago)"
                else:
                    dream_suffix = f" (last: {int(hours_ago)} hours ago)"
            except (ValueError, TypeError):
                pass
        lines.append(f"Dreams: {dream_count} completed{dream_suffix}")
        lines.append("")

        # Evolution narrative
        total_consolidated = evo.get("total_consolidated", 0)
        if total_consolidated or perm or active or dream_count:
            lines.append("Evolution:")
            if active:
                _d = "directive" if active == 1 else "directives"
                lines.append(
                    f"  \u2192 {active} {_d} promoted from "
                    f"provisional to active"
                )
            if total_consolidated:
                _m = "memory" if total_consolidated == 1 else "memories"
                lines.append(
                    f"  \u2192 {total_consolidated} {_m} consolidated "
                    f"into higher-order insights"
                )
            if perm:
                _d = "directive" if perm == 1 else "directives"
                lines.append(
                    f"  \u2192 {perm} {_d} reached permanent status"
                )
            total_mem = raw + consolidated + mem_tier.get("reflective", 0)
            if total_mem and total_active:
                _r = "rule" if total_active == 1 else "rules"
                lines.append(
                    f"  \u2192 Agent has processed {total_mem} experiences "
                    f"into {total_active} behavioral {_r}"
                )

        return "\n".join(lines)

    async def compose_system_prompt(
        self,
        role: str,
        query: str,
        *,
        memories: list[dict[str, object]] | None = None,
        memory_limit: int = 5,
        directive_limit: int = 5,
        memory_kinds: Sequence[str] | None = None,
        extra_instructions: str = "",
        track_usage: bool = True,
    ) -> str:
        """Compose a complete, ready-to-use system prompt for this agent.

        Wraps :meth:`MemoryInterface.search` + :meth:`DirectivesInterface
        .compose_context` into a single canonical assembly. The default
        framing is intentionally **task-neutral** — it works for customer
        support, code review, research synthesis, conversational chat, or
        report generation without locking the agent into a particular
        voice. Two framing choices in the default that solve real
        production failure modes:

        * **"respond directly to the user"** discourages the strategy-doc
          drift where the model produces "When this situation arises, the
          agent should..." instead of an actual reply.
        * **"cite specific known facts where they apply"** signals to the
          model that the ``## Known facts`` block is authoritative
          grounding, not background context to skim past.

        Pass ``extra_instructions`` to layer task-specific guidance on
        top of the default (e.g. ``"Respond as a markdown report with
        sections."`` or ``"Show your reasoning before the conclusion."``).

        Args:
            role: The agent's role for this prompt — e.g.
                ``"customer support agent"``, ``"code reviewer"``,
                ``"research assistant"``. Free-form; not validated.
            query: The user's current input. Used to retrieve relevant
                memories and directives. NOT included in the returned
                system prompt — pass it to your LLM as the user message.
            memories: Pre-fetched memory results. When ``None`` (default),
                this method calls :meth:`MemoryInterface.search` itself
                with ``query``, ``memory_limit``, and ``memory_kinds``.
                Pass an explicit list to reuse a search result you've
                already done.
            memory_limit: Forwarded to ``memory.search`` when ``memories``
                is ``None``. Default ``5`` matches ``compose_context``.
            directive_limit: Forwarded to ``directives.compose_context``
                as ``limit``. Default ``5``.
            memory_kinds: Forwarded to ``memory.search`` when ``memories``
                is ``None``. ``None`` (default) uses the configured
                ``search_insight_ratio`` mix; pass ``["conversation"]``
                to force raw events only.
            extra_instructions: Optional task-specific guidance appended
                to the default framing. Empty by default.
            track_usage: Forwarded to ``compose_context``. When ``True``,
                directives included in the prompt have their
                ``usage_count`` incremented fire-and-forget.

        Returns:
            The full system prompt string. Pass it directly as the
            ``system=`` parameter to your LLM call.

        Example:
            >>> system = await agent.compose_system_prompt(
            ...     role="customer support agent",
            ...     query="A customer was charged twice for order ORD-42.",
            ... )
            >>> resp = await llm.messages.create(
            ...     system=system,
            ...     messages=[{"role": "user", "content": user_query}],
            ... )
        """
        if memories is None:
            memories = await self.memory.search(
                query=query,
                limit=memory_limit,
                kinds=memory_kinds,
            )
        ctx = await self.directives.compose_context(
            query,
            limit=directive_limit,
            track_usage=track_usage,
        )

        sections: list[str] = []
        sections.append(
            f"You are a {role}. Use the context below to respond directly "
            "to the user's input. Cite specific known facts (by subject, "
            "ID, or value) where they apply. Do not restate this prompt "
            "or describe your approach — produce the response itself."
        )
        if extra_instructions:
            sections.append(extra_instructions.strip())

        memory_block = _render_memory_block(memories or [])
        if memory_block:
            sections.append(memory_block)

        directive_block = cast("str", ctx.get("text", "")).strip()
        if directive_block:
            sections.append(directive_block)

        return "\n\n".join(sections)

    @property
    def storage(self) -> BaseBackend:
        """The storage backend attached to this agent.

        Exposes operator-facing introspection such as
        ``agent.storage.migration_status()``. Regular subsystems should
        go through the typed interfaces (``agent.memory``,
        ``agent.directives``, etc.) rather than the backend directly.
        """
        return self._backend

    # -- Event bus ---------------------------------------------------------

    @property
    def events(self) -> EventEmitter:
        """The agent's event emitter.

        All cognition events flow through this single bus. Subsystems
        do not expose their own callback registries.
        """
        return self._events

    def on(self, event: str, handler: Handler) -> SubscriptionToken:
        """Subscribe ``handler`` to ``event``. Convenience for ``agent.events.on``."""
        return self._events.on(event, handler)

    def off(self, token: SubscriptionToken) -> None:
        """Unsubscribe by token. Convenience for ``agent.events.off``."""
        self._events.off(token)

    def once(self, event: str, handler: Handler) -> SubscriptionToken:
        """One-shot subscribe. Convenience for ``agent.events.once``."""
        return self._events.once(event, handler)

    async def _emit(
        self,
        name: str,
        *,
        priority: EventPriority = EventPriority.NORMAL,
        cycle_id: str | None = None,
        data: dict[str, Any] | None = None,
        entity_type: str | None = None,
        entity_id: str | None = None,
        parent_event_id: str | None = None,
    ) -> None:
        """Internal: fire an event through the agent's bus.

        All subsystems call this — never ``EventEmitter.emit`` directly —
        so the envelope fields (``agent_id``, ``timestamp``) are
        populated uniformly.

        When ``entity_type`` and ``entity_id`` are both provided, the event
        is also mirrored into the ``provenance_events`` append-only log
        so ``agent.provenance.trace()`` can reconstruct it later. The
        mirror is guarded by the ``provenance`` FeatureFlag — operators
        who opt out of provenance get bus-only emits with no log write.
        """
        await self._emit_returning(
            name,
            priority=priority,
            cycle_id=cycle_id,
            data=data,
            entity_type=entity_type,
            entity_id=entity_id,
            parent_event_id=parent_event_id,
        )

    async def _emit_returning(
        self,
        name: str,
        *,
        priority: EventPriority = EventPriority.NORMAL,
        cycle_id: str | None = None,
        data: dict[str, Any] | None = None,
        entity_type: str | None = None,
        entity_id: str | None = None,
        parent_event_id: str | None = None,
    ) -> Event:
        """Internal: fire an event and return it for audit correlation.

        Identical to ``_emit`` but returns the constructed ``Event``
        so callers (e.g., delete operations) can thread its identity
        into a ``DeleteReport.event_id``.
        """
        import uuid

        event_id = uuid.uuid4().hex[:12]
        merged_data = {**(data or {}), "event_id": event_id}
        timestamp = self._clock.now()
        event = Event(
            name=name,
            agent_id=self._agent_id,
            timestamp=timestamp,
            priority=priority,
            cycle_id=cycle_id,
            data=merged_data,
        )
        await self._events.emit(event)

        if entity_type is not None and entity_id is not None:
            await self._write_provenance_event(
                event_id=event_id,
                event_type=name,
                entity_type=entity_type,
                entity_id=entity_id,
                parent_event_id=parent_event_id,
                payload=merged_data,
                created_at=timestamp.isoformat(),
            )
        return event

    async def _write_provenance_event(
        self,
        *,
        event_id: str,
        event_type: str,
        entity_type: str,
        entity_id: str,
        parent_event_id: str | None,
        payload: dict[str, Any],
        created_at: str,
    ) -> None:
        """Mirror a lifecycle event to the provenance log.

        Gated by the ``provenance`` FeatureFlag so operators can opt out
        of the write. Failures are swallowed and logged — provenance
        must never break the hot path. Any persistent storage failure
        leaves the event on the bus but absent from ``trace()``, which
        is the conservative trade-off for v0.5 Phase 2.
        """
        if not self._config.feature_flags.provenance:
            return
        try:
            await self._backend.append_provenance_event(
                event_id=event_id,
                agent_id=self._agent_id,
                event_type=event_type,
                entity_type=entity_type,
                entity_id=entity_id,
                parent_event_id=parent_event_id,
                payload=payload,
                created_at=created_at,
            )
        except Exception:  # noqa: BLE001
            logger.warning(
                "Failed to append provenance event",
                extra={
                    "agent_id": self._agent_id,
                    "event_id": event_id,
                    "event_type": event_type,
                    "entity_type": entity_type,
                    "entity_id": entity_id,
                },
                exc_info=True,
            )


class _SessionContextWrapper:
    """Wrapper that emits session lifecycle events on enter/exit.

    ``agent.session()`` returns this. It delegates ``__aenter__`` to the
    inner ``SessionHandle`` and emits ``memory.session_ended`` on
    ``__aexit__``.
    """

    def __init__(self, *, handle: SessionHandle, agent: WisdomAgent) -> None:
        self._handle = handle
        self._agent = agent

    async def __aenter__(self) -> SessionHandle:
        return await self._handle.__aenter__()

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        await self._handle.__aexit__(exc_type, exc_val, exc_tb)
        await self._agent._emit(
            "memory.session_ended",
            data={
                "session_id": self._handle.session_id,
                "ephemeral": self._handle.ephemeral,
            },
        )
