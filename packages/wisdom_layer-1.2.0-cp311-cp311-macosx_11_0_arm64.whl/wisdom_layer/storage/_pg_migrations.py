"""Async migration runner for the Postgres backend.

Parallel to :class:`wisdom_layer.storage._migrations.MigrationRunner` but
built against :mod:`asyncpg` instead of :mod:`sqlite3`. The two runners
share file format, naming convention, and idempotency contract — the
only reason they are separate classes is that asyncpg is async-first
and sqlite3 is sync, and forcing one protocol across both drivers would
leak async into boot paths that don't need it.

Design decisions (identical to the sync runner):

- **Forward-only.** No downgrade API. The ``-- down`` block exists for
  manual operator use, not runtime rollback.
- **Idempotent runner.** ``apply_pending`` is safe to call on every boot —
  it consults ``schema_migrations`` and skips already-applied versions.
- **Idempotent migrations.** Every up block must use ``IF NOT EXISTS``
  (or ``ADD COLUMN IF NOT EXISTS``) so a partial apply followed by a
  retry is safe.
- **Atomic per-migration.** Each migration + its ``schema_migrations``
  bookkeeping row commit or roll back together inside a single
  transaction.

Doc reference: ``06_extraction_plan.md`` §0.2, ``engineering_standards.md`` §12.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from wisdom_layer.clock import SystemClock
from wisdom_layer.errors import StorageMigrationError
from wisdom_layer.storage._migrations import (
    Migration,
    _parse_migration_file,
    _split_statements,
)

if TYPE_CHECKING:
    from pathlib import Path

    import asyncpg

    from wisdom_layer.clock import Clock

__all__ = ["PostgresMigrationRunner"]

logger = logging.getLogger(__name__)


class PostgresMigrationRunner:
    """Applies SQL migrations to a Postgres database via asyncpg.

    Mirrors :class:`wisdom_layer.storage._migrations.MigrationRunner` method
    for method (``discover``, ``applied_versions``, ``apply_pending``,
    ``status``) so the two can be swapped by the backend without the
    backend caring about the driver.

    Args:
        pool: :class:`asyncpg.Pool` already opened against the target DB.
        migrations_dir: Directory containing ``NNNN_name.sql`` files
            (expected to be ``storage/migrations/postgres/``).
        clock: Clock for ``applied_at`` timestamps. Defaults to
            :class:`SystemClock`.
    """

    def __init__(
        self,
        *,
        pool: asyncpg.Pool,
        migrations_dir: Path,
        clock: Clock | None = None,
    ) -> None:
        self._pool = pool
        self._dir = migrations_dir
        self._clock: Clock = clock or SystemClock()

    async def ensure_table(self) -> None:
        """Create the ``schema_migrations`` tracking table if absent."""
        async with self._pool.acquire() as conn:
            await conn.execute(
                """CREATE TABLE IF NOT EXISTS schema_migrations (
                    version INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    applied_at TEXT NOT NULL
                )"""
            )

    def discover(self) -> list[Migration]:
        """Return all migrations in the migrations dir, sorted by version."""
        if not self._dir.exists():
            return []
        files = sorted(p for p in self._dir.glob("*.sql") if p.is_file())
        migrations = [_parse_migration_file(p) for p in files]
        migrations.sort(key=lambda m: m.version)
        return migrations

    async def applied_versions(self) -> set[int]:
        """Return the set of migration versions already applied."""
        await self.ensure_table()
        async with self._pool.acquire() as conn:
            rows = await conn.fetch("SELECT version FROM schema_migrations")
        return {int(r["version"]) for r in rows}

    async def apply_pending(self) -> list[Migration]:
        """Apply all pending migrations in numeric order.

        Each migration runs inside a single ``BEGIN``/``COMMIT`` that also
        writes its ``schema_migrations`` bookkeeping row, so either both
        land or neither does. A failing migration raises
        :class:`StorageMigrationError` and stops the run.
        """
        await self.ensure_table()
        discovered = self.discover()
        applied = await self.applied_versions()
        pending = [m for m in discovered if m.version not in applied]
        pending.sort(key=lambda m: m.version)

        newly_applied: list[Migration] = []
        for migration in pending:
            statements = _split_statements(migration.up_sql)
            async with self._pool.acquire() as conn:
                try:
                    async with conn.transaction():
                        for stmt in statements:
                            await conn.execute(stmt)
                        await conn.execute(
                            """INSERT INTO schema_migrations
                                   (version, name, applied_at)
                               VALUES ($1, $2, $3)""",
                            migration.version,
                            migration.name,
                            self._clock.now().isoformat(),
                        )
                except Exception as e:
                    raise StorageMigrationError(
                        f"Migration {migration.name} failed: {e}"
                    ) from e

            newly_applied.append(migration)
            logger.info(
                "migration applied",
                extra={
                    "subsystem": "storage.pg_migrations",
                    "migration_version": migration.version,
                    "migration_name": migration.name,
                },
            )

        return newly_applied

    async def status(self) -> dict[str, Any]:
        """Return a structured report of applied and pending migrations."""
        await self.ensure_table()
        async with self._pool.acquire() as conn:
            applied_rows = await conn.fetch(
                "SELECT version, name, applied_at FROM schema_migrations "
                "ORDER BY version"
            )

        applied_versions: set[int] = {int(r["version"]) for r in applied_rows}
        applied_list: list[dict[str, Any]] = [
            {
                "version": int(r["version"]),
                "name": str(r["name"]),
                "applied_at": str(r["applied_at"]),
            }
            for r in applied_rows
        ]

        discovered = self.discover()
        pending_list: list[dict[str, Any]] = [
            {"version": m.version, "name": m.name}
            for m in discovered
            if m.version not in applied_versions
        ]

        current = max(applied_versions) if applied_versions else 0
        return {
            "applied": applied_list,
            "pending": pending_list,
            "current_version": current,
        }
