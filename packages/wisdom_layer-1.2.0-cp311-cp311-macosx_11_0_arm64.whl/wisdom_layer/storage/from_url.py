"""URL- and env-driven backend construction.

Dev, staging, and production commonly differ in only one setting —
where the data lives. Hard-coding ``SQLiteBackend("./agent.db")`` in
application code forces a code change when a customer migrates from
local SQLite to a Pro Postgres cluster; :func:`backend_from_url` and
:func:`backend_from_env` keep that knob in config where it belongs.

Supported URL schemes:

- ``sqlite:///./agent.db`` — on-disk SQLite; path is the portion after
  the third slash (RFC-3986 ``authority`` is empty). ``sqlite://``
  without a path is treated as ``":memory:"``.
- ``sqlite:///:memory:`` — in-memory SQLite, explicit.
- ``file:///absolute/path.db`` — alias for ``sqlite://`` with an
  absolute path (useful in container environments that already use
  ``file://`` for volume-mounted data).
- ``postgresql://user:pass@host:5432/db`` — Postgres via asyncpg.
  ``postgres://`` is accepted as a synonym (matches the libpq and
  Heroku-style aliases).

Unknown schemes raise :class:`ValueError`; bare paths (no scheme) are
rejected — explicit is better than silent, especially for storage
routing.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

if TYPE_CHECKING:
    from wisdom_layer.storage.base import BaseBackend


_DEFAULT_ENV_VAR = "WISDOM_LAYER_DATABASE_URL"


def backend_from_url(url: str, **kwargs: Any) -> BaseBackend:
    """Construct a backend from a scheme-prefixed URL.

    Args:
        url: Scheme-prefixed connection string. See module docstring
            for supported schemes.
        **kwargs: Forwarded to the matching backend constructor. For
            SQLite: ``embed_fn``, ``admin_defaults``, etc. For
            Postgres: ``min_pool_size``, ``max_pool_size``, ``embed_fn``,
            ``admin_defaults``. Unknown kwargs raise ``TypeError`` at
            the backend constructor — not silently dropped.

    Returns:
        An un-initialized backend instance. The caller is responsible
        for ``await backend.initialize()``.

    Raises:
        ValueError: Empty URL, no scheme, or unsupported scheme.
    """
    if not url or not url.strip():
        msg = "backend_from_url requires a non-empty URL."
        raise ValueError(msg)

    parsed = urlparse(url)
    scheme = parsed.scheme.lower()

    if not scheme:
        msg = (
            f"backend_from_url: URL has no scheme: {url!r}. "
            f"Use 'sqlite:///./agent.db' or 'postgresql://user:pass@host/db'."
        )
        raise ValueError(msg)

    if scheme in {"sqlite", "file"}:
        # urlparse drops the leading slashes; for sqlite:///./agent.db
        # the path is "/./agent.db" which SQLite handles fine, but we
        # strip the leading "/" so relative paths work as written.
        path = parsed.path or ""
        if scheme == "sqlite" and (path in {"", "/"}) and not parsed.netloc:
            resolved: str = ":memory:"
        elif path == "/:memory:":
            resolved = ":memory:"
        else:
            resolved = path.lstrip("/") if scheme == "sqlite" else path
            if not resolved:
                msg = f"backend_from_url: file:// URL has no path: {url!r}"
                raise ValueError(msg)
        from wisdom_layer.storage.sqlite import SQLiteBackend

        return SQLiteBackend(resolved, **kwargs)

    if scheme in {"postgresql", "postgres"}:
        # asyncpg accepts either scheme; we pass the URL through as the
        # DSN after normalizing "postgres://" → "postgresql://" for
        # consistency with libpq's canonical form.
        dsn = url if scheme == "postgresql" else "postgresql://" + url.split("://", 1)[1]
        from wisdom_layer.storage.postgres import PostgresBackend

        return PostgresBackend(dsn=dsn, **kwargs)

    msg = (
        f"backend_from_url: unsupported scheme {scheme!r}. "
        f"Supported: sqlite, file, postgresql, postgres."
    )
    raise ValueError(msg)


def backend_from_env(
    var_name: str = _DEFAULT_ENV_VAR,
    *,
    default_url: str | None = None,
    **kwargs: Any,
) -> BaseBackend:
    """Read a backend URL from an environment variable and construct.

    The canonical var is ``WISDOM_LAYER_DATABASE_URL``; callers can
    override for multi-tenant setups that namespace their config.

    Args:
        var_name: Env var to read. Defaults to
            ``WISDOM_LAYER_DATABASE_URL``.
        default_url: URL to use when the env var is unset or empty.
            ``None`` (the default) raises ``ValueError`` if the var is
            missing — better than silently routing to an unintended
            store.
        **kwargs: Forwarded to :func:`backend_from_url`.

    Returns:
        An un-initialized backend instance.

    Raises:
        ValueError: ``var_name`` is unset/empty and ``default_url`` is
            ``None``.
    """
    url = os.environ.get(var_name, "").strip()
    if not url:
        if default_url is None:
            msg = (
                f"backend_from_env: ${var_name} is not set and no "
                f"default_url was provided. Set the env var or pass "
                f"default_url='sqlite:///./agent.db'."
            )
            raise ValueError(msg)
        url = default_url
    return backend_from_url(url, **kwargs)
