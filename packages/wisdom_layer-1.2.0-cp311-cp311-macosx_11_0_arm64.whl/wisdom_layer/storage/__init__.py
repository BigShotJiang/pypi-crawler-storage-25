"""Storage backends for the Wisdom Layer SDK.

``PostgresBackend`` is exported at the top level for parity with
``SQLiteBackend``, but its runtime dependencies (``asyncpg`` and
``pgvector``) are only required at ``initialize()`` time. Importing
this module without the ``[postgres]`` extra installed succeeds; the
ImportError is deferred until the backend is actually started.
"""

from wisdom_layer.storage.base import BaseBackend
from wisdom_layer.storage.from_url import backend_from_env, backend_from_url
from wisdom_layer.storage.postgres import PostgresBackend
from wisdom_layer.storage.sqlite import SQLiteBackend

__all__ = [
    "BaseBackend",
    "PostgresBackend",
    "SQLiteBackend",
    "backend_from_env",
    "backend_from_url",
]
