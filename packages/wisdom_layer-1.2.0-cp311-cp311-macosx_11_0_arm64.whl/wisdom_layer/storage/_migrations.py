"""Migration runner for the Wisdom Layer SDK.

This is the canonical schema evolution mechanism for the SDK. Every phase
that changes storage lands one ``NNNN_<name>.sql`` file per backend
dialect in ``wisdom_layer/storage/migrations/<dialect>/``;
:meth:`MigrationRunner.apply_pending` discovers them, applies them in
numeric order, and records each in the ``schema_migrations`` table.

The runner itself is dialect-agnostic — callers pass the directory they
want applied. :class:`SQLiteBackend` points at ``migrations/sqlite``;
the forthcoming :class:`PostgresBackend` will point at
``migrations/postgres``.

Design decisions (doc 06 §0.2):

- **Forward-only.** There is no downgrade API. The ``-- down`` block in
  each migration file exists for manual operator use, not for runtime
  rollback. Customers recover by restoring from backup.
- **Numbered, append-only.** Merged migrations are never edited; phases
  that need fixes add a new file with the next number.
- **Idempotent runner.** ``apply_pending`` is safe to call on every boot —
  it consults ``schema_migrations`` and skips already-applied versions.
- **Idempotent migrations.** Every up block must use ``IF NOT EXISTS``
  (or another idempotent form) so a partial apply followed by a retry
  is safe.

The runner is deliberately small. No "migrate to version N", no branching,
no down-migration execution. Schema evolution should be boring.

Doc reference: ``06_extraction_plan.md`` §0.2, ``engineering_standards.md`` §12.
"""

from __future__ import annotations

import contextlib
import logging
import sqlite3
from dataclasses import dataclass
from typing import TYPE_CHECKING

from wisdom_layer.clock import SystemClock
from wisdom_layer.errors import StorageMigrationError

if TYPE_CHECKING:
    from pathlib import Path

    from wisdom_layer.clock import Clock

__all__ = ["Migration", "MigrationRunner"]

logger = logging.getLogger(__name__)


_UP_MARKER = "-- up"
_DOWN_MARKER = "-- down"


def _split_statements(sql: str) -> list[str]:
    """Split a migration up block into individual SQL statements.

    Handles ``-- ...`` line comments (stripped) and ``;``-separated
    statements. Does not handle string literals with embedded semicolons
    or block comments — migration files are expected to be plain DDL
    without such constructs. Empty statements are dropped.
    """
    cleaned_lines: list[str] = []
    for line in sql.splitlines():
        if line.lstrip().startswith("--"):
            continue
        if "--" in line:
            line = line.split("--", 1)[0]
        cleaned_lines.append(line)
    body = "\n".join(cleaned_lines)
    return [s.strip() for s in body.split(";") if s.strip()]


@dataclass(frozen=True)
class Migration:
    """One SQL migration loaded from disk.

    Attributes:
        version: The numeric prefix of the filename (e.g. ``0001`` → ``1``).
        name: The filename stem without the ``.sql`` extension
            (e.g. ``0001_initial``).
        path: Absolute path to the source file.
        up_sql: Contents of the ``-- up`` block, whitespace-trimmed.
        down_sql: Contents of the ``-- down`` block, whitespace-trimmed.
            Used for manual operator rollback only; the runner never
            executes this automatically.
    """

    version: int
    name: str
    path: Path
    up_sql: str
    down_sql: str


def _parse_migration_file(path: Path) -> Migration:
    """Parse a ``NNNN_name.sql`` file into a :class:`Migration`.

    The file must contain both ``-- up`` and ``-- down`` marker lines.
    Everything between ``-- up`` and ``-- down`` is the up block; everything
    after ``-- down`` is the down block. Content before ``-- up`` is
    treated as a comment header and discarded.

    Args:
        path: Path to the SQL file.

    Returns:
        A fully-parsed :class:`Migration`.

    Raises:
        StorageMigrationError: If the filename lacks a numeric prefix, or
            the file is missing either marker, or ``-- down`` appears
            before ``-- up``.
    """
    version_str = path.stem.split("_", 1)[0]
    try:
        version = int(version_str)
    except ValueError as e:
        raise StorageMigrationError(
            f"Migration filename does not start with a numeric prefix: {path.name}"
        ) from e

    content = path.read_text()
    up_idx = content.find(_UP_MARKER)
    down_idx = content.find(_DOWN_MARKER)

    if up_idx == -1:
        raise StorageMigrationError(
            f"Migration {path.name} is missing the '-- up' marker"
        )
    if down_idx == -1:
        raise StorageMigrationError(
            f"Migration {path.name} is missing the '-- down' marker"
        )
    if down_idx < up_idx:
        raise StorageMigrationError(
            f"Migration {path.name} has '-- down' appearing before '-- up'"
        )

    up_sql = content[up_idx + len(_UP_MARKER) : down_idx].strip()
    down_sql = content[down_idx + len(_DOWN_MARKER) :].strip()

    if not up_sql:
        raise StorageMigrationError(
            f"Migration {path.name} has an empty '-- up' block"
        )

    return Migration(
        version=version,
        name=path.stem,
        path=path,
        up_sql=up_sql,
        down_sql=down_sql,
    )


class MigrationRunner:
    """Applies SQL migrations to a SQLite connection idempotently.

    Tracks applied migrations in the ``schema_migrations`` table. The runner
    is forward-only and deliberately small — no "migrate to version N", no
    automated rollback, no multi-database support beyond SQLite.

    Args:
        conn: Open ``sqlite3.Connection`` to apply migrations against.
        migrations_dir: Directory containing ``NNNN_name.sql`` files.
            Non-``.sql`` files are ignored.
        clock: :class:`Clock` for recording ``applied_at`` timestamps.
            Defaults to :class:`SystemClock`.

    Example::

        runner = MigrationRunner(
            conn=conn,
            migrations_dir=Path("wisdom_layer/storage/migrations/sqlite"),
        )
        newly_applied = runner.apply_pending()
        status = runner.status()
    """

    def __init__(
        self,
        *,
        conn: sqlite3.Connection,
        migrations_dir: Path,
        clock: Clock | None = None,
    ) -> None:
        self._conn = conn
        self._dir = migrations_dir
        self._clock: Clock = clock or SystemClock()

    def ensure_table(self) -> None:
        """Create the ``schema_migrations`` tracking table if it doesn't exist.

        Safe to call any number of times. Uses ``CREATE TABLE IF NOT EXISTS``
        so the runner's own bookkeeping participates in the same idempotency
        contract every migration obeys.
        """
        self._conn.execute(
            """CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at TEXT NOT NULL
            )"""
        )
        self._conn.commit()

    def discover(self) -> list[Migration]:
        """Return all migrations in the migrations dir, sorted by version.

        Non-``.sql`` files are silently ignored. If the directory does not
        exist, returns an empty list.

        Raises:
            StorageMigrationError: If any discovered file fails to parse.
        """
        if not self._dir.exists():
            return []
        files = sorted(p for p in self._dir.glob("*.sql") if p.is_file())
        migrations = [_parse_migration_file(p) for p in files]
        migrations.sort(key=lambda m: m.version)
        return migrations

    def applied_versions(self) -> set[int]:
        """Return the set of migration versions already applied to the DB."""
        self.ensure_table()
        rows = self._conn.execute("SELECT version FROM schema_migrations").fetchall()
        return {int(r[0]) for r in rows}

    def apply_pending(self) -> list[Migration]:
        """Apply all pending migrations in numeric order, atomically.

        Returns the list of migrations newly applied on this call.
        Already-applied migrations are skipped. Each migration runs inside
        its own explicit ``BEGIN``/``COMMIT`` transaction that also
        includes the ``schema_migrations`` bookkeeping row, so either the
        migration AND its bookkeeping both commit, or neither does. If any
        migration fails, the transaction is rolled back and
        :class:`StorageMigrationError` is raised — subsequent migrations
        are not attempted.

        Because bookkeeping is part of the same transaction, crash-retry
        will never see "DDL applied but version row missing" and never
        double-apply an ``ALTER TABLE ADD COLUMN``.
        """
        self.ensure_table()
        discovered = self.discover()
        applied = self.applied_versions()
        pending = [m for m in discovered if m.version not in applied]
        pending.sort(key=lambda m: m.version)

        newly_applied: list[Migration] = []
        for migration in pending:
            statements = _split_statements(migration.up_sql)
            try:
                self._conn.execute("BEGIN")
                for stmt in statements:
                    self._conn.execute(stmt)
                self._conn.execute(
                    """INSERT INTO schema_migrations (version, name, applied_at)
                       VALUES (?, ?, ?)""",
                    (
                        migration.version,
                        migration.name,
                        self._clock.now().isoformat(),
                    ),
                )
                self._conn.commit()
            except Exception as e:
                with contextlib.suppress(sqlite3.Error):
                    self._conn.rollback()
                raise StorageMigrationError(
                    f"Migration {migration.name} failed: {e}"
                ) from e

            newly_applied.append(migration)
            logger.info(
                "migration applied",
                extra={
                    "subsystem": "storage.migrations",
                    "migration_version": migration.version,
                    "migration_name": migration.name,
                },
            )

        return newly_applied

    def status(self) -> dict[str, object]:
        """Return a structured report of applied and pending migrations.

        Shape::

            {
                "applied": [
                    {"version": 1, "name": "0001_initial", "applied_at": "..."},
                    ...
                ],
                "pending": [
                    {"version": 2, "name": "0002_add_agent_id"},
                    ...
                ],
                "current_version": 1,   # 0 if nothing applied
            }

        This is the backing implementation for ``agent.storage.migration_status()``.
        """
        self.ensure_table()
        applied_rows = self._conn.execute(
            "SELECT version, name, applied_at FROM schema_migrations "
            "ORDER BY version"
        ).fetchall()
        applied_versions: set[int] = {int(row[0]) for row in applied_rows}
        applied_list: list[dict[str, object]] = [
            {
                "version": int(row[0]),
                "name": str(row[1]),
                "applied_at": str(row[2]),
            }
            for row in applied_rows
        ]

        discovered = self.discover()
        pending_list: list[dict[str, object]] = [
            {"version": m.version, "name": m.name}
            for m in discovered
            if m.version not in applied_versions
        ]

        current = max(applied_versions) if applied_versions else 0
        return {
            "applied": applied_list,
            "pending": pending_list,
            "current_version": current,
        }
