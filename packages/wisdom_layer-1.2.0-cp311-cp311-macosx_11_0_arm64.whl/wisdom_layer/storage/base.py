"""Abstract storage backend interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from wisdom_layer.errors import BackendNotInitializedError

if TYPE_CHECKING:
    from collections.abc import Sequence
    from datetime import datetime

    from wisdom_layer._internal.admin_defaults import AdminDefaults
    from wisdom_layer.llm.base import BaseLLMAdapter


class BaseBackend(ABC):
    """Abstract base class for all storage backends.

    Implementations must handle memory storage, search, directives,
    dream cycle history, and analytics.
    """

    @abstractmethod
    async def initialize(self) -> None:
        """Initialize the storage backend (apply migrations, open connections)."""

    @abstractmethod
    async def close(self) -> None:
        """Close connections and clean up resources."""

    async def bind_embedder(self, adapter: BaseLLMAdapter) -> None:
        """Wire the LLM adapter's embedder identity into this backend.

        Called by :meth:`WisdomAgent.initialize` immediately after
        :meth:`BaseLLMAdapter.warmup` has settled the adapter's
        ``embedding_dim``. Reads ``adapter.embedding_model_id`` and
        ``adapter.embedding_dim`` and dispatches to
        :meth:`_apply_embedder_binding` so subclasses can validate against
        any explicit user override and persist the values for write/read
        time dim-checks.

        The adapter is the single source of truth for embedder identity in
        v1.0 — users wire one ``LLMAdapter`` into ``WisdomAgent`` and the
        backend follows along, so swapping ``embedding_model="..."`` on the
        adapter doesn't need a parallel change on the backend.

        Backends that don't care about embeddings (e.g., a future
        directives-only store) can leave the default no-op
        :meth:`_apply_embedder_binding` in place.

        Raises:
            EmbeddingConfigMismatchError: When the user explicitly set
                ``embedding_model_id`` or ``embedding_dim`` on the backend
                AND those values disagree with what the adapter advertises.
                The fix is to drop the explicit override and let the agent
                thread the adapter's values through automatically.
        """
        model_id = getattr(adapter, "embedding_model_id", None) or "unknown"
        dim_raw = getattr(adapter, "embedding_dim", 0) or 0
        try:
            dim = int(dim_raw)
        except (TypeError, ValueError):
            dim = 0
        if dim <= 0:
            # Adapter declined to advertise a dim (CallableAdapter without
            # an embedder, third-party shim). Leave whatever the backend
            # was constructed with — bind_embedder is informational, not
            # required.
            return
        embed_fn = getattr(adapter, "embed", None)
        self._apply_embedder_binding(
            model_id=model_id,
            dim=dim,
            embed_fn=embed_fn,
        )

    def _apply_embedder_binding(
        self,
        *,
        model_id: str,
        dim: int,
        embed_fn: Any,
    ) -> None:
        """Subclass hook for :meth:`bind_embedder`.

        Default implementation is a no-op so abstract backends and
        embedding-agnostic stores do not need to opt in. Concrete
        backends override this to update their ``_embedding_model_id``,
        ``_embedding_dim``, and ``_embed_fn`` state.
        """
        return None

    async def pool_stats(self) -> dict[str, int]:
        """Return live connection-pool stats, or ``{}`` for pool-less backends.

        Shape when the backend maintains a pool::

            {
                "size": int,       # current open connections
                "idle": int,       # idle connections available to acquire
                "in_use": int,     # size - idle
                "min_size": int,   # lower bound configured at init
                "max_size": int,   # upper bound configured at init
            }

        Pool-less backends (SQLite, any in-process single-writer store)
        return ``{}`` unchanged — the empty dict is the signal to
        ``HealthInterface.capture_snapshot`` that there are no pool
        metrics worth emitting.

        Default implementation returns ``{}``; backends override only if
        they actually carry a pool.
        """
        return {}

    @abstractmethod
    async def migration_status(self) -> dict[str, Any]:
        """Return a structured report of applied and pending migrations.

        Shape::

            {
                "applied": [
                    {"version": 1, "name": "0001_initial", "applied_at": "..."},
                    ...
                ],
                "pending": [
                    {"version": 2, "name": "0002_add_agent_id"},
                    ...
                ],
                "current_version": 1,
            }

        This is the backing implementation for
        ``agent.storage.migration_status()``.
        """

    # --- Memory ---

    @abstractmethod
    async def store_memory(
        self,
        *,
        agent_id: str,
        tier: str,
        event_type: str,
        content: dict[str, object],
        emotional_intensity: float = 0.0,
        session_id: str | None = None,
        scope: str = "long_term",
        ttl_hours: int = 0,
        dedup_of: str | None = None,
        source_ids: list[str] | None = None,
        cycle_id: str | None = None,
        created_at: datetime | None = None,
    ) -> str:
        """Store a memory record scoped to ``agent_id``.

        Args:
            session_id: Optional session tag. ``None`` for bare captures.
            scope: ``long_term`` (default) or ``session``.
            ttl_hours: Hours before session-scoped memory is eligible for
                prune. 0 = no expiry. **Advisory only in Phase A** — the
                value is persisted but no prune job enforces it yet.
            dedup_of: ID of an existing memory this record is a semantic
                duplicate of. The new row is persisted; callers use this
                to link near-duplicates rather than silently dropping them.
            source_ids: Provenance chain — IDs of source memories this
                record was synthesized from (Tier 2 consolidation).
            cycle_id: Consolidation cycle tag for atomic rollback.
            created_at: Optional timestamp override. ``None`` (default)
                stamps with the backend's wall clock. Set this only for
                migration imports preserving original timestamps; the
                public agent surface validates the value before reaching
                this layer. ``updated_at`` and ``accessed_at`` always
                track wall-clock time regardless of override.

        Returns:
            The memory ID.
        """

    @abstractmethod
    async def search_memories(
        self,
        *,
        agent_id: str,
        query: str,
        limit: int = 5,
        min_salience: float = 0.0,
        kinds: Sequence[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Search memories owned by ``agent_id`` by semantic similarity.

        Args:
            kinds: Optional list of ``event_type`` values to restrict the
                search to. ``None`` (default) returns all kinds.

        Returns:
            List of matching memories with similarity scores.
        """

    @abstractmethod
    async def get_reflections(
        self,
        *,
        agent_id: str,
        topic: str = "",
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Retrieve Tier 3 reflective journal entries for ``agent_id``."""

    @abstractmethod
    async def get_provenance(
        self, memory_id: str, *, agent_id: str
    ) -> list[dict[str, Any]]:
        """Trace a memory back to its raw sources within ``agent_id``.

        Returns:
            The provenance chain, or an empty list if ``memory_id`` does
            not belong to ``agent_id``.
        """

    @abstractmethod
    async def find_near_duplicate(
        self,
        *,
        agent_id: str,
        embedding: list[float],
        threshold: float = 0.92,
    ) -> str | None:
        """Check if a near-duplicate memory exists for ``agent_id``.

        Compares ``embedding`` against all memories for this agent.
        Returns the memory ID of the best match if similarity >= threshold,
        or ``None`` if no near-duplicate exists.

        Invariant: the returned ID must always be the **root** original.
        If the closest match is itself marked as a duplicate (has
        ``dedup_of`` set), implementations must follow the chain to the
        root so all duplicates converge on a single original — no
        chained pointers (e.g., C → B → A must collapse to C → A).

        Used by write-time dedup to mark new captures as duplicates
        without destroying or merging the original.
        """

    @abstractmethod
    async def reinforce_memories(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> None:
        """Increment reinforcement_count and nudge salience for retrieved memories.

        Best-effort background write — callers should fire-and-forget.
        """

    @abstractmethod
    async def delete_memory(
        self,
        *,
        agent_id: str,
        memory_id: str,
    ) -> int:
        """Hard-delete a single memory row by id.

        Returns:
            Number of rows deleted (0 or 1). Idempotent — unknown id returns 0.
        """

    @abstractmethod
    async def delete_session_memories(
        self,
        *,
        agent_id: str,
        session_id: str,
    ) -> int:
        """Hard-delete every memory tagged with ``session_id``.

        Returns:
            Number of rows deleted. Idempotent — unknown session returns 0.
        """

    @abstractmethod
    async def delete_all_for_agent(
        self,
        *,
        agent_id: str,
    ) -> dict[str, int]:
        """Full erasure of all data for ``agent_id``.

        Deletes from ``memories``, ``directives``, ``directive_proposals``,
        ``dream_reports``, ``journals``. Returns per-table delete counts.
        """

    @abstractmethod
    async def delete_all_memories(
        self,
        *,
        agent_id: str,
    ) -> int:
        """Delete all memories for ``agent_id``, leaving directives intact.

        Used by ``memory.import_(mode='replace')`` to clear memories
        before a full re-import without destroying directives or other
        agent state.

        Returns:
            Number of deleted memory rows.
        """

    @abstractmethod
    async def clone_agent(
        self,
        *,
        src_agent_id: str,
        tgt_agent_id: str,
        tgt_backend: BaseBackend | None = None,
    ) -> dict[str, int]:
        """Copy an agent's memories and directives onto a new ``agent_id``.

        When ``tgt_backend`` is ``None``, clones within the same backend
        using an optimized single-transaction path. When set, performs a
        cross-backend clone via export/import.

        Args:
            src_agent_id: Source agent to read from.
            tgt_agent_id: Destination agent to write under. Must not
                already have rows in ``memories`` or ``directives``.
            tgt_backend: Target backend for cross-backend clone. If
                ``None``, clones within ``self``.

        Returns:
            Per-table copy counts, e.g. ``{"memories": 42, "directives": 7}``.

        Raises:
            ValueError: If ``src_agent_id == tgt_agent_id`` or either is
                empty, or if ``tgt_agent_id`` already has data.
            BackendNotInitializedError: If ``tgt_backend`` is not initialized.
        """

    async def _cross_backend_clone(
        self,
        *,
        src_agent_id: str,
        tgt_agent_id: str,
        tgt_backend: BaseBackend,
    ) -> dict[str, int]:
        """Export from self, import into tgt_backend.

        Concrete method inherited by all backends. Validates that the
        target backend is initialized before proceeding.
        """
        if not getattr(tgt_backend, "_initialized", True):
            msg = (
                "Target backend is not initialized. "
                "Call await tgt_backend.initialize() first."
            )
            raise BackendNotInitializedError(msg)

        memories = await self.export_memories(agent_id=src_agent_id)
        directives = await self.export_directives(agent_id=src_agent_id)

        mem_ids = await tgt_backend.import_memories(
            agent_id=tgt_agent_id, memories=memories,
        )
        dir_ids = await tgt_backend.import_directives(
            agent_id=tgt_agent_id, directives=directives,
        )

        return {
            "memories": len(mem_ids),
            "directives": len(dir_ids),
        }

    # -- Dream checkpointing ---------------------------------------------------

    @abstractmethod
    async def save_dream_checkpoint(
        self,
        *,
        cycle_id: str,
        agent_id: str,
        last_completed_phase: str,
        state_blob: str,
        created_at: str,
    ) -> None:
        """Persist a dream cycle checkpoint (upsert).

        Written after each dream phase completes so the cycle can
        resume from the last good phase after a crash or shutdown.
        """

    @abstractmethod
    async def load_dream_checkpoint(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Load the most recent unclosed dream checkpoint for an agent.

        Returns:
            Dict with ``cycle_id``, ``last_completed_phase``,
            ``state_blob``, ``created_at`` — or ``None`` if no
            checkpoint exists.
        """

    @abstractmethod
    async def delete_dream_checkpoint(
        self,
        *,
        cycle_id: str,
        agent_id: str,
    ) -> None:
        """Remove a checkpoint after the cycle completes successfully."""

    # -- Dream scheduling -----------------------------------------------------

    @abstractmethod
    async def save_scheduled_dream(
        self,
        *,
        agent_id: str,
        interval_hours: float,
        at_time: str | None,
        paused: bool,
        ignore_budget: bool,
        next_run: str,
        last_run: str | None,
        created_at: str,
        updated_at: str,
    ) -> None:
        """Upsert the persistent dream schedule for ``agent_id``.

        One row per agent. Called on every mutation (initial schedule,
        pause/resume, reschedule, last_run bump). ``at_time`` is an
        optional ``HH:MM:SS`` wall-clock anchor; ``None`` means the
        schedule fires ``interval_hours`` after the most recent run.
        """

    @abstractmethod
    async def load_scheduled_dream(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Return the persisted schedule for ``agent_id`` or ``None``.

        Shape matches :meth:`save_scheduled_dream` kwargs, with ``paused``
        and ``ignore_budget`` coerced to bool.
        """

    @abstractmethod
    async def delete_scheduled_dream(
        self,
        *,
        agent_id: str,
    ) -> None:
        """Remove any persisted schedule for ``agent_id``.

        Idempotent — absent schedule is not an error.
        """

    # -- Provenance event log (append-only) ----------------------------------

    @abstractmethod
    async def append_provenance_event(
        self,
        *,
        event_id: str,
        agent_id: str,
        event_type: str,
        entity_type: str,
        entity_id: str,
        parent_event_id: str | None,
        payload: dict[str, Any],
        created_at: str,
    ) -> None:
        """Append a single row to the ``provenance_events`` log.

        This is the only write path for the event log. Implementations
        MUST refuse UPDATE and DELETE on ``provenance_events`` — the log
        is the system's evidence trail and is append-only by contract.
        Migration down-scripts may drop the table; application code may
        not mutate rows.
        """

    @abstractmethod
    async def query_provenance_events_by_entity(
        self,
        *,
        agent_id: str,
        entity_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        """Return events touching ``entity_id`` for ``agent_id``, oldest first.

        Used by ``trace()`` to reconstruct the chain behind an entity.
        The returned dict shape matches :meth:`append_provenance_event`
        kwargs with ``payload`` decoded from JSON.
        """

    @abstractmethod
    async def query_provenance_events_by_time(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        """Return events within a time window, oldest first.

        Used for bulk export and debugging. ``since`` and ``until`` are
        ISO 8601 UTC timestamps; either or both may be omitted.
        """

    @abstractmethod
    async def get_provenance_event(
        self,
        *,
        agent_id: str,
        event_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single event by id, or ``None`` if not found.

        The agent_id scope enforces tenant isolation — an event from
        another agent is never returned even if ``event_id`` exists.
        """

    @abstractmethod
    async def get_consolidation_candidates(
        self,
        *,
        agent_id: str,
        limit: int = 20,
        min_salience: float = 0.4,
        tier: str = "raw",
        lookback_days: int | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch memories eligible for Tier 2 consolidation.

        Selects memories ordered by reinforcement_count (desc), salience
        (desc), then recency (desc). The caller (consolidation pipeline)
        is responsible for further filtering.

        Args:
            agent_id: Agent whose memories to query.
            limit: Hard cap on number of candidates returned.
            min_salience: Minimum salience threshold.
            tier: Which tier to draw candidates from.
            lookback_days: Optional age window — when set, only memories
                with ``created_at`` newer than ``now - lookback_days``
                are returned. ``None`` (default) applies no time filter.

        Returns:
            List of memory dicts with at least ``id``, ``content``,
            ``event_type``, ``salience``, ``created_at``.
        """

    @abstractmethod
    async def rollback_cycle(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> int:
        """Delete all memories tagged with ``cycle_id`` for atomic rollback.

        Used when a consolidation run fails partway through.

        Returns:
            Number of rows deleted.
        """

    @abstractmethod
    async def run_decay_pass(
        self,
        *,
        agent_id: str,
        admin_defaults: AdminDefaults | None = None,
    ) -> dict[str, Any]:
        """Run a single deterministic decay pass over all memories.

        Explicit-only — never called from capture, search, or respond paths.
        The pass performs three operations in strict order:

        1. **Rescore** — Recompute salience for every eligible memory
           using ``compute_salience()`` and persist the new value.
        2. **Archive** — Memories older than ``admin_defaults.archive_days``
           (and not immune) are marked with ``archived_at`` timestamp.
           Original ``scope`` is preserved.
        3. **Weaken** — Memories older than ``admin_defaults.weaken_days``
           but not yet archived (and not immune) have salience multiplied
           by ``admin_defaults.decay_factor``, clamped to [0, 1].

        A memory receives archive OR weaken, never both.

        Immunity rules (applied before weaken/archive):
        - ``emotional_intensity >= admin_defaults.emotional_immunity_threshold`` → skip
        - ``event_type in DECAY_EXEMPT_TYPES`` → skip

        Returns:
            Dict with ``rescored``, ``weakened``, ``archived``,
            ``skipped_immune``, and ``total_examined`` counts.
        """

    @abstractmethod
    async def prune_expired_sessions(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any]:
        """Delete session-scoped memories whose TTL has expired.

        Unconditional — runs even when ``freeze_decay=True`` because
        session TTL is a hard contract, not a decay heuristic.

        A memory is eligible for prune when **all** of:
        - ``scope = 'session'``
        - ``ttl_hours > 0``
        - ``created_at + ttl_hours`` < now (UTC)

        Returns:
            Dict with ``pruned_count`` (int) and ``pruned_ids``
            (list[str]) for audit traceability.
        """

    @abstractmethod
    async def update_memory_embedding(
        self,
        *,
        agent_id: str,
        memory_id: str,
        embedding: list[float],
        embedding_model_id: str,
        embedding_dim: int,
    ) -> bool:
        """Update a single memory's embedding in-place.

        Used by the re-embed migration to recompute embeddings against
        a new model without re-importing.

        Returns:
            True if the row was updated, False if not found.
        """

    @abstractmethod
    async def iter_memories_for_reembed(
        self,
        *,
        agent_id: str,
        current_model_id: str,
        batch_size: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Fetch a batch of memories needing re-embedding.

        Returns memories where ``embedding IS NOT NULL`` and
        ``embedding_model_id`` differs from ``current_model_id``
        (or is NULL/empty). Ordered by ``created_at ASC`` for
        deterministic resumability.

        Args:
            agent_id: Agent whose memories to walk.
            current_model_id: The model ID to exclude (already migrated).
            batch_size: Max rows per batch.
            offset: Row offset for pagination.

        Returns:
            List of dicts with ``id``, ``content``, ``event_type``.
        """

    @abstractmethod
    async def export_memories(
        self,
        *,
        agent_id: str,
        include_session_memories: bool = True,
        tier_filter: str | None = None,
    ) -> list[dict[str, Any]]:
        """Export all memories for ``agent_id`` as portable dicts.

        Returns semantic content, metadata, and provenance fields only —
        no DB-specific or transient fields (embedding blobs, internal
        indexes, dedup pointers).

        Args:
            agent_id: Agent whose memories to export.
            include_session_memories: If False, exclude memories with
                ``scope='session'``.
            tier_filter: If set, only export memories of this tier
                (e.g. ``'raw'``, ``'consolidated'``, ``'reflection'``).

        Returns:
            List of JSON-serializable memory dicts.
        """

    @abstractmethod
    async def import_memories(
        self,
        *,
        agent_id: str,
        memories: list[dict[str, Any]],
    ) -> list[str]:
        """Bulk-write pre-validated memory dicts for ``agent_id``.

        Each dict is stored as a new memory with a fresh ID, tagged with
        the importing agent's ``agent_id``. Embeddings and dedup are
        handled by the caller (agent layer).

        Args:
            agent_id: Agent to import into.
            memories: Pre-validated memory dicts with at least
                ``event_type`` and ``content``.

        Returns:
            List of newly created memory IDs.
        """

    # --- Directives ---

    @abstractmethod
    async def store_directive(
        self,
        *,
        agent_id: str,
        directive_id: str,
        text: str,
        content_hash: str,
        status: str = "provisional",
        embedding: list[float] | None = None,
    ) -> str:
        """Store a new directive row.

        Args:
            agent_id: Owning agent.
            directive_id: Pre-generated unique ID.
            text: Directive content.
            content_hash: SHA-256 of normalized text for exact-dedup.
            status: Initial lifecycle status.
            embedding: Optional embedding vector for semantic dedup.

        Returns:
            The directive ID.
        """

    @abstractmethod
    async def get_directive(
        self,
        *,
        agent_id: str,
        directive_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single directive by ID, scoped to ``agent_id``.

        Returns:
            Directive dict, or ``None`` if not found.
        """

    @abstractmethod
    async def list_directives(
        self,
        *,
        agent_id: str,
        include_inactive: bool = False,
    ) -> list[dict[str, Any]]:
        """List directives for ``agent_id``.

        Args:
            agent_id: Owning agent.
            include_inactive: If True, include directives with
                ``status='inactive'``. Default False.

        Returns:
            List of directive dicts ordered by ``created_at``.
        """

    @abstractmethod
    async def count_active_directives(self, *, agent_id: str) -> int:
        """Count non-inactive directives for ``agent_id``.

        Used by capacity enforcement in ``DirectiveManager.add()``.
        """

    @abstractmethod
    async def update_directive_status(
        self,
        *,
        agent_id: str,
        directive_id: str,
        new_status: str,
        promoted_at: str | None = None,
    ) -> bool:
        """Update the status of a directive.

        Args:
            agent_id: Owning agent.
            directive_id: Directive to update.
            new_status: Target lifecycle status.
            promoted_at: Timestamp for promotion (set when promoting
                to ``permanent``).

        Returns:
            True if the row was updated, False if not found.
        """

    @abstractmethod
    async def find_similar_directive(
        self,
        *,
        agent_id: str,
        embedding: list[float],
        threshold: float = 0.95,
    ) -> tuple[str | None, float]:
        """Find the most similar non-inactive directive for ``agent_id``.

        Args:
            agent_id: Owning agent.
            embedding: Query embedding vector.
            threshold: Minimum cosine similarity to consider a match.

        Returns:
            Tuple of (directive_id, similarity) if a match is found,
            or (None, 0.0) if no match meets the threshold.
        """

    @abstractmethod
    async def run_directive_decay(
        self,
        *,
        agent_id: str,
        usage_threshold: int,
        age_days: int,
    ) -> dict[str, Any]:
        """Deactivate directives that have low usage and sufficient age.

        Permanent directives are exempt. Only ``provisional`` and ``active``
        directives are candidates.

        Args:
            agent_id: Owning agent.
            usage_threshold: Directives with ``usage_count`` below this
                are candidates.
            age_days: Directives must be older than this many days to
                be eligible.

        Returns:
            Dict with ``deactivated_count`` and ``deactivated_ids``.
        """

    @abstractmethod
    async def increment_directive_usage(
        self,
        *,
        agent_id: str,
        directive_ids: list[str],
    ) -> None:
        """Increment ``usage_count`` for the given directives.

        Used by ``DirectiveManager.reinforce()`` when the caller
        explicitly signals that a directive was used.
        """

    @abstractmethod
    async def export_directives(
        self,
        *,
        agent_id: str,
        include_inactive: bool = True,
    ) -> list[dict[str, Any]]:
        """Export all directives for ``agent_id`` as portable dicts.

        Returns text, metadata, and lifecycle fields only — no embedding
        blobs or DB-internal indexes. Every entry includes ``content_hash``
        for deterministic import dedup.

        Args:
            agent_id: Agent whose directives to export.
            include_inactive: If False, exclude ``status='inactive'``.

        Returns:
            List of JSON-serializable directive dicts.
        """

    @abstractmethod
    async def import_directives(
        self,
        *,
        agent_id: str,
        directives: list[dict[str, Any]],
    ) -> list[str]:
        """Bulk-write pre-validated directive dicts for ``agent_id``.

        Each dict is stored with a fresh ID and ``status='provisional'``
        regardless of the source status. Embeddings and dedup are handled
        by the caller (agent layer).

        Args:
            agent_id: Agent to import into.
            directives: Pre-validated directive dicts with at least
                ``text`` and ``content_hash``.

        Returns:
            List of newly created directive IDs.
        """

    @abstractmethod
    async def reset_directives(
        self,
        *,
        agent_id: str,
    ) -> dict[str, int]:
        """Delete all directives and proposals for ``agent_id``.

        Atomic — both tables cleared in a single transaction.

        Returns:
            Dict with ``directives`` and ``directive_proposals`` counts.
        """

    # --- Proposals ---

    @abstractmethod
    async def store_proposal(
        self,
        *,
        agent_id: str,
        proposal_id: str,
        action: str,
        text: str,
        content_hash: str,
        proposed_status: str,
        target_directive_id: str | None = None,
        reasoning: str = "",
    ) -> str:
        """Store a new directive proposal.

        Args:
            agent_id: Owning agent.
            proposal_id: Pre-generated unique ID.
            action: Proposed action (``add``, ``promote``, ``deactivate``).
            text: Full directive text (for ``add``) or target directive
                text (for ``promote``/``deactivate``).
            content_hash: SHA-256 of normalized text.
            proposed_status: The status the directive would have after
                approval (e.g., ``provisional``, ``active``, ``inactive``).
            target_directive_id: For ``promote``/``deactivate``, the
                existing directive being acted on.
            reasoning: Optional explanation for the proposal.

        Returns:
            The proposal ID.
        """

    @abstractmethod
    async def get_proposal(
        self,
        *,
        agent_id: str,
        proposal_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single proposal by ID, scoped to ``agent_id``.

        Returns:
            Proposal dict, or ``None`` if not found.
        """

    @abstractmethod
    async def list_proposals(self, *, agent_id: str) -> list[dict[str, Any]]:
        """List pending directive proposals for ``agent_id``."""

    @abstractmethod
    async def approve_proposal(
        self,
        proposal_id: str,
        *,
        agent_id: str,
        directive_id: str,
        embedding: list[float] | None = None,
        resolved_by: str = "",
    ) -> dict[str, Any]:
        """Approve a directive proposal atomically.

        Validates the proposal exists and is ``pending``, then executes
        the proposed action (create directive, update status) and marks
        the proposal resolved — all in one transaction.

        Args:
            proposal_id: The proposal to approve.
            agent_id: Owning agent.
            directive_id: Pre-generated ID for the new directive (for
                ``add`` actions). Ignored for ``promote``/``deactivate``.
            embedding: Embedding vector for the new directive (for
                ``add`` actions). Computed fresh at approve time.
            resolved_by: Structured JSON string describing who/what
                approved (e.g., ``{"actor":"operator","method":"manual"}``).

        Returns:
            Dict with ``action``, ``directive_id``, ``status`` describing
            what was executed.

        Raises:
            ValueError: If the proposal does not exist, is already
                resolved, or the target directive is in an invalid state.
        """

    @abstractmethod
    async def reject_proposal(
        self,
        proposal_id: str,
        *,
        agent_id: str,
        reason: str = "",
        resolved_by: str = "",
    ) -> None:
        """Reject a directive proposal.

        Args:
            proposal_id: The proposal to reject.
            agent_id: Owning agent.
            reason: Rejection reason.
            resolved_by: Structured JSON string.

        Raises:
            ValueError: If the proposal does not exist or is already
                resolved.
        """

    # --- Critic reviews ---

    @abstractmethod
    async def store_review(
        self,
        *,
        agent_id: str,
        review_id: str,
        output_text: str,
        context: dict[str, Any] | None,
        risk_level: str,
        flags: list[str],
        rationale: str,
        pass_through: bool,
        directive_ids: list[str],
        created_at: str,
    ) -> None:
        """Persist a critic review for ``agent_id``."""

    @abstractmethod
    async def get_reviews(
        self,
        *,
        agent_id: str,
        limit: int = 20,
        risk_level: str | None = None,
    ) -> list[dict[str, Any]]:
        """Query stored critic reviews, most recent first.

        Args:
            agent_id: Agent whose reviews to fetch.
            limit: Maximum number of reviews to return.
            risk_level: If provided, filter to this risk level only.
        """

    @abstractmethod
    async def get_review(
        self,
        review_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single critic review by ID.

        Returns:
            Review dict, or None if not found for this agent.
        """

    # --- Critic audits ---

    @abstractmethod
    async def store_audit(
        self,
        *,
        agent_id: str,
        audit_id: str,
        coherence_score: float,
        is_coherent: bool,
        contradictions: list[dict[str, str]],
        summary: str,
        directive_ids: list[str],
        directive_count: int,
        created_at: str,
    ) -> None:
        """Persist a coherence audit for ``agent_id``."""

    @abstractmethod
    async def get_audits(
        self,
        *,
        agent_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Query stored coherence audits, most recent first."""

    @abstractmethod
    async def get_audit(
        self,
        audit_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single coherence audit by ID.

        Returns:
            Audit dict, or None if not found for this agent.
        """

    @abstractmethod
    async def validate_memory_ids(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> set[str]:
        """Check which memory IDs exist and belong to ``agent_id``.

        Args:
            agent_id: Owning agent.
            memory_ids: IDs to validate.

        Returns:
            Set of IDs that exist and belong to the agent.
        """

    @abstractmethod
    async def get_memories_by_ids(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> list[dict[str, Any]]:
        """Fetch memory rows by ID, scoped to ``agent_id``.

        Returns memory dicts for IDs that exist and belong to the agent.
        Result order matches input ``memory_ids`` order for IDs that are
        found; missing IDs are silently omitted.

        Args:
            agent_id: Owning agent.
            memory_ids: IDs to fetch.

        Returns:
            List of memory dicts (``id``, ``content``, ``event_type``,
            ``salience``, ``created_at``, etc.).
        """

    @abstractmethod
    async def get_unjournaled_memories(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        limit: int = 50,
        max_memories_cap: int | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch unjournaled, non-archived memories for an agent.

        Returns synthesis-relevant fields only: ``id``, ``content``,
        ``event_type``, ``salience``, ``created_at``.

        Args:
            agent_id: Owning agent.
            since: ISO 8601 lower bound on ``created_at`` (inclusive).
                ``None`` means no lower bound (all unjournaled memories).
            limit: Maximum results. Clamped to ``max_memories_cap`` at
                the backend layer.
            max_memories_cap: Hard ceiling for ``limit``; typically
                ``AdminDefaults.journal_max_memories``. Defaults to the
                balanced archetype when omitted.

        Returns:
            List of memory dicts ordered by ``created_at ASC, id ASC``.
        """

    # --- Journals ---

    @abstractmethod
    async def store_journal(
        self,
        *,
        agent_id: str,
        journal_id: str,
        content: str,
        memory_ids: list[str],
        created_at: str,
    ) -> None:
        """Persist a journal entry and mark its source memories as journaled.

        Atomic — the journal row and memory ``journaled`` flag updates
        must succeed or fail together.

        Args:
            agent_id: Owning agent.
            journal_id: Pre-generated unique ID.
            content: Journal text content.
            memory_ids: Sorted, validated list of memory IDs covered by
                this journal entry. All must exist and belong to ``agent_id``.
            created_at: ISO 8601 timestamp.
        """

    @abstractmethod
    async def get_journals(
        self,
        *,
        agent_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Query stored journals for ``agent_id``, most recent first.

        Args:
            agent_id: Owning agent.
            limit: Maximum number of journals to return.

        Returns:
            List of journal dicts with ``id``, ``agent_id``, ``content``,
            ``memory_ids``, ``created_at``.
        """

    @abstractmethod
    async def get_journal(
        self,
        journal_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single journal by ID, scoped to ``agent_id``.

        Returns:
            Journal dict, or ``None`` if not found for this agent.
        """

    @abstractmethod
    async def mark_memories_journaled(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> int:
        """Mark memories as journaled. Idempotent.

        Sets ``journaled = 1`` on each memory identified by ``memory_ids``
        that belongs to ``agent_id``. Already-journaled memories are
        silently skipped (idempotent).

        Args:
            agent_id: Owning agent.
            memory_ids: Memory IDs to mark.

        Returns:
            Number of rows actually updated (excludes already-journaled).
        """

    # --- Dreams ---

    @abstractmethod
    async def store_dream_report(
        self,
        *,
        agent_id: str,
        report_id: str,
        cycle_id: str,
        started_at: str,
        completed_at: str,
        status: str,
        steps: str,
        duration_ms: int,
    ) -> None:
        """Persist a dream cycle report.

        Args:
            agent_id: Owning agent.
            report_id: Unique row ID.
            cycle_id: 12-char hex cycle identifier (UNIQUE).
            started_at: ISO 8601 start timestamp.
            completed_at: ISO 8601 completion timestamp.
            status: Overall status (``success`` | ``partial`` | ``failed``).
            steps: JSON-serialized step results array.
            duration_ms: Total wall-clock duration in milliseconds.
        """

    @abstractmethod
    async def get_dream_report(
        self, *, agent_id: str, cycle_id: str
    ) -> dict[str, Any] | None:
        """Retrieve a single dream report by ``cycle_id``.

        Returns:
            Report dict or ``None`` if not found.
        """

    @abstractmethod
    async def get_dream_history(
        self, *, agent_id: str, limit: int = 30
    ) -> list[dict[str, Any]]:
        """Retrieve past dream cycle reports for ``agent_id``.

        Returns most recent first: ``ORDER BY started_at DESC, id DESC``.
        """

    @abstractmethod
    async def get_cycle_insights(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> list[dict[str, Any]]:
        """Fetch reconsolidated insights produced in the given dream cycle.

        Args:
            agent_id: Owning agent.
            cycle_id: The dream cycle identifier (12-char hex).

        Returns:
            List of memory dicts with ``id``, ``content`` (raw JSON string),
            and ``created_at``. Empty list if no insights were stored with
            this ``cycle_id``. Ordered by ``created_at DESC``.
        """

    # --- Counts ---

    @abstractmethod
    async def get_agent_counts(self, *, agent_id: str) -> dict[str, int]:
        """Return entity counts for ``agent_id``.

        Returns:
            Dict with keys ``memories``, ``directives``, ``journals``,
            ``dream_reports`` — each an integer count.
        """

    @abstractmethod
    async def get_evolution_summary(self, *, agent_id: str) -> dict[str, Any]:
        """Return evolution data for ``agent_id``'s status narrative.

        Returns:
            Dict with:

            - ``first_seen``: ISO 8601 timestamp of earliest entity, or ``None``
            - ``memories_by_tier``: ``{raw: int, consolidated: int, reflective: int}``
            - ``directives_by_status``: ``{provisional: int, active: int,
              permanent: int, inactive: int}``
            - ``dream_count``: total dream cycles completed
            - ``last_dream_at``: ISO 8601 of most recent dream, or ``None``
            - ``journal_count``: total journal entries
            - ``total_consolidated``: count of consolidated + reflective memories
        """

    # --- Analytics ---

    @abstractmethod
    async def get_health(self, *, agent_id: str) -> dict[str, Any]:
        """Get current cognitive health metrics for ``agent_id``."""

    @abstractmethod
    async def append_health_snapshot(
        self,
        *,
        agent_id: str,
        snapshot_date: str,
        payload: str,
        created_at: str,
    ) -> None:
        """Upsert a health snapshot for ``(agent_id, snapshot_date)``.

        ``snapshot_date`` is ``YYYY-MM-DD``. Multiple writes on the same
        day overwrite the prior payload — the last write wins so manual
        ``capture_snapshot`` calls refresh the scheduler's nightly entry
        when they fire later.

        ``payload`` is an opaque JSON string. Implementations must not
        parse it; the reader owns the schema.
        """

    @abstractmethod
    async def query_health_snapshots(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return health snapshots for ``agent_id`` in date order (ascending).

        ``since`` / ``until`` are inclusive ``YYYY-MM-DD`` bounds.
        ``None`` means unbounded. Missing days are returned as gaps
        (i.e. absent from the list) — no zero-filling, per spec.
        """

    @abstractmethod
    async def get_health_report_stats(
        self, *, agent_id: str, window_days: int = 7
    ) -> dict[str, Any]:
        """Return the raw aggregates backing a :class:`HealthReport`.

        Shape::

            {
                "memory": {
                    "stream_count": int,
                    "consolidated_count": int,
                    "journal_count": int,
                    "avg_salience": float,
                    "dedup_rate_7d": float,
                    "captures_7d": int,
                    "reinforced_count": int,
                    "total_memories": int,
                    "event_type_counts": dict[str, int],
                },
                "directives": {
                    "provisional_count": int,
                    "active_count": int,
                    "permanent_count": int,
                    "inactive_count": int,
                    "demotion_rate_7d": float,
                    "avg_age_days": float,
                },
                "dreams": {
                    "runs_7d": int,
                    "success_count_7d": int,
                    "failure_count_7d": int,
                    "success_rate_7d": float,
                    "avg_duration_ms": float,
                    "last_run_iso": str | None,
                },
                "cost": {
                    "tokens_7d": int,
                    "usd_7d": float,
                    "dream_tokens_7d": int,
                },
                "critic": {
                    "reviews_7d": int,
                    "pass_rate_7d": float,
                },
                "journals": {
                    "entries_7d": int,
                    "days_since_last_journal": float | None,
                },
            }

        Implementations compute these aggregates directly over the
        persisted tables — no materialized views required.
        """

    # --- Cost ledger (v0.5 Phase 4) ---------------------------------------

    @abstractmethod
    async def append_cost_record(
        self,
        *,
        record_id: str,
        agent_id: str,
        model_id: str,
        category: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        cycle_id: str | None,
        event_id: str | None,
        purpose: str,
        created_at: str,
    ) -> None:
        """Append a single row to the cost ledger (``cost_records``).

        Append-only — the row is a point-in-time observation. ``category``
        is the v0.5 Phase 4 classifier (``capture`` / ``dream.<phase>`` /
        ``explain`` / ``ad_hoc``); ``purpose`` is the pre-v0.5 free-form
        label and is kept for back-compat with existing callers.
        """

    @abstractmethod
    async def query_cost_records(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        category: str | None = None,
        cycle_id: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return ledger rows for ``agent_id`` in chronological order.

        ``since`` and ``until`` are inclusive ISO 8601 bounds. ``category``
        and ``cycle_id`` further narrow the window. Ordered by
        ``created_at ASC, id ASC``.
        """

    @abstractmethod
    async def sum_cost_by_cycle(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> list[dict[str, Any]]:
        """Return per-category totals for a dream cycle.

        Shape: ``[{"category": str, "model_id": str, "input_tokens": int,
        "output_tokens": int, "cost_usd": float, "calls": int}, ...]``.
        Used by ``DreamReport.cost_breakdown`` to split by phase and
        model — the consumer is the dreams pipeline, not end users.
        """

    @abstractmethod
    async def cost_summary_aggregate(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
    ) -> dict[str, Any]:
        """Return summary aggregates for ``agent.cost.summary()``.

        Shape::

            {
                "total_cost_usd": float,
                "total_input_tokens": int,
                "total_output_tokens": int,
                "total_calls": int,
                "by_category": {cat: {"cost_usd": float, "calls": int,
                                      "input_tokens": int,
                                      "output_tokens": int}, ...},
                "by_model": {model_id: {"cost_usd": float, "calls": int,
                                        "input_tokens": int,
                                        "output_tokens": int}, ...},
            }
        """

    # --- Atomic facts (Beta in v1.0) ----------------------------------------
    #
    # Concrete defaults raise NotImplementedError so backends without a
    # `facts` table (e.g. the v1.0 PostgresBackend skeleton) can ship
    # unchanged. SQLiteBackend overrides all four. Add a fact table to
    # any new backend by overriding these alongside writing the matching
    # migration in `storage/migrations/<dialect>/`.

    async def store_fact(
        self,
        *,
        fact_id: str,
        agent_id: str,
        subject: str,
        attribute: str,
        value: str,
        source_memory_id: str | None,
        confidence: float,
        decay_rate: float,
        created_at: str,
    ) -> str:
        """Persist a single extracted fact.

        Last-write-wins semantics in v1.0: callers don't reconcile against
        existing rows. Older rows for the same ``(agent_id, subject,
        attribute)`` are retained; ``list_facts_for_subject`` returns the
        most recent first. Reconciliation is a v1.0.1 concern.

        Returns:
            The ``fact_id`` (echoed for convenience).
        """
        msg = (
            f"{type(self).__name__} does not support fact storage. "
            "Use SQLiteBackend or override `store_fact`."
        )
        raise NotImplementedError(msg)

    async def search_facts(
        self,
        *,
        agent_id: str,
        query: str,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Search facts by substring match across subject/attribute/value.

        v1.0 uses a simple LIKE-based scan with most-recent-first ordering;
        a future revision may add embedding-based ranking. Returns at most
        ``limit`` rows.
        """
        msg = (
            f"{type(self).__name__} does not support fact search. "
            "Use SQLiteBackend or override `search_facts`."
        )
        raise NotImplementedError(msg)

    async def list_facts_for_subject(
        self,
        *,
        agent_id: str,
        subject: str,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Return all facts about ``subject`` for ``agent_id``, newest first.

        Used by the Critic's grounding verifier and by GDPR-style
        ``agent.facts.export_subject()`` lookups.
        """
        msg = (
            f"{type(self).__name__} does not support fact listing. "
            "Use SQLiteBackend or override `list_facts_for_subject`."
        )
        raise NotImplementedError(msg)

    async def list_facts_for_memory(
        self,
        *,
        agent_id: str,
        memory_id: str,
    ) -> list[dict[str, Any]]:
        """Return every fact extracted from ``memory_id``.

        Used by provenance tracing — closes the loop from a captured
        conversation back to the atomic claims it contributed.
        """
        msg = (
            f"{type(self).__name__} does not support fact listing. "
            "Use SQLiteBackend or override `list_facts_for_memory`."
        )
        raise NotImplementedError(msg)
