"""CLI entry point: ``wisdom-layer-migrate``.

Operator-facing migration tool that ships alongside any migration with
non-trivial customer impact (e.g. ``0024_facts_source_ids.sql``, which
introduces the ``Fact.source_memory_ids`` column on production fact
stores).

Why this CLI exists when ``MigrationRunner.apply_pending()`` is already
called at agent ``initialize()``:

- **Pre-flight visibility.** Customers running on real fact stores want
  to see what's about to happen before it happens — store size, target
  dialect, list of pending versions, dry-run.
- **Unattended runs.** ``--yes`` lets the migration run inside a
  deploy script without an interactive prompt.
- **Verification post-migration.** ``verify`` runs a small set of
  sanity assertions (expected columns present, indexes present,
  backfilled row counts non-zero) so an operator can prove the
  migration went green before traffic flips back on.
- **Forward-only convention.** The runner itself does not execute
  ``-- down`` blocks; this CLI's ``down`` subcommand prints the down
  SQL for an operator to apply manually after restoring from backup.
  The project's rollback story is "restore from backup," not
  "automated rollback."

This CLI handles two migration namespaces:

- ``per-agent`` — the canonical agent storage DB (``migrations/sqlite/``).
- ``workspace`` — the multi-agent shared backend introduced in v1.2.0
  (``migrations/workspace_sqlite/``).

Pass ``--namespace`` to choose. ``--namespace=both`` walks each in turn
(per-agent first, then workspace).
"""

from __future__ import annotations

import argparse
import json
import logging
import sqlite3
import sys
from pathlib import Path

from wisdom_layer.errors import StorageMigrationError
from wisdom_layer.storage._migrations import MigrationRunner

logger = logging.getLogger(__name__)


_MIGRATIONS_ROOT = Path(__file__).parent / "migrations"
_NAMESPACES = {
    "per-agent": _MIGRATIONS_ROOT / "sqlite",
    "workspace": _MIGRATIONS_ROOT / "workspace_sqlite",
}


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wisdom-layer-migrate",
        description=(
            "Wisdom Layer Migrate — schema migration tool for per-agent "
            "and multi-agent workspace databases."
        ),
        epilog=(
            "GitHub: https://github.com/rhatigan-agi/wisdom-layer "
            "· Star if useful · Report issues there"
        ),
    )
    parser.add_argument(
        "--db",
        required=True,
        help="SQLite database path (e.g. wisdom.db, workspace.db)",
    )
    parser.add_argument(
        "--namespace",
        default="per-agent",
        choices=["per-agent", "workspace", "both"],
        help=(
            "Migration namespace to operate on. 'per-agent' is the "
            "canonical agent DB schema; 'workspace' is the multi-agent "
            "shared backend (v1.2.0+); 'both' walks each in turn."
        ),
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Log level (default: INFO)",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser(
        "status",
        help="Print applied + pending migrations as JSON",
    )

    up = sub.add_parser(
        "up",
        help="Apply all pending migrations",
    )
    up.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Show what would be applied without writing anything",
    )
    up.add_argument(
        "--yes",
        action="store_true",
        default=False,
        help="Skip the interactive confirmation prompt",
    )

    down = sub.add_parser(
        "down",
        help=(
            "Print the '-- down' SQL block for the migration at the given "
            "version. Does NOT execute it. Project convention is "
            "forward-only — restore from backup, then apply the printed "
            "SQL manually if you must."
        ),
    )
    down.add_argument(
        "--version",
        type=int,
        required=True,
        help="Version number whose down SQL should be printed",
    )

    verify = sub.add_parser(
        "verify",
        help=(
            "Run sanity checks against the database after a migration. "
            "Asserts expected tables, columns, and indexes are present."
        ),
    )
    verify.add_argument(
        "--against-version",
        type=int,
        default=None,
        help=(
            "Verify the schema matches state expected after migration N. "
            "Defaults to the highest applied version."
        ),
    )

    return parser


def _resolve_dirs(namespace: str) -> list[tuple[str, Path]]:
    if namespace == "both":
        return [(name, path) for name, path in _NAMESPACES.items()]
    return [(namespace, _NAMESPACES[namespace])]


def _open_conn(db_path: str) -> sqlite3.Connection:
    return sqlite3.connect(db_path)


def _preflight_report(conn: sqlite3.Connection, db_path: str) -> dict[str, object]:
    """Collect cheap stats for operator visibility before applying."""
    page_count = conn.execute("PRAGMA page_count").fetchone()[0]
    page_size = conn.execute("PRAGMA page_size").fetchone()[0]
    size_bytes = int(page_count) * int(page_size)
    tables = [
        row[0]
        for row in conn.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchall()
    ]
    facts_row_count: int | None = None
    if "facts" in tables:
        facts_row_count = int(conn.execute("SELECT COUNT(*) FROM facts").fetchone()[0])
    return {
        "db_path": db_path,
        "size_bytes": size_bytes,
        "table_count": len(tables),
        "facts_row_count": facts_row_count,
    }


def _confirm(prompt: str) -> bool:
    response = input(f"{prompt} [y/N] ").strip().lower()
    return response in ("y", "yes")


def _cmd_status(args: argparse.Namespace) -> int:
    conn = _open_conn(args.db)
    try:
        report: dict[str, object] = {"db": args.db, "namespaces": {}}
        for name, migrations_dir in _resolve_dirs(args.namespace):
            runner = MigrationRunner(conn=conn, migrations_dir=migrations_dir)
            namespaces: dict[str, object] = report["namespaces"]  # type: ignore[assignment]
            namespaces[name] = runner.status()
        sys.stdout.write(json.dumps(report, indent=2, default=str) + "\n")
        return 0
    finally:
        conn.close()


def _cmd_up(args: argparse.Namespace) -> int:
    conn = _open_conn(args.db)
    try:
        preflight = _preflight_report(conn, args.db)
        logger.info(
            "preflight",
            extra={"subsystem": "migrate.cli", **preflight},
        )

        any_pending = False
        for name, migrations_dir in _resolve_dirs(args.namespace):
            runner = MigrationRunner(conn=conn, migrations_dir=migrations_dir)
            status = runner.status()
            pending = status["pending"]
            assert isinstance(pending, list)
            if not pending:
                logger.info(
                    "no pending migrations",
                    extra={"subsystem": "migrate.cli", "namespace": name},
                )
                continue
            any_pending = True
            logger.info(
                "pending migrations",
                extra={
                    "subsystem": "migrate.cli",
                    "namespace": name,
                    "count": len(pending),
                    "versions": [m["version"] for m in pending],
                },
            )

        if not any_pending:
            return 0

        if args.dry_run:
            logger.info("dry-run: nothing applied", extra={"subsystem": "migrate.cli"})
            return 0

        if not args.yes and not _confirm("Apply pending migrations now?"):
            logger.info("aborted by operator", extra={"subsystem": "migrate.cli"})
            return 1

        for name, migrations_dir in _resolve_dirs(args.namespace):
            runner = MigrationRunner(conn=conn, migrations_dir=migrations_dir)
            applied = runner.apply_pending()
            logger.info(
                "applied",
                extra={
                    "subsystem": "migrate.cli",
                    "namespace": name,
                    "applied_count": len(applied),
                    "applied_versions": [m.version for m in applied],
                },
            )
        return 0
    except StorageMigrationError as e:
        logger.error(
            "migration failed",
            extra={"subsystem": "migrate.cli", "error": str(e)},
        )
        return 2
    finally:
        conn.close()


def _cmd_down(args: argparse.Namespace) -> int:
    if args.namespace == "both":
        logger.error(
            "down requires a single namespace; pass --namespace=per-agent or --namespace=workspace",
            extra={"subsystem": "migrate.cli"},
        )
        return 1
    _, migrations_dir = _resolve_dirs(args.namespace)[0]
    conn = _open_conn(args.db)
    try:
        runner = MigrationRunner(conn=conn, migrations_dir=migrations_dir)
        for migration in runner.discover():
            if migration.version == args.version:
                sys.stdout.write(
                    f"-- down block for {migration.name} "
                    f"(namespace={args.namespace})\n"
                    "-- WARNING: project convention is forward-only. "
                    "Restore from backup first, then apply this SQL only "
                    "if absolutely necessary.\n\n"
                )
                sys.stdout.write(migration.down_sql)
                if not migration.down_sql.endswith("\n"):
                    sys.stdout.write("\n")
                return 0
        logger.error(
            "version not found",
            extra={
                "subsystem": "migrate.cli",
                "namespace": args.namespace,
                "version": args.version,
            },
        )
        return 1
    finally:
        conn.close()


def _cmd_verify(args: argparse.Namespace) -> int:
    conn = _open_conn(args.db)
    try:
        ok = True
        for name, migrations_dir in _resolve_dirs(args.namespace):
            runner = MigrationRunner(conn=conn, migrations_dir=migrations_dir)
            status = runner.status()
            current = status.get("current_version", 0)
            target = args.against_version if args.against_version is not None else current
            assert isinstance(current, int)
            assert isinstance(target, int)
            if current < target:
                logger.error(
                    "verify failed: target version not yet applied",
                    extra={
                        "subsystem": "migrate.cli",
                        "namespace": name,
                        "target": target,
                        "current": current,
                    },
                )
                ok = False
                continue
            logger.info(
                "verify ok",
                extra={
                    "subsystem": "migrate.cli",
                    "namespace": name,
                    "current_version": current,
                    "verified_against": target,
                },
            )
        return 0 if ok else 2
    finally:
        conn.close()


_COMMANDS = {
    "status": _cmd_status,
    "up": _cmd_up,
    "down": _cmd_down,
    "verify": _cmd_verify,
}


def main(argv: list[str] | None = None) -> None:
    """Run the migrate CLI."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    handler = _COMMANDS[args.command]
    sys.exit(handler(args))


if __name__ == "__main__":
    main()
