"""SQL migration files, organized by backend dialect.

Each dialect subfolder holds numbered ``NNNN_name.sql`` files that the
:class:`wisdom_layer.storage._migrations.MigrationRunner` applies in order.

Layout (v0.6+):

- ``sqlite/`` — the default free-tier backend. Applied by
  :class:`wisdom_layer.storage.sqlite.SQLiteBackend`.
- ``postgres/`` — the Pro/Enterprise production backend. Applied by
  :class:`wisdom_layer.storage.postgres.PostgresBackend`.

Files in the two folders share the same ``NNNN_description.sql`` stem so
a given schema version is a dialect pair — ``sqlite/0015_scheduled_dreams.sql``
and ``postgres/0015_scheduled_dreams.sql`` both represent schema v15,
one written against SQLite's dialect, the other against PostgreSQL's.
The runner selects the correct folder by dialect at boot; individual
backends do not know about the other dialect's files.

Contract (doc 06 §0.2):

- Migration numbers are **append-only** within each dialect. Phases that
  need schema changes add NEW files with the next number to BOTH
  dialects. A merged migration is never edited.
- Every up block must use ``IF NOT EXISTS`` (or another idempotent form)
  so a partial apply followed by a retry is safe.
- The runner refuses to roll back; customers recover by restoring from
  backup. The ``-- down`` block exists for manual operator use, not for
  runtime downgrades.
- SQLite and Postgres files at the same version number MUST produce
  schema-equivalent state (same column set, same index coverage, same
  constraints). The contract test suite enforces this by running the
  same assertions against both.

Canonical sequence (v0.2.3 → v0.5): 0001 base schema through 0018 cost
ledger. See each file header for the phase that introduced it.
"""
