-- 0001_workspace.sql
-- Multi-agent workspace schema — initial cut for v1.2.0.
--
-- This migration establishes the schema for `workspace.db`, the
-- shared backend that holds all cross-agent state for a single
-- multi-agent deployment. One file per workspace; per-agent state
-- continues to live in each agent's own database (migrations/sqlite/).
--
-- Architectural boundary:
--   - Per-agent backend  (migrations/sqlite/)  → memories, facts,
--     directives, journals, provenance_events, single-agent state.
--   - Workspace backend  (migrations/workspace_sqlite/) → workspaces,
--     agent_directory, shared_memory_pool, endorsements/contentions,
--     team_insights, cross-agent provenance.
--
-- The walls between the two are deliberate: a contributing agent's
-- private memory is *back-referenced* from shared_memory_pool.source_memory_id
-- but never copied. The provenance walk crosses the boundary by
-- looking up the back-reference in the agent's own DB. Compromising
-- workspace.db never exposes private memory content.
--
-- Tables in this migration:
--   workspaces                       — top-level container, one row per workspace
--   agent_directory                  — capability-tagged roster of registered agents
--   shared_memory_pool               — promoted memories with denormalized counters
--   shared_memory_endorsements       — audit: which agent endorsed what (prevents double-count)
--   shared_memory_contentions        — audit: which agent contested + reason
--   team_insights                    — collective reconsolidation outputs
--   team_insight_contributions       — M-to-N: source shared memories per insight
--   cross_agent_provenance_events    — workspace-scoped event log (mirror of
--                                       per-agent provenance_events; append-only by contract)
--
-- Visibility enum (enforced application-side, not via CHECK):
--   PRIVATE  — never appears in shared_memory_pool by definition; reserved
--              for the back-reference target in each agent's own DB
--   TEAM     — visible to all registered agents in this workspace
--   PUBLIC   — visible workspace-wide AND surfaced via list/search regardless
--              of contributor exclusion filters
--
-- Team scoring (computed on read, denormalized on write):
--   team_score = base_score + (0.1 * endorsement_count) - (0.2 * contention_count)
--
-- Append-only invariant on cross_agent_provenance_events: the workspace
-- backend exposes no UPDATE/DELETE method for this table. Hash-chain
-- tamper evidence (event_hash, prev_hash) is deferred to v1.3.0.

-- up

CREATE TABLE IF NOT EXISTS workspaces (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    license_jti     TEXT NOT NULL,
    config          TEXT NOT NULL DEFAULT '{}',
    feature_flags   TEXT NOT NULL DEFAULT '{}',
    created_at      TEXT NOT NULL,
    archived_at     TEXT
);

CREATE INDEX IF NOT EXISTS idx_workspaces_license
    ON workspaces (license_jti);

CREATE INDEX IF NOT EXISTS idx_workspaces_active
    ON workspaces (archived_at);


CREATE TABLE IF NOT EXISTS agent_directory (
    workspace_id        TEXT NOT NULL,
    agent_id            TEXT NOT NULL,
    capabilities        TEXT NOT NULL DEFAULT '[]',
    registered_at       TEXT NOT NULL,
    last_seen_at        TEXT,
    past_success_rate   REAL NOT NULL DEFAULT 0.0,
    archived_at         TEXT,
    PRIMARY KEY (workspace_id, agent_id)
);

-- Composite index supports both the "active within Δ" filter and the
-- archived/active partition. Most directory queries filter
-- archived_at IS NULL first, then bound on last_seen_at.
CREATE INDEX IF NOT EXISTS idx_agent_directory_workspace
    ON agent_directory (workspace_id, archived_at, last_seen_at);


CREATE TABLE IF NOT EXISTS shared_memory_pool (
    id                  TEXT PRIMARY KEY,
    workspace_id        TEXT NOT NULL,
    contributor_id      TEXT NOT NULL,
    source_memory_id    TEXT NOT NULL,
    visibility          TEXT NOT NULL DEFAULT 'TEAM',
    content             TEXT NOT NULL,
    reason              TEXT NOT NULL DEFAULT '',
    endorsement_count   INTEGER NOT NULL DEFAULT 0,
    contention_count    INTEGER NOT NULL DEFAULT 0,
    base_score          REAL NOT NULL DEFAULT 0.0,
    shared_at           TEXT NOT NULL,
    archived_at         TEXT
);

CREATE INDEX IF NOT EXISTS idx_shared_pool_workspace_visibility
    ON shared_memory_pool (workspace_id, visibility, archived_at);

CREATE INDEX IF NOT EXISTS idx_shared_pool_contributor
    ON shared_memory_pool (workspace_id, contributor_id, shared_at DESC);

CREATE INDEX IF NOT EXISTS idx_shared_pool_source_memory
    ON shared_memory_pool (source_memory_id);

CREATE INDEX IF NOT EXISTS idx_shared_pool_workspace_score
    ON shared_memory_pool (workspace_id, base_score DESC);


CREATE TABLE IF NOT EXISTS shared_memory_endorsements (
    shared_memory_id    TEXT NOT NULL,
    endorsing_agent_id  TEXT NOT NULL,
    endorsed_at         TEXT NOT NULL,
    PRIMARY KEY (shared_memory_id, endorsing_agent_id)
);

CREATE INDEX IF NOT EXISTS idx_endorsements_agent
    ON shared_memory_endorsements (endorsing_agent_id, endorsed_at DESC);


CREATE TABLE IF NOT EXISTS shared_memory_contentions (
    shared_memory_id    TEXT NOT NULL,
    contesting_agent_id TEXT NOT NULL,
    reason              TEXT NOT NULL DEFAULT '',
    contested_at        TEXT NOT NULL,
    PRIMARY KEY (shared_memory_id, contesting_agent_id)
);

CREATE INDEX IF NOT EXISTS idx_contentions_agent
    ON shared_memory_contentions (contesting_agent_id, contested_at DESC);


CREATE TABLE IF NOT EXISTS team_insights (
    id                      TEXT PRIMARY KEY,
    workspace_id            TEXT NOT NULL,
    content                 TEXT NOT NULL,
    synthesis_prompt_hash   TEXT NOT NULL,
    contributor_count       INTEGER NOT NULL DEFAULT 0,
    dream_cycle_id          TEXT,
    created_at              TEXT NOT NULL,
    archived_at             TEXT
);

CREATE INDEX IF NOT EXISTS idx_team_insights_workspace
    ON team_insights (workspace_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_team_insights_dream_cycle
    ON team_insights (dream_cycle_id);


CREATE TABLE IF NOT EXISTS team_insight_contributions (
    team_insight_id         TEXT NOT NULL,
    shared_memory_id        TEXT NOT NULL,
    contributor_agent_id    TEXT NOT NULL,
    contribution_weight     REAL NOT NULL DEFAULT 1.0,
    PRIMARY KEY (team_insight_id, shared_memory_id)
);

CREATE INDEX IF NOT EXISTS idx_team_insight_contrib_agent
    ON team_insight_contributions (contributor_agent_id);

CREATE INDEX IF NOT EXISTS idx_team_insight_contrib_shared_memory
    ON team_insight_contributions (shared_memory_id);


CREATE TABLE IF NOT EXISTS cross_agent_provenance_events (
    event_id            TEXT PRIMARY KEY,
    workspace_id        TEXT NOT NULL,
    event_type          TEXT NOT NULL,
    actor_agent_id      TEXT,
    target_agent_id     TEXT,
    entity_type         TEXT NOT NULL,
    entity_id           TEXT NOT NULL,
    parent_event_id     TEXT,
    payload             TEXT NOT NULL DEFAULT '{}',
    created_at          TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_xagent_prov_entity
    ON cross_agent_provenance_events (workspace_id, entity_id, created_at);

CREATE INDEX IF NOT EXISTS idx_xagent_prov_time
    ON cross_agent_provenance_events (workspace_id, created_at);

CREATE INDEX IF NOT EXISTS idx_xagent_prov_actor
    ON cross_agent_provenance_events (workspace_id, actor_agent_id, created_at);

CREATE INDEX IF NOT EXISTS idx_xagent_prov_parent
    ON cross_agent_provenance_events (parent_event_id);

-- down

DROP INDEX IF EXISTS idx_xagent_prov_parent;
DROP INDEX IF EXISTS idx_xagent_prov_actor;
DROP INDEX IF EXISTS idx_xagent_prov_time;
DROP INDEX IF EXISTS idx_xagent_prov_entity;
DROP TABLE IF EXISTS cross_agent_provenance_events;

DROP INDEX IF EXISTS idx_team_insight_contrib_shared_memory;
DROP INDEX IF EXISTS idx_team_insight_contrib_agent;
DROP TABLE IF EXISTS team_insight_contributions;

DROP INDEX IF EXISTS idx_team_insights_dream_cycle;
DROP INDEX IF EXISTS idx_team_insights_workspace;
DROP TABLE IF EXISTS team_insights;

DROP INDEX IF EXISTS idx_contentions_agent;
DROP TABLE IF EXISTS shared_memory_contentions;

DROP INDEX IF EXISTS idx_endorsements_agent;
DROP TABLE IF EXISTS shared_memory_endorsements;

DROP INDEX IF EXISTS idx_shared_pool_workspace_score;
DROP INDEX IF EXISTS idx_shared_pool_source_memory;
DROP INDEX IF EXISTS idx_shared_pool_contributor;
DROP INDEX IF EXISTS idx_shared_pool_workspace_visibility;
DROP TABLE IF EXISTS shared_memory_pool;

DROP INDEX IF EXISTS idx_agent_directory_workspace;
DROP TABLE IF EXISTS agent_directory;

DROP INDEX IF EXISTS idx_workspaces_active;
DROP INDEX IF EXISTS idx_workspaces_license;
DROP TABLE IF EXISTS workspaces;
