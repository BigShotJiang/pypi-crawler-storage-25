-- 0002_messaging.sql
-- Multi-C: agent-to-agent messaging schema.
--
-- Adds the four tables that back v1.2.0 Multi-C messaging:
--
--   agent_messages           — direct + broadcast messages (one row per
--                              send; broadcasts are NOT fanned out to one
--                              row per recipient — they live as a single
--                              row with `broadcast_capability` set).
--   broadcast_reads          — per-(message, reader) ack rows for
--                              broadcasts. Direct messages track read /
--                              replied state on `agent_messages` itself;
--                              broadcasts have N readers so per-row
--                              status would be wrong shape.
--   message_threads          — thread closure state (thread_id +
--                              close_reason + close_metadata). Threads
--                              are an emergent property of replies; the
--                              row in this table only exists once
--                              `ThreadExitPolicy` trips a gate.
--   message_rate_limit_log   — rolling-window counters used by the
--                              MessageBus to enforce per-agent and
--                              broadcast rate limits without scanning
--                              `agent_messages` each call. Append-only;
--                              old rows are pruned by `MessageBus` after
--                              the rate-limit window expires.
--
-- Thread model:
--   * thread_id = the root message's id (the first message in the chain).
--   * Replies set `in_reply_to = parent.id` AND `thread_id = parent.thread_id`.
--   * Closure: a row in `message_threads` with `closed_at IS NOT NULL`
--     means no further replies should append; the SDK enforces this at
--     the bus layer (`MessageBus.reply` raises if the thread is closed).
--
-- Broadcast model:
--   * `recipient_id IS NULL AND broadcast_capability IS NOT NULL` for a
--     broadcast row. The CHECK constraint pins this invariant.
--   * Recipients are matched at read time by joining the agent
--     capability filter — never fanned out at write time, so a new agent
--     joining the workspace mid-conversation immediately sees historical
--     broadcasts that match their capabilities.
--   * `broadcast_reads` carries the per-recipient ack row so
--     `check_inbox()` can hide already-read broadcasts.
--
-- Rate limits (enforced application-side, not as a CHECK):
--   max_messages_per_agent_per_hour  = 100  — direct + broadcast combined
--   broadcast_rate_limit_per_hour    = 10   — broadcasts only
--
-- Cross-agent provenance event coupling:
--   Sending a message emits `message.sent` (actor=sender, target=recipient
--   for direct; target=NULL for broadcast).
--   Reading a message emits `message.received` (actor=reader,
--   entity_id=message_id).
--   Replying emits `message.replied` (actor=replier, entity_id=parent
--   message_id, payload carries reply_message_id).
--   ThreadExitPolicy closure emits `message.thread_closed` (actor=NULL,
--   entity_id=thread_id, payload carries close_reason + metadata).
--   Constants live in `XAgentEventType`.

-- up

CREATE TABLE IF NOT EXISTS agent_messages (
    id                      TEXT PRIMARY KEY,
    workspace_id            TEXT NOT NULL,
    sender_id               TEXT NOT NULL,
    recipient_id            TEXT,
    broadcast_capability    TEXT,
    content                 TEXT NOT NULL,
    purpose                 TEXT NOT NULL,
    related_memory_ids      TEXT NOT NULL DEFAULT '[]',
    related_task_id         TEXT,
    thread_id               TEXT NOT NULL,
    in_reply_to             TEXT,
    expects_reply           INTEGER NOT NULL DEFAULT 1,
    reply_deadline          TEXT,
    status                  TEXT NOT NULL DEFAULT 'pending',
    read_at                 TEXT,
    replied_at              TEXT,
    reply_message_id        TEXT,
    created_at              TEXT NOT NULL,
    CHECK (
        (recipient_id IS NOT NULL AND broadcast_capability IS NULL)
        OR
        (recipient_id IS NULL AND broadcast_capability IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS idx_messages_recipient_status
    ON agent_messages (workspace_id, recipient_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_messages_sender_time
    ON agent_messages (workspace_id, sender_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_messages_thread
    ON agent_messages (workspace_id, thread_id, created_at);

CREATE INDEX IF NOT EXISTS idx_messages_broadcast
    ON agent_messages (workspace_id, broadcast_capability, created_at DESC);


CREATE TABLE IF NOT EXISTS broadcast_reads (
    message_id          TEXT NOT NULL,
    reader_agent_id     TEXT NOT NULL,
    read_at             TEXT NOT NULL,
    PRIMARY KEY (message_id, reader_agent_id)
);

CREATE INDEX IF NOT EXISTS idx_broadcast_reads_reader
    ON broadcast_reads (reader_agent_id, read_at DESC);


CREATE TABLE IF NOT EXISTS message_threads (
    workspace_id        TEXT NOT NULL,
    thread_id           TEXT NOT NULL,
    closed_at           TEXT,
    close_reason        TEXT,
    close_metadata      TEXT NOT NULL DEFAULT '{}',
    PRIMARY KEY (workspace_id, thread_id)
);

CREATE INDEX IF NOT EXISTS idx_threads_closed
    ON message_threads (workspace_id, closed_at);


CREATE TABLE IF NOT EXISTS message_rate_limit_log (
    workspace_id        TEXT NOT NULL,
    sender_id           TEXT NOT NULL,
    is_broadcast        INTEGER NOT NULL DEFAULT 0,
    sent_at             TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_rate_limit_window
    ON message_rate_limit_log (workspace_id, sender_id, is_broadcast, sent_at DESC);

-- down

DROP INDEX IF EXISTS idx_rate_limit_window;
DROP TABLE IF EXISTS message_rate_limit_log;

DROP INDEX IF EXISTS idx_threads_closed;
DROP TABLE IF EXISTS message_threads;

DROP INDEX IF EXISTS idx_broadcast_reads_reader;
DROP TABLE IF EXISTS broadcast_reads;

DROP INDEX IF EXISTS idx_messages_broadcast;
DROP INDEX IF EXISTS idx_messages_thread;
DROP INDEX IF EXISTS idx_messages_sender_time;
DROP INDEX IF EXISTS idx_messages_recipient_status;
DROP TABLE IF EXISTS agent_messages;
