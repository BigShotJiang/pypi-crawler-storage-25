-- 0002_messaging.sql (postgres)
-- Multi-C: agent-to-agent messaging schema.
--
-- Mirrors the SQLite variant. PostgresWorkspaceBackend ships as a
-- skeleton in v1.2.0 (workspace methods raise NotImplementedError); the
-- migration ships in lockstep so the schema is deployable today and the
-- dialect-parity test stays green when the runtime lands in v1.3.0.
--
-- See migrations/workspace_sqlite/0002_messaging.sql for the full design
-- rationale (thread model, broadcast model, rate limiting, cross-agent
-- provenance event coupling).
--
-- Dialect-specific differences from the SQLite variant:
--   - INTEGER boolean columns → BOOLEAN
--   - TEXT JSON columns → JSONB with default '[]' / '{}'
--   - All other columns remain TEXT (including timestamps, in line
--     with the project-wide rule that backend reads return identical
--     Python types across dialects).

-- up

CREATE TABLE IF NOT EXISTS agent_messages (
    id                      TEXT PRIMARY KEY,
    workspace_id            TEXT NOT NULL,
    sender_id               TEXT NOT NULL,
    recipient_id            TEXT,
    broadcast_capability    TEXT,
    content                 TEXT NOT NULL,
    purpose                 TEXT NOT NULL,
    related_memory_ids      JSONB NOT NULL DEFAULT '[]'::jsonb,
    related_task_id         TEXT,
    thread_id               TEXT NOT NULL,
    in_reply_to             TEXT,
    expects_reply           BOOLEAN NOT NULL DEFAULT TRUE,
    reply_deadline          TEXT,
    status                  TEXT NOT NULL DEFAULT 'pending',
    read_at                 TEXT,
    replied_at              TEXT,
    reply_message_id        TEXT,
    created_at              TEXT NOT NULL,
    CHECK (
        (recipient_id IS NOT NULL AND broadcast_capability IS NULL)
        OR
        (recipient_id IS NULL AND broadcast_capability IS NOT NULL)
    )
);

CREATE INDEX IF NOT EXISTS idx_messages_recipient_status
    ON agent_messages (workspace_id, recipient_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_messages_sender_time
    ON agent_messages (workspace_id, sender_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_messages_thread
    ON agent_messages (workspace_id, thread_id, created_at);

CREATE INDEX IF NOT EXISTS idx_messages_broadcast
    ON agent_messages (workspace_id, broadcast_capability, created_at DESC);


CREATE TABLE IF NOT EXISTS broadcast_reads (
    message_id          TEXT NOT NULL,
    reader_agent_id     TEXT NOT NULL,
    read_at             TEXT NOT NULL,
    PRIMARY KEY (message_id, reader_agent_id)
);

CREATE INDEX IF NOT EXISTS idx_broadcast_reads_reader
    ON broadcast_reads (reader_agent_id, read_at DESC);


CREATE TABLE IF NOT EXISTS message_threads (
    workspace_id        TEXT NOT NULL,
    thread_id           TEXT NOT NULL,
    closed_at           TEXT,
    close_reason        TEXT,
    close_metadata      JSONB NOT NULL DEFAULT '{}'::jsonb,
    PRIMARY KEY (workspace_id, thread_id)
);

CREATE INDEX IF NOT EXISTS idx_threads_closed
    ON message_threads (workspace_id, closed_at);


CREATE TABLE IF NOT EXISTS message_rate_limit_log (
    workspace_id        TEXT NOT NULL,
    sender_id           TEXT NOT NULL,
    is_broadcast        BOOLEAN NOT NULL DEFAULT FALSE,
    sent_at             TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_rate_limit_window
    ON message_rate_limit_log (workspace_id, sender_id, is_broadcast, sent_at DESC);

-- down

DROP INDEX IF EXISTS idx_rate_limit_window;
DROP TABLE IF EXISTS message_rate_limit_log;

DROP INDEX IF EXISTS idx_threads_closed;
DROP TABLE IF EXISTS message_threads;

DROP INDEX IF EXISTS idx_broadcast_reads_reader;
DROP TABLE IF EXISTS broadcast_reads;

DROP INDEX IF EXISTS idx_messages_broadcast;
DROP INDEX IF EXISTS idx_messages_thread;
DROP INDEX IF EXISTS idx_messages_sender_time;
DROP INDEX IF EXISTS idx_messages_recipient_status;
DROP TABLE IF EXISTS agent_messages;
