-- 0001_workspace.sql (postgres)
-- Multi-agent workspace schema — initial cut for v1.2.0.
--
-- Mirrors the SQLite schema. PostgresBackend ships as a skeleton in
-- v1.2.0 (workspace methods on BaseWorkspaceBackend raise
-- NotImplementedError), but the migration is provided in lockstep so
-- the tables exist when a backend implementation lands and so the
-- dialect-parity test stays green.
--
-- See migrations/workspace_sqlite/0001_workspace.sql for the full
-- design rationale, isolation contract, and table-by-table commentary.
--
-- Dialect-specific differences from the SQLite variant:
--   - REAL → DOUBLE PRECISION
--   - TEXT JSON columns → JSONB with default '{}' / '[]'
--   - All other columns remain TEXT (including timestamps, in line
--     with the project-wide rule that backend reads return identical
--     Python types across dialects).

-- up

CREATE TABLE IF NOT EXISTS workspaces (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    license_jti     TEXT NOT NULL,
    config          JSONB NOT NULL DEFAULT '{}'::jsonb,
    feature_flags   JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TEXT NOT NULL,
    archived_at     TEXT
);

CREATE INDEX IF NOT EXISTS idx_workspaces_license
    ON workspaces (license_jti);

CREATE INDEX IF NOT EXISTS idx_workspaces_active
    ON workspaces (archived_at);


CREATE TABLE IF NOT EXISTS agent_directory (
    workspace_id        TEXT NOT NULL,
    agent_id            TEXT NOT NULL,
    capabilities        JSONB NOT NULL DEFAULT '[]'::jsonb,
    registered_at       TEXT NOT NULL,
    last_seen_at        TEXT,
    past_success_rate   DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    archived_at         TEXT,
    PRIMARY KEY (workspace_id, agent_id)
);

CREATE INDEX IF NOT EXISTS idx_agent_directory_workspace
    ON agent_directory (workspace_id, archived_at, last_seen_at);


CREATE TABLE IF NOT EXISTS shared_memory_pool (
    id                  TEXT PRIMARY KEY,
    workspace_id        TEXT NOT NULL,
    contributor_id      TEXT NOT NULL,
    source_memory_id    TEXT NOT NULL,
    visibility          TEXT NOT NULL DEFAULT 'TEAM',
    content             TEXT NOT NULL,
    reason              TEXT NOT NULL DEFAULT '',
    endorsement_count   INTEGER NOT NULL DEFAULT 0,
    contention_count    INTEGER NOT NULL DEFAULT 0,
    base_score          DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    shared_at           TEXT NOT NULL,
    archived_at         TEXT
);

CREATE INDEX IF NOT EXISTS idx_shared_pool_workspace_visibility
    ON shared_memory_pool (workspace_id, visibility, archived_at);

CREATE INDEX IF NOT EXISTS idx_shared_pool_contributor
    ON shared_memory_pool (workspace_id, contributor_id, shared_at DESC);

CREATE INDEX IF NOT EXISTS idx_shared_pool_source_memory
    ON shared_memory_pool (source_memory_id);

CREATE INDEX IF NOT EXISTS idx_shared_pool_workspace_score
    ON shared_memory_pool (workspace_id, base_score DESC);


CREATE TABLE IF NOT EXISTS shared_memory_endorsements (
    shared_memory_id    TEXT NOT NULL,
    endorsing_agent_id  TEXT NOT NULL,
    endorsed_at         TEXT NOT NULL,
    PRIMARY KEY (shared_memory_id, endorsing_agent_id)
);

CREATE INDEX IF NOT EXISTS idx_endorsements_agent
    ON shared_memory_endorsements (endorsing_agent_id, endorsed_at DESC);


CREATE TABLE IF NOT EXISTS shared_memory_contentions (
    shared_memory_id    TEXT NOT NULL,
    contesting_agent_id TEXT NOT NULL,
    reason              TEXT NOT NULL DEFAULT '',
    contested_at        TEXT NOT NULL,
    PRIMARY KEY (shared_memory_id, contesting_agent_id)
);

CREATE INDEX IF NOT EXISTS idx_contentions_agent
    ON shared_memory_contentions (contesting_agent_id, contested_at DESC);


CREATE TABLE IF NOT EXISTS team_insights (
    id                      TEXT PRIMARY KEY,
    workspace_id            TEXT NOT NULL,
    content                 TEXT NOT NULL,
    synthesis_prompt_hash   TEXT NOT NULL,
    contributor_count       INTEGER NOT NULL DEFAULT 0,
    dream_cycle_id          TEXT,
    created_at              TEXT NOT NULL,
    archived_at             TEXT
);

CREATE INDEX IF NOT EXISTS idx_team_insights_workspace
    ON team_insights (workspace_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_team_insights_dream_cycle
    ON team_insights (dream_cycle_id);


CREATE TABLE IF NOT EXISTS team_insight_contributions (
    team_insight_id         TEXT NOT NULL,
    shared_memory_id        TEXT NOT NULL,
    contributor_agent_id    TEXT NOT NULL,
    contribution_weight     DOUBLE PRECISION NOT NULL DEFAULT 1.0,
    PRIMARY KEY (team_insight_id, shared_memory_id)
);

CREATE INDEX IF NOT EXISTS idx_team_insight_contrib_agent
    ON team_insight_contributions (contributor_agent_id);

CREATE INDEX IF NOT EXISTS idx_team_insight_contrib_shared_memory
    ON team_insight_contributions (shared_memory_id);


CREATE TABLE IF NOT EXISTS cross_agent_provenance_events (
    event_id            TEXT PRIMARY KEY,
    workspace_id        TEXT NOT NULL,
    event_type          TEXT NOT NULL,
    actor_agent_id      TEXT,
    target_agent_id     TEXT,
    entity_type         TEXT NOT NULL,
    entity_id           TEXT NOT NULL,
    parent_event_id     TEXT,
    payload             JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at          TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_xagent_prov_entity
    ON cross_agent_provenance_events (workspace_id, entity_id, created_at);

CREATE INDEX IF NOT EXISTS idx_xagent_prov_time
    ON cross_agent_provenance_events (workspace_id, created_at);

CREATE INDEX IF NOT EXISTS idx_xagent_prov_actor
    ON cross_agent_provenance_events (workspace_id, actor_agent_id, created_at);

CREATE INDEX IF NOT EXISTS idx_xagent_prov_parent
    ON cross_agent_provenance_events (parent_event_id);

-- down

DROP INDEX IF EXISTS idx_xagent_prov_parent;
DROP INDEX IF EXISTS idx_xagent_prov_actor;
DROP INDEX IF EXISTS idx_xagent_prov_time;
DROP INDEX IF EXISTS idx_xagent_prov_entity;
DROP TABLE IF EXISTS cross_agent_provenance_events;

DROP INDEX IF EXISTS idx_team_insight_contrib_shared_memory;
DROP INDEX IF EXISTS idx_team_insight_contrib_agent;
DROP TABLE IF EXISTS team_insight_contributions;

DROP INDEX IF EXISTS idx_team_insights_dream_cycle;
DROP INDEX IF EXISTS idx_team_insights_workspace;
DROP TABLE IF EXISTS team_insights;

DROP INDEX IF EXISTS idx_contentions_agent;
DROP TABLE IF EXISTS shared_memory_contentions;

DROP INDEX IF EXISTS idx_endorsements_agent;
DROP TABLE IF EXISTS shared_memory_endorsements;

DROP INDEX IF EXISTS idx_shared_pool_workspace_score;
DROP INDEX IF EXISTS idx_shared_pool_source_memory;
DROP INDEX IF EXISTS idx_shared_pool_contributor;
DROP INDEX IF EXISTS idx_shared_pool_workspace_visibility;
DROP TABLE IF EXISTS shared_memory_pool;

DROP INDEX IF EXISTS idx_agent_directory_workspace;
DROP TABLE IF EXISTS agent_directory;

DROP INDEX IF EXISTS idx_workspaces_active;
DROP INDEX IF EXISTS idx_workspaces_license;
DROP TABLE IF EXISTS workspaces;
