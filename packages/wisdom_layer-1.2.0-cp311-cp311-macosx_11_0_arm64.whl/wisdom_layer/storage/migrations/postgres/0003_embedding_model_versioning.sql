-- 0003_embedding_model_versioning.sql (postgres)
-- Postgres dialect of the embedding model/dim versioning migration.
-- Schema-equivalent to migrations/sqlite/0003_embedding_model_versioning.sql.

-- up

ALTER TABLE memories ADD COLUMN IF NOT EXISTS embedding_model_id TEXT NOT NULL DEFAULT 'all-MiniLM-L6-v2';
ALTER TABLE memories ADD COLUMN IF NOT EXISTS embedding_dim INTEGER NOT NULL DEFAULT 384;

CREATE INDEX IF NOT EXISTS idx_memories_agent_embedding_model
    ON memories(agent_id, embedding_model_id, embedding_dim);

-- down

DROP INDEX IF EXISTS idx_memories_agent_embedding_model;
ALTER TABLE memories DROP COLUMN IF EXISTS embedding_dim;
ALTER TABLE memories DROP COLUMN IF EXISTS embedding_model_id;
