-- 0001_initial.sql (postgres)
-- Postgres dialect of the Wisdom Layer SDK baseline schema.
-- Schema-equivalent to migrations/sqlite/0001_initial.sql: same tables,
-- same column set, same index coverage, same constraints. Dialect
-- differences are intentional:
--
--   SQLite                           Postgres
--   ------                           --------
--   TEXT metadata '{}'               JSONB metadata '{}'::jsonb
--   TEXT source_ids '[]'             JSONB source_ids '[]'::jsonb
--   TEXT phases_completed '[]'       JSONB phases_completed '[]'::jsonb
--   REAL                             DOUBLE PRECISION
--   BLOB embedding                   VECTOR(384) embedding  (pgvector)
--
-- Timestamp columns (created_at/updated_at/accessed_at/started_at/...)
-- are kept as TEXT on both dialects so row reads return identical Python
-- types across backends. The backend layer owns any ISO8601 parsing.
--
-- All statements use IF NOT EXISTS so a partial apply followed by a retry
-- is safe. Do NOT add INSERT statements here — seed data belongs in a
-- dedicated seed migration that uses ON CONFLICT DO NOTHING.

-- up

CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    tier TEXT NOT NULL DEFAULT 'raw',
    event_type TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    salience DOUBLE PRECISION NOT NULL DEFAULT 0.5,
    reinforcement_count INTEGER NOT NULL DEFAULT 0,
    emotional_intensity DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    embedding VECTOR(384),
    source_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    accessed_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memories_tier ON memories(tier);
CREATE INDEX IF NOT EXISTS idx_memories_salience ON memories(salience);
CREATE INDEX IF NOT EXISTS idx_memories_created_at ON memories(created_at);

CREATE TABLE IF NOT EXISTS directives (
    id TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    priority TEXT NOT NULL DEFAULT 'contextual',
    usage_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    last_used TEXT
);

CREATE TABLE IF NOT EXISTS directive_proposals (
    id TEXT PRIMARY KEY,
    action TEXT NOT NULL,
    text TEXT NOT NULL,
    reasoning TEXT NOT NULL DEFAULT '',
    confidence DOUBLE PRECISION NOT NULL DEFAULT 0.5,
    status TEXT NOT NULL DEFAULT 'pending',
    source_memory_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TEXT NOT NULL,
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS dream_reports (
    id TEXT PRIMARY KEY,
    started_at TEXT NOT NULL,
    completed_at TEXT NOT NULL,
    phases_completed JSONB NOT NULL DEFAULT '[]'::jsonb,
    reconsolidated INTEGER NOT NULL DEFAULT 0,
    new_insights INTEGER NOT NULL DEFAULT 0,
    decayed INTEGER NOT NULL DEFAULT 0,
    directives_proposed INTEGER NOT NULL DEFAULT 0,
    journal_entry_id TEXT
);

-- down

DROP TABLE IF EXISTS dream_reports;
DROP TABLE IF EXISTS directive_proposals;
DROP TABLE IF EXISTS directives;
DROP INDEX IF EXISTS idx_memories_created_at;
DROP INDEX IF EXISTS idx_memories_salience;
DROP INDEX IF EXISTS idx_memories_tier;
DROP TABLE IF EXISTS memories;
