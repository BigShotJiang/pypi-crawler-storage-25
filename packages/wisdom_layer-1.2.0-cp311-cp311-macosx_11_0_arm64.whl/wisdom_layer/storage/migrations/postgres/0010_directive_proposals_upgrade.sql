-- 0010_directive_proposals_upgrade.sql (postgres)
-- Postgres dialect of the advisory-mode proposal columns.
-- Schema-equivalent to migrations/sqlite/0010_directive_proposals_upgrade.sql.
-- "resolved_by" is promoted to JSONB on Postgres (structured audit envelope
-- like {"actor":"operator","method":"manual"}) — consistent with how every
-- other JSON-bearing column maps to JSONB in the Postgres dialect.

-- up

ALTER TABLE directive_proposals ADD COLUMN IF NOT EXISTS proposed_status TEXT NOT NULL DEFAULT '';
ALTER TABLE directive_proposals ADD COLUMN IF NOT EXISTS target_directive_id TEXT DEFAULT NULL;
ALTER TABLE directive_proposals ADD COLUMN IF NOT EXISTS content_hash TEXT NOT NULL DEFAULT '';
ALTER TABLE directive_proposals ADD COLUMN IF NOT EXISTS resolved_by JSONB DEFAULT NULL;

-- down

ALTER TABLE directive_proposals DROP COLUMN IF EXISTS resolved_by;
ALTER TABLE directive_proposals DROP COLUMN IF EXISTS content_hash;
ALTER TABLE directive_proposals DROP COLUMN IF EXISTS target_directive_id;
ALTER TABLE directive_proposals DROP COLUMN IF EXISTS proposed_status;
