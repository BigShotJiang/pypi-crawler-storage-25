-- 0024_facts_source_ids.sql (postgres)
-- Per-fact provenance graph — schema half. Mirrors the SQLite
-- variant; full design rationale and migration story live in
-- migrations/sqlite/0024_facts_source_ids.sql.
--
-- Dialect-specific differences:
--   - JSON array column is JSONB (vs TEXT on SQLite)
--   - Backfill uses jsonb_build_array() (vs json_array())
--   - DROP COLUMN is supported natively, so the down path is clean
--
-- Pro tip for operators on Postgres: this ALTER TABLE rewrites the
-- table in older Postgres versions. On Postgres ≥ 11 the new column
-- with default is metadata-only and instantly cheap. The
-- `wisdom-layer-migrate` CLI's pre-flight check warns if the target
-- server is older than 11.

-- up

ALTER TABLE facts
    ADD COLUMN IF NOT EXISTS source_memory_ids JSONB NOT NULL DEFAULT '[]'::jsonb;

UPDATE facts
   SET source_memory_ids = jsonb_build_array(source_memory_id)
 WHERE source_memory_id IS NOT NULL
   AND source_memory_ids = '[]'::jsonb;

-- down

ALTER TABLE facts
    DROP COLUMN IF EXISTS source_memory_ids;
