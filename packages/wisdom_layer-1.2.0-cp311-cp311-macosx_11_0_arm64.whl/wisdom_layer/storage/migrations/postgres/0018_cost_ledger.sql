-- 0018_cost_ledger.sql (postgres)
-- Postgres dialect of the cost ledger extension.
-- Schema-equivalent to migrations/sqlite/0018_cost_ledger.sql.

-- up

ALTER TABLE cost_records ADD COLUMN IF NOT EXISTS event_id TEXT;
ALTER TABLE cost_records ADD COLUMN IF NOT EXISTS category TEXT NOT NULL DEFAULT '';

CREATE INDEX IF NOT EXISTS idx_cost_records_agent_category_created
    ON cost_records (agent_id, category, created_at);

CREATE INDEX IF NOT EXISTS idx_cost_records_agent_event
    ON cost_records (agent_id, event_id);

-- down

DROP INDEX IF EXISTS idx_cost_records_agent_event;
DROP INDEX IF EXISTS idx_cost_records_agent_category_created;
ALTER TABLE cost_records DROP COLUMN IF EXISTS category;
ALTER TABLE cost_records DROP COLUMN IF EXISTS event_id;
