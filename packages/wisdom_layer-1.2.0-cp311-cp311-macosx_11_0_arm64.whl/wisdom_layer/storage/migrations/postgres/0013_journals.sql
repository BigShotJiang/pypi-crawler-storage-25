-- 0013_journals.sql (postgres)
-- Postgres dialect of the journals table + journaled flag.
-- Schema-equivalent to migrations/sqlite/0013_journals.sql.

-- up

CREATE TABLE IF NOT EXISTS journals (
    id              TEXT PRIMARY KEY,
    agent_id        TEXT NOT NULL,
    content         TEXT NOT NULL,
    memory_ids_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at      TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_journals_agent
    ON journals(agent_id, created_at DESC);

ALTER TABLE memories ADD COLUMN IF NOT EXISTS journaled INTEGER NOT NULL DEFAULT 0;

-- down

ALTER TABLE memories DROP COLUMN IF EXISTS journaled;
DROP INDEX IF EXISTS idx_journals_agent;
DROP TABLE IF EXISTS journals;
