-- 0012_critic_audits.sql (postgres)
-- Postgres dialect of the critic_audits table.
-- Schema-equivalent to migrations/sqlite/0012_critic_audits.sql.

-- up

CREATE TABLE IF NOT EXISTS critic_audits (
    id                  TEXT PRIMARY KEY,
    agent_id            TEXT NOT NULL,
    coherence_score     DOUBLE PRECISION NOT NULL,
    is_coherent         INTEGER NOT NULL DEFAULT 1,
    contradictions_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    summary             TEXT NOT NULL,
    directive_ids_json  JSONB NOT NULL DEFAULT '[]'::jsonb,
    directive_count     INTEGER NOT NULL DEFAULT 0,
    created_at          TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_critic_audits_agent
    ON critic_audits(agent_id, created_at DESC);

-- down

DROP INDEX IF EXISTS idx_critic_audits_agent;
DROP TABLE IF EXISTS critic_audits;
