-- 0016_provenance_events.sql (postgres)
-- Postgres dialect of the append-only provenance event log.
-- Schema-equivalent to migrations/sqlite/0016_provenance_events.sql.
-- Append-only invariant is enforced by the absence of a mutation write
-- path on the backend, identical to the SQLite dialect.

-- up

CREATE TABLE IF NOT EXISTS provenance_events (
    event_id        TEXT PRIMARY KEY,
    agent_id        TEXT NOT NULL,
    event_type      TEXT NOT NULL,
    entity_type     TEXT NOT NULL,
    entity_id       TEXT NOT NULL,
    parent_event_id TEXT,
    payload         JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at      TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_prov_entity
    ON provenance_events(agent_id, entity_id, created_at);

CREATE INDEX IF NOT EXISTS idx_prov_time
    ON provenance_events(agent_id, created_at);

CREATE INDEX IF NOT EXISTS idx_prov_parent
    ON provenance_events(parent_event_id);

-- down

DROP INDEX IF EXISTS idx_prov_parent;
DROP INDEX IF EXISTS idx_prov_time;
DROP INDEX IF EXISTS idx_prov_entity;
DROP TABLE IF EXISTS provenance_events;
