-- 0007_cycle_id.sql (postgres)
-- Postgres dialect of the consolidation cycle_id tag.
-- Schema-equivalent to migrations/sqlite/0007_cycle_id.sql.

-- up

ALTER TABLE memories ADD COLUMN IF NOT EXISTS cycle_id TEXT;

-- down

ALTER TABLE memories DROP COLUMN IF EXISTS cycle_id;
