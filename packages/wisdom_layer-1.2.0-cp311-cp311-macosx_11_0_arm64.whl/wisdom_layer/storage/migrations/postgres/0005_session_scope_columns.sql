-- 0005_session_scope_columns.sql (postgres)
-- Postgres dialect of the session scoping migration.
-- Schema-equivalent to migrations/sqlite/0005_session_scope_columns.sql.

-- up

ALTER TABLE memories ADD COLUMN IF NOT EXISTS session_id TEXT;
ALTER TABLE memories ADD COLUMN IF NOT EXISTS scope TEXT NOT NULL DEFAULT 'long_term';
ALTER TABLE memories ADD COLUMN IF NOT EXISTS ttl_hours INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_memories_agent_session_scope
    ON memories (agent_id, session_id, scope);

-- down

ALTER TABLE memories DROP COLUMN IF EXISTS session_id;
ALTER TABLE memories DROP COLUMN IF EXISTS scope;
ALTER TABLE memories DROP COLUMN IF EXISTS ttl_hours;
