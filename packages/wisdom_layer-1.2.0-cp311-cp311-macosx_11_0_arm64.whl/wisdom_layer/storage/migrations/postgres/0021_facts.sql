-- 0021_facts.sql (postgres)
-- Atomic facts table — Beta in v1.0.
--
-- Mirrors the SQLite schema. PostgresBackend ships as a skeleton in
-- v1.0 (the fact methods on BaseBackend raise NotImplementedError),
-- but the migration is provided in lockstep so the table exists when
-- a backend implementation lands and so the dialect-parity test
-- (test_storage_postgres_skeleton) stays green.
--
-- v1.0 behavior: last-write-wins on (agent_id, subject, attribute).
-- Older rows are retained for history. Reconciliation, decay
-- enforcement, and history queries are deferred to v1.0.1 — see
-- docs/releases/V1_0_1_RELEASE.md "Fact Extraction — Beta-to-GA
-- Hardening".

-- up

CREATE TABLE IF NOT EXISTS facts (
    id               TEXT PRIMARY KEY,
    agent_id         TEXT NOT NULL,
    subject          TEXT NOT NULL,
    attribute        TEXT NOT NULL,
    value            TEXT NOT NULL,
    source_memory_id TEXT,
    confidence       DOUBLE PRECISION NOT NULL DEFAULT 0.7,
    decay_rate       DOUBLE PRECISION NOT NULL DEFAULT 0.95,
    created_at       TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_facts_agent_subject
    ON facts (agent_id, subject);

CREATE INDEX IF NOT EXISTS idx_facts_agent_subject_attribute
    ON facts (agent_id, subject, attribute);

CREATE INDEX IF NOT EXISTS idx_facts_source_memory
    ON facts (source_memory_id);

CREATE INDEX IF NOT EXISTS idx_facts_agent_created
    ON facts (agent_id, created_at DESC);

-- down

DROP TABLE IF EXISTS facts;
