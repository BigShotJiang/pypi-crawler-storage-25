-- 0014_dream_reports_upgrade.sql (postgres)
-- Postgres dialect of the dream_reports trigger() shape upgrade.
-- Schema-equivalent to migrations/sqlite/0014_dream_reports_upgrade.sql.

-- up

ALTER TABLE dream_reports ADD COLUMN IF NOT EXISTS cycle_id TEXT;
ALTER TABLE dream_reports ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'success';
ALTER TABLE dream_reports ADD COLUMN IF NOT EXISTS steps JSONB NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE dream_reports ADD COLUMN IF NOT EXISTS duration_ms INTEGER NOT NULL DEFAULT 0;

CREATE UNIQUE INDEX IF NOT EXISTS idx_dream_reports_cycle_id
    ON dream_reports(cycle_id);

CREATE INDEX IF NOT EXISTS idx_dream_reports_agent_cycle
    ON dream_reports(agent_id, cycle_id);

-- down

DROP INDEX IF EXISTS idx_dream_reports_agent_cycle;
DROP INDEX IF EXISTS idx_dream_reports_cycle_id;
ALTER TABLE dream_reports DROP COLUMN IF EXISTS duration_ms;
ALTER TABLE dream_reports DROP COLUMN IF EXISTS steps;
ALTER TABLE dream_reports DROP COLUMN IF EXISTS status;
ALTER TABLE dream_reports DROP COLUMN IF EXISTS cycle_id;
