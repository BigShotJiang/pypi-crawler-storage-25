-- 0020_dream_checkpoints.sql (postgres)
-- Dream cycle checkpointing for graceful shutdown / resume.

-- up

CREATE TABLE IF NOT EXISTS dream_cycle_checkpoints (
    cycle_id            TEXT PRIMARY KEY,
    agent_id            TEXT NOT NULL,
    last_completed_phase TEXT NOT NULL,
    state_blob          TEXT NOT NULL,
    created_at          TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_dream_checkpoints_agent
    ON dream_cycle_checkpoints (agent_id);

-- down

DROP TABLE IF EXISTS dream_cycle_checkpoints;
