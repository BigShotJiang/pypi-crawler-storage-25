-- 0017_health_snapshots.sql (postgres)
-- Postgres dialect of the daily health_snapshots table.
-- Schema-equivalent to migrations/sqlite/0017_health_snapshots.sql.

-- up

CREATE TABLE IF NOT EXISTS health_snapshots (
    agent_id      TEXT NOT NULL,
    snapshot_date TEXT NOT NULL,
    payload       JSONB NOT NULL,
    created_at    TEXT NOT NULL,
    PRIMARY KEY (agent_id, snapshot_date)
);

CREATE INDEX IF NOT EXISTS idx_health_snapshots_agent_date
    ON health_snapshots (agent_id, snapshot_date DESC);

-- down

DROP INDEX IF EXISTS idx_health_snapshots_agent_date;
DROP TABLE IF EXISTS health_snapshots;
