-- 0009_directive_state_machine.sql (postgres)
-- Postgres dialect of the directive state machine columns.
-- Schema-equivalent to migrations/sqlite/0009_directive_state_machine.sql.
-- BLOB embedding → VECTOR(384) (pgvector).

-- up

ALTER TABLE directives ADD COLUMN IF NOT EXISTS content_hash TEXT NOT NULL DEFAULT '';
ALTER TABLE directives ADD COLUMN IF NOT EXISTS embedding VECTOR(384);
ALTER TABLE directives ADD COLUMN IF NOT EXISTS embedding_model_id TEXT NOT NULL DEFAULT '';
ALTER TABLE directives ADD COLUMN IF NOT EXISTS embedding_dim INTEGER NOT NULL DEFAULT 0;
ALTER TABLE directives ADD COLUMN IF NOT EXISTS promoted_at TEXT;
ALTER TABLE directives ADD COLUMN IF NOT EXISTS updated_at TEXT;

CREATE INDEX IF NOT EXISTS idx_directives_agent_content_hash
    ON directives(agent_id, content_hash);

-- down

DROP INDEX IF EXISTS idx_directives_agent_content_hash;
ALTER TABLE directives DROP COLUMN IF EXISTS updated_at;
ALTER TABLE directives DROP COLUMN IF EXISTS promoted_at;
ALTER TABLE directives DROP COLUMN IF EXISTS embedding_dim;
ALTER TABLE directives DROP COLUMN IF EXISTS embedding_model_id;
ALTER TABLE directives DROP COLUMN IF EXISTS embedding;
ALTER TABLE directives DROP COLUMN IF EXISTS content_hash;
