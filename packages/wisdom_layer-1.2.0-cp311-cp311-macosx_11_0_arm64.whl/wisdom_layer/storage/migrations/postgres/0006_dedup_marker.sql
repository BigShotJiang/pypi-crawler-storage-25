-- 0006_dedup_marker.sql (postgres)
-- Postgres dialect of the dedup_of marker column.
-- Schema-equivalent to migrations/sqlite/0006_dedup_marker.sql.

-- up

ALTER TABLE memories ADD COLUMN IF NOT EXISTS dedup_of TEXT;

-- down

ALTER TABLE memories DROP COLUMN IF EXISTS dedup_of;
