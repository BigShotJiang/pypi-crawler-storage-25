-- 0022_facts_embedding.sql (postgres)
-- Mirrors the SQLite migration. PostgresBackend ships as a skeleton in
-- v1.0 (the fact methods on BaseBackend raise NotImplementedError), but
-- the schema lands in lockstep so a future backend implementation does
-- not need to invent embedding storage from scratch.

-- up

ALTER TABLE facts ADD COLUMN IF NOT EXISTS embedding BYTEA;
ALTER TABLE facts ADD COLUMN IF NOT EXISTS embedding_model_id TEXT;
ALTER TABLE facts ADD COLUMN IF NOT EXISTS embedding_dim INTEGER;

CREATE INDEX IF NOT EXISTS idx_facts_agent_embed_model
    ON facts (agent_id, embedding_model_id, embedding_dim);

-- down

DROP INDEX IF EXISTS idx_facts_agent_embed_model;
ALTER TABLE facts DROP COLUMN IF EXISTS embedding_dim;
ALTER TABLE facts DROP COLUMN IF EXISTS embedding_model_id;
ALTER TABLE facts DROP COLUMN IF EXISTS embedding;
