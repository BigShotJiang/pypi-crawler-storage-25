-- 0011_critic_reviews.sql (postgres)
-- Postgres dialect of the critic_reviews table.
-- Schema-equivalent to migrations/sqlite/0011_critic_reviews.sql.
-- Column name suffixes (_json) are preserved for cross-backend parity;
-- the storage type is JSONB on Postgres.

-- up

CREATE TABLE IF NOT EXISTS critic_reviews (
    id                 TEXT PRIMARY KEY,
    agent_id           TEXT NOT NULL,
    output_text        TEXT NOT NULL,
    context_json       JSONB,
    risk_level         TEXT NOT NULL,
    flags_json         JSONB NOT NULL DEFAULT '[]'::jsonb,
    rationale          TEXT NOT NULL,
    pass_through       INTEGER NOT NULL DEFAULT 1,
    directive_ids_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at         TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_critic_reviews_agent
    ON critic_reviews(agent_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_critic_reviews_risk
    ON critic_reviews(agent_id, risk_level);

-- down

DROP INDEX IF EXISTS idx_critic_reviews_risk;
DROP INDEX IF EXISTS idx_critic_reviews_agent;
DROP TABLE IF EXISTS critic_reviews;
