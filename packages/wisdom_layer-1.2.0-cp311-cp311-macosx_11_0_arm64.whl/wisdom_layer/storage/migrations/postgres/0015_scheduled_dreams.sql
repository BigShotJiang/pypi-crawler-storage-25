-- 0015_scheduled_dreams.sql (postgres)
-- Postgres dialect of the scheduled_dreams singleton table.
-- Schema-equivalent to migrations/sqlite/0015_scheduled_dreams.sql.

-- up

CREATE TABLE IF NOT EXISTS scheduled_dreams (
    agent_id        TEXT PRIMARY KEY,
    interval_hours  DOUBLE PRECISION NOT NULL,
    at_time         TEXT,
    paused          INTEGER NOT NULL DEFAULT 0,
    ignore_budget   INTEGER NOT NULL DEFAULT 0,
    next_run        TEXT NOT NULL,
    last_run        TEXT,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_scheduled_dreams_next_run
    ON scheduled_dreams(next_run);

-- down

DROP INDEX IF EXISTS idx_scheduled_dreams_next_run;
DROP TABLE IF EXISTS scheduled_dreams;
