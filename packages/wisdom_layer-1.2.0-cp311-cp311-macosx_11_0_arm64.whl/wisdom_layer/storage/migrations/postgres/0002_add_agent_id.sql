-- 0002_add_agent_id.sql (postgres)
-- Postgres dialect of the agent_id multi-tenancy migration.
-- Schema-equivalent to migrations/sqlite/0002_add_agent_id.sql.
--
-- Dialect note: Postgres supports ADD COLUMN IF NOT EXISTS (9.6+) so every
-- ALTER statement is independently idempotent in addition to the runner's
-- per-migration transaction. The runner still wraps the whole migration in
-- BEGIN/COMMIT, so a crash mid-file rolls every DDL statement back.

-- up

ALTER TABLE memories ADD COLUMN IF NOT EXISTS agent_id TEXT NOT NULL DEFAULT 'default';
ALTER TABLE directives ADD COLUMN IF NOT EXISTS agent_id TEXT NOT NULL DEFAULT 'default';
ALTER TABLE directive_proposals ADD COLUMN IF NOT EXISTS agent_id TEXT NOT NULL DEFAULT 'default';
ALTER TABLE dream_reports ADD COLUMN IF NOT EXISTS agent_id TEXT NOT NULL DEFAULT 'default';

CREATE INDEX IF NOT EXISTS idx_memories_agent_tier
    ON memories(agent_id, tier);
CREATE INDEX IF NOT EXISTS idx_memories_agent_salience
    ON memories(agent_id, salience);
CREATE INDEX IF NOT EXISTS idx_memories_agent_created
    ON memories(agent_id, created_at);
CREATE INDEX IF NOT EXISTS idx_directives_agent_status
    ON directives(agent_id, status);
CREATE INDEX IF NOT EXISTS idx_directive_proposals_agent_status
    ON directive_proposals(agent_id, status);
CREATE INDEX IF NOT EXISTS idx_dream_reports_agent_completed
    ON dream_reports(agent_id, completed_at);

-- down

DROP INDEX IF EXISTS idx_dream_reports_agent_completed;
DROP INDEX IF EXISTS idx_directive_proposals_agent_status;
DROP INDEX IF EXISTS idx_directives_agent_status;
DROP INDEX IF EXISTS idx_memories_agent_created;
DROP INDEX IF EXISTS idx_memories_agent_salience;
DROP INDEX IF EXISTS idx_memories_agent_tier;
ALTER TABLE dream_reports DROP COLUMN IF EXISTS agent_id;
ALTER TABLE directive_proposals DROP COLUMN IF EXISTS agent_id;
ALTER TABLE directives DROP COLUMN IF EXISTS agent_id;
ALTER TABLE memories DROP COLUMN IF EXISTS agent_id;
