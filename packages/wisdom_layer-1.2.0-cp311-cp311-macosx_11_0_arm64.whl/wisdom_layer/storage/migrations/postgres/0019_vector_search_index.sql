-- 0019_vector_search_index.sql (postgres)
-- v0.6 Phase 1 Slice C: Approximate-nearest-neighbour index on the
-- memories embedding column using pgvector's ``ivfflat`` access method.
--
-- Distance operator: we standardize on cosine distance (``<=>``) across
-- both dialects; the index is built with ``vector_cosine_ops`` so the
-- planner can use the index when the query ORDER BY clause also uses
-- ``<=>``. Using a different operator class would silently force a
-- sequential scan.
--
-- ``lists`` parameter: fixed at 100 in this migration — matches
-- :attr:`AdminDefaults.postgres_ivf_lists`. 100 is pgvector's canonical
-- small-corpus default and holds stable recall up to ~100k rows. The
-- field is tunable in :class:`AdminDefaults` so Enterprise customers
-- at larger scale can rebuild the index via an ops runbook; changing
-- it here would require a new numbered migration.
--
-- Below-threshold guard: the index is created regardless of row count,
-- but :attr:`AdminDefaults.postgres_ivf_threshold_rows` tells the
-- backend to skip the ivfflat hint at query time when the corpus is
-- too small for ANN to beat sequential scan.
--
-- Idempotency: ``CREATE INDEX IF NOT EXISTS`` is idempotent even for
-- ``USING ivfflat``, so crash-retry and re-boot are safe.
--
-- SQLite parity: ``migrations/sqlite/0019_vector_search_index.sql`` is
-- a documented no-op — SQLite has no vector index type and performs
-- full-corpus cosine in Python. Version parity is preserved so both
-- dialects report the same ``current_version``.

-- up

CREATE INDEX IF NOT EXISTS idx_memories_embedding_ivfflat
    ON memories USING ivfflat (embedding vector_cosine_ops)
    WITH (lists = 100);

-- down

DROP INDEX IF EXISTS idx_memories_embedding_ivfflat;
