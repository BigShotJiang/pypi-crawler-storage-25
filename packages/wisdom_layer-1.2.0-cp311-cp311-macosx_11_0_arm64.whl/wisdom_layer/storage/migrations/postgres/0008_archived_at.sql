-- 0008_archived_at.sql (postgres)
-- Postgres dialect of the archived_at decay marker.
-- Schema-equivalent to migrations/sqlite/0008_archived_at.sql.

-- up

ALTER TABLE memories ADD COLUMN IF NOT EXISTS archived_at TEXT DEFAULT NULL;

CREATE INDEX IF NOT EXISTS idx_memories_archived_at
    ON memories (agent_id, archived_at);

-- down

DROP INDEX IF EXISTS idx_memories_archived_at;
ALTER TABLE memories DROP COLUMN IF EXISTS archived_at;
