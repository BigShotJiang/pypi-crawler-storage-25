-- 0003_embedding_model_versioning.sql
-- Embedding model + dimension columns on memories so the SDK can switch
-- embedding adapters without silently producing dim-mismatched cosine
-- comparisons. Vector search will filter by (agent_id, embedding_model_id,
-- embedding_dim); rows under stale models remain reachable via the lexical
-- fallback path until Phase A's reembed migration job rewrites them.
--
-- Doc reference: 06_extraction_plan.md §0.4;
-- 01_memory_architecture.md §"Memory Schema";
-- 11_integration_ergonomics_resolutions.md §2 ("Embedding model versioning").
-- Canonical sequence entry: 0003.
--
-- Backfill defaults match the historical free-tier baseline: every existing
-- row was embedded with all-MiniLM-L6-v2 at 384 dimensions. New rows written
-- after this migration carry whatever the active SQLiteBackend was
-- constructed with.
--
-- SQLite note: ALTER TABLE ADD COLUMN does not support IF NOT EXISTS, but
-- MigrationRunner wraps each migration in a single BEGIN/COMMIT transaction
-- that also writes the schema_migrations bookkeeping row, so a crash mid-
-- migration rolls every DDL statement back and the retry starts from a
-- clean state. The composite index is guarded with IF NOT EXISTS so re-
-- running the *statement* in isolation (outside the runner) is still safe.

-- up

ALTER TABLE memories ADD COLUMN embedding_model_id TEXT NOT NULL DEFAULT 'all-MiniLM-L6-v2';
ALTER TABLE memories ADD COLUMN embedding_dim INTEGER NOT NULL DEFAULT 384;

CREATE INDEX IF NOT EXISTS idx_memories_agent_embedding_model
    ON memories(agent_id, embedding_model_id, embedding_dim);

-- down

DROP INDEX IF EXISTS idx_memories_agent_embedding_model;
-- Note: SQLite ALTER TABLE DROP COLUMN was added in 3.35.0 (2021-03-12).
-- The runner never executes this block; customers recover from backup.
ALTER TABLE memories DROP COLUMN embedding_dim;
ALTER TABLE memories DROP COLUMN embedding_model_id;
