-- v0.5 Phase 2 — Provenance event log.
-- Append-only audit log of every lifecycle mutation that the user can
-- later reconstruct via `agent.provenance.trace()` or have narrated via
-- `agent.provenance.explain()`. The data in this table is the evidence
-- behind the patent's "auditable learning" claim.
--
-- Append-only by contract: rows are written by the agent's emit path
-- and never modified or removed by application code. The backend
-- exposes no mutation method for this table, so the invariant is
-- enforced by the absence of a write path rather than by SQLite
-- triggers (the current migration splitter does not parse BEGIN/END
-- trigger bodies). A cryptographic tamper-evident hash chain lands
-- in v0.9 as part of the compliance audit log.
--
-- Columns:
--   event_id        — ULID-style string (12-char like memory_id); PK
--   agent_id        — owner; multi-tenant isolation boundary
--   event_type      — dotted name (e.g. `memory.captured`, `dream.cycle.started`)
--   entity_type     — one of: memory | insight | directive | journal |
--                     critic_pass | dream_cycle | agent
--   entity_id       — id of the entity this event touches
--   parent_event_id — link to the event that caused this one, NULL for roots
--   payload         — JSON blob with event-specific fields; always a dict
--   created_at      — ISO 8601 UTC timestamp of the emit
--
-- Indexes:
--   idx_prov_entity — (agent_id, entity_id, created_at) for trace walks
--   idx_prov_time   — (agent_id, created_at) for time-range scans
--   idx_prov_parent — (parent_event_id) for child lookups during trace

-- up

CREATE TABLE IF NOT EXISTS provenance_events (
    event_id TEXT PRIMARY KEY,
    agent_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    parent_event_id TEXT,
    payload TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_prov_entity
    ON provenance_events(agent_id, entity_id, created_at);

CREATE INDEX IF NOT EXISTS idx_prov_time
    ON provenance_events(agent_id, created_at);

CREATE INDEX IF NOT EXISTS idx_prov_parent
    ON provenance_events(parent_event_id);

-- down

DROP INDEX IF EXISTS idx_prov_parent;
DROP INDEX IF EXISTS idx_prov_time;
DROP INDEX IF EXISTS idx_prov_entity;
DROP TABLE IF EXISTS provenance_events;
