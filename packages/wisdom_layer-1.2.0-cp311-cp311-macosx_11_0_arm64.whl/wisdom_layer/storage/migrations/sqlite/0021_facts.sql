-- 0021_facts.sql
-- Atomic facts table — Beta in v1.0.
--
-- Stores discrete (subject, attribute, value) triples extracted from
-- captured memories. Each fact retains a pointer to its source memory
-- so the agent can produce an audit trail for any claim it later makes
-- ("Sarah's address is 123 Main St" → "extracted from conversation
-- captured 2026-04-19, ticket TKT-60012").
--
-- v1.0 behavior: last-write-wins on (agent_id, subject, attribute).
-- Older rows are retained for history but only the most recent surfaces
-- at retrieval time. Reconciliation, decay enforcement, and history
-- queries are deferred to v1.0.1 — see docs/releases/V1_0_1_RELEASE.md
-- "Fact Extraction — Beta-to-GA Hardening".

-- up

CREATE TABLE IF NOT EXISTS facts (
    id              TEXT PRIMARY KEY,
    agent_id        TEXT NOT NULL,
    subject         TEXT NOT NULL,
    attribute       TEXT NOT NULL,
    value           TEXT NOT NULL,
    source_memory_id TEXT,
    confidence      REAL NOT NULL DEFAULT 0.7,
    decay_rate      REAL NOT NULL DEFAULT 0.95,
    created_at      TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_facts_agent_subject
    ON facts (agent_id, subject);

CREATE INDEX IF NOT EXISTS idx_facts_agent_subject_attribute
    ON facts (agent_id, subject, attribute);

CREATE INDEX IF NOT EXISTS idx_facts_source_memory
    ON facts (source_memory_id);

CREATE INDEX IF NOT EXISTS idx_facts_agent_created
    ON facts (agent_id, created_at DESC);

-- down

DROP TABLE IF EXISTS facts;
