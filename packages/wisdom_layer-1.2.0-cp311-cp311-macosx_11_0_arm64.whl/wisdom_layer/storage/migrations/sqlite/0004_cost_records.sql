-- 0004_cost_records.sql
-- Phase 0.8: Cost tracking persistence (optional — CostTracker also works in-memory).
-- Adds a cost_records table for durable cost audit trails.

-- up

CREATE TABLE IF NOT EXISTS cost_records (
    id          TEXT PRIMARY KEY,
    agent_id    TEXT NOT NULL DEFAULT 'default',
    model_id    TEXT NOT NULL,
    tier        TEXT NOT NULL DEFAULT 'mid',
    purpose     TEXT NOT NULL DEFAULT '',
    input_tokens    INTEGER NOT NULL DEFAULT 0,
    output_tokens   INTEGER NOT NULL DEFAULT 0,
    cost_usd    REAL NOT NULL DEFAULT 0.0,
    cycle_id    TEXT,
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cost_records_agent_created
    ON cost_records (agent_id, created_at);

CREATE INDEX IF NOT EXISTS idx_cost_records_agent_cycle
    ON cost_records (agent_id, cycle_id);

-- down

DROP TABLE IF EXISTS cost_records;
