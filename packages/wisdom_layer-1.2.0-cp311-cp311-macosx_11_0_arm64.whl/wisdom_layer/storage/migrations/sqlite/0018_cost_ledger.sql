-- 0018_cost_ledger.sql
-- v0.5 Phase 4: Cost visibility.
--
-- Extends the existing cost_records table into a cost ledger:
--   * ``event_id`` links each call to a provenance event when the call
--     was part of a traced op. NULL for free-standing calls.
--   * ``category`` is a structured classifier for per-category summaries
--     (``capture``, ``dream.<phase>``, ``explain``, ``ad_hoc``). Kept
--     alongside the existing ``purpose`` column so older rows remain
--     queryable by their original label.
--
-- No data is migrated — older rows simply carry NULL for the new columns.

-- up

ALTER TABLE cost_records ADD COLUMN event_id TEXT;
ALTER TABLE cost_records ADD COLUMN category TEXT NOT NULL DEFAULT '';

CREATE INDEX IF NOT EXISTS idx_cost_records_agent_category_created
    ON cost_records (agent_id, category, created_at);

CREATE INDEX IF NOT EXISTS idx_cost_records_agent_event
    ON cost_records (agent_id, event_id);

-- down

DROP INDEX IF EXISTS idx_cost_records_agent_event;
DROP INDEX IF EXISTS idx_cost_records_agent_category_created;
-- SQLite pre-3.35 cannot DROP COLUMN; callers should drop the table
-- via 0004's down script if a full reset is required.
