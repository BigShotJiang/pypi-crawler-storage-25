-- 0019_vector_search_index.sql (sqlite)
-- v0.6 Phase 1 Slice C: Intentional no-op for version-number parity
-- with the Postgres dialect.
--
-- Postgres ships an ivfflat ANN index on memories.embedding at this
-- version. SQLite has no vector index type; cosine is computed in
-- Python against every candidate row, which is fast enough for the
-- free-tier scale target (~10k rows per agent).
--
-- The migration runner requires a non-empty up block, so we emit a
-- no-op SELECT that commits cleanly, records the bookkeeping row, and
-- leaves the schema unchanged. Customers observe current_version == 19
-- across both dialects; that is the invariant the contract test suite
-- asserts.
--
-- NOTE: avoid the literal substring "dash dash up" anywhere outside the
-- marker line below; the migration parser finds the FIRST occurrence of
-- that token and treats it as the start of the up block.

-- up

SELECT 1;

-- down

SELECT 1;
