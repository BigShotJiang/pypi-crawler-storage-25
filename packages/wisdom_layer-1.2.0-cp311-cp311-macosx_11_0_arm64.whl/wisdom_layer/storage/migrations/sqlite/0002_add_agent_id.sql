-- 0002_add_agent_id.sql
-- Multi-tenancy: add agent_id to every core table and backfill existing rows
-- to 'default' so single-tenant deployments keep working without migration.
--
-- Doc reference: 06_extraction_plan.md §0.3; 11_integration_ergonomics_resolutions.md §8.
-- Canonical sequence entry: 0002.
--
-- SQLite note: ALTER TABLE ADD COLUMN does not support IF NOT EXISTS, but the
-- MigrationRunner now wraps each migration in a BEGIN/COMMIT transaction that
-- also commits the schema_migrations bookkeeping row, so a crash during this
-- migration rolls the DDL back and a retry starts from a clean state. The
-- composite indexes use IF NOT EXISTS so re-running the *statement* (outside
-- the runner) would still be safe.

-- up

ALTER TABLE memories ADD COLUMN agent_id TEXT NOT NULL DEFAULT 'default';
ALTER TABLE directives ADD COLUMN agent_id TEXT NOT NULL DEFAULT 'default';
ALTER TABLE directive_proposals ADD COLUMN agent_id TEXT NOT NULL DEFAULT 'default';
ALTER TABLE dream_reports ADD COLUMN agent_id TEXT NOT NULL DEFAULT 'default';

CREATE INDEX IF NOT EXISTS idx_memories_agent_tier
    ON memories(agent_id, tier);
CREATE INDEX IF NOT EXISTS idx_memories_agent_salience
    ON memories(agent_id, salience);
CREATE INDEX IF NOT EXISTS idx_memories_agent_created
    ON memories(agent_id, created_at);
CREATE INDEX IF NOT EXISTS idx_directives_agent_status
    ON directives(agent_id, status);
CREATE INDEX IF NOT EXISTS idx_directive_proposals_agent_status
    ON directive_proposals(agent_id, status);
CREATE INDEX IF NOT EXISTS idx_dream_reports_agent_completed
    ON dream_reports(agent_id, completed_at);

-- down

DROP INDEX IF EXISTS idx_dream_reports_agent_completed;
DROP INDEX IF EXISTS idx_directive_proposals_agent_status;
DROP INDEX IF EXISTS idx_directives_agent_status;
DROP INDEX IF EXISTS idx_memories_agent_created;
DROP INDEX IF EXISTS idx_memories_agent_salience;
DROP INDEX IF EXISTS idx_memories_agent_tier;
-- Note: SQLite ALTER TABLE DROP COLUMN was added in 3.35.0 (2021-03-12).
-- The runner never executes this block; customers recover from backup.
ALTER TABLE dream_reports DROP COLUMN agent_id;
ALTER TABLE directive_proposals DROP COLUMN agent_id;
ALTER TABLE directives DROP COLUMN agent_id;
ALTER TABLE memories DROP COLUMN agent_id;
