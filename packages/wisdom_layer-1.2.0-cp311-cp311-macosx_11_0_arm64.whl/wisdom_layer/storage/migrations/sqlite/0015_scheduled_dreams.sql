-- v0.5 Phase 1 — Dream scheduling.
-- Persists the per-agent dream schedule so restarts pick up where the
-- previous process left off. One row per agent_id (schedules are
-- singletons; agents do not currently support multiple concurrent
-- recurring schedules).
--
-- Columns:
--   agent_id       — owner; primary key (one schedule per agent)
--   interval_hours — cadence for the recurring run (float, hours)
--   at_time        — optional HH:MM:SS wall-clock anchor for the run;
--                    NULL means "run `interval_hours` after last run"
--   paused         — 0/1 flag; a paused schedule keeps its next_run
--                    but the scheduler skips until resumed
--   ignore_budget  — 0/1 flag; set by `schedule(..., ignore_budget=True)`
--                    to bypass BudgetGuard pre-flight on scheduled runs
--   next_run       — ISO 8601 UTC timestamp of the next firing
--   last_run       — ISO 8601 UTC timestamp of the most recent firing,
--                    or NULL if never fired
--   created_at     — ISO 8601 UTC timestamp of the original schedule()
--                    call
--   updated_at     — ISO 8601 UTC timestamp of the most recent write
--                    (pause/resume/reschedule all bump this)

-- up

CREATE TABLE IF NOT EXISTS scheduled_dreams (
    agent_id TEXT PRIMARY KEY,
    interval_hours REAL NOT NULL,
    at_time TEXT,
    paused INTEGER NOT NULL DEFAULT 0,
    ignore_budget INTEGER NOT NULL DEFAULT 0,
    next_run TEXT NOT NULL,
    last_run TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_scheduled_dreams_next_run
    ON scheduled_dreams(next_run);

-- down

DROP INDEX IF EXISTS idx_scheduled_dreams_next_run;
DROP TABLE IF EXISTS scheduled_dreams;
