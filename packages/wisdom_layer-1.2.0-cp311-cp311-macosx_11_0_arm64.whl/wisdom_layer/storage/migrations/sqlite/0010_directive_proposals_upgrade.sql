-- 0010_directive_proposals_upgrade.sql
-- Phase E Slice 2: Advisory mode proposal schema.
--
-- Upgrades the directive_proposals table with the fields needed for
-- advisory mode governance:
--
-- - proposed_status: the target status the proposal would create/move to
-- - target_directive_id: for promote/deactivate proposals, the directive being acted on
-- - content_hash: SHA-256 of the proposed text (for add proposals, used in dedup at approve time)
-- - resolved_by: structured JSON (e.g. {"actor":"operator","method":"manual"})
--   to support future audit trail extensibility
--
-- Existing rows retain their current values and the new columns default
-- to NULL / empty, which is valid: pre-Slice-2 proposals have no advisory
-- mode metadata and that's correct.
--
-- Doc reference: 03_critic_directives.md §"Advisory Mode",
-- 06_extraction_plan.md §Phase E.

-- up

ALTER TABLE directive_proposals ADD COLUMN proposed_status TEXT NOT NULL DEFAULT '';
ALTER TABLE directive_proposals ADD COLUMN target_directive_id TEXT DEFAULT NULL;
ALTER TABLE directive_proposals ADD COLUMN content_hash TEXT NOT NULL DEFAULT '';
ALTER TABLE directive_proposals ADD COLUMN resolved_by TEXT DEFAULT NULL;

-- down

ALTER TABLE directive_proposals DROP COLUMN resolved_by;
ALTER TABLE directive_proposals DROP COLUMN content_hash;
ALTER TABLE directive_proposals DROP COLUMN target_directive_id;
ALTER TABLE directive_proposals DROP COLUMN proposed_status;
