-- 0006_dedup_marker.sql
-- Phase A Slice 2: Non-destructive semantic dedup.
--
-- Adds a dedup_of column to memories. When a new capture is detected as a
-- near-duplicate of an existing memory, the NEW row is written with
-- dedup_of = <existing_memory_id>. The existing memory is untouched.
-- Search ranking can use this to bias results (prefer originals).
--
-- Doc reference: 01_memory_architecture.md §"Semantic Dedup",
--                06_extraction_plan.md §Phase A.

-- up

ALTER TABLE memories ADD COLUMN dedup_of TEXT;

-- down

ALTER TABLE memories DROP COLUMN dedup_of;
