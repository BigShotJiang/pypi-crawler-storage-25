-- 0017_health_snapshots.sql
-- v0.5 Phase 3b: Daily health snapshot storage for the trajectory API.
--
-- Stores one JSON-serialized HealthReport per (agent_id, snapshot_date)
-- so ``agent.health.trajectory(days=N)`` can reconstruct a time series
-- without re-aggregating from raw tables. One row per calendar day;
-- the scheduler captures nightly, manual captures upsert the same row.
--
-- Design choices:
--   - snapshot_date is a date-only string (YYYY-MM-DD) so upserts are
--     idempotent within a day without worrying about clock skew.
--   - payload is opaque JSON — the reader is the HealthReport pydantic
--     model, and we deliberately don't shred fields into columns so
--     future HealthReport additions don't require a new migration.
--   - No FK to any other table. HealthReport is a snapshot; the
--     underlying entities may have been deleted by the time a trajectory
--     is read.
--
-- Doc reference: ROADMAP_v1.0/v0.5_scheduler_provenance_analytics/
-- phase_3_health_analytics.md §"Trajectory API".

-- up

CREATE TABLE IF NOT EXISTS health_snapshots (
    agent_id        TEXT NOT NULL,
    snapshot_date   TEXT NOT NULL,
    payload         TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    PRIMARY KEY (agent_id, snapshot_date)
);

CREATE INDEX IF NOT EXISTS idx_health_snapshots_agent_date
    ON health_snapshots (agent_id, snapshot_date DESC);

-- down

DROP INDEX IF EXISTS idx_health_snapshots_agent_date;
DROP TABLE IF EXISTS health_snapshots;
