-- 0008_archived_at.sql
-- Phase B: Decay-driven archive marker for memories.
--
-- Adds an archived_at timestamp column to memories. When a decay pass
-- determines a memory is old enough for archiving, it writes the current
-- UTC timestamp here instead of overwriting the original scope column.
-- This preserves the memory's original scope (long_term, session) while
-- allowing search to filter out archived rows via `archived_at IS NULL`.
--
-- Doc reference: 01_memory_architecture.md §"Decay System",
--                06_extraction_plan.md §Phase B.

-- up

ALTER TABLE memories ADD COLUMN archived_at TEXT DEFAULT NULL;

-- Index for efficient archive filtering in search queries.
-- Partial index: only index non-NULL values (the archived ones) since
-- most rows will be NULL and search filters on IS NULL.
CREATE INDEX IF NOT EXISTS idx_memories_archived_at
    ON memories (agent_id, archived_at);

-- down

ALTER TABLE memories DROP COLUMN archived_at;
