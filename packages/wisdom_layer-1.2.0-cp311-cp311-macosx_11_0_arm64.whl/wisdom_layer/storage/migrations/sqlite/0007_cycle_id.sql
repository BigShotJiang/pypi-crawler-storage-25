-- 0007_cycle_id.sql
-- Phase A Slice 3: Consolidation cycle tagging.
--
-- Adds a cycle_id column to memories. Every row written during a
-- consolidation run is tagged with its cycle_id so the entire batch
-- can be atomically rolled back on failure (DELETE WHERE cycle_id = ?).
--
-- Doc reference: 02_dream_cycles.md §"Critical-Phase Rollback",
--                06_extraction_plan.md §Phase A.

-- up

ALTER TABLE memories ADD COLUMN cycle_id TEXT;

-- down

ALTER TABLE memories DROP COLUMN cycle_id;
