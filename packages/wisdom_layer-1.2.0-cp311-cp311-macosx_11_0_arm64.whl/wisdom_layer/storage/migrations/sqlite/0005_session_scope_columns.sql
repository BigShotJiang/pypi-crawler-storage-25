-- 0005_session_scope_columns.sql
-- Phase A: Session scoping for memories.
--
-- Adds session_id and scope columns to the memories table.
-- scope='long_term' (default) memories never expire.
-- scope='session' memories are eligible for TTL pruning (Phase B).
-- Memories with scope='long_term' + a session_id are tagged for audit only.
--
-- Doc reference: 01_memory_architecture.md §"Session Scoping",
--                06_extraction_plan.md §Phase A.

-- up

ALTER TABLE memories ADD COLUMN session_id TEXT;
ALTER TABLE memories ADD COLUMN scope TEXT NOT NULL DEFAULT 'long_term';
ALTER TABLE memories ADD COLUMN ttl_hours INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_memories_agent_session_scope
    ON memories (agent_id, session_id, scope);

-- down

-- SQLite 3.35.0+ required for DROP COLUMN.
-- Down migration is for manual operator use only — the SDK never calls it.
ALTER TABLE memories DROP COLUMN session_id;
ALTER TABLE memories DROP COLUMN scope;
ALTER TABLE memories DROP COLUMN ttl_hours;
