-- 0022_facts_embedding.sql
-- Add embedding columns to the facts table so ``agent.facts.search()``
-- can rank by semantic similarity instead of substring LIKE matching.
--
-- v1.0 originally shipped facts without embeddings — search was a
-- subscring scan over (subject, attribute, value). That made natural-
-- language queries unusable ("What is Sarah's email?" never matches a
-- value of "sarah@acme.com"). This migration backfills the embedding
-- columns with NULLs; existing rows fall through to the cross-model
-- lexical fallback path until the next write embeds them.
--
-- Cross-backend invariant: same column names + types as the memories
-- table so the dialect-parity test stays green.

-- up

ALTER TABLE facts ADD COLUMN embedding BLOB;
ALTER TABLE facts ADD COLUMN embedding_model_id TEXT;
ALTER TABLE facts ADD COLUMN embedding_dim INTEGER;

CREATE INDEX IF NOT EXISTS idx_facts_agent_embed_model
    ON facts (agent_id, embedding_model_id, embedding_dim);

-- down

DROP INDEX IF EXISTS idx_facts_agent_embed_model;
ALTER TABLE facts DROP COLUMN embedding_dim;
ALTER TABLE facts DROP COLUMN embedding_model_id;
ALTER TABLE facts DROP COLUMN embedding;
