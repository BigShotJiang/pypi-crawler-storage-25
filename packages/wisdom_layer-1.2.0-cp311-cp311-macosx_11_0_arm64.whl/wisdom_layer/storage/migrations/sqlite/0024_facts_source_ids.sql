-- 0024_facts_source_ids.sql
-- Per-fact provenance graph — schema half. Public API surface
-- (`agent.facts.trace()`) lands in v1.2.1; the column lives on disk
-- starting in v1.2.0 so the data is captured the moment the wheel
-- ships.
--
-- Why this matters: in v1.0/v1.1 every fact carries a single
-- `source_memory_id`, so a fact synthesized from multiple memories
-- (the common case once memories are dense and reconsolidation
-- runs) loses every supporting reference except one. When team
-- insights start deriving from facts in v1.2.0, that loss
-- terminates the cross-agent provenance walk early — exactly the
-- failure mode the moat is designed to prevent.
--
-- This migration is **breaking** in spirit, even though the column
-- swap is non-destructive on disk:
--   - The new column `source_memory_ids` (JSON array) is added with
--     default '[]'. Existing rows are backfilled from the legacy
--     scalar column on first run.
--   - The legacy `source_memory_id` column is **retained**, not
--     dropped, for one release cycle. Application code in v1.2.0
--     writes to BOTH columns; reads prefer the array. v1.2.1 stops
--     writing to the scalar column. A future migration drops it
--     once Studio + downstream products are confirmed off the old
--     read path.
--
-- Customer migration story: the `wisdom-layer-migrate` CLI handles
-- this column for users on real fact stores — pre-flight stats,
-- backfill verification, dry-run, rollback within one version.
-- Customers who let the agent's normal initialize() apply the
-- migration get the same backfill but without the diagnostic
-- output.
--
-- Backfill semantics (idempotent):
--   - rows where `source_memory_id IS NOT NULL` → `'["<that id>"]'`
--   - rows where `source_memory_id IS NULL`     → `'[]'`
--
-- Edge case: rows where `source_memory_ids` was already populated
-- by a partially-applied migration are left alone. The UPDATE uses
-- a guard on `source_memory_ids = '[]'` to avoid clobbering
-- already-migrated data.

-- up

ALTER TABLE facts
    ADD COLUMN source_memory_ids TEXT NOT NULL DEFAULT '[]';

UPDATE facts
   SET source_memory_ids = json_array(source_memory_id)
 WHERE source_memory_id IS NOT NULL
   AND source_memory_ids = '[]';

-- down

-- Cannot DROP COLUMN cleanly on older SQLite versions. The supported
-- rollback path is via `wisdom-layer-migrate down --to 0023` which
-- recreates the table without the column. Manual rollback for direct
-- DB editors:
--
--   ALTER TABLE facts DROP COLUMN source_memory_ids;
--
-- Available on SQLite >= 3.35. Verify before invoking.
