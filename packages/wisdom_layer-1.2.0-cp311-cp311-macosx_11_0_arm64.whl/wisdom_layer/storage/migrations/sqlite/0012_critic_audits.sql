-- 0012_critic_audits.sql
-- Phase C Slice 2: Coherence audit storage.
--
-- Stores structured coherence assessments of an agent's active
-- directive set. Each audit records the directives consulted,
-- the coherence score, any contradictions detected, and the
-- deterministically derived is_coherent flag.
--
-- Doc reference: 03_critic_directives.md §"Coherence Detection",
-- 06_extraction_plan.md §Phase F.

-- up

CREATE TABLE IF NOT EXISTS critic_audits (
    id                  TEXT PRIMARY KEY,
    agent_id            TEXT NOT NULL,
    coherence_score     REAL NOT NULL,
    is_coherent         INTEGER NOT NULL DEFAULT 1,
    contradictions_json TEXT NOT NULL DEFAULT '[]',
    summary             TEXT NOT NULL,
    directive_ids_json  TEXT NOT NULL DEFAULT '[]',
    directive_count     INTEGER NOT NULL DEFAULT 0,
    created_at          TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_critic_audits_agent
    ON critic_audits(agent_id, created_at DESC);

-- down

DROP INDEX IF EXISTS idx_critic_audits_agent;
DROP TABLE IF EXISTS critic_audits;
