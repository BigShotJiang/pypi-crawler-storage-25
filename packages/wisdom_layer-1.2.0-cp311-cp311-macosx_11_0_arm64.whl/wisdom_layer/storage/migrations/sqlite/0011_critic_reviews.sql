-- 0011_critic_reviews.sql
-- Phase C Slice 1: Critic review storage.
--
-- Stores structured evaluations of agent output against active directives.
-- Each review records the output assessed, the directives consulted,
-- the LLM's risk assessment, and the deterministically derived
-- pass_through recommendation.
--
-- Doc reference: 03_critic_directives.md §"Critic",
-- 06_extraction_plan.md §Phase F.

-- up

CREATE TABLE IF NOT EXISTS critic_reviews (
    id              TEXT PRIMARY KEY,
    agent_id        TEXT NOT NULL,
    output_text     TEXT NOT NULL,
    context_json    TEXT,
    risk_level      TEXT NOT NULL,
    flags_json      TEXT NOT NULL DEFAULT '[]',
    rationale       TEXT NOT NULL,
    pass_through    INTEGER NOT NULL DEFAULT 1,
    directive_ids_json TEXT NOT NULL DEFAULT '[]',
    created_at      TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_critic_reviews_agent
    ON critic_reviews(agent_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_critic_reviews_risk
    ON critic_reviews(agent_id, risk_level);

-- down

DROP INDEX IF EXISTS idx_critic_reviews_risk;
DROP INDEX IF EXISTS idx_critic_reviews_agent;
DROP TABLE IF EXISTS critic_reviews;
