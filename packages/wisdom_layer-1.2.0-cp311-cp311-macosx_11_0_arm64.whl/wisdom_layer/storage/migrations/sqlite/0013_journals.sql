-- 0013_journals.sql
-- Phase D Slice 1: Journal persistence layer.
--
-- Creates the journals table for storing synthesized journal entries
-- and adds a journaled flag to the memories table so the system can
-- track which memories have been incorporated into a journal.
--
-- Doc reference: 06_extraction_plan.md §Phase D,
-- 01_memory_architecture.md §"Journal Synthesis".

-- up

CREATE TABLE IF NOT EXISTS journals (
    id              TEXT PRIMARY KEY,
    agent_id        TEXT NOT NULL,
    content         TEXT NOT NULL,
    memory_ids_json TEXT NOT NULL DEFAULT '[]',
    created_at      TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_journals_agent
    ON journals(agent_id, created_at DESC);

ALTER TABLE memories ADD COLUMN journaled INTEGER NOT NULL DEFAULT 0;

-- down

ALTER TABLE memories DROP COLUMN journaled;
DROP INDEX IF EXISTS idx_journals_agent;
DROP TABLE IF EXISTS journals;
