-- Phase F Slice 2: Dream report persistence.
-- Adds columns to dream_reports for the new trigger() result shape.
-- Legacy columns (phases_completed, reconsolidated, new_insights,
-- decayed, directives_proposed, journal_entry_id) remain untouched.

-- up

ALTER TABLE dream_reports ADD COLUMN cycle_id TEXT;
ALTER TABLE dream_reports ADD COLUMN status TEXT NOT NULL DEFAULT 'success';
ALTER TABLE dream_reports ADD COLUMN steps TEXT NOT NULL DEFAULT '[]';
ALTER TABLE dream_reports ADD COLUMN duration_ms INTEGER NOT NULL DEFAULT 0;

CREATE UNIQUE INDEX IF NOT EXISTS idx_dream_reports_cycle_id
    ON dream_reports(cycle_id);

CREATE INDEX IF NOT EXISTS idx_dream_reports_agent_cycle
    ON dream_reports(agent_id, cycle_id);

-- down

DROP INDEX IF EXISTS idx_dream_reports_agent_cycle;
DROP INDEX IF EXISTS idx_dream_reports_cycle_id;
