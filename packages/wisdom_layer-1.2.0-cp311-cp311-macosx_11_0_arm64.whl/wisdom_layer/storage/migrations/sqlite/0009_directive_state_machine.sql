-- 0009_directive_state_machine.sql
-- Phase E Slice 1: Directive state machine columns.
--
-- Adds the columns needed for the directive lifecycle:
-- - content_hash: SHA-256 of text for fast exact-dedup
-- - embedding, embedding_model_id, embedding_dim: semantic dedup
-- - promoted_at: timestamp when directive was promoted to permanent
-- - updated_at: last-modified timestamp
--
-- Status values after this migration:
--   provisional → active → permanent (forward)
--   active → inactive (decay or manual deactivate)
--   permanent → inactive (manual deactivate only)
--
-- Existing rows keep status='active', which is a valid lifecycle state.
-- No data loss, no backfill needed — pre-existing rows are already
-- in a valid state.
--
-- Doc reference: 03_critic_directives.md §"Directive Lifecycle",
-- 06_extraction_plan.md §Phase E.

-- up

ALTER TABLE directives ADD COLUMN content_hash TEXT NOT NULL DEFAULT '';
ALTER TABLE directives ADD COLUMN embedding BLOB;
ALTER TABLE directives ADD COLUMN embedding_model_id TEXT NOT NULL DEFAULT '';
ALTER TABLE directives ADD COLUMN embedding_dim INTEGER NOT NULL DEFAULT 0;
ALTER TABLE directives ADD COLUMN promoted_at TEXT;
ALTER TABLE directives ADD COLUMN updated_at TEXT;

CREATE INDEX IF NOT EXISTS idx_directives_agent_content_hash
    ON directives(agent_id, content_hash);

-- down

DROP INDEX IF EXISTS idx_directives_agent_content_hash;
-- SQLite ALTER TABLE DROP COLUMN requires 3.35.0+
ALTER TABLE directives DROP COLUMN updated_at;
ALTER TABLE directives DROP COLUMN promoted_at;
ALTER TABLE directives DROP COLUMN embedding_dim;
ALTER TABLE directives DROP COLUMN embedding_model_id;
ALTER TABLE directives DROP COLUMN embedding;
ALTER TABLE directives DROP COLUMN content_hash;
