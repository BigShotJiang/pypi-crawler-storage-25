-- 0001_initial.sql
-- Baseline schema for the Wisdom Layer SDK default SQLite backend.
--
-- This migration captures the pre-0.2 ad-hoc schema exactly as it was so
-- that 0.3 (agent_id), 0.4 (embedding_model_id), 0.8 (cost_records),
-- Phase A (session/scope), and Phase E (directive state machine) can
-- layer on top cleanly without retroactively editing this file.
--
-- All statements use IF NOT EXISTS so a partial apply followed by a retry
-- is safe. Do NOT add INSERT statements here — seed data belongs in a
-- dedicated seed migration that uses INSERT OR IGNORE.

-- up

CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    tier TEXT NOT NULL DEFAULT 'raw',
    event_type TEXT NOT NULL DEFAULT '',
    content TEXT NOT NULL,
    metadata TEXT NOT NULL DEFAULT '{}',
    salience REAL NOT NULL DEFAULT 0.5,
    reinforcement_count INTEGER NOT NULL DEFAULT 0,
    emotional_intensity REAL NOT NULL DEFAULT 0.0,
    embedding BLOB,
    source_ids TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    accessed_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_memories_tier ON memories(tier);
CREATE INDEX IF NOT EXISTS idx_memories_salience ON memories(salience);
CREATE INDEX IF NOT EXISTS idx_memories_created_at ON memories(created_at);

CREATE TABLE IF NOT EXISTS directives (
    id TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    priority TEXT NOT NULL DEFAULT 'contextual',
    usage_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    last_used TEXT
);

CREATE TABLE IF NOT EXISTS directive_proposals (
    id TEXT PRIMARY KEY,
    action TEXT NOT NULL,
    text TEXT NOT NULL,
    reasoning TEXT NOT NULL DEFAULT '',
    confidence REAL NOT NULL DEFAULT 0.5,
    status TEXT NOT NULL DEFAULT 'pending',
    source_memory_ids TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS dream_reports (
    id TEXT PRIMARY KEY,
    started_at TEXT NOT NULL,
    completed_at TEXT NOT NULL,
    phases_completed TEXT NOT NULL DEFAULT '[]',
    reconsolidated INTEGER NOT NULL DEFAULT 0,
    new_insights INTEGER NOT NULL DEFAULT 0,
    decayed INTEGER NOT NULL DEFAULT 0,
    directives_proposed INTEGER NOT NULL DEFAULT 0,
    journal_entry_id TEXT
);

-- down

DROP TABLE IF EXISTS dream_reports;
DROP TABLE IF EXISTS directive_proposals;
DROP TABLE IF EXISTS directives;
DROP INDEX IF EXISTS idx_memories_created_at;
DROP INDEX IF EXISTS idx_memories_salience;
DROP INDEX IF EXISTS idx_memories_tier;
DROP TABLE IF EXISTS memories;
