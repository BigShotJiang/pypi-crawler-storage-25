"""SQLite storage backend — free tier, zero infrastructure.

Schema is owned by :mod:`wisdom_layer.storage._migrations`. On
:meth:`SQLiteBackend.initialize`, :class:`MigrationRunner` discovers and
applies every pending ``NNNN_<name>.sql`` file in
``wisdom_layer/storage/migrations/sqlite/`` in numeric order and records
the result in ``schema_migrations``. The backend itself never defines DDL
inline — adding a column or index means writing a new migration file,
never editing this module.

v0.6: migration files live under a dialect subfolder so the forthcoming
``PostgresBackend`` can ship its own parallel tree at
``storage/migrations/postgres/`` without forking the runner.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import struct
import uuid
from datetime import UTC, datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any

import numpy as np

from wisdom_layer._internal.admin_defaults import AdminDefaults
from wisdom_layer.errors import BackendNotInitializedError, EmbeddingConfigMismatchError
from wisdom_layer.memory._decay import (
    DECAY_EXEMPT_TYPES,
    compute_salience,
)
from wisdom_layer.memory.ranking import recency_bonus
from wisdom_layer.storage._migrations import MigrationRunner
from wisdom_layer.storage.base import BaseBackend

if TYPE_CHECKING:
    from collections.abc import Sequence

logger = logging.getLogger(__name__)

_MIGRATIONS_DIR = Path(__file__).parent / "migrations" / "sqlite"

#: Centralized SQL fragment for excluding archived memories from search.
#: Every query that should respect archive status uses this constant
#: instead of inlining the clause — single source of truth.
_NOT_ARCHIVED: str = "AND archived_at IS NULL"


def _kinds_filter_sqlite(
    kinds: Sequence[str] | None,
) -> tuple[str, tuple[str, ...]]:
    """Build the ``AND event_type IN (...)`` clause + param tuple for SQLite.

    Returns ``("", ())`` when ``kinds`` is None or empty so the caller can
    splice without conditional branching.
    """
    if not kinds:
        return "", ()
    placeholders = ",".join("?" for _ in kinds)
    return f"AND event_type IN ({placeholders})", tuple(kinds)


def _now_iso() -> str:
    """Current UTC time as ISO 8601 string."""
    return datetime.now(UTC).isoformat()


def _gen_id() -> str:
    """Generate a 12-char hex ID."""
    return uuid.uuid4().hex[:12]


def _pack_embedding(vec: list[float]) -> bytes:
    """Pack a float list into compact bytes for SQLite storage."""
    return struct.pack(f"{len(vec)}f", *vec)


def _unpack_embedding(data: bytes) -> list[float]:
    """Unpack bytes back to float list."""
    n = len(data) // 4
    return list(struct.unpack(f"{n}f", data))


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors."""
    a_arr = np.array(a, dtype=np.float32)
    b_arr = np.array(b, dtype=np.float32)
    dot = np.dot(a_arr, b_arr)
    norm_a = np.linalg.norm(a_arr)
    norm_b = np.linalg.norm(b_arr)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return float(dot / (norm_a * norm_b))


#: Backfill default for migration 0003. Every row written before Phase 0.4
#: was assumed to be embedded with this model at 384 dimensions.
DEFAULT_EMBEDDING_MODEL_ID = "all-MiniLM-L6-v2"
DEFAULT_EMBEDDING_DIM = 384


class SQLiteBackend(BaseBackend):
    """SQLite storage backend with in-process vector search.

    Stores everything in a single SQLite file. Vector search is done
    in-process using numpy cosine similarity — no external vector DB needed.

    Args:
        path: Path to the SQLite database file. Created if it doesn't exist.
        embed_fn: Optional async function to generate embeddings.
            Signature: ``async (text: str) -> list[float]``. When ``None``
            (the default), :meth:`bind_embedder` wires the LLM adapter's
            ``embed`` callable in at agent startup.
        embedding_model_id: Stable identifier of the embedding model that
            vectors are produced for. Persisted with every row so vector
            search can refuse to compare across models. When ``None`` (the
            default), :meth:`bind_embedder` reads it from the LLM adapter
            so adapter and backend cannot drift. Setting this explicitly
            opts you out of auto-binding — disagreement with the adapter
            then raises :class:`EmbeddingConfigMismatchError`.
        embedding_dim: Dimensionality of vectors. Same semantics as
            ``embedding_model_id`` — leave at ``None`` to auto-bind.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        embed_fn: Any = None,
        embedding_model_id: str | None = None,
        embedding_dim: int | None = None,
    ) -> None:
        self._path = Path(path)
        self._conn: sqlite3.Connection | None = None
        self._embed_fn = embed_fn
        # Defaults preserve the historical baseline so backward-compat paths
        # that never call bind_embedder still work. Track explicit overrides
        # separately so bind_embedder can validate and raise
        # EmbeddingConfigMismatchError on disagreement.
        self._embedding_model_id = embedding_model_id or DEFAULT_EMBEDDING_MODEL_ID
        self._embedding_dim = (
            embedding_dim if embedding_dim is not None else DEFAULT_EMBEDDING_DIM
        )
        self._embedding_model_id_explicit = embedding_model_id is not None
        self._embedding_dim_explicit = embedding_dim is not None

    def _apply_embedder_binding(
        self,
        *,
        model_id: str,
        dim: int,
        embed_fn: Any,
    ) -> None:
        """Wire the adapter's embedder identity into this backend.

        See :meth:`BaseBackend.bind_embedder` for the contract.
        """
        if self._embedding_model_id_explicit and self._embedding_model_id != model_id:
            raise EmbeddingConfigMismatchError(
                f"SQLiteBackend was constructed with "
                f"embedding_model_id={self._embedding_model_id!r} but the "
                f"LLM adapter advertises {model_id!r}. Drop the explicit "
                f"embedding_model_id from SQLiteBackend(...) and let the "
                f"agent thread the adapter's value through automatically."
            )
        if self._embedding_dim_explicit and self._embedding_dim != dim:
            raise EmbeddingConfigMismatchError(
                f"SQLiteBackend was constructed with "
                f"embedding_dim={self._embedding_dim} but the LLM adapter "
                f"produces {dim}-dim vectors (model={model_id!r}). Drop "
                f"the explicit embedding_dim from SQLiteBackend(...) and "
                f"let the agent thread the adapter's value through "
                f"automatically."
            )
        self._embedding_model_id = model_id
        self._embedding_dim = dim
        if self._embed_fn is None and embed_fn is not None:
            self._embed_fn = embed_fn

    async def initialize(self) -> None:
        """Open the connection and apply any pending schema migrations.

        Safe to call on every boot. :class:`MigrationRunner` consults
        ``schema_migrations`` and only runs versions that have not yet
        been applied.
        """
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.execute("PRAGMA temp_store=MEMORY")
        self._conn.execute("PRAGMA mmap_size=268435456")

        runner = MigrationRunner(
            conn=self._conn,
            migrations_dir=_MIGRATIONS_DIR,
        )
        newly_applied = runner.apply_pending()

        logger.info(
            "SQLite backend initialized",
            extra={
                "subsystem": "storage.sqlite",
                "path": str(self._path),
                "migrations_applied": [m.name for m in newly_applied],
            },
        )

    async def migration_status(self) -> dict[str, object]:
        """Return the structured migration report for this backend.

        Returns:
            A dict with ``applied``, ``pending``, and ``current_version``
            keys. See :meth:`MigrationRunner.status` for shape details.
        """
        runner = MigrationRunner(
            conn=self._db(),
            migrations_dir=_MIGRATIONS_DIR,
        )
        return runner.status()

    async def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    def _db(self) -> sqlite3.Connection:
        """Get the active connection or raise."""
        if self._conn is None:
            msg = "Backend not initialized. Call initialize() first."
            raise BackendNotInitializedError(msg)
        return self._conn

    # --- Memory ---

    async def store_memory(
        self,
        *,
        agent_id: str,
        tier: str,
        event_type: str,
        content: dict[str, object],
        emotional_intensity: float = 0.0,
        session_id: str | None = None,
        scope: str = "long_term",
        ttl_hours: int = 0,
        dedup_of: str | None = None,
        source_ids: list[str] | None = None,
        cycle_id: str | None = None,
        created_at: datetime | None = None,
    ) -> str:
        """Store a memory record, scoped to ``agent_id``, with optional embedding.

        Every row carries the active backend's ``embedding_model_id`` and
        ``embedding_dim`` so that future vector searches can refuse to
        compare vectors across models. Rows persisted before Phase 0.4 were
        backfilled to ``all-MiniLM-L6-v2`` / 384 by migration 0003.

        Args:
            session_id: Optional session tag (``None`` for bare captures).
            scope: ``long_term`` (default) or ``session``.
            ttl_hours: Hours before session-scoped memory is eligible for
                prune. 0 = no expiry. **Advisory only in Phase A** — the
                value is persisted but no prune job enforces it yet.
            dedup_of: If this row was identified as a near-duplicate of an
                existing memory, stores the original's ID. Non-destructive
                dedup marker — the original memory is never modified.
            source_ids: Provenance chain — IDs of source memories this
                record was synthesized from (Tier 2 consolidation).
            cycle_id: Consolidation cycle tag for atomic rollback.

        Raises:
            ValueError: If ``embed_fn`` returns a vector whose length does
                not match the configured ``embedding_dim``.
        """
        db = self._db()
        memory_id = _gen_id()
        now = _now_iso()
        # Migration imports preserve the original capture timestamp via
        # ``created_at=``. ``updated_at`` and ``accessed_at`` always
        # track wall-clock so reinforcement and decay run against real
        # elapsed time, not historical time.
        created_at_iso = (
            created_at.astimezone(UTC).isoformat()
            if created_at is not None
            else now
        )
        content_str = json.dumps(content, default=str)
        source_ids_str = json.dumps(source_ids or [])

        embedding: bytes | None = None
        if self._embed_fn is not None:
            vec = await self._embed_fn(content_str)
            if len(vec) != self._embedding_dim:
                msg = (
                    f"Embedding adapter returned {len(vec)}-dim vector but "
                    f"backend is configured for {self._embedding_dim}-dim "
                    f"({self._embedding_model_id}). Refusing to write a "
                    f"row that would silently corrupt vector search."
                )
                raise ValueError(msg)
            embedding = _pack_embedding(vec)

        db.execute(
            """INSERT INTO memories
               (id, agent_id, tier, event_type, content, salience,
                emotional_intensity, embedding, embedding_model_id,
                embedding_dim, source_ids, session_id, scope, ttl_hours,
                dedup_of, cycle_id, created_at, updated_at, accessed_at)
               VALUES (?, ?, ?, ?, ?, 0.5, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                memory_id,
                agent_id,
                tier,
                event_type,
                content_str,
                emotional_intensity,
                embedding,
                self._embedding_model_id,
                self._embedding_dim,
                source_ids_str,
                session_id,
                scope,
                ttl_hours,
                dedup_of,
                cycle_id,
                created_at_iso,
                now,
                now,
            ),
        )
        db.commit()

        logger.info(
            "Memory stored",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "memory_id": memory_id,
                "tier": tier,
                "event_type": event_type,
                "session_id": session_id,
                "scope": scope,
                "dedup_of": dedup_of,
                "cycle_id": cycle_id,
                "embedding_model_id": self._embedding_model_id,
                "embedding_dim": self._embedding_dim,
                "has_embedding": embedding is not None,
            },
        )
        return memory_id

    async def search_memories(
        self,
        *,
        agent_id: str,
        query: str,
        limit: int = 5,
        min_salience: float = 0.0,
        kinds: Sequence[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Search memories owned by ``agent_id`` via semantic similarity or text.

        Vector search is restricted to rows whose ``embedding_model_id`` and
        ``embedding_dim`` match this backend's configured embedder — cosine
        similarity across embedding spaces is meaningless and would silently
        corrupt ranking. Rows under stale models (captured by a previous
        embedder before a model upgrade) are unreachable via vector search
        until Phase A's reembed migration job rewrites them; the cross-model
        lexical fallback below catches them in the meantime, returning them
        with ``similarity=1.0`` (the text-match marker, not a real score).

        Rows belonging to other agents are never considered.

        Args:
            kinds: Optional list of ``event_type`` values. ``None`` (default)
                returns all kinds. When provided, every search path (vector,
                stale-model lexical fallback, no-embed text fallback) honors
                the same filter so the caller's filter is never silently
                dropped on a fallback path.

        Raises:
            ValueError: If ``embed_fn`` returns a query vector whose length
                does not match the configured ``embedding_dim``. The strongly-
                typed ``EmbeddingDimensionMismatchError`` lands in Phase 0.10.
        """
        db = self._db()
        kinds_clause, kinds_params = _kinds_filter_sqlite(kinds)

        # If we have an embed function, do vector search
        if self._embed_fn is not None:
            query_vec = await self._embed_fn(query)
            if len(query_vec) != self._embedding_dim:
                msg = (
                    f"Embedding adapter returned {len(query_vec)}-dim query "
                    f"vector but backend is configured for "
                    f"{self._embedding_dim}-dim ({self._embedding_model_id}). "
                    f"Refusing a search that would silently rank against the "
                    f"wrong embedding space."
                )
                raise ValueError(msg)
            rows = db.execute(
                f"""SELECT id, tier, event_type, content, salience,
                          reinforcement_count, emotional_intensity,
                          embedding, source_ids, created_at
                   FROM memories
                   WHERE agent_id = ?
                     AND salience >= ?
                     AND embedding_model_id = ?
                     AND embedding_dim = ?
                     AND embedding IS NOT NULL
                     {kinds_clause}
                     {_NOT_ARCHIVED}""",
                (
                    agent_id,
                    min_salience,
                    self._embedding_model_id,
                    self._embedding_dim,
                    *kinds_params,
                ),
            ).fetchall()

            # Score with recency-weighted ranking.
            # Formula: score = cosine_sim + recency_bonus(age)
            # recency_bonus is a named constant from memory.ranking.
            now = _now_iso()
            now_dt = datetime.fromisoformat(now)
            scored = []
            for row in rows:
                mem_vec = _unpack_embedding(row["embedding"])
                sim = _cosine_similarity(query_vec, mem_vec)
                created_dt = datetime.fromisoformat(row["created_at"])
                age_seconds = max(
                    (now_dt - created_dt).total_seconds(), 0.0
                )
                combined = sim + recency_bonus(age_seconds)
                scored.append((combined, sim, row))

            scored.sort(key=lambda x: x[0], reverse=True)

            # Build results WITHOUT inline reinforcement.
            # The agent layer owns async-after-return reinforcement.
            results = []
            for _combined, sim, row in scored[:limit]:
                results.append({
                    "id": row["id"],
                    "tier": row["tier"],
                    "event_type": row["event_type"],
                    "content": json.loads(row["content"]),
                    "salience": row["salience"],
                    "similarity": round(sim, 4),
                    "created_at": row["created_at"],
                })

            # Cross-model lexical fallback. If vector search left capacity,
            # fill it with text-LIKE hits over stale-model rows so a fresh
            # embedding-model upgrade does not silently make pre-upgrade
            # memories unreachable. These rows are not reinforced (we only
            # know the content textually matches, not that it is semantically
            # close) and carry the text-match similarity marker.
            remaining = limit - len(results)
            if remaining > 0:
                stale_rows = db.execute(
                    f"""SELECT id, tier, event_type, content, salience, created_at
                       FROM memories
                       WHERE agent_id = ?
                         AND salience >= ?
                         AND content LIKE ?
                         AND (embedding_model_id != ? OR embedding_dim != ?)
                         {kinds_clause}
                         {_NOT_ARCHIVED}
                       ORDER BY salience DESC, created_at DESC
                       LIMIT ?""",
                    (
                        agent_id,
                        min_salience,
                        f"%{query}%",
                        self._embedding_model_id,
                        self._embedding_dim,
                        *kinds_params,
                        remaining,
                    ),
                ).fetchall()
                for row in stale_rows:
                    results.append({
                        "id": row["id"],
                        "tier": row["tier"],
                        "event_type": row["event_type"],
                        "content": json.loads(row["content"]),
                        "salience": row["salience"],
                        "similarity": 1.0,
                        "created_at": row["created_at"],
                    })

            return results

        # Fallback: text search
        rows = db.execute(
            f"""SELECT id, tier, event_type, content, salience, created_at
               FROM memories
               WHERE agent_id = ?
                 AND salience >= ?
                 AND content LIKE ?
                 {kinds_clause}
                 {_NOT_ARCHIVED}
               ORDER BY salience DESC, created_at DESC
               LIMIT ?""",
            (
                agent_id,
                min_salience,
                f"%{query}%",
                *kinds_params,
                limit,
            ),
        ).fetchall()

        return [
            {
                "id": row["id"],
                "tier": row["tier"],
                "event_type": row["event_type"],
                "content": json.loads(row["content"]),
                "salience": row["salience"],
                "similarity": 1.0,  # Text match, no real similarity score
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def get_reflections(
        self,
        *,
        agent_id: str,
        topic: str = "",
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Retrieve Tier 3 reflective journal entries for ``agent_id``."""
        db = self._db()

        if topic and self._embed_fn:
            # Semantic search within reflections (still agent-scoped)
            return await self.search_memories(
                agent_id=agent_id,
                query=topic,
                limit=limit,
                min_salience=0.0,
            )

        query_sql = """SELECT id, content, source_ids, created_at
                       FROM memories
                       WHERE agent_id = ? AND tier = 'reflective'
                       ORDER BY created_at DESC LIMIT ?"""
        rows = db.execute(query_sql, (agent_id, limit)).fetchall()

        return [
            {
                "id": row["id"],
                "content": json.loads(row["content"]),
                "source_ids": json.loads(row["source_ids"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def get_provenance(
        self, memory_id: str, *, agent_id: str
    ) -> list[dict[str, Any]]:
        """Trace a memory back to its raw sources within ``agent_id``.

        Returns an empty list if ``memory_id`` does not belong to this
        agent. Every row in the returned chain is guaranteed to be owned
        by ``agent_id`` — the walk never follows a ``source_ids`` edge
        into another agent's namespace.
        """
        db = self._db()
        chain: list[dict[str, Any]] = []
        visited: set[str] = set()
        queue = [memory_id]

        while queue:
            mid = queue.pop(0)
            if mid in visited:
                continue
            visited.add(mid)

            row = db.execute(
                """SELECT id, tier, content, source_ids, created_at
                   FROM memories WHERE id = ? AND agent_id = ?""",
                (mid, agent_id),
            ).fetchone()

            if row is None:
                continue

            chain.append({
                "id": row["id"],
                "tier": row["tier"],
                "content": json.loads(row["content"]),
                "created_at": row["created_at"],
            })

            source_ids = json.loads(row["source_ids"])
            queue.extend(source_ids)

        return chain

    async def find_near_duplicate(
        self,
        *,
        agent_id: str,
        embedding: list[float],
        threshold: float = 0.92,
    ) -> str | None:
        """Check if a near-duplicate memory exists for ``agent_id``.

        Scans all embedded memories for this agent and returns the ID of
        the best match if its cosine similarity >= threshold. Returns
        ``None`` if no near-duplicate exists or if the backend has no
        embed function.

        Invariant: the returned ID always points to the **root** original.
        If the closest vector match is itself a duplicate (has ``dedup_of``
        set), the chain is followed to the root so all duplicates converge
        on a single original — no chained pointers.
        """
        db = self._db()
        rows = db.execute(
            """SELECT id, embedding
               FROM memories
               WHERE agent_id = ?
                 AND embedding IS NOT NULL
                 AND embedding_model_id = ?
                 AND embedding_dim = ?""",
            (agent_id, self._embedding_model_id, self._embedding_dim),
        ).fetchall()

        best_id: str | None = None
        best_sim = 0.0
        for row in rows:
            mem_vec = _unpack_embedding(row["embedding"])
            sim = _cosine_similarity(embedding, mem_vec)
            if sim >= threshold and sim > best_sim:
                best_sim = sim
                best_id = row["id"]

        if best_id is not None:
            best_id = self._resolve_dedup_root(agent_id, best_id)

        return best_id

    def _resolve_dedup_root(self, agent_id: str, memory_id: str) -> str:
        """Follow the ``dedup_of`` chain to the root original memory.

        Cycle-safe: stops if a visited ID is encountered again.
        Deletion-safe: if an intermediate row was deleted, the chain
        stops at the last reachable node.
        """
        db = self._db()
        current = memory_id
        seen: set[str] = set()
        while True:
            if current in seen:
                break
            seen.add(current)
            row = db.execute(
                "SELECT dedup_of FROM memories WHERE id = ? AND agent_id = ?",
                (current, agent_id),
            ).fetchone()
            if row is None or row["dedup_of"] is None:
                return current
            current = row["dedup_of"]
        return current

    async def get_consolidation_candidates(
        self,
        *,
        agent_id: str,
        limit: int = 20,
        min_salience: float = 0.4,
        tier: str = "raw",
        lookback_days: int | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch memories eligible for Tier 2 consolidation.

        Orders by reinforcement_count (most accessed first), then
        salience, then recency. The hard ``limit`` prevents
        unbounded LLM context.
        """
        db = self._db()
        lookback_clause = ""
        params: tuple[Any, ...] = (agent_id, tier, min_salience)
        if lookback_days is not None:
            cutoff = (
                datetime.now(UTC) - timedelta(days=lookback_days)
            ).isoformat()
            lookback_clause = "AND created_at >= ?"
            params = (*params, cutoff)
        rows = db.execute(
            f"""SELECT id, tier, event_type, content, salience,
                      reinforcement_count, emotional_intensity,
                      source_ids, created_at
               FROM memories
               WHERE agent_id = ?
                 AND tier = ?
                 AND salience >= ?
                 {lookback_clause}
                 {_NOT_ARCHIVED}
               ORDER BY reinforcement_count DESC,
                        salience DESC,
                        created_at DESC
               LIMIT ?""",
            (*params, limit),
        ).fetchall()

        return [
            {
                "id": row["id"],
                "tier": row["tier"],
                "event_type": row["event_type"],
                "content": json.loads(row["content"]),
                "salience": row["salience"],
                "reinforcement_count": row["reinforcement_count"],
                "emotional_intensity": row["emotional_intensity"],
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def rollback_cycle(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> int:
        """Delete all memories tagged with ``cycle_id`` for atomic rollback."""
        db = self._db()
        cursor = db.execute(
            "DELETE FROM memories WHERE agent_id = ? AND cycle_id = ?",
            (agent_id, cycle_id),
        )
        db.commit()
        deleted = cursor.rowcount
        logger.info(
            "Cycle rolled back",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "cycle_id": cycle_id,
                "deleted": deleted,
            },
        )
        return deleted

    async def get_cycle_insights(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> list[dict[str, Any]]:
        """Fetch reconsolidated insights produced in the given dream cycle."""
        db = self._db()
        rows = db.execute(
            """SELECT id, content, created_at
               FROM memories
               WHERE agent_id = ?
                 AND tier = 'consolidated'
                 AND event_type = 'reconsolidated_insight'
                 AND cycle_id = ?
                 AND archived_at IS NULL
               ORDER BY created_at DESC""",
            (agent_id, cycle_id),
        ).fetchall()

        return [
            {
                "id": row["id"],
                "content": row["content"],
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def run_decay_pass(
        self,
        *,
        agent_id: str,
        admin_defaults: AdminDefaults | None = None,
    ) -> dict[str, Any]:
        """Run a single deterministic decay pass over all non-archived memories.

        Operations in strict order per memory:
        1. Rescore salience via ``compute_salience()``.
        2. If immune → skip weaken/archive.
        3. If age > ``archive_days`` → archive (set ``archived_at``).
        4. Elif age > ``weaken_days`` → weaken (multiply salience by
           ``decay_factor``).

        A memory receives archive OR weaken, never both. When
        ``admin_defaults`` is omitted, the balanced archetype is used
        (matches pre-v0.3 behavior).
        """
        ad = admin_defaults or AdminDefaults()
        db = self._db()
        now = _now_iso()
        now_dt = datetime.fromisoformat(now)

        # Fetch all non-archived memories for this agent
        rows = db.execute(
            """SELECT id, event_type, emotional_intensity,
                      reinforcement_count, created_at
               FROM memories
               WHERE agent_id = ?
                 AND archived_at IS NULL""",
            (agent_id,),
        ).fetchall()

        total_examined = len(rows)
        rescored = 0
        weakened = 0
        archived = 0
        skipped_immune = 0

        rescore_updates: list[tuple[float, str]] = []
        weaken_updates: list[tuple[float, str]] = []
        archive_updates: list[str] = []

        for row in rows:
            created_dt = datetime.fromisoformat(row["created_at"])
            age_seconds = max(
                (now_dt - created_dt).total_seconds(), 0.0
            )
            age_days = age_seconds / 86_400.0

            # 1. Rescore salience
            new_salience = compute_salience(
                reinforcement_count=row["reinforcement_count"],
                emotional_intensity=row["emotional_intensity"],
                age_seconds=age_seconds,
                admin_defaults=ad,
            )
            rescore_updates.append((new_salience, row["id"]))
            rescored += 1

            # 2. Check immunity
            is_immune = (
                row["emotional_intensity"] >= ad.emotional_immunity_threshold
                or row["event_type"] in DECAY_EXEMPT_TYPES
            )
            if is_immune:
                skipped_immune += 1
                continue

            # 3. Archive OR weaken (mutually exclusive)
            if age_days > ad.archive_days:
                archive_updates.append(row["id"])
                archived += 1
            elif age_days > ad.weaken_days:
                # Apply decay factor to the rescored salience, clamped to [0, 1]
                weakened_salience = max(
                    0.0, min(new_salience * ad.decay_factor, 1.0)
                )
                weaken_updates.append((weakened_salience, row["id"]))
                weakened += 1

        # Batch UPDATE: rescore all (except those about to be weakened —
        # weaken_updates already includes the decay factor)
        weakened_ids = {mid for _, mid in weaken_updates}
        for salience, mid in rescore_updates:
            if mid not in weakened_ids:
                db.execute(
                    "UPDATE memories SET salience = ?, updated_at = ? WHERE id = ?",
                    (salience, now, mid),
                )

        # Batch UPDATE: weaken (rescored + decay factor applied)
        for salience, mid in weaken_updates:
            db.execute(
                "UPDATE memories SET salience = ?, updated_at = ? WHERE id = ?",
                (salience, now, mid),
            )

        # Batch UPDATE: archive
        for mid in archive_updates:
            db.execute(
                "UPDATE memories SET archived_at = ?, updated_at = ? WHERE id = ?",
                (now, now, mid),
            )

        db.commit()

        logger.info(
            "Decay pass completed",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "total_examined": total_examined,
                "rescored": rescored,
                "weakened": weakened,
                "archived": archived,
                "skipped_immune": skipped_immune,
            },
        )
        return {
            "rescored": rescored,
            "weakened": weakened,
            "archived": archived,
            "skipped_immune": skipped_immune,
            "total_examined": total_examined,
        }

    async def prune_expired_sessions(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any]:
        """Delete session-scoped memories whose TTL has expired.

        Uses SQLite ``datetime()`` arithmetic to compare
        ``created_at + ttl_hours`` against UTC now. Only rows with
        ``scope='session'`` and ``ttl_hours > 0`` are candidates.

        Returns:
            Dict with ``pruned_count`` and ``pruned_ids``.
        """
        db = self._db()

        # Step 1: SELECT expired IDs for audit trail before deleting
        rows = db.execute(
            """SELECT id FROM memories
               WHERE agent_id = ?
                 AND scope = 'session'
                 AND ttl_hours > 0
                 AND datetime(created_at, '+' || ttl_hours || ' hours')
                     <= datetime('now')""",
            (agent_id,),
        ).fetchall()

        pruned_ids = [row["id"] for row in rows]

        if pruned_ids:
            placeholders = ",".join("?" for _ in pruned_ids)
            db.execute(
                f"DELETE FROM memories WHERE id IN ({placeholders})",  # noqa: S608
                pruned_ids,
            )
            db.commit()

        logger.info(
            "Session memories pruned",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "pruned_count": len(pruned_ids),
            },
        )
        return {
            "pruned_count": len(pruned_ids),
            "pruned_ids": pruned_ids,
        }

    async def update_memory_embedding(
        self,
        *,
        agent_id: str,
        memory_id: str,
        embedding: list[float],
        embedding_model_id: str,
        embedding_dim: int,
    ) -> bool:
        db = self._db()
        packed = _pack_embedding(embedding)
        now = datetime.now(UTC).isoformat()
        cursor = db.execute(
            """UPDATE memories
               SET embedding = ?, embedding_model_id = ?,
                   embedding_dim = ?, updated_at = ?
               WHERE id = ? AND agent_id = ?""",
            (packed, embedding_model_id, embedding_dim, now, memory_id, agent_id),
        )
        db.commit()
        return cursor.rowcount > 0

    async def iter_memories_for_reembed(
        self,
        *,
        agent_id: str,
        current_model_id: str,
        batch_size: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        db = self._db()
        rows = db.execute(
            """SELECT id, content, event_type
               FROM memories
               WHERE agent_id = ?
                 AND embedding IS NOT NULL
                 AND (embedding_model_id != ? OR embedding_model_id IS NULL
                      OR embedding_model_id = '')
               ORDER BY created_at ASC
               LIMIT ? OFFSET ?""",
            (agent_id, current_model_id, batch_size, offset),
        ).fetchall()
        return [
            {
                "id": row["id"],
                "content": json.loads(row["content"]),
                "event_type": row["event_type"],
            }
            for row in rows
        ]

    async def export_memories(
        self,
        *,
        agent_id: str,
        include_session_memories: bool = True,
        tier_filter: str | None = None,
    ) -> list[dict[str, Any]]:
        """Export all memories for ``agent_id`` as portable dicts.

        Returns semantic content, metadata, and provenance — no embedding
        blobs, dedup pointers, or DB-internal fields.
        """
        db = self._db()
        scope_filter = "" if include_session_memories else "AND scope != 'session'"
        tier_clause = ""
        params: list[Any] = [agent_id]
        if tier_filter is not None:
            tier_clause = "AND tier = ?"
            params.append(tier_filter)
        rows = db.execute(
            f"""SELECT id, tier, event_type, content, salience,
                       reinforcement_count, emotional_intensity,
                       source_ids, session_id, scope, ttl_hours,
                       created_at, updated_at, accessed_at
                FROM memories
                WHERE agent_id = ?
                {scope_filter}
                {tier_clause}
                ORDER BY created_at ASC""",  # noqa: S608
            params,
        ).fetchall()

        exported: list[dict[str, Any]] = []
        for row in rows:
            exported.append({
                "id": row["id"],
                "tier": row["tier"],
                "event_type": row["event_type"],
                "content": json.loads(row["content"]),
                "salience": row["salience"],
                "reinforcement_count": row["reinforcement_count"],
                "emotional_intensity": row["emotional_intensity"],
                "source_ids": json.loads(row["source_ids"]),
                "session_id": row["session_id"],
                "scope": row["scope"],
                "ttl_hours": row["ttl_hours"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "accessed_at": row["accessed_at"],
            })

        logger.info(
            "Memories exported",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "count": len(exported),
                "include_session": include_session_memories,
            },
        )
        return exported

    async def import_memories(
        self,
        *,
        agent_id: str,
        memories: list[dict[str, Any]],
    ) -> list[str]:
        """Bulk-write pre-validated memory dicts for ``agent_id``.

        Generates fresh IDs for each memory. Embeddings are expected to
        be handled by the caller (agent layer) via ``re_embed`` flag.
        """
        db = self._db()
        created_ids: list[str] = []
        now = _now_iso()

        for mem in memories:
            memory_id = _gen_id()
            content_str = json.dumps(mem["content"], default=str)
            source_ids_str = json.dumps(mem.get("source_ids", []))

            # Re-embed if the caller attached an embedding
            embedding: bytes | None = None
            raw_embedding = mem.get("_embedding")
            if raw_embedding is not None:
                embedding = _pack_embedding(raw_embedding)

            db.execute(
                """INSERT INTO memories
                   (id, agent_id, tier, event_type, content, salience,
                    emotional_intensity, embedding, embedding_model_id,
                    embedding_dim, source_ids, session_id, scope, ttl_hours,
                    dedup_of, cycle_id, created_at, updated_at, accessed_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    memory_id,
                    agent_id,
                    mem.get("tier", "raw"),
                    mem["event_type"],
                    content_str,
                    mem.get("salience", 0.5),
                    mem.get("emotional_intensity", 0.0),
                    embedding,
                    self._embedding_model_id if embedding else "",
                    self._embedding_dim if embedding else 0,
                    source_ids_str,
                    mem.get("session_id"),
                    mem.get("scope", "long_term"),
                    mem.get("ttl_hours", 0),
                    None,  # dedup_of — not imported
                    None,  # cycle_id — not imported
                    mem.get("created_at") or now,
                    now,
                    now,
                ),
            )
            created_ids.append(memory_id)

        db.commit()
        logger.info(
            "Memories imported",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "count": len(created_ids),
            },
        )
        return created_ids

    async def reinforce_memories(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> None:
        """Increment reinforcement_count and nudge salience for retrieved memories.

        Best-effort background write — callers should fire-and-forget.
        Scoped to ``agent_id``; IDs belonging to other agents are silently
        skipped (no error, no update).

        Concurrency note: Each UPDATE is atomic per-row (SQLite guarantees
        row-level atomicity within a single connection). The ``MIN(... + 0.05, 1.0)``
        expression is evaluated server-side, so concurrent calls nudge
        independently and the cap holds. However, the per-ID loop means
        high-frequency concurrent callers may generate write amplification.

        TODO(Slice 3): Consider batching reinforcement calls (collect IDs
        over a short window, flush once) to reduce commit frequency under
        high search throughput.
        """
        if not memory_ids:
            return
        db = self._db()
        now = _now_iso()
        for mid in memory_ids:
            db.execute(
                """UPDATE memories
                   SET salience = MIN(salience + 0.05, 1.0),
                       reinforcement_count = reinforcement_count + 1,
                       accessed_at = ?
                   WHERE id = ? AND agent_id = ?""",
                (now, mid, agent_id),
            )
        db.commit()
        logger.info(
            "Memories reinforced",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "memory_count": len(memory_ids),
            },
        )

    async def delete_memory(
        self,
        *,
        agent_id: str,
        memory_id: str,
    ) -> int:
        """Hard-delete a single memory row by id.

        Returns:
            Number of rows deleted (0 or 1). Idempotent — unknown id returns 0.
        """
        db = self._db()
        cursor = db.execute(
            "DELETE FROM memories WHERE id = ? AND agent_id = ?",
            (memory_id, agent_id),
        )
        db.commit()
        deleted = cursor.rowcount
        logger.info(
            "Memory deleted",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "memory_id": memory_id,
                "deleted": deleted,
            },
        )
        return deleted

    async def delete_session_memories(
        self,
        *,
        agent_id: str,
        session_id: str,
    ) -> int:
        """Hard-delete every memory tagged with ``session_id``.

        Returns:
            Number of rows deleted. Idempotent — unknown session returns 0.
        """
        db = self._db()
        cursor = db.execute(
            "DELETE FROM memories WHERE agent_id = ? AND session_id = ?",
            (agent_id, session_id),
        )
        db.commit()
        deleted = cursor.rowcount
        logger.info(
            "Session memories deleted",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "session_id": session_id,
                "deleted": deleted,
            },
        )
        return deleted

    async def delete_all_for_agent(
        self,
        *,
        agent_id: str,
    ) -> dict[str, int]:
        """Full erasure of all data for ``agent_id``.

        Deletes from ``memories``, ``directives``, ``directive_proposals``,
        ``dream_reports``, ``journals``. Returns per-table delete counts.
        """
        db = self._db()
        tables = [
            "memories",
            "directives",
            "directive_proposals",
            "dream_reports",
            "journals",
        ]
        counts: dict[str, int] = {}
        for table in tables:
            cursor = db.execute(
                f"DELETE FROM {table} WHERE agent_id = ?",  # noqa: S608
                (agent_id,),
            )
            counts[table] = cursor.rowcount
        db.commit()
        logger.info(
            "All agent data deleted",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "per_table": counts,
            },
        )
        return counts

    async def delete_all_memories(
        self,
        *,
        agent_id: str,
    ) -> int:
        db = self._db()
        cursor = db.execute(
            "DELETE FROM memories WHERE agent_id = ?",
            (agent_id,),
        )
        db.commit()
        count = cursor.rowcount
        logger.info(
            "All memories deleted",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "count": count,
            },
        )
        return count

    async def clone_agent(
        self,
        *,
        src_agent_id: str,
        tgt_agent_id: str,
        tgt_backend: BaseBackend | None = None,
    ) -> dict[str, int]:
        """Copy ``src_agent_id``'s memories and directives to ``tgt_agent_id``.

        When ``tgt_backend`` is set, delegates to the cross-backend
        export/import path. Otherwise uses the optimized single-transaction
        same-backend clone.
        """
        if not src_agent_id or not tgt_agent_id:
            msg = "clone_agent requires non-empty src_agent_id and tgt_agent_id"
            raise ValueError(msg)
        if src_agent_id == tgt_agent_id and tgt_backend is None:
            msg = (
                f"clone_agent refuses to clone onto the same agent_id "
                f"({src_agent_id!r}) — source and target must differ."
            )
            raise ValueError(msg)

        if tgt_backend is not None:
            return await self._cross_backend_clone(
                src_agent_id=src_agent_id,
                tgt_agent_id=tgt_agent_id,
                tgt_backend=tgt_backend,
            )

        db = self._db()

        existing_memories = db.execute(
            "SELECT COUNT(*) AS n FROM memories WHERE agent_id = ?",
            (tgt_agent_id,),
        ).fetchone()["n"]
        existing_directives = db.execute(
            "SELECT COUNT(*) AS n FROM directives WHERE agent_id = ?",
            (tgt_agent_id,),
        ).fetchone()["n"]
        if existing_memories or existing_directives:
            msg = (
                f"clone_agent refuses to overwrite target {tgt_agent_id!r}: "
                f"it already has {existing_memories} memory rows and "
                f"{existing_directives} directive rows. Delete them first "
                f"or pick a fresh agent_id."
            )
            raise ValueError(msg)

        try:
            db.execute("BEGIN")

            memory_rows = db.execute(
                """SELECT id, tier, event_type, content, metadata, salience,
                          reinforcement_count, emotional_intensity, embedding,
                          embedding_model_id, embedding_dim, source_ids,
                          session_id, scope, ttl_hours, dedup_of, cycle_id,
                          archived_at, created_at, updated_at, accessed_at
                   FROM memories
                   WHERE agent_id = ?""",
                (src_agent_id,),
            ).fetchall()
            id_map: dict[str, str] = {row["id"]: _gen_id() for row in memory_rows}

            for row in memory_rows:
                new_id = id_map[row["id"]]
                raw_sources = json.loads(row["source_ids"] or "[]")
                rewritten_sources = [
                    id_map[s] for s in raw_sources if s in id_map
                ]
                dedup_of = row["dedup_of"]
                rewritten_dedup = id_map.get(dedup_of) if dedup_of else None
                db.execute(
                    """INSERT INTO memories
                       (id, agent_id, tier, event_type, content, metadata,
                        salience, reinforcement_count, emotional_intensity,
                        embedding, embedding_model_id, embedding_dim,
                        source_ids, session_id, scope, ttl_hours, dedup_of,
                        cycle_id, archived_at, created_at, updated_at,
                        accessed_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                               ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        new_id,
                        tgt_agent_id,
                        row["tier"],
                        row["event_type"],
                        row["content"],
                        row["metadata"],
                        row["salience"],
                        row["reinforcement_count"],
                        row["emotional_intensity"],
                        row["embedding"],
                        row["embedding_model_id"],
                        row["embedding_dim"],
                        json.dumps(rewritten_sources),
                        row["session_id"],
                        row["scope"],
                        row["ttl_hours"],
                        rewritten_dedup,
                        # cycle_id cleared: dream_reports aren't cloned in v0.4.
                        None,
                        row["archived_at"],
                        row["created_at"],
                        row["updated_at"],
                        row["accessed_at"],
                    ),
                )

            directive_rows = db.execute(
                """SELECT id, text, content_hash, status, priority, usage_count,
                          embedding, embedding_model_id, embedding_dim,
                          created_at, updated_at, last_used, promoted_at
                   FROM directives
                   WHERE agent_id = ?""",
                (src_agent_id,),
            ).fetchall()

            for row in directive_rows:
                db.execute(
                    """INSERT INTO directives
                       (id, agent_id, text, content_hash, status, priority,
                        usage_count, embedding, embedding_model_id,
                        embedding_dim, created_at, updated_at, last_used,
                        promoted_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        _gen_id(),
                        tgt_agent_id,
                        row["text"],
                        row["content_hash"],
                        row["status"],
                        row["priority"],
                        row["usage_count"],
                        row["embedding"],
                        row["embedding_model_id"],
                        row["embedding_dim"],
                        row["created_at"],
                        row["updated_at"],
                        row["last_used"],
                        row["promoted_at"],
                    ),
                )

            db.commit()
        except Exception:
            db.rollback()
            raise

        counts = {"memories": len(memory_rows), "directives": len(directive_rows)}
        logger.info(
            "Agent cloned",
            extra={
                "subsystem": "storage.sqlite",
                "src_agent_id": src_agent_id,
                "tgt_agent_id": tgt_agent_id,
                "per_table": counts,
            },
        )
        return counts

    # --- Dream checkpointing ---

    async def save_dream_checkpoint(
        self,
        *,
        cycle_id: str,
        agent_id: str,
        last_completed_phase: str,
        state_blob: str,
        created_at: str,
    ) -> None:
        db = self._db()
        db.execute(
            """INSERT OR REPLACE INTO dream_cycle_checkpoints
               (cycle_id, agent_id, last_completed_phase, state_blob, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (cycle_id, agent_id, last_completed_phase, state_blob, created_at),
        )
        db.commit()

    async def load_dream_checkpoint(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        db = self._db()
        row = db.execute(
            """SELECT cycle_id, last_completed_phase, state_blob, created_at
               FROM dream_cycle_checkpoints
               WHERE agent_id = ?
               ORDER BY created_at DESC
               LIMIT 1""",
            (agent_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "cycle_id": row["cycle_id"],
            "last_completed_phase": row["last_completed_phase"],
            "state_blob": row["state_blob"],
            "created_at": row["created_at"],
        }

    async def delete_dream_checkpoint(
        self,
        *,
        cycle_id: str,
        agent_id: str,
    ) -> None:
        db = self._db()
        db.execute(
            "DELETE FROM dream_cycle_checkpoints WHERE cycle_id = ? AND agent_id = ?",
            (cycle_id, agent_id),
        )
        db.commit()

    # --- Dream scheduling ---

    async def save_scheduled_dream(
        self,
        *,
        agent_id: str,
        interval_hours: float,
        at_time: str | None,
        paused: bool,
        ignore_budget: bool,
        next_run: str,
        last_run: str | None,
        created_at: str,
        updated_at: str,
    ) -> None:
        db = self._db()
        db.execute(
            """INSERT INTO scheduled_dreams
                   (agent_id, interval_hours, at_time, paused, ignore_budget,
                    next_run, last_run, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(agent_id) DO UPDATE SET
                   interval_hours=excluded.interval_hours,
                   at_time=excluded.at_time,
                   paused=excluded.paused,
                   ignore_budget=excluded.ignore_budget,
                   next_run=excluded.next_run,
                   last_run=excluded.last_run,
                   updated_at=excluded.updated_at""",
            (
                agent_id,
                interval_hours,
                at_time,
                1 if paused else 0,
                1 if ignore_budget else 0,
                next_run,
                last_run,
                created_at,
                updated_at,
            ),
        )
        db.commit()

    async def load_scheduled_dream(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        row = self._db().execute(
            """SELECT agent_id, interval_hours, at_time, paused, ignore_budget,
                      next_run, last_run, created_at, updated_at
               FROM scheduled_dreams
               WHERE agent_id = ?""",
            (agent_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "agent_id": row["agent_id"],
            "interval_hours": row["interval_hours"],
            "at_time": row["at_time"],
            "paused": bool(row["paused"]),
            "ignore_budget": bool(row["ignore_budget"]),
            "next_run": row["next_run"],
            "last_run": row["last_run"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    async def delete_scheduled_dream(
        self,
        *,
        agent_id: str,
    ) -> None:
        db = self._db()
        db.execute(
            "DELETE FROM scheduled_dreams WHERE agent_id = ?",
            (agent_id,),
        )
        db.commit()

    # --- Provenance event log (append-only) ---

    async def append_provenance_event(
        self,
        *,
        event_id: str,
        agent_id: str,
        event_type: str,
        entity_type: str,
        entity_id: str,
        parent_event_id: str | None,
        payload: dict[str, Any],
        created_at: str,
    ) -> None:
        """Append one row to ``provenance_events``. Append-only by contract."""
        db = self._db()
        db.execute(
            """INSERT INTO provenance_events
               (event_id, agent_id, event_type, entity_type, entity_id,
                parent_event_id, payload, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                event_id,
                agent_id,
                event_type,
                entity_type,
                entity_id,
                parent_event_id,
                json.dumps(payload, default=str),
                created_at,
            ),
        )
        db.commit()

    async def query_provenance_events_by_entity(
        self,
        *,
        agent_id: str,
        entity_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        db = self._db()
        cursor = db.execute(
            """SELECT event_id, agent_id, event_type, entity_type, entity_id,
                      parent_event_id, payload, created_at
               FROM provenance_events
               WHERE agent_id = ? AND entity_id = ?
               ORDER BY created_at ASC, event_id ASC
               LIMIT ?""",
            (agent_id, entity_id, limit),
        )
        return [self._row_to_provenance_event(row) for row in cursor.fetchall()]

    async def query_provenance_events_by_time(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        db = self._db()
        clauses = ["agent_id = ?"]
        params: list[Any] = [agent_id]
        if since is not None:
            clauses.append("created_at >= ?")
            params.append(since)
        if until is not None:
            clauses.append("created_at <= ?")
            params.append(until)
        where = " AND ".join(clauses)
        params.append(limit)
        cursor = db.execute(
            f"""SELECT event_id, agent_id, event_type, entity_type, entity_id,
                       parent_event_id, payload, created_at
                FROM provenance_events
                WHERE {where}
                ORDER BY created_at ASC, event_id ASC
                LIMIT ?""",  # noqa: S608 — `where` is built from a fixed allowlist
            params,
        )
        return [self._row_to_provenance_event(row) for row in cursor.fetchall()]

    async def get_provenance_event(
        self,
        *,
        agent_id: str,
        event_id: str,
    ) -> dict[str, Any] | None:
        db = self._db()
        cursor = db.execute(
            """SELECT event_id, agent_id, event_type, entity_type, entity_id,
                      parent_event_id, payload, created_at
               FROM provenance_events
               WHERE agent_id = ? AND event_id = ?""",
            (agent_id, event_id),
        )
        row = cursor.fetchone()
        if row is None:
            return None
        return self._row_to_provenance_event(row)

    @staticmethod
    def _row_to_provenance_event(row: Any) -> dict[str, Any]:
        # sqlite3.Row.__contains__ checks values, not column names — use
        # row.keys() for the membership test. Every SELECT in this file
        # includes ``payload``, so the guard is defensive only.
        raw_payload = row["payload"] if "payload" in row.keys() else "{}"  # noqa: SIM118
        try:
            payload = json.loads(raw_payload) if raw_payload else {}
        except json.JSONDecodeError:
            payload = {"_decode_error": True, "raw": raw_payload}
        return {
            "event_id": row["event_id"],
            "agent_id": row["agent_id"],
            "event_type": row["event_type"],
            "entity_type": row["entity_type"],
            "entity_id": row["entity_id"],
            "parent_event_id": row["parent_event_id"],
            "payload": payload,
            "created_at": row["created_at"],
        }

    # --- Directives ---

    async def store_directive(
        self,
        *,
        agent_id: str,
        directive_id: str,
        text: str,
        content_hash: str,
        status: str = "provisional",
        embedding: list[float] | None = None,
    ) -> str:
        """Store a new directive row with optional embedding."""
        db = self._db()
        now = _now_iso()

        packed_embedding: bytes | None = None
        emb_model = ""
        emb_dim = 0
        if embedding is not None:
            packed_embedding = _pack_embedding(embedding)
            emb_model = self._embedding_model_id
            emb_dim = self._embedding_dim

        db.execute(
            """INSERT INTO directives
               (id, agent_id, text, content_hash, status, priority,
                usage_count, embedding, embedding_model_id, embedding_dim,
                created_at, updated_at, last_used, promoted_at)
               VALUES (?, ?, ?, ?, ?, 'contextual', 0, ?, ?, ?, ?, ?, NULL, NULL)""",
            (
                directive_id,
                agent_id,
                text,
                content_hash,
                status,
                packed_embedding,
                emb_model,
                emb_dim,
                now,
                now,
            ),
        )
        db.commit()

        logger.info(
            "Directive stored",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "directive_id": directive_id,
                "status": status,
                "has_embedding": packed_embedding is not None,
            },
        )
        return directive_id

    async def get_directive(
        self,
        *,
        agent_id: str,
        directive_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single directive by ID, scoped to ``agent_id``."""
        db = self._db()
        row = db.execute(
            """SELECT id, agent_id, text, content_hash, status, priority,
                      usage_count, created_at, updated_at, last_used, promoted_at
               FROM directives
               WHERE id = ? AND agent_id = ?""",
            (directive_id, agent_id),
        ).fetchone()
        if row is None:
            return None
        return dict(row)

    async def list_directives(
        self,
        *,
        agent_id: str,
        include_inactive: bool = False,
    ) -> list[dict[str, Any]]:
        """List directives for ``agent_id``."""
        db = self._db()
        if include_inactive:
            rows = db.execute(
                """SELECT id, agent_id, text, content_hash, status, priority,
                          usage_count, created_at, updated_at, last_used, promoted_at
                   FROM directives
                   WHERE agent_id = ?
                   ORDER BY created_at""",
                (agent_id,),
            ).fetchall()
        else:
            rows = db.execute(
                """SELECT id, agent_id, text, content_hash, status, priority,
                          usage_count, created_at, updated_at, last_used, promoted_at
                   FROM directives
                   WHERE agent_id = ? AND status != 'inactive'
                   ORDER BY created_at""",
                (agent_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    async def count_active_directives(self, *, agent_id: str) -> int:
        """Count non-inactive directives for ``agent_id``."""
        db = self._db()
        row = db.execute(
            """SELECT COUNT(*) as n FROM directives
               WHERE agent_id = ? AND status != 'inactive'""",
            (agent_id,),
        ).fetchone()
        return int(row["n"])

    async def update_directive_status(
        self,
        *,
        agent_id: str,
        directive_id: str,
        new_status: str,
        promoted_at: str | None = None,
    ) -> bool:
        """Update the status of a directive."""
        db = self._db()
        now = _now_iso()
        if promoted_at:
            cursor = db.execute(
                """UPDATE directives
                   SET status = ?, promoted_at = ?, updated_at = ?
                   WHERE id = ? AND agent_id = ?""",
                (new_status, promoted_at, now, directive_id, agent_id),
            )
        else:
            cursor = db.execute(
                """UPDATE directives
                   SET status = ?, updated_at = ?
                   WHERE id = ? AND agent_id = ?""",
                (new_status, now, directive_id, agent_id),
            )
        db.commit()
        return cursor.rowcount > 0

    async def find_similar_directive(
        self,
        *,
        agent_id: str,
        embedding: list[float],
        threshold: float = 0.95,
    ) -> tuple[str | None, float]:
        """Find the most similar non-inactive directive."""
        db = self._db()
        rows = db.execute(
            """SELECT id, embedding
               FROM directives
               WHERE agent_id = ?
                 AND status != 'inactive'
                 AND embedding IS NOT NULL
                 AND embedding_model_id = ?
                 AND embedding_dim = ?""",
            (agent_id, self._embedding_model_id, self._embedding_dim),
        ).fetchall()

        best_id: str | None = None
        best_sim = 0.0
        for row in rows:
            dir_vec = _unpack_embedding(row["embedding"])
            sim = _cosine_similarity(embedding, dir_vec)
            if sim >= threshold and sim > best_sim:
                best_sim = sim
                best_id = row["id"]

        return (best_id, round(best_sim, 4))

    async def run_directive_decay(
        self,
        *,
        agent_id: str,
        usage_threshold: int,
        age_days: int,
    ) -> dict[str, Any]:
        """Deactivate low-usage, old directives. Permanent are exempt."""
        db = self._db()
        now = _now_iso()
        now_dt = datetime.fromisoformat(now)

        rows = db.execute(
            """SELECT id, usage_count, created_at
               FROM directives
               WHERE agent_id = ?
                 AND status IN ('provisional', 'active')""",
            (agent_id,),
        ).fetchall()

        deactivated_ids: list[str] = []
        for row in rows:
            created_dt = datetime.fromisoformat(row["created_at"])
            # Normalize tz: if stored timestamp is naive, treat as UTC
            if created_dt.tzinfo is None:
                created_dt = created_dt.replace(tzinfo=timezone.utc)  # noqa: UP017
            age = (now_dt - created_dt).total_seconds() / 86_400.0
            if row["usage_count"] < usage_threshold and age > age_days:
                deactivated_ids.append(row["id"])

        if deactivated_ids:
            placeholders = ",".join("?" for _ in deactivated_ids)
            db.execute(
                f"UPDATE directives SET status = 'inactive', updated_at = ? "  # noqa: S608
                f"WHERE id IN ({placeholders})",
                [now, *deactivated_ids],
            )
            db.commit()

        logger.info(
            "Directive decay completed",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "deactivated_count": len(deactivated_ids),
            },
        )
        return {
            "deactivated_count": len(deactivated_ids),
            "deactivated_ids": deactivated_ids,
        }

    async def increment_directive_usage(
        self,
        *,
        agent_id: str,
        directive_ids: list[str],
    ) -> None:
        """Increment ``usage_count`` for the given directives."""
        if not directive_ids:
            return
        db = self._db()
        now = _now_iso()
        for did in directive_ids:
            db.execute(
                """UPDATE directives
                   SET usage_count = usage_count + 1,
                       last_used = ?,
                       updated_at = ?
                   WHERE id = ? AND agent_id = ?""",
                (now, now, did, agent_id),
            )
        db.commit()

    async def export_directives(
        self,
        *,
        agent_id: str,
        include_inactive: bool = True,
    ) -> list[dict[str, Any]]:
        """Export all directives for ``agent_id`` as portable dicts.

        No embedding blobs or DB-internal indexes.
        """
        db = self._db()
        inactive_filter = "" if include_inactive else "AND status != 'inactive'"
        rows = db.execute(
            f"""SELECT id, text, content_hash, status, priority,
                       usage_count, created_at, updated_at,
                       last_used, promoted_at
                FROM directives
                WHERE agent_id = ?
                {inactive_filter}
                ORDER BY created_at ASC""",  # noqa: S608
            (agent_id,),
        ).fetchall()

        exported: list[dict[str, Any]] = []
        for row in rows:
            exported.append({
                "id": row["id"],
                "text": row["text"],
                "content_hash": row["content_hash"],
                "status": row["status"],
                "priority": row["priority"],
                "usage_count": row["usage_count"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "last_used": row["last_used"],
                "promoted_at": row["promoted_at"],
            })

        logger.info(
            "Directives exported",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "count": len(exported),
                "include_inactive": include_inactive,
            },
        )
        return exported

    async def import_directives(
        self,
        *,
        agent_id: str,
        directives: list[dict[str, Any]],
    ) -> list[str]:
        """Bulk-write pre-validated directive dicts for ``agent_id``.

        All imported directives get fresh IDs and ``status='provisional'``.
        """
        db = self._db()
        created_ids: list[str] = []
        now = _now_iso()

        for d in directives:
            directive_id = _gen_id()

            # Re-embed if the caller attached an embedding
            packed_emb: bytes | None = None
            raw_embedding = d.get("_embedding")
            emb_model = ""
            emb_dim = 0
            if raw_embedding is not None:
                packed_emb = _pack_embedding(raw_embedding)
                emb_model = self._embedding_model_id
                emb_dim = self._embedding_dim

            db.execute(
                """INSERT INTO directives
                   (id, agent_id, text, content_hash, status, priority,
                    usage_count, embedding, embedding_model_id, embedding_dim,
                    created_at, updated_at, last_used, promoted_at)
                   VALUES (?, ?, ?, ?, 'provisional', ?, 0,
                           ?, ?, ?,
                           ?, ?, NULL, NULL)""",
                (
                    directive_id,
                    agent_id,
                    d["text"],
                    d["content_hash"],
                    d.get("priority", "contextual"),
                    packed_emb,
                    emb_model,
                    emb_dim,
                    d.get("created_at") or now,
                    now,
                ),
            )
            created_ids.append(directive_id)

        db.commit()
        logger.info(
            "Directives imported",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "count": len(created_ids),
            },
        )
        return created_ids

    async def reset_directives(
        self,
        *,
        agent_id: str,
    ) -> dict[str, int]:
        """Delete all directives and proposals for ``agent_id``.

        Atomic — both tables cleared in a single transaction.
        """
        db = self._db()
        d_cursor = db.execute(
            "DELETE FROM directives WHERE agent_id = ?",
            (agent_id,),
        )
        p_cursor = db.execute(
            "DELETE FROM directive_proposals WHERE agent_id = ?",
            (agent_id,),
        )
        counts = {
            "directives": d_cursor.rowcount,
            "directive_proposals": p_cursor.rowcount,
        }
        db.commit()
        logger.info(
            "Directives and proposals reset",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "per_table": counts,
            },
        )
        return counts

    # --- Proposals ---

    async def store_proposal(
        self,
        *,
        agent_id: str,
        proposal_id: str,
        action: str,
        text: str,
        content_hash: str,
        proposed_status: str,
        target_directive_id: str | None = None,
        reasoning: str = "",
    ) -> str:
        """Store a new directive proposal."""
        db = self._db()
        now = _now_iso()

        db.execute(
            """INSERT INTO directive_proposals
               (id, agent_id, action, text, reasoning, confidence,
                status, source_memory_ids, content_hash,
                proposed_status, target_directive_id,
                created_at, resolved_at, resolved_by)
               VALUES (?, ?, ?, ?, ?, 1.0,
                       'pending', '[]', ?,
                       ?, ?,
                       ?, NULL, NULL)""",
            (
                proposal_id,
                agent_id,
                action,
                text,
                reasoning,
                content_hash,
                proposed_status,
                target_directive_id,
                now,
            ),
        )
        db.commit()

        logger.info(
            "Directive proposal stored",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "proposal_id": proposal_id,
                "action": action,
            },
        )
        return proposal_id

    async def get_proposal(
        self,
        *,
        agent_id: str,
        proposal_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single proposal by ID, scoped to ``agent_id``."""
        db = self._db()
        row = db.execute(
            """SELECT * FROM directive_proposals
               WHERE id = ? AND agent_id = ?""",
            (proposal_id, agent_id),
        ).fetchone()
        if row is None:
            return None
        return dict(row)

    async def list_proposals(self, *, agent_id: str) -> list[dict[str, Any]]:
        """List pending directive proposals for ``agent_id``."""
        db = self._db()
        rows = db.execute(
            """SELECT * FROM directive_proposals
               WHERE agent_id = ? AND status = 'pending'
               ORDER BY created_at""",
            (agent_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    async def approve_proposal(
        self,
        proposal_id: str,
        *,
        agent_id: str,
        directive_id: str,
        embedding: list[float] | None = None,
        resolved_by: str = "",
    ) -> dict[str, Any]:
        """Approve a directive proposal atomically.

        Validates → executes → marks resolved in one transaction.

        Raises:
            ValueError: If the proposal does not exist, is already
                resolved, or the target directive is in an invalid state.
        """
        db = self._db()
        now = _now_iso()

        row = db.execute(
            """SELECT * FROM directive_proposals
               WHERE id = ? AND agent_id = ?""",
            (proposal_id, agent_id),
        ).fetchone()

        if row is None:
            msg = f"Proposal {proposal_id} not found for agent {agent_id}"
            raise ValueError(msg)

        if row["status"] != "pending":
            msg = (
                f"Proposal {proposal_id} is already resolved "
                f"(status='{row['status']}')"
            )
            raise ValueError(msg)

        action = row["action"]
        result: dict[str, Any]

        if action == "add":
            packed_emb = _pack_embedding(embedding) if embedding else None
            emb_model = self._embedding_model_id if embedding else ""
            emb_dim = self._embedding_dim if embedding else 0

            db.execute(
                """INSERT INTO directives
                   (id, agent_id, text, content_hash, status, priority,
                    usage_count, embedding, embedding_model_id, embedding_dim,
                    created_at, updated_at, last_used, promoted_at)
                   VALUES (?, ?, ?, ?, ?, 'contextual', 0,
                           ?, ?, ?,
                           ?, ?, NULL, NULL)""",
                (
                    directive_id,
                    agent_id,
                    row["text"],
                    row["content_hash"],
                    row["proposed_status"],
                    packed_emb,
                    emb_model,
                    emb_dim,
                    now,
                    now,
                ),
            )
            result = {
                "action": "add",
                "directive_id": directive_id,
                "status": row["proposed_status"],
            }

        elif action == "promote":
            target_id = row["target_directive_id"]
            if not target_id:
                msg = f"Proposal {proposal_id} has no target_directive_id"
                raise ValueError(msg)

            target = db.execute(
                """SELECT id, status FROM directives
                   WHERE id = ? AND agent_id = ?""",
                (target_id, agent_id),
            ).fetchone()

            if target is None:
                # Target directive was deleted — mark proposal stale
                db.execute(
                    """UPDATE directive_proposals
                       SET status = 'rejected', resolved_at = ?,
                           resolved_by = ?
                       WHERE id = ? AND agent_id = ?""",
                    (
                        now,
                        '{"actor":"system","method":"stale","reason":"target_missing"}',
                        proposal_id,
                        agent_id,
                    ),
                )
                db.commit()
                msg = (
                    f"Target directive '{target_id}' no longer exists. "
                    f"Proposal marked stale."
                )
                raise ValueError(msg)

            new_status = row["proposed_status"]
            promoted_at = now if new_status == "permanent" else None
            if promoted_at:
                db.execute(
                    """UPDATE directives
                       SET status = ?, promoted_at = ?, updated_at = ?
                       WHERE id = ? AND agent_id = ?""",
                    (new_status, promoted_at, now, target_id, agent_id),
                )
            else:
                db.execute(
                    """UPDATE directives
                       SET status = ?, updated_at = ?
                       WHERE id = ? AND agent_id = ?""",
                    (new_status, now, target_id, agent_id),
                )
            result = {
                "action": "promote",
                "directive_id": target_id,
                "status": new_status,
            }

        elif action == "deactivate":
            target_id = row["target_directive_id"]
            if not target_id:
                msg = f"Proposal {proposal_id} has no target_directive_id"
                raise ValueError(msg)

            target = db.execute(
                """SELECT id, status FROM directives
                   WHERE id = ? AND agent_id = ?""",
                (target_id, agent_id),
            ).fetchone()

            if target is None:
                db.execute(
                    """UPDATE directive_proposals
                       SET status = 'rejected', resolved_at = ?,
                           resolved_by = ?
                       WHERE id = ? AND agent_id = ?""",
                    (
                        now,
                        '{"actor":"system","method":"stale","reason":"target_missing"}',
                        proposal_id,
                        agent_id,
                    ),
                )
                db.commit()
                msg = (
                    f"Target directive '{target_id}' no longer exists. "
                    f"Proposal marked stale."
                )
                raise ValueError(msg)

            if target["status"] == "inactive":
                db.execute(
                    """UPDATE directive_proposals
                       SET status = 'rejected', resolved_at = ?,
                           resolved_by = ?
                       WHERE id = ? AND agent_id = ?""",
                    (
                        now,
                        '{"actor":"system","method":"stale","reason":"already_inactive"}',
                        proposal_id,
                        agent_id,
                    ),
                )
                db.commit()
                msg = (
                    f"Target directive '{target_id}' is already inactive. "
                    f"Proposal marked stale."
                )
                raise ValueError(msg)

            db.execute(
                """UPDATE directives
                   SET status = 'inactive', updated_at = ?
                   WHERE id = ? AND agent_id = ?""",
                (now, target_id, agent_id),
            )
            result = {
                "action": "deactivate",
                "directive_id": target_id,
                "status": "inactive",
            }

        else:
            msg = f"Unknown proposal action: '{action}'"
            raise ValueError(msg)

        # Mark proposal resolved (same transaction)
        db.execute(
            """UPDATE directive_proposals
               SET status = 'approved', resolved_at = ?,
                   resolved_by = ?
               WHERE id = ? AND agent_id = ?""",
            (now, resolved_by or '{"actor":"operator","method":"manual"}',
             proposal_id, agent_id),
        )
        db.commit()

        logger.info(
            "Directive proposal approved",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "proposal_id": proposal_id,
                "action": action,
            },
        )
        return result

    async def reject_proposal(
        self,
        proposal_id: str,
        *,
        agent_id: str,
        reason: str = "",
        resolved_by: str = "",
    ) -> None:
        """Reject a directive proposal.

        Raises:
            ValueError: If the proposal does not exist or is already resolved.
        """
        db = self._db()
        now = _now_iso()

        row = db.execute(
            """SELECT id, status FROM directive_proposals
               WHERE id = ? AND agent_id = ?""",
            (proposal_id, agent_id),
        ).fetchone()
        if row is None:
            msg = f"Proposal {proposal_id} not found for agent {agent_id}"
            raise ValueError(msg)

        if row["status"] != "pending":
            msg = (
                f"Proposal {proposal_id} is already resolved "
                f"(status='{row['status']}')"
            )
            raise ValueError(msg)

        db.execute(
            """UPDATE directive_proposals
               SET status = 'rejected', resolved_at = ?,
                   resolved_by = ?
               WHERE id = ? AND agent_id = ?""",
            (now, resolved_by or f'{{"actor":"operator","method":"manual","reason":"{reason}"}}',
             proposal_id, agent_id),
        )
        db.commit()

    # --- Critic reviews ---

    async def store_review(
        self,
        *,
        agent_id: str,
        review_id: str,
        output_text: str,
        context: dict[str, Any] | None,
        risk_level: str,
        flags: list[str],
        rationale: str,
        pass_through: bool,
        directive_ids: list[str],
        created_at: str,
    ) -> None:
        """Persist a critic review for ``agent_id``."""
        db = self._db()
        db.execute(
            """INSERT INTO critic_reviews
               (id, agent_id, output_text, context_json, risk_level,
                flags_json, rationale, pass_through, directive_ids_json,
                created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                review_id,
                agent_id,
                output_text,
                json.dumps(context) if context is not None else None,
                risk_level,
                json.dumps(flags),
                rationale,
                1 if pass_through else 0,
                json.dumps(directive_ids),
                created_at,
            ),
        )
        db.commit()
        logger.info(
            "Critic review stored",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "review_id": review_id,
                "risk_level": risk_level,
            },
        )

    async def get_reviews(
        self,
        *,
        agent_id: str,
        limit: int = 20,
        risk_level: str | None = None,
    ) -> list[dict[str, Any]]:
        """Query stored critic reviews, most recent first."""
        db = self._db()
        if risk_level is not None:
            rows = db.execute(
                """SELECT id, agent_id, output_text, context_json,
                          risk_level, flags_json, rationale, pass_through,
                          directive_ids_json, created_at
                   FROM critic_reviews
                   WHERE agent_id = ? AND risk_level = ?
                   ORDER BY created_at DESC LIMIT ?""",
                (agent_id, risk_level, limit),
            ).fetchall()
        else:
            rows = db.execute(
                """SELECT id, agent_id, output_text, context_json,
                          risk_level, flags_json, rationale, pass_through,
                          directive_ids_json, created_at
                   FROM critic_reviews
                   WHERE agent_id = ?
                   ORDER BY created_at DESC LIMIT ?""",
                (agent_id, limit),
            ).fetchall()

        results: list[dict[str, Any]] = []
        for row in rows:
            results.append({
                "id": row["id"],
                "agent_id": row["agent_id"],
                "output_text": row["output_text"],
                "context": json.loads(row["context_json"])
                if row["context_json"] is not None
                else None,
                "risk_level": row["risk_level"],
                "flags": json.loads(row["flags_json"]),
                "rationale": row["rationale"],
                "pass_through": bool(row["pass_through"]),
                "directive_ids": json.loads(row["directive_ids_json"]),
                "created_at": row["created_at"],
            })
        return results

    async def get_review(
        self,
        review_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single critic review by ID."""
        db = self._db()
        row = db.execute(
            """SELECT id, agent_id, output_text, context_json,
                      risk_level, flags_json, rationale, pass_through,
                      directive_ids_json, created_at
               FROM critic_reviews
               WHERE id = ? AND agent_id = ?""",
            (review_id, agent_id),
        ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "agent_id": row["agent_id"],
            "output_text": row["output_text"],
            "context": json.loads(row["context_json"])
            if row["context_json"] is not None
            else None,
            "risk_level": row["risk_level"],
            "flags": json.loads(row["flags_json"]),
            "rationale": row["rationale"],
            "pass_through": bool(row["pass_through"]),
            "directive_ids": json.loads(row["directive_ids_json"]),
            "created_at": row["created_at"],
        }

    # --- Critic audits ---

    async def store_audit(
        self,
        *,
        agent_id: str,
        audit_id: str,
        coherence_score: float,
        is_coherent: bool,
        contradictions: list[dict[str, str]],
        summary: str,
        directive_ids: list[str],
        directive_count: int,
        created_at: str,
    ) -> None:
        """Persist a coherence audit for ``agent_id``."""
        db = self._db()
        db.execute(
            """INSERT INTO critic_audits
               (id, agent_id, coherence_score, is_coherent,
                contradictions_json, summary, directive_ids_json,
                directive_count, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                audit_id,
                agent_id,
                coherence_score,
                1 if is_coherent else 0,
                json.dumps(contradictions),
                summary,
                json.dumps(directive_ids),
                directive_count,
                created_at,
            ),
        )
        db.commit()
        logger.info(
            "Coherence audit stored",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "audit_id": audit_id,
                "coherence_score": coherence_score,
            },
        )

    async def get_audits(
        self,
        *,
        agent_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Query stored coherence audits, most recent first."""
        db = self._db()
        rows = db.execute(
            """SELECT id, agent_id, coherence_score, is_coherent,
                      contradictions_json, summary, directive_ids_json,
                      directive_count, created_at
               FROM critic_audits
               WHERE agent_id = ?
               ORDER BY created_at DESC LIMIT ?""",
            (agent_id, limit),
        ).fetchall()

        results: list[dict[str, Any]] = []
        for row in rows:
            results.append({
                "id": row["id"],
                "agent_id": row["agent_id"],
                "coherence_score": row["coherence_score"],
                "is_coherent": bool(row["is_coherent"]),
                "contradictions": json.loads(row["contradictions_json"]),
                "summary": row["summary"],
                "directive_ids": json.loads(row["directive_ids_json"]),
                "directive_count": row["directive_count"],
                "created_at": row["created_at"],
            })
        return results

    async def get_audit(
        self,
        audit_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single coherence audit by ID."""
        db = self._db()
        row = db.execute(
            """SELECT id, agent_id, coherence_score, is_coherent,
                      contradictions_json, summary, directive_ids_json,
                      directive_count, created_at
               FROM critic_audits
               WHERE id = ? AND agent_id = ?""",
            (audit_id, agent_id),
        ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "agent_id": row["agent_id"],
            "coherence_score": row["coherence_score"],
            "is_coherent": bool(row["is_coherent"]),
            "contradictions": json.loads(row["contradictions_json"]),
            "summary": row["summary"],
            "directive_ids": json.loads(row["directive_ids_json"]),
            "directive_count": row["directive_count"],
            "created_at": row["created_at"],
        }

    async def validate_memory_ids(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> set[str]:
        """Check which memory IDs exist and belong to ``agent_id``."""
        if not memory_ids:
            return set()
        db = self._db()
        placeholders = ",".join("?" for _ in memory_ids)
        rows = db.execute(
            f"SELECT id FROM memories"  # noqa: S608
            f" WHERE id IN ({placeholders}) AND agent_id = ?",
            (*memory_ids, agent_id),
        ).fetchall()
        return {row["id"] for row in rows}

    async def get_memories_by_ids(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> list[dict[str, Any]]:
        """Fetch memory rows by ID, scoped to ``agent_id``."""
        if not memory_ids:
            return []
        db = self._db()
        placeholders = ",".join("?" for _ in memory_ids)
        rows = db.execute(
            f"SELECT id, tier, event_type, content, salience,"  # noqa: S608
            f"       reinforcement_count, emotional_intensity,"
            f"       source_ids, created_at"
            f" FROM memories"
            f" WHERE id IN ({placeholders}) AND agent_id = ?",
            (*memory_ids, agent_id),
        ).fetchall()

        # Build lookup for input-order preservation
        by_id: dict[str, dict[str, Any]] = {}
        for row in rows:
            d = dict(row)
            raw = d["content"]
            d["content"] = json.loads(raw) if isinstance(raw, str) else raw
            raw_src = d.get("source_ids")
            d["source_ids"] = (
                json.loads(raw_src) if isinstance(raw_src, str) and raw_src
                else []
            )
            by_id[d["id"]] = d

        return [by_id[mid] for mid in memory_ids if mid in by_id]

    async def get_unjournaled_memories(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        limit: int = 50,
        max_memories_cap: int | None = None,
    ) -> list[dict[str, Any]]:
        """Fetch unjournaled, non-archived memories for an agent.

        ``limit`` is clamped to ``max_memories_cap`` (or the balanced
        archetype's ``journal_max_memories`` when omitted) to bound LLM
        synthesis cost.
        """
        cap = (
            max_memories_cap
            if max_memories_cap is not None
            else AdminDefaults().journal_max_memories
        )
        effective_limit = min(limit, cap)

        db = self._db()

        if since is not None:
            rows = db.execute(
                f"""SELECT id, content, event_type, salience, created_at
                   FROM memories
                   WHERE agent_id = ?
                     AND journaled = 0
                     AND created_at >= ?
                     {_NOT_ARCHIVED}
                   ORDER BY created_at ASC, id ASC
                   LIMIT ?""",
                (agent_id, since, effective_limit),
            ).fetchall()
        else:
            rows = db.execute(
                f"""SELECT id, content, event_type, salience, created_at
                   FROM memories
                   WHERE agent_id = ?
                     AND journaled = 0
                     {_NOT_ARCHIVED}
                   ORDER BY created_at ASC, id ASC
                   LIMIT ?""",
                (agent_id, effective_limit),
            ).fetchall()

        result: list[dict[str, Any]] = []
        for row in rows:
            d = dict(row)
            raw = d["content"]
            d["content"] = json.loads(raw) if isinstance(raw, str) else raw
            result.append(d)
        return result

    # --- Journals ---

    async def store_journal(
        self,
        *,
        agent_id: str,
        journal_id: str,
        content: str,
        memory_ids: list[str],
        created_at: str,
    ) -> None:
        """Persist a journal entry and mark source memories as journaled.

        Atomic — journal row insert and memory journaled flag updates
        happen in a single transaction.
        """
        db = self._db()
        try:
            db.execute("BEGIN")
            db.execute(
                """INSERT INTO journals
                   (id, agent_id, content, memory_ids_json, created_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    journal_id,
                    agent_id,
                    content,
                    json.dumps(memory_ids),
                    created_at,
                ),
            )
            if memory_ids:
                placeholders = ",".join("?" for _ in memory_ids)
                db.execute(
                    f"UPDATE memories SET journaled = 1"  # noqa: S608
                    f" WHERE id IN ({placeholders}) AND agent_id = ?",
                    (*memory_ids, agent_id),
                )
            db.execute("COMMIT")
        except Exception:
            db.execute("ROLLBACK")
            raise
        logger.info(
            "Journal stored",
            extra={
                "subsystem": "storage.sqlite",
                "agent_id": agent_id,
                "journal_id": journal_id,
                "memory_count": len(memory_ids),
            },
        )

    async def get_journals(
        self,
        *,
        agent_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Query stored journals, most recent first."""
        db = self._db()
        rows = db.execute(
            """SELECT id, agent_id, content, memory_ids_json, created_at
               FROM journals
               WHERE agent_id = ?
               ORDER BY created_at DESC LIMIT ?""",
            (agent_id, limit),
        ).fetchall()
        return [
            {
                "id": row["id"],
                "agent_id": row["agent_id"],
                "content": row["content"],
                "memory_ids": json.loads(row["memory_ids_json"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def get_journal(
        self,
        journal_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Fetch a single journal by ID."""
        db = self._db()
        row = db.execute(
            """SELECT id, agent_id, content, memory_ids_json, created_at
               FROM journals
               WHERE id = ? AND agent_id = ?""",
            (journal_id, agent_id),
        ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "agent_id": row["agent_id"],
            "content": row["content"],
            "memory_ids": json.loads(row["memory_ids_json"]),
            "created_at": row["created_at"],
        }

    async def mark_memories_journaled(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> int:
        """Mark memories as journaled. Idempotent."""
        if not memory_ids:
            return 0
        db = self._db()
        placeholders = ",".join("?" for _ in memory_ids)
        cursor = db.execute(
            f"UPDATE memories SET journaled = 1"  # noqa: S608
            f" WHERE id IN ({placeholders}) AND agent_id = ?"
            f" AND journaled = 0",
            (*memory_ids, agent_id),
        )
        db.commit()
        return cursor.rowcount

    # --- Dreams ---

    _DREAM_REPORT_FIELDS = (
        "id", "cycle_id", "agent_id", "started_at", "completed_at",
        "status", "steps", "duration_ms",
    )

    def _deserialize_dream_report(self, row: Any) -> dict[str, Any]:
        """Deserialize a dream_reports row to a dict with new-schema fields."""
        return {
            "id": row["id"],
            "cycle_id": row["cycle_id"],
            "agent_id": row["agent_id"],
            "started_at": row["started_at"],
            "completed_at": row["completed_at"],
            "status": row["status"],
            "steps": json.loads(row["steps"]),
            "duration_ms": row["duration_ms"],
        }

    async def store_dream_report(
        self,
        *,
        agent_id: str,
        report_id: str,
        cycle_id: str,
        started_at: str,
        completed_at: str,
        status: str,
        steps: str,
        duration_ms: int,
    ) -> None:
        """Persist a dream cycle report."""
        db = self._db()
        db.execute(
            """INSERT INTO dream_reports
               (id, agent_id, cycle_id, started_at, completed_at,
                status, steps, duration_ms)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                report_id, agent_id, cycle_id,
                started_at, completed_at,
                status, steps, duration_ms,
            ),
        )
        db.commit()

    async def get_dream_report(
        self, *, agent_id: str, cycle_id: str
    ) -> dict[str, Any] | None:
        """Retrieve a single dream report by ``cycle_id``."""
        db = self._db()
        row = db.execute(
            """SELECT * FROM dream_reports
               WHERE agent_id = ? AND cycle_id = ?""",
            (agent_id, cycle_id),
        ).fetchone()
        if row is None:
            return None
        return self._deserialize_dream_report(row)

    async def get_dream_history(
        self, *, agent_id: str, limit: int = 30
    ) -> list[dict[str, Any]]:
        """Retrieve past dream cycle reports for ``agent_id``."""
        db = self._db()
        rows = db.execute(
            """SELECT * FROM dream_reports
               WHERE agent_id = ?
               ORDER BY started_at DESC, id DESC LIMIT ?""",
            (agent_id, limit),
        ).fetchall()
        return [self._deserialize_dream_report(row) for row in rows]

    # --- Counts ---

    async def get_agent_counts(self, *, agent_id: str) -> dict[str, int]:
        """Return entity counts for ``agent_id``."""
        db = self._db()
        tables = {
            "memories": "memories",
            "directives": "directives",
            "journals": "journals",
            "dream_reports": "dream_reports",
        }
        counts: dict[str, int] = {}
        for key, table in tables.items():
            row = db.execute(
                f"SELECT COUNT(*) as n FROM {table} WHERE agent_id = ?",  # noqa: S608
                (agent_id,),
            ).fetchone()
            counts[key] = row["n"]
        return counts

    async def get_evolution_summary(self, *, agent_id: str) -> dict[str, Any]:
        """Return evolution data for the status narrative."""
        db = self._db()

        # Earliest entity timestamp (proxy for agent creation)
        first_seen: str | None = None
        for table in ("memories", "directives", "journals"):
            row = db.execute(
                f"SELECT MIN(created_at) as ts FROM {table} WHERE agent_id = ?",  # noqa: S608
                (agent_id,),
            ).fetchone()
            ts = row["ts"] if row else None
            if ts and (first_seen is None or ts < first_seen):
                first_seen = ts

        # Memory counts by tier
        tier_rows = db.execute(
            """SELECT tier, COUNT(*) as n FROM memories
               WHERE agent_id = ? GROUP BY tier""",
            (agent_id,),
        ).fetchall()
        memories_by_tier = {"raw": 0, "consolidated": 0, "reflective": 0}
        for row in tier_rows:
            tier_key = row["tier"]
            if tier_key in memories_by_tier:
                memories_by_tier[tier_key] = row["n"]

        # Directive counts by status
        status_rows = db.execute(
            """SELECT status, COUNT(*) as n FROM directives
               WHERE agent_id = ? GROUP BY status""",
            (agent_id,),
        ).fetchall()
        directives_by_status = {
            "provisional": 0,
            "active": 0,
            "permanent": 0,
            "inactive": 0,
        }
        for row in status_rows:
            s = row["status"]
            if s in directives_by_status:
                directives_by_status[s] = row["n"]

        # Dream count and most recent
        dream_row = db.execute(
            """SELECT COUNT(*) as n, MAX(completed_at) as last
               FROM dream_reports WHERE agent_id = ?""",
            (agent_id,),
        ).fetchone()
        dream_count = dream_row["n"]
        last_dream_at = dream_row["last"]

        # Journal count
        journal_row = db.execute(
            "SELECT COUNT(*) as n FROM journals WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()

        total_consolidated = (
            memories_by_tier["consolidated"] + memories_by_tier["reflective"]
        )

        return {
            "first_seen": first_seen,
            "memories_by_tier": memories_by_tier,
            "directives_by_status": directives_by_status,
            "dream_count": dream_count,
            "last_dream_at": last_dream_at,
            "journal_count": journal_row["n"],
            "total_consolidated": total_consolidated,
        }

    # --- Analytics ---

    async def get_health(self, *, agent_id: str) -> dict[str, Any]:
        """Get current cognitive health metrics for ``agent_id``."""
        db = self._db()

        total = db.execute(
            "SELECT COUNT(*) as n FROM memories WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()["n"]
        by_tier = db.execute(
            """SELECT tier, COUNT(*) as n FROM memories
               WHERE agent_id = ? GROUP BY tier""",
            (agent_id,),
        ).fetchall()
        avg_salience = db.execute(
            "SELECT AVG(salience) as avg FROM memories WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()["avg"]
        active_directives = db.execute(
            """SELECT COUNT(*) as n FROM directives
               WHERE agent_id = ? AND status != 'inactive'""",
            (agent_id,),
        ).fetchone()["n"]
        pending_proposals = db.execute(
            """SELECT COUNT(*) as n FROM directive_proposals
               WHERE agent_id = ? AND status = 'pending'""",
            (agent_id,),
        ).fetchone()["n"]
        last_dream = db.execute(
            """SELECT completed_at FROM dream_reports
               WHERE agent_id = ?
               ORDER BY completed_at DESC LIMIT 1""",
            (agent_id,),
        ).fetchone()

        return {
            "total_memories": total,
            "memories_by_tier": {row["tier"]: row["n"] for row in by_tier},
            "average_salience": round(avg_salience or 0.0, 3),
            "active_directives": active_directives,
            "pending_proposals": pending_proposals,
            "last_dream_cycle": last_dream["completed_at"] if last_dream else None,
            "memory_load": min(total / 10000.0, 1.0),  # Rough load estimate
            "drift_risk": 0.0,  # TODO: Implement drift calculation
        }

    async def get_health_report_stats(
        self,
        *,
        agent_id: str,
        window_days: int = 7,
    ) -> dict[str, Any]:
        """Return rich aggregates backing :meth:`WisdomAgent.health`.

        The window is a rolling N-day slice (default 7) anchored on
        "now" at call time. All timestamps compared against the window
        use ISO 8601 strings (lexicographically sortable); we never do
        SQL-side datetime arithmetic to keep behavior identical across
        SQLite builds.
        """
        db = self._db()
        now = datetime.now(UTC)
        since = (now - timedelta(days=window_days)).isoformat()

        # ------------------------------------------------------------------
        # Memory aggregates
        # ------------------------------------------------------------------
        total_row = db.execute(
            "SELECT COUNT(*) as n FROM memories WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()
        total_memories = int(total_row["n"])

        tier_rows = db.execute(
            """SELECT tier, COUNT(*) as n FROM memories
               WHERE agent_id = ? GROUP BY tier""",
            (agent_id,),
        ).fetchall()
        by_tier = {row["tier"]: int(row["n"]) for row in tier_rows}

        avg_sal_row = db.execute(
            "SELECT AVG(salience) as avg FROM memories WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()
        avg_salience = float(avg_sal_row["avg"] or 0.0)

        captures_row = db.execute(
            """SELECT COUNT(*) as n FROM memories
               WHERE agent_id = ? AND created_at >= ?""",
            (agent_id, since),
        ).fetchone()
        captures_7d = int(captures_row["n"])

        dedup_row = db.execute(
            """SELECT COUNT(*) as n FROM memories
               WHERE agent_id = ? AND created_at >= ?
                 AND dedup_of IS NOT NULL""",
            (agent_id, since),
        ).fetchone()
        dedup_count_7d = int(dedup_row["n"])
        dedup_rate_7d = (
            dedup_count_7d / captures_7d if captures_7d > 0 else 0.0
        )

        reinforced_row = db.execute(
            """SELECT COUNT(*) as n FROM memories
               WHERE agent_id = ? AND reinforcement_count > 0""",
            (agent_id,),
        ).fetchone()
        reinforced_count = int(reinforced_row["n"])

        event_type_rows = db.execute(
            """SELECT event_type, COUNT(*) as n FROM memories
               WHERE agent_id = ? AND event_type != ''
               GROUP BY event_type""",
            (agent_id,),
        ).fetchall()
        event_type_counts = {
            row["event_type"]: int(row["n"]) for row in event_type_rows
        }

        # Journal count lives in its own table (migration 0013)
        journal_total_row = db.execute(
            "SELECT COUNT(*) as n FROM journals WHERE agent_id = ?",
            (agent_id,),
        ).fetchone()
        journal_count = int(journal_total_row["n"])

        # ------------------------------------------------------------------
        # Directive aggregates
        # ------------------------------------------------------------------
        status_rows = db.execute(
            """SELECT status, COUNT(*) as n FROM directives
               WHERE agent_id = ?
               GROUP BY status""",
            (agent_id,),
        ).fetchall()
        provisional_count = 0
        active_count = 0
        permanent_count = 0
        inactive_count = 0
        for row in status_rows:
            status = row["status"]
            n = int(row["n"])
            if status == "inactive":
                inactive_count += n
            elif status == "provisional":
                provisional_count += n
            elif status == "permanent":
                permanent_count += n
            else:
                active_count += n

        demotions_row = db.execute(
            """SELECT COUNT(*) as n FROM directives
               WHERE agent_id = ? AND status = 'inactive'
                 AND updated_at IS NOT NULL AND updated_at >= ?""",
            (agent_id, since),
        ).fetchone()
        demotions_7d = int(demotions_row["n"])

        directive_updates_row = db.execute(
            """SELECT COUNT(*) as n FROM directives
               WHERE agent_id = ? AND updated_at IS NOT NULL
                 AND updated_at >= ?""",
            (agent_id, since),
        ).fetchone()
        directive_updates_7d = int(directive_updates_row["n"])
        demotion_rate_7d = (
            demotions_7d / directive_updates_7d
            if directive_updates_7d > 0
            else 0.0
        )

        age_row = db.execute(
            """SELECT created_at FROM directives
               WHERE agent_id = ? AND status != 'inactive'""",
            (agent_id,),
        ).fetchall()
        avg_age_days = 0.0
        if age_row:
            ages: list[float] = []
            for row in age_row:
                try:
                    created = datetime.fromisoformat(row["created_at"])
                    if created.tzinfo is None:
                        created = created.replace(tzinfo=UTC)
                    ages.append((now - created).total_seconds() / 86400.0)
                except (ValueError, TypeError):
                    continue
            if ages:
                avg_age_days = sum(ages) / len(ages)

        # ------------------------------------------------------------------
        # Dream aggregates
        # ------------------------------------------------------------------
        dream_rows = db.execute(
            """SELECT status, duration_ms, completed_at FROM dream_reports
               WHERE agent_id = ? AND completed_at >= ?""",
            (agent_id, since),
        ).fetchall()
        runs_7d = len(dream_rows)
        success_count_7d = sum(1 for r in dream_rows if r["status"] == "success")
        failure_count_7d = runs_7d - success_count_7d
        success_rate_7d = (
            success_count_7d / runs_7d if runs_7d > 0 else 0.0
        )
        avg_duration_ms = (
            sum(int(r["duration_ms"] or 0) for r in dream_rows) / runs_7d
            if runs_7d > 0
            else 0.0
        )
        last_dream_row = db.execute(
            """SELECT completed_at FROM dream_reports
               WHERE agent_id = ?
               ORDER BY completed_at DESC LIMIT 1""",
            (agent_id,),
        ).fetchone()
        last_run_iso = last_dream_row["completed_at"] if last_dream_row else None

        # ------------------------------------------------------------------
        # Cost aggregates (cost_records may be empty if tracking disabled)
        # ------------------------------------------------------------------
        cost_row = db.execute(
            """SELECT COALESCE(SUM(input_tokens + output_tokens), 0) as tokens,
                      COALESCE(SUM(cost_usd), 0.0) as usd
               FROM cost_records
               WHERE agent_id = ? AND created_at >= ?""",
            (agent_id, since),
        ).fetchone()
        tokens_7d = int(cost_row["tokens"])
        usd_7d = float(cost_row["usd"])

        dream_cost_row = db.execute(
            """SELECT COALESCE(SUM(input_tokens + output_tokens), 0) as tokens
               FROM cost_records
               WHERE agent_id = ? AND created_at >= ?
                 AND cycle_id IS NOT NULL""",
            (agent_id, since),
        ).fetchone()
        dream_tokens_7d = int(dream_cost_row["tokens"])

        # ------------------------------------------------------------------
        # Critic reviews (pass rate)
        # ------------------------------------------------------------------
        critic_row = db.execute(
            """SELECT COUNT(*) as n,
                      COALESCE(SUM(pass_through), 0) as passes
               FROM critic_reviews
               WHERE agent_id = ? AND created_at >= ?""",
            (agent_id, since),
        ).fetchone()
        reviews_7d = int(critic_row["n"])
        passes_7d = int(critic_row["passes"])
        pass_rate_7d = passes_7d / reviews_7d if reviews_7d > 0 else 1.0

        # ------------------------------------------------------------------
        # Journal frequency (for wisdom score)
        # ------------------------------------------------------------------
        journal_recent_row = db.execute(
            """SELECT COUNT(*) as n FROM journals
               WHERE agent_id = ? AND created_at >= ?""",
            (agent_id, since),
        ).fetchone()
        entries_7d = int(journal_recent_row["n"])

        last_journal_row = db.execute(
            """SELECT created_at FROM journals
               WHERE agent_id = ?
               ORDER BY created_at DESC LIMIT 1""",
            (agent_id,),
        ).fetchone()
        days_since_last_journal: float | None = None
        if last_journal_row:
            try:
                last_j = datetime.fromisoformat(last_journal_row["created_at"])
                if last_j.tzinfo is None:
                    last_j = last_j.replace(tzinfo=UTC)
                days_since_last_journal = max(
                    (now - last_j).total_seconds() / 86400.0, 0.0
                )
            except (ValueError, TypeError):
                days_since_last_journal = None

        return {
            "memory": {
                "stream_count": by_tier.get("raw", 0),
                "consolidated_count": by_tier.get("consolidated", 0)
                + by_tier.get("reflective", 0),
                "journal_count": journal_count,
                "avg_salience": round(avg_salience, 3),
                "dedup_rate_7d": round(dedup_rate_7d, 3),
                "captures_7d": captures_7d,
                "reinforced_count": reinforced_count,
                "total_memories": total_memories,
                "event_type_counts": event_type_counts,
            },
            "directives": {
                "provisional_count": provisional_count,
                "active_count": active_count,
                "permanent_count": permanent_count,
                "inactive_count": inactive_count,
                "demotion_rate_7d": round(demotion_rate_7d, 3),
                "avg_age_days": round(avg_age_days, 2),
            },
            "dreams": {
                "runs_7d": runs_7d,
                "success_count_7d": success_count_7d,
                "failure_count_7d": failure_count_7d,
                "success_rate_7d": round(success_rate_7d, 3),
                "avg_duration_ms": round(avg_duration_ms, 2),
                "last_run_iso": last_run_iso,
            },
            "cost": {
                "tokens_7d": tokens_7d,
                "usd_7d": round(usd_7d, 4),
                "dream_tokens_7d": dream_tokens_7d,
            },
            "critic": {
                "reviews_7d": reviews_7d,
                "pass_rate_7d": round(pass_rate_7d, 3),
            },
            "journals": {
                "entries_7d": entries_7d,
                "days_since_last_journal": (
                    round(days_since_last_journal, 2)
                    if days_since_last_journal is not None
                    else None
                ),
            },
        }

    async def append_health_snapshot(
        self,
        *,
        agent_id: str,
        snapshot_date: str,
        payload: str,
        created_at: str,
    ) -> None:
        """Upsert a health snapshot — last write on a given date wins."""
        db = self._db()
        db.execute(
            """INSERT INTO health_snapshots
                   (agent_id, snapshot_date, payload, created_at)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(agent_id, snapshot_date) DO UPDATE SET
                   payload = excluded.payload,
                   created_at = excluded.created_at""",
            (agent_id, snapshot_date, payload, created_at),
        )
        db.commit()

    async def query_health_snapshots(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return snapshots ascending by ``snapshot_date``."""
        db = self._db()
        where = ["agent_id = ?"]
        params: list[Any] = [agent_id]
        if since is not None:
            where.append("snapshot_date >= ?")
            params.append(since)
        if until is not None:
            where.append("snapshot_date <= ?")
            params.append(until)
        sql = f"""SELECT snapshot_date, payload, created_at
                  FROM health_snapshots
                  WHERE {" AND ".join(where)}
                  ORDER BY snapshot_date ASC"""  # noqa: S608 — where fragments are fixed
        if limit is not None:
            sql += " LIMIT ?"
            params.append(int(limit))
        rows = db.execute(sql, params).fetchall()
        return [
            {
                "snapshot_date": row["snapshot_date"],
                "payload": row["payload"],
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    # ----------------------------------------------------------------------
    # Cost ledger (v0.5 Phase 4)
    # ----------------------------------------------------------------------

    async def append_cost_record(
        self,
        *,
        record_id: str,
        agent_id: str,
        model_id: str,
        category: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        cycle_id: str | None,
        event_id: str | None,
        purpose: str,
        created_at: str,
    ) -> None:
        """Append one row to ``cost_records``."""
        db = self._db()
        db.execute(
            """INSERT INTO cost_records
                   (id, agent_id, model_id, tier, purpose,
                    input_tokens, output_tokens, cost_usd,
                    cycle_id, created_at, event_id, category)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                record_id,
                agent_id,
                model_id,
                "mid",
                purpose,
                int(input_tokens),
                int(output_tokens),
                float(cost_usd),
                cycle_id,
                created_at,
                event_id,
                category,
            ),
        )
        db.commit()

    async def query_cost_records(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        category: str | None = None,
        cycle_id: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return ledger rows for ``agent_id`` ordered by ``created_at ASC``."""
        db = self._db()
        where = ["agent_id = ?"]
        params: list[Any] = [agent_id]
        if since is not None:
            where.append("created_at >= ?")
            params.append(since)
        if until is not None:
            where.append("created_at <= ?")
            params.append(until)
        if category is not None:
            where.append("category = ?")
            params.append(category)
        if cycle_id is not None:
            where.append("cycle_id = ?")
            params.append(cycle_id)
        sql = f"""SELECT id, agent_id, model_id, tier, purpose,
                         input_tokens, output_tokens, cost_usd,
                         cycle_id, created_at, event_id, category
                  FROM cost_records
                  WHERE {" AND ".join(where)}
                  ORDER BY created_at ASC, id ASC"""  # noqa: S608 — fragments are fixed
        if limit is not None:
            sql += " LIMIT ?"
            params.append(int(limit))
        rows = db.execute(sql, params).fetchall()
        return [
            {
                "id": row["id"],
                "agent_id": row["agent_id"],
                "model_id": row["model_id"],
                "tier": row["tier"],
                "purpose": row["purpose"],
                "input_tokens": int(row["input_tokens"] or 0),
                "output_tokens": int(row["output_tokens"] or 0),
                "cost_usd": float(row["cost_usd"] or 0.0),
                "cycle_id": row["cycle_id"],
                "created_at": row["created_at"],
                "event_id": row["event_id"],
                "category": row["category"] or "",
            }
            for row in rows
        ]

    async def sum_cost_by_cycle(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> list[dict[str, Any]]:
        """Per-(category, model) totals for one dream cycle."""
        db = self._db()
        rows = db.execute(
            """SELECT category, model_id,
                      COALESCE(SUM(input_tokens), 0) AS input_tokens,
                      COALESCE(SUM(output_tokens), 0) AS output_tokens,
                      COALESCE(SUM(cost_usd), 0.0) AS cost_usd,
                      COUNT(*) AS calls
               FROM cost_records
               WHERE agent_id = ? AND cycle_id = ?
               GROUP BY category, model_id
               ORDER BY category ASC, model_id ASC""",
            (agent_id, cycle_id),
        ).fetchall()
        return [
            {
                "category": row["category"] or "",
                "model_id": row["model_id"] or "",
                "input_tokens": int(row["input_tokens"]),
                "output_tokens": int(row["output_tokens"]),
                "cost_usd": float(row["cost_usd"]),
                "calls": int(row["calls"]),
            }
            for row in rows
        ]

    async def cost_summary_aggregate(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
    ) -> dict[str, Any]:
        """Totals + by-category + by-model aggregation for ``cost.summary()``."""
        db = self._db()
        where = ["agent_id = ?"]
        params: list[Any] = [agent_id]
        if since is not None:
            where.append("created_at >= ?")
            params.append(since)
        if until is not None:
            where.append("created_at <= ?")
            params.append(until)
        where_sql = " AND ".join(where)

        total_row = db.execute(
            f"""SELECT COALESCE(SUM(cost_usd), 0.0) AS cost_usd,
                       COALESCE(SUM(input_tokens), 0) AS input_tokens,
                       COALESCE(SUM(output_tokens), 0) AS output_tokens,
                       COUNT(*) AS calls
                FROM cost_records
                WHERE {where_sql}""",  # noqa: S608 — fragments are fixed
            params,
        ).fetchone()

        by_cat_rows = db.execute(
            f"""SELECT COALESCE(category, '') AS category,
                       COALESCE(SUM(cost_usd), 0.0) AS cost_usd,
                       COALESCE(SUM(input_tokens), 0) AS input_tokens,
                       COALESCE(SUM(output_tokens), 0) AS output_tokens,
                       COUNT(*) AS calls
                FROM cost_records
                WHERE {where_sql}
                GROUP BY category""",  # noqa: S608 — fragments are fixed
            params,
        ).fetchall()
        by_model_rows = db.execute(
            f"""SELECT model_id,
                       COALESCE(SUM(cost_usd), 0.0) AS cost_usd,
                       COALESCE(SUM(input_tokens), 0) AS input_tokens,
                       COALESCE(SUM(output_tokens), 0) AS output_tokens,
                       COUNT(*) AS calls
                FROM cost_records
                WHERE {where_sql}
                GROUP BY model_id""",  # noqa: S608 — fragments are fixed
            params,
        ).fetchall()

        return {
            "total_cost_usd": float(total_row["cost_usd"]),
            "total_input_tokens": int(total_row["input_tokens"]),
            "total_output_tokens": int(total_row["output_tokens"]),
            "total_calls": int(total_row["calls"]),
            "by_category": {
                (row["category"] or ""): {
                    "cost_usd": float(row["cost_usd"]),
                    "input_tokens": int(row["input_tokens"]),
                    "output_tokens": int(row["output_tokens"]),
                    "calls": int(row["calls"]),
                }
                for row in by_cat_rows
            },
            "by_model": {
                row["model_id"]: {
                    "cost_usd": float(row["cost_usd"]),
                    "input_tokens": int(row["input_tokens"]),
                    "output_tokens": int(row["output_tokens"]),
                    "calls": int(row["calls"]),
                }
                for row in by_model_rows
            },
        }

    # --- Atomic facts (Beta in v1.0) ----------------------------------------

    async def store_fact(
        self,
        *,
        fact_id: str,
        agent_id: str,
        subject: str,
        attribute: str,
        value: str,
        source_memory_id: str | None,
        confidence: float,
        decay_rate: float,
        created_at: str,
    ) -> str:
        """Insert a single fact row. Last-write-wins at retrieval time.

        When the backend is bound to an embedder, the fact is embedded
        as ``"{subject} {attribute} {value}"`` so ``search_facts`` can
        rank by cosine similarity. Without an embedder, the embedding
        column stays NULL and search falls back to substring matching.
        """
        db = self._db()
        embedding: bytes | None = None
        embedding_model_id: str | None = None
        embedding_dim: int | None = None
        if self._embed_fn is not None:
            fact_text = f"{subject} {attribute} {value}"
            vec = await self._embed_fn(fact_text)
            if len(vec) != self._embedding_dim:
                msg = (
                    f"Embedding adapter returned {len(vec)}-dim vector but "
                    f"backend is configured for {self._embedding_dim}-dim "
                    f"({self._embedding_model_id}). Refusing to write a "
                    f"fact row that would silently corrupt vector search."
                )
                raise ValueError(msg)
            embedding = _pack_embedding(vec)
            embedding_model_id = self._embedding_model_id
            embedding_dim = self._embedding_dim

        db.execute(
            """INSERT INTO facts
                   (id, agent_id, subject, attribute, value,
                    source_memory_id, confidence, decay_rate, created_at,
                    embedding, embedding_model_id, embedding_dim)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                fact_id,
                agent_id,
                subject,
                attribute,
                value,
                source_memory_id,
                float(confidence),
                float(decay_rate),
                created_at,
                embedding,
                embedding_model_id,
                embedding_dim,
            ),
        )
        db.commit()
        return fact_id

    async def search_facts(
        self,
        *,
        agent_id: str,
        query: str,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Rank facts by semantic similarity, with a substring fallback.

        When the backend is bound to an embedder, the query is embedded
        and scored against every fact embedded under the same model
        (cosine similarity). Cross-model rows and rows that pre-date the
        embedding migration fall through to a substring scan over
        ``(subject, attribute, value)`` so no fact ever becomes
        unreachable after a model upgrade.

        Without an embedder, pure substring scan — same behavior as the
        original v1.0 release for backends with no embed_fn bound.
        """
        db = self._db()
        like = f"%{query}%"

        if self._embed_fn is None:
            rows = db.execute(
                """SELECT id, subject, attribute, value, source_memory_id,
                          confidence, decay_rate, created_at
                   FROM facts
                   WHERE agent_id = ?
                     AND (subject LIKE ? OR attribute LIKE ? OR value LIKE ?)
                   ORDER BY created_at DESC
                   LIMIT ?""",
                (agent_id, like, like, like, limit),
            ).fetchall()
            return [
                {
                    "id": row["id"],
                    "subject": row["subject"],
                    "attribute": row["attribute"],
                    "value": row["value"],
                    "source_memory_id": row["source_memory_id"],
                    "confidence": float(row["confidence"]),
                    "decay_rate": float(row["decay_rate"]),
                    "created_at": row["created_at"],
                }
                for row in rows
            ]

        query_vec = await self._embed_fn(query)
        if len(query_vec) != self._embedding_dim:
            msg = (
                f"Embedding adapter returned {len(query_vec)}-dim query "
                f"vector but backend is configured for "
                f"{self._embedding_dim}-dim ({self._embedding_model_id}). "
                f"Refusing a fact search that would silently rank against "
                f"the wrong embedding space."
            )
            raise ValueError(msg)

        embedded_rows = db.execute(
            """SELECT id, subject, attribute, value, source_memory_id,
                      confidence, decay_rate, created_at, embedding
               FROM facts
               WHERE agent_id = ?
                 AND embedding IS NOT NULL
                 AND embedding_model_id = ?
                 AND embedding_dim = ?""",
            (agent_id, self._embedding_model_id, self._embedding_dim),
        ).fetchall()

        scored = []
        for row in embedded_rows:
            fact_vec = _unpack_embedding(row["embedding"])
            sim = _cosine_similarity(query_vec, fact_vec)
            scored.append((sim, row))
        scored.sort(key=lambda x: x[0], reverse=True)

        results: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        for sim, row in scored[:limit]:
            seen_ids.add(row["id"])
            results.append({
                "id": row["id"],
                "subject": row["subject"],
                "attribute": row["attribute"],
                "value": row["value"],
                "source_memory_id": row["source_memory_id"],
                "confidence": float(row["confidence"]),
                "decay_rate": float(row["decay_rate"]),
                "created_at": row["created_at"],
                "similarity": round(sim, 4),
            })

        # Cross-model lexical fallback for rows under stale embedders or
        # rows that pre-date migration 0022. Same pattern as
        # ``search_memories``.
        remaining = limit - len(results)
        if remaining > 0:
            stale_rows = db.execute(
                """SELECT id, subject, attribute, value, source_memory_id,
                          confidence, decay_rate, created_at
                   FROM facts
                   WHERE agent_id = ?
                     AND (subject LIKE ? OR attribute LIKE ? OR value LIKE ?)
                     AND (
                         embedding IS NULL
                         OR embedding_model_id != ?
                         OR embedding_dim != ?
                     )
                   ORDER BY created_at DESC
                   LIMIT ?""",
                (
                    agent_id, like, like, like,
                    self._embedding_model_id, self._embedding_dim,
                    remaining,
                ),
            ).fetchall()
            for row in stale_rows:
                if row["id"] in seen_ids:
                    continue
                results.append({
                    "id": row["id"],
                    "subject": row["subject"],
                    "attribute": row["attribute"],
                    "value": row["value"],
                    "source_memory_id": row["source_memory_id"],
                    "confidence": float(row["confidence"]),
                    "decay_rate": float(row["decay_rate"]),
                    "created_at": row["created_at"],
                    "similarity": 1.0,
                })

        return results

    async def list_facts_for_subject(
        self,
        *,
        agent_id: str,
        subject: str,
        limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Return facts about ``subject``, newest first."""
        db = self._db()
        rows = db.execute(
            """SELECT id, subject, attribute, value, source_memory_id,
                      confidence, decay_rate, created_at
               FROM facts
               WHERE agent_id = ? AND subject = ?
               ORDER BY created_at DESC
               LIMIT ?""",
            (agent_id, subject, limit),
        ).fetchall()
        return [
            {
                "id": row["id"],
                "subject": row["subject"],
                "attribute": row["attribute"],
                "value": row["value"],
                "source_memory_id": row["source_memory_id"],
                "confidence": float(row["confidence"]),
                "decay_rate": float(row["decay_rate"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def list_facts_for_memory(
        self,
        *,
        agent_id: str,
        memory_id: str,
    ) -> list[dict[str, Any]]:
        """Return every fact extracted from ``memory_id``."""
        db = self._db()
        rows = db.execute(
            """SELECT id, subject, attribute, value, source_memory_id,
                      confidence, decay_rate, created_at
               FROM facts
               WHERE agent_id = ? AND source_memory_id = ?
               ORDER BY created_at ASC""",
            (agent_id, memory_id),
        ).fetchall()
        return [
            {
                "id": row["id"],
                "subject": row["subject"],
                "attribute": row["attribute"],
                "value": row["value"],
                "source_memory_id": row["source_memory_id"],
                "confidence": float(row["confidence"]),
                "decay_rate": float(row["decay_rate"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]
