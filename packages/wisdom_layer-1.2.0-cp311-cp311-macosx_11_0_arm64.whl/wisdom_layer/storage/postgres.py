"""Postgres storage backend — Pro/Enterprise production tier.

Async-first backend built on :mod:`asyncpg` and the :mod:`pgvector`
Postgres extension. Schema is owned by
:mod:`wisdom_layer.storage._pg_migrations` which applies every pending
``NNNN_<name>.sql`` file in ``wisdom_layer/storage/migrations/postgres/``
at :meth:`PostgresBackend.initialize`.

This module is **optional**: the core SDK installs without asyncpg /
pgvector. Importing this file without the ``[postgres]`` extra installed
succeeds (so type-only consumers stay unaffected), but calling
:meth:`PostgresBackend.initialize` raises :class:`ImportError` with
instructions to install the extra.

Scope in v0.6:
- Connection pool lifecycle (init + close)
- JSONB + pgvector type codec registration
- Migration runner wiring
- Per-agent advisory lock helper for reconsolidation / dream-cycle
  single-flight (see :meth:`PostgresBackend.agent_lock`)
- All :class:`~wisdom_layer.storage.base.BaseBackend` abstractmethods
  are scaffolded as stubs; real implementations land in subsequent
  slices driven by the contract test suite in ``tests/backends/``.

Doc reference: ROADMAP_v1.0/v0.6_storage_reliability/phase_1_postgres.md.
"""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
from datetime import UTC, datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any

from wisdom_layer._internal.admin_defaults import AdminDefaults
from wisdom_layer.errors import BackendNotInitializedError, EmbeddingConfigMismatchError
from wisdom_layer.memory._decay import DECAY_EXEMPT_TYPES, compute_salience
from wisdom_layer.memory.ranking import recency_bonus
from wisdom_layer.storage.base import BaseBackend

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path
    from types import TracebackType

    import asyncpg

logger = logging.getLogger(__name__)

_POSTGRES_EXTRA_HINT = (
    "PostgresBackend requires the [postgres] extra. Install with:\n"
    "    pip install 'wisdom-layer[postgres]'"
)


def _migrations_dir() -> Path:
    """Absolute path to the Postgres dialect migrations folder."""
    from pathlib import Path as _Path

    return _Path(__file__).parent / "migrations" / "postgres"


DEFAULT_EMBEDDING_MODEL_ID = "all-MiniLM-L6-v2"
DEFAULT_EMBEDDING_DIM = 384


def _now_iso() -> str:
    """Current UTC time as ISO 8601 string — identical to SQLiteBackend."""
    return datetime.now(UTC).isoformat()


def _gen_id() -> str:
    """Generate a 12-char hex ID — identical to SQLiteBackend."""
    return uuid.uuid4().hex[:12]


def _agent_lock_key(agent_id: str) -> int:
    """Map ``agent_id`` to a signed 64-bit integer for ``pg_advisory_*_lock``.

    Postgres advisory locks take a ``bigint``; we deterministically hash
    ``agent_id`` with SHA-256 and take the first 8 bytes as a signed
    little-endian integer. Collisions are astronomically unlikely at
    fleet scale (SDK caps agents at 50 per workspace).

    Stable across processes, versions, and architectures — the same
    ``agent_id`` always produces the same key.
    """
    digest = hashlib.sha256(agent_id.encode("utf-8")).digest()[:8]
    return int.from_bytes(digest, byteorder="little", signed=True)


class _AgentLock:
    """Async context manager for a per-agent transactional advisory lock.

    Wraps ``pg_advisory_xact_lock(key)`` so the lock auto-releases when
    the transaction commits or rolls back — no cleanup required from
    the caller. Concurrent dream-cycle / reconsolidation attempts on
    the same ``agent_id`` serialize; different agents run in parallel.

    Example::

        async with backend.agent_lock(agent_id) as conn:
            async with conn.transaction():
                # ... reconsolidation writes ...
    """

    def __init__(self, pool: asyncpg.Pool, agent_id: str) -> None:
        self._pool = pool
        self._key = _agent_lock_key(agent_id)
        self._conn: asyncpg.Connection | None = None
        self._tx: Any = None

    async def __aenter__(self) -> asyncpg.Connection:
        self._conn = await self._pool.acquire()
        self._tx = self._conn.transaction()
        await self._tx.start()
        await self._conn.execute("SELECT pg_advisory_xact_lock($1)", self._key)
        return self._conn

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        try:
            if exc is None:
                await self._tx.commit()
            else:
                await self._tx.rollback()
        finally:
            if self._conn is not None:
                await self._pool.release(self._conn)
            self._conn = None
            self._tx = None


class PostgresBackend(BaseBackend):
    """Postgres storage backend.

    Args:
        dsn: Postgres connection string (e.g.
            ``postgresql://user:pass@host:5432/dbname``). Takes precedence
            over individual connection parameters.
        min_pool_size: Minimum number of pool connections. Defaults to 1.
        max_pool_size: Maximum number of pool connections. Defaults to 10.
        embed_fn: Optional async function to generate embeddings.
            Signature: ``async (text: str) -> list[float]``. When ``None``
            (the default), :meth:`bind_embedder` wires the LLM adapter's
            ``embed`` callable in at agent startup. Without an embedder,
            semantic search falls back to text ``LIKE`` matching — API
            parity with :class:`SQLiteBackend`.
        embedding_model_id: Identifier of the active embedding model.
            When ``None`` (the default), :meth:`bind_embedder` reads it
            from the LLM adapter so adapter and backend cannot drift.
            Setting this explicitly opts you out of auto-binding —
            disagreement with the adapter then raises
            :class:`EmbeddingConfigMismatchError`.
        embedding_dim: Dimension of embedding vectors. Must resolve to
            384 — migration 0001 hard-codes ``VECTOR(384)``. ``None``
            defers to :meth:`bind_embedder`, which raises
            :class:`EmbeddingConfigMismatchError` if the adapter
            advertises a different dim.
        admin_defaults: Tuning profile for vector search (ivfflat
            threshold). Defaults to :meth:`AdminDefaults.balanced`.

    Example::

        backend = PostgresBackend(dsn="postgresql://localhost/wisdom")
        await backend.initialize()
        try:
            status = await backend.migration_status()
        finally:
            await backend.close()
    """

    def __init__(
        self,
        *,
        dsn: str,
        min_pool_size: int = 1,
        max_pool_size: int = 10,
        embed_fn: Any = None,
        embedding_model_id: str | None = None,
        embedding_dim: int | None = None,
        admin_defaults: AdminDefaults | None = None,
    ) -> None:
        if embedding_dim is not None and embedding_dim != DEFAULT_EMBEDDING_DIM:
            raise ValueError(
                f"PostgresBackend v0.6 hard-codes VECTOR({DEFAULT_EMBEDDING_DIM}) "
                f"in migration 0001; embedding_dim={embedding_dim} is not "
                "supported. File an issue if you need a different dimension."
            )
        self._dsn = dsn
        self._min_pool_size = min_pool_size
        self._max_pool_size = max_pool_size
        self._embed_fn = embed_fn
        self._embedding_model_id = embedding_model_id or DEFAULT_EMBEDDING_MODEL_ID
        self._embedding_dim = (
            embedding_dim if embedding_dim is not None else DEFAULT_EMBEDDING_DIM
        )
        self._embedding_model_id_explicit = embedding_model_id is not None
        self._embedding_dim_explicit = embedding_dim is not None
        self._admin_defaults = admin_defaults or AdminDefaults.balanced()
        self._pool: asyncpg.Pool | None = None

    def _apply_embedder_binding(
        self,
        *,
        model_id: str,
        dim: int,
        embed_fn: Any,
    ) -> None:
        """Wire the adapter's embedder identity into this backend.

        Postgres v0.6 hard-codes ``VECTOR(384)`` in migration 0001, so any
        adapter advertising a different dim is rejected here with
        :class:`EmbeddingConfigMismatchError`. See
        :meth:`BaseBackend.bind_embedder` for the contract.
        """
        if dim != DEFAULT_EMBEDDING_DIM:
            raise EmbeddingConfigMismatchError(
                f"PostgresBackend hard-codes VECTOR({DEFAULT_EMBEDDING_DIM}) "
                f"in migration 0001 but the LLM adapter '{model_id}' "
                f"produces {dim}-dim vectors. Either swap to a "
                f"{DEFAULT_EMBEDDING_DIM}-dim embedder (e.g., "
                f"all-MiniLM-L6-v2) on the adapter, or use SQLiteBackend "
                f"until a parameterized-dim Postgres migration ships."
            )
        if self._embedding_model_id_explicit and self._embedding_model_id != model_id:
            raise EmbeddingConfigMismatchError(
                f"PostgresBackend was constructed with "
                f"embedding_model_id={self._embedding_model_id!r} but the "
                f"LLM adapter advertises {model_id!r}. Drop the explicit "
                f"embedding_model_id from PostgresBackend(...) and let the "
                f"agent thread the adapter's value through automatically."
            )
        self._embedding_model_id = model_id
        self._embedding_dim = dim
        if self._embed_fn is None and embed_fn is not None:
            self._embed_fn = embed_fn

    # ---- Connection lifecycle -------------------------------------------------

    async def initialize(self) -> None:
        """Open the pool, register type codecs, apply pending migrations.

        Safe to call on every boot. The migration runner consults
        ``schema_migrations`` and only runs versions not yet applied.

        Raises:
            ImportError: If the ``[postgres]`` extra is not installed.
            StorageMigrationError: If a migration fails to apply.
        """
        try:
            import asyncpg
        except ImportError as e:
            raise ImportError(_POSTGRES_EXTRA_HINT) from e

        # Bootstrap: ``pgvector`` must be installed before the pool opens,
        # because :meth:`_init_connection` registers the ``vector`` type
        # codec on every pooled connection — and an un-installed extension
        # means asyncpg's type introspection fails with
        # ``unknown type: public.vector`` before a single migration runs.
        # We install (or confirm) the extension on a bare connection here;
        # migration 0001's ``CREATE EXTENSION IF NOT EXISTS vector`` is a
        # redundant no-op after this path and stays for operators who
        # bootstrap DBs outside the SDK.
        bootstrap_conn = await asyncpg.connect(dsn=self._dsn)
        try:
            await bootstrap_conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
        finally:
            await bootstrap_conn.close()

        self._pool = await asyncpg.create_pool(
            dsn=self._dsn,
            min_size=self._min_pool_size,
            max_size=self._max_pool_size,
            init=self._init_connection,
        )

        from wisdom_layer.storage._pg_migrations import PostgresMigrationRunner

        runner = PostgresMigrationRunner(
            pool=self._pool,
            migrations_dir=_migrations_dir(),
        )
        newly_applied = await runner.apply_pending()

        logger.info(
            "Postgres backend initialized",
            extra={
                "subsystem": "storage.postgres",
                "dsn_host": self._dsn_host_hint(),
                "migrations_applied": [m.name for m in newly_applied],
            },
        )

    @staticmethod
    async def _init_connection(conn: asyncpg.Connection) -> None:
        """Register JSONB + pgvector codecs on a pooled connection.

        Runs once per connection at pool-acquire time. Without these
        codecs, asyncpg returns JSONB as ``str`` and pgvector values as
        unparsed strings, which forces every read path through manual
        deserialization.
        """
        import json

        await conn.set_type_codec(
            "jsonb",
            encoder=json.dumps,
            decoder=json.loads,
            schema="pg_catalog",
            format="text",
        )
        await conn.set_type_codec(
            "json",
            encoder=json.dumps,
            decoder=json.loads,
            schema="pg_catalog",
            format="text",
        )
        try:
            from pgvector.asyncpg import register_vector
        except ImportError as e:
            raise ImportError(_POSTGRES_EXTRA_HINT) from e
        await register_vector(conn)

    async def close(self) -> None:
        """Close the connection pool."""
        if self._pool is not None:
            await self._pool.close()
            self._pool = None

    def _pool_or_raise(self) -> asyncpg.Pool:
        if self._pool is None:
            raise BackendNotInitializedError(
                "PostgresBackend not initialized; call `await backend.initialize()` first."
            )
        return self._pool

    async def pool_stats(self) -> dict[str, int]:
        """Return live asyncpg pool stats for ops dashboards.

        Returns ``{}`` if called before ``initialize()`` so the method is
        safe to probe from health snapshots even during warmup. When the
        pool is live, reports ``size``, ``idle``, ``in_use``, ``min_size``,
        and ``max_size`` — enough for an operator to spot exhaustion
        ("in_use == max_size for N snapshots in a row") without pulling
        in a full Prometheus/OTel pipeline.

        asyncpg does not expose a public "acquire-queue depth" on Pool,
        so we deliberately omit a ``waiting`` field rather than derive
        one from private attributes. If asyncpg adds it upstream, extend
        the dict — callers must tolerate new keys.
        """
        pool = self._pool
        if pool is None:
            return {}
        size = pool.get_size()
        idle = pool.get_idle_size()
        return {
            "size": size,
            "idle": idle,
            "in_use": size - idle,
            "min_size": pool.get_min_size(),
            "max_size": pool.get_max_size(),
        }

    def _dsn_host_hint(self) -> str:
        """Best-effort extract of host[:port] from the DSN, for log lines.

        Not a full DSN parser — only used for structured-log tagging.
        """
        try:
            tail = self._dsn.split("@", 1)[-1]
            return tail.split("/", 1)[0]
        except Exception:
            return "unknown"

    # ---- Concurrency primitive ------------------------------------------------

    def agent_lock(self, agent_id: str) -> _AgentLock:
        """Return a context manager that serializes work on ``agent_id``.

        Acquires ``pg_advisory_xact_lock(hash(agent_id))`` inside a new
        transaction; the lock auto-releases on commit/rollback so callers
        cannot leak locks. Used by reconsolidation and dream-cycle paths
        to guarantee single-flight per agent across multiple workers.
        """
        return _AgentLock(self._pool_or_raise(), agent_id)

    # ---- Migration status -----------------------------------------------------

    async def migration_status(self) -> dict[str, Any]:
        from wisdom_layer.storage._pg_migrations import PostgresMigrationRunner

        runner = PostgresMigrationRunner(
            pool=self._pool_or_raise(),
            migrations_dir=_migrations_dir(),
        )
        return await runner.status()

    # ---- Memory ----------------------------------------------------------------
    #
    # The remaining 68 methods mirror BaseBackend. They are stubbed as
    # `NotImplementedError` in v0.6 Phase 1 Slice B; each is filled in by
    # the contract test suite (Task D) one behavior at a time. SQLiteBackend
    # is the reference implementation — the port is mechanical (SQL dialect
    # translation plus async/await), not redesign.

    async def store_memory(
        self,
        *,
        agent_id: str,
        tier: str,
        event_type: str,
        content: dict[str, object],
        emotional_intensity: float = 0.0,
        session_id: str | None = None,
        scope: str = "long_term",
        ttl_hours: int = 0,
        dedup_of: str | None = None,
        source_ids: list[str] | None = None,
        cycle_id: str | None = None,
        created_at: datetime | None = None,
    ) -> str:
        """Postgres port of :meth:`SQLiteBackend.store_memory`.

        Behavioral parity contract:
        - Same memory_id generator (12-char hex uuid4).
        - Same ISO8601 timestamp format for ``created_at``/``updated_at``/
          ``accessed_at`` — persisted as TEXT on both dialects so reads
          return identical Python types across backends.
        - Same embedding-dim validation: an adapter returning an off-dim
          vector is refused with ``ValueError`` before the write.
        - Identical default ``salience=0.5``.

        Dialect differences:
        - ``content`` stays a TEXT column holding a JSON string (parity
          with SQLite); ``source_ids`` is JSONB (the one JSON column the
          SDK routinely *queries*, not just round-trips).
        - ``embedding`` is a native ``VECTOR(384)`` — pgvector's asyncpg
          codec converts ``list[float]`` directly. No struct.pack bytes
          shim.
        """
        pool = self._pool_or_raise()
        memory_id = _gen_id()
        now = _now_iso()
        # Migration imports preserve the original capture timestamp via
        # ``created_at=``. ``updated_at`` and ``accessed_at`` always
        # track wall-clock so reinforcement and decay run against real
        # elapsed time.
        created_at_iso = (
            created_at.astimezone(UTC).isoformat()
            if created_at is not None
            else now
        )
        source_ids_list: list[str] = list(source_ids or [])

        embedding: list[float] | None = None
        if self._embed_fn is not None:
            content_str = json.dumps(content, default=str)
            vec = await self._embed_fn(content_str)
            if len(vec) != self._embedding_dim:
                raise ValueError(
                    f"Embedding adapter returned {len(vec)}-dim vector but "
                    f"backend is configured for {self._embedding_dim}-dim "
                    f"({self._embedding_model_id}). Refusing to write a "
                    f"row that would silently corrupt vector search."
                )
            embedding = list(vec)

        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO memories
                    (id, agent_id, tier, event_type, content, salience,
                     emotional_intensity, embedding, embedding_model_id,
                     embedding_dim, source_ids, session_id, scope, ttl_hours,
                     dedup_of, cycle_id, created_at, updated_at, accessed_at)
                    VALUES ($1, $2, $3, $4, $5, 0.5, $6, $7, $8, $9, $10,
                            $11, $12, $13, $14, $15, $16, $17, $18)""",
                memory_id,
                agent_id,
                tier,
                event_type,
                json.dumps(content, default=str),
                emotional_intensity,
                embedding,
                self._embedding_model_id,
                self._embedding_dim,
                source_ids_list,
                session_id,
                scope,
                ttl_hours,
                dedup_of,
                cycle_id,
                created_at_iso,
                now,
                now,
            )

        logger.info(
            "Memory stored",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "memory_id": memory_id,
                "tier": tier,
                "event_type": event_type,
                "session_id": session_id,
                "scope": scope,
                "dedup_of": dedup_of,
                "cycle_id": cycle_id,
                "embedding_model_id": self._embedding_model_id,
                "embedding_dim": self._embedding_dim,
                "has_embedding": embedding is not None,
            },
        )
        return memory_id

    async def search_memories(
        self,
        *,
        agent_id: str,
        query: str,
        limit: int = 5,
        min_salience: float = 0.0,
        kinds: Sequence[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Postgres port of :meth:`SQLiteBackend.search_memories`.

        Ranking parity: we use pgvector's cosine distance operator
        ``<=>`` for candidate selection, then apply the *exact same*
        recency-weighted re-rank formula as SQLite in Python before
        returning::

            combined = cosine_similarity + recency_bonus(age_seconds)

        This preserves bit-for-bit identical ordering across backends at
        the scale the v0.6 contract suite exercises. At larger corpora
        the ivfflat index (migration 0019) kicks in once the candidate
        count exceeds :attr:`AdminDefaults.postgres_ivf_threshold_rows`;
        recall loss there is the documented trade-off for ANN scale.

        Kept identical to SQLite:
        - Cross-model lexical fallback for rows captured under a stale
          embedder, returned with ``similarity=1.0``.
        - Pure-text ``LIKE`` fallback when the backend has no
          ``embed_fn``.
        - Result shape: ``{id, tier, event_type, content, salience,
          similarity, created_at}`` where ``similarity`` is the rounded
          cosine (not the recency-weighted combined score).
        """
        pool = self._pool_or_raise()

        if self._embed_fn is not None:
            query_vec = await self._embed_fn(query)
            if len(query_vec) != self._embedding_dim:
                raise ValueError(
                    f"Embedding adapter returned {len(query_vec)}-dim query "
                    f"vector but backend is configured for "
                    f"{self._embedding_dim}-dim ({self._embedding_model_id}). "
                    f"Refusing a search that would silently rank against the "
                    f"wrong embedding space."
                )

            # Fetch candidates via pgvector cosine distance. 1 - <=> is the
            # cosine similarity in pgvector's convention (distance = 1 - sim).
            # We over-fetch 4× to give the Python recency re-rank room to
            # swap near-ties, mirroring the SQLite formula behavior.
            candidate_limit = max(limit * 4, limit)
            query_vec_list = list(query_vec)
            kinds_clause_v = "AND event_type = ANY($7::text[])" if kinds else ""
            kinds_args_v: tuple[Any, ...] = (list(kinds),) if kinds else ()
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    f"""SELECT id, tier, event_type, content, salience,
                              reinforcement_count, emotional_intensity,
                              embedding, source_ids, created_at,
                              (1 - (embedding <=> $1::vector)) AS cosine_sim
                        FROM memories
                        WHERE agent_id = $2
                          AND salience >= $3
                          AND embedding_model_id = $4
                          AND embedding_dim = $5
                          AND embedding IS NOT NULL
                          AND archived_at IS NULL
                          {kinds_clause_v}
                        ORDER BY embedding <=> $1::vector
                        LIMIT $6""",
                    query_vec_list,
                    agent_id,
                    min_salience,
                    self._embedding_model_id,
                    self._embedding_dim,
                    candidate_limit,
                    *kinds_args_v,
                )

            now_dt = datetime.fromisoformat(_now_iso())
            scored: list[tuple[float, float, Any]] = []
            for row in rows:
                sim = float(row["cosine_sim"])
                created_dt = datetime.fromisoformat(row["created_at"])
                age_seconds = max((now_dt - created_dt).total_seconds(), 0.0)
                combined = sim + recency_bonus(age_seconds)
                scored.append((combined, sim, row))

            scored.sort(key=lambda x: x[0], reverse=True)

            results: list[dict[str, Any]] = []
            for _combined, sim, row in scored[:limit]:
                results.append({
                    "id": row["id"],
                    "tier": row["tier"],
                    "event_type": row["event_type"],
                    "content": json.loads(row["content"]),
                    "salience": row["salience"],
                    "similarity": round(sim, 4),
                    "created_at": row["created_at"],
                })

            remaining = limit - len(results)
            if remaining > 0:
                kinds_clause_s = "AND event_type = ANY($7::text[])" if kinds else ""
                kinds_args_s: tuple[Any, ...] = (list(kinds),) if kinds else ()
                async with pool.acquire() as conn:
                    stale_rows = await conn.fetch(
                        f"""SELECT id, tier, event_type, content, salience, created_at
                            FROM memories
                            WHERE agent_id = $1
                              AND salience >= $2
                              AND content LIKE $3
                              AND (embedding_model_id != $4 OR embedding_dim != $5)
                              AND archived_at IS NULL
                              {kinds_clause_s}
                            ORDER BY salience DESC, created_at DESC
                            LIMIT $6""",
                        agent_id,
                        min_salience,
                        f"%{query}%",
                        self._embedding_model_id,
                        self._embedding_dim,
                        remaining,
                        *kinds_args_s,
                    )
                for row in stale_rows:
                    results.append({
                        "id": row["id"],
                        "tier": row["tier"],
                        "event_type": row["event_type"],
                        "content": json.loads(row["content"]),
                        "salience": row["salience"],
                        "similarity": 1.0,
                        "created_at": row["created_at"],
                    })

            return results

        kinds_clause_t = "AND event_type = ANY($5::text[])" if kinds else ""
        kinds_args_t: tuple[Any, ...] = (list(kinds),) if kinds else ()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                f"""SELECT id, tier, event_type, content, salience, created_at
                    FROM memories
                    WHERE agent_id = $1
                      AND salience >= $2
                      AND content LIKE $3
                      AND archived_at IS NULL
                      {kinds_clause_t}
                    ORDER BY salience DESC, created_at DESC
                    LIMIT $4""",
                agent_id,
                min_salience,
                f"%{query}%",
                limit,
                *kinds_args_t,
            )

        return [
            {
                "id": row["id"],
                "tier": row["tier"],
                "event_type": row["event_type"],
                "content": json.loads(row["content"]),
                "salience": row["salience"],
                "similarity": 1.0,
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def get_reflections(
        self,
        *,
        agent_id: str,
        topic: str = "",
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        if topic and self._embed_fn:
            return await self.search_memories(
                agent_id=agent_id, query=topic, limit=limit, min_salience=0.0,
            )
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, content, source_ids, created_at
                   FROM memories
                   WHERE agent_id = $1 AND tier = 'reflective'
                   ORDER BY created_at DESC LIMIT $2""",
                agent_id, limit,
            )
        return [
            {
                "id": row["id"],
                "content": json.loads(row["content"]),
                "source_ids": row["source_ids"],
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def get_provenance(
        self, memory_id: str, *, agent_id: str
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        chain: list[dict[str, Any]] = []
        visited: set[str] = set()
        queue = [memory_id]
        async with pool.acquire() as conn:
            while queue:
                mid = queue.pop(0)
                if mid in visited:
                    continue
                visited.add(mid)
                row = await conn.fetchrow(
                    """SELECT id, tier, content, source_ids, created_at
                       FROM memories WHERE id = $1 AND agent_id = $2""",
                    mid, agent_id,
                )
                if row is None:
                    continue
                chain.append({
                    "id": row["id"],
                    "tier": row["tier"],
                    "content": json.loads(row["content"]),
                    "created_at": row["created_at"],
                })
                queue.extend(row["source_ids"] or [])
        return chain

    async def validate_memory_ids(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> set[str]:
        if not memory_ids:
            return set()
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT id FROM memories WHERE id = ANY($1::text[]) AND agent_id = $2",
                memory_ids, agent_id,
            )
        return {row["id"] for row in rows}

    async def get_memories_by_ids(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> list[dict[str, Any]]:
        if not memory_ids:
            return []
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, tier, event_type, content, salience,
                          reinforcement_count, emotional_intensity,
                          source_ids, created_at
                   FROM memories
                   WHERE id = ANY($1::text[]) AND agent_id = $2""",
                memory_ids, agent_id,
            )
        by_id: dict[str, dict[str, Any]] = {}
        for row in rows:
            d: dict[str, Any] = {
                "id": row["id"],
                "tier": row["tier"],
                "event_type": row["event_type"],
                "content": json.loads(row["content"]),
                "salience": row["salience"],
                "reinforcement_count": row["reinforcement_count"],
                "emotional_intensity": row["emotional_intensity"],
                "source_ids": row["source_ids"] or [],
                "created_at": row["created_at"],
            }
            by_id[d["id"]] = d
        return [by_id[mid] for mid in memory_ids if mid in by_id]

    async def find_near_duplicate(
        self,
        *,
        agent_id: str,
        embedding: list[float],
        threshold: float = 0.92,
    ) -> str | None:
        pool = self._pool_or_raise()
        query_vec = list(embedding)
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, 1 - (embedding <=> $1::vector) AS sim
                   FROM memories
                   WHERE agent_id = $2
                     AND embedding IS NOT NULL
                     AND embedding_model_id = $3
                     AND embedding_dim = $4
                   ORDER BY embedding <=> $1::vector
                   LIMIT 1""",
                query_vec, agent_id,
                self._embedding_model_id, self._embedding_dim,
            )
        if row is None or float(row["sim"]) < threshold:
            return None
        best_id = row["id"]
        return await self._resolve_dedup_root(agent_id, best_id)

    async def _resolve_dedup_root(self, agent_id: str, memory_id: str) -> str:
        pool = self._pool_or_raise()
        current = memory_id
        seen: set[str] = set()
        async with pool.acquire() as conn:
            while True:
                if current in seen:
                    break
                seen.add(current)
                row = await conn.fetchrow(
                    "SELECT dedup_of FROM memories WHERE id = $1 AND agent_id = $2",
                    current, agent_id,
                )
                if row is None or row["dedup_of"] is None:
                    return current
                current = row["dedup_of"]
        return current

    async def reinforce_memories(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> None:
        if not memory_ids:
            return
        pool = self._pool_or_raise()
        now = _now_iso()
        async with pool.acquire() as conn:
            for mid in memory_ids:
                await conn.execute(
                    """UPDATE memories
                       SET salience = LEAST(salience + 0.05, 1.0),
                           reinforcement_count = reinforcement_count + 1,
                           accessed_at = $1
                       WHERE id = $2 AND agent_id = $3""",
                    now, mid, agent_id,
                )
        logger.info(
            "Memories reinforced",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "memory_count": len(memory_ids),
            },
        )

    async def delete_memory(
        self,
        *,
        agent_id: str,
        memory_id: str,
    ) -> int:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            status = await conn.execute(
                "DELETE FROM memories WHERE id = $1 AND agent_id = $2",
                memory_id, agent_id,
            )
        deleted = int(status.split()[-1])
        logger.info(
            "Memory deleted",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "memory_id": memory_id,
                "deleted": deleted,
            },
        )
        return deleted

    async def delete_session_memories(
        self,
        *,
        agent_id: str,
        session_id: str,
    ) -> int:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            status = await conn.execute(
                "DELETE FROM memories WHERE agent_id = $1 AND session_id = $2",
                agent_id, session_id,
            )
        deleted = int(status.split()[-1])
        logger.info(
            "Session memories deleted",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "session_id": session_id,
                "deleted": deleted,
            },
        )
        return deleted

    async def delete_all_for_agent(
        self,
        *,
        agent_id: str,
    ) -> dict[str, int]:
        pool = self._pool_or_raise()
        tables = [
            "memories", "directives", "directive_proposals",
            "dream_reports", "journals", "critic_reviews",
            "critic_audits", "provenance_events", "scheduled_dreams",
            "health_snapshots", "cost_records",
        ]
        counts: dict[str, int] = {}
        async with pool.acquire() as conn:
            for table in tables:
                status = await conn.execute(
                    f"DELETE FROM {table} WHERE agent_id = $1",  # noqa: S608
                    agent_id,
                )
                counts[table] = int(status.split()[-1])
        logger.info(
            "All agent data deleted",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "per_table": counts,
            },
        )
        return counts

    async def delete_all_memories(
        self,
        *,
        agent_id: str,
    ) -> int:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            status = await conn.execute(
                "DELETE FROM memories WHERE agent_id = $1",
                agent_id,
            )
        count = int(status.split()[-1])
        logger.info(
            "All memories deleted",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "count": count,
            },
        )
        return count

    async def prune_expired_sessions(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id FROM memories
                   WHERE agent_id = $1
                     AND scope = 'session'
                     AND ttl_hours > 0
                     AND (created_at::timestamptz + (ttl_hours * interval '1 hour'))
                         <= NOW()""",
                agent_id,
            )
            pruned_ids = [row["id"] for row in rows]
            if pruned_ids:
                await conn.execute(
                    "DELETE FROM memories WHERE id = ANY($1::text[])",
                    pruned_ids,
                )
        logger.info(
            "Session memories pruned",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "pruned_count": len(pruned_ids),
            },
        )
        return {"pruned_count": len(pruned_ids), "pruned_ids": pruned_ids}

    async def run_decay_pass(
        self,
        *,
        agent_id: str,
        admin_defaults: AdminDefaults | None = None,
    ) -> dict[str, Any]:
        ad = admin_defaults or AdminDefaults()
        pool = self._pool_or_raise()
        now = _now_iso()
        now_dt = datetime.fromisoformat(now)

        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, event_type, emotional_intensity,
                          reinforcement_count, created_at
                   FROM memories
                   WHERE agent_id = $1 AND archived_at IS NULL""",
                agent_id,
            )

            total_examined = len(rows)
            rescored = weakened = archived = skipped_immune = 0
            rescore_updates: list[tuple[float, str]] = []
            weaken_updates: list[tuple[float, str]] = []
            archive_updates: list[str] = []

            for row in rows:
                created_dt = datetime.fromisoformat(row["created_at"])
                age_seconds = max((now_dt - created_dt).total_seconds(), 0.0)
                age_days = age_seconds / 86_400.0

                new_salience = compute_salience(
                    reinforcement_count=row["reinforcement_count"],
                    emotional_intensity=row["emotional_intensity"],
                    age_seconds=age_seconds,
                    admin_defaults=ad,
                )
                rescore_updates.append((new_salience, row["id"]))
                rescored += 1

                is_immune = (
                    row["emotional_intensity"] >= ad.emotional_immunity_threshold
                    or row["event_type"] in DECAY_EXEMPT_TYPES
                )
                if is_immune:
                    skipped_immune += 1
                    continue

                if age_days > ad.archive_days:
                    archive_updates.append(row["id"])
                    archived += 1
                elif age_days > ad.weaken_days:
                    weakened_salience = max(
                        0.0, min(new_salience * ad.decay_factor, 1.0)
                    )
                    weaken_updates.append((weakened_salience, row["id"]))
                    weakened += 1

            weakened_ids = {mid for _, mid in weaken_updates}
            for salience, mid in rescore_updates:
                if mid not in weakened_ids:
                    await conn.execute(
                        "UPDATE memories SET salience = $1, updated_at = $2 WHERE id = $3",
                        salience, now, mid,
                    )
            for salience, mid in weaken_updates:
                await conn.execute(
                    "UPDATE memories SET salience = $1, updated_at = $2 WHERE id = $3",
                    salience, now, mid,
                )
            for mid in archive_updates:
                await conn.execute(
                    "UPDATE memories SET archived_at = $1, updated_at = $2 WHERE id = $3",
                    now, now, mid,
                )

        logger.info(
            "Decay pass completed",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "total_examined": total_examined,
                "rescored": rescored,
                "weakened": weakened,
                "archived": archived,
                "skipped_immune": skipped_immune,
            },
        )
        return {
            "rescored": rescored,
            "weakened": weakened,
            "archived": archived,
            "skipped_immune": skipped_immune,
            "total_examined": total_examined,
        }

    async def rollback_cycle(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> int:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            status = await conn.execute(
                "DELETE FROM memories WHERE agent_id = $1 AND cycle_id = $2",
                agent_id, cycle_id,
            )
        deleted = int(status.split()[-1])
        logger.info(
            "Cycle rolled back",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "cycle_id": cycle_id,
                "deleted": deleted,
            },
        )
        return deleted

    async def get_consolidation_candidates(
        self,
        *,
        agent_id: str,
        limit: int = 20,
        min_salience: float = 0.4,
        tier: str = "raw",
        lookback_days: int | None = None,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            if lookback_days is None:
                rows = await conn.fetch(
                    """SELECT id, tier, event_type, content, salience,
                              reinforcement_count, emotional_intensity,
                              source_ids, created_at
                       FROM memories
                       WHERE agent_id = $1
                         AND tier = $2
                         AND salience >= $3
                         AND archived_at IS NULL
                       ORDER BY reinforcement_count DESC,
                                salience DESC,
                                created_at DESC
                       LIMIT $4""",
                    agent_id, tier, min_salience, limit,
                )
            else:
                cutoff = (
                    datetime.now(UTC) - timedelta(days=lookback_days)
                ).isoformat()
                rows = await conn.fetch(
                    """SELECT id, tier, event_type, content, salience,
                              reinforcement_count, emotional_intensity,
                              source_ids, created_at
                       FROM memories
                       WHERE agent_id = $1
                         AND tier = $2
                         AND salience >= $3
                         AND created_at >= $4
                         AND archived_at IS NULL
                       ORDER BY reinforcement_count DESC,
                                salience DESC,
                                created_at DESC
                       LIMIT $5""",
                    agent_id, tier, min_salience, cutoff, limit,
                )
        return [
            {
                "id": row["id"],
                "tier": row["tier"],
                "event_type": row["event_type"],
                "content": json.loads(row["content"]),
                "salience": row["salience"],
                "reinforcement_count": row["reinforcement_count"],
                "emotional_intensity": row["emotional_intensity"],
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def get_cycle_insights(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, content, created_at
                   FROM memories
                   WHERE agent_id = $1
                     AND tier = 'consolidated'
                     AND event_type = 'reconsolidated_insight'
                     AND cycle_id = $2
                     AND archived_at IS NULL
                   ORDER BY created_at DESC""",
                agent_id, cycle_id,
            )
        return [
            {"id": row["id"], "content": row["content"], "created_at": row["created_at"]}
            for row in rows
        ]

    async def get_unjournaled_memories(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        limit: int = 50,
        max_memories_cap: int | None = None,
    ) -> list[dict[str, Any]]:
        cap = (
            max_memories_cap
            if max_memories_cap is not None
            else AdminDefaults().journal_max_memories
        )
        effective_limit = min(limit, cap)
        pool = self._pool_or_raise()

        if since is not None:
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    """SELECT id, content, event_type, salience, created_at
                       FROM memories
                       WHERE agent_id = $1
                         AND journaled = 0
                         AND created_at >= $2
                         AND archived_at IS NULL
                       ORDER BY created_at ASC, id ASC
                       LIMIT $3""",
                    agent_id, since, effective_limit,
                )
        else:
            async with pool.acquire() as conn:
                rows = await conn.fetch(
                    """SELECT id, content, event_type, salience, created_at
                       FROM memories
                       WHERE agent_id = $1
                         AND journaled = 0
                         AND archived_at IS NULL
                       ORDER BY created_at ASC, id ASC
                       LIMIT $2""",
                    agent_id, effective_limit,
                )

        result: list[dict[str, Any]] = []
        for row in rows:
            d: dict[str, Any] = {
                "id": row["id"],
                "content": json.loads(row["content"])
                if isinstance(row["content"], str)
                else row["content"],
                "event_type": row["event_type"],
                "salience": row["salience"],
                "created_at": row["created_at"],
            }
            result.append(d)
        return result

    async def mark_memories_journaled(
        self,
        *,
        agent_id: str,
        memory_ids: list[str],
    ) -> int:
        if not memory_ids:
            return 0
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            status = await conn.execute(
                """UPDATE memories SET journaled = 1
                   WHERE id = ANY($1::text[]) AND agent_id = $2
                     AND journaled = 0""",
                memory_ids, agent_id,
            )
        return int(status.split()[-1])

    async def update_memory_embedding(
        self,
        *,
        agent_id: str,
        memory_id: str,
        embedding: list[float],
        embedding_model_id: str,
        embedding_dim: int,
    ) -> bool:
        pool = self._pool_or_raise()
        now = datetime.now(UTC).isoformat()
        async with pool.acquire() as conn:
            status = await conn.execute(
                """UPDATE memories
                   SET embedding = $1, embedding_model_id = $2,
                       embedding_dim = $3, updated_at = $4
                   WHERE id = $5 AND agent_id = $6""",
                embedding, embedding_model_id, embedding_dim,
                now, memory_id, agent_id,
            )
        return int(status.split()[-1]) > 0

    async def iter_memories_for_reembed(
        self,
        *,
        agent_id: str,
        current_model_id: str,
        batch_size: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, content, event_type
                   FROM memories
                   WHERE agent_id = $1
                     AND embedding IS NOT NULL
                     AND (embedding_model_id != $2
                          OR embedding_model_id IS NULL
                          OR embedding_model_id = '')
                   ORDER BY created_at ASC
                   LIMIT $3 OFFSET $4""",
                agent_id, current_model_id, batch_size, offset,
            )
        return [
            {
                "id": row["id"],
                "content": (
                    json.loads(row["content"])
                    if isinstance(row["content"], str)
                    else row["content"]
                ),
                "event_type": row["event_type"],
            }
            for row in rows
        ]

    async def export_memories(
        self,
        *,
        agent_id: str,
        include_session_memories: bool = True,
        tier_filter: str | None = None,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        scope_filter = "" if include_session_memories else "AND scope != 'session'"
        tier_clause = ""
        params: list[Any] = [agent_id]
        if tier_filter is not None:
            tier_clause = f"AND tier = ${len(params) + 1}"
            params.append(tier_filter)
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                f"""SELECT id, tier, event_type, content, salience,
                           reinforcement_count, emotional_intensity,
                           source_ids, session_id, scope, ttl_hours,
                           created_at, updated_at, accessed_at
                    FROM memories
                    WHERE agent_id = $1 {scope_filter}
                    {tier_clause}
                    ORDER BY created_at ASC""",  # noqa: S608
                *params,
            )
        exported: list[dict[str, Any]] = []
        for row in rows:
            exported.append({
                "id": row["id"],
                "tier": row["tier"],
                "event_type": row["event_type"],
                "content": json.loads(row["content"]),
                "salience": row["salience"],
                "reinforcement_count": row["reinforcement_count"],
                "emotional_intensity": row["emotional_intensity"],
                "source_ids": row["source_ids"] or [],
                "session_id": row["session_id"],
                "scope": row["scope"],
                "ttl_hours": row["ttl_hours"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "accessed_at": row["accessed_at"],
            })
        logger.info(
            "Memories exported",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "count": len(exported),
                "include_session": include_session_memories,
            },
        )
        return exported

    async def import_memories(
        self,
        *,
        agent_id: str,
        memories: list[dict[str, Any]],
    ) -> list[str]:
        pool = self._pool_or_raise()
        created_ids: list[str] = []
        now = _now_iso()
        async with pool.acquire() as conn:
            for mem in memories:
                memory_id = _gen_id()
                content_str = json.dumps(mem["content"], default=str)
                source_ids_list: list[str] = mem.get("source_ids", [])

                embedding: list[float] | None = mem.get("_embedding")

                await conn.execute(
                    """INSERT INTO memories
                       (id, agent_id, tier, event_type, content, salience,
                        emotional_intensity, embedding, embedding_model_id,
                        embedding_dim, source_ids, session_id, scope, ttl_hours,
                        dedup_of, cycle_id, created_at, updated_at, accessed_at)
                       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,
                               $12, $13, $14, $15, $16, $17, $18, $19)""",
                    memory_id,
                    agent_id,
                    mem.get("tier", "raw"),
                    mem["event_type"],
                    content_str,
                    mem.get("salience", 0.5),
                    mem.get("emotional_intensity", 0.0),
                    embedding,
                    self._embedding_model_id if embedding else "",
                    self._embedding_dim if embedding else 0,
                    source_ids_list,
                    mem.get("session_id"),
                    mem.get("scope", "long_term"),
                    mem.get("ttl_hours", 0),
                    None,
                    None,
                    mem.get("created_at") or now,
                    now,
                    now,
                )
                created_ids.append(memory_id)
        logger.info(
            "Memories imported",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "count": len(created_ids),
            },
        )
        return created_ids

    # ---- Directives ------------------------------------------------------------

    async def store_directive(
        self,
        *,
        agent_id: str,
        directive_id: str,
        text: str,
        content_hash: str,
        status: str = "provisional",
        embedding: list[float] | None = None,
    ) -> str:
        pool = self._pool_or_raise()
        now = _now_iso()
        emb_model = self._embedding_model_id if embedding else ""
        emb_dim = self._embedding_dim if embedding else 0
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO directives
                   (id, agent_id, text, content_hash, status, priority,
                    usage_count, embedding, embedding_model_id, embedding_dim,
                    created_at, updated_at, last_used, promoted_at)
                   VALUES ($1, $2, $3, $4, $5, 'contextual', 0, $6, $7, $8,
                           $9, $10, NULL, NULL)""",
                directive_id, agent_id, text, content_hash, status,
                embedding, emb_model, emb_dim, now, now,
            )
        logger.info(
            "Directive stored",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "directive_id": directive_id,
                "status": status,
                "has_embedding": embedding is not None,
            },
        )
        return directive_id

    async def get_directive(
        self,
        *,
        agent_id: str,
        directive_id: str,
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, agent_id, text, content_hash, status, priority,
                          usage_count, created_at, updated_at, last_used, promoted_at
                   FROM directives
                   WHERE id = $1 AND agent_id = $2""",
                directive_id, agent_id,
            )
        if row is None:
            return None
        return dict(row)

    async def list_directives(
        self,
        *,
        agent_id: str,
        include_inactive: bool = False,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            if include_inactive:
                rows = await conn.fetch(
                    """SELECT id, agent_id, text, content_hash, status, priority,
                              usage_count, created_at, updated_at, last_used, promoted_at
                       FROM directives
                       WHERE agent_id = $1
                       ORDER BY created_at""",
                    agent_id,
                )
            else:
                rows = await conn.fetch(
                    """SELECT id, agent_id, text, content_hash, status, priority,
                              usage_count, created_at, updated_at, last_used, promoted_at
                       FROM directives
                       WHERE agent_id = $1 AND status != 'inactive'
                       ORDER BY created_at""",
                    agent_id,
                )
        return [dict(row) for row in rows]

    async def count_active_directives(self, *, agent_id: str) -> int:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            val = await conn.fetchval(
                """SELECT COUNT(*) FROM directives
                   WHERE agent_id = $1 AND status != 'inactive'""",
                agent_id,
            )
        return int(val)

    async def update_directive_status(
        self,
        *,
        agent_id: str,
        directive_id: str,
        new_status: str,
        promoted_at: str | None = None,
    ) -> bool:
        pool = self._pool_or_raise()
        now = _now_iso()
        async with pool.acquire() as conn:
            if promoted_at:
                status = await conn.execute(
                    """UPDATE directives
                       SET status = $1, promoted_at = $2, updated_at = $3
                       WHERE id = $4 AND agent_id = $5""",
                    new_status, promoted_at, now, directive_id, agent_id,
                )
            else:
                status = await conn.execute(
                    """UPDATE directives
                       SET status = $1, updated_at = $2
                       WHERE id = $3 AND agent_id = $4""",
                    new_status, now, directive_id, agent_id,
                )
        return int(status.split()[-1]) > 0

    async def find_similar_directive(
        self,
        *,
        agent_id: str,
        embedding: list[float],
        threshold: float = 0.95,
    ) -> tuple[str | None, float]:
        pool = self._pool_or_raise()
        query_vec = list(embedding)
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, 1 - (embedding <=> $1::vector) AS sim
                   FROM directives
                   WHERE agent_id = $2
                     AND status != 'inactive'
                     AND embedding IS NOT NULL
                     AND embedding_model_id = $3
                     AND embedding_dim = $4
                   ORDER BY embedding <=> $1::vector
                   LIMIT 1""",
                query_vec, agent_id,
                self._embedding_model_id, self._embedding_dim,
            )
        if row is None:
            return (None, 0.0)
        sim = float(row["sim"])
        if sim < threshold:
            return (None, 0.0)
        return (row["id"], round(sim, 4))

    async def run_directive_decay(
        self,
        *,
        agent_id: str,
        usage_threshold: int,
        age_days: int,
    ) -> dict[str, Any]:
        pool = self._pool_or_raise()
        now = _now_iso()
        now_dt = datetime.fromisoformat(now)
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, usage_count, created_at
                   FROM directives
                   WHERE agent_id = $1
                     AND status IN ('provisional', 'active')""",
                agent_id,
            )
            deactivated_ids: list[str] = []
            for row in rows:
                created_dt = datetime.fromisoformat(row["created_at"])
                if created_dt.tzinfo is None:
                    created_dt = created_dt.replace(tzinfo=timezone.utc)  # noqa: UP017
                age = (now_dt - created_dt).total_seconds() / 86_400.0
                if row["usage_count"] < usage_threshold and age > age_days:
                    deactivated_ids.append(row["id"])
            if deactivated_ids:
                await conn.execute(
                    """UPDATE directives SET status = 'inactive', updated_at = $1
                       WHERE id = ANY($2::text[])""",
                    now, deactivated_ids,
                )
        logger.info(
            "Directive decay completed",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "deactivated_count": len(deactivated_ids),
            },
        )
        return {
            "deactivated_count": len(deactivated_ids),
            "deactivated_ids": deactivated_ids,
        }

    async def increment_directive_usage(
        self,
        *,
        agent_id: str,
        directive_ids: list[str],
    ) -> None:
        if not directive_ids:
            return
        pool = self._pool_or_raise()
        now = _now_iso()
        async with pool.acquire() as conn:
            for did in directive_ids:
                await conn.execute(
                    """UPDATE directives
                       SET usage_count = usage_count + 1,
                           last_used = $1,
                           updated_at = $2
                       WHERE id = $3 AND agent_id = $4""",
                    now, now, did, agent_id,
                )

    async def export_directives(
        self,
        *,
        agent_id: str,
        include_inactive: bool = True,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        inactive_filter = "" if include_inactive else "AND status != 'inactive'"
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                f"""SELECT id, text, content_hash, status, priority,
                           usage_count, created_at, updated_at,
                           last_used, promoted_at
                    FROM directives
                    WHERE agent_id = $1 {inactive_filter}
                    ORDER BY created_at ASC""",  # noqa: S608
                agent_id,
            )
        exported: list[dict[str, Any]] = []
        for row in rows:
            exported.append({
                "id": row["id"],
                "text": row["text"],
                "content_hash": row["content_hash"],
                "status": row["status"],
                "priority": row["priority"],
                "usage_count": row["usage_count"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "last_used": row["last_used"],
                "promoted_at": row["promoted_at"],
            })
        logger.info(
            "Directives exported",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "count": len(exported),
                "include_inactive": include_inactive,
            },
        )
        return exported

    async def import_directives(
        self,
        *,
        agent_id: str,
        directives: list[dict[str, Any]],
    ) -> list[str]:
        pool = self._pool_or_raise()
        created_ids: list[str] = []
        now = _now_iso()
        async with pool.acquire() as conn:
            for d in directives:
                directive_id = _gen_id()
                embedding: list[float] | None = d.get("_embedding")
                emb_model = self._embedding_model_id if embedding else ""
                emb_dim = self._embedding_dim if embedding else 0
                await conn.execute(
                    """INSERT INTO directives
                       (id, agent_id, text, content_hash, status, priority,
                        usage_count, embedding, embedding_model_id, embedding_dim,
                        created_at, updated_at, last_used, promoted_at)
                       VALUES ($1, $2, $3, $4, 'provisional', $5, 0,
                               $6, $7, $8, $9, $10, NULL, NULL)""",
                    directive_id, agent_id, d["text"], d["content_hash"],
                    d.get("priority", "contextual"),
                    embedding, emb_model, emb_dim,
                    d.get("created_at") or now, now,
                )
                created_ids.append(directive_id)
        logger.info(
            "Directives imported",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "count": len(created_ids),
            },
        )
        return created_ids

    async def reset_directives(
        self,
        *,
        agent_id: str,
    ) -> dict[str, int]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            d_status = await conn.execute(
                "DELETE FROM directives WHERE agent_id = $1", agent_id,
            )
            p_status = await conn.execute(
                "DELETE FROM directive_proposals WHERE agent_id = $1", agent_id,
            )
        counts = {
            "directives": int(d_status.split()[-1]),
            "directive_proposals": int(p_status.split()[-1]),
        }
        logger.info(
            "Directives and proposals reset",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "per_table": counts,
            },
        )
        return counts

    async def get_evolution_summary(self, *, agent_id: str) -> dict[str, Any]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            first_seen: str | None = None
            for table in ("memories", "directives", "journals"):
                row = await conn.fetchrow(
                    f"SELECT MIN(created_at) as ts FROM {table} WHERE agent_id = $1",  # noqa: S608
                    agent_id,
                )
                ts = row["ts"] if row else None
                if ts and (first_seen is None or ts < first_seen):
                    first_seen = ts

            tier_rows = await conn.fetch(
                """SELECT tier, COUNT(*) as n FROM memories
                   WHERE agent_id = $1 GROUP BY tier""",
                agent_id,
            )
            memories_by_tier = {"raw": 0, "consolidated": 0, "reflective": 0}
            for row in tier_rows:
                if row["tier"] in memories_by_tier:
                    memories_by_tier[row["tier"]] = int(row["n"])

            status_rows = await conn.fetch(
                """SELECT status, COUNT(*) as n FROM directives
                   WHERE agent_id = $1 GROUP BY status""",
                agent_id,
            )
            directives_by_status = {
                "provisional": 0, "active": 0, "permanent": 0, "inactive": 0,
            }
            for row in status_rows:
                if row["status"] in directives_by_status:
                    directives_by_status[row["status"]] = int(row["n"])

            dream_row = await conn.fetchrow(
                """SELECT COUNT(*) as n, MAX(completed_at) as last
                   FROM dream_reports WHERE agent_id = $1""",
                agent_id,
            )
            dream_count = int(dream_row["n"])
            last_dream_at = dream_row["last"]

            journal_row = await conn.fetchrow(
                "SELECT COUNT(*) as n FROM journals WHERE agent_id = $1",
                agent_id,
            )

        total_consolidated = (
            memories_by_tier["consolidated"] + memories_by_tier["reflective"]
        )
        return {
            "first_seen": first_seen,
            "memories_by_tier": memories_by_tier,
            "directives_by_status": directives_by_status,
            "dream_count": dream_count,
            "last_dream_at": last_dream_at,
            "journal_count": int(journal_row["n"]),
            "total_consolidated": total_consolidated,
        }

    # ---- Proposals -------------------------------------------------------------

    async def store_proposal(
        self,
        *,
        agent_id: str,
        proposal_id: str,
        action: str,
        text: str,
        content_hash: str,
        proposed_status: str,
        target_directive_id: str | None = None,
        reasoning: str = "",
    ) -> str:
        pool = self._pool_or_raise()
        now = _now_iso()
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO directive_proposals
                   (id, agent_id, action, text, reasoning, confidence,
                    status, source_memory_ids, content_hash,
                    proposed_status, target_directive_id,
                    created_at, resolved_at, resolved_by)
                   VALUES ($1, $2, $3, $4, $5, 1.0,
                           'pending', '[]'::jsonb, $6,
                           $7, $8,
                           $9, NULL, NULL)""",
                proposal_id, agent_id, action, text, reasoning,
                content_hash, proposed_status, target_directive_id, now,
            )
        logger.info(
            "Directive proposal stored",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "proposal_id": proposal_id,
                "action": action,
            },
        )
        return proposal_id

    async def get_proposal(
        self,
        *,
        agent_id: str,
        proposal_id: str,
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, agent_id, action, text, reasoning, confidence,
                          status, source_memory_ids, content_hash,
                          proposed_status, target_directive_id,
                          created_at, resolved_at, resolved_by
                   FROM directive_proposals
                   WHERE id = $1 AND agent_id = $2""",
                proposal_id, agent_id,
            )
        if row is None:
            return None
        d = dict(row)
        if isinstance(d.get("resolved_by"), dict):
            d["resolved_by"] = json.dumps(d["resolved_by"])
        if isinstance(d.get("source_memory_ids"), list):
            d["source_memory_ids"] = json.dumps(d["source_memory_ids"])
        return d

    async def list_proposals(self, *, agent_id: str) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, agent_id, action, text, reasoning, confidence,
                          status, source_memory_ids, content_hash,
                          proposed_status, target_directive_id,
                          created_at, resolved_at, resolved_by
                   FROM directive_proposals
                   WHERE agent_id = $1 AND status = 'pending'
                   ORDER BY created_at""",
                agent_id,
            )
        results: list[dict[str, Any]] = []
        for row in rows:
            d = dict(row)
            if isinstance(d.get("resolved_by"), dict):
                d["resolved_by"] = json.dumps(d["resolved_by"])
            if isinstance(d.get("source_memory_ids"), list):
                d["source_memory_ids"] = json.dumps(d["source_memory_ids"])
            results.append(d)
        return results

    async def approve_proposal(
        self,
        proposal_id: str,
        *,
        agent_id: str,
        directive_id: str,
        embedding: list[float] | None = None,
        resolved_by: str = "",
    ) -> dict[str, Any]:
        pool = self._pool_or_raise()
        now = _now_iso()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, action, text, content_hash, status,
                          proposed_status, target_directive_id
                   FROM directive_proposals
                   WHERE id = $1 AND agent_id = $2""",
                proposal_id, agent_id,
            )
            if row is None:
                msg = f"Proposal {proposal_id} not found for agent {agent_id}"
                raise ValueError(msg)
            if row["status"] != "pending":
                msg = (
                    f"Proposal {proposal_id} is already resolved "
                    f"(status='{row['status']}')"
                )
                raise ValueError(msg)

            action = row["action"]
            result: dict[str, Any]

            if action == "add":
                emb_model = self._embedding_model_id if embedding else ""
                emb_dim = self._embedding_dim if embedding else 0
                await conn.execute(
                    """INSERT INTO directives
                       (id, agent_id, text, content_hash, status, priority,
                        usage_count, embedding, embedding_model_id, embedding_dim,
                        created_at, updated_at, last_used, promoted_at)
                       VALUES ($1, $2, $3, $4, $5, 'contextual', 0,
                               $6, $7, $8, $9, $10, NULL, NULL)""",
                    directive_id, agent_id, row["text"], row["content_hash"],
                    row["proposed_status"],
                    embedding, emb_model, emb_dim, now, now,
                )
                result = {
                    "action": "add",
                    "directive_id": directive_id,
                    "status": row["proposed_status"],
                }

            elif action == "promote":
                target_id = row["target_directive_id"]
                if not target_id:
                    msg = f"Proposal {proposal_id} has no target_directive_id"
                    raise ValueError(msg)
                target = await conn.fetchrow(
                    "SELECT id, status FROM directives WHERE id = $1 AND agent_id = $2",
                    target_id, agent_id,
                )
                if target is None:
                    resolved_json = {
                        "actor": "system",
                        "method": "stale",
                        "reason": "target_missing",
                    }
                    await conn.execute(
                        """UPDATE directive_proposals
                           SET status = 'rejected', resolved_at = $1, resolved_by = $2
                           WHERE id = $3 AND agent_id = $4""",
                        now, resolved_json, proposal_id, agent_id,
                    )
                    msg = f"Target directive '{target_id}' no longer exists. Proposal marked stale."
                    raise ValueError(msg)

                new_status = row["proposed_status"]
                promoted_ts = now if new_status == "permanent" else None
                if promoted_ts:
                    await conn.execute(
                        """UPDATE directives
                           SET status = $1, promoted_at = $2, updated_at = $3
                           WHERE id = $4 AND agent_id = $5""",
                        new_status, promoted_ts, now, target_id, agent_id,
                    )
                else:
                    await conn.execute(
                        """UPDATE directives SET status = $1, updated_at = $2
                           WHERE id = $3 AND agent_id = $4""",
                        new_status, now, target_id, agent_id,
                    )
                result = {
                    "action": "promote",
                    "directive_id": target_id,
                    "status": new_status,
                }

            elif action == "deactivate":
                target_id = row["target_directive_id"]
                if not target_id:
                    msg = f"Proposal {proposal_id} has no target_directive_id"
                    raise ValueError(msg)
                target = await conn.fetchrow(
                    "SELECT id, status FROM directives WHERE id = $1 AND agent_id = $2",
                    target_id, agent_id,
                )
                if target is None:
                    resolved_json = {
                        "actor": "system",
                        "method": "stale",
                        "reason": "target_missing",
                    }
                    await conn.execute(
                        """UPDATE directive_proposals
                           SET status = 'rejected', resolved_at = $1, resolved_by = $2
                           WHERE id = $3 AND agent_id = $4""",
                        now, resolved_json, proposal_id, agent_id,
                    )
                    msg = (
                        f"Target directive '{target_id}' no longer exists."
                        " Proposal marked stale."
                    )
                    raise ValueError(msg)
                if target["status"] == "inactive":
                    resolved_json = {
                        "actor": "system",
                        "method": "stale",
                        "reason": "already_inactive",
                    }
                    await conn.execute(
                        """UPDATE directive_proposals
                           SET status = 'rejected', resolved_at = $1, resolved_by = $2
                           WHERE id = $3 AND agent_id = $4""",
                        now, resolved_json, proposal_id, agent_id,
                    )
                    msg = (
                        f"Target directive '{target_id}' is already inactive."
                        " Proposal marked stale."
                    )
                    raise ValueError(msg)
                await conn.execute(
                    """UPDATE directives SET status = 'inactive', updated_at = $1
                       WHERE id = $2 AND agent_id = $3""",
                    now, target_id, agent_id,
                )
                result = {
                    "action": "deactivate",
                    "directive_id": target_id,
                    "status": "inactive",
                }
            else:
                msg = f"Unknown proposal action: '{action}'"
                raise ValueError(msg)

            resolved_by_val: Any = None
            if resolved_by:
                try:
                    resolved_by_val = json.loads(resolved_by)
                except json.JSONDecodeError:
                    resolved_by_val = {"actor": "operator", "method": "manual", "raw": resolved_by}
            else:
                resolved_by_val = {"actor": "operator", "method": "manual"}

            await conn.execute(
                """UPDATE directive_proposals
                   SET status = 'approved', resolved_at = $1, resolved_by = $2
                   WHERE id = $3 AND agent_id = $4""",
                now, resolved_by_val, proposal_id, agent_id,
            )

        logger.info(
            "Directive proposal approved",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "proposal_id": proposal_id,
                "action": action,
            },
        )
        return result

    async def reject_proposal(
        self,
        proposal_id: str,
        *,
        agent_id: str,
        reason: str = "",
        resolved_by: str = "",
    ) -> None:
        pool = self._pool_or_raise()
        now = _now_iso()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT id, status FROM directive_proposals WHERE id = $1 AND agent_id = $2",
                proposal_id, agent_id,
            )
            if row is None:
                msg = f"Proposal {proposal_id} not found for agent {agent_id}"
                raise ValueError(msg)
            if row["status"] != "pending":
                msg = (
                    f"Proposal {proposal_id} is already resolved "
                    f"(status='{row['status']}')"
                )
                raise ValueError(msg)

            resolved_by_val: Any
            if resolved_by:
                try:
                    resolved_by_val = json.loads(resolved_by)
                except json.JSONDecodeError:
                    resolved_by_val = {"actor": "operator", "method": "manual", "reason": reason}
            else:
                resolved_by_val = {"actor": "operator", "method": "manual", "reason": reason}

            await conn.execute(
                """UPDATE directive_proposals
                   SET status = 'rejected', resolved_at = $1, resolved_by = $2
                   WHERE id = $3 AND agent_id = $4""",
                now, resolved_by_val, proposal_id, agent_id,
            )

    # ---- Critic reviews --------------------------------------------------------

    async def store_review(
        self,
        *,
        agent_id: str,
        review_id: str,
        output_text: str,
        context: dict[str, Any] | None,
        risk_level: str,
        flags: list[str],
        rationale: str,
        pass_through: bool,
        directive_ids: list[str],
        created_at: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO critic_reviews
                   (id, agent_id, output_text, context_json, risk_level,
                    flags_json, rationale, pass_through, directive_ids_json,
                    created_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)""",
                review_id, agent_id, output_text, context, risk_level,
                flags, rationale, 1 if pass_through else 0, directive_ids,
                created_at,
            )
        logger.info(
            "Critic review stored",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "review_id": review_id,
                "risk_level": risk_level,
            },
        )

    def _row_to_review(self, row: Any) -> dict[str, Any]:
        return {
            "id": row["id"],
            "agent_id": row["agent_id"],
            "output_text": row["output_text"],
            "context": row["context_json"],
            "risk_level": row["risk_level"],
            "flags": (
                row["flags_json"]
                if isinstance(row["flags_json"], list)
                else json.loads(row["flags_json"])
            ),
            "rationale": row["rationale"],
            "pass_through": bool(row["pass_through"]),
            "directive_ids": (
                row["directive_ids_json"]
                if isinstance(row["directive_ids_json"], list)
                else json.loads(row["directive_ids_json"])
            ),
            "created_at": row["created_at"],
        }

    async def get_reviews(
        self,
        *,
        agent_id: str,
        limit: int = 20,
        risk_level: str | None = None,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            if risk_level is not None:
                rows = await conn.fetch(
                    """SELECT id, agent_id, output_text, context_json,
                              risk_level, flags_json, rationale, pass_through,
                              directive_ids_json, created_at
                       FROM critic_reviews
                       WHERE agent_id = $1 AND risk_level = $2
                       ORDER BY created_at DESC LIMIT $3""",
                    agent_id, risk_level, limit,
                )
            else:
                rows = await conn.fetch(
                    """SELECT id, agent_id, output_text, context_json,
                              risk_level, flags_json, rationale, pass_through,
                              directive_ids_json, created_at
                       FROM critic_reviews
                       WHERE agent_id = $1
                       ORDER BY created_at DESC LIMIT $2""",
                    agent_id, limit,
                )
        return [self._row_to_review(row) for row in rows]

    async def get_review(
        self,
        review_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, agent_id, output_text, context_json,
                          risk_level, flags_json, rationale, pass_through,
                          directive_ids_json, created_at
                   FROM critic_reviews
                   WHERE id = $1 AND agent_id = $2""",
                review_id, agent_id,
            )
        if row is None:
            return None
        return self._row_to_review(row)

    # ---- Critic audits ---------------------------------------------------------

    async def store_audit(
        self,
        *,
        agent_id: str,
        audit_id: str,
        coherence_score: float,
        is_coherent: bool,
        contradictions: list[dict[str, str]],
        summary: str,
        directive_ids: list[str],
        directive_count: int,
        created_at: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO critic_audits
                   (id, agent_id, coherence_score, is_coherent,
                    contradictions_json, summary, directive_ids_json,
                    directive_count, created_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)""",
                audit_id, agent_id, coherence_score,
                1 if is_coherent else 0, contradictions,
                summary, directive_ids, directive_count, created_at,
            )
        logger.info(
            "Coherence audit stored",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "audit_id": audit_id,
                "coherence_score": coherence_score,
            },
        )

    def _row_to_audit(self, row: Any) -> dict[str, Any]:
        contradictions = row["contradictions_json"]
        if isinstance(contradictions, str):
            contradictions = json.loads(contradictions)
        directive_ids = row["directive_ids_json"]
        if isinstance(directive_ids, str):
            directive_ids = json.loads(directive_ids)
        return {
            "id": row["id"],
            "agent_id": row["agent_id"],
            "coherence_score": row["coherence_score"],
            "is_coherent": bool(row["is_coherent"]),
            "contradictions": contradictions,
            "summary": row["summary"],
            "directive_ids": directive_ids,
            "directive_count": row["directive_count"],
            "created_at": row["created_at"],
        }

    async def get_audits(
        self,
        *,
        agent_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, agent_id, coherence_score, is_coherent,
                          contradictions_json, summary, directive_ids_json,
                          directive_count, created_at
                   FROM critic_audits
                   WHERE agent_id = $1
                   ORDER BY created_at DESC LIMIT $2""",
                agent_id, limit,
            )
        return [self._row_to_audit(row) for row in rows]

    async def get_audit(
        self,
        audit_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, agent_id, coherence_score, is_coherent,
                          contradictions_json, summary, directive_ids_json,
                          directive_count, created_at
                   FROM critic_audits
                   WHERE id = $1 AND agent_id = $2""",
                audit_id, agent_id,
            )
        if row is None:
            return None
        return self._row_to_audit(row)

    # ---- Journals --------------------------------------------------------------

    async def store_journal(
        self,
        *,
        agent_id: str,
        journal_id: str,
        content: str,
        memory_ids: list[str],
        created_at: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn, conn.transaction():
            await conn.execute(
                """INSERT INTO journals
                   (id, agent_id, content, memory_ids_json, created_at)
                   VALUES ($1, $2, $3, $4, $5)""",
                journal_id, agent_id, content, memory_ids, created_at,
            )
            if memory_ids:
                await conn.execute(
                    """UPDATE memories SET journaled = 1
                       WHERE id = ANY($1::text[]) AND agent_id = $2""",
                    memory_ids, agent_id,
                )
        logger.info(
            "Journal stored",
            extra={
                "subsystem": "storage.postgres",
                "agent_id": agent_id,
                "journal_id": journal_id,
                "memory_count": len(memory_ids),
            },
        )

    async def get_journals(
        self,
        *,
        agent_id: str,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, agent_id, content, memory_ids_json, created_at
                   FROM journals
                   WHERE agent_id = $1
                   ORDER BY created_at DESC LIMIT $2""",
                agent_id, limit,
            )
        return [
            {
                "id": row["id"],
                "agent_id": row["agent_id"],
                "content": row["content"],
                "memory_ids": (
                    row["memory_ids_json"]
                    if isinstance(row["memory_ids_json"], list)
                    else json.loads(row["memory_ids_json"])
                ),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    async def get_journal(
        self,
        journal_id: str,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, agent_id, content, memory_ids_json, created_at
                   FROM journals
                   WHERE id = $1 AND agent_id = $2""",
                journal_id, agent_id,
            )
        if row is None:
            return None
        return {
            "id": row["id"],
            "agent_id": row["agent_id"],
            "content": row["content"],
            "memory_ids": (
                row["memory_ids_json"]
                if isinstance(row["memory_ids_json"], list)
                else json.loads(row["memory_ids_json"])
            ),
            "created_at": row["created_at"],
        }

    # ---- Dream history ---------------------------------------------------------

    async def store_dream_report(
        self,
        *,
        agent_id: str,
        report_id: str,
        cycle_id: str,
        started_at: str,
        completed_at: str,
        status: str,
        steps: str,
        duration_ms: int,
    ) -> None:
        pool = self._pool_or_raise()
        steps_val = json.loads(steps) if isinstance(steps, str) else steps
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO dream_reports
                   (id, agent_id, cycle_id, started_at, completed_at,
                    status, steps, duration_ms)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8)""",
                report_id, agent_id, cycle_id,
                started_at, completed_at,
                status, steps_val, duration_ms,
            )

    async def get_dream_report(
        self, *, agent_id: str, cycle_id: str
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT id, cycle_id, agent_id, started_at, completed_at,
                          status, steps, duration_ms
                   FROM dream_reports
                   WHERE agent_id = $1 AND cycle_id = $2""",
                agent_id, cycle_id,
            )
        if row is None:
            return None
        return self._deserialize_dream_report(row)

    async def get_dream_history(
        self, *, agent_id: str, limit: int = 30
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT id, cycle_id, agent_id, started_at, completed_at,
                          status, steps, duration_ms
                   FROM dream_reports
                   WHERE agent_id = $1
                   ORDER BY started_at DESC, id DESC LIMIT $2""",
                agent_id, limit,
            )
        return [self._deserialize_dream_report(row) for row in rows]

    @staticmethod
    def _deserialize_dream_report(row: Any) -> dict[str, Any]:
        steps = row["steps"]
        if isinstance(steps, str):
            steps = json.loads(steps)
        return {
            "id": row["id"],
            "cycle_id": row["cycle_id"],
            "agent_id": row["agent_id"],
            "started_at": row["started_at"],
            "completed_at": row["completed_at"],
            "status": row["status"],
            "steps": steps,
            "duration_ms": row["duration_ms"],
        }

    # ---- Dream checkpointing ---------------------------------------------------

    async def save_dream_checkpoint(
        self,
        *,
        cycle_id: str,
        agent_id: str,
        last_completed_phase: str,
        state_blob: str,
        created_at: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO dream_cycle_checkpoints
                   (cycle_id, agent_id, last_completed_phase, state_blob, created_at)
                   VALUES ($1, $2, $3, $4, $5)
                   ON CONFLICT (cycle_id) DO UPDATE SET
                       last_completed_phase = EXCLUDED.last_completed_phase,
                       state_blob = EXCLUDED.state_blob,
                       created_at = EXCLUDED.created_at""",
                cycle_id, agent_id, last_completed_phase, state_blob, created_at,
            )

    async def load_dream_checkpoint(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT cycle_id, last_completed_phase, state_blob, created_at
                   FROM dream_cycle_checkpoints
                   WHERE agent_id = $1
                   ORDER BY created_at DESC
                   LIMIT 1""",
                agent_id,
            )
        if row is None:
            return None
        return {
            "cycle_id": row["cycle_id"],
            "last_completed_phase": row["last_completed_phase"],
            "state_blob": row["state_blob"],
            "created_at": row["created_at"],
        }

    async def delete_dream_checkpoint(
        self,
        *,
        cycle_id: str,
        agent_id: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            await conn.execute(
                """DELETE FROM dream_cycle_checkpoints
                   WHERE cycle_id = $1 AND agent_id = $2""",
                cycle_id, agent_id,
            )

    # ---- Scheduled dreams ------------------------------------------------------

    async def save_scheduled_dream(
        self,
        *,
        agent_id: str,
        interval_hours: float,
        at_time: str | None,
        paused: bool,
        ignore_budget: bool,
        next_run: str,
        last_run: str | None,
        created_at: str,
        updated_at: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO scheduled_dreams
                       (agent_id, interval_hours, at_time, paused, ignore_budget,
                        next_run, last_run, created_at, updated_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                   ON CONFLICT(agent_id) DO UPDATE SET
                       interval_hours=EXCLUDED.interval_hours,
                       at_time=EXCLUDED.at_time,
                       paused=EXCLUDED.paused,
                       ignore_budget=EXCLUDED.ignore_budget,
                       next_run=EXCLUDED.next_run,
                       last_run=EXCLUDED.last_run,
                       updated_at=EXCLUDED.updated_at""",
                agent_id, interval_hours, at_time,
                1 if paused else 0, 1 if ignore_budget else 0,
                next_run, last_run, created_at, updated_at,
            )

    async def load_scheduled_dream(
        self,
        *,
        agent_id: str,
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT agent_id, interval_hours, at_time, paused, ignore_budget,
                          next_run, last_run, created_at, updated_at
                   FROM scheduled_dreams
                   WHERE agent_id = $1""",
                agent_id,
            )
        if row is None:
            return None
        return {
            "agent_id": row["agent_id"],
            "interval_hours": row["interval_hours"],
            "at_time": row["at_time"],
            "paused": bool(row["paused"]),
            "ignore_budget": bool(row["ignore_budget"]),
            "next_run": row["next_run"],
            "last_run": row["last_run"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    async def delete_scheduled_dream(
        self,
        *,
        agent_id: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            await conn.execute(
                "DELETE FROM scheduled_dreams WHERE agent_id = $1",
                agent_id,
            )

    # ---- Provenance event log --------------------------------------------------

    async def append_provenance_event(
        self,
        *,
        event_id: str,
        agent_id: str,
        event_type: str,
        entity_type: str,
        entity_id: str,
        parent_event_id: str | None,
        payload: dict[str, Any],
        created_at: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO provenance_events
                   (event_id, agent_id, event_type, entity_type, entity_id,
                    parent_event_id, payload, created_at)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8)""",
                event_id, agent_id, event_type, entity_type, entity_id,
                parent_event_id, payload, created_at,
            )

    async def get_provenance_event(
        self,
        *,
        agent_id: str,
        event_id: str,
    ) -> dict[str, Any] | None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                """SELECT event_id, agent_id, event_type, entity_type, entity_id,
                          parent_event_id, payload, created_at
                   FROM provenance_events
                   WHERE agent_id = $1 AND event_id = $2""",
                agent_id, event_id,
            )
        if row is None:
            return None
        return self._row_to_provenance_event(row)

    async def query_provenance_events_by_entity(
        self,
        *,
        agent_id: str,
        entity_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT event_id, agent_id, event_type, entity_type, entity_id,
                          parent_event_id, payload, created_at
                   FROM provenance_events
                   WHERE agent_id = $1 AND entity_id = $2
                   ORDER BY created_at ASC, event_id ASC
                   LIMIT $3""",
                agent_id, entity_id, limit,
            )
        return [self._row_to_provenance_event(row) for row in rows]

    async def query_provenance_events_by_time(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        limit: int = 500,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        clauses = ["agent_id = $1"]
        params: list[Any] = [agent_id]
        idx = 2
        if since is not None:
            clauses.append(f"created_at >= ${idx}")
            params.append(since)
            idx += 1
        if until is not None:
            clauses.append(f"created_at <= ${idx}")
            params.append(until)
            idx += 1
        where = " AND ".join(clauses)
        params.append(limit)
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                f"""SELECT event_id, agent_id, event_type, entity_type, entity_id,
                           parent_event_id, payload, created_at
                    FROM provenance_events
                    WHERE {where}
                    ORDER BY created_at ASC, event_id ASC
                    LIMIT ${idx}""",  # noqa: S608
                *params,
            )
        return [self._row_to_provenance_event(row) for row in rows]

    @staticmethod
    def _row_to_provenance_event(row: Any) -> dict[str, Any]:
        payload = row["payload"]
        if isinstance(payload, str):
            try:
                payload = json.loads(payload) if payload else {}
            except json.JSONDecodeError:
                payload = {"_decode_error": True, "raw": payload}
        elif payload is None:
            payload = {}
        return {
            "event_id": row["event_id"],
            "agent_id": row["agent_id"],
            "event_type": row["event_type"],
            "entity_type": row["entity_type"],
            "entity_id": row["entity_id"],
            "parent_event_id": row["parent_event_id"],
            "payload": payload,
            "created_at": row["created_at"],
        }

    # ---- Cost ledger -----------------------------------------------------------

    async def append_cost_record(
        self,
        *,
        record_id: str,
        agent_id: str,
        model_id: str,
        category: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float,
        cycle_id: str | None,
        event_id: str | None,
        purpose: str,
        created_at: str,
    ) -> None:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO cost_records
                       (id, agent_id, model_id, tier, purpose,
                        input_tokens, output_tokens, cost_usd,
                        cycle_id, created_at, event_id, category)
                   VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)""",
                record_id, agent_id, model_id, "mid", purpose,
                int(input_tokens), int(output_tokens), float(cost_usd),
                cycle_id, created_at, event_id, category,
            )

    async def query_cost_records(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        category: str | None = None,
        cycle_id: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        clauses = ["agent_id = $1"]
        params: list[Any] = [agent_id]
        idx = 2
        if since is not None:
            clauses.append(f"created_at >= ${idx}")
            params.append(since)
            idx += 1
        if until is not None:
            clauses.append(f"created_at <= ${idx}")
            params.append(until)
            idx += 1
        if category is not None:
            clauses.append(f"category = ${idx}")
            params.append(category)
            idx += 1
        if cycle_id is not None:
            clauses.append(f"cycle_id = ${idx}")
            params.append(cycle_id)
            idx += 1
        where_sql = " AND ".join(clauses)
        sql = f"""SELECT id, agent_id, model_id, tier, purpose,
                         input_tokens, output_tokens, cost_usd,
                         cycle_id, created_at, event_id, category
                  FROM cost_records
                  WHERE {where_sql}
                  ORDER BY created_at ASC, id ASC"""  # noqa: S608
        if limit is not None:
            sql += f" LIMIT ${idx}"
            params.append(int(limit))
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        return [
            {
                "id": row["id"],
                "agent_id": row["agent_id"],
                "model_id": row["model_id"],
                "tier": row["tier"],
                "purpose": row["purpose"],
                "input_tokens": int(row["input_tokens"] or 0),
                "output_tokens": int(row["output_tokens"] or 0),
                "cost_usd": float(row["cost_usd"] or 0.0),
                "cycle_id": row["cycle_id"],
                "created_at": row["created_at"],
                "event_id": row["event_id"],
                "category": row["category"] or "",
            }
            for row in rows
        ]

    async def sum_cost_by_cycle(
        self,
        *,
        agent_id: str,
        cycle_id: str,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT category, model_id,
                          COALESCE(SUM(input_tokens), 0) AS input_tokens,
                          COALESCE(SUM(output_tokens), 0) AS output_tokens,
                          COALESCE(SUM(cost_usd), 0.0) AS cost_usd,
                          COUNT(*) AS calls
                   FROM cost_records
                   WHERE agent_id = $1 AND cycle_id = $2
                   GROUP BY category, model_id
                   ORDER BY category ASC, model_id ASC""",
                agent_id, cycle_id,
            )
        return [
            {
                "category": row["category"] or "",
                "model_id": row["model_id"] or "",
                "input_tokens": int(row["input_tokens"]),
                "output_tokens": int(row["output_tokens"]),
                "cost_usd": float(row["cost_usd"]),
                "calls": int(row["calls"]),
            }
            for row in rows
        ]

    async def cost_summary_aggregate(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
    ) -> dict[str, Any]:
        pool = self._pool_or_raise()
        clauses = ["agent_id = $1"]
        params: list[Any] = [agent_id]
        idx = 2
        if since is not None:
            clauses.append(f"created_at >= ${idx}")
            params.append(since)
            idx += 1
        if until is not None:
            clauses.append(f"created_at <= ${idx}")
            params.append(until)
            idx += 1
        where_sql = " AND ".join(clauses)

        async with pool.acquire() as conn:
            total_row = await conn.fetchrow(
                f"""SELECT COALESCE(SUM(cost_usd), 0.0) AS cost_usd,
                           COALESCE(SUM(input_tokens), 0) AS input_tokens,
                           COALESCE(SUM(output_tokens), 0) AS output_tokens,
                           COUNT(*) AS calls
                    FROM cost_records WHERE {where_sql}""",  # noqa: S608
                *params,
            )
            by_cat_rows = await conn.fetch(
                f"""SELECT COALESCE(category, '') AS category,
                           COALESCE(SUM(cost_usd), 0.0) AS cost_usd,
                           COALESCE(SUM(input_tokens), 0) AS input_tokens,
                           COALESCE(SUM(output_tokens), 0) AS output_tokens,
                           COUNT(*) AS calls
                    FROM cost_records WHERE {where_sql}
                    GROUP BY category""",  # noqa: S608
                *params,
            )
            by_model_rows = await conn.fetch(
                f"""SELECT model_id,
                           COALESCE(SUM(cost_usd), 0.0) AS cost_usd,
                           COALESCE(SUM(input_tokens), 0) AS input_tokens,
                           COALESCE(SUM(output_tokens), 0) AS output_tokens,
                           COUNT(*) AS calls
                    FROM cost_records WHERE {where_sql}
                    GROUP BY model_id""",  # noqa: S608
                *params,
            )

        return {
            "total_cost_usd": float(total_row["cost_usd"]),
            "total_input_tokens": int(total_row["input_tokens"]),
            "total_output_tokens": int(total_row["output_tokens"]),
            "total_calls": int(total_row["calls"]),
            "by_category": {
                (row["category"] or ""): {
                    "cost_usd": float(row["cost_usd"]),
                    "input_tokens": int(row["input_tokens"]),
                    "output_tokens": int(row["output_tokens"]),
                    "calls": int(row["calls"]),
                }
                for row in by_cat_rows
            },
            "by_model": {
                row["model_id"]: {
                    "cost_usd": float(row["cost_usd"]),
                    "input_tokens": int(row["input_tokens"]),
                    "output_tokens": int(row["output_tokens"]),
                    "calls": int(row["calls"]),
                }
                for row in by_model_rows
            },
        }

    # ---- Health / Analytics ----------------------------------------------------

    async def get_health(self, *, agent_id: str) -> dict[str, Any]:
        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            total = await conn.fetchval(
                "SELECT COUNT(*) FROM memories WHERE agent_id = $1", agent_id,
            )
            by_tier = await conn.fetch(
                """SELECT tier, COUNT(*) as n FROM memories
                   WHERE agent_id = $1 GROUP BY tier""",
                agent_id,
            )
            avg_salience = await conn.fetchval(
                "SELECT AVG(salience) FROM memories WHERE agent_id = $1", agent_id,
            )
            active_directives = await conn.fetchval(
                """SELECT COUNT(*) FROM directives
                   WHERE agent_id = $1 AND status != 'inactive'""",
                agent_id,
            )
            pending_proposals = await conn.fetchval(
                """SELECT COUNT(*) FROM directive_proposals
                   WHERE agent_id = $1 AND status = 'pending'""",
                agent_id,
            )
            last_dream = await conn.fetchrow(
                """SELECT completed_at FROM dream_reports
                   WHERE agent_id = $1
                   ORDER BY completed_at DESC LIMIT 1""",
                agent_id,
            )
        return {
            "total_memories": int(total),
            "memories_by_tier": {row["tier"]: int(row["n"]) for row in by_tier},
            "average_salience": round(float(avg_salience or 0.0), 3),
            "active_directives": int(active_directives),
            "pending_proposals": int(pending_proposals),
            "last_dream_cycle": last_dream["completed_at"] if last_dream else None,
            "memory_load": min(int(total) / 10000.0, 1.0),
            "drift_risk": 0.0,
        }

    async def get_health_report_stats(
        self, *, agent_id: str, window_days: int = 7
    ) -> dict[str, Any]:
        pool = self._pool_or_raise()
        now = datetime.now(UTC)
        since = (now - timedelta(days=window_days)).isoformat()

        async with pool.acquire() as conn:
            total_memories = int(await conn.fetchval(
                "SELECT COUNT(*) FROM memories WHERE agent_id = $1", agent_id,
            ))
            tier_rows = await conn.fetch(
                """SELECT tier, COUNT(*) as n FROM memories
                   WHERE agent_id = $1 GROUP BY tier""",
                agent_id,
            )
            by_tier = {row["tier"]: int(row["n"]) for row in tier_rows}

            avg_salience = float(await conn.fetchval(
                "SELECT COALESCE(AVG(salience), 0.0) FROM memories WHERE agent_id = $1",
                agent_id,
            ))
            captures_7d = int(await conn.fetchval(
                """SELECT COUNT(*) FROM memories
                   WHERE agent_id = $1 AND created_at >= $2""",
                agent_id, since,
            ))
            dedup_count_7d = int(await conn.fetchval(
                """SELECT COUNT(*) FROM memories
                   WHERE agent_id = $1 AND created_at >= $2
                     AND dedup_of IS NOT NULL""",
                agent_id, since,
            ))
            dedup_rate_7d = dedup_count_7d / captures_7d if captures_7d > 0 else 0.0

            reinforced_count = int(await conn.fetchval(
                """SELECT COUNT(*) FROM memories
                   WHERE agent_id = $1 AND reinforcement_count > 0""",
                agent_id,
            ))
            event_type_rows = await conn.fetch(
                """SELECT event_type, COUNT(*) as n FROM memories
                   WHERE agent_id = $1 AND event_type != ''
                   GROUP BY event_type""",
                agent_id,
            )
            event_type_counts = {row["event_type"]: int(row["n"]) for row in event_type_rows}

            journal_count = int(await conn.fetchval(
                "SELECT COUNT(*) FROM journals WHERE agent_id = $1", agent_id,
            ))

            status_rows = await conn.fetch(
                """SELECT status, COUNT(*) as n FROM directives
                   WHERE agent_id = $1 GROUP BY status""",
                agent_id,
            )
            provisional_count = active_count = permanent_count = inactive_count = 0
            for row in status_rows:
                status = row["status"]
                n = int(row["n"])
                if status == "inactive":
                    inactive_count += n
                elif status == "provisional":
                    provisional_count += n
                elif status == "permanent":
                    permanent_count += n
                else:
                    active_count += n

            demotions_7d = int(await conn.fetchval(
                """SELECT COUNT(*) FROM directives
                   WHERE agent_id = $1 AND status = 'inactive'
                     AND updated_at IS NOT NULL AND updated_at >= $2""",
                agent_id, since,
            ))
            directive_updates_7d = int(await conn.fetchval(
                """SELECT COUNT(*) FROM directives
                   WHERE agent_id = $1 AND updated_at IS NOT NULL
                     AND updated_at >= $2""",
                agent_id, since,
            ))
            demotion_rate_7d = (
                demotions_7d / directive_updates_7d
                if directive_updates_7d > 0 else 0.0
            )

            age_rows = await conn.fetch(
                """SELECT created_at FROM directives
                   WHERE agent_id = $1 AND status != 'inactive'""",
                agent_id,
            )
            avg_age_days = 0.0
            if age_rows:
                ages: list[float] = []
                for row in age_rows:
                    try:
                        created = datetime.fromisoformat(row["created_at"])
                        if created.tzinfo is None:
                            created = created.replace(tzinfo=UTC)
                        ages.append((now - created).total_seconds() / 86400.0)
                    except (ValueError, TypeError):
                        continue
                if ages:
                    avg_age_days = sum(ages) / len(ages)

            dream_rows = await conn.fetch(
                """SELECT status, duration_ms, completed_at FROM dream_reports
                   WHERE agent_id = $1 AND completed_at >= $2""",
                agent_id, since,
            )
            runs_7d = len(dream_rows)
            success_count_7d = sum(1 for r in dream_rows if r["status"] == "success")
            failure_count_7d = runs_7d - success_count_7d
            success_rate_7d = success_count_7d / runs_7d if runs_7d > 0 else 0.0
            avg_duration_ms = (
                sum(int(r["duration_ms"] or 0) for r in dream_rows) / runs_7d
                if runs_7d > 0 else 0.0
            )
            last_dream_row = await conn.fetchrow(
                """SELECT completed_at FROM dream_reports
                   WHERE agent_id = $1
                   ORDER BY completed_at DESC LIMIT 1""",
                agent_id,
            )
            last_run_iso = last_dream_row["completed_at"] if last_dream_row else None

            cost_row = await conn.fetchrow(
                """SELECT COALESCE(SUM(input_tokens + output_tokens), 0) as tokens,
                          COALESCE(SUM(cost_usd), 0.0) as usd
                   FROM cost_records
                   WHERE agent_id = $1 AND created_at >= $2""",
                agent_id, since,
            )
            tokens_7d = int(cost_row["tokens"])
            usd_7d = float(cost_row["usd"])

            dream_cost_row = await conn.fetchrow(
                """SELECT COALESCE(SUM(input_tokens + output_tokens), 0) as tokens
                   FROM cost_records
                   WHERE agent_id = $1 AND created_at >= $2
                     AND cycle_id IS NOT NULL""",
                agent_id, since,
            )
            dream_tokens_7d = int(dream_cost_row["tokens"])

            critic_row = await conn.fetchrow(
                """SELECT COUNT(*) as n,
                          COALESCE(SUM(pass_through), 0) as passes
                   FROM critic_reviews
                   WHERE agent_id = $1 AND created_at >= $2""",
                agent_id, since,
            )
            reviews_7d = int(critic_row["n"])
            passes_7d = int(critic_row["passes"])
            pass_rate_7d = passes_7d / reviews_7d if reviews_7d > 0 else 1.0

            entries_7d = int(await conn.fetchval(
                """SELECT COUNT(*) FROM journals
                   WHERE agent_id = $1 AND created_at >= $2""",
                agent_id, since,
            ))
            last_journal_row = await conn.fetchrow(
                """SELECT created_at FROM journals
                   WHERE agent_id = $1
                   ORDER BY created_at DESC LIMIT 1""",
                agent_id,
            )
            days_since_last_journal: float | None = None
            if last_journal_row:
                try:
                    last_j = datetime.fromisoformat(last_journal_row["created_at"])
                    if last_j.tzinfo is None:
                        last_j = last_j.replace(tzinfo=UTC)
                    days_since_last_journal = max(
                        (now - last_j).total_seconds() / 86400.0, 0.0
                    )
                except (ValueError, TypeError):
                    days_since_last_journal = None

        return {
            "memory": {
                "stream_count": by_tier.get("raw", 0),
                "consolidated_count": by_tier.get("consolidated", 0)
                + by_tier.get("reflective", 0),
                "journal_count": journal_count,
                "avg_salience": round(avg_salience, 3),
                "dedup_rate_7d": round(dedup_rate_7d, 3),
                "captures_7d": captures_7d,
                "reinforced_count": reinforced_count,
                "total_memories": total_memories,
                "event_type_counts": event_type_counts,
            },
            "directives": {
                "provisional_count": provisional_count,
                "active_count": active_count,
                "permanent_count": permanent_count,
                "inactive_count": inactive_count,
                "demotion_rate_7d": round(demotion_rate_7d, 3),
                "avg_age_days": round(avg_age_days, 2),
            },
            "dreams": {
                "runs_7d": runs_7d,
                "success_count_7d": success_count_7d,
                "failure_count_7d": failure_count_7d,
                "success_rate_7d": round(success_rate_7d, 3),
                "avg_duration_ms": round(avg_duration_ms, 2),
                "last_run_iso": last_run_iso,
            },
            "cost": {
                "tokens_7d": tokens_7d,
                "usd_7d": round(usd_7d, 4),
                "dream_tokens_7d": dream_tokens_7d,
            },
            "critic": {
                "reviews_7d": reviews_7d,
                "pass_rate_7d": round(pass_rate_7d, 3),
            },
            "journals": {
                "entries_7d": entries_7d,
                "days_since_last_journal": (
                    round(days_since_last_journal, 2)
                    if days_since_last_journal is not None
                    else None
                ),
            },
        }

    async def append_health_snapshot(
        self,
        *,
        agent_id: str,
        snapshot_date: str,
        payload: str,
        created_at: str,
    ) -> None:
        pool = self._pool_or_raise()
        payload_val = json.loads(payload) if isinstance(payload, str) else payload
        async with pool.acquire() as conn:
            await conn.execute(
                """INSERT INTO health_snapshots
                       (agent_id, snapshot_date, payload, created_at)
                   VALUES ($1, $2, $3, $4)
                   ON CONFLICT(agent_id, snapshot_date) DO UPDATE SET
                       payload = EXCLUDED.payload,
                       created_at = EXCLUDED.created_at""",
                agent_id, snapshot_date, payload_val, created_at,
            )

    async def query_health_snapshots(
        self,
        *,
        agent_id: str,
        since: str | None = None,
        until: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        pool = self._pool_or_raise()
        clauses = ["agent_id = $1"]
        params: list[Any] = [agent_id]
        idx = 2
        if since is not None:
            clauses.append(f"snapshot_date >= ${idx}")
            params.append(since)
            idx += 1
        if until is not None:
            clauses.append(f"snapshot_date <= ${idx}")
            params.append(until)
            idx += 1
        sql = f"""SELECT snapshot_date, payload, created_at
                  FROM health_snapshots
                  WHERE {" AND ".join(clauses)}
                  ORDER BY snapshot_date ASC"""  # noqa: S608
        if limit is not None:
            sql += f" LIMIT ${idx}"
            params.append(int(limit))
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        return [
            {
                "snapshot_date": row["snapshot_date"],
                "payload": (
                    json.dumps(row["payload"])
                    if isinstance(row["payload"], (dict, list))
                    else row["payload"]
                ),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    # ---- Counts / Agent operations ---------------------------------------------

    async def get_agent_counts(self, *, agent_id: str) -> dict[str, int]:
        pool = self._pool_or_raise()
        tables = {
            "memories": "memories",
            "directives": "directives",
            "journals": "journals",
            "dream_reports": "dream_reports",
        }
        counts: dict[str, int] = {}
        async with pool.acquire() as conn:
            for key, table in tables.items():
                val = await conn.fetchval(
                    f"SELECT COUNT(*) FROM {table} WHERE agent_id = $1",  # noqa: S608
                    agent_id,
                )
                counts[key] = int(val)
        return counts

    async def clone_agent(
        self,
        *,
        src_agent_id: str,
        tgt_agent_id: str,
        tgt_backend: BaseBackend | None = None,
    ) -> dict[str, int]:
        if not src_agent_id or not tgt_agent_id:
            msg = "clone_agent requires non-empty src_agent_id and tgt_agent_id"
            raise ValueError(msg)
        if src_agent_id == tgt_agent_id and tgt_backend is None:
            msg = (
                f"clone_agent refuses to clone onto the same agent_id "
                f"({src_agent_id!r}) — source and target must differ."
            )
            raise ValueError(msg)

        if tgt_backend is not None:
            return await self._cross_backend_clone(
                src_agent_id=src_agent_id,
                tgt_agent_id=tgt_agent_id,
                tgt_backend=tgt_backend,
            )

        pool = self._pool_or_raise()
        async with pool.acquire() as conn:
            existing_memories = await conn.fetchval(
                "SELECT COUNT(*) FROM memories WHERE agent_id = $1",
                tgt_agent_id,
            )
            existing_directives = await conn.fetchval(
                "SELECT COUNT(*) FROM directives WHERE agent_id = $1",
                tgt_agent_id,
            )
            if existing_memories or existing_directives:
                msg = (
                    f"clone_agent refuses to overwrite target {tgt_agent_id!r}: "
                    f"it already has {existing_memories} memory rows and "
                    f"{existing_directives} directive rows. Delete them first "
                    f"or pick a fresh agent_id."
                )
                raise ValueError(msg)

            async with conn.transaction():
                memory_rows = await conn.fetch(
                    """SELECT id, tier, event_type, content, metadata, salience,
                              reinforcement_count, emotional_intensity, embedding,
                              embedding_model_id, embedding_dim, source_ids,
                              session_id, scope, ttl_hours, dedup_of, cycle_id,
                              archived_at, created_at, updated_at, accessed_at
                       FROM memories WHERE agent_id = $1""",
                    src_agent_id,
                )
                id_map: dict[str, str] = {row["id"]: _gen_id() for row in memory_rows}

                for row in memory_rows:
                    new_id = id_map[row["id"]]
                    raw_sources = row["source_ids"] or []
                    rewritten_sources = [id_map[s] for s in raw_sources if s in id_map]
                    dedup_of = row["dedup_of"]
                    rewritten_dedup = id_map.get(dedup_of) if dedup_of else None
                    await conn.execute(
                        """INSERT INTO memories
                           (id, agent_id, tier, event_type, content, metadata,
                            salience, reinforcement_count, emotional_intensity,
                            embedding, embedding_model_id, embedding_dim,
                            source_ids, session_id, scope, ttl_hours, dedup_of,
                            cycle_id, archived_at, created_at, updated_at,
                            accessed_at)
                           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
                                   $11, $12, $13, $14, $15, $16, $17, $18,
                                   $19, $20, $21, $22)""",
                        new_id, tgt_agent_id,
                        row["tier"], row["event_type"],
                        row["content"], row["metadata"],
                        row["salience"], row["reinforcement_count"],
                        row["emotional_intensity"], row["embedding"],
                        row["embedding_model_id"], row["embedding_dim"],
                        rewritten_sources, row["session_id"],
                        row["scope"], row["ttl_hours"],
                        rewritten_dedup, None,
                        row["archived_at"], row["created_at"],
                        row["updated_at"], row["accessed_at"],
                    )

                directive_rows = await conn.fetch(
                    """SELECT id, text, content_hash, status, priority, usage_count,
                              embedding, embedding_model_id, embedding_dim,
                              created_at, updated_at, last_used, promoted_at
                       FROM directives WHERE agent_id = $1""",
                    src_agent_id,
                )
                for row in directive_rows:
                    await conn.execute(
                        """INSERT INTO directives
                           (id, agent_id, text, content_hash, status, priority,
                            usage_count, embedding, embedding_model_id,
                            embedding_dim, created_at, updated_at, last_used,
                            promoted_at)
                           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
                                   $11, $12, $13, $14)""",
                        _gen_id(), tgt_agent_id,
                        row["text"], row["content_hash"],
                        row["status"], row["priority"],
                        row["usage_count"], row["embedding"],
                        row["embedding_model_id"], row["embedding_dim"],
                        row["created_at"], row["updated_at"],
                        row["last_used"], row["promoted_at"],
                    )

        counts = {"memories": len(memory_rows), "directives": len(directive_rows)}
        logger.info(
            "Agent cloned",
            extra={
                "subsystem": "storage.postgres",
                "src_agent_id": src_agent_id,
                "tgt_agent_id": tgt_agent_id,
                "per_table": counts,
            },
        )
        return counts


