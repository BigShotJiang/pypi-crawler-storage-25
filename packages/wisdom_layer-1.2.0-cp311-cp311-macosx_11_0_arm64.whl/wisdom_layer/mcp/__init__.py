"""MCP (Model Context Protocol) server for the Wisdom Layer SDK.

Exposes Wisdom Layer primitives as MCP tools and resources,
enabling integration with Claude Code, Cursor, and other
MCP-compatible AI tools.

Install: ``pip install "wisdom-layer[mcp]"``
"""
