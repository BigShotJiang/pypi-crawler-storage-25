"""CLI entry point: ``wisdom-layer-mcp``."""

from __future__ import annotations

import argparse
import logging
import sys

logger = logging.getLogger(__name__)


def main(argv: list[str] | None = None) -> None:
    """Launch the Wisdom Layer MCP server."""
    parser = argparse.ArgumentParser(
        description="Wisdom Layer MCP Server — expose SDK primitives to AI tools",
        epilog=(
            "GitHub: https://github.com/rhatigan-agi/wisdom-layer "
            "· Star if useful · Report issues there"
        ),
    )
    parser.add_argument(
        "--db",
        default="wisdom.db",
        help="SQLite database path (default: wisdom.db)",
    )
    parser.add_argument(
        "--agent-id",
        default="mcp-agent",
        help="Agent ID to use (default: mcp-agent)",
    )
    parser.add_argument(
        "--transport",
        default="stdio",
        choices=["stdio", "sse", "streamable-http"],
        help="MCP transport (default: stdio)",
    )
    parser.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Log level (default: WARNING — stdio transport requires quiet stdout)",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        stream=sys.stderr,
    )

    try:
        from mcp.server.fastmcp import FastMCP  # noqa: F401
    except ImportError:
        logger.error(
            "MCP SDK not found. Install with: pip install wisdom-layer[mcp]",
        )
        sys.exit(1)

    import asyncio
    import os

    from wisdom_layer.agent import WisdomAgent
    from wisdom_layer.config import AgentConfig
    from wisdom_layer.dashboard._bootstrap import _resolve_llm
    from wisdom_layer.mcp.server import create_mcp_server
    from wisdom_layer.storage.sqlite import SQLiteBackend

    llm = _resolve_llm()
    backend = SQLiteBackend(args.db, embed_fn=getattr(llm, "embed", None))
    config = AgentConfig(
        name=args.agent_id,
        role="MCP agent",
        api_key=os.environ.get("WISDOM_LAYER_LICENSE", ""),
    )
    agent = WisdomAgent(
        agent_id=args.agent_id,
        config=config,
        llm=llm,  # type: ignore[arg-type]
        backend=backend,
    )

    async def _run() -> None:
        await agent.initialize()
        mcp = create_mcp_server(agent)
        mcp.run(transport=args.transport)

    asyncio.run(_run())


if __name__ == "__main__":
    main()
