"""MCP server exposing Wisdom Layer SDK primitives as tools and resources.

Uses the ``FastMCP`` framework from the official MCP Python SDK.
Designed for stdio transport (Claude Code, Cursor integration).

Usage::

    wisdom-layer-mcp --db wisdom.db --agent-id my-agent

Or programmatically::

    from wisdom_layer.mcp.server import create_mcp_server
    mcp = create_mcp_server(agent)
    mcp.run(transport="stdio")
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

try:
    from mcp.server.fastmcp import FastMCP
except ImportError as e:
    raise ImportError(
        "MCP SDK not found. Install with: pip install 'wisdom-layer[mcp]'"
    ) from e

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)


def create_mcp_server(agent: WisdomAgent) -> FastMCP:
    """Create an MCP server wired to a WisdomAgent.

    Args:
        agent: An initialized WisdomAgent instance.

    Returns:
        A configured FastMCP server ready to run.
    """
    mcp = FastMCP(
        "Wisdom Layer",
        json_response=True,
    )

    # ── Tools ──────────────────────────────────────────────────────

    @mcp.tool()
    async def wisdom_capture(
        event_type: str,
        content: str,
    ) -> str:
        """Capture an experience into wisdom memory.

        Stores text content as a memory that the agent can learn from.
        Memories flow through the three-tier architecture: stream →
        consolidated → journal.

        Args:
            event_type: Category of the memory (e.g., "observation",
                "interaction", "feedback", "decision").
            content: The text content to remember.
        """
        result = await agent.memory.capture(
            event_type=event_type,
            content={"text": content},
        )
        return json.dumps(result)

    @mcp.tool()
    async def wisdom_recall(
        query: str,
        limit: int = 5,
    ) -> str:
        """Search wisdom memory for relevant context.

        Performs semantic search across all memory tiers and returns
        the most relevant memories ranked by salience and recency.

        Args:
            query: Natural language search query.
            limit: Maximum number of memories to return (1-20).
        """
        limit = max(1, min(limit, 20))
        results = await agent.memory.search(query, limit=limit)
        formatted = [
            {
                "content": str(r.get("content", r.get("text", ""))),
                "tier": r.get("tier"),
                "salience": r.get("salience"),
                "id": str(r.get("id", "")),
            }
            for r in results
        ]
        return json.dumps(formatted)

    @mcp.tool()
    async def wisdom_health() -> str:
        """Get the agent's cognitive health report.

        Returns the wisdom score (0-1), classification (healthy/stagnant/
        drifting/overloaded), score component breakdown, memory and
        directive statistics, and remedy suggestions.
        """
        report = await agent.health()
        data: dict[str, Any] = {
            "wisdom_score": report.wisdom_score,
            "classification": report.classification,
        }
        if hasattr(report, "score_components"):
            data["score_components"] = report.score_components
        if hasattr(report, "stats"):
            data["stats"] = report.stats
        if hasattr(report, "remedy_suggestion"):
            data["remedy_suggestion"] = report.remedy_suggestion
        return json.dumps(data)

    @mcp.tool()
    async def wisdom_directives() -> str:
        """List all active behavioral directives.

        Directives are rules the agent has learned from experience.
        They follow a lifecycle: provisional → active → permanent.
        """
        directives = await agent.directives.active()
        formatted = [
            {
                "id": str(getattr(d, "id", "")),
                "text": str(getattr(d, "text", d)),
                "status": str(getattr(d, "status", "active")),
                "usage_count": getattr(d, "usage_count", 0),
            }
            for d in directives
        ]
        return json.dumps(formatted)

    @mcp.tool()
    async def wisdom_add_directive(text: str) -> str:
        """Add a new behavioral directive for the agent.

        The directive starts as 'provisional' and must be reinforced
        through usage before promotion to 'active' or 'permanent'.

        Args:
            text: The directive text (a behavioral rule to follow).
        """
        result = await agent.directives.add(text)
        return json.dumps(result)

    @mcp.tool()
    async def wisdom_dream() -> str:
        """Trigger a dream cycle (reflection pipeline).

        Runs the multi-step reflection process: consolidate memories,
        evolve directives, audit coherence, clean up stale rules, and
        synthesize a journal entry. Requires an LLM adapter.
        """
        result = await agent.dreams.trigger()
        return json.dumps(result, default=str)

    @mcp.tool()
    async def wisdom_provenance(entity_id: str) -> str:
        """Trace the provenance chain for any entity.

        Shows the full creation/modification history of a memory,
        directive, or journal entry.

        Args:
            entity_id: The ID of the entity to trace.
        """
        events = await agent.provenance.trace(entity_id)
        return json.dumps(events, default=str)

    # ── Resources ──────────────────────────────────────────────────

    @mcp.resource("wisdom://config")
    async def get_config() -> str:
        """Current agent configuration snapshot."""
        config = agent._config
        data = {
            "agent_id": agent.agent_id,
            "name": config.name,
            "role": config.role,
            "tier": str(agent.tier),
        }
        return json.dumps(data)

    @mcp.resource("wisdom://directives")
    async def get_directives_resource() -> str:
        """All active directives as a resource."""
        directives = await agent.directives.active()
        return json.dumps([
            {"text": str(getattr(d, "text", d)), "status": str(getattr(d, "status", "active"))}
            for d in directives
        ])

    @mcp.resource("wisdom://health")
    async def get_health_resource() -> str:
        """Agent health report as a resource."""
        report = await agent.health()
        return json.dumps({
            "wisdom_score": report.wisdom_score,
            "classification": report.classification,
        })

    return mcp
