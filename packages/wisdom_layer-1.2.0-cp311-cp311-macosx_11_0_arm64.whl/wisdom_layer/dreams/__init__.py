"""Dream cycles — autonomous reconsolidation and reflection."""
