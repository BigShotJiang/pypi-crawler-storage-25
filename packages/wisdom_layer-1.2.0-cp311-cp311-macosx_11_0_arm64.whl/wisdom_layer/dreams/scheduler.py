"""Dream scheduler — in-process recurring dream runner.

Owns a single asyncio background task per agent that sleeps until the
next scheduled dream cycle, invokes ``dream.trigger()``, and reschedules.
Budget-aware via :class:`wisdom_layer.cost.budgets.BudgetGuard` and
single-flight: a second fire is skipped (with an event) if one is
already in progress.

Persistence is delegated to ``save_scheduled_dream`` /
``load_scheduled_dream`` / ``delete_scheduled_dream`` on the backend,
so a restart picks up the schedule where the previous process left
off (see migration ``0015_scheduled_dreams.sql``).

Doc reference: ``ROADMAP_v1.0/v0.5_scheduler_provenance_analytics/phase_1_dream_scheduling.md``.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from datetime import UTC, datetime, time, timedelta
from typing import TYPE_CHECKING, Any, Literal

from wisdom_layer.errors import BudgetExceededError

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent
    from wisdom_layer.cost.budgets import BudgetGuard

logger = logging.getLogger(__name__)

# Default background-loop poll cadence. The loop wakes up at least this
# often so that clock skew, DST, and pause/resume transitions take effect
# without waiting for the full schedule interval.
_DEFAULT_POLL_SECONDS: float = 60.0

# Valid values for interval_hours when ``at`` is set. Requiring the
# interval to divide 24 evenly keeps the wall-clock anchor well-defined
# (every N hours *starting from* ``at`` UTC).
_AT_PINNED_ALLOWED_INTERVALS: frozenset[float] = frozenset(
    {1.0, 2.0, 3.0, 4.0, 6.0, 8.0, 12.0, 24.0}
)

ScheduleState = Literal["scheduled", "paused", "running", "unscheduled", "error"]


@dataclass
class ScheduleStatus:
    """Structured status for dashboards + programmatic introspection."""

    state: ScheduleState
    interval_hours: float | None = None
    at_time: time | None = None
    next_run: datetime | None = None
    last_run: datetime | None = None
    paused: bool = False
    ignore_budget: bool = False
    error: str | None = None


def _parse_iso(ts: str | None) -> datetime | None:
    if ts is None:
        return None
    dt = datetime.fromisoformat(ts)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt


def _parse_time(s: str | None) -> time | None:
    if s is None:
        return None
    return time.fromisoformat(s)


def _fmt_time(t: time | None) -> str | None:
    if t is None:
        return None
    return t.isoformat()


def compute_next_run(
    *,
    reference: datetime,
    interval_hours: float,
    at_time: time | None,
) -> datetime:
    """Compute the next scheduled run strictly after ``reference``.

    When ``at_time`` is ``None`` the result is simply ``reference +
    interval_hours``. When ``at_time`` is set, the result is the next
    UTC instant whose wall-clock time equals ``at_time`` and which is
    on the "every ``interval_hours``" grid anchored at that time of day.

    The scheduler treats scheduling as UTC-only; local-time scheduling
    is a user concern that lands outside the SDK.
    """
    if interval_hours <= 0:
        raise ValueError(
            f"interval_hours must be positive; got {interval_hours}"
        )
    if at_time is not None and interval_hours not in _AT_PINNED_ALLOWED_INTERVALS:
        raise ValueError(
            "When at_time is set, interval_hours must divide 24 evenly "
            f"(allowed: {sorted(_AT_PINNED_ALLOWED_INTERVALS)}). "
            f"Got {interval_hours}."
        )

    if at_time is None:
        return reference + timedelta(hours=interval_hours)

    ref = reference.astimezone(UTC)
    anchor = datetime(
        ref.year, ref.month, ref.day,
        at_time.hour, at_time.minute, at_time.second,
        at_time.microsecond,
        tzinfo=UTC,
    )
    step = timedelta(hours=interval_hours)
    while anchor <= ref:
        anchor = anchor + step
    return anchor


class DreamScheduler:
    """Background dream-cycle scheduler bound to a :class:`WisdomAgent`.

    One instance per agent; wired from :class:`DreamsInterface`. Not
    constructed directly by users.

    Lifecycle:

    * :meth:`initialize` reloads any persisted schedule and, if one
      exists, spawns the background task.
    * :meth:`schedule` / :meth:`pause` / :meth:`resume` /
      :meth:`unschedule` mutate the schedule and persist.
    * :meth:`close` cancels the background task and awaits clean
      shutdown.
    * :meth:`tick` is the pure fire-if-due step, exposed for tests.

    Concurrency:

    * Single-flight: a ``dream.trigger()`` call from :meth:`tick` is
      guarded by an internal :class:`asyncio.Lock`. A second tick while
      one is running emits ``dream.scheduled.skipped`` with reason
      ``"already_running"``.
    * The background task is cooperative — it sleeps on
      :func:`asyncio.sleep` in a cancellation-aware loop and terminates
      promptly when :meth:`close` is called.
    """

    def __init__(
        self,
        agent: WisdomAgent,
        *,
        poll_seconds: float = _DEFAULT_POLL_SECONDS,
        budget_guard: BudgetGuard | None = None,
    ) -> None:
        self._agent = agent
        self._poll_seconds = poll_seconds
        self._budget_guard = budget_guard

        self._interval_hours: float | None = None
        self._at_time: time | None = None
        self._paused: bool = False
        self._ignore_budget: bool = False
        self._next_run: datetime | None = None
        self._last_run: datetime | None = None
        self._created_at: datetime | None = None
        self._last_error: str | None = None

        self._running_lock = asyncio.Lock()
        self._task: asyncio.Task[None] | None = None
        self._wake_event = asyncio.Event()

    # -- Public accessors ----------------------------------------------------

    @property
    def next_run(self) -> datetime | None:
        return self._next_run

    @property
    def last_run(self) -> datetime | None:
        return self._last_run

    def status(self) -> ScheduleStatus:
        if self._interval_hours is None:
            state: ScheduleState = "unscheduled"
        elif self._last_error is not None:
            state = "error"
        elif self._running_lock.locked():
            state = "running"
        elif self._paused:
            state = "paused"
        else:
            state = "scheduled"
        return ScheduleStatus(
            state=state,
            interval_hours=self._interval_hours,
            at_time=self._at_time,
            next_run=self._next_run,
            last_run=self._last_run,
            paused=self._paused,
            ignore_budget=self._ignore_budget,
            error=self._last_error,
        )

    # -- Lifecycle -----------------------------------------------------------

    async def initialize(self) -> None:
        """Reload persisted schedule and start the background loop.

        Safe to call once per agent; subsequent calls are no-ops.
        """
        if self._task is not None:
            return
        row = await self._agent._backend.load_scheduled_dream(
            agent_id=self._agent._agent_id,
        )
        if row is not None:
            self._interval_hours = float(row["interval_hours"])
            self._at_time = _parse_time(row["at_time"])
            self._paused = bool(row["paused"])
            self._ignore_budget = bool(row["ignore_budget"])
            self._next_run = _parse_iso(row["next_run"])
            self._last_run = _parse_iso(row["last_run"])
            self._created_at = _parse_iso(row["created_at"])
            self._task = asyncio.create_task(
                self._run_loop(), name=f"wl-scheduler-{self._agent._agent_id}"
            )
            logger.info(
                "Dream scheduler restored",
                extra={
                    "subsystem": "scheduler",
                    "agent_id": self._agent._agent_id,
                    "next_run": row["next_run"],
                    "paused": self._paused,
                },
            )

    async def close(self) -> None:
        """Cancel the background loop and wait for it to exit."""
        task = self._task
        self._task = None
        if task is None:
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("Dream scheduler loop exited with error")

    # -- Mutations -----------------------------------------------------------

    async def schedule(
        self,
        *,
        interval_hours: float,
        at_time: time | None,
        ignore_budget: bool,
    ) -> ScheduleStatus:
        if interval_hours <= 0:
            raise ValueError(
                f"interval_hours must be positive; got {interval_hours}"
            )
        if at_time is not None and interval_hours not in _AT_PINNED_ALLOWED_INTERVALS:
            raise ValueError(
                "When at= is set, interval_hours must divide 24 evenly "
                f"(allowed: {sorted(_AT_PINNED_ALLOWED_INTERVALS)}). "
                f"Got {interval_hours}."
            )
        if ignore_budget:
            logger.warning(
                "Dream scheduler: ignore_budget=True set for agent_id=%s. "
                "Scheduled dreams will bypass BudgetGuard pre-flight checks.",
                self._agent._agent_id,
            )

        now = self._now()
        self._interval_hours = float(interval_hours)
        self._at_time = at_time
        self._ignore_budget = ignore_budget
        self._paused = False
        self._last_error = None
        if self._created_at is None:
            self._created_at = now
        self._next_run = compute_next_run(
            reference=now,
            interval_hours=self._interval_hours,
            at_time=self._at_time,
        )
        await self._persist(updated_at=now)
        self._ensure_task()
        self._wake_event.set()
        return self.status()

    async def pause(self) -> ScheduleStatus:
        if self._interval_hours is None:
            return self.status()
        self._paused = True
        await self._persist(updated_at=self._now())
        self._wake_event.set()
        return self.status()

    async def resume(self) -> ScheduleStatus:
        if self._interval_hours is None:
            return self.status()
        self._paused = False
        # If next_run is in the past (we were paused through it),
        # move it forward to the next slot so we don't immediately fire
        # without the user's consent.
        now = self._now()
        if self._next_run is not None and self._next_run <= now:
            self._next_run = compute_next_run(
                reference=now,
                interval_hours=self._interval_hours,
                at_time=self._at_time,
            )
        await self._persist(updated_at=now)
        self._wake_event.set()
        return self.status()

    async def unschedule(self) -> ScheduleStatus:
        self._interval_hours = None
        self._at_time = None
        self._paused = False
        self._ignore_budget = False
        self._next_run = None
        self._last_run = None
        self._created_at = None
        self._last_error = None
        await self._agent._backend.delete_scheduled_dream(
            agent_id=self._agent._agent_id,
        )
        self._wake_event.set()
        return self.status()

    # -- Tick (pure, test-friendly) -----------------------------------------

    async def tick(self) -> dict[str, Any]:
        """Fire a scheduled dream if one is due.

        Returns a structured result so tests can assert on the outcome
        without snooping on events:

        * ``{"fired": True, "cycle_id": ..., "duration_ms": ...}``
        * ``{"fired": False, "reason": "not_due" | "paused" |
            "unscheduled" | "already_running" | "budget_cap" |
            "feature_disabled" | "no_memories"}``

        Callers must not rely on this method for concurrency control;
        the internal lock handles reentrancy.
        """
        if self._interval_hours is None or self._next_run is None:
            return {"fired": False, "reason": "unscheduled"}
        if self._paused:
            return {"fired": False, "reason": "paused"}
        now = self._now()
        if self._next_run > now:
            return {"fired": False, "reason": "not_due"}
        if self._running_lock.locked():
            await self._emit_skipped(reason="already_running")
            return {"fired": False, "reason": "already_running"}

        async with self._running_lock:
            return await self._fire(now=now)

    # -- Internals -----------------------------------------------------------

    async def _fire(self, *, now: datetime) -> dict[str, Any]:
        if not self._ignore_budget and self._budget_guard is not None:
            try:
                self._budget_guard.preflight_cycle(estimated_cost_usd=0.0)
            except BudgetExceededError as e:
                await self._reschedule_after_fire(now=now)
                await self._emit_skipped(reason="budget_cap", detail=str(e))
                return {"fired": False, "reason": "budget_cap"}

        await self._agent._emit(
            "dream.scheduled.start",
            data={
                "scheduled_at": (
                    self._next_run.isoformat() if self._next_run else None
                ),
            },
        )
        try:
            result = await self._agent.dreams.trigger()
        except Exception as e:
            self._last_error = f"{type(e).__name__}: {e}"
            await self._reschedule_after_fire(now=now)
            await self._agent._emit(
                "dream.scheduled.failed",
                data={
                    "error_type": type(e).__name__,
                    "error_message": str(e)[:500],
                },
            )
            logger.exception(
                "Scheduled dream cycle failed",
                extra={
                    "subsystem": "scheduler",
                    "agent_id": self._agent._agent_id,
                },
            )
            return {"fired": False, "reason": "failed", "error": str(e)}

        self._last_error = None
        self._last_run = now
        await self._reschedule_after_fire(now=now)
        await self._agent._emit(
            "dream.scheduled.complete",
            data={
                "cycle_id": result.get("cycle_id"),
                "status": result.get("status"),
                "duration_ms": result.get("duration_ms"),
            },
        )
        await self._maybe_capture_health_snapshot()
        return {
            "fired": True,
            "cycle_id": result.get("cycle_id"),
            "status": result.get("status"),
            "duration_ms": result.get("duration_ms"),
        }

    async def _maybe_capture_health_snapshot(self) -> None:
        """Best-effort health snapshot after a successful scheduled dream.

        Silently skipped when the agent's tier lacks ``standard_analytics``
        or the ``health_analytics`` flag is off — a scheduler side-effect
        must never raise into the dream path. Failures are logged at
        WARNING but not re-raised for the same reason.
        """
        from wisdom_layer.license import has_feature  # local to avoid cycle

        if not has_feature(self._agent._tier, "standard_analytics"):
            return
        if not self._agent._config.feature_flags.health_analytics:
            return
        try:
            await self._agent.health.capture_snapshot()
        except Exception:
            logger.warning(
                "Post-cycle health snapshot failed",
                extra={
                    "subsystem": "scheduler",
                    "agent_id": self._agent._agent_id,
                },
                exc_info=True,
            )

    async def _reschedule_after_fire(self, *, now: datetime) -> None:
        if self._interval_hours is None:
            return
        self._next_run = compute_next_run(
            reference=now,
            interval_hours=self._interval_hours,
            at_time=self._at_time,
        )
        await self._persist(updated_at=now)

    async def _emit_skipped(
        self, *, reason: str, detail: str | None = None,
    ) -> None:
        data: dict[str, Any] = {"reason": reason}
        if detail is not None:
            data["detail"] = detail
        await self._agent._emit("dream.scheduled.skipped", data=data)

    async def _persist(self, *, updated_at: datetime) -> None:
        if self._interval_hours is None or self._next_run is None:
            return
        created = self._created_at or updated_at
        await self._agent._backend.save_scheduled_dream(
            agent_id=self._agent._agent_id,
            interval_hours=self._interval_hours,
            at_time=_fmt_time(self._at_time),
            paused=self._paused,
            ignore_budget=self._ignore_budget,
            next_run=self._next_run.isoformat(),
            last_run=self._last_run.isoformat() if self._last_run else None,
            created_at=created.isoformat(),
            updated_at=updated_at.isoformat(),
        )

    def _ensure_task(self) -> None:
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(
                self._run_loop(),
                name=f"wl-scheduler-{self._agent._agent_id}",
            )

    async def _run_loop(self) -> None:
        try:
            while True:
                await self.tick()
                self._wake_event.clear()
                sleep_for = self._compute_sleep_seconds()
                try:
                    await asyncio.wait_for(
                        self._wake_event.wait(), timeout=sleep_for,
                    )
                except TimeoutError:
                    continue
        except asyncio.CancelledError:
            raise

    def _compute_sleep_seconds(self) -> float:
        # With no schedule or while paused, sleep one full poll interval;
        # a wake_event set from schedule()/resume() will cut it short.
        if (
            self._interval_hours is None
            or self._next_run is None
            or self._paused
        ):
            return self._poll_seconds
        delta = (self._next_run - self._now()).total_seconds()
        if delta <= 0:
            # Still due: wake immediately on next loop iteration.
            return 0.0
        return min(self._poll_seconds, delta)

    def _now(self) -> datetime:
        now = self._agent._clock.now()
        if now.tzinfo is None:
            now = now.replace(tzinfo=UTC)
        return now
