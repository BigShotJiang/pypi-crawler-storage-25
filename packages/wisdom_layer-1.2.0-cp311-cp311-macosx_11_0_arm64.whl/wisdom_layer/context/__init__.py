"""Context composition for the Wisdom Layer SDK.

Doc reference: ``03_critic_directives.md`` §"Context Composition Order",
``11_integration_ergonomics_resolutions.md`` §"Hybrid Mode".
"""

from wisdom_layer.context.composer import ContextComposer

__all__ = ["ContextComposer"]
