"""ContextComposer — explicit callable that assembles the 7-layer prompt.

The 7-layer composition order (doc 03 §"Context Composition Order"):

    0. hard_constraints   — identity axioms, safety rails           (non-truncatable)
    1. active_directives  — current directive set, priority-sorted
    2. personality         — curiosity / empathy / rigor / etc.
    3. relevant_memories   — top-k memories from snapshot
    4. session_context     — recent messages within the session
    5. critic_guidance     — last critic review, if any
    6. raw_prompt          — the user's actual input                 (non-truncatable)

ContextComposer is:
- **Stateless**: one instance per agent, no hidden per-call mutation.
- **Deterministic**: identical inputs → identical outputs.
- **Directly callable**: ``composed = composer.compose(raw_prompt=..., ...)``.
- **The only path** that emits ``context.composed`` events and raises
  ``ContextOverflowError``.

Doc reference: ``03_critic_directives.md``, ``06_extraction_plan.md`` §0.10,
``11_integration_ergonomics_resolutions.md`` §"Hybrid Mode".
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from wisdom_layer.errors import ContextOverflowError

if TYPE_CHECKING:
    from wisdom_layer.config import AgentConfig

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ComposedContext:
    """Result of a composition pass.

    Attributes:
        layers: Ordered dict of layer_name → assembled text for that layer.
        total_chars: Total character count across all layers.
        truncated_layers: Names of layers that were truncated to fit budget.
        metadata: Per-layer metadata (token estimates, source counts, etc.).
    """

    layers: dict[str, str] = field(default_factory=dict)
    total_chars: int = 0
    truncated_layers: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


# Layer indices — the canonical composition order.
LAYER_HARD_CONSTRAINTS = 0
LAYER_ACTIVE_DIRECTIVES = 1
LAYER_PERSONALITY = 2
LAYER_RELEVANT_MEMORIES = 3
LAYER_SESSION_CONTEXT = 4
LAYER_CRITIC_GUIDANCE = 5
LAYER_RAW_PROMPT = 6

LAYER_NAMES = [
    "hard_constraints",
    "active_directives",
    "personality",
    "relevant_memories",
    "session_context",
    "critic_guidance",
    "raw_prompt",
]

# Non-truncatable layers — overflow here raises ContextOverflowError.
NON_TRUNCATABLE = frozenset({"hard_constraints", "raw_prompt"})


class ContextComposer:
    """Assembles the 7-layer prompt for an agent.

    Args:
        config: The agent's configuration (for personality, directives).
        max_context_chars: Character budget for the full composed prompt.
            Defaults to 100 000 (~25 000 tokens at 4 chars/token).
    """

    def __init__(
        self,
        config: AgentConfig,
        *,
        max_context_chars: int = 100_000,
    ) -> None:
        self._config = config
        self._max_context_chars = max_context_chars

    def compose(
        self,
        *,
        raw_prompt: str,
        hard_constraints: str = "",
        active_directives: list[str] | None = None,
        relevant_memories: list[dict[str, Any]] | None = None,
        session_context: list[dict[str, str]] | None = None,
        critic_guidance: str = "",
    ) -> ComposedContext:
        """Compose the full context from the 7 layers.

        Args:
            raw_prompt: The user's input (layer 6, non-truncatable).
            hard_constraints: Identity axioms and safety rails (layer 0).
            active_directives: Priority-sorted directive texts (layer 1).
            relevant_memories: Top-k memories from snapshot (layer 3).
            session_context: Recent session messages (layer 4).
            critic_guidance: Last critic review text (layer 5).

        Returns:
            A :class:`ComposedContext` with the assembled layers.

        Raises:
            ContextOverflowError: If a non-truncatable layer exceeds the
                remaining budget after other non-truncatable layers are placed.
        """
        layers: dict[str, str] = {}
        truncated: list[str] = []
        meta: dict[str, Any] = {}

        # Layer 0 — hard constraints
        layers["hard_constraints"] = hard_constraints

        # Layer 1 — active directives
        directives = active_directives or list(self._config.directives)
        layers["active_directives"] = "\n".join(
            f"- {d}" for d in directives
        ) if directives else ""

        # Layer 2 — personality
        p = self._config.personality
        layers["personality"] = (
            f"curiosity={p.curiosity} empathy={p.empathy} "
            f"rigor={p.rigor} creativity={p.creativity} "
            f"assertiveness={p.assertiveness}"
        )

        # Layer 3 — relevant memories
        memories = relevant_memories or []
        memory_lines = []
        for mem in memories:
            content = mem.get("content", "")
            salience = mem.get("salience", 0.0)
            memory_lines.append(f"[salience={salience:.2f}] {content}")
        layers["relevant_memories"] = "\n".join(memory_lines)
        meta["memory_count"] = len(memories)

        # Layer 4 — session context
        messages = session_context or []
        session_lines = []
        for msg in messages:
            role = msg.get("role", "user")
            text = msg.get("content", "")
            session_lines.append(f"{role}: {text}")
        layers["session_context"] = "\n".join(session_lines)
        meta["session_message_count"] = len(messages)

        # Layer 5 — critic guidance
        layers["critic_guidance"] = critic_guidance

        # Layer 6 — raw prompt
        layers["raw_prompt"] = raw_prompt

        # --- Budget enforcement ---
        # First, measure non-truncatable layers.
        non_trunc_chars = sum(
            len(layers[name]) for name in NON_TRUNCATABLE if layers.get(name)
        )
        if non_trunc_chars > self._max_context_chars:
            # Identify which non-truncatable layer is the overflow culprit.
            # Check raw_prompt first (most likely to be over-sized).
            for layer_name in NON_TRUNCATABLE:
                if len(layers[layer_name]) > self._max_context_chars:
                    raise ContextOverflowError(
                        layer=layer_name,
                        tokens_used=len(layers[layer_name]),
                        tokens_available=self._max_context_chars,
                    )
            # Combined overflow
            raise ContextOverflowError(
                layer="hard_constraints+raw_prompt",
                tokens_used=non_trunc_chars,
                tokens_available=self._max_context_chars,
            )

        # Remaining budget for truncatable layers.
        remaining = self._max_context_chars - non_trunc_chars
        truncatable_names = [
            n for n in LAYER_NAMES if n not in NON_TRUNCATABLE
        ]

        for name in truncatable_names:
            text = layers[name]
            if len(text) > remaining:
                layers[name] = text[:remaining]
                truncated.append(name)
                remaining = 0
            else:
                remaining -= len(text)

        total_chars = sum(len(v) for v in layers.values())
        meta["truncated_layers"] = truncated

        logger.info(
            "Context composed",
            extra={
                "subsystem": "context.composer",
                "total_chars": total_chars,
                "truncated_layers": truncated,
                "memory_count": meta.get("memory_count", 0),
            },
        )

        return ComposedContext(
            layers=layers,
            total_chars=total_chars,
            truncated_layers=truncated,
            metadata=meta,
        )
