"""Public test factories for the Wisdom Layer SDK.

These factories produce valid instances of the SDK's public types with
sensible defaults. They mirror the internal ``tests/factories.py`` but
are part of the stable customer-facing ``wisdom_layer.testing`` surface.

Doc reference: ``16_testing.md``, ``06_extraction_plan.md`` §0.10.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from wisdom_layer.config import AgentConfig
from wisdom_layer.types import (
    Directive,
    DirectiveProposal,
    DirectiveStatus,
    Memory,
    MemoryTier,
)

__all__ = [
    "make_agent_config",
    "make_directive",
    "make_directive_proposal",
    "make_memory",
]

_FIXED_TIME = datetime(2026, 1, 1, 0, 0, 0, tzinfo=UTC)


def _gen_id(prefix: str) -> str:
    """Return a short readable test id with a stable prefix."""
    return f"{prefix}_{uuid4().hex[:8]}"


def make_agent_config(**overrides: Any) -> AgentConfig:
    """Build an :class:`AgentConfig` with sane test defaults.

    Args:
        **overrides: Any field on :class:`AgentConfig` to override.

    Returns:
        A fully-validated :class:`AgentConfig` instance.
    """
    defaults: dict[str, Any] = {
        "name": "TestAgent",
        "role": "test runner",
        "api_key": "wl_free_test123",
    }
    defaults.update(overrides)
    return AgentConfig(**defaults)


def make_memory(
    *,
    tier: MemoryTier = MemoryTier.RAW,
    content: str = "test memory content",
    event_type: str = "test_event",
    salience: float = 0.5,
    emotional_intensity: float = 0.0,
    reinforcement_count: int = 0,
    metadata: dict[str, Any] | None = None,
    source_ids: list[str] | None = None,
    created_at: datetime = _FIXED_TIME,
) -> Memory:
    """Build a :class:`Memory` with sane test defaults.

    Args:
        tier: Which tier the memory belongs to.
        content: Free-text payload of the memory.
        event_type: Category of event the memory represents.
        salience: Initial salience score (0.0 - 1.0).
        emotional_intensity: Initial emotional intensity (0.0 - 1.0).
        reinforcement_count: Initial reinforcement count.
        metadata: Optional structured metadata dict.
        source_ids: Optional provenance chain (parent memory ids).
        created_at: Timestamp for ``created_at`` and ``updated_at``.

    Returns:
        A fully-populated :class:`Memory` instance with a generated id.
    """
    return Memory(
        id=_gen_id("mem"),
        tier=tier,
        content=content,
        event_type=event_type,
        salience=salience,
        emotional_intensity=emotional_intensity,
        reinforcement_count=reinforcement_count,
        metadata=metadata or {},
        source_ids=source_ids or [],
        created_at=created_at,
        updated_at=created_at,
    )


def make_directive(
    *,
    text: str = "Always verify identity before granting access",
    status: DirectiveStatus = DirectiveStatus.ACTIVE,
    priority: str = "contextual",
    usage_count: int = 0,
    created_at: datetime = _FIXED_TIME,
    last_used: datetime | None = None,
) -> Directive:
    """Build a :class:`Directive` with sane test defaults.

    Args:
        text: The directive rule itself.
        status: Lifecycle status (``active``, ``provisional``, ``inactive``).
        priority: Either ``permanent`` or ``contextual``.
        usage_count: How many times the directive has been applied.
        created_at: When the directive was created.
        last_used: When the directive was most recently applied.

    Returns:
        A fully-populated :class:`Directive` instance with a generated id.
    """
    return Directive(
        id=_gen_id("dir"),
        text=text,
        status=status,
        priority=priority,
        usage_count=usage_count,
        created_at=created_at,
        last_used=last_used,
    )


def make_directive_proposal(
    *,
    action: str = "add",
    text: str = "Never log customer PII at INFO level",
    reasoning: str = "Observed three INFO log lines containing email addresses",
    confidence: float = 0.8,
    source_memory_ids: list[str] | None = None,
) -> DirectiveProposal:
    """Build a :class:`DirectiveProposal` with sane test defaults.

    Args:
        action: One of ``add``, ``modify``, ``remove``.
        text: The proposed directive text.
        reasoning: One-line justification for the proposal.
        confidence: Critic confidence in the proposal (0.0 - 1.0).
        source_memory_ids: Memories that triggered the proposal.

    Returns:
        A fully-populated :class:`DirectiveProposal` instance.
    """
    return DirectiveProposal(
        id=_gen_id("prop"),
        action=action,
        text=text,
        reasoning=reasoning,
        confidence=confidence,
        source_memory_ids=source_memory_ids or [],
    )
