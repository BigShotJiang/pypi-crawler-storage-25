"""FakeEmbedder — deterministic hash-based embeddings for testing.

Produces stable, normalized vectors from text input using iterative
hashing. Configurable ``embedding_dim`` so ``EmbeddingDimensionMismatchError``
paths are testable.

Doc reference: ``16_testing.md``, ``06_extraction_plan.md`` §0.10.
"""

from __future__ import annotations

import hashlib
import struct


class FakeEmbedder:
    """Deterministic embedder for testing.

    Args:
        embedding_dim: Dimensionality of output vectors (default 384,
            matching ``all-MiniLM-L6-v2``).

    Usage::

        embedder = FakeEmbedder(embedding_dim=384)
        vec = await embedder.embed("hello")
        assert len(vec) == 384
    """

    def __init__(self, embedding_dim: int = 384) -> None:
        self.embedding_dim = embedding_dim
        self.embed_calls: list[str] = []

    async def embed(self, text: str) -> list[float]:
        """Generate a deterministic embedding from text hash.

        Args:
            text: Input text to embed.

        Returns:
            Normalized float vector of length ``embedding_dim``.
        """
        self.embed_calls.append(text)
        return self._hash_embedding(text)

    async def embed_one(self, text: str) -> list[float]:
        """Alias for ``embed()`` — matches ``BaseEmbeddingAdapter`` interface."""
        return await self.embed(text)

    def _hash_embedding(self, text: str) -> list[float]:
        """Produce a deterministic normalized vector via iterative SHA-256."""
        vec: list[float] = []
        counter = 0
        while len(vec) < self.embedding_dim:
            chunk = hashlib.sha256(f"{text}:{counter}".encode()).digest()
            floats_in_chunk = len(chunk) // 4
            unpacked = struct.unpack(f"{floats_in_chunk}I", chunk)
            for val in unpacked:
                if len(vec) >= self.embedding_dim:
                    break
                vec.append(float(val & 0xFFFF) / 65535.0 - 0.5)
            counter += 1
        # Normalize
        norm = sum(v * v for v in vec) ** 0.5
        if norm > 0:
            vec = [v / norm for v in vec]
        return vec
