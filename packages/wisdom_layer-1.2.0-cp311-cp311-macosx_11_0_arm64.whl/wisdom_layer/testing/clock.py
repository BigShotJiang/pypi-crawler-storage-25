"""FrozenClock — re-export from the internal clock package.

The ``FrozenClock`` implementation lives in ``wisdom_layer.clock._frozen``
and was created in Phase 0.1. This module re-exports it as part of the
stable ``wisdom_layer.testing`` surface so customers import from a single
canonical location.

Doc reference: ``06_extraction_plan.md`` §0.10, §0.1.
"""

from wisdom_layer.clock import FrozenClock

__all__ = ["FrozenClock"]
