"""Hybrid-mode test callers for the Wisdom Layer SDK.

Provides ``PrimitivesCaller`` and ``RespondLoopCaller`` — two strategies
for driving agent interactions in tests. The ``caller`` pytest fixture
parametrises across both so customer tests automatically run against
both the primitives path and the respond_loop path.

Doc reference: ``16_testing.md`` §"Hybrid-mode testing split",
``06_extraction_plan.md`` §0.10.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent


class BaseCaller(ABC):
    """Abstract interface for driving agent interactions in tests."""

    @abstractmethod
    async def send(
        self,
        agent: WisdomAgent,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Send a prompt to the agent and return the response text."""


class PrimitivesCaller(BaseCaller):
    """Drive the agent via raw primitives (search → generate manually)."""

    async def send(
        self,
        agent: WisdomAgent,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Search memories, build context manually, and call LLM."""
        memories = await agent._backend.search_memories(
            agent_id=agent._agent_id,
            query=prompt,
            limit=kwargs.get("memory_limit", 5),
        )
        memory_context = "\n".join(
            str(m.get("content", "")) for m in memories
        )
        system = f"Context:\n{memory_context}" if memory_context else ""
        return await agent._model.generate(
            messages=[{"role": "user", "content": prompt}],
            system=system,
        )


class RespondLoopCaller(BaseCaller):
    """Drive the agent via the reference ``respond_loop`` helper."""

    async def send(
        self,
        agent: WisdomAgent,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Use ``respond_loop()`` for the full composition pipeline."""
        from wisdom_layer.integration.respond import respond_loop

        result = await respond_loop(agent, prompt, **kwargs)
        return result.response


@dataclass
class CallerFixture:
    """Wrapper returned by the ``caller`` pytest fixture.

    Attributes:
        caller: The active caller strategy.
        mode: Either ``"primitives"`` or ``"respond_loop"``.
    """

    caller: BaseCaller
    mode: str

    async def send(
        self,
        agent: WisdomAgent,
        prompt: str,
        **kwargs: Any,
    ) -> str:
        """Delegate to the active caller."""
        return await self.caller.send(agent, prompt, **kwargs)
