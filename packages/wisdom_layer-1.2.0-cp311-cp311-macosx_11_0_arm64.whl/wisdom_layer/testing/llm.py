"""FakeLLMAdapter — scripted LLM adapter for deterministic testing.

Implements ``BaseLLMAdapter`` with pre-configured responses. Records
every call for assertion. Supports ``expect()`` for pattern matching
and ``fail_next()`` for error injection.

Doc reference: ``16_testing.md``, ``06_extraction_plan.md`` §0.10.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from wisdom_layer.llm.base import BaseLLMAdapter
from wisdom_layer.llm.types import AdapterUsage


@dataclass
class _Expectation:
    """A scripted response keyed on a prompt regex."""

    pattern: str
    response: str
    structured_response: dict[str, Any] | None = None
    _compiled: re.Pattern[str] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._compiled = re.compile(self.pattern)


class FakeLLMAdapter(BaseLLMAdapter):
    """Deterministic LLM adapter for testing — no external calls.

    Usage::

        adapter = FakeLLMAdapter()
        adapter.set_response("Hello from the fake LLM")
        adapter.expect(r"refund", response="Processing your refund...")
        adapter.fail_next(RuntimeError("boom"))

        # In your test:
        result = await adapter.generate(messages=[...])
        assert adapter.generate_calls  # recorded
    """

    def __init__(self) -> None:
        self.generate_calls: list[dict[str, Any]] = []
        self.embed_calls: list[str] = []
        self.structured_calls: list[dict[str, Any]] = []

        self._default_response = "Fake LLM response"
        self._default_structured: dict[str, Any] = {"result": "fake_structured"}
        self._expectations: list[_Expectation] = []
        self._pending_error: BaseException | None = None
        # v0.5 Phase 4: scripted usage so tests can assert cost_ledger
        # rows without reaching for a real adapter.
        self.model_id = "fake-model"
        self._scripted_input_tokens: int = 10
        self._scripted_output_tokens: int = 5
        self._scripted_cost_usd: float = 0.0

    def set_usage(
        self,
        *,
        input_tokens: int = 10,
        output_tokens: int = 5,
        cost_usd: float = 0.0,
        model_id: str | None = None,
    ) -> None:
        """Configure the token/cost footprint reported on each call."""
        self._scripted_input_tokens = input_tokens
        self._scripted_output_tokens = output_tokens
        self._scripted_cost_usd = cost_usd
        if model_id is not None:
            self.model_id = model_id

    def _record_usage(self) -> None:
        self.last_usage = AdapterUsage(
            model_id=self.model_id,
            input_tokens=self._scripted_input_tokens,
            output_tokens=self._scripted_output_tokens,
            cost_usd=self._scripted_cost_usd,
        )

    def set_response(self, text: str) -> None:
        """Set the default response text for ``generate()``."""
        self._default_response = text

    def set_structured_response(self, data: dict[str, Any]) -> None:
        """Set the default response for ``generate_structured()``."""
        self._default_structured = data

    def expect(
        self,
        pattern: str,
        *,
        response: str = "",
        structured_response: dict[str, Any] | None = None,
    ) -> None:
        """Register a pattern-matched response.

        When ``generate()`` is called and any message content matches
        ``pattern`` (regex), the corresponding ``response`` is returned
        instead of the default.

        Args:
            pattern: Regex to match against message content.
            response: Text to return from ``generate()``.
            structured_response: Dict to return from ``generate_structured()``.
        """
        self._expectations.append(
            _Expectation(
                pattern=pattern,
                response=response,
                structured_response=structured_response,
            )
        )

    def fail_next(self, error: BaseException) -> None:
        """Make the next ``generate()`` or ``generate_structured()`` raise ``error``."""
        self._pending_error = error

    def _check_pending_error(self) -> None:
        """Raise the pending error if one is set, then clear it."""
        if self._pending_error is not None:
            err = self._pending_error
            self._pending_error = None
            raise err

    def _match_expectations(self, messages: list[dict[str, str]]) -> _Expectation | None:
        """Find the first matching expectation for the given messages."""
        combined = " ".join(
            msg.get("content", "") for msg in messages
        )
        for exp in self._expectations:
            if exp._compiled.search(combined):
                return exp
        return None

    async def generate(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        """Return scripted text and record the call."""
        self.generate_calls.append({
            "messages": messages,
            "system": system,
            "temperature": temperature,
            "max_tokens": max_tokens,
        })
        self._check_pending_error()
        self._record_usage()
        match = self._match_expectations(messages)
        if match:
            return match.response
        return self._default_response

    async def embed(self, text: str) -> list[float]:
        """Return a zero vector of dimension 384. Use FakeEmbedder for real dims."""
        self.embed_calls.append(text)
        return [0.0] * 384

    async def generate_structured(
        self,
        *,
        messages: list[dict[str, str]],
        system: str = "",
        schema: dict[str, Any],
        temperature: float = 0.3,
    ) -> dict[str, Any]:
        """Return scripted structured output and record the call."""
        self.structured_calls.append({
            "messages": messages,
            "system": system,
            "schema": schema,
            "temperature": temperature,
        })
        self._check_pending_error()
        self._record_usage()
        match = self._match_expectations(messages)
        if match and match.structured_response is not None:
            return match.structured_response
        return dict(self._default_structured)
