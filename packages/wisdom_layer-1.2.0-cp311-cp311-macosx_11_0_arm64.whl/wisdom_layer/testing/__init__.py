"""Public testing surface for the Wisdom Layer SDK.

Stable SDK surface — customers import these fixtures to write their
own tests against the SDK without reinventing the determinism rules
the internal suite uses.

No pytest plugin auto-registration. No network-dependent fixtures.
No ``freezegun`` dependency. Every fixture is fully in-process.

Doc reference: ``16_testing.md``, ``06_extraction_plan.md`` §0.10.
"""

from wisdom_layer.testing.clock import FrozenClock
from wisdom_layer.testing.embedder import FakeEmbedder
from wisdom_layer.testing.factories import (
    make_agent_config,
    make_directive,
    make_directive_proposal,
    make_memory,
)
from wisdom_layer.testing.llm import FakeLLMAdapter

__all__ = [
    "FakeLLMAdapter",
    "FakeEmbedder",
    "FrozenClock",
    "make_agent_config",
    "make_directive",
    "make_directive_proposal",
    "make_memory",
]
