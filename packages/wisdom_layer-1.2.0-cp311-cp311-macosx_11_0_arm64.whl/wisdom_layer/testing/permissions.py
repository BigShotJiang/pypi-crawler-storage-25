"""Permission matrix builder for exhaustive config testing.

Generates the Cartesian product of ``LockConfig`` × ``SessionConfig`` ×
``ResourceLimits`` combinations so customers who extend
``PermissionManager`` can verify their additions against the full
combinatorial surface.

Doc reference: ``16_testing.md`` §"PermissionManager test matrix",
``06_extraction_plan.md`` §0.10.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from wisdom_layer.config.flags import FeatureFlags
from wisdom_layer.config.limits import ResourceLimits
from wisdom_layer.config.lock import LockConfig
from wisdom_layer.config.session import SessionConfig


@dataclass(frozen=True)
class PermissionScenario:
    """A single configuration combination for permission testing.

    Attributes:
        label: Human-readable description of the scenario.
        lock: The LockConfig under test.
        session: The SessionConfig under test.
        limits: The ResourceLimits under test.
        flags: The FeatureFlags under test.
    """

    label: str
    lock: LockConfig
    session: SessionConfig
    limits: ResourceLimits
    flags: FeatureFlags


def build_permission_matrix(
    *,
    lock_modes: list[dict[str, Any]] | None = None,
    session_modes: list[dict[str, Any]] | None = None,
) -> list[PermissionScenario]:
    """Generate the Cartesian product of lock × session config combos.

    Args:
        lock_modes: Optional list of LockConfig kwargs dicts.
            Defaults to all meaningful combinations.
        session_modes: Optional list of SessionConfig kwargs dicts.
            Defaults to common combinations.

    Returns:
        List of :class:`PermissionScenario` instances.
    """
    if lock_modes is None:
        lock_modes = [
            {"directive_evolution_mode": "active", "memory_mode": "learning"},
            {"directive_evolution_mode": "advisory", "memory_mode": "learning"},
            {"directive_evolution_mode": "locked", "memory_mode": "read_only",
             "freeze_decay": True},
            {"directive_evolution_mode": "active", "memory_mode": "append_only"},
        ]

    if session_modes is None:
        session_modes = [
            {"ephemeral_default": False, "require_session_for_capture": False},
            {"ephemeral_default": True, "require_session_for_capture": False},
            {"ephemeral_default": False, "require_session_for_capture": True},
        ]

    scenarios: list[PermissionScenario] = []
    for lock_kwargs in lock_modes:
        for session_kwargs in session_modes:
            lock = LockConfig(**lock_kwargs)
            session = SessionConfig(**session_kwargs)
            label = (
                f"lock({lock.directive_evolution_mode}/{lock.memory_mode})"
                f"+session(eph={session.ephemeral_default},"
                f"req={session.require_session_for_capture})"
            )
            scenarios.append(
                PermissionScenario(
                    label=label,
                    lock=lock,
                    session=session,
                    limits=ResourceLimits(),
                    flags=FeatureFlags(),
                )
            )

    return scenarios
