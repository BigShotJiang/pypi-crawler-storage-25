"""Runtime helpers for the Wisdom Layer SDK.

Doc reference: ``06_extraction_plan.md`` §0.10.
"""

from wisdom_layer.runtime.snapshot import SnapshotScope

__all__ = ["SnapshotScope"]
