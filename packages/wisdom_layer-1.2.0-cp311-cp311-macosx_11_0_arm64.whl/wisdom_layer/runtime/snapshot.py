"""SnapshotScope — explicit async context manager for snapshot isolation.

Opens a backend snapshot scope, publishes the resulting ``SnapshotHandle``
for the duration of the block, and closes it on exit. Raises
``SnapshotExpiredError`` if the block exceeds
``ResourceLimits.max_snapshot_seconds``.

Usage::

    async with agent.snapshot() as snap:
        directives = await agent.directives.active()
        memories = await agent.memory.search(query, top_k=10)
        # Both reads see the same backend state.

Doc reference: ``06_extraction_plan.md`` §0.10,
``02_dream_cycles.md`` §"State Visibility Model".
"""

from __future__ import annotations

import logging
import uuid
from typing import TYPE_CHECKING

from wisdom_layer.errors import SnapshotExpiredError

if TYPE_CHECKING:
    from types import TracebackType

    from wisdom_layer.clock import Clock

logger = logging.getLogger(__name__)


class SnapshotHandle:
    """Opaque handle to an active snapshot scope.

    Attributes:
        snapshot_id: Unique identifier for this snapshot.
        opened_at: Monotonic timestamp when the scope was opened.
        max_seconds: Maximum lifetime before expiry.
    """

    def __init__(
        self,
        *,
        snapshot_id: str,
        opened_at: float,
        max_seconds: int,
        clock: Clock,
    ) -> None:
        self.snapshot_id = snapshot_id
        self.opened_at = opened_at
        self.max_seconds = max_seconds
        self._clock = clock
        self._closed = False

    @property
    def is_expired(self) -> bool:
        """Check whether the snapshot has exceeded its lifetime."""
        if self._closed:
            return True
        elapsed = self._clock.monotonic() - self.opened_at
        return elapsed >= self.max_seconds

    @property
    def age_seconds(self) -> float:
        """Seconds elapsed since the snapshot was opened."""
        return self._clock.monotonic() - self.opened_at

    def check_alive(self) -> None:
        """Raise ``SnapshotExpiredError`` if the snapshot is past its limit."""
        if self.is_expired:
            raise SnapshotExpiredError(
                snapshot_id=self.snapshot_id,
                age_seconds=self.age_seconds,
                limit_seconds=float(self.max_seconds),
            )

    def close(self) -> None:
        """Mark the snapshot as closed."""
        self._closed = True


class SnapshotScope:
    """Async context manager for snapshot isolation.

    Args:
        clock: Clock instance for timing.
        max_snapshot_seconds: Maximum scope lifetime (from ResourceLimits).
    """

    def __init__(
        self,
        *,
        clock: Clock,
        max_snapshot_seconds: int = 300,
    ) -> None:
        self._clock = clock
        self._max_seconds = max_snapshot_seconds
        self._handle: SnapshotHandle | None = None

    async def __aenter__(self) -> SnapshotHandle:
        snapshot_id = uuid.uuid4().hex[:12]
        self._handle = SnapshotHandle(
            snapshot_id=snapshot_id,
            opened_at=self._clock.monotonic(),
            max_seconds=self._max_seconds,
            clock=self._clock,
        )
        logger.info(
            "Snapshot scope opened",
            extra={
                "subsystem": "runtime.snapshot",
                "snapshot_id": snapshot_id,
                "max_seconds": self._max_seconds,
            },
        )
        return self._handle

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if self._handle is not None:
            elapsed = self._handle.age_seconds
            self._handle.close()
            logger.info(
                "Snapshot scope closed",
                extra={
                    "subsystem": "runtime.snapshot",
                    "snapshot_id": self._handle.snapshot_id,
                    "elapsed_seconds": round(elapsed, 2),
                },
            )
            self._handle = None
