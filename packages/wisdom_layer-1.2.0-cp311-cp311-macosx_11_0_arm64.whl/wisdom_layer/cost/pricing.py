"""Built-in pricing data and customer-overridable pricing table.

Doc reference: ``13_cost_model.md``.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelPricing:
    """Per-model token pricing (USD per million tokens)."""

    model_id: str
    input_rate_per_mtok: float
    output_rate_per_mtok: float


# Built-in pricing for common models (T2 — admin-tunable defaults)
BUILT_IN_PRICING: dict[str, ModelPricing] = {
    # Anthropic
    "claude-opus-4-20250514": ModelPricing("claude-opus-4-20250514", 15.0, 75.0),
    "claude-sonnet-4-20250514": ModelPricing("claude-sonnet-4-20250514", 3.0, 15.0),
    "claude-haiku-4-5-20251001": ModelPricing("claude-haiku-4-5-20251001", 0.80, 4.0),
    # OpenAI
    "gpt-4o": ModelPricing("gpt-4o", 2.50, 10.0),
    "gpt-4o-mini": ModelPricing("gpt-4o-mini", 0.15, 0.60),
    # Ollama / local (free)
    "ollama:*": ModelPricing("ollama:*", 0.0, 0.0),
}


class PricingTable:
    """Lookup table for model pricing with customer override support."""

    def __init__(self, overrides: dict[str, ModelPricing] | None = None) -> None:
        self._table: dict[str, ModelPricing] = dict(BUILT_IN_PRICING)
        if overrides:
            self._table.update(overrides)

    def get(self, model_id: str) -> ModelPricing | None:
        """Look up pricing for a model_id. Falls back to wildcard patterns."""
        if model_id in self._table:
            return self._table[model_id]
        # Try wildcard (e.g. "ollama:llama3" matches "ollama:*")
        prefix = model_id.split(":")[0] + ":*" if ":" in model_id else None
        if prefix and prefix in self._table:
            return self._table[prefix]
        return None

    def upsert(self, pricing: ModelPricing) -> None:
        """Add or update pricing for a model."""
        self._table[pricing.model_id] = pricing

    def compute_cost(
        self, model_id: str, input_tokens: int, output_tokens: int
    ) -> float:
        """Compute cost in USD for a given token usage.

        Returns 0.0 if no pricing data is available.
        """
        pricing = self.get(model_id)
        if pricing is None:
            return 0.0
        input_cost = (input_tokens / 1_000_000) * pricing.input_rate_per_mtok
        output_cost = (output_tokens / 1_000_000) * pricing.output_rate_per_mtok
        return input_cost + output_cost
