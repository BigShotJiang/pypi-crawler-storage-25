"""BudgetGuard — threshold alerts and cooldown enforcement.

Doc reference: ``13_cost_model.md``, ``02_dream_cycles.md`` §"ALERT and COOLDOWN".
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import timedelta
from typing import TYPE_CHECKING, Any, Literal

from wisdom_layer.errors import BudgetExceededError

if TYPE_CHECKING:
    from wisdom_layer.cost.tracker import CostTracker
    from wisdom_layer.storage.base import BaseBackend

logger = logging.getLogger("wisdom_layer.cost")

# T2 defaults (doc 06 constants reference)
_ALERT_THRESHOLD: float = 0.90
_COOLDOWN_THRESHOLD: float = 1.20


@dataclass
class BudgetConfig:
    """Per-agent budget configuration (T1).

    v0.5 Phase 4 adds ``monthly_cap_usd`` and ``grace_percent`` — a
    ``grace_percent`` of 10 means callers get a 10 % overrun before the
    guard trips to cooldown. Set any cap to ``0`` or ``None`` to disable.
    """

    daily_cap_usd: float = 10.0
    per_cycle_cap_usd: float = 2.0
    monthly_cap_usd: float = 0.0
    grace_percent: float = 0.0
    alert_threshold: float = _ALERT_THRESHOLD
    cooldown_threshold: float = _COOLDOWN_THRESHOLD


class BudgetGuard:
    """Enforces budget thresholds and emits alerts.

    Sits between the cost tracker and subsystems that spend money
    (dream cycles, critic evaluation, etc.). Checks pre-flight
    estimates against caps before allowing expensive operations.
    """

    def __init__(
        self,
        *,
        tracker: CostTracker,
        config: BudgetConfig | None = None,
    ) -> None:
        self._tracker = tracker
        self._config = config or BudgetConfig()
        self._in_cooldown = False

    @property
    def in_cooldown(self) -> bool:
        """Whether the agent is currently in budget cooldown."""
        return self._in_cooldown

    def check_daily(self) -> Literal["ok", "alert", "cooldown"]:
        """Check daily spend against thresholds.

        Returns:
            "ok", "alert" (>= 90% of cap), or "cooldown" (>= 120% of cap).
        """
        daily = self._tracker.daily_total()
        cap = self._config.daily_cap_usd

        if cap <= 0:
            return "ok"

        fraction = daily / cap

        if fraction >= self._config.cooldown_threshold:
            self._in_cooldown = True
            return "cooldown"
        if fraction >= self._config.alert_threshold:
            return "alert"
        return "ok"

    def preflight_cycle(
        self,
        *,
        estimated_cost_usd: float,
        cycle_id: str | None = None,
    ) -> None:
        """Pre-flight budget check before a dream cycle.

        Raises:
            BudgetExceededError: If the estimate exceeds the per-cycle cap
                or the agent is in cooldown.
        """
        if self._in_cooldown:
            daily = self._tracker.daily_total()
            raise BudgetExceededError(
                spent_usd=daily,
                cap_usd=self._config.daily_cap_usd,
                period="daily",
                cycle_id=cycle_id,
            )

        if estimated_cost_usd > self._config.per_cycle_cap_usd:
            raise BudgetExceededError(
                spent_usd=estimated_cost_usd,
                cap_usd=self._config.per_cycle_cap_usd,
                period="per_cycle",
                cycle_id=cycle_id,
            )

    async def enforce_from_backend(
        self,
        *,
        agent_id: str,
        backend: BaseBackend,
        clock_now: Any,
    ) -> None:
        """Recompute daily/monthly totals from the ledger and enforce caps.

        v0.5 Phase 4. Called by ``WisdomAgent._record_llm_usage`` after
        each successful LLM call. If the new ledger state puts the agent
        past any cap (with ``grace_percent`` applied), trips cooldown and
        raises :class:`BudgetExceededError` so the caller sees the breach
        on the first call that crosses it. Subsequent calls are blocked
        by ``_in_cooldown`` until the guard is explicitly reset.
        """
        grace = max(0.0, float(self._config.grace_percent)) / 100.0

        daily_cap = float(self._config.daily_cap_usd)
        if daily_cap > 0:
            since = (clock_now - timedelta(days=1)).isoformat()
            rows = await backend.query_cost_records(
                agent_id=agent_id, since=since,
            )
            daily_total = sum(float(r.get("cost_usd", 0.0)) for r in rows)
            if daily_total >= daily_cap * (1.0 + grace):
                self._in_cooldown = True
                raise BudgetExceededError(
                    spent_usd=daily_total,
                    cap_usd=daily_cap,
                    period="daily",
                    cycle_id=None,
                )

        monthly_cap = float(self._config.monthly_cap_usd)
        if monthly_cap > 0:
            since = (clock_now - timedelta(days=30)).isoformat()
            rows = await backend.query_cost_records(
                agent_id=agent_id, since=since,
            )
            monthly_total = sum(float(r.get("cost_usd", 0.0)) for r in rows)
            if monthly_total >= monthly_cap * (1.0 + grace):
                self._in_cooldown = True
                raise BudgetExceededError(
                    spent_usd=monthly_total,
                    cap_usd=monthly_cap,
                    period="monthly",
                    cycle_id=None,
                )

    def reset_cooldown(self) -> None:
        """Clear the cooldown flag.

        Called by operators after increasing the cap or at start of a
        new billing period. The guard re-trips on the next over-cap call.
        """
        self._in_cooldown = False
