"""CostTracker — per-agent cost accounting.

Doc reference: ``13_cost_model.md``.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime  # noqa: TC003
from typing import TYPE_CHECKING

from wisdom_layer.cost.pricing import PricingTable

if TYPE_CHECKING:
    from wisdom_layer.clock import Clock

logger = logging.getLogger("wisdom_layer.cost")


@dataclass
class CostRecord:
    """A single cost entry from an LLM call."""

    model_id: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    purpose: str
    cycle_id: str | None
    timestamp: datetime


@dataclass
class CostStats:
    """Aggregate cost statistics."""

    total_usd: float = 0.0
    total_records: int = 0
    by_model: dict[str, float] = field(default_factory=lambda: defaultdict(float))
    by_purpose: dict[str, float] = field(default_factory=lambda: defaultdict(float))
    by_day: dict[str, float] = field(default_factory=lambda: defaultdict(float))


class CostTracker:
    """In-memory cost tracker per agent.

    Records cost entries from LLM calls, provides aggregate queries,
    and feeds the BudgetGuard for threshold alerting.
    """

    def __init__(
        self,
        *,
        clock: Clock | None = None,
        pricing: PricingTable | None = None,
    ) -> None:
        from wisdom_layer.clock import SystemClock

        self._clock: Clock = clock or SystemClock()
        self._pricing = pricing or PricingTable()
        self._records: list[CostRecord] = []

    def record(
        self,
        *,
        model_id: str,
        input_tokens: int,
        output_tokens: int,
        cost_usd: float | None = None,
        purpose: str = "",
        cycle_id: str | None = None,
    ) -> CostRecord:
        """Record a cost entry.

        If ``cost_usd`` is not provided, it is computed from the pricing table.
        """
        if cost_usd is None:
            cost_usd = self._pricing.compute_cost(model_id, input_tokens, output_tokens)

        entry = CostRecord(
            model_id=model_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost_usd,
            purpose=purpose,
            cycle_id=cycle_id,
            timestamp=self._clock.now(),
        )
        self._records.append(entry)

        logger.info(
            "Cost recorded",
            extra={
                "model_id": model_id,
                "cost_usd": cost_usd,
                "purpose": purpose,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
        )
        return entry

    def daily_total(self, day: date | None = None) -> float:
        """Total cost for a given day (default: today)."""
        target = day or self._clock.now().date()
        return sum(
            r.cost_usd for r in self._records if r.timestamp.date() == target
        )

    def cycle_total(self, cycle_id: str) -> float:
        """Total cost for a specific dream cycle."""
        return sum(
            r.cost_usd for r in self._records if r.cycle_id == cycle_id
        )

    def stats(self) -> CostStats:
        """Aggregate cost statistics across all records."""
        s = CostStats()
        for r in self._records:
            s.total_usd += r.cost_usd
            s.total_records += 1
            s.by_model[r.model_id] += r.cost_usd
            s.by_purpose[r.purpose] += r.cost_usd
            s.by_day[r.timestamp.date().isoformat()] += r.cost_usd
        return s
