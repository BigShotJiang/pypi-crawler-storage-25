"""License validation and tier enforcement.

The SDK supports two key formats:

* **Signed entitlement tokens** (``wl_<tier>_<jwt>``) — cryptographically
  verified locally via the embedded Ed25519 public key. No network call
  is ever required; offline validation is *real* validation.
* **Legacy random-hex keys** (``wl_<tier>_<32-hex>``) — verified by
  round-tripping to the licensing API, with a 72-hour offline grace
  period. Maintained for early-beta keys issued before the signed
  format existed; new keys are always signed.

``parse_key_tier`` is a synchronous *peek* used during construction;
it does **not** verify signatures and must never be treated as
trusted. ``validate_license`` is the authoritative async path and
enforces every claim (signature, expiry, audience, tier consistency).
"""

from __future__ import annotations

import logging
import os
from enum import StrEnum

import httpx

from wisdom_layer._internal.entitlements import (
    EntitlementClaims,
    looks_like_signed_token,
    verify_entitlement,
)
from wisdom_layer._internal.feature_gate import check_feature as _compiled_check_feature
from wisdom_layer._internal.feature_gate import features_for as _compiled_features_for
from wisdom_layer.errors import LicenseExpiredError, LicenseInvalidError

logger = logging.getLogger(__name__)

# Base URL of the Wisdom Layer licensing API. Override for local development
# or staging by setting WISDOM_LAYER_API_URL (no trailing slash).
_DEFAULT_API_BASE = "https://api.wisdomlayer.ai"
LICENSE_API_URL = (
    os.environ.get("WISDOM_LAYER_API_URL", _DEFAULT_API_BASE).rstrip("/")
    + "/v1/license/validate"
)
SIGNUP_URL = "https://wisdomlayer.ai/signup"
OFFLINE_GRACE_HOURS = 72

# One-shot guard so the registration nudge fires at most once per process.
_NUDGE_EMITTED = False


def _emit_registration_nudge_once() -> None:
    """Log a one-time hint pointing anonymous users at /signup.

    Fires when ``WisdomAgent`` is constructed without an API key. Uses
    ``logger.info`` rather than a warning — anonymous use is fully
    supported, just shy of its full potential. Suppress entirely by
    silencing the ``wisdom_layer.license`` logger.
    """
    global _NUDGE_EMITTED
    if _NUDGE_EMITTED:
        return
    _NUDGE_EMITTED = True
    logger.info(
        "Running on anonymous Free tier. Get a registered key for free at %s "
        "to track your agents, receive updates, and unlock contextual upgrade "
        "paths as your usage grows.",
        SIGNUP_URL,
    )


class Tier(StrEnum):
    """License tiers."""

    FREE = "free"
    PRO = "pro"
    ENTERPRISE = "enterprise"


# Features gated by tier.
#
# FREE intentionally exposes ``directive_view`` (read-only) so that:
#   1. lapsed Pro users can still inspect directives they previously formed,
#   2. fresh users get a coherent empty list rather than a tier error when
#      probing the API, and
#   3. the demo path "show me what's in your agent's head" works without
#      a paid key. Mutation paths (add/promote/deactivate/reinforce/
#      run_decay) remain gated on ``directive_evolution``.
TIER_FEATURES: dict[Tier, set[str]] = {
    Tier.FREE: {
        "agent_identity",
        "tier1_memory",
        "basic_search",
        "basic_stats",
        "directive_view",
    },
    Tier.PRO: {
        "agent_identity",
        "tier1_memory",
        "tier2_memory",
        "tier3_memory",
        "basic_search",
        "semantic_search",
        "dream_cycles",
        "scheduled_dreams",
        "critic",
        "directive_view",
        "directive_evolution",
        "standard_analytics",
        "provenance",
        "provenance_trace",
        "basic_stats",
        "cost_visibility",
        "cost_budget",
        # v1.0 Beta surfaces — see AdminDefaults.enable_fact_extraction
        # and AdminDefaults.critic_verifies_grounding for opt-in.
        "fact_extraction",
        "grounding_verifier",
    },
    Tier.ENTERPRISE: {
        "agent_identity",
        "tier1_memory",
        "tier2_memory",
        "tier3_memory",
        "basic_search",
        "semantic_search",
        "dream_cycles",
        "scheduled_dreams",
        "critic",
        "directive_view",
        "directive_evolution",
        "standard_analytics",
        "advanced_analytics",
        "provenance",
        "provenance_trace",
        "provenance_explain",
        "provenance_export",
        "multi_agent_mesh",
        "cross_agent_memory",
        # v1.2.0 multi-agent moat — granular gates checked by the
        # workspace API surface. ``multi_agent_workspace`` gates
        # workspace construction; ``shared_memory_pool`` gates the
        # promote / endorse / contest / search APIs;
        # ``agent_messaging`` gates send / inbox / outbox.
        "multi_agent_workspace",
        "shared_memory_pool",
        "agent_messaging",
        "custom_dream_phases",
        "multi_tier_routing",
        "basic_stats",
        "cost_visibility",
        "cost_budget",
        "cost_export",
        "fact_extraction",
        "grounding_verifier",
        # Forward-declared Enterprise capability — see
        # BUSINESSFY/03_TIER_MATRIX.md. Tier check resolves to True
        # today; the audit-log surface ships when the first Enterprise
        # compliance customer asks for it.
        "license_audit_log",
    },
}

# Advisory agent limits per tier.  NOT enforced in the SDK — enforcement
# is backend-side via the licensing API.  Kept here only so introspection
# callers (dashboards, CLI status) can display the contractual limit
# without a network call.  Do not treat these as a security boundary.
TIER_AGENT_LIMITS_ADVISORY: dict[Tier, int] = {
    Tier.FREE: 1,
    Tier.PRO: 10,
    Tier.ENTERPRISE: 999_999,
}


def parse_key_tier(api_key: str) -> Tier:
    """Extract tier from license key prefix.

    Key format: wl_{tier}_{random}
    Examples: wl_free_abc123, wl_pro_xyz789, wl_ent_def456
    """
    if not api_key:
        _emit_registration_nudge_once()
        return Tier.FREE

    parts = api_key.split("_")
    if len(parts) < 3 or parts[0] != "wl":
        logger.warning(
            "Unrecognized api_key format (expected wl_<tier>_<id>). "
            "Defaulting to free tier. Remove api_key to suppress this "
            "warning, or get a valid key at https://wisdomlayer.ai/pricing.",
        )
        return Tier.FREE

    tier_map = {"free": Tier.FREE, "pro": Tier.PRO, "ent": Tier.ENTERPRISE}
    tier = tier_map.get(parts[1])
    if tier is None:
        logger.warning(
            "Unknown tier '%s' in api_key. Defaulting to free tier. "
            "Valid tiers: wl_free_*, wl_pro_*, wl_ent_*",
            parts[1],
        )
        return Tier.FREE
    return tier


async def validate_license_full(
    api_key: str,
) -> tuple[Tier, EntitlementClaims | None]:
    """Authoritative license validation. Returns tier *and* claims.

    Same routing rules as :func:`validate_license`, but additionally
    returns the parsed :class:`EntitlementClaims` for signed tokens so
    callers can honor the trial mechanic
    (``claims.effective_tier(now)``) without a second verify pass.

    Routing:

    * No key                  -> ``(Tier.FREE, None)`` (anonymous nudge fired).
    * Signed entitlement      -> verified locally via Ed25519 public
                                 key. Never touches the network. Returns
                                 ``(Tier(claims.tier), claims)``. Forged
                                 keys raise :class:`LicenseInvalidError`;
                                 expired keys raise
                                 :class:`LicenseExpiredError`.
    * Legacy random-hex key   -> validated against the licensing API,
                                 with a 72-hour offline grace period
                                 that trusts the prefix peek if the
                                 API is unreachable. Returns
                                 ``(tier, None)`` — legacy keys carry no
                                 trial claims.
    """
    if not api_key:
        _emit_registration_nudge_once()
        return Tier.FREE, None

    if looks_like_signed_token(api_key):
        # Local cryptographic verification — this is the trusted path
        # and never falls back to network. A LicenseInvalidError or
        # LicenseExpiredError raised here is propagated to the caller.
        claims = verify_entitlement(api_key)
        logger.info(
            "License verified locally via signed entitlement",
            extra={
                "tier": claims.tier,
                "key_id": claims.key_id,
                "expires_at": claims.expires_at.isoformat(),
                "trial_active": claims.trial_ends_at is not None,
            },
        )
        return Tier(claims.tier), claims

    # ---- Legacy random-hex key path (pre-signed-entitlements) -------
    tier = parse_key_tier(api_key)
    if tier == Tier.FREE:
        return tier, None

    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(
                LICENSE_API_URL,
                json={"key": api_key},
            )

        if response.status_code == 200:
            data = response.json()
            if data.get("valid"):
                logger.info(
                    "License validated via API (legacy key)",
                    extra={"tier": tier.value, "status": "active"},
                )
                return tier, None
            if data.get("expired"):
                raise LicenseExpiredError(
                    "License has expired. Renew at https://wisdomlayer.ai/billing"
                )
            raise LicenseInvalidError(
                "License key is invalid or revoked. Contact jeff@rhatigan.ai"
            )

    except httpx.HTTPError:
        # Offline grace period — trust the key prefix. Only applies to
        # legacy keys; signed tokens never need this and never get it.
        logger.warning(
            "License API unreachable, using offline grace period (legacy key)",
            extra={"tier": tier.value, "grace_hours": OFFLINE_GRACE_HOURS},
        )
        return tier, None

    return tier, None


async def validate_license(api_key: str) -> Tier:
    """Authoritative license validation. Returns tier only.

    Thin wrapper over :func:`validate_license_full` that drops the
    claims. Kept stable for callers that only care about the resolved
    tier (legacy SDK code paths and external consumers).
    """
    tier, _ = await validate_license_full(api_key)
    return tier


def has_feature(tier: Tier, feature: str) -> bool:
    """Check if a tier includes a specific feature.

    Delegates to the Cython-compiled ``_internal.feature_gate``
    module — the dict above is a public introspection view, not the
    authoritative source of truth. Mutating ``TIER_FEATURES`` at
    runtime cannot grant features the compiled gate denies.
    """
    return _compiled_check_feature(tier.value, feature)


def get_tier_features(tier: Tier) -> set[str]:
    """Return the full set of feature strings available at ``tier``.

    Sourced from the compiled gate so introspection agrees with the
    actual enforcement boundary even if the Python-source
    ``TIER_FEATURES`` is monkeypatched.
    """
    return set(_compiled_features_for(tier.value))
