"""PROPRIETARY — Wisdom Layer internal algorithms.

This module contains the tuned proprietary algorithms that constitute
the Wisdom Layer's core intellectual property. In production builds,
these files are compiled to .so/.pyd via Cython and are not distributed
as readable source.

DO NOT import from this module directly. All access is through the
public SDK interfaces.
"""
