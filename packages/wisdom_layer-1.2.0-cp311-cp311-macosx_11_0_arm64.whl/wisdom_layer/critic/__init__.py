"""Internal critic — evaluation, audit, and drift detection."""
