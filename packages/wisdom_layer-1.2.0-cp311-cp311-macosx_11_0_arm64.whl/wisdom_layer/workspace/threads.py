"""Thread exit policy — Multi-C surface, v1.2.0.

A multi-agent thread is a back-and-forth between two or more agents
with no built-in stopping condition. Without an exit policy, threads
either run to the rate-limit cap (wasting LLM spend) or run forever
on a loop (wasting LLM spend more impressively). :class:`ThreadExitPolicy`
is the SDK-level guard against both failure modes.

Three gates evaluate in priority order, each independently toggleable:

1. ``max_turns`` — hard ceiling, deterministic, no I/O. Always
   evaluated first because it costs nothing and provides the
   guaranteed termination property the other two gates do not.
2. ``stagnation_check`` — cosine similarity over the last two message
   bodies. Deterministic given embeddings; requires an embedder
   callable. The threshold lives in
   :mod:`wisdom_layer._internal.thread_exit` because it is the most
   sensitive tuning constant in the policy and ships compiled.
3. ``convergence_check`` — LLM judge classifies the thread as
   ``CONVERGED`` or ``OPEN``. Opportunistic: requires a judge
   callable; silently skipped when none is provided so application
   code can run the policy in a deterministic-only mode (CI, tests).
   The judge prompt and parser also live in
   :mod:`wisdom_layer._internal.thread_exit`.

The policy itself is application-layer-driven: it does not auto-fire
on every message. Application code calls
:meth:`MessageBus.evaluate_thread_exit` (or invokes the policy
directly) at whatever cadence makes sense for the deployment —
typically once per turn after a reply lands. Whether to *invoke* the
policy is an application concern (ponder loop, supervisor, etc.); the
SDK ships the primitive.

Strategist integration is explicitly out of SDK scope. See
``docs/releases/V1_2_0.md`` Multi-C Chunk D notes and
``docs/releases/VFUTURE.md:314`` / ``docs/releases/V1_3_0.md:306``.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

from wisdom_layer._internal.thread_exit import (
    CONVERGENCE_JUDGE_SYSTEM_PROMPT,
    STAGNATION_COSINE_THRESHOLD,
    build_convergence_prompt,
    cosine_similarity,
    parse_convergence_verdict,
)
from wisdom_layer.workspace.types import (
    ThreadClosedResult,
    ThreadCloseReason,
)

if TYPE_CHECKING:
    from datetime import datetime

    from wisdom_layer.workspace.types import AgentMessage


logger = logging.getLogger(__name__)


Embedder = Callable[[str], Awaitable[list[float]]]
"""``async embed(text) -> list[float]``. Provide via application code.

The policy invokes the embedder exactly twice per evaluation when the
stagnation gate is active — once for each of the last two message
bodies — so even a heavy embedder is acceptable here. The embedder
must return vectors of the same length across calls; mismatches raise
:class:`ValueError` from :func:`cosine_similarity`.
"""


LLMJudge = Callable[[str, str], Awaitable[str]]
"""``async judge(system_prompt, user_prompt) -> verdict_text``.

Symmetric with the ``model.generate(messages=..., system=...)``
contract used elsewhere in the SDK; a one-line adapter from any
provider client suffices. The judge is invoked at most once per
evaluation. The system prompt and user prompt are both supplied by
the policy — callers should not edit them, only forward them to the
underlying client.
"""


@dataclass(frozen=True)
class ThreadExitPolicy:
    """Configurable triple-gate exit policy for an agent message thread.

    Construct once per workspace (or per deployment) and reuse across
    threads. The policy itself is stateless; per-thread state lives in
    the message log and the closure row.

    Fields:
        max_turns: Hard ceiling on the number of messages in a thread.
            The thread closes with :attr:`ThreadCloseReason.MAX_TURNS`
            when ``len(messages) >= max_turns``. Always evaluated.
            Default ``10`` matches the phoenix Crucible reference; tune
            up for research / discovery threads, down for narrow
            coordination threads.
        stagnation_check: Toggle the cosine-similarity stagnation
            gate. Default ``True``. Skipped when fewer than two messages
            exist or when the caller does not supply an embedder.
        convergence_check: Toggle the LLM convergence gate. Default
            ``True``. Skipped when the caller does not supply an
            ``llm_judge`` — letting application code run a
            deterministic-only configuration without changing the
            policy object.
    """

    max_turns: int = 10
    stagnation_check: bool = True
    convergence_check: bool = True

    def __post_init__(self) -> None:
        if self.max_turns < 1:
            raise ValueError(
                "ThreadExitPolicy.max_turns must be >= 1; got "
                f"{self.max_turns}.",
            )

    async def evaluate(
        self,
        messages: list[AgentMessage],
        *,
        thread_id: str,
        now: datetime,
        embedder: Embedder | None = None,
        llm_judge: LLMJudge | None = None,
    ) -> ThreadClosedResult | None:
        """Evaluate every active gate against ``messages``.

        Returns the first :class:`ThreadClosedResult` produced by a
        tripping gate (in priority order: max_turns → stagnation →
        convergence) or ``None`` when every active gate kept the
        thread open. ``None`` is the "keep going" signal; the caller
        is responsible for actually closing the thread (via
        :meth:`MessageBus.close_thread`) when the result is non-None.
        :meth:`MessageBus.evaluate_thread_exit` does the close
        automatically and is the recommended entry point.

        Args:
            messages: Thread messages in chronological order. An empty
                list never trips any gate (``None`` returned).
            thread_id: Stamped into the returned
                :class:`ThreadClosedResult`. Required because the
                policy is stateless and the message rows do not
                redundantly carry it on the public type.
            now: Wall-clock timestamp stamped into
                :attr:`ThreadClosedResult.closed_at`. Threaded
                explicitly so the policy is testable without
                monkey-patching system time and so it composes with
                the SDK's :class:`Clock` injection pattern.
            embedder: Optional async callable for the stagnation gate.
                Skipped silently when ``None`` and
                :attr:`stagnation_check` is true.
            llm_judge: Optional async callable for the convergence
                gate. Skipped silently when ``None`` and
                :attr:`convergence_check` is true.
        """
        turn_count = len(messages)
        if turn_count == 0:
            return None

        if turn_count >= self.max_turns:
            return ThreadClosedResult(
                thread_id=thread_id,
                reason=ThreadCloseReason.MAX_TURNS,
                closed_at=now,
                turn_count=turn_count,
                similarity=None,
                judge_verdict=None,
            )

        if self.stagnation_check and embedder is not None and turn_count >= 2:
            similarity = await self._compute_stagnation_similarity(
                messages=messages, embedder=embedder,
            )
            if similarity is not None and similarity >= STAGNATION_COSINE_THRESHOLD:
                return ThreadClosedResult(
                    thread_id=thread_id,
                    reason=ThreadCloseReason.STAGNATION,
                    closed_at=now,
                    turn_count=turn_count,
                    similarity=similarity,
                    judge_verdict=None,
                )

        if self.convergence_check and llm_judge is not None:
            converged, verdict = await self._run_convergence_judge(
                messages=messages, llm_judge=llm_judge,
            )
            if converged:
                return ThreadClosedResult(
                    thread_id=thread_id,
                    reason=ThreadCloseReason.CONVERGENCE,
                    closed_at=now,
                    turn_count=turn_count,
                    similarity=None,
                    judge_verdict=verdict,
                )

        return None

    async def _compute_stagnation_similarity(
        self,
        *,
        messages: list[AgentMessage],
        embedder: Embedder,
    ) -> float | None:
        """Embed the last two message bodies and return their cosine.

        Returns ``None`` when the embedder raises — a flaky embedder
        should not crash the policy run; it should leave the gate
        un-tripped so the deterministic max_turns ceiling stays the
        guaranteed terminator. The exception is logged so debugging
        an embedding regression is not silent.
        """
        last_two = messages[-2:]
        try:
            vec_prev = await embedder(last_two[0].content)
            vec_last = await embedder(last_two[1].content)
        except Exception:  # noqa: BLE001 — embedder is application-supplied
            logger.exception(
                "ThreadExitPolicy stagnation gate skipped — embedder raised",
                extra={"subsystem": "workspace.threads"},
            )
            return None
        try:
            return cosine_similarity(vec_prev, vec_last)
        except ValueError:
            logger.exception(
                "ThreadExitPolicy stagnation gate skipped — embedding shapes mismatched",
                extra={"subsystem": "workspace.threads"},
            )
            return None

    async def _run_convergence_judge(
        self,
        *,
        messages: list[AgentMessage],
        llm_judge: LLMJudge,
    ) -> tuple[bool, str | None]:
        """Invoke the LLM judge and parse the verdict.

        Returns ``(is_converged, verdict_text)``. The judge is treated
        as advisory: any exception or malformed response leaves the
        thread open (returns ``(False, None)``) so a flaky judge does
        not silently close a live thread. Closure on ambiguity is the
        max_turns gate's job.
        """
        turns = [(m.sender_id, m.content) for m in messages]
        user_prompt = build_convergence_prompt(turns)
        try:
            verdict_text = await llm_judge(
                CONVERGENCE_JUDGE_SYSTEM_PROMPT, user_prompt,
            )
        except Exception:  # noqa: BLE001 — judge is application-supplied
            logger.exception(
                "ThreadExitPolicy convergence gate skipped — judge raised",
                extra={"subsystem": "workspace.threads"},
            )
            return (False, None)
        is_converged, summary = parse_convergence_verdict(verdict_text)
        return (is_converged, summary)


__all__ = [
    "Embedder",
    "LLMJudge",
    "ThreadExitPolicy",
]
