"""The :class:`Workspace` public class — top of the multi-agent surface.

Construction is sync (mirroring :class:`WisdomAgent`); :meth:`initialize`
is the async I/O path that:

1. Validates the api_key against the Enterprise feature gate
   (``multi_agent_workspace``).
2. Initializes the backend (which applies pending workspace migrations).
3. Upserts the canonical row in the ``workspaces`` table.

The validate-then-initialize ordering is deliberate: a Free / Pro key
must fail before any DB file is created, so a tier-rejected
construction does not leave a stray ``workspace.db`` on disk.
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC
from typing import TYPE_CHECKING

from wisdom_layer._internal.feature_gate import require_cap
from wisdom_layer._internal.team_synthesis import (
    TEAM_SYNTHESIS_SYSTEM_PROMPT,
    build_team_synthesis_prompt,
    compute_prompt_hash,
)
from wisdom_layer.clock import SystemClock
from wisdom_layer.errors import TierRestrictionError
from wisdom_layer.license import has_feature, validate_license_full
from wisdom_layer.workspace.directory import AgentDirectory
from wisdom_layer.workspace.messages import MessageBus
from wisdom_layer.workspace.pool import SharedMemoryPool
from wisdom_layer.workspace.sqlite import WorkspaceSQLiteBackend
from wisdom_layer.workspace.types import (
    DerivedProvenanceEventType,
    Visibility,
)

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent
    from wisdom_layer.clock import Clock
    from wisdom_layer.workspace.backend import BaseWorkspaceBackend
    from wisdom_layer.workspace.types import SharedMemory, TeamInsight

logger = logging.getLogger(__name__)

_WORKSPACE_FEATURE = "multi_agent_workspace"


class Workspace:
    """Multi-agent workspace — the shared backend for one team of agents.

    A :class:`Workspace` owns one ``workspace.db`` (or one Postgres DSN
    in v1.3.0+). Agents register against it via :meth:`register_agent`;
    cross-agent state — directory, shared memory pool, team insights,
    cross-agent provenance — flows through :attr:`directory`,
    :attr:`pool`, and (Multi-C, ships in v1.2.0) the messaging surface.

    Construction is sync. Call :meth:`initialize` to validate the
    license and apply schema migrations before any other method.

    Args:
        workspace_id: Stable identifier. Used as the primary key in the
            ``workspaces`` table; surfaces in the cross-agent provenance
            event log; persists for the life of the workspace. Required.
        name: Human-readable name. Surfaced in dashboards / Studio.
            Required.
        api_key: An Enterprise-tier ``wl_ent_*`` key. Validated at
            :meth:`initialize`. Free / Pro keys raise
            :class:`TierRestrictionError` and the underlying backend is
            never opened. Required.
        backend: Concrete :class:`BaseWorkspaceBackend`. Defaults to a
            :class:`WorkspaceSQLiteBackend` at ``./workspace.db``.
        config: Opaque dict persisted to ``workspaces.config``. Reserved
            for application-side configuration that should travel with
            the workspace; the SDK does not interpret its contents.
        feature_flags: Workspace-scoped feature toggles (distinct from
            license features). Persisted to ``workspaces.feature_flags``.
        clock: Optional :class:`Clock`. Defaults to :class:`SystemClock`.
    """

    def __init__(
        self,
        *,
        workspace_id: str,
        name: str,
        api_key: str,
        backend: BaseWorkspaceBackend | None = None,
        config: dict[str, object] | None = None,
        feature_flags: dict[str, bool] | None = None,
        clock: Clock | None = None,
    ) -> None:
        if not workspace_id:
            raise ValueError(
                "Workspace requires a non-empty workspace_id. "
                "Silent defaults hide tenancy and observability blindspots."
            )
        if not name:
            raise ValueError("Workspace requires a non-empty name.")
        if not api_key:
            raise ValueError(
                "Workspace requires an Enterprise-tier api_key. "
                "Multi-agent features are not available on Free or Pro."
            )

        if backend is None:
            logger.warning(
                "Workspace started without an explicit backend; using "
                "WorkspaceSQLiteBackend at ./workspace.db. Pass "
                "backend=WorkspaceSQLiteBackend('./team.db') to override.",
            )
            backend = WorkspaceSQLiteBackend("./workspace.db")

        self._workspace_id = workspace_id
        self._name = name
        self._api_key = api_key
        self._backend = backend
        self._config: dict[str, object] = dict(config or {})
        self._feature_flags: dict[str, bool] = dict(feature_flags or {})
        self._clock: Clock = clock or SystemClock()
        self._initialized = False
        self._license_jti: str = ""

        self._directory = AgentDirectory(
            backend=self._backend,
            workspace_id=self._workspace_id,
            clock=self._clock,
        )
        self._pool = SharedMemoryPool(
            backend=self._backend,
            workspace_id=self._workspace_id,
            clock=self._clock,
        )
        self._messages = MessageBus(
            backend=self._backend,
            workspace_id=self._workspace_id,
            clock=self._clock,
        )
        # In-process registry of registered agents by id. Used by Team
        # Dream Phase 1 (:meth:`team_synthesize`) to write the
        # ``team.insight.derived_from_you`` back-pointer event into each
        # contributor's per-agent ``provenance_events`` table — the
        # workspace doesn't hold per-agent backends itself, so it
        # delegates the write to the live agent handles registered here.
        # Contributors that aren't in this process at synthesis time get
        # a logged warning and skipped; the cross-agent xagent log
        # remains the canonical record either way.
        self._agents: dict[str, WisdomAgent] = {}

    # ---- Read-only public surface ---------------------------------------

    @property
    def workspace_id(self) -> str:
        return self._workspace_id

    @property
    def name(self) -> str:
        return self._name

    @property
    def directory(self) -> AgentDirectory:
        """Read-only view of the agent directory."""
        return self._directory

    @property
    def pool(self) -> SharedMemoryPool:
        """Shared memory pool surface (Multi-B)."""
        return self._pool

    @property
    def messages(self) -> MessageBus:
        """Agent-to-agent messaging bus (Multi-C)."""
        return self._messages

    # ---- Lifecycle ------------------------------------------------------

    async def initialize(self) -> None:
        """Validate the license, open the backend, and persist the workspace row.

        Raises:
            TierRestrictionError: If the api_key does not include the
                ``multi_agent_workspace`` feature. The backend is not
                opened in this case — no ``workspace.db`` file is left
                behind.
        """
        tier, claims = await validate_license_full(self._api_key)
        # The trial mechanic can grant temporary Pro features but never
        # Enterprise — multi-agent stays gated even during a trial. We
        # check the contracted tier directly rather than effective_tier,
        # so a trial Pro key cannot sneak into a workspace.
        if not has_feature(tier, _WORKSPACE_FEATURE):
            raise TierRestrictionError(
                feature=_WORKSPACE_FEATURE,
                required_tier="enterprise",
            )

        self._license_jti = claims.token_id if claims is not None else ""

        await self._backend.initialize()
        await self._backend.upsert_workspace(
            workspace_id=self._workspace_id,
            name=self._name,
            license_jti=self._license_jti,
            config=self._config,
            feature_flags=self._feature_flags,
            created_at=self._clock.now().astimezone(UTC),
        )
        self._initialized = True

        logger.info(
            "workspace initialized",
            extra={
                "subsystem": "workspace.core",
                "workspace_id": self._workspace_id,
                "tier": tier.value,
                "license_jti": self._license_jti or "legacy-or-none",
            },
        )

    async def close(self) -> None:
        """Close the underlying backend. Idempotent."""
        if self._initialized:
            await self._backend.close()
            self._initialized = False

    # ---- Agent registration ---------------------------------------------

    async def register_agent(
        self,
        agent: WisdomAgent,
        *,
        capabilities: list[str] | None = None,
    ) -> None:
        """Add ``agent`` to the workspace directory.

        Idempotent on ``(workspace_id, agent.agent_id)``. On re-register:

        * ``capabilities`` is replaced with the new value (not merged).
        * ``last_seen_at`` is refreshed.
        * ``registered_at`` is preserved from the original registration.
        * ``archived_at`` is cleared (re-register reactivates a previously
          unregistered agent).
        * ``past_success_rate`` is preserved.

        This method does not validate the agent's own license tier:
        agents register with their own keys independently. The
        workspace owner's key is the authority for membership; per-agent
        feature gates remain enforced inside each agent's own surface.

        Args:
            agent: A constructed :class:`WisdomAgent`. ``initialize()``
                does not need to have been called yet — only ``agent_id``
                is read here.
            capabilities: Free-form capability tags. Defaults to ``[]``.
        """
        self._require_initialized()
        agent_id = agent.agent_id
        await self._enforce_max_agents(joining_agent_id=agent_id)
        now = self._clock.now().astimezone(UTC)
        await self._backend.register_agent(
            workspace_id=self._workspace_id,
            agent_id=agent_id,
            capabilities=list(capabilities or []),
            registered_at=now,
            last_seen_at=now,
        )
        # Bind the agent to this workspace so agent.memory.share() and
        # agent.provenance.walk_xagent() can route through here without
        # threading the workspace handle through every call site. The
        # in-process registry tracks the live handle so Team Dream
        # Phase 1 can write back-pointer events into each contributor's
        # per-agent provenance store.
        agent._workspace = self
        self._agents[agent_id] = agent
        logger.info(
            "agent registered to workspace",
            extra={
                "subsystem": "workspace.core",
                "workspace_id": self._workspace_id,
                "agent_id": agent_id,
                "capabilities": list(capabilities or []),
            },
        )

    async def unregister_agent(self, agent_id: str) -> None:
        """Soft-archive an agent's directory entry.

        Sets ``archived_at`` on the row but leaves cross-agent provenance
        events and shared-pool contributions intact. Re-registering the
        same ``agent_id`` reactivates the row.
        """
        self._require_initialized()
        now = self._clock.now().astimezone(UTC)
        await self._backend.unregister_agent(
            workspace_id=self._workspace_id,
            agent_id=agent_id,
            archived_at=now,
        )
        # Drop the in-process handle so Team Dream Phase 1 stops writing
        # back-pointer events to a contributor that has left the
        # workspace. The agent's own ``_workspace`` attribute is left
        # intact — see test_share_unbinds_after_unregister for the
        # rationale (directory is the source of truth; the local handle
        # is an ergonomic delegation aid).
        self._agents.pop(agent_id, None)
        logger.info(
            "agent unregistered from workspace",
            extra={
                "subsystem": "workspace.core",
                "workspace_id": self._workspace_id,
                "agent_id": agent_id,
            },
        )

    async def touch_agent(self, agent_id: str) -> None:
        """Update an agent's ``last_seen_at`` to now.

        Called by liveness signals (heartbeat, message send/receive,
        shared-pool contribution). No-op if the agent is not in the
        directory.
        """
        self._require_initialized()
        await self._backend.touch_agent_seen(
            workspace_id=self._workspace_id,
            agent_id=agent_id,
            last_seen_at=self._clock.now().astimezone(UTC),
        )

    # ---- Team Dream Phase 1 — collective synthesis ----------------------
    #
    # The system prompt, user-prompt template, and idempotency-hash
    # algorithm all live in :mod:`wisdom_layer._internal.team_synthesis`
    # so they ship as compiled .so binaries on release wheels. This
    # method is intentionally a thin orchestration shell — what it does
    # is part of the public contract; how the prompt is built and hashed
    # is proprietary IP.

    async def team_synthesize(
        self,
        synthesizer: WisdomAgent,
        *,
        min_contributors: int = 2,
        visibility_in: list[Visibility] | None = None,
        pool_limit: int = 50,
        dream_cycle_id: str | None = None,
    ) -> TeamInsight | None:
        """Run a Team Dream Phase 1 collective-synthesis cycle.

        Pulls cross-agent shared memories from the pool, runs the
        synthesizer agent's LLM over them, persists the result as a
        :class:`TeamInsight`, emits :attr:`XAgentEventType.TEAM_INSIGHT_SYNTHESIZED`
        to the workspace-scoped log, and emits a
        :attr:`DerivedProvenanceEventType.TEAM_INSIGHT_DERIVED_FROM_YOU`
        back-pointer event into **each contributor's per-agent
        ``provenance_events`` table** so the contributor's own
        :meth:`agent.provenance.trace` can answer "what team-level
        outcomes did my private memory feed into."

        The contributor-threshold filter (:paramref:`min_contributors`)
        lives at this orchestration boundary — *not* in the shared
        :meth:`SharedMemoryPool.synthesize_team_insight` primitive — so
        a future per-agent change to the pool primitive cannot
        accidentally trip the team gate (per the v1.2.0 design decision
        on separation of orchestration vs. shared synthesis).

        Args:
            synthesizer: A :class:`WisdomAgent` whose LLM adapter runs
                the synthesis. Must be registered to this workspace
                (raises :class:`ValueError` otherwise — the synthesizer's
                identity is part of the dream-cycle audit, so it cannot
                be an unregistered drive-by caller).
            min_contributors: Minimum distinct contributor count in the
                pulled pool slice for synthesis to fire. ``None`` is
                returned when the threshold is not met — no LLM call,
                no insight row, no events. Default ``2`` matches the
                "team" contract (one agent's pool slice is just that
                agent's own memory).
            visibility_in: Visibility scopes to pull from. Defaults to
                ``[TEAM, PUBLIC]`` — the canonical cross-agent view.
            pool_limit: Soft cap on shared-memory rows pulled into the
                synthesis. The pool's own ranking by ``team_score``
                applies before the cap binds.
            dream_cycle_id: Optional id linking this synthesis to a
                running dream cycle in Studio. ``None`` is fine for
                stand-alone team synthesis triggered from the API.

        Returns:
            The persisted :class:`TeamInsight`, or ``None`` if the pool
            slice did not reach :paramref:`min_contributors` distinct
            contributors. Idempotent on the synthesis prompt hash —
            re-running with an identical input set returns the existing
            insight rather than producing a duplicate row, with no
            second LLM call.

        Raises:
            ValueError: If ``synthesizer`` is not registered to this
                workspace.
        """
        self._require_initialized()
        if synthesizer._workspace is not self:
            raise ValueError(
                "team_synthesize requires a synthesizer registered to "
                "this workspace. Call workspace.register_agent("
                "synthesizer) first.",
            )

        view = visibility_in if visibility_in is not None else [
            Visibility.TEAM,
            Visibility.PUBLIC,
        ]
        rows = await self._pool.list(
            visibility_in=view,
            include_archived=False,
            limit=pool_limit,
        )

        contributor_ids = {r.contributor_id for r in rows}
        if len(contributor_ids) < min_contributors:
            logger.info(
                "team synthesis skipped — below contributor threshold",
                extra={
                    "subsystem": "workspace.core",
                    "workspace_id": self._workspace_id,
                    "distinct_contributors": len(contributor_ids),
                    "min_contributors": min_contributors,
                },
            )
            return None

        prompt = build_team_synthesis_prompt(rows)
        prompt_hash = compute_prompt_hash(prompt)

        # Idempotency — if a prior run already synthesised this exact
        # input set (same prompt hash), return that insight rather than
        # paying for another LLM call. Keeps Team Dream cycles
        # deterministic when the pool is unchanged between triggers.
        existing = await self._find_team_insight_by_prompt_hash(prompt_hash)
        if existing is not None:
            return existing

        synthesis_text = await synthesizer._model.generate(
            messages=[{"role": "user", "content": prompt}],
            system=TEAM_SYNTHESIS_SYSTEM_PROMPT,
        )

        weight = 1.0 / len(rows) if rows else 0.0
        contributions: list[tuple[str, str, float]] = [
            (r.id, r.contributor_id, weight) for r in rows
        ]
        insight_id = await self._pool.synthesize_team_insight(
            content=synthesis_text,
            contributor_shared_memories=contributions,
            synthesis_prompt_hash=prompt_hash,
            dream_cycle_id=dream_cycle_id,
        )

        await self._emit_back_pointer_events(insight_id=insight_id, rows=rows)

        return await self._pool.get_team_insight(insight_id)

    async def _find_team_insight_by_prompt_hash(
        self, prompt_hash: str,
    ) -> TeamInsight | None:
        """Return the existing TeamInsight matching ``prompt_hash``, else ``None``.

        Phase 1 implementation scans the recent insight list. v1.3.0 will
        replace this with a dedicated index lookup; the column already
        exists on the row so the migration is index-only.
        """
        existing = await self._pool.list_team_insights(
            include_archived=False, limit=200,
        )
        for ins in existing:
            if ins.synthesis_prompt_hash == prompt_hash:
                return ins
        return None

    async def _emit_back_pointer_events(
        self,
        *,
        insight_id: str,
        rows: list[SharedMemory],
    ) -> None:
        """Write ``team.insight.derived_from_you`` to each contributor's per-agent log.

        The workspace doesn't hold per-agent backends directly — it
        delegates the write to the live :class:`WisdomAgent` handles
        registered via :meth:`register_agent`. Contributors not in this
        process at synthesis time get a logged warning and skipped; the
        cross-agent xagent log (already emitted by the pool) is the
        canonical record either way, so missing back-pointer events are
        recoverable but not strictly necessary for audit completeness.
        """
        per_contributor: dict[str, list[str]] = {}
        for r in rows:
            per_contributor.setdefault(r.contributor_id, []).append(r.id)

        now_iso = self._clock.now().astimezone(UTC).isoformat()
        for contributor_id, shared_ids in per_contributor.items():
            agent = self._agents.get(contributor_id)
            if agent is None:
                logger.warning(
                    "team insight back-pointer skipped — contributor "
                    "agent not registered in this process",
                    extra={
                        "subsystem": "workspace.core",
                        "workspace_id": self._workspace_id,
                        "contributor_id": contributor_id,
                        "insight_id": insight_id,
                    },
                )
                continue
            event_id = uuid.uuid4().hex[:16]
            await agent._backend.append_provenance_event(
                event_id=event_id,
                agent_id=contributor_id,
                event_type=DerivedProvenanceEventType.TEAM_INSIGHT_DERIVED_FROM_YOU,
                entity_type="team_insight",
                entity_id=insight_id,
                parent_event_id=None,
                payload={
                    "workspace_id": self._workspace_id,
                    "shared_memory_ids": shared_ids,
                    "contribution_count": len(shared_ids),
                },
                created_at=now_iso,
            )

    # ---- Internal -------------------------------------------------------

    def _require_initialized(self) -> None:
        if not self._initialized:
            raise RuntimeError(
                "Workspace not initialized. Call await workspace.initialize() first."
            )

    async def _enforce_max_agents(self, *, joining_agent_id: str) -> None:
        """Workspace-scoped agent cap.

        Read from ``config["max_agents"]``. Unset means unlimited.
        Re-registering an existing active agent does not consume a
        slot — only net-new joins are checked against the cap. Uses
        :func:`require_cap` so the error shape matches every other
        capacity violation in the SDK.
        """
        raw = self._config.get("max_agents")
        if raw is None:
            return
        if not isinstance(raw, int) or raw <= 0:
            return
        existing = await self._backend.get_agent(
            workspace_id=self._workspace_id,
            agent_id=joining_agent_id,
        )
        # Re-register of an active row does not occupy a new slot.
        if existing is not None and existing.get("archived_at") is None:
            return
        active = await self._backend.list_agents(
            workspace_id=self._workspace_id,
            include_archived=False,
        )
        require_cap(cap_kind="agents", current=len(active), limit=raw)

    async def __aenter__(self) -> Workspace:
        await self.initialize()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()
