"""Postgres skeleton for :class:`BaseWorkspaceBackend` — v1.2.0.

Intentionally a skeleton: every concrete method raises
:class:`NotImplementedError`. The migrations exist
(``migrations/workspace_postgres/0001_workspace.sql``) so the schema is
deployable in v1.2.0, and the dialect-parity test stays green; a real
implementation lands in v1.3.0 alongside mesh completion.

Why ship the skeleton at all? Two reasons:

1. **Type-checker honesty.** Code paths that depend on a workspace
   backend (Studio integration, Multi-A tests) can hold a
   :class:`BaseWorkspaceBackend` reference without case-splitting on
   "is this the SQLite one or the unimplemented Postgres one"; the ABC
   answers that.
2. **Customer migration story.** Operators on Postgres can run
   ``wisdom-layer-migrate --namespace=workspace`` against their target
   server in v1.2.0 to validate schema deployability before the runtime
   ships in v1.3.0.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from wisdom_layer.workspace.backend import BaseWorkspaceBackend

if TYPE_CHECKING:
    from datetime import datetime


_NOT_IMPLEMENTED_MSG = (
    "PostgresWorkspaceBackend is a v1.2.0 skeleton — schema migrations "
    "ship, but the runtime is unimplemented. The Postgres workspace "
    "backend lands in v1.3.0 alongside mesh completion. Use "
    "WorkspaceSQLiteBackend in the meantime."
)


class PostgresWorkspaceBackend(BaseWorkspaceBackend):
    """Postgres workspace backend — unimplemented in v1.2.0.

    Every method raises :class:`NotImplementedError` with a pointer to
    :class:`WorkspaceSQLiteBackend`. The class exists so the type
    contract holds end-to-end and so the migration namespace has an
    advertised home, but no runtime is wired up yet.
    """

    def __init__(self, dsn: str) -> None:
        self._dsn = dsn

    async def initialize(self) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def close(self) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def migration_status(self) -> dict[str, Any]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def upsert_workspace(
        self,
        *,
        workspace_id: str,
        name: str,
        license_jti: str,
        config: dict[str, object],
        feature_flags: dict[str, bool],
        created_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def get_workspace(self, *, workspace_id: str) -> dict[str, Any] | None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def archive_workspace(self, *, workspace_id: str, archived_at: datetime) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def register_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        capabilities: list[str],
        registered_at: datetime,
        last_seen_at: datetime | None = None,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def unregister_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        archived_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_agents(
        self,
        *,
        workspace_id: str,
        capability: str | None = None,
        active_since: datetime | None = None,
        include_archived: bool = False,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def get_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
    ) -> dict[str, Any] | None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def touch_agent_seen(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        last_seen_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    # ---- Shared memory pool (Multi-B) — Postgres deferred to v1.3.0 ------

    async def promote_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        contributor_id: str,
        source_memory_id: str,
        visibility: str,
        content: str,
        reason: str,
        base_score: float,
        shared_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def get_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> dict[str, Any] | None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_shared_memories(
        self,
        *,
        workspace_id: str,
        contributor_id: str | None = None,
        exclude_contributor_id: str | None = None,
        visibility_in: list[str] | None = None,
        min_base_score: float | None = None,
        include_archived: bool = False,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def archive_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        archived_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def record_endorsement(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        endorsing_agent_id: str,
        endorsed_at: datetime,
    ) -> bool:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def record_contention(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        contesting_agent_id: str,
        reason: str,
        contested_at: datetime,
    ) -> bool:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_endorsements(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_contentions(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def record_xagent_event(
        self,
        *,
        workspace_id: str,
        event_id: str,
        event_type: str,
        actor_agent_id: str | None,
        target_agent_id: str | None,
        entity_type: str,
        entity_id: str,
        parent_event_id: str | None,
        payload: dict[str, Any],
        created_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_xagent_events_by_entity(
        self,
        *,
        workspace_id: str,
        entity_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_xagent_events_by_actor(
        self,
        *,
        workspace_id: str,
        actor_agent_id: str,
        since: datetime | None = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def record_team_insight(
        self,
        *,
        workspace_id: str,
        insight_id: str,
        content: str,
        synthesis_prompt_hash: str,
        contributor_count: int,
        dream_cycle_id: str | None,
        created_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def record_team_insight_contribution(
        self,
        *,
        team_insight_id: str,
        shared_memory_id: str,
        contributor_agent_id: str,
        contribution_weight: float,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def get_team_insight(
        self,
        *,
        workspace_id: str,
        insight_id: str,
    ) -> dict[str, Any] | None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_team_insights(
        self,
        *,
        workspace_id: str,
        include_archived: bool = False,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_team_insight_contributions(
        self,
        *,
        team_insight_id: str,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    # ---- Messaging (Multi-C) — Postgres deferred to v1.3.0 ---------------

    async def record_message(
        self,
        *,
        workspace_id: str,
        message_id: str,
        sender_id: str,
        recipient_id: str | None,
        broadcast_capability: str | None,
        content: str,
        purpose: str,
        related_memory_ids: list[str],
        related_task_id: str | None,
        thread_id: str,
        in_reply_to: str | None,
        expects_reply: bool,
        reply_deadline: datetime | None,
        created_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def get_message(
        self,
        *,
        workspace_id: str,
        message_id: str,
    ) -> dict[str, Any] | None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_inbox(
        self,
        *,
        workspace_id: str,
        recipient_id: str,
        recipient_capabilities: list[str],
        unread_only: bool = True,
        include_broadcasts: bool = True,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def list_thread(
        self,
        *,
        workspace_id: str,
        thread_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def mark_message_read(
        self,
        *,
        workspace_id: str,
        message_id: str,
        reader_agent_id: str,
        read_at: datetime,
    ) -> bool:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def mark_message_replied(
        self,
        *,
        workspace_id: str,
        message_id: str,
        reply_message_id: str,
        replied_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def mark_message_expired(
        self,
        *,
        workspace_id: str,
        message_id: str,
        expired_at: datetime,
    ) -> bool:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def count_messages_sent_within(
        self,
        *,
        workspace_id: str,
        sender_id: str,
        since: datetime,
        is_broadcast: bool | None = None,
    ) -> int:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def record_rate_limit_event(
        self,
        *,
        workspace_id: str,
        sender_id: str,
        is_broadcast: bool,
        sent_at: datetime,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def prune_rate_limit_log(
        self,
        *,
        workspace_id: str,
        older_than: datetime,
    ) -> int:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def upsert_thread_closure(
        self,
        *,
        workspace_id: str,
        thread_id: str,
        closed_at: datetime,
        close_reason: str,
        close_metadata: dict[str, Any],
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)

    async def get_thread_closure(
        self,
        *,
        workspace_id: str,
        thread_id: str,
    ) -> dict[str, Any] | None:
        raise NotImplementedError(_NOT_IMPLEMENTED_MSG)
