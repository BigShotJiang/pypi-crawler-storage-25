"""Agent directory — capability-tagged roster of registered agents.

Adapts the raw rows returned by :class:`BaseWorkspaceBackend.list_agents`
to typed :class:`AgentRecord` instances. The directory is read-only on
the public surface; registration goes through :meth:`Workspace.register_agent`
so all writes pass through the same validation and event-emission path.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator
    from datetime import datetime, timedelta

    from wisdom_layer.clock import Clock
    from wisdom_layer.workspace.backend import BaseWorkspaceBackend


@dataclass(frozen=True)
class AgentRecord:
    """One row in the workspace agent directory.

    Read-only snapshot of a directory entry at the moment of fetch.
    Subsequent registrations or ``last_seen_at`` touches will not
    update an existing :class:`AgentRecord` instance — fetch a new one
    from :meth:`AgentDirectory.get` if you need fresh state.

    Fields:
        workspace_id: The owning workspace.
        agent_id: Stable per-workspace identifier (PK with ``workspace_id``).
        capabilities: Free-form capability tags supplied at registration.
            v1.2.0 makes no schema assertion about valid values; capability
            taxonomy is application-side.
        registered_at: First-seen timestamp. Preserved across re-registrations.
        last_seen_at: Refreshed on every liveness signal (heartbeat,
            shared-pool contribution, message send/receive). ``None`` until
            the first signal arrives.
        past_success_rate: Reputation metric in ``[0.0, 1.0]``. Schema
            ships at 0.0 in v1.2.0; the closed-loop writer that updates
            it (cross-agent provenance + endorsement aggregates) lands in
            v1.3.0. Surfaced now so introspection and dashboards can
            render the field once it starts moving.
        archived_at: Set by :meth:`Workspace.unregister_agent`. ``None``
            for active agents. Re-registering the same ``agent_id``
            clears the field.
    """

    workspace_id: str
    agent_id: str
    capabilities: list[str]
    registered_at: datetime
    last_seen_at: datetime | None
    past_success_rate: float
    archived_at: datetime | None


def _record_from_row(row: dict[str, Any]) -> AgentRecord:
    return AgentRecord(
        workspace_id=row["workspace_id"],
        agent_id=row["agent_id"],
        capabilities=row["capabilities"],
        registered_at=row["registered_at"],
        last_seen_at=row["last_seen_at"],
        past_success_rate=row["past_success_rate"],
        archived_at=row["archived_at"],
    )


class AgentDirectory:
    """Read-only view of the agents registered to one workspace."""

    def __init__(
        self,
        *,
        backend: BaseWorkspaceBackend,
        workspace_id: str,
        clock: Clock,
    ) -> None:
        self._backend = backend
        self._workspace_id = workspace_id
        self._clock = clock

    async def list(
        self,
        *,
        capability: str | None = None,
        active_within: timedelta | None = None,
        include_archived: bool = False,
    ) -> list[AgentRecord]:
        """Return matching directory entries.

        Args:
            capability: Filter to agents that registered with this exact
                capability tag. ``None`` (default) returns all.
            active_within: Filter to agents whose ``last_seen_at`` is
                within this window from the current clock. Agents that
                have never been seen (``last_seen_at IS NULL``) are
                excluded when this filter is set.
            include_archived: When ``False`` (default), omits
                soft-archived rows.
        """
        active_since: datetime | None = None
        if active_within is not None:
            active_since = self._clock.now() - active_within
        rows = await self._backend.list_agents(
            workspace_id=self._workspace_id,
            capability=capability,
            active_since=active_since,
            include_archived=include_archived,
        )
        return [_record_from_row(r) for r in rows]

    async def get(self, agent_id: str) -> AgentRecord | None:
        """Return the directory entry for ``agent_id``, or ``None``.

        Includes archived rows: callers can distinguish "never registered"
        (``None``) from "previously registered, since unregistered"
        (``AgentRecord`` with ``archived_at`` set).
        """
        row = await self._backend.get_agent(
            workspace_id=self._workspace_id,
            agent_id=agent_id,
        )
        if row is None:
            return None
        return _record_from_row(row)

    async def __aiter__(self) -> AsyncIterator[AgentRecord]:
        """Iterate active (non-archived) agents in registration order."""
        for record in await self.list():
            yield record
