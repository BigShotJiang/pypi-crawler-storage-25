"""SQLite implementation of :class:`BaseWorkspaceBackend`.

One ``workspace.db`` file per multi-agent deployment. Holds the
canonical workspace row, the agent directory, and (in subsequent v1.2.0
phases) the shared memory pool, team insights, and cross-agent
provenance events.

This backend is intentionally separate from :class:`SQLiteBackend`
(``wisdom_layer.storage.sqlite``). The architectural boundary is real:
per-agent state lives in the agent's own backend; cross-agent state
lives here. Mixing the two in a single file would defeat the moat's
isolation contract — see ``migrations/workspace_sqlite/0001_workspace.sql``
for the rationale.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from wisdom_layer.errors import BackendNotInitializedError
from wisdom_layer.storage._migrations import MigrationRunner
from wisdom_layer.workspace.backend import BaseWorkspaceBackend

logger = logging.getLogger(__name__)

_MIGRATIONS_DIR = Path(__file__).parent.parent / "storage" / "migrations" / "workspace_sqlite"

def _iso(dt: datetime) -> str:
    return dt.isoformat()


def _parse_iso(value: str | None) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(value)


class WorkspaceSQLiteBackend(BaseWorkspaceBackend):
    """SQLite-backed implementation of the workspace storage interface.

    Args:
        path: Path to the ``workspace.db`` file. Created if it does not
            exist. Pass ``":memory:"`` for ephemeral test backends —
            note that the same connection must be reused for the
            duration of the test, since each ``:memory:`` connection
            opens a fresh, empty database.
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path) if path != ":memory:" else Path(":memory:")
        self._conn: sqlite3.Connection | None = None

    # ---- Lifecycle -------------------------------------------------------

    async def initialize(self) -> None:
        if str(self._path) != ":memory:":
            self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.execute("PRAGMA foreign_keys=ON")

        runner = MigrationRunner(
            conn=self._conn,
            migrations_dir=_MIGRATIONS_DIR,
        )
        newly_applied = runner.apply_pending()

        logger.info(
            "workspace SQLite backend initialized",
            extra={
                "subsystem": "workspace.sqlite",
                "path": str(self._path),
                "migrations_applied": [m.name for m in newly_applied],
            },
        )

    async def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    async def migration_status(self) -> dict[str, Any]:
        runner = MigrationRunner(
            conn=self._db(),
            migrations_dir=_MIGRATIONS_DIR,
        )
        return runner.status()

    def _db(self) -> sqlite3.Connection:
        if self._conn is None:
            raise BackendNotInitializedError(
                "WorkspaceSQLiteBackend not initialized. Call initialize() first."
            )
        return self._conn

    # ---- Workspace row ---------------------------------------------------

    async def upsert_workspace(
        self,
        *,
        workspace_id: str,
        name: str,
        license_jti: str,
        config: dict[str, object],
        feature_flags: dict[str, bool],
        created_at: datetime,
    ) -> None:
        db = self._db()
        # ON CONFLICT preserves the original created_at and archived_at;
        # name, license_jti, config, and feature_flags refresh on every
        # upsert. license_jti updates so a re-init under a renewed key
        # records the new authorizing token without dropping history.
        db.execute(
            """INSERT INTO workspaces
                   (id, name, license_jti, config, feature_flags, created_at)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                   name = excluded.name,
                   license_jti = excluded.license_jti,
                   config = excluded.config,
                   feature_flags = excluded.feature_flags
            """,
            (
                workspace_id,
                name,
                license_jti,
                json.dumps(config, default=str),
                json.dumps(feature_flags),
                _iso(created_at),
            ),
        )
        db.commit()

    async def get_workspace(self, *, workspace_id: str) -> dict[str, Any] | None:
        db = self._db()
        row = db.execute(
            "SELECT id, name, license_jti, config, feature_flags, "
            "created_at, archived_at FROM workspaces WHERE id = ?",
            (workspace_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "name": row["name"],
            "license_jti": row["license_jti"],
            "config": json.loads(row["config"]),
            "feature_flags": json.loads(row["feature_flags"]),
            "created_at": _parse_iso(row["created_at"]),
            "archived_at": _parse_iso(row["archived_at"]),
        }

    async def archive_workspace(self, *, workspace_id: str, archived_at: datetime) -> None:
        db = self._db()
        db.execute(
            "UPDATE workspaces SET archived_at = ? WHERE id = ?",
            (_iso(archived_at), workspace_id),
        )
        db.commit()

    # ---- Agent directory -------------------------------------------------

    async def register_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        capabilities: list[str],
        registered_at: datetime,
        last_seen_at: datetime | None = None,
    ) -> None:
        db = self._db()
        seen = last_seen_at if last_seen_at is not None else registered_at
        # registered_at is preserved on update via COALESCE-like pattern:
        # the ON CONFLICT branch deliberately omits registered_at.
        # archived_at is cleared so re-registration reactivates a row.
        # past_success_rate is omitted so the existing value is kept.
        db.execute(
            """INSERT INTO agent_directory
                   (workspace_id, agent_id, capabilities, registered_at,
                    last_seen_at, past_success_rate, archived_at)
               VALUES (?, ?, ?, ?, ?, 0.0, NULL)
               ON CONFLICT(workspace_id, agent_id) DO UPDATE SET
                   capabilities = excluded.capabilities,
                   last_seen_at = excluded.last_seen_at,
                   archived_at = NULL
            """,
            (
                workspace_id,
                agent_id,
                json.dumps(capabilities),
                _iso(registered_at),
                _iso(seen),
            ),
        )
        db.commit()

    async def unregister_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        archived_at: datetime,
    ) -> None:
        db = self._db()
        db.execute(
            "UPDATE agent_directory SET archived_at = ? WHERE workspace_id = ? AND agent_id = ?",
            (_iso(archived_at), workspace_id, agent_id),
        )
        db.commit()

    async def list_agents(
        self,
        *,
        workspace_id: str,
        capability: str | None = None,
        active_since: datetime | None = None,
        include_archived: bool = False,
    ) -> list[dict[str, Any]]:
        db = self._db()
        clauses = ["workspace_id = ?"]
        params: list[object] = [workspace_id]
        if not include_archived:
            clauses.append("archived_at IS NULL")
        if active_since is not None:
            clauses.append("last_seen_at IS NOT NULL AND last_seen_at >= ?")
            params.append(_iso(active_since))
        sql = (
            "SELECT workspace_id, agent_id, capabilities, registered_at, "
            "last_seen_at, past_success_rate, archived_at "
            "FROM agent_directory WHERE " + " AND ".join(clauses) + " ORDER BY registered_at"
        )
        rows = db.execute(sql, tuple(params)).fetchall()
        results: list[dict[str, Any]] = []
        for row in rows:
            caps = json.loads(row["capabilities"])
            # Capability filter is applied in Python because the JSON
            # array is opaque to SQLite without json1 extension paths;
            # at v1.2.0 directory sizes are small enough that the
            # in-process filter is the right tradeoff.
            if capability is not None and capability not in caps:
                continue
            results.append(
                {
                    "workspace_id": row["workspace_id"],
                    "agent_id": row["agent_id"],
                    "capabilities": caps,
                    "registered_at": _parse_iso(row["registered_at"]),
                    "last_seen_at": _parse_iso(row["last_seen_at"]),
                    "past_success_rate": float(row["past_success_rate"]),
                    "archived_at": _parse_iso(row["archived_at"]),
                }
            )
        return results

    async def get_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
    ) -> dict[str, Any] | None:
        db = self._db()
        row = db.execute(
            "SELECT workspace_id, agent_id, capabilities, registered_at, "
            "last_seen_at, past_success_rate, archived_at "
            "FROM agent_directory WHERE workspace_id = ? AND agent_id = ?",
            (workspace_id, agent_id),
        ).fetchone()
        if row is None:
            return None
        return {
            "workspace_id": row["workspace_id"],
            "agent_id": row["agent_id"],
            "capabilities": json.loads(row["capabilities"]),
            "registered_at": _parse_iso(row["registered_at"]),
            "last_seen_at": _parse_iso(row["last_seen_at"]),
            "past_success_rate": float(row["past_success_rate"]),
            "archived_at": _parse_iso(row["archived_at"]),
        }

    async def touch_agent_seen(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        last_seen_at: datetime,
    ) -> None:
        db = self._db()
        db.execute(
            "UPDATE agent_directory SET last_seen_at = ? WHERE workspace_id = ? AND agent_id = ?",
            (_iso(last_seen_at), workspace_id, agent_id),
        )
        db.commit()

    # ---- Shared memory pool (Multi-B) ------------------------------------

    def _shared_memory_row_to_dict(self, row: sqlite3.Row) -> dict[str, Any]:
        """Map a ``shared_memory_pool`` row to the documented dict shape."""
        return {
            "id": row["id"],
            "workspace_id": row["workspace_id"],
            "contributor_id": row["contributor_id"],
            "source_memory_id": row["source_memory_id"],
            "visibility": row["visibility"],
            "content": row["content"],
            "reason": row["reason"],
            "endorsement_count": int(row["endorsement_count"]),
            "contention_count": int(row["contention_count"]),
            "base_score": float(row["base_score"]),
            "shared_at": _parse_iso(row["shared_at"]),
            "archived_at": _parse_iso(row["archived_at"]),
        }

    async def promote_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        contributor_id: str,
        source_memory_id: str,
        visibility: str,
        content: str,
        reason: str,
        base_score: float,
        shared_at: datetime,
    ) -> None:
        db = self._db()
        # ON CONFLICT DO NOTHING preserves the original row on a re-share
        # of the same (contributor, source_memory) — promote() at the SDK
        # layer derives shared_memory_id deterministically from
        # (contributor_id, source_memory_id) so callers can call promote
        # idempotently without an existence check. Counters and base_score
        # on the original row are preserved; the stale ``content`` /
        # ``reason`` / ``visibility`` from the new call are dropped because
        # the caller is asserting "this private memory is shared," not
        # "rewrite the canonical shared text" — that path is :meth:`update`
        # / :meth:`archive` + re-promote, neither of which exists in v1.2.0.
        db.execute(
            """INSERT INTO shared_memory_pool
                   (id, workspace_id, contributor_id, source_memory_id,
                    visibility, content, reason, endorsement_count,
                    contention_count, base_score, shared_at, archived_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, NULL)
               ON CONFLICT(id) DO NOTHING
            """,
            (
                shared_memory_id,
                workspace_id,
                contributor_id,
                source_memory_id,
                visibility,
                content,
                reason,
                base_score,
                _iso(shared_at),
            ),
        )
        db.commit()

    async def get_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> dict[str, Any] | None:
        db = self._db()
        row = db.execute(
            "SELECT id, workspace_id, contributor_id, source_memory_id, "
            "visibility, content, reason, endorsement_count, contention_count, "
            "base_score, shared_at, archived_at "
            "FROM shared_memory_pool WHERE workspace_id = ? AND id = ?",
            (workspace_id, shared_memory_id),
        ).fetchone()
        if row is None:
            return None
        return self._shared_memory_row_to_dict(row)

    async def list_shared_memories(
        self,
        *,
        workspace_id: str,
        contributor_id: str | None = None,
        exclude_contributor_id: str | None = None,
        visibility_in: list[str] | None = None,
        min_base_score: float | None = None,
        include_archived: bool = False,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        if contributor_id is not None and exclude_contributor_id is not None:
            raise ValueError(
                "Pass at most one of contributor_id / exclude_contributor_id; "
                "the two filters are mutually exclusive."
            )
        db = self._db()
        clauses = ["workspace_id = ?"]
        params: list[object] = [workspace_id]
        if contributor_id is not None:
            clauses.append("contributor_id = ?")
            params.append(contributor_id)
        if exclude_contributor_id is not None:
            clauses.append("contributor_id != ?")
            params.append(exclude_contributor_id)
        if visibility_in is not None:
            if not visibility_in:
                # Empty allowlist — no row can match. Short-circuit so we
                # don't generate ``visibility IN ()`` which is a SQL error.
                return []
            placeholders = ", ".join("?" for _ in visibility_in)
            clauses.append(f"visibility IN ({placeholders})")
            params.extend(visibility_in)
        if min_base_score is not None:
            clauses.append("base_score >= ?")
            params.append(min_base_score)
        if not include_archived:
            clauses.append("archived_at IS NULL")
        sql = (
            "SELECT id, workspace_id, contributor_id, source_memory_id, "
            "visibility, content, reason, endorsement_count, contention_count, "
            "base_score, shared_at, archived_at "
            "FROM shared_memory_pool WHERE "
            + " AND ".join(clauses)
            + " ORDER BY shared_at DESC LIMIT ?"
        )
        params.append(limit)
        rows = db.execute(sql, tuple(params)).fetchall()
        return [self._shared_memory_row_to_dict(row) for row in rows]

    async def archive_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        archived_at: datetime,
    ) -> None:
        db = self._db()
        db.execute(
            "UPDATE shared_memory_pool SET archived_at = ? "
            "WHERE workspace_id = ? AND id = ?",
            (_iso(archived_at), workspace_id, shared_memory_id),
        )
        db.commit()

    # ---- Endorsements & contentions (Multi-B) ----------------------------

    def _shared_memory_belongs_to_workspace(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> bool:
        """Tenancy check used by endorse / contest before mutating counters."""
        db = self._db()
        row = db.execute(
            "SELECT 1 FROM shared_memory_pool "
            "WHERE workspace_id = ? AND id = ? LIMIT 1",
            (workspace_id, shared_memory_id),
        ).fetchone()
        return row is not None

    async def record_endorsement(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        endorsing_agent_id: str,
        endorsed_at: datetime,
    ) -> bool:
        db = self._db()
        if not self._shared_memory_belongs_to_workspace(
            workspace_id=workspace_id, shared_memory_id=shared_memory_id
        ):
            # Tenancy isolation: refuse to record an endorsement against a
            # shared memory that does not exist in the named workspace.
            # Returning False (rather than raising) matches the duplicate-
            # endorsement contract; the caller cannot distinguish "duplicate"
            # from "wrong workspace" but neither is an exceptional condition
            # for this method's contract.
            return False
        # The composite primary key on shared_memory_endorsements
        # ((shared_memory_id, endorsing_agent_id)) gives us atomic
        # idempotency. INSERT OR IGNORE returns rowcount == 0 on a
        # duplicate, allowing us to skip the counter increment.
        cur = db.execute(
            "INSERT OR IGNORE INTO shared_memory_endorsements "
            "(shared_memory_id, endorsing_agent_id, endorsed_at) "
            "VALUES (?, ?, ?)",
            (shared_memory_id, endorsing_agent_id, _iso(endorsed_at)),
        )
        is_new = cur.rowcount == 1
        if is_new:
            db.execute(
                "UPDATE shared_memory_pool "
                "SET endorsement_count = endorsement_count + 1 "
                "WHERE workspace_id = ? AND id = ?",
                (workspace_id, shared_memory_id),
            )
        db.commit()
        return is_new

    async def record_contention(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        contesting_agent_id: str,
        reason: str,
        contested_at: datetime,
    ) -> bool:
        db = self._db()
        if not self._shared_memory_belongs_to_workspace(
            workspace_id=workspace_id, shared_memory_id=shared_memory_id
        ):
            return False
        cur = db.execute(
            "INSERT OR IGNORE INTO shared_memory_contentions "
            "(shared_memory_id, contesting_agent_id, reason, contested_at) "
            "VALUES (?, ?, ?, ?)",
            (shared_memory_id, contesting_agent_id, reason, _iso(contested_at)),
        )
        is_new = cur.rowcount == 1
        if is_new:
            db.execute(
                "UPDATE shared_memory_pool "
                "SET contention_count = contention_count + 1 "
                "WHERE workspace_id = ? AND id = ?",
                (workspace_id, shared_memory_id),
            )
        db.commit()
        return is_new

    async def list_endorsements(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> list[dict[str, Any]]:
        db = self._db()
        # Tenancy: join to shared_memory_pool to filter by workspace_id so
        # callers cannot enumerate endorsements for a memory they do not
        # own. The shared_memory_endorsements table itself is keyed only
        # on shared_memory_id; the pool row is the workspace anchor.
        rows = db.execute(
            "SELECT e.shared_memory_id, e.endorsing_agent_id, e.endorsed_at "
            "FROM shared_memory_endorsements AS e "
            "JOIN shared_memory_pool AS p "
            "  ON p.id = e.shared_memory_id "
            "WHERE p.workspace_id = ? AND e.shared_memory_id = ? "
            "ORDER BY e.endorsed_at",
            (workspace_id, shared_memory_id),
        ).fetchall()
        return [
            {
                "shared_memory_id": row["shared_memory_id"],
                "endorsing_agent_id": row["endorsing_agent_id"],
                "endorsed_at": _parse_iso(row["endorsed_at"]),
            }
            for row in rows
        ]

    async def list_contentions(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> list[dict[str, Any]]:
        db = self._db()
        rows = db.execute(
            "SELECT c.shared_memory_id, c.contesting_agent_id, c.reason, c.contested_at "
            "FROM shared_memory_contentions AS c "
            "JOIN shared_memory_pool AS p "
            "  ON p.id = c.shared_memory_id "
            "WHERE p.workspace_id = ? AND c.shared_memory_id = ? "
            "ORDER BY c.contested_at",
            (workspace_id, shared_memory_id),
        ).fetchall()
        return [
            {
                "shared_memory_id": row["shared_memory_id"],
                "contesting_agent_id": row["contesting_agent_id"],
                "reason": row["reason"],
                "contested_at": _parse_iso(row["contested_at"]),
            }
            for row in rows
        ]

    # ---- Cross-agent provenance events (Multi-B) -------------------------

    def _xagent_event_row_to_dict(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "event_id": row["event_id"],
            "workspace_id": row["workspace_id"],
            "event_type": row["event_type"],
            "actor_agent_id": row["actor_agent_id"],
            "target_agent_id": row["target_agent_id"],
            "entity_type": row["entity_type"],
            "entity_id": row["entity_id"],
            "parent_event_id": row["parent_event_id"],
            "payload": json.loads(row["payload"]),
            "created_at": _parse_iso(row["created_at"]),
        }

    async def record_xagent_event(
        self,
        *,
        workspace_id: str,
        event_id: str,
        event_type: str,
        actor_agent_id: str | None,
        target_agent_id: str | None,
        entity_type: str,
        entity_id: str,
        parent_event_id: str | None,
        payload: dict[str, Any],
        created_at: datetime,
    ) -> None:
        db = self._db()
        # Append-only by contract: no ON CONFLICT clause, no upsert path.
        # A duplicate event_id raises sqlite3.IntegrityError so callers
        # can detect double-emits during development; the SDK assigns
        # ULID-style event_ids so collisions in production are not a
        # realistic concern.
        db.execute(
            """INSERT INTO cross_agent_provenance_events
                   (event_id, workspace_id, event_type, actor_agent_id,
                    target_agent_id, entity_type, entity_id, parent_event_id,
                    payload, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event_id,
                workspace_id,
                event_type,
                actor_agent_id,
                target_agent_id,
                entity_type,
                entity_id,
                parent_event_id,
                json.dumps(payload, default=str),
                _iso(created_at),
            ),
        )
        db.commit()

    async def list_xagent_events_by_entity(
        self,
        *,
        workspace_id: str,
        entity_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        db = self._db()
        rows = db.execute(
            "SELECT event_id, workspace_id, event_type, actor_agent_id, "
            "target_agent_id, entity_type, entity_id, parent_event_id, "
            "payload, created_at "
            "FROM cross_agent_provenance_events "
            "WHERE workspace_id = ? AND entity_id = ? "
            "ORDER BY created_at LIMIT ?",
            (workspace_id, entity_id, limit),
        ).fetchall()
        return [self._xagent_event_row_to_dict(row) for row in rows]

    async def list_xagent_events_by_actor(
        self,
        *,
        workspace_id: str,
        actor_agent_id: str,
        since: datetime | None = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        db = self._db()
        clauses = ["workspace_id = ?", "actor_agent_id = ?"]
        params: list[object] = [workspace_id, actor_agent_id]
        if since is not None:
            clauses.append("created_at >= ?")
            params.append(_iso(since))
        sql = (
            "SELECT event_id, workspace_id, event_type, actor_agent_id, "
            "target_agent_id, entity_type, entity_id, parent_event_id, "
            "payload, created_at "
            "FROM cross_agent_provenance_events WHERE "
            + " AND ".join(clauses)
            + " ORDER BY created_at LIMIT ?"
        )
        params.append(limit)
        rows = db.execute(sql, tuple(params)).fetchall()
        return [self._xagent_event_row_to_dict(row) for row in rows]

    # ---- Team insights (Multi-B) -----------------------------------------

    def _team_insight_row_to_dict(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "workspace_id": row["workspace_id"],
            "content": row["content"],
            "synthesis_prompt_hash": row["synthesis_prompt_hash"],
            "contributor_count": int(row["contributor_count"]),
            "dream_cycle_id": row["dream_cycle_id"],
            "created_at": _parse_iso(row["created_at"]),
            "archived_at": _parse_iso(row["archived_at"]),
        }

    async def record_team_insight(
        self,
        *,
        workspace_id: str,
        insight_id: str,
        content: str,
        synthesis_prompt_hash: str,
        contributor_count: int,
        dream_cycle_id: str | None,
        created_at: datetime,
    ) -> None:
        db = self._db()
        db.execute(
            """INSERT INTO team_insights
                   (id, workspace_id, content, synthesis_prompt_hash,
                    contributor_count, dream_cycle_id, created_at, archived_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, NULL)
            """,
            (
                insight_id,
                workspace_id,
                content,
                synthesis_prompt_hash,
                contributor_count,
                dream_cycle_id,
                _iso(created_at),
            ),
        )
        db.commit()

    async def record_team_insight_contribution(
        self,
        *,
        team_insight_id: str,
        shared_memory_id: str,
        contributor_agent_id: str,
        contribution_weight: float,
    ) -> None:
        db = self._db()
        # Idempotent on the composite primary key — a re-record of the
        # same (team_insight_id, shared_memory_id) is a no-op.
        db.execute(
            """INSERT INTO team_insight_contributions
                   (team_insight_id, shared_memory_id, contributor_agent_id,
                    contribution_weight)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(team_insight_id, shared_memory_id) DO NOTHING
            """,
            (
                team_insight_id,
                shared_memory_id,
                contributor_agent_id,
                contribution_weight,
            ),
        )
        db.commit()

    async def get_team_insight(
        self,
        *,
        workspace_id: str,
        insight_id: str,
    ) -> dict[str, Any] | None:
        db = self._db()
        row = db.execute(
            "SELECT id, workspace_id, content, synthesis_prompt_hash, "
            "contributor_count, dream_cycle_id, created_at, archived_at "
            "FROM team_insights WHERE workspace_id = ? AND id = ?",
            (workspace_id, insight_id),
        ).fetchone()
        if row is None:
            return None
        return self._team_insight_row_to_dict(row)

    async def list_team_insights(
        self,
        *,
        workspace_id: str,
        include_archived: bool = False,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        db = self._db()
        clauses = ["workspace_id = ?"]
        params: list[object] = [workspace_id]
        if not include_archived:
            clauses.append("archived_at IS NULL")
        sql = (
            "SELECT id, workspace_id, content, synthesis_prompt_hash, "
            "contributor_count, dream_cycle_id, created_at, archived_at "
            "FROM team_insights WHERE "
            + " AND ".join(clauses)
            + " ORDER BY created_at DESC LIMIT ?"
        )
        params.append(limit)
        rows = db.execute(sql, tuple(params)).fetchall()
        return [self._team_insight_row_to_dict(row) for row in rows]

    async def list_team_insight_contributions(
        self,
        *,
        team_insight_id: str,
    ) -> list[dict[str, Any]]:
        db = self._db()
        rows = db.execute(
            "SELECT team_insight_id, shared_memory_id, contributor_agent_id, "
            "contribution_weight "
            "FROM team_insight_contributions "
            "WHERE team_insight_id = ? "
            "ORDER BY contributor_agent_id, shared_memory_id",
            (team_insight_id,),
        ).fetchall()
        return [
            {
                "team_insight_id": row["team_insight_id"],
                "shared_memory_id": row["shared_memory_id"],
                "contributor_agent_id": row["contributor_agent_id"],
                "contribution_weight": float(row["contribution_weight"]),
            }
            for row in rows
        ]

    # ---- Messaging (Multi-C) ---------------------------------------------

    # Column list factored out so every SELECT against agent_messages
    # reads the same shape; _message_row_to_dict assumes this exact set.
    _MESSAGE_COLUMNS = (
        "id, workspace_id, sender_id, recipient_id, broadcast_capability, "
        "content, purpose, related_memory_ids, related_task_id, thread_id, "
        "in_reply_to, expects_reply, reply_deadline, status, read_at, "
        "replied_at, reply_message_id, created_at"
    )

    def _message_row_to_dict(self, row: sqlite3.Row) -> dict[str, Any]:
        """Map an ``agent_messages`` row to the documented dict shape.

        ``expects_reply`` is stored as ``INTEGER`` and projected as
        ``bool`` so the boundary type matches the Postgres dialect (which
        stores it as ``BOOLEAN``). Timestamps remain strings on the row
        and are parsed to ``datetime`` here.
        """
        return {
            "id": row["id"],
            "workspace_id": row["workspace_id"],
            "sender_id": row["sender_id"],
            "recipient_id": row["recipient_id"],
            "broadcast_capability": row["broadcast_capability"],
            "content": row["content"],
            "purpose": row["purpose"],
            "related_memory_ids": json.loads(row["related_memory_ids"]),
            "related_task_id": row["related_task_id"],
            "thread_id": row["thread_id"],
            "in_reply_to": row["in_reply_to"],
            "expects_reply": bool(row["expects_reply"]),
            "reply_deadline": _parse_iso(row["reply_deadline"]),
            "status": row["status"],
            "read_at": _parse_iso(row["read_at"]),
            "replied_at": _parse_iso(row["replied_at"]),
            "reply_message_id": row["reply_message_id"],
            "created_at": _parse_iso(row["created_at"]),
        }

    async def record_message(
        self,
        *,
        workspace_id: str,
        message_id: str,
        sender_id: str,
        recipient_id: str | None,
        broadcast_capability: str | None,
        content: str,
        purpose: str,
        related_memory_ids: list[str],
        related_task_id: str | None,
        thread_id: str,
        in_reply_to: str | None,
        expects_reply: bool,
        reply_deadline: datetime | None,
        created_at: datetime,
    ) -> None:
        db = self._db()
        # Status defaults to 'pending' at insert; transitions go through
        # mark_message_read / mark_message_replied / mark_message_expired.
        # No ON CONFLICT clause: a duplicate message_id is a programming
        # error from the bus (which assigns ULID-style ids) and should
        # surface as an integrity error rather than silently collapse.
        db.execute(
            """INSERT INTO agent_messages
                   (id, workspace_id, sender_id, recipient_id,
                    broadcast_capability, content, purpose,
                    related_memory_ids, related_task_id, thread_id,
                    in_reply_to, expects_reply, reply_deadline, status,
                    read_at, replied_at, reply_message_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending',
                       NULL, NULL, NULL, ?)
            """,
            (
                message_id,
                workspace_id,
                sender_id,
                recipient_id,
                broadcast_capability,
                content,
                purpose,
                json.dumps(related_memory_ids),
                related_task_id,
                thread_id,
                in_reply_to,
                1 if expects_reply else 0,
                _iso(reply_deadline) if reply_deadline is not None else None,
                _iso(created_at),
            ),
        )
        db.commit()

    async def get_message(
        self,
        *,
        workspace_id: str,
        message_id: str,
    ) -> dict[str, Any] | None:
        db = self._db()
        row = db.execute(
            f"SELECT {self._MESSAGE_COLUMNS} FROM agent_messages "
            "WHERE workspace_id = ? AND id = ?",
            (workspace_id, message_id),
        ).fetchone()
        if row is None:
            return None
        return self._message_row_to_dict(row)

    async def list_inbox(
        self,
        *,
        workspace_id: str,
        recipient_id: str,
        recipient_capabilities: list[str],
        unread_only: bool = True,
        include_broadcasts: bool = True,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        db = self._db()
        # Inbox is the union of two slices:
        #   1. Direct messages addressed to recipient_id.
        #   2. Broadcasts whose broadcast_capability matches one of the
        #      recipient's capabilities, less those the recipient has
        #      already acked in broadcast_reads.
        # The two legs are unioned in SQL so the LIMIT cap is global
        # (applying ORDER BY in Python after fetching unbounded slices
        # would let a large broadcast volume crowd out direct mail).
        legs: list[str] = []
        params: list[object] = []

        direct_clauses = ["workspace_id = ?", "recipient_id = ?"]
        params.extend([workspace_id, recipient_id])
        if unread_only:
            direct_clauses.append("status = 'pending'")
        legs.append(
            f"SELECT {self._MESSAGE_COLUMNS} FROM agent_messages "
            "WHERE " + " AND ".join(direct_clauses)
        )

        if include_broadcasts and recipient_capabilities:
            placeholders = ", ".join("?" for _ in recipient_capabilities)
            bcast_clauses = [
                "workspace_id = ?",
                "recipient_id IS NULL",
                f"broadcast_capability IN ({placeholders})",
            ]
            params.append(workspace_id)
            params.extend(recipient_capabilities)
            if unread_only:
                # Hide broadcasts the reader has already acked. We
                # reference the table by alias-free name because the leg
                # is parsed independently of the union.
                bcast_clauses.append(
                    "NOT EXISTS (SELECT 1 FROM broadcast_reads br "
                    "WHERE br.message_id = agent_messages.id "
                    "AND br.reader_agent_id = ?)"
                )
                params.append(recipient_id)
            legs.append(
                f"SELECT {self._MESSAGE_COLUMNS} FROM agent_messages "
                "WHERE " + " AND ".join(bcast_clauses)
            )

        sql = " UNION ALL ".join(legs) + " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        rows = db.execute(sql, tuple(params)).fetchall()
        return [self._message_row_to_dict(row) for row in rows]

    async def list_thread(
        self,
        *,
        workspace_id: str,
        thread_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        db = self._db()
        rows = db.execute(
            f"SELECT {self._MESSAGE_COLUMNS} FROM agent_messages "
            "WHERE workspace_id = ? AND thread_id = ? "
            "ORDER BY created_at LIMIT ?",
            (workspace_id, thread_id, limit),
        ).fetchall()
        return [self._message_row_to_dict(row) for row in rows]

    async def mark_message_read(
        self,
        *,
        workspace_id: str,
        message_id: str,
        reader_agent_id: str,
        read_at: datetime,
    ) -> bool:
        db = self._db()
        # Branch on direct vs broadcast: the two surfaces have different
        # ack tables. Read the message row first so we know which path to
        # take; the cost of the extra round-trip is dwarfed by the
        # contract clarity.
        row = db.execute(
            "SELECT recipient_id, broadcast_capability, status "
            "FROM agent_messages WHERE workspace_id = ? AND id = ?",
            (workspace_id, message_id),
        ).fetchone()
        if row is None:
            return False
        if row["broadcast_capability"] is not None:
            # Broadcast: per-(message, reader) ack via broadcast_reads.
            # INSERT OR IGNORE collapses duplicates atomically; rowcount
            # tells us whether this was the first ack from this reader.
            cur = db.execute(
                "INSERT OR IGNORE INTO broadcast_reads "
                "(message_id, reader_agent_id, read_at) VALUES (?, ?, ?)",
                (message_id, reader_agent_id, _iso(read_at)),
            )
            db.commit()
            return cur.rowcount == 1
        # Direct: only the addressed recipient may transition the row,
        # and only PENDING → READ. Any other state (already read /
        # replied / expired) is a no-op returning False.
        if row["recipient_id"] != reader_agent_id:
            return False
        cur = db.execute(
            "UPDATE agent_messages SET status = 'read', read_at = ? "
            "WHERE workspace_id = ? AND id = ? AND status = 'pending'",
            (_iso(read_at), workspace_id, message_id),
        )
        db.commit()
        return cur.rowcount > 0

    async def mark_message_replied(
        self,
        *,
        workspace_id: str,
        message_id: str,
        reply_message_id: str,
        replied_at: datetime,
    ) -> None:
        db = self._db()
        # First-reply-wins: the WHERE clause guards on replied_at IS NULL
        # so a second mark_replied call with a different reply_message_id
        # is a silent no-op (the original reply remains canonical). This
        # keeps the bus deterministic when two replies race; the SDK
        # could detect the loss but the contract is "first wins" and
        # raising would surface a non-actionable error at the bus layer.
        db.execute(
            "UPDATE agent_messages "
            "SET status = 'replied', replied_at = ?, reply_message_id = ? "
            "WHERE workspace_id = ? AND id = ? AND replied_at IS NULL",
            (_iso(replied_at), reply_message_id, workspace_id, message_id),
        )
        db.commit()

    async def mark_message_expired(
        self,
        *,
        workspace_id: str,
        message_id: str,
        expired_at: datetime,
    ) -> bool:
        db = self._db()
        # Only PENDING transitions to EXPIRED. A message already READ /
        # REPLIED / EXPIRED is past the lazy-expiry boundary and the
        # call is a no-op. read_at stays NULL on expiry — the recipient
        # never acknowledged the row.
        cur = db.execute(
            "UPDATE agent_messages SET status = 'expired' "
            "WHERE workspace_id = ? AND id = ? AND status = 'pending'",
            (workspace_id, message_id),
        )
        db.commit()
        # `expired_at` is intentionally unused at the SQL layer: the
        # schema has no expired_at column today (the rate-limit and
        # audit story can be reconstructed from the rate-limit log and
        # cross-agent provenance events). Keeping the parameter on the
        # ABC reserves the column rename optionality for v1.3.0 without
        # a backend signature break.
        del expired_at
        return cur.rowcount > 0

    async def count_messages_sent_within(
        self,
        *,
        workspace_id: str,
        sender_id: str,
        since: datetime,
        is_broadcast: bool | None = None,
    ) -> int:
        db = self._db()
        clauses = [
            "workspace_id = ?",
            "sender_id = ?",
            "sent_at >= ?",
        ]
        params: list[object] = [workspace_id, sender_id, _iso(since)]
        if is_broadcast is not None:
            clauses.append("is_broadcast = ?")
            params.append(1 if is_broadcast else 0)
        sql = (
            "SELECT COUNT(*) AS c FROM message_rate_limit_log WHERE "
            + " AND ".join(clauses)
        )
        row = db.execute(sql, tuple(params)).fetchone()
        return int(row["c"]) if row is not None else 0

    async def record_rate_limit_event(
        self,
        *,
        workspace_id: str,
        sender_id: str,
        is_broadcast: bool,
        sent_at: datetime,
    ) -> None:
        db = self._db()
        # Append-only. The MessageBus calls record_message + this method
        # in sequence; a partial failure between the two is recoverable
        # because count_messages_sent_within reads only this log, so a
        # missing counter row strictly under-counts (favours the sender)
        # rather than blocking. The reverse (counter row without the
        # message) would over-count; the bus orders the writes to make
        # under-counting the only possible drift.
        db.execute(
            "INSERT INTO message_rate_limit_log "
            "(workspace_id, sender_id, is_broadcast, sent_at) "
            "VALUES (?, ?, ?, ?)",
            (workspace_id, sender_id, 1 if is_broadcast else 0, _iso(sent_at)),
        )
        db.commit()

    async def prune_rate_limit_log(
        self,
        *,
        workspace_id: str,
        older_than: datetime,
    ) -> int:
        db = self._db()
        cur = db.execute(
            "DELETE FROM message_rate_limit_log "
            "WHERE workspace_id = ? AND sent_at < ?",
            (workspace_id, _iso(older_than)),
        )
        db.commit()
        return cur.rowcount

    async def upsert_thread_closure(
        self,
        *,
        workspace_id: str,
        thread_id: str,
        closed_at: datetime,
        close_reason: str,
        close_metadata: dict[str, Any],
    ) -> None:
        db = self._db()
        # First-closure-wins on (closed_at, close_reason); subsequent
        # calls overwrite close_metadata only. This lets a re-evaluation
        # of the same thread refresh evidence (e.g., a stale similarity
        # score) without rewriting the historical "why this closed"
        # record. The ABC contract is documented at the abstract method.
        db.execute(
            """INSERT INTO message_threads
                   (workspace_id, thread_id, closed_at, close_reason, close_metadata)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(workspace_id, thread_id) DO UPDATE SET
                   close_metadata = excluded.close_metadata
            """,
            (
                workspace_id,
                thread_id,
                _iso(closed_at),
                close_reason,
                json.dumps(close_metadata, default=str),
            ),
        )
        db.commit()

    async def get_thread_closure(
        self,
        *,
        workspace_id: str,
        thread_id: str,
    ) -> dict[str, Any] | None:
        db = self._db()
        row = db.execute(
            "SELECT workspace_id, thread_id, closed_at, close_reason, close_metadata "
            "FROM message_threads WHERE workspace_id = ? AND thread_id = ?",
            (workspace_id, thread_id),
        ).fetchone()
        if row is None:
            return None
        return {
            "workspace_id": row["workspace_id"],
            "thread_id": row["thread_id"],
            "closed_at": _parse_iso(row["closed_at"]),
            "close_reason": row["close_reason"],
            "close_metadata": json.loads(row["close_metadata"]),
        }
