"""Agent-to-agent messaging bus — Multi-C surface, v1.2.0.

Mirrors :class:`SharedMemoryPool` in shape: holds a reference to a
:class:`BaseWorkspaceBackend` plus the workspace's ``workspace_id`` and
threads both into every backend call. The bus owns four
responsibilities the backend layer deliberately does not:

1. **Rate limiting.** Every send / broadcast checks the rolling-hour
   counter in ``message_rate_limit_log`` against the configured caps and
   raises :class:`MessageRateLimitExceededError` before the message row
   is written. The check + record pair is intentionally not atomic
   across the two backend calls — a partial failure under-counts (the
   sender is favoured) rather than over-counts, which would silently
   block legitimate sends.
2. **Lazy expiry.** :meth:`get`, :meth:`list_inbox`, and
   :meth:`list_thread` walk pending messages whose ``reply_deadline``
   has lapsed and transition them to ``EXPIRED`` on the read path.
   There is no background daemon — expiry is a function of read
   pressure and the caller's clock.
3. **Threading discipline.** :meth:`reply` fetches the parent, inherits
   ``thread_id``, refuses to append to a closed thread, and links the
   parent's ``reply_message_id`` forward via
   :meth:`BaseWorkspaceBackend.mark_message_replied` so the full thread
   walk is reconstructable from either end of the chain.
4. **Cross-agent provenance event emission.** Every state transition
   (send / broadcast / receive / reply / thread close) appends the
   matching ``message.*`` event into
   ``cross_agent_provenance_events``. The events are the canonical
   audit log for "who messaged whom about what" — the same stream
   Studio dashboards and the v1.3.0 mesh integrity pipeline read from.

The bus deliberately does *not* validate recipient existence at send
time. Fire-and-forget delivery means a message addressed to an agent
not yet in the directory is recoverable: when that agent registers,
their first :meth:`Workspace.messages.list_inbox` call returns the
historical row. The agent surface (``agent.messages.send`` in Chunk C)
may layer on a stricter check; the bus stays permissive.
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, timedelta
from typing import TYPE_CHECKING, Any

from wisdom_layer.errors import MessageRateLimitExceededError
from wisdom_layer.workspace.threads import (
    Embedder,
    LLMJudge,
    ThreadExitPolicy,
)
from wisdom_layer.workspace.types import (
    AgentMessage,
    MessagePurpose,
    MessageStatus,
    ThreadClosedResult,
    ThreadCloseReason,
    XAgentEventType,
)

if TYPE_CHECKING:
    from datetime import datetime

    from wisdom_layer.clock import Clock
    from wisdom_layer.workspace.backend import BaseWorkspaceBackend

logger = logging.getLogger(__name__)

# Module-level alias for the ``list`` builtin so annotations on methods
# named :meth:`list_inbox` / :meth:`list_thread` don't collide with the
# in-class shadowing pattern used elsewhere in this package. Used only
# in type annotations — never at runtime.
_List = list

# Rate-limit caps. Module-level so tests can monkey-patch and so the
# Studio dashboard can render the same numbers the bus enforces. The
# caps are workspace-local safety throttles — they are *not* tier-billing
# caps (those raise :class:`TierRestrictionError`).
MAX_MESSAGES_PER_AGENT_PER_HOUR: int = 100
MAX_BROADCASTS_PER_AGENT_PER_HOUR: int = 10
RATE_LIMIT_WINDOW_SECONDS: int = 3600


def _gen_id() -> str:
    """16-char hex id for messages and event rows."""
    return uuid.uuid4().hex[:16]


def _message_from_row(row: dict[str, Any]) -> AgentMessage:
    """Map a backend row dict to a typed :class:`AgentMessage`.

    Coerces the string ``purpose`` and ``status`` columns into their
    enum members so callers cannot accidentally compare against a raw
    string and silently miss a status transition. Backend writes of an
    unknown value raise :class:`ValueError` at construction time —
    surfacing the schema drift loudly is the right tradeoff for a
    multi-tenant audit log.
    """
    return AgentMessage(
        id=str(row["id"]),
        workspace_id=str(row["workspace_id"]),
        sender_id=str(row["sender_id"]),
        recipient_id=(
            str(row["recipient_id"]) if row["recipient_id"] is not None else None
        ),
        broadcast_capability=(
            str(row["broadcast_capability"])
            if row["broadcast_capability"] is not None
            else None
        ),
        content=str(row["content"]),
        purpose=MessagePurpose(str(row["purpose"])),
        related_memory_ids=list(row["related_memory_ids"]),
        related_task_id=(
            str(row["related_task_id"]) if row["related_task_id"] is not None else None
        ),
        thread_id=str(row["thread_id"]),
        in_reply_to=(
            str(row["in_reply_to"]) if row["in_reply_to"] is not None else None
        ),
        expects_reply=bool(row["expects_reply"]),
        reply_deadline=row["reply_deadline"],
        status=MessageStatus(str(row["status"])),
        read_at=row["read_at"],
        replied_at=row["replied_at"],
        reply_message_id=(
            str(row["reply_message_id"])
            if row["reply_message_id"] is not None
            else None
        ),
        created_at=row["created_at"],
    )


class MessageBus:
    """The Multi-C messaging surface for one workspace.

    Holds a reference to the workspace's :class:`BaseWorkspaceBackend`
    and the workspace's own ``workspace_id``. Every method threads the
    workspace_id into the backend call so the multi-tenant isolation
    contract is uniform.

    The bus exposes:

    * Sending: :meth:`send` (direct), :meth:`broadcast`, :meth:`reply`.
    * Reading: :meth:`get`, :meth:`list_inbox`, :meth:`list_thread`.
    * Lifecycle: :meth:`mark_read`, :meth:`expire_overdue`,
      :meth:`close_thread`, :meth:`get_thread_closure`.
    * Maintenance: :meth:`prune_rate_limit_log`.

    Use :meth:`Workspace.messages` to obtain the bus for a workspace —
    do not construct directly.
    """

    def __init__(
        self,
        *,
        backend: BaseWorkspaceBackend,
        workspace_id: str,
        clock: Clock,
    ) -> None:
        self._backend = backend
        self._workspace_id = workspace_id
        self._clock = clock

    # ---- Sending ---------------------------------------------------------

    async def send(
        self,
        *,
        sender_id: str,
        recipient_id: str,
        content: str,
        purpose: MessagePurpose = MessagePurpose.QUESTION,
        related_memory_ids: _List[str] | None = None,
        related_task_id: str | None = None,
        expects_reply: bool = True,
        reply_deadline: datetime | None = None,
    ) -> str:
        """Send a direct message; return the new ``message_id``.

        The message becomes the root of a new thread (``thread_id`` is
        set to the message's own id). Replies via :meth:`reply` will
        inherit this thread_id.

        Rate limit: the sender's per-hour total (default 100) is checked
        before the row is written. Exceeding raises
        :class:`MessageRateLimitExceededError`.

        Args:
            sender_id: The sending agent's ``agent_id``.
            recipient_id: The addressed agent's ``agent_id``. The bus
                does not enforce that the recipient is in the directory
                — see module docstring for the fire-and-forget
                rationale.
            content: The message body. Free-form; the SDK does not
                validate length here (the LLM context window is the
                practical cap).
            purpose: Closed-set classifier (see :class:`MessagePurpose`).
                Defaults to :attr:`MessagePurpose.QUESTION` because the
                most common send is a recipient-targeted ask; pass
                explicitly when sending information / coordination /
                handoff.
            related_memory_ids: Optional list of per-agent memory ids
                the sender is referencing. Surfaces in the recipient's
                inbox so they can pull the cited rows from the shared
                pool when relevant.
            related_task_id: Optional pointer at a task in the workspace
                shared task queue (lands in v1.3.0 — column reserved on
                the schema today).
            expects_reply: Sender hint for the recipient's prompting
                machinery. The bus does not enforce this — it does not
                auto-decline a no-reply message.
            reply_deadline: Wall-clock deadline by which the sender
                wants a reply. ``None`` (default) means no deadline.
                Past-deadline pending messages transition to EXPIRED
                lazily on the next inbox / thread read.
        """
        await self._check_rate_limit(sender_id=sender_id, is_broadcast=False)

        message_id = _gen_id()
        now = self._clock.now().astimezone(UTC)
        await self._backend.record_message(
            workspace_id=self._workspace_id,
            message_id=message_id,
            sender_id=sender_id,
            recipient_id=recipient_id,
            broadcast_capability=None,
            content=content,
            purpose=purpose.value,
            related_memory_ids=list(related_memory_ids or []),
            related_task_id=related_task_id,
            thread_id=message_id,  # Root message: thread_id = own id.
            in_reply_to=None,
            expects_reply=expects_reply,
            reply_deadline=reply_deadline,
            created_at=now,
        )
        await self._backend.record_rate_limit_event(
            workspace_id=self._workspace_id,
            sender_id=sender_id,
            is_broadcast=False,
            sent_at=now,
        )
        await self._backend.touch_agent_seen(
            workspace_id=self._workspace_id,
            agent_id=sender_id,
            last_seen_at=now,
        )
        await self._emit_xagent_event(
            event_type=XAgentEventType.MESSAGE_SENT,
            actor_agent_id=sender_id,
            target_agent_id=recipient_id,
            entity_type="message",
            entity_id=message_id,
            payload={
                "purpose": purpose.value,
                "thread_id": message_id,
                "broadcast": False,
            },
        )
        logger.info(
            "agent message sent",
            extra={
                "subsystem": "workspace.messages",
                "workspace_id": self._workspace_id,
                "message_id": message_id,
                "sender_id": sender_id,
                "recipient_id": recipient_id,
                "purpose": purpose.value,
            },
        )
        return message_id

    async def broadcast(
        self,
        *,
        sender_id: str,
        broadcast_capability: str,
        content: str,
        purpose: MessagePurpose = MessagePurpose.INFORMATION,
        related_memory_ids: _List[str] | None = None,
        related_task_id: str | None = None,
        expects_reply: bool = False,
        reply_deadline: datetime | None = None,
    ) -> str:
        """Send a broadcast; return the new ``message_id``.

        A broadcast is a single row addressed at every agent whose
        capability list contains ``broadcast_capability``. Recipients
        are matched at *read* time by :meth:`list_inbox`, never fanned
        out at write time — so an agent registering after the broadcast
        was sent immediately sees historical broadcasts that match
        their capabilities.

        Rate limits: broadcasts count against *both* the per-agent total
        (100/hr) and the broadcast sub-cap (10/hr). The broadcast cap
        is the tighter of the two; it is checked first so the error
        message names the right limit.

        ``purpose`` defaults to :attr:`MessagePurpose.INFORMATION`
        because most broadcasts are announcements — the sender
        explicitly does not expect each recipient to reply. Pass
        explicitly for coordination / question broadcasts.
        """
        await self._check_rate_limit(sender_id=sender_id, is_broadcast=True)

        message_id = _gen_id()
        now = self._clock.now().astimezone(UTC)
        await self._backend.record_message(
            workspace_id=self._workspace_id,
            message_id=message_id,
            sender_id=sender_id,
            recipient_id=None,
            broadcast_capability=broadcast_capability,
            content=content,
            purpose=purpose.value,
            related_memory_ids=list(related_memory_ids or []),
            related_task_id=related_task_id,
            thread_id=message_id,
            in_reply_to=None,
            expects_reply=expects_reply,
            reply_deadline=reply_deadline,
            created_at=now,
        )
        await self._backend.record_rate_limit_event(
            workspace_id=self._workspace_id,
            sender_id=sender_id,
            is_broadcast=True,
            sent_at=now,
        )
        await self._backend.touch_agent_seen(
            workspace_id=self._workspace_id,
            agent_id=sender_id,
            last_seen_at=now,
        )
        await self._emit_xagent_event(
            event_type=XAgentEventType.MESSAGE_SENT,
            actor_agent_id=sender_id,
            target_agent_id=None,
            entity_type="message",
            entity_id=message_id,
            payload={
                "purpose": purpose.value,
                "thread_id": message_id,
                "broadcast": True,
                "broadcast_capability": broadcast_capability,
            },
        )
        logger.info(
            "agent broadcast sent",
            extra={
                "subsystem": "workspace.messages",
                "workspace_id": self._workspace_id,
                "message_id": message_id,
                "sender_id": sender_id,
                "broadcast_capability": broadcast_capability,
                "purpose": purpose.value,
            },
        )
        return message_id

    async def reply(
        self,
        *,
        sender_id: str,
        in_reply_to: str,
        content: str,
        purpose: MessagePurpose = MessagePurpose.INFORMATION,
        related_memory_ids: _List[str] | None = None,
        related_task_id: str | None = None,
        expects_reply: bool = False,
        reply_deadline: datetime | None = None,
    ) -> str:
        """Reply to ``in_reply_to``; return the new ``message_id``.

        Inherits ``thread_id`` from the parent. The recipient is the
        parent's sender (replies always flow back to the asker for a
        direct message; replies to broadcasts are not currently
        supported and raise :class:`ValueError` — the v1.2.0 broadcast
        contract is one-shot announcement, not a fan-in conversation).

        Closed threads refuse replies: if a closure row exists for the
        thread, raises :class:`ValueError`. The closure row is written
        by :meth:`close_thread` (manual) or by
        :class:`ThreadExitPolicy` (Chunk D).

        On success: appends a row, links the parent's
        ``reply_message_id`` forward via
        :meth:`BaseWorkspaceBackend.mark_message_replied`, and emits a
        :attr:`XAgentEventType.MESSAGE_REPLIED` event.

        Raises:
            ValueError: If the parent message does not exist, the
                parent is a broadcast, or the thread is closed.
        """
        parent_row = await self._backend.get_message(
            workspace_id=self._workspace_id,
            message_id=in_reply_to,
        )
        if parent_row is None:
            raise ValueError(
                f"reply: parent message {in_reply_to!r} not found in "
                f"workspace {self._workspace_id!r}.",
            )
        parent = _message_from_row(parent_row)
        if parent.is_broadcast:
            raise ValueError(
                f"reply: cannot reply to broadcast {in_reply_to!r}. "
                f"v1.2.0 broadcasts are one-shot announcements; start a "
                f"new direct thread to the broadcaster instead.",
            )

        closure = await self._backend.get_thread_closure(
            workspace_id=self._workspace_id,
            thread_id=parent.thread_id,
        )
        if closure is not None and closure.get("closed_at") is not None:
            raise ValueError(
                f"reply: thread {parent.thread_id!r} is closed "
                f"(reason={closure.get('close_reason')!r}). "
                f"Start a new thread instead.",
            )

        await self._check_rate_limit(sender_id=sender_id, is_broadcast=False)

        message_id = _gen_id()
        now = self._clock.now().astimezone(UTC)
        # Reply recipient = parent's sender. The parent established the
        # invitation; the bus inverts the (sender, recipient) pair on
        # reply so the asker hears back from the answerer.
        recipient_id = parent.sender_id
        await self._backend.record_message(
            workspace_id=self._workspace_id,
            message_id=message_id,
            sender_id=sender_id,
            recipient_id=recipient_id,
            broadcast_capability=None,
            content=content,
            purpose=purpose.value,
            related_memory_ids=list(related_memory_ids or []),
            related_task_id=related_task_id,
            thread_id=parent.thread_id,
            in_reply_to=in_reply_to,
            expects_reply=expects_reply,
            reply_deadline=reply_deadline,
            created_at=now,
        )
        await self._backend.record_rate_limit_event(
            workspace_id=self._workspace_id,
            sender_id=sender_id,
            is_broadcast=False,
            sent_at=now,
        )
        await self._backend.touch_agent_seen(
            workspace_id=self._workspace_id,
            agent_id=sender_id,
            last_seen_at=now,
        )
        # Link the parent's reply_message_id forward. First-reply-wins
        # at the backend layer; a racing second reply preserves the
        # original linkage.
        await self._backend.mark_message_replied(
            workspace_id=self._workspace_id,
            message_id=in_reply_to,
            reply_message_id=message_id,
            replied_at=now,
        )
        # Emit MESSAGE_SENT for the new reply row first (the canonical
        # "this message exists" audit row, keyed on the new id), then
        # MESSAGE_REPLIED on the parent (the canonical "the parent's
        # state transitioned to replied" audit row, keyed on the parent
        # id). Both fire on every reply so the entity-id walk for either
        # message returns the full picture.
        await self._emit_xagent_event(
            event_type=XAgentEventType.MESSAGE_SENT,
            actor_agent_id=sender_id,
            target_agent_id=recipient_id,
            entity_type="message",
            entity_id=message_id,
            payload={
                "purpose": purpose.value,
                "thread_id": parent.thread_id,
                "broadcast": False,
                "in_reply_to": in_reply_to,
            },
        )
        await self._emit_xagent_event(
            event_type=XAgentEventType.MESSAGE_REPLIED,
            actor_agent_id=sender_id,
            target_agent_id=recipient_id,
            entity_type="message",
            entity_id=in_reply_to,
            payload={
                "thread_id": parent.thread_id,
                "reply_message_id": message_id,
                "purpose": purpose.value,
            },
        )
        logger.info(
            "agent reply sent",
            extra={
                "subsystem": "workspace.messages",
                "workspace_id": self._workspace_id,
                "thread_id": parent.thread_id,
                "in_reply_to": in_reply_to,
                "reply_message_id": message_id,
                "sender_id": sender_id,
            },
        )
        return message_id

    # ---- Reading ---------------------------------------------------------

    async def get(self, message_id: str) -> AgentMessage | None:
        """Return one message, or ``None`` if it does not exist.

        Lazy-expires the row if its ``reply_deadline`` has lapsed and
        it is still ``PENDING`` — the returned :class:`AgentMessage`
        reflects the post-expiry status.
        """
        row = await self._backend.get_message(
            workspace_id=self._workspace_id,
            message_id=message_id,
        )
        if row is None:
            return None
        msg = _message_from_row(row)
        return await self._lazy_expire(msg)

    async def list_inbox(
        self,
        *,
        recipient_id: str,
        recipient_capabilities: _List[str],
        unread_only: bool = True,
        include_broadcasts: bool = True,
        limit: int = 100,
    ) -> _List[AgentMessage]:
        """Return messages addressed to ``recipient_id``, newest-first.

        Combines direct messages and matching broadcasts in one call.
        Lazy-expires past-deadline pending rows on the read; if
        ``unread_only=True``, the just-expired rows are dropped from
        the returned list (they are no longer ``PENDING`` and therefore
        no longer "unread" by the inbox contract).

        Args mirror
        :meth:`BaseWorkspaceBackend.list_inbox`. Returns
        :class:`AgentMessage` instead of row dicts.
        """
        rows = await self._backend.list_inbox(
            workspace_id=self._workspace_id,
            recipient_id=recipient_id,
            recipient_capabilities=list(recipient_capabilities),
            unread_only=unread_only,
            include_broadcasts=include_broadcasts,
            limit=limit,
        )
        out: _List[AgentMessage] = []
        for row in rows:
            msg = _message_from_row(row)
            updated = await self._lazy_expire(msg)
            if unread_only and updated.status == MessageStatus.EXPIRED:
                # The row was PENDING when the backend matched the
                # unread filter, but we just expired it. Drop it from
                # the result so the caller's "unread" view stays
                # consistent with the post-expiry state.
                continue
            out.append(updated)
        return out

    async def list_thread(
        self,
        thread_id: str,
        *,
        limit: int = 200,
    ) -> _List[AgentMessage]:
        """Return all messages in a thread, oldest-first.

        Lazy-expires past-deadline pending rows on the read. The
        expired rows remain in the result — thread reads are the audit
        view, not the unread view, so historical state belongs.
        """
        rows = await self._backend.list_thread(
            workspace_id=self._workspace_id,
            thread_id=thread_id,
            limit=limit,
        )
        out: _List[AgentMessage] = []
        for row in rows:
            msg = _message_from_row(row)
            out.append(await self._lazy_expire(msg))
        return out

    # ---- Lifecycle -------------------------------------------------------

    async def mark_read(
        self,
        *,
        message_id: str,
        reader_agent_id: str,
    ) -> bool:
        """Mark a direct message as read or record a broadcast ack.

        Returns ``True`` on a state transition (or first broadcast
        ack), ``False`` on a no-op (already read / replied / expired,
        not addressed to this reader, or duplicate broadcast ack).

        On a true transition, emits
        :attr:`XAgentEventType.MESSAGE_RECEIVED` (actor=reader,
        entity=message_id) and refreshes the reader's
        ``last_seen_at``. Duplicates do not emit — the event log is
        the audit, not the attempt log.
        """
        now = self._clock.now().astimezone(UTC)
        transitioned = await self._backend.mark_message_read(
            workspace_id=self._workspace_id,
            message_id=message_id,
            reader_agent_id=reader_agent_id,
            read_at=now,
        )
        if transitioned:
            await self._backend.touch_agent_seen(
                workspace_id=self._workspace_id,
                agent_id=reader_agent_id,
                last_seen_at=now,
            )
            await self._emit_xagent_event(
                event_type=XAgentEventType.MESSAGE_RECEIVED,
                actor_agent_id=reader_agent_id,
                target_agent_id=None,
                entity_type="message",
                entity_id=message_id,
                payload={"reader_agent_id": reader_agent_id},
            )
        return transitioned

    async def expire_overdue(self, message_id: str) -> bool:
        """Force a pending message to ``EXPIRED``.

        Idempotent — a no-op on messages already past pending. Returns
        ``True`` on transition, ``False`` on no-op. Most callers will
        rely on the lazy expiry hook in :meth:`get` /
        :meth:`list_inbox` / :meth:`list_thread` instead of calling
        this directly; surfaced for tests and for explicit operator
        cleanup paths.
        """
        now = self._clock.now().astimezone(UTC)
        return await self._backend.mark_message_expired(
            workspace_id=self._workspace_id,
            message_id=message_id,
            expired_at=now,
        )

    async def close_thread(
        self,
        *,
        thread_id: str,
        reason: ThreadCloseReason = ThreadCloseReason.MANUAL,
        metadata: dict[str, Any] | None = None,
    ) -> ThreadClosedResult:
        """Close a thread; return the :class:`ThreadClosedResult`.

        Idempotent on ``(workspace_id, thread_id)`` at the backend
        layer (first-closure-wins on the timestamp + reason; subsequent
        calls overwrite ``close_metadata`` only). Subsequent
        :meth:`reply` calls against the closed thread raise
        :class:`ValueError`.

        Default reason is :attr:`ThreadCloseReason.MANUAL` because the
        :class:`ThreadExitPolicy` (Chunk D) calls
        :meth:`BaseWorkspaceBackend.upsert_thread_closure` directly
        with the gate-specific reason; this surface is the operator /
        application escape hatch.

        Emits :attr:`XAgentEventType.MESSAGE_THREAD_CLOSED` (actor
        unset for manual closure; the operator identity is not part
        of the workspace audit boundary at v1.2.0).
        """
        now = self._clock.now().astimezone(UTC)
        meta = dict(metadata or {})
        await self._backend.upsert_thread_closure(
            workspace_id=self._workspace_id,
            thread_id=thread_id,
            closed_at=now,
            close_reason=reason.value,
            close_metadata=meta,
        )
        # Turn count is a useful default datum on every closure; we
        # always populate it regardless of which gate tripped so
        # analytics across reasons remain comparable.
        thread_rows = await self._backend.list_thread(
            workspace_id=self._workspace_id,
            thread_id=thread_id,
            limit=10_000,
        )
        turn_count = len(thread_rows)
        await self._emit_xagent_event(
            event_type=XAgentEventType.MESSAGE_THREAD_CLOSED,
            actor_agent_id=None,
            target_agent_id=None,
            entity_type="thread",
            entity_id=thread_id,
            payload={
                "close_reason": reason.value,
                "close_metadata": meta,
                "turn_count": turn_count,
            },
        )
        logger.info(
            "agent thread closed",
            extra={
                "subsystem": "workspace.messages",
                "workspace_id": self._workspace_id,
                "thread_id": thread_id,
                "close_reason": reason.value,
                "turn_count": turn_count,
            },
        )
        return ThreadClosedResult(
            thread_id=thread_id,
            reason=reason,
            closed_at=now,
            turn_count=turn_count,
            similarity=(
                meta.get("similarity")
                if isinstance(meta.get("similarity"), float)
                else None
            ),
            judge_verdict=(
                str(meta.get("judge_verdict"))
                if meta.get("judge_verdict") is not None
                else None
            ),
        )

    async def get_thread_closure(self, thread_id: str) -> dict[str, Any] | None:
        """Return the closure row for ``thread_id``, or ``None`` if open."""
        return await self._backend.get_thread_closure(
            workspace_id=self._workspace_id,
            thread_id=thread_id,
        )

    async def evaluate_thread_exit(
        self,
        *,
        thread_id: str,
        policy: ThreadExitPolicy | None = None,
        embedder: Embedder | None = None,
        llm_judge: LLMJudge | None = None,
        auto_close: bool = True,
    ) -> ThreadClosedResult | None:
        """Evaluate :class:`ThreadExitPolicy` against ``thread_id``.

        Loads the thread, runs the policy's gates in priority order
        (max_turns → stagnation → convergence), and — when a gate
        trips — calls :meth:`close_thread` with the gate-specific
        reason and the evidence (similarity / judge_verdict) threaded
        through ``close_metadata`` so the persisted closure row carries
        the full provenance of *why* the thread was closed.

        Returns ``None`` when no gate trips (the thread should keep
        going) or when the thread is already closed (idempotent — a
        re-evaluation against a closed thread is a no-op rather than
        an error). Application code typically invokes this once per
        turn after a reply lands.

        ``auto_close=False`` runs the policy without persisting — the
        returned :class:`ThreadClosedResult` describes the gate that
        *would* trip, but the thread row stays open. Useful for
        dry-run evaluation in dashboards or for application code that
        wants to layer additional logic on top of the verdict before
        closing. The ``closed_at`` timestamp on the dry-run result
        comes from the policy's ``now`` (the bus's clock) and is
        advisory only; the canonical timestamp is stamped by
        :meth:`close_thread` on the real close.

        Args:
            thread_id: Thread to evaluate.
            policy: :class:`ThreadExitPolicy` to apply. Defaults to
                :class:`ThreadExitPolicy()` (all gates enabled at
                their reference values).
            embedder: Application-supplied embedder for the stagnation
                gate. The gate is silently skipped when ``None``.
            llm_judge: Application-supplied judge for the convergence
                gate. The gate is silently skipped when ``None``.
            auto_close: When ``True`` (default), persist the closure
                via :meth:`close_thread` on a tripping gate. When
                ``False``, return the verdict without writing.
        """
        existing_closure = await self.get_thread_closure(thread_id)
        if existing_closure is not None:
            return None

        active_policy = policy if policy is not None else ThreadExitPolicy()
        messages = await self.list_thread(thread_id, limit=10_000)
        now = self._clock.now().astimezone(UTC)
        verdict = await active_policy.evaluate(
            messages,
            thread_id=thread_id,
            now=now,
            embedder=embedder,
            llm_judge=llm_judge,
        )
        if verdict is None:
            return None
        if not auto_close:
            return verdict

        metadata: dict[str, Any] = {}
        if verdict.similarity is not None:
            metadata["similarity"] = verdict.similarity
        if verdict.judge_verdict is not None:
            metadata["judge_verdict"] = verdict.judge_verdict
        return await self.close_thread(
            thread_id=thread_id,
            reason=verdict.reason,
            metadata=metadata,
        )

    # ---- Maintenance -----------------------------------------------------

    async def prune_rate_limit_log(self, *, older_than_seconds: int | None = None) -> int:
        """Delete rate-limit log rows older than the configured window.

        ``older_than_seconds`` defaults to
        :data:`RATE_LIMIT_WINDOW_SECONDS` (1 hour) — the same window
        the rate-limit check applies — so pruning never drops a row
        that could still affect a current-window count. Pass an
        explicit longer value to retain history for analytics.

        Returns the number of rows pruned.
        """
        cutoff_seconds = (
            older_than_seconds if older_than_seconds is not None else RATE_LIMIT_WINDOW_SECONDS
        )
        cutoff = self._clock.now().astimezone(UTC) - timedelta(seconds=cutoff_seconds)
        return await self._backend.prune_rate_limit_log(
            workspace_id=self._workspace_id,
            older_than=cutoff,
        )

    # ---- Internal --------------------------------------------------------

    async def _check_rate_limit(self, *, sender_id: str, is_broadcast: bool) -> None:
        """Enforce the rolling-hour caps before recording a message.

        Broadcasts are checked against the broadcast sub-cap *first*
        because that limit is tighter. The per-agent total cap applies
        to both direct and broadcast sends. Either check failing
        raises :class:`MessageRateLimitExceededError` with a
        ``limit_kind`` that names the binding cap.
        """
        window_start = self._clock.now().astimezone(UTC) - timedelta(
            seconds=RATE_LIMIT_WINDOW_SECONDS
        )
        if is_broadcast:
            broadcast_count = await self._backend.count_messages_sent_within(
                workspace_id=self._workspace_id,
                sender_id=sender_id,
                since=window_start,
                is_broadcast=True,
            )
            if broadcast_count >= MAX_BROADCASTS_PER_AGENT_PER_HOUR:
                raise MessageRateLimitExceededError(
                    sender_id=sender_id,
                    limit_kind="broadcasts_per_hour",
                    current=broadcast_count,
                    limit=MAX_BROADCASTS_PER_AGENT_PER_HOUR,
                    window_seconds=RATE_LIMIT_WINDOW_SECONDS,
                )
        total_count = await self._backend.count_messages_sent_within(
            workspace_id=self._workspace_id,
            sender_id=sender_id,
            since=window_start,
            is_broadcast=None,
        )
        if total_count >= MAX_MESSAGES_PER_AGENT_PER_HOUR:
            raise MessageRateLimitExceededError(
                sender_id=sender_id,
                limit_kind="messages_per_hour",
                current=total_count,
                limit=MAX_MESSAGES_PER_AGENT_PER_HOUR,
                window_seconds=RATE_LIMIT_WINDOW_SECONDS,
            )

    async def _lazy_expire(self, msg: AgentMessage) -> AgentMessage:
        """Transition a past-deadline pending message to ``EXPIRED``.

        Returns the (possibly mutated) message. Only PENDING messages
        with a non-null ``reply_deadline`` in the past are eligible;
        everything else returns unchanged. Backend transition happens
        before the in-memory rewrite so a concurrent reader observes
        the same status.
        """
        if (
            msg.status != MessageStatus.PENDING
            or msg.reply_deadline is None
        ):
            return msg
        now = self._clock.now().astimezone(UTC)
        if msg.reply_deadline >= now:
            return msg
        transitioned = await self._backend.mark_message_expired(
            workspace_id=self._workspace_id,
            message_id=msg.id,
            expired_at=now,
        )
        if not transitioned:
            # Lost the race to another reader (or the backend already
            # held the row past PENDING). Re-fetch to capture the
            # canonical status; the bus owns the lazy-expiry contract
            # and must not return a stale view.
            current = await self._backend.get_message(
                workspace_id=self._workspace_id,
                message_id=msg.id,
            )
            return _message_from_row(current) if current is not None else msg
        return AgentMessage(
            id=msg.id,
            workspace_id=msg.workspace_id,
            sender_id=msg.sender_id,
            recipient_id=msg.recipient_id,
            broadcast_capability=msg.broadcast_capability,
            content=msg.content,
            purpose=msg.purpose,
            related_memory_ids=msg.related_memory_ids,
            related_task_id=msg.related_task_id,
            thread_id=msg.thread_id,
            in_reply_to=msg.in_reply_to,
            expects_reply=msg.expects_reply,
            reply_deadline=msg.reply_deadline,
            status=MessageStatus.EXPIRED,
            read_at=msg.read_at,
            replied_at=msg.replied_at,
            reply_message_id=msg.reply_message_id,
            created_at=msg.created_at,
        )

    async def _emit_xagent_event(
        self,
        *,
        event_type: str,
        actor_agent_id: str | None,
        target_agent_id: str | None,
        entity_type: str,
        entity_id: str,
        payload: dict[str, object],
    ) -> None:
        """Append one row to ``cross_agent_provenance_events``.

        Centralised so callers do not have to reach into ``_clock`` /
        ``_backend`` for the canonical fields. ``parent_event_id`` is
        always ``None`` in v1.2.0 — chain reconstruction is the
        caller's responsibility today; v1.3.0 introduces the hash-chain
        that uses this field.
        """
        await self._backend.record_xagent_event(
            workspace_id=self._workspace_id,
            event_id=_gen_id(),
            event_type=event_type,
            actor_agent_id=actor_agent_id,
            target_agent_id=target_agent_id,
            entity_type=entity_type,
            entity_id=entity_id,
            parent_event_id=None,
            payload=payload,
            created_at=self._clock.now().astimezone(UTC),
        )
