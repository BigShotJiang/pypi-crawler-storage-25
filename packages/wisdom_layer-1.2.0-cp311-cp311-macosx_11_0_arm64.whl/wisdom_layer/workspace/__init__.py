"""Multi-agent workspace surface — v1.2.0.

The workspace is the shared backend that holds all cross-agent state for
a single multi-agent deployment: the agent directory, the shared memory
pool, team insights, and cross-agent provenance events.

Architectural boundary:

* Per-agent state continues to live in each :class:`WisdomAgent`'s own
  :class:`BaseBackend` (memories, facts, directives, journals,
  provenance_events).
* Cross-agent state lives in :class:`BaseWorkspaceBackend` (workspaces,
  agent_directory, shared_memory_pool, endorsements, contentions,
  team_insights, cross_agent_provenance_events).

A contributing agent's private memory is **back-referenced** from
``shared_memory_pool.source_memory_id`` but never copied. The provenance
walk crosses the boundary by looking up that back-reference in the
agent's own DB. Compromising ``workspace.db`` never exposes private
memory content.

Tier-gated: workspace construction validates an Enterprise license
against the ``multi_agent_workspace`` feature gate. Free / Pro keys
raise :class:`TierRestrictionError` at :meth:`Workspace.initialize`.
"""

from __future__ import annotations

from wisdom_layer.workspace.backend import BaseWorkspaceBackend
from wisdom_layer.workspace.core import Workspace
from wisdom_layer.workspace.directory import AgentDirectory, AgentRecord
from wisdom_layer.workspace.messages import MessageBus
from wisdom_layer.workspace.pool import SharedMemoryPool
from wisdom_layer.workspace.postgres import PostgresWorkspaceBackend
from wisdom_layer.workspace.sqlite import WorkspaceSQLiteBackend
from wisdom_layer.workspace.threads import (
    Embedder,
    LLMJudge,
    ThreadExitPolicy,
)
from wisdom_layer.workspace.tools import (
    BROADCAST_TOOL,
    CHECK_INBOX_TOOL,
    LIST_AGENTS_TOOL,
    REPLY_TO_MESSAGE_TOOL,
    SEND_MESSAGE_TO_AGENT_TOOL,
    WORKSPACE_TOOLS,
    execute_tool,
)
from wisdom_layer.workspace.types import (
    AgentMessage,
    CrossAgentProvenanceEvent,
    DerivedProvenanceEventType,
    MessagePurpose,
    MessageStatus,
    ProvenanceContribution,
    SharedMemory,
    SharedMemoryContention,
    SharedMemoryEndorsement,
    TeamInsight,
    TeamInsightContribution,
    TeamInsightProvenance,
    ThreadClosedResult,
    ThreadCloseReason,
    Visibility,
    XAgentEventType,
    compute_team_score,
)

__all__ = [
    "BROADCAST_TOOL",
    "CHECK_INBOX_TOOL",
    "LIST_AGENTS_TOOL",
    "REPLY_TO_MESSAGE_TOOL",
    "SEND_MESSAGE_TO_AGENT_TOOL",
    "WORKSPACE_TOOLS",
    "AgentDirectory",
    "AgentMessage",
    "AgentRecord",
    "BaseWorkspaceBackend",
    "CrossAgentProvenanceEvent",
    "DerivedProvenanceEventType",
    "Embedder",
    "LLMJudge",
    "MessageBus",
    "MessagePurpose",
    "MessageStatus",
    "PostgresWorkspaceBackend",
    "ProvenanceContribution",
    "SharedMemory",
    "SharedMemoryContention",
    "SharedMemoryEndorsement",
    "SharedMemoryPool",
    "TeamInsight",
    "TeamInsightContribution",
    "TeamInsightProvenance",
    "ThreadCloseReason",
    "ThreadClosedResult",
    "ThreadExitPolicy",
    "Visibility",
    "Workspace",
    "WorkspaceSQLiteBackend",
    "XAgentEventType",
    "compute_team_score",
    "execute_tool",
]
