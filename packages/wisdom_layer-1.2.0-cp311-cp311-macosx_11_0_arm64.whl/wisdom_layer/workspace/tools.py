"""LLM tool schemas for the agent messaging surface — Multi-C, v1.2.0.

Five Anthropic-format tool definitions plus a dispatcher that maps
``(name, arguments)`` from a tool-use response onto the matching
:class:`MessagesInterface` method on a :class:`WisdomAgent`. Schemas
are deliberately Anthropic-shaped because that format ports cleanly to
OpenAI ``functions`` (rename ``input_schema`` → ``parameters``) and to
the LiteLLM tool-use shim — keeping one canonical definition avoids
schema drift between providers.

Why a dispatcher and not raw method binding:

* The LLM's tool call carries a string ``name`` and a JSON ``arguments``
  dict — the SDK converts string ``purpose`` values into the
  :class:`MessagePurpose` enum, parses ``reply_deadline_hours`` into a
  ``datetime``, and re-shapes the result back into a JSON-serialisable
  dict. The agent surface keeps its typed signatures; the dispatcher
  carries the LLM-specific marshalling.
* The dispatcher refuses unknown tool names with a structured
  ``{"error": ...}`` payload rather than raising — letting the LLM see
  the error and self-correct keeps the agent loop running. Fatal errors
  (missing workspace, rate limit, closed thread) still raise so callers
  can decide whether to surface them to the LLM as tool errors.

The five tools mirror the V1_2_0.md Multi-C spec one-for-one:

* ``send_message_to_agent``
* ``list_agents``
* ``check_inbox``
* ``reply_to_message``
* ``broadcast``
"""

from __future__ import annotations

from datetime import UTC, timedelta
from typing import TYPE_CHECKING, Any

from wisdom_layer.workspace.types import MessagePurpose

if TYPE_CHECKING:
    from wisdom_layer.agent import WisdomAgent
    from wisdom_layer.workspace.types import AgentMessage

# ---- Tool-name constants ---------------------------------------------------
#
# Re-exported so callers building their own tool routers can reference the
# names by symbol rather than by string literal — typo-resistant and
# refactor-safe.
TOOL_SEND_MESSAGE_TO_AGENT: str = "send_message_to_agent"
TOOL_LIST_AGENTS: str = "list_agents"
TOOL_CHECK_INBOX: str = "check_inbox"
TOOL_REPLY_TO_MESSAGE: str = "reply_to_message"
TOOL_BROADCAST: str = "broadcast"


# ---- Schema fragments shared across tools ----------------------------------
#
# Centralising the purpose enum here means a future addition to
# :class:`MessagePurpose` only requires a one-line update at this module
# level — every tool schema picks up the new value automatically.
_PURPOSE_VALUES: list[str] = [p.value for p in MessagePurpose]


SEND_MESSAGE_TO_AGENT_TOOL: dict[str, Any] = {
    "name": TOOL_SEND_MESSAGE_TO_AGENT,
    "description": (
        "Send a direct message to one specific agent in this workspace. "
        "Use list_agents first to discover valid recipient_id values. The "
        "message is rate-limited to 100 per agent per hour. Threads start "
        "from this message — replies via reply_to_message inherit the "
        "thread."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "recipient_id": {
                "type": "string",
                "description": "agent_id of the addressee. Must be in the workspace directory.",
            },
            "content": {
                "type": "string",
                "description": (
                    "Free-form message body. The LLM context window is the "
                    "practical cap."
                ),
            },
            "purpose": {
                "type": "string",
                "enum": _PURPOSE_VALUES,
                "description": (
                    "Closed-set classifier. Defaults to 'question' (the most "
                    "common direct send); use 'information' for an FYI, "
                    "'coordination' for a workflow handoff, 'handoff' for "
                    "transferring ownership of a task."
                ),
                "default": MessagePurpose.QUESTION.value,
            },
            "related_memory_ids": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Optional list of this agent's memory ids the recipient "
                    "should consult. Surfaces in the recipient's inbox view."
                ),
            },
            "related_task_id": {
                "type": ["string", "null"],
                "description": "Optional pointer at a shared task (v1.3.0 surface).",
            },
            "expects_reply": {
                "type": "boolean",
                "description": "Hint for the recipient's prompting machinery. Default true.",
                "default": True,
            },
            "reply_deadline_hours": {
                "type": ["number", "null"],
                "description": (
                    "Wall-clock deadline relative to now, in hours. Past-deadline "
                    "pending messages transition to EXPIRED on the recipient's "
                    "next inbox read. Omit for no deadline."
                ),
            },
        },
        "required": ["recipient_id", "content"],
    },
}


LIST_AGENTS_TOOL: dict[str, Any] = {
    "name": TOOL_LIST_AGENTS,
    "description": (
        "Return the workspace's agent directory: every active agent's "
        "agent_id, capabilities, registration timestamp, and last_seen_at. "
        "Call this before send_message_to_agent or broadcast to discover "
        "valid recipient ids and capability tags."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "capability": {
                "type": ["string", "null"],
                "description": (
                    "Optional capability filter. When set, returns only "
                    "agents whose capability list contains this exact tag."
                ),
            },
            "include_archived": {
                "type": "boolean",
                "description": (
                    "When true, includes agents that have been unregistered. "
                    "Default false (active roster only)."
                ),
                "default": False,
            },
        },
        "required": [],
    },
}


CHECK_INBOX_TOOL: dict[str, Any] = {
    "name": TOOL_CHECK_INBOX,
    "description": (
        "Return messages addressed to this agent (direct + matching "
        "broadcasts), newest-first. By default returns only unread "
        "messages. Past-deadline pending messages are auto-expired on "
        "this read. Use reply_to_message to respond, or mark_read to "
        "acknowledge without replying."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "unread_only": {
                "type": "boolean",
                "description": "When true (default), filters to PENDING messages.",
                "default": True,
            },
            "include_broadcasts": {
                "type": "boolean",
                "description": (
                    "When true (default), includes broadcasts whose "
                    "broadcast_capability matches one of this agent's "
                    "registered capabilities."
                ),
                "default": True,
            },
            "limit": {
                "type": "integer",
                "description": "Maximum messages to return. Default 100.",
                "default": 100,
                "minimum": 1,
                "maximum": 500,
            },
        },
        "required": [],
    },
}


REPLY_TO_MESSAGE_TOOL: dict[str, Any] = {
    "name": TOOL_REPLY_TO_MESSAGE,
    "description": (
        "Reply to a specific message in an existing thread. The reply "
        "inherits the parent's thread_id and is automatically addressed "
        "back to the parent's sender. Cannot reply to a broadcast or to "
        "a closed thread — both raise an error."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "in_reply_to": {
                "type": "string",
                "description": "message_id of the parent message (from check_inbox).",
            },
            "content": {
                "type": "string",
                "description": "Free-form reply body.",
            },
            "purpose": {
                "type": "string",
                "enum": _PURPOSE_VALUES,
                "description": (
                    "Closed-set classifier. Defaults to 'information' (the "
                    "most common reply shape — an answer to a question)."
                ),
                "default": MessagePurpose.INFORMATION.value,
            },
            "related_memory_ids": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional memory ids the reply references.",
            },
            "expects_reply": {
                "type": "boolean",
                "description": (
                    "Hint for the recipient. Default false (replies usually "
                    "close the loop)."
                ),
                "default": False,
            },
            "reply_deadline_hours": {
                "type": ["number", "null"],
                "description": "Optional reply deadline in hours.",
            },
        },
        "required": ["in_reply_to", "content"],
    },
}


BROADCAST_TOOL: dict[str, Any] = {
    "name": TOOL_BROADCAST,
    "description": (
        "Send a single message to every agent whose capability list "
        "contains broadcast_capability. Recipients are matched at READ "
        "time, so an agent registering after the broadcast still sees "
        "it. Rate-limited to 10 broadcasts per agent per hour AND "
        "counts against the 100/hr per-agent total. Broadcasts are "
        "one-shot announcements — recipients cannot reply to them; "
        "they must start a new direct thread."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "broadcast_capability": {
                "type": "string",
                "description": (
                    "Capability tag to filter recipients by. Use list_agents "
                    "to discover valid tags. Agents with this tag in their "
                    "capabilities list will see this broadcast in their inbox."
                ),
            },
            "content": {
                "type": "string",
                "description": "Free-form announcement body.",
            },
            "purpose": {
                "type": "string",
                "enum": _PURPOSE_VALUES,
                "description": (
                    "Closed-set classifier. Defaults to 'information' (most "
                    "broadcasts are FYI announcements)."
                ),
                "default": MessagePurpose.INFORMATION.value,
            },
            "related_memory_ids": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional memory ids the broadcast cites.",
            },
            "expects_reply": {
                "type": "boolean",
                "description": "Sender hint. Default false.",
                "default": False,
            },
            "reply_deadline_hours": {
                "type": ["number", "null"],
                "description": "Optional reply deadline in hours.",
            },
        },
        "required": ["broadcast_capability", "content"],
    },
}


WORKSPACE_TOOLS: list[dict[str, Any]] = [
    SEND_MESSAGE_TO_AGENT_TOOL,
    LIST_AGENTS_TOOL,
    CHECK_INBOX_TOOL,
    REPLY_TO_MESSAGE_TOOL,
    BROADCAST_TOOL,
]
"""The full Multi-C tool set in canonical order. Stamp into the LLM's
tool list when the agent is workspace-registered. The order matches
the typical call sequence (discover peers → message → reply / broadcast)
which some LLMs use as a soft prior."""


# ---- Dispatcher -----------------------------------------------------------


def _coerce_purpose(value: Any, *, default: MessagePurpose) -> MessagePurpose:
    """Coerce a tool-call ``purpose`` argument to :class:`MessagePurpose`.

    Accepts an enum member (when callers pass through pre-typed args)
    or a string. Unknown strings raise :class:`ValueError` — the LLM
    sees the error and self-corrects on the next turn rather than
    silently routing a 'question' as 'information'.
    """
    if value is None:
        return default
    if isinstance(value, MessagePurpose):
        return value
    if isinstance(value, str):
        return MessagePurpose(value)
    raise TypeError(
        f"purpose must be a MessagePurpose or string, got {type(value).__name__}",
    )


def _coerce_deadline(
    value: Any,
    *,
    clock_now: Any,
) -> Any:
    """Coerce ``reply_deadline_hours`` into an absolute UTC datetime.

    LLM tool calls express deadlines as hours-from-now because absolute
    timestamps are awkward to reason about in prompts. The dispatcher
    anchors the offset at the agent's clock so test clocks (and any
    future virtual-time backends) compose cleanly.
    """
    if value is None:
        return None
    hours = float(value)
    return clock_now.astimezone(UTC) + timedelta(hours=hours)


def _agent_message_to_dict(msg: AgentMessage) -> dict[str, Any]:
    """JSON-serialisable view of an :class:`AgentMessage` for the LLM.

    Drops nothing the LLM might need but flattens enums to their string
    values and ISO-formats timestamps so the result round-trips through
    ``json.dumps`` without a custom encoder.
    """
    return {
        "id": msg.id,
        "workspace_id": msg.workspace_id,
        "sender_id": msg.sender_id,
        "recipient_id": msg.recipient_id,
        "broadcast_capability": msg.broadcast_capability,
        "content": msg.content,
        "purpose": msg.purpose.value,
        "related_memory_ids": list(msg.related_memory_ids),
        "related_task_id": msg.related_task_id,
        "thread_id": msg.thread_id,
        "in_reply_to": msg.in_reply_to,
        "expects_reply": msg.expects_reply,
        "reply_deadline": (
            msg.reply_deadline.isoformat() if msg.reply_deadline is not None else None
        ),
        "status": msg.status.value,
        "read_at": msg.read_at.isoformat() if msg.read_at is not None else None,
        "replied_at": (
            msg.replied_at.isoformat() if msg.replied_at is not None else None
        ),
        "reply_message_id": msg.reply_message_id,
        "created_at": msg.created_at.isoformat(),
        "is_broadcast": msg.is_broadcast,
    }


async def execute_tool(
    *,
    agent: WisdomAgent,
    name: str,
    arguments: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch one tool call onto the agent's :class:`MessagesInterface`.

    Returns a JSON-serialisable dict the caller can hand back to the LLM
    as the tool result. Unknown tool names return
    ``{"error": "unknown_tool", ...}`` rather than raising — the LLM can
    self-correct. Tool execution errors (workspace not registered, rate
    limit exceeded, closed thread) propagate so the caller can decide
    whether to surface them to the LLM as a tool error or a hard fail.

    Args:
        agent: The :class:`WisdomAgent` whose ``messages`` surface
            handles the call. The agent must already be registered to a
            workspace; the underlying methods raise if not.
        name: The tool name from the LLM's tool-use block.
        arguments: The JSON arguments dict the LLM produced. Keys are
            tool-specific.

    Returns:
        For ``list_agents``: ``{"agents": [...]}``
        For ``check_inbox``: ``{"messages": [...]}``
        For ``send_message_to_agent`` / ``reply_to_message`` /
        ``broadcast``: ``{"message_id": "..."}``.
        For an unknown name: ``{"error": "unknown_tool", "name": name}``.
    """
    if name == TOOL_SEND_MESSAGE_TO_AGENT:
        message_id = await agent.messages.send(
            recipient_id=arguments["recipient_id"],
            content=arguments["content"],
            purpose=_coerce_purpose(
                arguments.get("purpose"),
                default=MessagePurpose.QUESTION,
            ),
            related_memory_ids=arguments.get("related_memory_ids"),
            related_task_id=arguments.get("related_task_id"),
            expects_reply=bool(arguments.get("expects_reply", True)),
            reply_deadline=_coerce_deadline(
                arguments.get("reply_deadline_hours"),
                clock_now=agent._clock.now(),
            ),
        )
        return {"message_id": message_id}

    if name == TOOL_LIST_AGENTS:
        records = await agent.messages.list_agents(
            capability=arguments.get("capability"),
            include_archived=bool(arguments.get("include_archived", False)),
        )
        return {
            "agents": [
                {
                    "agent_id": r.agent_id,
                    "capabilities": list(r.capabilities),
                    "registered_at": r.registered_at.isoformat(),
                    "last_seen_at": (
                        r.last_seen_at.isoformat() if r.last_seen_at is not None else None
                    ),
                    "past_success_rate": r.past_success_rate,
                    "archived_at": (
                        r.archived_at.isoformat() if r.archived_at is not None else None
                    ),
                }
                for r in records
            ],
        }

    if name == TOOL_CHECK_INBOX:
        messages = await agent.messages.check_inbox(
            unread_only=bool(arguments.get("unread_only", True)),
            include_broadcasts=bool(arguments.get("include_broadcasts", True)),
            limit=int(arguments.get("limit", 100)),
        )
        return {"messages": [_agent_message_to_dict(m) for m in messages]}

    if name == TOOL_REPLY_TO_MESSAGE:
        message_id = await agent.messages.reply(
            in_reply_to=arguments["in_reply_to"],
            content=arguments["content"],
            purpose=_coerce_purpose(
                arguments.get("purpose"),
                default=MessagePurpose.INFORMATION,
            ),
            related_memory_ids=arguments.get("related_memory_ids"),
            expects_reply=bool(arguments.get("expects_reply", False)),
            reply_deadline=_coerce_deadline(
                arguments.get("reply_deadline_hours"),
                clock_now=agent._clock.now(),
            ),
        )
        return {"message_id": message_id}

    if name == TOOL_BROADCAST:
        message_id = await agent.messages.broadcast(
            broadcast_capability=arguments["broadcast_capability"],
            content=arguments["content"],
            purpose=_coerce_purpose(
                arguments.get("purpose"),
                default=MessagePurpose.INFORMATION,
            ),
            related_memory_ids=arguments.get("related_memory_ids"),
            expects_reply=bool(arguments.get("expects_reply", False)),
            reply_deadline=_coerce_deadline(
                arguments.get("reply_deadline_hours"),
                clock_now=agent._clock.now(),
            ),
        )
        return {"message_id": message_id}

    return {"error": "unknown_tool", "name": name}


__all__ = [
    "BROADCAST_TOOL",
    "CHECK_INBOX_TOOL",
    "LIST_AGENTS_TOOL",
    "REPLY_TO_MESSAGE_TOOL",
    "SEND_MESSAGE_TO_AGENT_TOOL",
    "TOOL_BROADCAST",
    "TOOL_CHECK_INBOX",
    "TOOL_LIST_AGENTS",
    "TOOL_REPLY_TO_MESSAGE",
    "TOOL_SEND_MESSAGE_TO_AGENT",
    "WORKSPACE_TOOLS",
    "execute_tool",
]
