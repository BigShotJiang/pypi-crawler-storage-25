"""Abstract workspace backend interface — v1.2.0.

Every method takes ``workspace_id`` as a required keyword argument so the
multi-tenant scoping pattern from :class:`BaseBackend` (where every
read/write is bound to ``agent_id``) extends cleanly across the
boundary. A concrete backend implementation must thread ``workspace_id``
through every WHERE clause; never assume a single workspace per process.

Multi-A surface:
    initialize / close / migration_status
    upsert_workspace / get_workspace / archive_workspace
    register_agent / unregister_agent
    list_agents / get_agent / touch_agent_seen

Multi-B surface (shared memory pool, endorsements / contentions, team
insights, cross-agent provenance — the patent-defensible moat):
    promote_shared_memory / get_shared_memory / list_shared_memories
        / archive_shared_memory
    record_endorsement / record_contention
    list_endorsements / list_contentions
    record_xagent_event / list_xagent_events_by_entity
        / list_xagent_events_by_actor
    record_team_insight / record_team_insight_contribution
    get_team_insight / list_team_insights
        / list_team_insight_contributions

Multi-C surface (agent-to-agent messaging — fire-and-forget bus,
threads, rate limits, ThreadExitPolicy gating):
    record_message / get_message / list_inbox / list_thread
    mark_message_read / mark_message_replied / mark_message_expired
    record_broadcast_read
    count_messages_sent_within
    upsert_thread_closure / get_thread_closure

The skeleton :class:`PostgresWorkspaceBackend` raises
:class:`NotImplementedError` on every concrete method until v1.3.0; the
ABC itself is dialect-agnostic.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from datetime import datetime


class BaseWorkspaceBackend(ABC):
    """Abstract base class for cross-agent workspace storage.

    A workspace backend persists exactly the cross-agent state that
    cannot live inside an individual :class:`WisdomAgent`'s own
    :class:`BaseBackend`: the agent directory, shared memory pool,
    team insights, and cross-agent provenance event log.

    The interface is intentionally narrow in v1.2.0. Multi-B (shared
    pool reads/writes) and Multi-C (agent messaging) extend this class
    with additional abstract methods; the v1.3.0 mesh-completion work
    extends it again. Each new abstract method ships with a SQLite
    implementation; Postgres fills in afterwards.
    """

    # ---- Lifecycle -------------------------------------------------------

    @abstractmethod
    async def initialize(self) -> None:
        """Open connections and apply pending workspace migrations.

        Idempotent. Safe to call on every boot — :class:`MigrationRunner`
        consults ``schema_migrations`` and only runs versions that have
        not yet been applied.
        """

    @abstractmethod
    async def close(self) -> None:
        """Close connections and release resources."""

    @abstractmethod
    async def migration_status(self) -> dict[str, Any]:
        """Return a structured report of applied + pending workspace migrations.

        Mirror of :meth:`BaseBackend.migration_status` for the workspace
        migration namespace. Shape::

            {
                "applied": [{"version": 1, "name": "0001_workspace", ...}, ...],
                "pending": [...],
                "current_version": 1,
            }
        """

    # ---- Workspace row ---------------------------------------------------

    @abstractmethod
    async def upsert_workspace(
        self,
        *,
        workspace_id: str,
        name: str,
        license_jti: str,
        config: dict[str, object],
        feature_flags: dict[str, bool],
        created_at: datetime,
    ) -> None:
        """Insert or update the canonical row for this workspace.

        Idempotent on ``workspace_id``. ``license_jti`` is the JWT ID of
        the license token used to construct the workspace; recorded for
        post-hoc audit (which key authorized this workspace's creation),
        not for per-call enforcement.
        """

    @abstractmethod
    async def get_workspace(self, *, workspace_id: str) -> dict[str, Any] | None:
        """Return the workspace row, or ``None`` if it does not exist.

        Shape::

            {
                "id": str,
                "name": str,
                "license_jti": str,
                "config": dict,
                "feature_flags": dict,
                "created_at": datetime,
                "archived_at": datetime | None,
            }
        """

    @abstractmethod
    async def archive_workspace(self, *, workspace_id: str, archived_at: datetime) -> None:
        """Soft-archive a workspace.

        Sets ``archived_at`` on the workspace row. Does not cascade to
        ``agent_directory`` or ``shared_memory_pool`` — historical reads
        across the cross-agent provenance walk continue to work.
        """

    # ---- Agent directory -------------------------------------------------

    @abstractmethod
    async def register_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        capabilities: list[str],
        registered_at: datetime,
        last_seen_at: datetime | None = None,
    ) -> None:
        """Insert or update the directory row for ``agent_id`` in this workspace.

        Idempotent on ``(workspace_id, agent_id)``. On re-register:

        * ``capabilities`` is replaced with the new value (not merged).
        * ``last_seen_at`` is set to the supplied value, or refreshed to
          ``registered_at`` if ``last_seen_at`` is ``None``.
        * ``registered_at`` is preserved from the original registration.
        * ``archived_at`` is cleared (re-register reactivates a previously
          unregistered agent).
        * ``past_success_rate`` is preserved.
        """

    @abstractmethod
    async def unregister_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        archived_at: datetime,
    ) -> None:
        """Soft-archive a directory entry.

        Sets ``archived_at`` on the row but leaves ``past_success_rate``,
        ``capabilities``, and historical references in
        ``shared_memory_pool`` and ``cross_agent_provenance_events``
        intact. Re-registering the same ``agent_id`` clears
        ``archived_at`` and reactivates the row.
        """

    @abstractmethod
    async def list_agents(
        self,
        *,
        workspace_id: str,
        capability: str | None = None,
        active_since: datetime | None = None,
        include_archived: bool = False,
    ) -> list[dict[str, Any]]:
        """Return directory rows matching the predicate set.

        Args:
            capability: When set, only returns agents whose
                ``capabilities`` list contains this exact string.
            active_since: When set, only returns agents whose
                ``last_seen_at >= active_since``.
            include_archived: When ``False`` (default), excludes rows
                with a non-null ``archived_at``.

        Each row::

            {
                "workspace_id": str,
                "agent_id": str,
                "capabilities": list[str],
                "registered_at": datetime,
                "last_seen_at": datetime | None,
                "past_success_rate": float,
                "archived_at": datetime | None,
            }
        """

    @abstractmethod
    async def get_agent(
        self,
        *,
        workspace_id: str,
        agent_id: str,
    ) -> dict[str, Any] | None:
        """Return one directory row, or ``None``.

        Includes archived rows so callers can distinguish "never
        registered" (returns None) from "previously registered, since
        unregistered" (returns row with ``archived_at`` set).
        """

    @abstractmethod
    async def touch_agent_seen(
        self,
        *,
        workspace_id: str,
        agent_id: str,
        last_seen_at: datetime,
    ) -> None:
        """Update ``last_seen_at`` on the directory row.

        Called by liveness signals (heartbeat, message send/receive,
        shared-pool contribution). No-op if the directory row does not
        exist; callers should register first.
        """

    # ---- Shared memory pool (Multi-B) -----------------------------------

    @abstractmethod
    async def promote_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        contributor_id: str,
        source_memory_id: str,
        visibility: str,
        content: str,
        reason: str,
        base_score: float,
        shared_at: datetime,
    ) -> None:
        """Insert a new row into ``shared_memory_pool``.

        Called by :meth:`Workspace.pool.promote` (and by
        ``agent.memory.share`` which delegates through it). The caller
        is responsible for generating ``shared_memory_id`` (the SDK uses
        a stable hash of ``(contributor_id, source_memory_id)`` so a
        re-share of the same private memory is idempotent at the
        application layer; the backend itself does not enforce
        idempotency, leaving that decision to the caller).

        ``visibility`` is the string value of a
        :class:`wisdom_layer.workspace.types.Visibility` member. Backends
        do not validate it as an enum — the application surface enforces
        membership.

        ``base_score`` is frozen at promotion time. ``endorsement_count``
        and ``contention_count`` start at zero; they are managed by
        :meth:`record_endorsement` / :meth:`record_contention`.
        """

    @abstractmethod
    async def get_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> dict[str, Any] | None:
        """Return the shared-memory row, or ``None`` if it does not exist.

        Returns archived rows so callers can render historical
        provenance walks; filter on ``archived_at`` at the call site
        when only live rows are wanted.

        Shape::

            {
                "id": str,
                "workspace_id": str,
                "contributor_id": str,
                "source_memory_id": str,
                "visibility": str,
                "content": str,
                "reason": str,
                "endorsement_count": int,
                "contention_count": int,
                "base_score": float,
                "shared_at": datetime,
                "archived_at": datetime | None,
            }
        """

    @abstractmethod
    async def list_shared_memories(
        self,
        *,
        workspace_id: str,
        contributor_id: str | None = None,
        exclude_contributor_id: str | None = None,
        visibility_in: list[str] | None = None,
        min_base_score: float | None = None,
        include_archived: bool = False,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Return shared-pool rows matching the predicate set.

        Args:
            contributor_id: When set, only returns memories promoted by
                this exact agent. Mutually exclusive with
                ``exclude_contributor_id`` — callers should pass at most
                one.
            exclude_contributor_id: When set, excludes memories promoted
                by this agent. Used by cross-agent search to honour the
                ``exclude_own=True`` flag.
            visibility_in: When set, restricts results to rows whose
                ``visibility`` value appears in the list. Defaults to
                ``["TEAM", "PUBLIC"]`` if the caller wants the full
                cross-agent view; backends do not apply this default.
            min_base_score: When set, restricts to rows with
                ``base_score >= min_base_score``. Score-derived ranking
                (team_score combining endorsements / contentions) is
                applied at the SDK layer, not in SQL.
            include_archived: When ``False`` (default), excludes rows
                with a non-null ``archived_at``.
            limit: Hard cap on rows returned. Backends should ORDER BY
                ``shared_at DESC`` so the most recent contributions
                surface when the cap binds.

        Each row matches the shape returned by :meth:`get_shared_memory`.
        """

    @abstractmethod
    async def archive_shared_memory(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        archived_at: datetime,
    ) -> None:
        """Soft-archive a shared-memory row.

        Sets ``archived_at`` on the row but leaves
        ``shared_memory_endorsements``,
        ``shared_memory_contentions``, and any
        ``team_insight_contributions`` references intact — provenance
        walks across the archived row continue to resolve.
        """

    # ---- Endorsements & contentions (Multi-B) ----------------------------

    @abstractmethod
    async def record_endorsement(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        endorsing_agent_id: str,
        endorsed_at: datetime,
    ) -> bool:
        """Record an endorsement; return ``True`` if new, ``False`` if duplicate.

        On a new endorsement: inserts the audit row and atomically
        increments ``shared_memory_pool.endorsement_count``. On a
        duplicate (the same agent endorsing the same memory twice): the
        method is a no-op and returns ``False`` without raising.

        ``workspace_id`` is required for tenancy isolation even though
        the underlying audit table is keyed only on
        ``(shared_memory_id, endorsing_agent_id)``: backends must verify
        the shared memory belongs to the given workspace before
        recording, so a caller cannot endorse a row in another
        workspace.
        """

    @abstractmethod
    async def record_contention(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
        contesting_agent_id: str,
        reason: str,
        contested_at: datetime,
    ) -> bool:
        """Record a contention; return ``True`` if new, ``False`` if duplicate.

        Mirror of :meth:`record_endorsement`. Re-contesting with a
        different ``reason`` does *not* update the original row — the
        first reason wins. This is intentional: contention is a
        one-shot signal, not a continuous discussion. Disputes that
        require dialogue belong in v1.2.0's Multi-C messaging surface,
        not in the contention audit table.

        Atomically increments
        ``shared_memory_pool.contention_count`` on a new row.
        """

    @abstractmethod
    async def list_endorsements(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> list[dict[str, Any]]:
        """Return all endorsements for a shared memory, oldest-first.

        Each row::

            {
                "shared_memory_id": str,
                "endorsing_agent_id": str,
                "endorsed_at": datetime,
            }
        """

    @abstractmethod
    async def list_contentions(
        self,
        *,
        workspace_id: str,
        shared_memory_id: str,
    ) -> list[dict[str, Any]]:
        """Return all contentions for a shared memory, oldest-first.

        Each row::

            {
                "shared_memory_id": str,
                "contesting_agent_id": str,
                "reason": str,
                "contested_at": datetime,
            }
        """

    # ---- Cross-agent provenance events (Multi-B) -------------------------

    @abstractmethod
    async def record_xagent_event(
        self,
        *,
        workspace_id: str,
        event_id: str,
        event_type: str,
        actor_agent_id: str | None,
        target_agent_id: str | None,
        entity_type: str,
        entity_id: str,
        parent_event_id: str | None,
        payload: dict[str, Any],
        created_at: datetime,
    ) -> None:
        """Append one event to ``cross_agent_provenance_events``.

        Append-only by contract: backends MUST NOT expose UPDATE or
        DELETE methods for this table. Hash-chain tamper evidence is
        deferred to v1.3.0; today, callers can reconstruct chains via
        :attr:`parent_event_id` and verify ordering via ``created_at``.

        ``event_type`` should come from
        :class:`wisdom_layer.workspace.types.XAgentEventType`. Backends
        do not validate the value — the application surface owns the
        taxonomy.

        ``payload`` is JSON-serialised by the backend. Keep it small
        (canonical IDs and minimum render metadata); the underlying
        memory / insight rows are the source of truth for content.
        """

    @abstractmethod
    async def list_xagent_events_by_entity(
        self,
        *,
        workspace_id: str,
        entity_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        """Return cross-agent provenance events for ``entity_id``.

        Oldest-first. Tenant isolation is enforced — events belonging
        to another workspace are never returned even if ``entity_id``
        collides.

        Each row::

            {
                "event_id": str,
                "workspace_id": str,
                "event_type": str,
                "actor_agent_id": str | None,
                "target_agent_id": str | None,
                "entity_type": str,
                "entity_id": str,
                "parent_event_id": str | None,
                "payload": dict,
                "created_at": datetime,
            }
        """

    @abstractmethod
    async def list_xagent_events_by_actor(
        self,
        *,
        workspace_id: str,
        actor_agent_id: str,
        since: datetime | None = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        """Return cross-agent provenance events emitted by ``actor_agent_id``.

        Oldest-first. ``since`` filters on ``created_at >= since`` when
        set; ``None`` (default) returns all events.

        Each row matches the shape returned by
        :meth:`list_xagent_events_by_entity`.
        """

    # ---- Team insights (Multi-B) -----------------------------------------

    @abstractmethod
    async def record_team_insight(
        self,
        *,
        workspace_id: str,
        insight_id: str,
        content: str,
        synthesis_prompt_hash: str,
        contributor_count: int,
        dream_cycle_id: str | None,
        created_at: datetime,
    ) -> None:
        """Insert a row into ``team_insights``.

        Called by Team Dream Phase 1 after the synthesis LLM call
        returns. ``synthesis_prompt_hash`` lets the SDK dedupe re-runs
        of the same prompt against the same input set; the backend
        itself does not enforce uniqueness on it.

        Contributors are recorded in a separate call to
        :meth:`record_team_insight_contribution` (one call per
        contribution row) so the M-to-N edge is the source of truth
        even if ``contributor_count`` drifts.
        """

    @abstractmethod
    async def record_team_insight_contribution(
        self,
        *,
        team_insight_id: str,
        shared_memory_id: str,
        contributor_agent_id: str,
        contribution_weight: float,
    ) -> None:
        """Insert one row into ``team_insight_contributions``.

        Idempotent on the composite primary key
        ``(team_insight_id, shared_memory_id)`` — re-recording the same
        contribution row is a no-op rather than an error.
        ``contribution_weight`` defaults to 1.0 in the schema; pass an
        explicit value when a future weighting strategy
        (citation-graph / PageRank style) is in play.
        """

    @abstractmethod
    async def get_team_insight(
        self,
        *,
        workspace_id: str,
        insight_id: str,
    ) -> dict[str, Any] | None:
        """Return the ``team_insights`` row, or ``None``.

        Shape::

            {
                "id": str,
                "workspace_id": str,
                "content": str,
                "synthesis_prompt_hash": str,
                "contributor_count": int,
                "dream_cycle_id": str | None,
                "created_at": datetime,
                "archived_at": datetime | None,
            }
        """

    @abstractmethod
    async def list_team_insights(
        self,
        *,
        workspace_id: str,
        include_archived: bool = False,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Return team insights for the workspace, newest-first.

        ``include_archived=False`` (default) excludes archived rows.
        """

    @abstractmethod
    async def list_team_insight_contributions(
        self,
        *,
        team_insight_id: str,
    ) -> list[dict[str, Any]]:
        """Return contribution rows for a team insight.

        Each row::

            {
                "team_insight_id": str,
                "shared_memory_id": str,
                "contributor_agent_id": str,
                "contribution_weight": float,
            }
        """

    # ---- Messaging (Multi-C) ---------------------------------------------

    @abstractmethod
    async def record_message(
        self,
        *,
        workspace_id: str,
        message_id: str,
        sender_id: str,
        recipient_id: str | None,
        broadcast_capability: str | None,
        content: str,
        purpose: str,
        related_memory_ids: list[str],
        related_task_id: str | None,
        thread_id: str,
        in_reply_to: str | None,
        expects_reply: bool,
        reply_deadline: datetime | None,
        created_at: datetime,
    ) -> None:
        """Insert one row into ``agent_messages``.

        Direct + broadcast messages share this table. The CHECK
        constraint on the schema (``recipient_id XOR broadcast_capability``)
        is the contract; backends do not need to re-validate but
        violating callers will see a backend-level integrity error.

        ``purpose`` is the string value of a
        :class:`wisdom_layer.workspace.types.MessagePurpose` member;
        backends do not validate the value — the application surface
        owns the taxonomy.

        ``status`` is implicitly ``'pending'`` at insert (schema
        default). Subsequent transitions go through
        :meth:`mark_message_read` / :meth:`mark_message_replied` /
        :meth:`mark_message_expired`.

        ``related_memory_ids`` is JSON-serialised by the backend.
        """

    @abstractmethod
    async def get_message(
        self,
        *,
        workspace_id: str,
        message_id: str,
    ) -> dict[str, Any] | None:
        """Return the message row, or ``None``.

        Shape::

            {
                "id": str,
                "workspace_id": str,
                "sender_id": str,
                "recipient_id": str | None,
                "broadcast_capability": str | None,
                "content": str,
                "purpose": str,
                "related_memory_ids": list[str],
                "related_task_id": str | None,
                "thread_id": str,
                "in_reply_to": str | None,
                "expects_reply": bool,
                "reply_deadline": datetime | None,
                "status": str,
                "read_at": datetime | None,
                "replied_at": datetime | None,
                "reply_message_id": str | None,
                "created_at": datetime,
            }
        """

    @abstractmethod
    async def list_inbox(
        self,
        *,
        workspace_id: str,
        recipient_id: str,
        recipient_capabilities: list[str],
        unread_only: bool = True,
        include_broadcasts: bool = True,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Return messages addressed to ``recipient_id``.

        Combines two sources:

        * Direct messages where ``recipient_id == recipient_id``.
        * Broadcasts whose ``broadcast_capability`` appears in
          ``recipient_capabilities``, when ``include_broadcasts=True``.

        ``unread_only=True`` (default) hides direct messages where
        ``status != 'pending'`` and broadcasts already acked in
        :class:`broadcast_reads` for ``recipient_id``.

        Newest-first.

        Each row matches the shape returned by :meth:`get_message`.
        """

    @abstractmethod
    async def list_thread(
        self,
        *,
        workspace_id: str,
        thread_id: str,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        """Return all messages in a thread, oldest-first.

        Includes the root message and every reply. Each row matches the
        shape returned by :meth:`get_message`.
        """

    @abstractmethod
    async def mark_message_read(
        self,
        *,
        workspace_id: str,
        message_id: str,
        reader_agent_id: str,
        read_at: datetime,
    ) -> bool:
        """Mark a direct message as read or record a broadcast ack.

        For a direct message: transitions ``status pending → read`` if
        not already past pending; idempotent on subsequent calls.
        Returns ``True`` when the row transitioned, ``False`` on a
        no-op (already read / replied / not addressed to this reader).

        For a broadcast (``recipient_id IS NULL``): inserts a row into
        :class:`broadcast_reads` keyed on
        ``(message_id, reader_agent_id)``. Returns ``True`` on the
        first ack from this reader, ``False`` on a duplicate.
        """

    @abstractmethod
    async def mark_message_replied(
        self,
        *,
        workspace_id: str,
        message_id: str,
        reply_message_id: str,
        replied_at: datetime,
    ) -> None:
        """Record that the recipient replied to ``message_id``.

        Sets ``replied_at``, ``reply_message_id``, and transitions
        ``status → replied``. Idempotent: a second call with the same
        ``reply_message_id`` is a no-op; a different
        ``reply_message_id`` is a contract violation by the caller and
        the first reply wins (the SDK does not raise to keep this method
        deterministic from the bus's perspective).
        """

    @abstractmethod
    async def mark_message_expired(
        self,
        *,
        workspace_id: str,
        message_id: str,
        expired_at: datetime,
    ) -> bool:
        """Transition a pending message to ``status = 'expired'``.

        No-op if the message is already past pending. Returns ``True``
        on transition, ``False`` on no-op. Called by the SDK lazily on
        inbox / thread reads when ``reply_deadline`` is in the past;
        there is no background expiry daemon.
        """

    @abstractmethod
    async def count_messages_sent_within(
        self,
        *,
        workspace_id: str,
        sender_id: str,
        since: datetime,
        is_broadcast: bool | None = None,
    ) -> int:
        """Count messages sent by ``sender_id`` since ``since``.

        Reads from ``message_rate_limit_log``. ``is_broadcast=None``
        (default) counts all sends; ``True`` restricts to broadcasts;
        ``False`` restricts to direct sends. Used by the
        :class:`MessageBus` to enforce per-agent and per-broadcast
        hourly caps before recording the next send.
        """

    @abstractmethod
    async def record_rate_limit_event(
        self,
        *,
        workspace_id: str,
        sender_id: str,
        is_broadcast: bool,
        sent_at: datetime,
    ) -> None:
        """Append one row to ``message_rate_limit_log``.

        Append-only. Pruning of old rows is the SDK's responsibility
        (the bus calls a TTL prune at boot and every Nth send); the
        backend exposes :meth:`prune_rate_limit_log` for that path.
        """

    @abstractmethod
    async def prune_rate_limit_log(
        self,
        *,
        workspace_id: str,
        older_than: datetime,
    ) -> int:
        """Delete rate-limit log rows with ``sent_at < older_than``.

        Returns the number of rows pruned. Called periodically by the
        :class:`MessageBus` to keep the log bounded.
        """

    @abstractmethod
    async def upsert_thread_closure(
        self,
        *,
        workspace_id: str,
        thread_id: str,
        closed_at: datetime,
        close_reason: str,
        close_metadata: dict[str, Any],
    ) -> None:
        """Insert or update the closure row for a thread.

        Idempotent on ``(workspace_id, thread_id)``. The first closure
        wins on the timestamp + reason; subsequent calls overwrite
        ``close_metadata`` only (so a re-evaluation can refresh the
        evidence bag without rewriting history).
        """

    @abstractmethod
    async def get_thread_closure(
        self,
        *,
        workspace_id: str,
        thread_id: str,
    ) -> dict[str, Any] | None:
        """Return the closure row for ``thread_id``, or ``None`` if open.

        Shape::

            {
                "workspace_id": str,
                "thread_id": str,
                "closed_at": datetime | None,
                "close_reason": str | None,
                "close_metadata": dict[str, Any],
            }

        A row exists in :class:`message_threads` only after the first
        :meth:`upsert_thread_closure` call; an open thread returns
        ``None`` (not a row with ``closed_at IS NULL``).
        """
