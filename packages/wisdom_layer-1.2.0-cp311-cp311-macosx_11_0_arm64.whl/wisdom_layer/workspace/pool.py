"""Shared memory pool — Multi-B surface, v1.2.0.

Adapts the row-dict storage surface of :class:`BaseWorkspaceBackend` into
typed, frozen dataclasses (:class:`SharedMemory`, :class:`TeamInsight`,
:class:`TeamInsightProvenance`) and emits cross-agent provenance events
on every state transition.

The pool owns three responsibilities the backend layer deliberately does
not:

1. **Idempotency by content identity.** ``shared_memory_id`` is a stable
   hash of ``(contributor_id, source_memory_id)``. Re-promoting the same
   private memory is a no-op rather than a duplicate row. The hash is
   computed at the SDK boundary so the backend stays a generic
   key-value store.
2. **Cross-agent provenance event emission.** Every mutating operation
   (promote / endorse / contest / synthesize_team_insight) appends a
   matching ``cross_agent_provenance_events`` row. The events are the
   canonical audit log for "who did what to whose memory" — Studio
   dashboards, benchmark harnesses, and the v1.3.0 mesh integrity
   pipeline all read from this stream.
3. **Provenance walk termination.** :meth:`walk_provenance` is the
   patent-defensible boundary. It returns the team insight, the list of
   contributing shared memories, and each contribution's
   ``source_memory_id`` back-pointer into the contributor's per-agent
   DB. **It does not, and cannot, dereference that back-pointer.** Only
   the contributor — who holds a handle to their own per-agent backend
   — can resolve it via ``agent.memory.get(memory_id)``. Compromising
   ``workspace.db`` never exposes any contributor's private memory
   content. This is enforced two ways: the
   :class:`TeamInsightProvenance` type has no field for cross-agent
   private content, and the walk method itself never opens a per-agent
   backend.
"""

from __future__ import annotations

import hashlib
import logging
import uuid
from datetime import UTC
from typing import TYPE_CHECKING, Any

from wisdom_layer.workspace.types import (
    ProvenanceContribution,
    SharedMemory,
    TeamInsight,
    TeamInsightProvenance,
    Visibility,
    XAgentEventType,
)

if TYPE_CHECKING:
    from wisdom_layer.clock import Clock
    from wisdom_layer.workspace.backend import BaseWorkspaceBackend

logger = logging.getLogger(__name__)

# Module-level alias for the ``list`` builtin so annotations inside
# :class:`SharedMemoryPool` (which has a ``.list()`` method that shadows
# the builtin in class scope) resolve correctly under mypy. Used only in
# type annotations — never at runtime.
_List = list


def _shared_memory_id(contributor_id: str, source_memory_id: str) -> str:
    """Deterministic 16-char hex id for a (contributor, source_memory) pair.

    Re-promoting the same private memory yields the same id, so the
    underlying ``ON CONFLICT DO NOTHING`` in the backend collapses the
    duplicate. SHA-256 truncated to 16 chars is collision-resistant for
    the workspace's row-count regime; the full hash is unnecessary
    storage overhead.
    """
    digest = hashlib.sha256(
        f"{contributor_id}|{source_memory_id}".encode()
    ).hexdigest()
    return digest[:16]


def _gen_id() -> str:
    """16-char hex id for insight rows and event rows."""
    return uuid.uuid4().hex[:16]


def _shared_memory_from_row(row: dict[str, Any]) -> SharedMemory:
    return SharedMemory(
        id=str(row["id"]),
        workspace_id=str(row["workspace_id"]),
        contributor_id=str(row["contributor_id"]),
        source_memory_id=str(row["source_memory_id"]),
        visibility=Visibility(str(row["visibility"])),
        content=str(row["content"]),
        reason=str(row["reason"]),
        endorsement_count=int(row["endorsement_count"]),
        contention_count=int(row["contention_count"]),
        base_score=float(row["base_score"]),
        shared_at=row["shared_at"],
        archived_at=row["archived_at"],
    )


def _team_insight_from_row(row: dict[str, Any]) -> TeamInsight:
    return TeamInsight(
        id=str(row["id"]),
        workspace_id=str(row["workspace_id"]),
        content=str(row["content"]),
        synthesis_prompt_hash=str(row["synthesis_prompt_hash"]),
        contributor_count=int(row["contributor_count"]),
        dream_cycle_id=(
            str(row["dream_cycle_id"]) if row["dream_cycle_id"] is not None else None
        ),
        created_at=row["created_at"],
        archived_at=row["archived_at"],
    )


class SharedMemoryPool:
    """The Multi-B shared-memory surface for one workspace.

    Holds a reference to the workspace's :class:`BaseWorkspaceBackend`
    and the workspace's own ``workspace_id``. Every method threads the
    workspace_id into the backend call so the multi-tenant isolation
    contract is uniform.

    Use :meth:`promote` to publish a private memory into the pool,
    :meth:`endorse` / :meth:`contest` to surface team consensus,
    :meth:`search` / :meth:`list` to retrieve, and :meth:`walk_provenance`
    to traverse the team-insight → contributing-memory edges. Team Dream
    Phase 1 calls :meth:`synthesize_team_insight` to record the
    collective synthesis output and its contributing rows in one
    transaction.
    """

    def __init__(
        self,
        *,
        backend: BaseWorkspaceBackend,
        workspace_id: str,
        clock: Clock,
    ) -> None:
        self._backend = backend
        self._workspace_id = workspace_id
        self._clock = clock

    # ---- Promotion / fetch / list / search -------------------------------

    async def promote(
        self,
        *,
        contributor_id: str,
        source_memory_id: str,
        content: str,
        visibility: Visibility = Visibility.TEAM,
        reason: str = "",
        base_score: float = 0.0,
    ) -> str:
        """Promote a private memory into the workspace pool.

        Returns the deterministic ``shared_memory_id``. Re-promoting the
        same ``(contributor_id, source_memory_id)`` is idempotent — the
        original row's content / counters are preserved.

        Args:
            contributor_id: The promoting agent's ``agent_id``.
            source_memory_id: The contributor's per-agent memory id —
                the back-reference target for provenance walks. Stays
                opaque at the workspace boundary; only the contributor
                can dereference it via their own backend.
            content: The promoted memory text. The contributor's
                per-agent backend retains the authoritative copy; this
                column is the consumable one for cross-agent search.
            visibility: ``TEAM`` (default) or ``PUBLIC``. ``PRIVATE`` is
                a contradiction in terms — it lives in the pool — and
                raises :class:`ValueError`.
            reason: Free-form rationale ("why am I sharing this"). Shows
                up in dashboards and the cross-agent provenance log.
            base_score: Frozen at promotion time. Carries forward
                whatever ranking weight the contributor's local memory
                carried (default 0.0 keeps the math sane when the
                contributor has no scoring signal of their own).

        Raises:
            ValueError: If ``visibility`` is :attr:`Visibility.PRIVATE`.
        """
        if visibility == Visibility.PRIVATE:
            raise ValueError(
                "Cannot promote with visibility=PRIVATE — the PRIVATE "
                "scope is the back-reference sentinel and never appears "
                "in shared_memory_pool. Use TEAM or PUBLIC."
            )
        shared_id = _shared_memory_id(contributor_id, source_memory_id)
        now = self._clock.now().astimezone(UTC)
        await self._backend.promote_shared_memory(
            workspace_id=self._workspace_id,
            shared_memory_id=shared_id,
            contributor_id=contributor_id,
            source_memory_id=source_memory_id,
            visibility=visibility.value,
            content=content,
            reason=reason,
            base_score=base_score,
            shared_at=now,
        )
        await self._emit_xagent_event(
            event_type=XAgentEventType.MEMORY_SHARED,
            actor_agent_id=contributor_id,
            target_agent_id=None,
            entity_type="shared_memory",
            entity_id=shared_id,
            payload={
                "contributor_id": contributor_id,
                "source_memory_id": source_memory_id,
                "visibility": visibility.value,
                "reason": reason,
            },
        )
        logger.info(
            "shared memory promoted",
            extra={
                "subsystem": "workspace.pool",
                "workspace_id": self._workspace_id,
                "shared_memory_id": shared_id,
                "contributor_id": contributor_id,
                "visibility": visibility.value,
            },
        )
        return shared_id

    async def get(self, shared_memory_id: str) -> SharedMemory | None:
        """Return one shared memory, or ``None`` if it does not exist.

        Returns archived rows so callers can render historical provenance
        walks; filter on :attr:`SharedMemory.archived_at` at the call
        site if only live rows are wanted.
        """
        row = await self._backend.get_shared_memory(
            workspace_id=self._workspace_id,
            shared_memory_id=shared_memory_id,
        )
        if row is None:
            return None
        return _shared_memory_from_row(row)

    async def list(
        self,
        *,
        contributor_id: str | None = None,
        exclude_contributor_id: str | None = None,
        visibility_in: _List[Visibility] | None = None,
        min_base_score: float | None = None,
        include_archived: bool = False,
        limit: int = 100,
    ) -> _List[SharedMemory]:
        """Return shared-pool rows matching the predicate set, newest-first.

        Args mirror :meth:`BaseWorkspaceBackend.list_shared_memories`
        with two boundary refinements:

        * ``visibility_in`` accepts :class:`Visibility` enum values; the
          pool maps them to strings before crossing into the backend.
        * ``contributor_id`` and ``exclude_contributor_id`` are mutually
          exclusive — pass at most one. The backend raises
          :class:`ValueError` if both are supplied.
        """
        visibility_strs = (
            [v.value for v in visibility_in] if visibility_in is not None else None
        )
        rows = await self._backend.list_shared_memories(
            workspace_id=self._workspace_id,
            contributor_id=contributor_id,
            exclude_contributor_id=exclude_contributor_id,
            visibility_in=visibility_strs,
            min_base_score=min_base_score,
            include_archived=include_archived,
            limit=limit,
        )
        return [_shared_memory_from_row(r) for r in rows]

    async def search(
        self,
        query: str,
        *,
        asking_agent_id: str | None = None,
        exclude_own: bool = False,
        visibility_in: _List[Visibility] | None = None,
        limit: int = 20,
    ) -> _List[SharedMemory]:
        """Substring search over shared-memory content, ranked by team_score.

        v1.2.0 ships text-substring matching only — semantic search lands
        with the shared-pool embedding column in v1.3.0. Results are
        sorted by :attr:`SharedMemory.team_score` descending so the
        highest-confidence rows surface first.

        Args:
            query: Case-insensitive substring matched against
                :attr:`SharedMemory.content`. Empty string matches all
                rows (the predicate degenerates into a list call).
            asking_agent_id: The agent on whose behalf the search runs.
                Required when ``exclude_own=True``; supplies the value
                for the underlying contributor-exclusion filter.
            exclude_own: When ``True``, omits memories the asking agent
                contributed. The default of ``False`` returns the full
                visible pool. ``PUBLIC``-scoped memories are *not*
                exempted from this filter at the pool layer; that
                exemption belongs to the application surface
                (``agent.memory.search``) which knows whether the
                visibility-aware view is desired.
            visibility_in: Defaults to ``[TEAM, PUBLIC]`` when ``None`` —
                the canonical cross-agent view. Pass an explicit list to
                widen or narrow.
            limit: Soft cap on rows returned. The pool over-fetches
                (4× limit) and re-ranks in Python so team_score order is
                stable even when the backend cap binds.

        Raises:
            ValueError: If ``exclude_own=True`` and ``asking_agent_id``
                is ``None``. The contract requires the asking identity
                to enforce the exclusion safely.
        """
        if exclude_own and asking_agent_id is None:
            raise ValueError(
                "search(exclude_own=True) requires asking_agent_id — "
                "the pool cannot infer 'own' without the asking identity."
            )
        view = visibility_in if visibility_in is not None else [
            Visibility.TEAM,
            Visibility.PUBLIC,
        ]
        rows = await self.list(
            exclude_contributor_id=asking_agent_id if exclude_own else None,
            visibility_in=view,
            include_archived=False,
            limit=max(limit * 4, limit),
        )
        needle = query.casefold()
        if needle:
            rows = [r for r in rows if needle in r.content.casefold()]
        rows.sort(key=lambda r: r.team_score, reverse=True)
        return rows[:limit]

    async def archive(self, shared_memory_id: str) -> None:
        """Soft-archive a shared memory.

        Removes it from active search / list results but preserves the
        row, its endorsements, contentions, and any
        ``team_insight_contributions`` references. Provenance walks
        across the archived row continue to resolve.
        """
        now = self._clock.now().astimezone(UTC)
        await self._backend.archive_shared_memory(
            workspace_id=self._workspace_id,
            shared_memory_id=shared_memory_id,
            archived_at=now,
        )
        logger.info(
            "shared memory archived",
            extra={
                "subsystem": "workspace.pool",
                "workspace_id": self._workspace_id,
                "shared_memory_id": shared_memory_id,
            },
        )

    # ---- Endorsements & contentions -------------------------------------

    async def endorse(
        self,
        shared_memory_id: str,
        *,
        endorsing_agent_id: str,
    ) -> bool:
        """Record an endorsement; ``True`` if new, ``False`` if duplicate.

        Endorsement is a *surfacing* primitive, not a vote — the count
        feeds the team_score weighting. A re-endorsement by the same
        agent is a silent no-op (the backend's composite PK enforces
        the single-vote-per-agent contract).

        On a new endorsement, emits an
        :attr:`XAgentEventType.MEMORY_ENDORSED` event so cross-agent
        provenance walks see who lent their voice to which memory.
        Duplicates do not emit (the event log is the audit, not the
        attempt log).
        """
        now = self._clock.now().astimezone(UTC)
        is_new = await self._backend.record_endorsement(
            workspace_id=self._workspace_id,
            shared_memory_id=shared_memory_id,
            endorsing_agent_id=endorsing_agent_id,
            endorsed_at=now,
        )
        if is_new:
            await self._emit_xagent_event(
                event_type=XAgentEventType.MEMORY_ENDORSED,
                actor_agent_id=endorsing_agent_id,
                target_agent_id=None,
                entity_type="shared_memory",
                entity_id=shared_memory_id,
                payload={"endorsing_agent_id": endorsing_agent_id},
            )
        return is_new

    async def contest(
        self,
        shared_memory_id: str,
        *,
        contesting_agent_id: str,
        reason: str,
    ) -> bool:
        """Record a contention; ``True`` if new, ``False`` if duplicate.

        ``reason`` is required and persisted so reviewers can adjudicate
        without chasing the contesting agent. Re-contesting with a
        different reason does *not* update the original row — disputes
        that need dialogue belong in the v1.2.0 Multi-C messaging
        surface, not in the contention audit table.
        """
        now = self._clock.now().astimezone(UTC)
        is_new = await self._backend.record_contention(
            workspace_id=self._workspace_id,
            shared_memory_id=shared_memory_id,
            contesting_agent_id=contesting_agent_id,
            reason=reason,
            contested_at=now,
        )
        if is_new:
            await self._emit_xagent_event(
                event_type=XAgentEventType.MEMORY_CONTESTED,
                actor_agent_id=contesting_agent_id,
                target_agent_id=None,
                entity_type="shared_memory",
                entity_id=shared_memory_id,
                payload={
                    "contesting_agent_id": contesting_agent_id,
                    "reason": reason,
                },
            )
        return is_new

    # ---- Team insights & provenance walk --------------------------------

    async def synthesize_team_insight(
        self,
        *,
        content: str,
        contributor_shared_memories: _List[tuple[str, str, float]],
        synthesis_prompt_hash: str,
        dream_cycle_id: str | None = None,
    ) -> str:
        """Persist a Team Dream Phase 1 collective synthesis output.

        Records the insight row, the M-to-N contribution edges, and a
        :attr:`XAgentEventType.TEAM_INSIGHT_SYNTHESIZED` event in one
        logical pass. Returns the new ``insight_id``.

        Args:
            content: The synthesised insight text. The LLM output
                committed to the team's collective record.
            contributor_shared_memories: List of
                ``(shared_memory_id, contributor_agent_id,
                contribution_weight)`` tuples — one per memory the
                synthesis drew from. ``contribution_weight=1.0`` is the
                neutral default; future weighting strategies (citation-
                graph PageRank) populate non-uniform weights.
            synthesis_prompt_hash: SHA hash of the synthesis prompt and
                input set. Lets the SDK dedupe re-runs of the same
                prompt against the same inputs without a unique index
                on the column.
            dream_cycle_id: When the synthesis was triggered by a Team
                Dream Phase 1 run, the cycle id flows through here so
                the Studio dashboard can render insight → cycle linkage.
        """
        insight_id = _gen_id()
        now = self._clock.now().astimezone(UTC)
        contributor_ids = {agent_id for _, agent_id, _ in contributor_shared_memories}
        await self._backend.record_team_insight(
            workspace_id=self._workspace_id,
            insight_id=insight_id,
            content=content,
            synthesis_prompt_hash=synthesis_prompt_hash,
            contributor_count=len(contributor_ids),
            dream_cycle_id=dream_cycle_id,
            created_at=now,
        )
        for shared_id, agent_id, weight in contributor_shared_memories:
            await self._backend.record_team_insight_contribution(
                team_insight_id=insight_id,
                shared_memory_id=shared_id,
                contributor_agent_id=agent_id,
                contribution_weight=weight,
            )
        await self._emit_xagent_event(
            event_type=XAgentEventType.TEAM_INSIGHT_SYNTHESIZED,
            actor_agent_id=None,
            target_agent_id=None,
            entity_type="team_insight",
            entity_id=insight_id,
            payload={
                "synthesis_prompt_hash": synthesis_prompt_hash,
                "contributor_count": len(contributor_ids),
                "dream_cycle_id": dream_cycle_id,
                "shared_memory_ids": [s for s, _, _ in contributor_shared_memories],
            },
        )
        logger.info(
            "team insight synthesized",
            extra={
                "subsystem": "workspace.pool",
                "workspace_id": self._workspace_id,
                "insight_id": insight_id,
                "contributor_count": len(contributor_ids),
                "dream_cycle_id": dream_cycle_id,
            },
        )
        return insight_id

    async def get_team_insight(self, insight_id: str) -> TeamInsight | None:
        """Return one team insight, or ``None``."""
        row = await self._backend.get_team_insight(
            workspace_id=self._workspace_id,
            insight_id=insight_id,
        )
        if row is None:
            return None
        return _team_insight_from_row(row)

    async def list_team_insights(
        self,
        *,
        include_archived: bool = False,
        limit: int = 100,
    ) -> _List[TeamInsight]:
        """Return team insights for this workspace, newest-first."""
        rows = await self._backend.list_team_insights(
            workspace_id=self._workspace_id,
            include_archived=include_archived,
            limit=limit,
        )
        return [_team_insight_from_row(r) for r in rows]

    async def walk_provenance(self, team_insight_id: str) -> TeamInsightProvenance:
        """Walk a team insight to the workspace boundary of its provenance.

        **Patent-defensible isolation contract.** This method returns:

        * The :class:`TeamInsight` row.
        * One :class:`ProvenanceContribution` per contributing memory,
          carrying the ``shared_memory_id``, ``contributor_agent_id``,
          ``source_memory_id`` (an opaque back-pointer into the
          contributor's per-agent backend), the *shared* content (what
          the contributor explicitly promoted), and the contribution
          weight.

        The walk **terminates at the workspace boundary**: it never
        opens a per-agent backend, never dereferences
        ``source_memory_id`` against another agent's private memory,
        and never returns private memory content from any contributor.
        Resolving ``source_memory_id`` is the contributor's exclusive
        right via ``agent.memory.get(memory_id)`` on their own backend.

        Compromising ``workspace.db`` therefore exposes only what the
        contributors explicitly chose to share, never the private
        memories those shares were *derived from*. The
        :class:`TeamInsightProvenance` type itself has no field for
        cross-agent private content — the type system enforces the
        invariant at compile time; this method enforces it at runtime.

        Raises:
            LookupError: If the team insight does not exist in this
                workspace. Distinguishing "missing" from "wrong
                workspace" is intentional — the workspace boundary is
                also a tenancy boundary.
        """
        insight = await self.get_team_insight(team_insight_id)
        if insight is None:
            raise LookupError(
                f"Team insight {team_insight_id!r} not found in workspace "
                f"{self._workspace_id!r}."
            )
        contribution_rows = await self._backend.list_team_insight_contributions(
            team_insight_id=team_insight_id,
        )
        contributions: _List[ProvenanceContribution] = []
        for row in contribution_rows:
            shared_id = str(row["shared_memory_id"])
            shared = await self.get(shared_id)
            if shared is None:
                # The contribution edge points at a shared memory that
                # has been hard-deleted (no path produces this in v1.2.0;
                # the surface only soft-archives). Skip rather than fail
                # so the walk still returns the insight + the surviving
                # contributions — the caller can detect the mismatch via
                # contributor_count vs len(contributions).
                continue
            contributions.append(
                ProvenanceContribution(
                    shared_memory_id=shared_id,
                    contributor_agent_id=str(row["contributor_agent_id"]),
                    source_memory_id=shared.source_memory_id,
                    shared_content=shared.content,
                    contribution_weight=float(row["contribution_weight"]),
                )
            )
        return TeamInsightProvenance(
            team_insight=insight,
            contributions=contributions,
        )

    # ---- Internal --------------------------------------------------------

    async def _emit_xagent_event(
        self,
        *,
        event_type: str,
        actor_agent_id: str | None,
        target_agent_id: str | None,
        entity_type: str,
        entity_id: str,
        payload: dict[str, object],
    ) -> None:
        """Append one row to ``cross_agent_provenance_events``.

        Centralised so callers do not have to reach into ``_clock`` /
        ``_backend`` for the canonical fields. ``parent_event_id`` is
        always ``None`` in v1.2.0 — chain reconstruction is the caller's
        responsibility today; v1.3.0 introduces the hash-chain that uses
        this field.
        """
        await self._backend.record_xagent_event(
            workspace_id=self._workspace_id,
            event_id=_gen_id(),
            event_type=event_type,
            actor_agent_id=actor_agent_id,
            target_agent_id=target_agent_id,
            entity_type=entity_type,
            entity_id=entity_id,
            parent_event_id=None,
            payload=payload,
            created_at=self._clock.now().astimezone(UTC),
        )
