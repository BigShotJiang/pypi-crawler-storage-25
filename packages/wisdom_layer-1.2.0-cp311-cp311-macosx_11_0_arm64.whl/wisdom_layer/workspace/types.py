"""Workspace value types — visibility scopes, shared-memory records,
team-insight records, and the cross-agent provenance event log row.

These types are the typed boundary between the workspace backend (which
deals in raw row dicts) and the public :mod:`wisdom_layer.workspace`
surface (which returns frozen dataclasses). They mirror the
``shared_memory_pool``, ``team_insights``, and
``cross_agent_provenance_events`` tables from
``migrations/workspace_sqlite/0001_workspace.sql``.

The Visibility enum is enforced application-side, not as a CHECK
constraint — keeping the value space extensible across future scopes
(e.g. ``CAPABILITY``-scoped sharing) without requiring a schema
migration. ``PRIVATE`` is reserved as a sentinel for the back-reference
target that lives in the contributor's per-agent DB; a row in
``shared_memory_pool`` should never carry ``PRIVATE`` because that is
a contradiction in terms (it lives in the pool).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from datetime import datetime


class Visibility(StrEnum):
    """Visibility scope for a shared memory.

    Members:
        PRIVATE: Sentinel for the back-reference target in the
            contributor's per-agent DB. Never appears in
            ``shared_memory_pool`` by definition.
        TEAM: Visible to all agents registered to the workspace.
            Default for :meth:`Workspace.pool.promote`.
        PUBLIC: Visible workspace-wide and surfaced via list / search
            regardless of contributor-exclusion filters. Reserved for
            artifacts the contributor explicitly wants every consumer to
            see (canonical decisions, public references).
    """

    PRIVATE = "PRIVATE"
    TEAM = "TEAM"
    PUBLIC = "PUBLIC"


# Score weighting constants. Surfaced as module-level so dashboards and
# tests can reference the same numbers the SDK applies, without
# duplicating the literal in two places.
ENDORSEMENT_WEIGHT: float = 0.1
CONTENTION_WEIGHT: float = 0.2


def compute_team_score(
    *,
    base_score: float,
    endorsement_count: int,
    contention_count: int,
) -> float:
    """Compute the derived team score for a shared memory.

    ``team_score = base_score
                   + (ENDORSEMENT_WEIGHT * endorsement_count)
                   - (CONTENTION_WEIGHT * contention_count)``

    Per the v1.2.0 design, the score is computed on read; only the
    counters and base score are denormalized into ``shared_memory_pool``.
    Centralising the formula here prevents drift between the SDK and any
    downstream tool (Studio dashboard, benchmark harness) that needs to
    reproduce the ranking.
    """
    return (
        base_score
        + (ENDORSEMENT_WEIGHT * endorsement_count)
        - (CONTENTION_WEIGHT * contention_count)
    )


@dataclass(frozen=True)
class SharedMemory:
    """One row in the workspace ``shared_memory_pool``.

    Read-only snapshot at the moment of fetch. The :attr:`team_score`
    property is derived from :attr:`base_score`, :attr:`endorsement_count`,
    and :attr:`contention_count` via :func:`compute_team_score`; treat it
    as a view, not a stored field.

    Fields:
        id: Stable workspace-scoped identifier for this shared memory.
        workspace_id: The owning workspace.
        contributor_id: ``agent_id`` of the agent that promoted the
            memory into the pool. Survives the contributor's
            unregistration so historical provenance walks still resolve.
        source_memory_id: Back-reference to the row in the
            contributor's own per-agent backend. The provenance walk
            crosses the workspace boundary by looking up this id in the
            contributor's DB. Compromising ``workspace.db`` never
            exposes the private content behind this id.
        visibility: Application-side enforced scope. Always ``TEAM`` or
            ``PUBLIC`` for rows that exist in the pool; ``PRIVATE`` is a
            sentinel reserved for the back-reference target.
        content: The promoted memory content as a JSON-serialisable
            string. The contributor's per-agent backend retains the
            authoritative copy; this column is the consumable one for
            cross-agent search.
        reason: Free-form rationale supplied at promotion time
            (``agent.memory.share(memory_id, visibility, reason)``).
            Surfaces in dashboards and the cross-agent provenance log.
        endorsement_count: Distinct endorsing agents — denormalised from
            :class:`SharedMemoryEndorsement`. Updated transactionally on
            each :meth:`Workspace.pool.endorse` call.
        contention_count: Distinct contesting agents — denormalised from
            :class:`SharedMemoryContention`. Updated transactionally on
            each :meth:`Workspace.pool.contest` call.
        base_score: Frozen at promotion time. Carries forward whatever
            ranking weight the contributor's local memory carried.
        shared_at: Promotion timestamp.
        archived_at: Set when an admin or the contributor explicitly
            removes the memory from circulation. Archived rows remain in
            the pool for provenance walks but are excluded from
            cross-agent search by default.
    """

    id: str
    workspace_id: str
    contributor_id: str
    source_memory_id: str
    visibility: Visibility
    content: str
    reason: str
    endorsement_count: int
    contention_count: int
    base_score: float
    shared_at: datetime
    archived_at: datetime | None

    @property
    def team_score(self) -> float:
        """Derived score combining base score, endorsements, contentions."""
        return compute_team_score(
            base_score=self.base_score,
            endorsement_count=self.endorsement_count,
            contention_count=self.contention_count,
        )


@dataclass(frozen=True)
class SharedMemoryEndorsement:
    """One row in the workspace ``shared_memory_endorsements`` audit table.

    Endorse is a *surfacing* primitive, not a vote. The aggregate count
    on :class:`SharedMemory` is what scoring uses; the per-row endorser
    audit exists so dashboards can answer "who has endorsed this" and
    so the SDK can prevent double-counting.
    """

    shared_memory_id: str
    endorsing_agent_id: str
    endorsed_at: datetime


@dataclass(frozen=True)
class SharedMemoryContention:
    """One row in the workspace ``shared_memory_contentions`` audit table.

    Like :class:`SharedMemoryEndorsement`, a contention is a surfacing
    primitive. The :attr:`reason` is required and persisted so reviewers
    can adjudicate without chasing the contesting agent for context.
    """

    shared_memory_id: str
    contesting_agent_id: str
    reason: str
    contested_at: datetime


@dataclass(frozen=True)
class TeamInsight:
    """One row in the workspace ``team_insights`` table.

    Output of a Team Dream Phase 1 collective synthesis cycle. The
    :attr:`synthesis_prompt_hash` lets the caller dedupe re-runs of the
    same prompt against the same inputs; :attr:`contributor_count`
    captures how many distinct agents the synthesis drew from at the
    moment it ran.
    """

    id: str
    workspace_id: str
    content: str
    synthesis_prompt_hash: str
    contributor_count: int
    dream_cycle_id: str | None
    created_at: datetime
    archived_at: datetime | None


@dataclass(frozen=True)
class TeamInsightContribution:
    """One row in the workspace ``team_insight_contributions`` table.

    M-to-N link between a :class:`TeamInsight` and the
    :class:`SharedMemory` rows the synthesis cycle drew from. Carries
    :attr:`contribution_weight` so future weighting strategies (e.g.
    citation-graph PageRank) have a place to land without a migration.
    """

    team_insight_id: str
    shared_memory_id: str
    contributor_agent_id: str
    contribution_weight: float


@dataclass(frozen=True)
class CrossAgentProvenanceEvent:
    """One row in the workspace ``cross_agent_provenance_events`` log.

    Workspace-scoped, append-only by contract. The workspace backend
    exposes no UPDATE / DELETE method for the underlying table. Hash-
    chain tamper evidence (event_hash, prev_hash) is deferred to v1.3.0;
    the schema accepts a :attr:`parent_event_id` so chains can be
    reconstructed today via the parent edge.

    The :attr:`payload` is opaque to the SDK — event-type-specific
    callers (Studio dashboards, benchmark harness, audit narrators)
    interpret it. Keep payloads small (canonical IDs and the minimum
    metadata required to render a row), not full content blobs; the
    underlying memory rows are the source of truth for content.
    """

    event_id: str
    workspace_id: str
    event_type: str
    actor_agent_id: str | None
    target_agent_id: str | None
    entity_type: str
    entity_id: str
    parent_event_id: str | None
    payload: dict[str, Any]
    created_at: datetime


@dataclass(frozen=True)
class ProvenanceContribution:
    """One contributor's role in a team insight, as visible at the workspace boundary.

    Returned as part of :class:`TeamInsightProvenance`. Carries only the
    workspace-level metadata: the contributor's ``agent_id``, the
    ``shared_memory_id`` row in the pool, the ``source_memory_id``
    back-pointer into the contributor's per-agent backend, the
    ``shared_content`` (the *shared* version of the memory — what the
    contributor explicitly promoted to the pool), and the
    ``contribution_weight``.

    The ``source_memory_id`` is an opaque key into the contributor's
    own per-agent DB. The workspace SDK provides no method to resolve
    it into private memory content; only the contributor (who holds
    a handle to their own per-agent backend) can dereference it via
    their own ``agent.memory.get(memory_id)``. Compromising
    ``workspace.db`` never exposes any contributor's private memory
    content — this is the patent-defensible isolation invariant.
    """

    shared_memory_id: str
    contributor_agent_id: str
    source_memory_id: str
    shared_content: str
    contribution_weight: float


@dataclass(frozen=True)
class TeamInsightProvenance:
    """Result of :meth:`SharedMemoryPool.walk_provenance`.

    Carries the team insight and the list of contributing
    :class:`ProvenanceContribution` records. The contributions list is
    the *complete* boundary of what the workspace will surface for a
    team insight; there is intentionally no field for "private content
    from contributor X".

    To extend the walk into a contributor's private memory, the caller
    must be that contributor and must call ``agent.memory.get()`` on
    their own per-agent backend. The walk does not (and cannot) cross
    that boundary on the caller's behalf — the per-agent backend handle
    lives in the contributor's process, not in the workspace.
    """

    team_insight: TeamInsight
    contributions: list[ProvenanceContribution]


class XAgentEventType:
    """Canonical ``event_type`` values for cross-agent provenance events.

    Use these constants rather than string literals at call sites. The
    strings are part of the persisted log and must not change between
    versions; centralising them here makes that contract obvious and
    keeps dashboards / benchmarks compiling against a single source.

    Multi-B emits ``memory.*`` and ``team_insight.synthesized``. Multi-C
    extends with ``message.*`` events covering send / receive / reply
    and ``message.thread_closed`` for ``ThreadExitPolicy`` gates.
    """

    MEMORY_SHARED: str = "memory.shared"
    MEMORY_ENDORSED: str = "memory.endorsed"
    MEMORY_CONTESTED: str = "memory.contested"
    TEAM_INSIGHT_SYNTHESIZED: str = "team_insight.synthesized"
    MESSAGE_SENT: str = "message.sent"
    MESSAGE_RECEIVED: str = "message.received"
    MESSAGE_REPLIED: str = "message.replied"
    MESSAGE_THREAD_CLOSED: str = "message.thread_closed"


class MessagePurpose(StrEnum):
    """Discrete classifier for what an :class:`AgentMessage` is *for*.

    Pinned as an enum (not a free-form string) so the LLM tool schema
    can advertise the closed value set and so dashboards can group by
    purpose without string normalisation. Keep the surface tight: each
    new purpose multiplies the cardinality of every analytics view, so
    additions go through a release-note review, not ad-hoc.

    Members:
        QUESTION: Sender expects a substantive answer.
        INFORMATION: Sender is sharing context; no reply required.
        COORDINATION: Two-way: aligning on a shared piece of work.
        HANDOFF: Sender is transferring ownership; recipient now owns
            the next step. Distinct from COORDINATION because the next
            action lives squarely on the recipient.
    """

    QUESTION = "question"
    INFORMATION = "information"
    COORDINATION = "coordination"
    HANDOFF = "handoff"


class MessageStatus(StrEnum):
    """Lifecycle state of an :class:`AgentMessage`.

    Direct messages traverse PENDING → READ → REPLIED (or EXPIRED if
    the deadline lapses without a reply, or DECLINED if the recipient
    explicitly refuses). Broadcasts stay PENDING from the sender's
    perspective; per-recipient ack lives in ``broadcast_reads``.

    Members:
        PENDING: Sent but not yet acknowledged by the recipient.
        READ: Recipient has fetched the row via ``check_inbox()``.
        REPLIED: Recipient has sent a reply linked via ``in_reply_to``.
            Implies READ — there is no path to REPLIED that skips READ.
        EXPIRED: ``reply_deadline`` lapsed before the recipient replied.
            Set lazily by the SDK on inbox / thread reads, not by a
            background daemon.
        DECLINED: Recipient explicitly declined; reserved for a future
            ``decline_message(message_id, reason)`` surface.
    """

    PENDING = "pending"
    READ = "read"
    REPLIED = "replied"
    EXPIRED = "expired"
    DECLINED = "declined"


class ThreadCloseReason(StrEnum):
    """Why a :class:`message_threads` row was closed.

    Mirrors the gates inside :class:`ThreadExitPolicy`. ``MANUAL`` is
    reserved for application-side close calls that bypass the policy
    (operator override, workspace teardown). ``DEADLINE`` is set when
    the *thread's* aggregate deadline passes — distinct from a single
    message expiring its ``reply_deadline``.

    Members:
        MAX_TURNS: ``ThreadExitPolicy.max_turns`` ceiling tripped.
        STAGNATION: Cosine similarity over the last two message bodies
            crossed ``ThreadExitPolicy`` threshold.
        CONVERGENCE: LLM convergence judge concluded the thread had
            reached a conclusion.
        DEADLINE: Thread-level deadline lapsed.
        MANUAL: Operator / application-level close.
    """

    MAX_TURNS = "max_turns"
    STAGNATION = "stagnation"
    CONVERGENCE = "convergence"
    DEADLINE = "deadline"
    MANUAL = "manual"


@dataclass(frozen=True)
class AgentMessage:
    """One row in the workspace ``agent_messages`` table.

    Direct + broadcast messages live in the same table. Direct messages
    carry ``recipient_id`` and ``broadcast_capability is None``;
    broadcasts invert the pair (CHECK constraint enforces the XOR).
    Broadcast read state lives in :class:`broadcast_reads` because a
    single message can be read by N recipients; per-direct-message read
    state lives on this row.

    Threading: ``thread_id`` equals the root message's ``id``. Replies
    set ``in_reply_to = parent.id`` and inherit ``thread_id`` from the
    parent. ``reply_message_id`` on the parent points forward to the
    reply (set when the recipient replies).

    Fields:
        id: Stable workspace-scoped message id.
        workspace_id: The owning workspace.
        sender_id: ``agent_id`` of the agent that sent the message.
        recipient_id: For direct messages, the addressee's ``agent_id``.
            ``None`` for broadcasts; the broadcast recipient set is
            derived from ``broadcast_capability`` at read time.
        broadcast_capability: For broadcasts, the capability tag every
            recipient must carry. ``None`` for direct messages.
        content: The message body.
        purpose: Closed-set classifier (see :class:`MessagePurpose`).
        related_memory_ids: List of per-agent memory ids the sender
            references. Backends store the list as JSON; the SDK
            surface returns it as a real list.
        related_task_id: Optional pointer at a task in the workspace
            ``SharedTaskQueue`` (which lands in v1.3.0 — kept on the
            schema today so the migration cost is paid once).
        thread_id: Root message id of this conversation. Equal to
            :attr:`id` for the first message in a thread.
        in_reply_to: ``id`` of the message this is replying to.
            ``None`` for thread roots.
        expects_reply: Sender flag. The SDK does not enforce this
            (no auto-decline on a message with ``expects_reply=False``);
            it surfaces as a hint for the recipient agent's prompting.
        reply_deadline: Wall-clock deadline by which the sender wants
            a reply. ``None`` means no deadline.
        status: See :class:`MessageStatus`.
        read_at: Timestamp the recipient acknowledged the message via
            ``check_inbox()``. ``None`` while ``status == PENDING``.
        replied_at: Timestamp the recipient sent a reply. ``None``
            until the reply is sent.
        reply_message_id: Forward link to the reply. ``None`` until a
            reply is sent.
        created_at: Send timestamp.
    """

    id: str
    workspace_id: str
    sender_id: str
    recipient_id: str | None
    broadcast_capability: str | None
    content: str
    purpose: MessagePurpose
    related_memory_ids: list[str]
    related_task_id: str | None
    thread_id: str
    in_reply_to: str | None
    expects_reply: bool
    reply_deadline: datetime | None
    status: MessageStatus
    read_at: datetime | None
    replied_at: datetime | None
    reply_message_id: str | None
    created_at: datetime

    @property
    def is_broadcast(self) -> bool:
        """``True`` iff this message is a broadcast (no single recipient)."""
        return self.broadcast_capability is not None


@dataclass(frozen=True)
class ThreadClosedResult:
    """Result of a :class:`ThreadExitPolicy` evaluation.

    Returned by :meth:`MessageBus.evaluate_thread_exit` (and surfaced
    on :meth:`agent.messages.reply` when the gate trips). Carries the
    reason and a small bag of metadata describing the evidence — turn
    count, cosine similarity, judge verdict text — so callers can log
    or display *why* the thread closed without re-running the policy.

    Fields:
        thread_id: The closed thread.
        reason: Which gate tripped (see :class:`ThreadCloseReason`).
        closed_at: Timestamp the closure was recorded.
        turn_count: Number of messages in the thread at closure time.
            Always populated, regardless of which gate tripped — useful
            for analytics across reasons.
        similarity: Cosine similarity over the last two message bodies
            when the gate evaluated. ``None`` when the stagnation check
            did not run (max_turns or deadline tripped first).
        judge_verdict: Free-form judge output for ``CONVERGENCE``
            closures. ``None`` for other reasons.
    """

    thread_id: str
    reason: ThreadCloseReason
    closed_at: datetime
    turn_count: int
    similarity: float | None
    judge_verdict: str | None


class DerivedProvenanceEventType:
    """Per-agent provenance event types emitted *into* a contributor's own
    ``provenance_events`` table by the workspace.

    These rows live in the contributor's per-agent backend, not in
    ``cross_agent_provenance_events``. They exist so the contributor's
    own provenance walk can answer "what team-level outcomes did my
    private memory contribute to" without the per-agent backend ever
    holding a reference into another agent's private store.

    The reverse direction (team insight → contributing private memory)
    is the cross-agent walk; it terminates at the contributor's
    per-agent DB but never traverses *into* another agent's private
    content. This pair of one-way edges is the patent-defensible
    isolation contract.
    """

    TEAM_INSIGHT_DERIVED_FROM_YOU: str = "team.insight.derived_from_you"


__all__ = [
    "CONTENTION_WEIGHT",
    "ENDORSEMENT_WEIGHT",
    "AgentMessage",
    "CrossAgentProvenanceEvent",
    "DerivedProvenanceEventType",
    "MessagePurpose",
    "MessageStatus",
    "ProvenanceContribution",
    "SharedMemory",
    "SharedMemoryContention",
    "SharedMemoryEndorsement",
    "TeamInsight",
    "TeamInsightContribution",
    "TeamInsightProvenance",
    "ThreadCloseReason",
    "ThreadClosedResult",
    "Visibility",
    "XAgentEventType",
    "compute_team_score",
]
