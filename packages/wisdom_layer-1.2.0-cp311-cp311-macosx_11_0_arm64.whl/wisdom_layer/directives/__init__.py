"""Directive evolution — behavioral rules that persist and evolve."""
