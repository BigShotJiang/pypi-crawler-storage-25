"""Session context manager for the Wisdom Layer SDK.

Provides ``SessionHandle``, returned by ``agent.session()``. A session
tags all captures with a ``session_id`` and optionally runs in ephemeral
mode (no DB writes, no reinforcement, events still emitted, retrieval
unaffected).

Sessions are optional by default. ``require_session_for_capture`` must be
explicitly enabled in ``SessionConfig`` — bare ``agent.memory.capture()``
works without a session unless that flag is set.

Doc reference: ``01_memory_architecture.md`` §"Session Scoping",
``07_config_architecture.md`` §"SessionConfig",
``11_integration_ergonomics_resolutions.md`` §16.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime  # noqa: TC003  (public signature)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import TracebackType

    from wisdom_layer.agent import WisdomAgent

logger = logging.getLogger(__name__)


@dataclass
class SessionHandle:
    """Live session — returned by ``async with agent.session(...)``.

    Attributes:
        session_id: Unique identifier for this session.
        ephemeral: If True, captures are suppressed (no DB writes),
            reinforcement is skipped, but events still fire and
            search is unaffected.
        scope: Scope label written to captured memories (default ``long_term``).
        ttl_hours: TTL for session-scoped memories (0 = no expiry).
            **Advisory only in Phase A** — the value is persisted but no
            prune job enforces it yet. Enforcement lands with the TTL
            prune worker in a future slice.
    """

    session_id: str
    ephemeral: bool = False
    scope: str = "long_term"
    ttl_hours: int = 0
    _agent: WisdomAgent = field(repr=False, default=None)  # type: ignore[assignment]
    _active: bool = field(repr=False, default=False)

    async def capture(
        self,
        event_type: str,
        content: dict[str, object],
        *,
        emotional_intensity: float = 0.0,
        created_at: datetime | None = None,
    ) -> str:
        """Capture a memory within this session.

        If ephemeral, emits ``memory.capture_suppressed`` and returns
        an empty string instead of a memory ID. No DB write occurs.

        Args:
            event_type: Category of event.
            content: Event payload.
            emotional_intensity: Optional emotional weight (0.0–1.0).
            created_at: Optional timestamp override. See
                :meth:`MemoryInterface.capture` for the full contract;
                same validation rules apply (must be tz-aware, in the
                past, within the last 10 years). Default ``None`` stamps
                the memory with the agent's clock now.

        Returns:
            Memory ID, or empty string if ephemeral.

        Raises:
            ValueError: If ``created_at`` is naive, in the future, or
                older than the supported historical bound.
        """
        if not self._active:
            msg = "Session is not active. Use 'async with agent.session() as s:'."
            raise RuntimeError(msg)

        if created_at is not None:
            self._agent._validate_created_at(created_at)

        if self.ephemeral:
            await self._agent._emit(
                "memory.capture_suppressed",
                data={
                    "memory_type": event_type,
                    "reason": "ephemeral",
                    "session_id": self.session_id,
                },
            )
            return ""

        # Delegate to agent's memory capture with session metadata
        return await self._agent._session_capture(
            event_type=event_type,
            content=content,
            emotional_intensity=emotional_intensity,
            session_id=self.session_id,
            scope=self.scope,
            ttl_hours=self.ttl_hours,
            created_at=created_at,
        )

    async def search(
        self,
        query: str,
        *,
        limit: int = 5,
        min_salience: float = 0.0,
    ) -> list[dict[str, object]]:
        """Search memories. Retrieval is always allowed, even in ephemeral mode.

        Reinforcement is skipped in ephemeral mode.
        """
        if not self._active:
            msg = "Session is not active. Use 'async with agent.session() as s:'."
            raise RuntimeError(msg)

        results = await self._agent.memory.search(
            query, limit=limit, min_salience=min_salience
        )

        # In ephemeral mode, reinforcement was already skipped by the
        # memory_mode check OR we suppress it here via the session flag.
        # The MemoryInterface.search() respects memory_mode; ephemeral
        # sessions additionally suppress by not being in "learning" mode
        # for reinforcement purposes. This is handled in the agent layer.
        return results

    async def __aenter__(self) -> SessionHandle:
        """Enter the session context."""
        self._active = True
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit the session context."""
        self._active = False
