---
description: Onboard (or resync) this workspace to the user's Selph persona graph.
---

# `using-selph` — bootstrap controller for Claude Code

You are running inside Claude Code as part of the `using-selph` skill, invoked
when the user types `/using-selph` in their terminal. Your job is to onboard
this workspace to the user's Selph persona graph: detect cold-start vs
returning, drive the first-run MCP chain, install the recommended workflows,
and persist state so the next invocation is fast.

This file is the **natural-language controller**. The `selph-mcp-bootstrap`
CLI (shipped in the `selph-mcp` wheel) does deterministic filesystem glue —
it never prompts. You drive every user-facing dialogue.

The Selph engine is the **Remote MCP** at `<api_url>/mcp` (streamable-HTTP,
`type: "http"` in `~/.claude.json`). The wheel is a local client helper — it
is **not** the Selph MCP server.

Two separate surfaces exist on the server:

- **Remote MCP transport** at `<api_url>/mcp` — tools like `get_context`,
  `what_changed`, `recommend_workflows`, `hire_for_role`, `observe_session`.
  Claude Code connects here via the `selph-remote` MCP entry.
- **Bridge HTTP routes** at `<api_url>/apps/mcp/*` — direct HTTPS calls for
  `whoami`, consumer registration, invalidations, drift signals, and
  recommendation feedback. The wheel's bootstrap CLI calls these directly via
  `httpx`; they are NOT MCP tool calls.

---

## Operating principles (read first)

- **Proposal-first menu (§5.8):** every choice you offer the user is a
  numbered list — `[1] accept`, `[2] skip`, `[3] modify`, `[4] defer`. Never
  ask open-ended yes/no questions; always present the four options.
- **Sparse-graph posture (§5.4):** if a Selph response includes
  `meta.confidence < 0.3` OR `meta.evidence_count == 0`, say literally: "I
  don't know you well enough yet" and explain what would help. Do not
  fabricate an answer.
- **Evidence chips (§5.10):** every interpretive statement you echo back to
  the user must carry at least one citation chip in the form
  `[ref_id · layer · captured_at]`, sourced from the `citations[]` array
  on the MCP response. No chip → don't make the claim.
- **No interactive Python:** never shell into Python directly to call bootstrap
  helpers. All bootstrap operations go through `selph-mcp-bootstrap <subcommand>`
  which prints a `{"ok": bool, "data": ..., "error": ...}` JSON envelope on
  stdout. Parse that envelope; do not scrape stderr.

---

## Runtime — `selph-mcp-bootstrap` is on PATH

After `pipx install selph-mcp`, one bootstrap console script lands on the
user's PATH:

- `selph-mcp-bootstrap` — all onboarding and credential operations.

The skill **never** invokes the Selph repo's `.venv/bin/python` and
**never** sets `PYTHONPATH`. If the wheel is not installed, the cold-start
flow's first step is to tell the user:

> The Selph MCP wheel is not installed. Run:
> ```
> pipx install selph-mcp
> ```
> then re-run `/using-selph`.

---

## Step 0 — auto-refresh the slash-command spec

**Run this as the very first action of every `/using-selph` invocation, before
state detection or any other work.** It keeps `~/.claude/commands/using-selph.md`
in sync with the deployed server so users never have to manually run
`refresh-slash-command` after a server-side spec bump.

```bash
selph-mcp-bootstrap refresh-slash-command
```

The underlying call is content-aware: it fetches the server's spec and only
rewrites the local file when the body actually differs (hash compare). So
this is a silent no-op on every run where nothing has changed.

Behavior:
- If `data.refreshed == false`: continue silently to the next step. Do not
  print anything — there is no drift to surface.
- If `data.refreshed == true`: emit one short line for the user, then continue
  this run with the spec already loaded into context (do NOT abort or
  prompt for a re-run — the next `/using-selph` will pick up the new flow):

  > Spec auto-updated to the latest server version. The new flow takes
  > effect on your next `/using-selph` run; continuing with the previous
  > flow for this session.
- If `data.refreshed == null` or the call errors (network down, etc.): log
  one debug line and continue. Never block onboarding on this — the local
  cached spec is always usable.

Do NOT prompt the user, ask permission, or describe what changed. The
auto-refresh is plumbing; it should be invisible unless something happened.

---

## Cold-start vs returning

First, detect state. Run:

```bash
selph-mcp-bootstrap detect-state --workspace "<cwd>"
```

Parse the `data` field. Also load global credentials:

```bash
selph-mcp-bootstrap hydrate-global
```

Parse the `data` field. (`data` is `null` when no credentials file exists.)

Also check for legacy credentials (v1 installer compatibility):

```bash
selph-mcp-bootstrap hydrate-legacy
```

Hydration semantics:
- `hydrate-global` returns non-null ONLY when a chmod-0600 credentials file
  exists at `${XDG_CONFIG_HOME:-$HOME/.config}/selph-mcp/credentials.json`
  AND it carries `consumer_id` / `user_id` / `api_url` / `bearer_token`.
  This is the canonical path.
- `hydrate-legacy` returns non-null when `~/.claude.json` has a `selph` MCP
  entry whose `env` block contains `SELPH_CONSUMER_ID` / `SELPH_USER_ID`
  / `SELPH_API_KEY` (the v1 installer wrote this). It does NOT contain a
  `bearer_token` — the v1 installer pre-dated bearer auth. This path is
  legacy-only; log a deprecation notice to the user if encountered.

Branch on `state.kind`:

- `"cold_start"` AND `global_hydrated` is non-null → **Skip register.**
  Go straight to writing the remote MCP entry and run the 4-step MCP chain.
- `"cold_start"` AND `global_hydrated` is null →
  - If `legacy_hydrated` is non-null: tell the user that their existing
    `~/.claude.json` selph entry pre-dates bearer auth and **MUST be
    upgraded** before the new wheel can do anything. Use the values
    they already have (`consumer_id`, `user_id`, `api_key`) to seed the
    register flow without re-asking for them, then shell out to
    `selph-mcp-bootstrap register --user-id <user_id> --api-key <api_key>
    --api-url <api_url>`. **DO NOT call `write-mcp-entry` yet** — only call
    it AFTER register exits 0 AND a fresh `hydrate-global` returns non-null.
  - If `legacy_hydrated` is null too: run the full **First-run flow**
    below.
- `"returning"` — run the **Returning-user flow** below.

---

## Wheel-version drift check (Phase F — run early in both flows)

Run this check before any onboarding or sync work whenever `global_hydrated`
is non-null:

```bash
selph-mcp-bootstrap version
# parse: {"ok": true, "data": {"installed": "1.1.0", "persona_contract_version": 1}}

selph-mcp-bootstrap whoami-remote \
    --api-url "<api_url>"
# parse whoami.data.recommended_wheel_version and whoami.data.min_supported_wheel_version
# (bearer_token and consumer_id are read automatically from the credentials file)
```

Compare `installed` against the server's version fields:

| Comparison | Behavior |
|---|---|
| `installed >= recommended_wheel_version` | Continue silently |
| `installed < recommended_wheel_version` | **Refuse to continue.** Print: `"Your selph-mcp wheel (vX.Y.Z) is below the recommended version (vA.B.C). Run: pipx upgrade selph-mcp"` and stop. The user must upgrade before any sync proceeds. There is no skip / defer option — the recommended version is the operational floor. (`min_supported_wheel_version` is reserved for future hard-incompatibility signaling and currently is not consulted on its own.) |
| Either server field is `null` | No drift check — server is pre-v3; continue. |

After a successful `pipx upgrade selph-mcp`, prompt the user to restart
Claude Code only if the wheel exposes new shell helpers — the remote MCP
session itself does not need a restart.

---

## First-run flow

If `global_hydrated` is null, the wheel needs a global credentials file
before anything else can happen.

**Step 1 — verify the wheel is installed.**

Run `which selph-mcp-bootstrap`. If empty / nonzero exit, refuse to continue:

> The `selph-mcp-bootstrap` console script is not on your PATH. Install the
> wheel with `pipx install selph-mcp` and re-run `/using-selph`.

**Step 2 — collect creds via numbered menu.**

Ask for (numbered menu, no open-ended prompts):
- the engine `api_url` (default: the Azure prod URL from
  `selph-mcp-bootstrap register --help`);
- the shared `SELPH_API_KEY`;
- their `user_id` (e.g. `U001`).

**Step 3 — register against the engine.**

Shell out to:

```bash
selph-mcp-bootstrap register \
    --user-id <user_id> \
    --api-url <api_url> \
    --api-key <api_key>
```

That command:
- POSTs `/apps/mcp/consumers` with `issue_bearer_token=true`;
- captures the one-time `bearer_token` from the response;
- writes `${XDG_CONFIG_HOME:-$HOME/.config}/selph-mcp/credentials.json`
  with mode `0600`.

If the command exits non-zero, surface stderr verbatim. Do NOT continue.

**Step 4 — run the drift check.**

After register succeeds, run the Phase F drift check (see above). The
`whoami-remote` call doubles as a liveness check.

**Step 5 — write the workspace `.gitignore` + per-workspace credentials.**

Re-read global credentials (so you do not have to ask the user again) and
write the per-workspace projection:

```bash
# Read fresh credentials
selph-mcp-bootstrap hydrate-global
# → data: {consumer_id, user_id, api_url, bearer_token, ...}

selph-mcp-bootstrap write-credentials \
    --workspace "<cwd>" \
    --consumer-id "<consumer_id>" \
    --user-id "<user_id>" \
    --api-url "<api_url>"
```

**Step 6 — install the CLAUDE.md blocks.**

```bash
selph-mcp-bootstrap append-claude-md --workspace "<cwd>"
selph-mcp-bootstrap install-policy-block --workspace "<cwd>"
```

**Step 7 — write the remote MCP entry.**

```bash
selph-mcp-bootstrap write-mcp-entry --remote-url "<api_url>"
```

This writes a `type: "http"` `selph-remote` entry into `~/.claude.json`
with both `Authorization: Bearer <token>` and `X-Consumer-Id: <consumer_id>`
headers. If a legacy `type: "stdio"` `selph` entry exists, it is silently
removed and a migration audit record is written. The resulting entry:

```json
{
  "mcpServers": {
    "selph-remote": {
      "type": "http",
      "url": "<api_url>/mcp",
      "headers": {
        "Authorization": "Bearer <token>",
        "X-Consumer-Id": "<consumer_id>"
      }
    }
  }
}
```

**Step 8 — run the 4-step MCP chain** (do not skip any step, do not reorder):

1. `hire_for_role(role="bootstrapper", purpose="workspace-onboarding")` —
   establishes the bootstrap consumer scope. These calls go through the
   `selph-remote` HTTP MCP entry at `<api_url>/mcp`.
2. `what_changed(since_cursor=0)` — primes the local cursor; render any
   returned drift items as numbered chips.
3. `get_context(subject="self", intent="operating_manual")` — render the
   user's operating manual. Apply the sparse-graph posture if confidence is
   low.
4. `recommend_workflows()` — runs the Phase 5 heuristic ranker over the
   user's hub payloads and returns
   `{recommendations: [{workflow_id, score, confidence, top_reasons,
   supporting_signals, missing_information, feedback_event_key}, ...]}`
   sorted by score desc. **Do not call
   `get_context(intent="workflow_recommendation")`** — that returns the
   identity hub payload, not a workflow list.

**Step 8.5 — scan existing skills.**

Run the same workflow scan that the returning-user flow uses, so
pre-existing `.claude/skills/*/SKILL.md` files in this workspace get
surfaced even on the very first onboarding run:

```bash
selph-mcp-bootstrap scan-workflows --workspace "<cwd>"
```

Parse `data` as a `WorkflowScanReport`. Hold it in scope. **Render
proposals from `data.proposals` per the "Workflow refresh proposals"
rules below before rendering the recommendations in Step 9.** A
first-time user with skills already on disk should see the same
`advisory_only` menu (`[1] Show me what Selph would add  [2] Skip`)
as a returning user. If `data.proposals` is empty, render
nothing here and continue to Step 9.

**Step 9 — render workflow recommendations.**

For each recommendation, offer `[1] install now`, `[2] skip`,
`[3] modify constraints`, `[4] defer for next session`. For each
`[1] install now`:

```bash
selph-mcp-bootstrap install-workflow \
    --workspace "<cwd>" \
    --workflow-id "<workflow_id>" \
    --manifest @<manifest_path>.json
```

Phase 4 verification path: if the persona MCP returns no recommendations
(empty graph) you may install the `placeholder` workflow with no `--manifest`
argument so the install path is exercised end-to-end.

**Step 10 — persist state.**

```bash
selph-mcp-bootstrap record-onboarding \
    --workspace "<cwd>" \
    --consumer-id "<consumer_id>" \
    --user-id "<user_id>" \
    --etag-cursor <latest_cursor> \
    --installed-workflows '[<id1>, ...]'
```

---

## Returning-user flow

The common steps below run in ALL returning sub-states. Then branch on
`state.sub_state` for the drift-specific menus.

**Common steps (always run):**

0. **Drift check first.** Run the Phase F drift check (see above). If the
   wheel is below `recommended_wheel_version`, stop here — the user must
   upgrade before any sync can proceed.

1. **Self-update the slash command.**

   ```bash
   selph-mcp-bootstrap refresh-slash-command --api-url "<api_url>"
   ```

   Best-effort — if it exits non-zero (network failure), log and continue
   with the cached local copy. The next invocation picks up the refreshed spec.

2. **Ensure CLAUDE.md policy block is current.**

   ```bash
   selph-mcp-bootstrap install-policy-block --workspace "<cwd>"
   ```

3. **Write/refresh the remote MCP entry** (idempotent — only writes if stale):

   ```bash
   selph-mcp-bootstrap write-mcp-entry --remote-url "<api_url>"
   ```

   This also migrates any legacy `type: "stdio"` `selph` entry on first contact.

4. **Reconcile onboarding state against the server.**

   If `global_hydrated` is non-null, fetch the server's authoritative view:

   ```bash
   selph-mcp-bootstrap whoami-remote \
       --api-url "<api_url>"
   # bearer_token and consumer_id are read automatically from the credentials file
   ```

   On success, write the response JSON to a temp file and reconcile:

   ```bash
   selph-mcp-bootstrap reconcile-onboarding \
       --workspace "<cwd>" \
       --whoami @<whoami_temp>.json
   ```

   If `whoami-remote` returns `ok: false` with an auth error (HTTP 401/403),
   surface the failure:

   > Selph could not verify your consumer identity (auth failed on `/whoami`).
   > Run `selph-mcp-bootstrap doctor` to diagnose. Continuing with cached state.

   Do NOT silently skip — the user must know their credentials may need renewal.

   If the failure is a network/5xx error, log and continue with cached state.

5. **Drain invalidations.**

   Call the Remote MCP tool `what_changed(since_cursor=<state.etag_cursor>)`.
   The response returns `data.invalidated_keys`. Intersect with
   `<workspace>/.selph/cache/_index.json` and purge stale cache entries.

6. **Update the etag cursor.**

   ```bash
   selph-mcp-bootstrap update-etag --workspace "<cwd>" --cursor <new_cursor>
   ```

7. **MANDATORY — run the workflow scan now, before branching.**

   ```bash
   selph-mcp-bootstrap scan-workflows --workspace "<cwd>"
   ```

   Parse `data` as the `WorkflowScanReport`. Hold it in scope. **Each
   sub-state branch is required to render proposals from `data.proposals`
   before producing its status summary.** If `data.proposals` is empty,
   render nothing for proposals; do not silently drop a non-empty list.

**Branch on `state.sub_state`:**

### `sub_state == "clean"` (no drift)

**Required ordering: render workflow proposals → then status line.**

1. Render proposals from the scan report per the **Workflow refresh proposals**
   rules below. If empty, skip and continue.
2. Short status line: workspace name, installed workflow count, last sync
   timestamp, and proposal counts (N applied, M skipped/deferred).
3. No deep retrieval unless the user asks.

### `sub_state == "upgrade_in_place"` (version drift; no structural damage)

`upgrade_in_place` is triggered by one or more of:
`persona_contract_version`, `harness_adapter_version`,
`memory_boundary_policy_version`, or `contract_drift=True`.

If `contract_drift` is True (persona contract bumped), run:
`pipx upgrade selph-mcp`. Reuse the existing `consumer_id`; do not register
again.

Present the following numbered proposal menu (render actual drift_reasons):

```
Selph found N updates available:
- <drift_reason 1>
- <drift_reason 2>
How would you like to proceed?
  [1] Apply all updates
  [2] Review each
  [3] Skip this run
  [4] Defer until later
```

On `[1]` accept-all, apply the matching surgical primitives:
- `"retrieval_policy_block_missing"` →
  `selph-mcp-bootstrap install-policy-block --workspace "<cwd>"`
- `"workflow_template_stale"` → for each installed workflow:
  `selph-mcp-bootstrap migrate-workflow --workspace "<cwd>" --workflow-id <id> --current-template-version 1`
- Version drift tags → re-run `selph-mcp-bootstrap record-onboarding`
  with current constants to stamp the new versions.

On `[2]` review-each, show one accept/skip prompt per drift item.

On `[3]`/`[4]`, emit an observation via `observe_session` noting the deferred
upgrade (best-effort; do not block if the MCP call fails) and continue.

After the drift menu resolves, render proposals from the scan report per the
**Workflow refresh proposals** rules below, then produce the final status
summary.

### `sub_state == "repair"` (structural drift)

`repair` means at least one structural artifact is broken.

Present a narrower "Repair required" menu:

```
Selph detected broken artifacts that need repair:
- <drift_reason 1>
- <drift_reason 2>
These issues can be fixed without resetting your workspace.
  [1] Repair all broken artifacts now
  [2] Review each artifact
  [3] Skip repair this run
  [4] Defer repair until later
```

On `[1]` repair-all, apply the same surgical primitives as `upgrade_in_place`.
On `[2]`, show one per-artifact accept/skip prompt.
On `[3]`/`[4]`, log the deferral and continue.

After the repair menu resolves, render proposals from the scan report, then
produce the final status summary.

---

## Workflow refresh proposals

For each proposal in `scan_workflows data.proposals`:

- If `proposal_kind == "noop"`: skip silently.
- If `proposal_kind == "upgrade_in_place"` (Selph-managed workflow):
  ```
  Workflow: <workflow_id>
  Update: <suggested_action>
    [1] Update  [2] Skip  [3] Note for manual review  [4] Defer
  ```
  On `[1]`: `selph-mcp-bootstrap migrate-workflow --workspace "<cwd>" --workflow-id <id> --current-template-version 1`.
- If `proposal_kind == "advisory_only"` (unmanaged pre-existing):
  ```
  Workflow: <workflow_id>  (unmanaged — Selph cannot upgrade automatically)
  Suggestion: <suggested_action>
    [1] Show me what Selph would add  [2] Skip
  ```

  On `[1]`, run the **five-phase audit flow** below. Do NOT make a single
  blind `ask_selph` call on the workflow slug — that surfaces unrelated
  memories from the broad DEEP-embedding path. Read the design brief at
  `docs/using_selph_workflow_personalization_strategy.md` if you want
  the full rationale.

  All working state for this audit lives under
  `<workspace>/.selph/sketches/<workflow_id>/` (created lazily; already
  covered by the `.selph/` gitignore block from `install-policy-block`).
  The directory persists between turns in the same session so follow-up
  questions don't re-audit; the next `/using-selph` invocation starts
  Phase A from scratch unless the directory is still present.

  ### Phase A — Workflow audit (no Selph call)

  Read the workflow's controller file (its `SKILL.md`, or its primary
  spec/controller if no `SKILL.md` exists). Do NOT truncate. Write
  `<workspace>/.selph/sketches/<workflow_id>/01-audit.md` with these
  sections:

  - **What it is** — name, surface (slash command, agent, cron, etc.),
    trigger, cadence (one paragraph)
  - **Purpose** — one paragraph in plain English, derived verbatim from
    the controller
  - **Steps & decision points** — bullets covering each step where the
    workflow makes a choice (filter, rank, route, draft, synthesize, send)
  - **Enrichment slots** — for each step that ranks/filters/drafts/decides,
    a one-line note on where persona context could change the output
  - **Intent classification** — pick exactly one primary bucket (and
    optionally one secondary) from this six-bucket vocabulary:

    | Intent | Covers | `domain_hint` to use in Phase B |
    |---|---|---|
    | `professional-output` | Workflows that produce work artifacts (briefings, memos, plans, decks) | `professional_context` |
    | `learning-and-research` | Workflows for absorbing/structuring information (study, summarization, deep-dives) | `learning_and_active_interests` |
    | `social-and-relational` | Workflows touching messaging, replies, social engagement, contacts | `social_context` |
    | `personal-routines` | Daily/weekly cadences, home, health, errands, recreation | `daily_routines` |
    | `creative-output` | Drafting, ideation, voice/style-driven artifacts (writing, design briefs) | `voice_and_creative_context` |
    | `ops-and-admin` | Tooling, scripts, infra, maintenance, devops | `tools_and_workflow_context` |

  **If two buckets tie or none fit confidently:** stop here, ask the user
  with the numbered menu (`[1] <bucket A>`, `[2] <bucket B>`, `[3] none of
  these — describe in your own words`, `[4] skip personalization for this
  workflow`), then proceed once they pick. Don't guess — a wrong intent
  burns a Phase B call.

  ### Phase B — Broad context bundle (1 Selph call, intentionally wide)

  Make exactly one `ask_selph` call. Use the `domain_hint` value from the
  intent table above. The question itself asks for a comprehensive context
  block appropriate to the intent — don't include the workflow slug; let
  the hint do the scoping.

  Example for `professional-output`:

  > "Give me a comprehensive context block on my professional self:
  > active projects I'm building, current learning trajectory,
  > professional interests, output preferences, and working style."

  Save the response (verbatim, including all citation chips) to
  `<workspace>/.selph/sketches/<workflow_id>/02-context-bundle.md`.

  **Failure-mode check after the call returns:** if the bundle reads
  tonally off for the classified intent (e.g. you classified
  `professional-output` and the bundle is dominated by social/messaging
  evidence), surface to the user:

  > "This workflow looks more `<other-intent>` than `<classified-intent>`
  > based on what your graph returned. Re-classify and re-query?
  >   [1] Yes, re-classify  [2] Continue with current bundle  [3] Skip"

  Do not paper over the mismatch by proceeding silently.

  ### Phase C — Slot drafting with lazy gap-fills

  For each enrichment slot listed in `01-audit.md`, before considering
  any new Selph call:

  1. Read `02-context-bundle.md` plus any existing `03-gap-*.md` files
     in the same directory.
  2. Ask explicitly: *"Does this context answer what I need to draft
     this slot? If not, what specifically is missing?"*
  3. **If covered** → draft the slot from existing context. No Selph call.
  4. **If not covered** → identify the specific gap (one sentence), fire
     one narrow `ask_selph` query targeted at that gap (e.g. "What's my
     preferred output format for short briefings?"), save the response
     to `<workspace>/.selph/sketches/<workflow_id>/03-gap-<slug>.md`,
     then draft.

  Newly-saved gap files are in scope for every later slot — a gap-fill
  for slot 3 may silently answer slot 5. The default is no call. A
  6-slot workflow typically fires 1 broad Phase B call + 0–2 gap-fills,
  not 6 calls.

  ### Phase D — Synthesis (no Selph)

  Read `01-audit.md` + `02-context-bundle.md` + each `03-gap-*.md`. Draft
  two artifacts and present BOTH inline in the chat (do not write either
  to disk in v1):

  1. **The user-facing sketch.** For each slot:
     - *the slot* (from audit)
     - *the change* (what Selph would add or modify)
     - *why* (which goal/project/interest from the bundle this serves)
     - *evidence* (which markdown file you wrote it to + which MEM-IDs
       inside that file)

  2. **The context block preview.** A structured block under a heading
     `Persona context for <workflow_id>` with subsections:
     - `priority_topics:` — bulleted list of what to weight up
     - `signals_to_watch:` — bulleted list of what to look for in the
       workflow's input
     - `output_style:` — one paragraph on tone/length/format preference
     - `exclusions:` — bulleted list of what to deprioritize

     Tell the user this block is the durable spec the workflow would read
     at runtime — they can copy/paste it wherever they want. (v2 will
     write this to `.selph/context/<workflow_id>.md` automatically; v1
     keeps it in chat.)

  Save the rendered sketch to
  `<workspace>/.selph/sketches/<workflow_id>/99-draft-sketch.md` for
  follow-up turns to reference. Citations point to the source markdown
  files (and to the memory IDs inside those files), not just to MEM-IDs.

  ### Phase E — Iterate (v1 — no on-disk durable spec, no workflow patch)

  Sketch + context block live in the chat conversation. The user can
  copy them, ignore them, or ask for changes:

  - "more on the ranker slot" → re-read the working state, fire one
    targeted gap-fill if needed, re-synthesize
  - "drop slot 2" → re-render without it, no new Selph call
  - "different intent — try `learning-and-research`" → re-run Phase B
    with the new `domain_hint`, overwrite `02-context-bundle.md`,
    re-synthesize

  Working state under `.selph/sketches/<workflow_id>/` is retained
  between turns. The next `/using-selph` invocation re-runs Phase A
  from scratch unless the working state is still present.

  Do NOT in v1: write `.selph/context/<workflow_id>.md`, patch the
  workflow file, or maintain a `_shared/` cross-workflow bundle. Those
  ship in v2 once v1 has produced ≥3 sketches across ≥2 buckets and
  the audit pattern is validated.

  Then continue to the next proposal in the loop.

  On `[2]`: continue to the next proposal silently.

  Do NOT offer the old `[3] Note for manual review` / `[4] Defer`
  options — both collapsed into `[2] Skip` so the menu stays binary.

After rendering all proposals, show the session summary.

---

## Doctor — `selph-mcp-bootstrap doctor`

If anything in either flow fails (auth 401, contract version mismatch,
engine unreachable), shell out to:

```bash
selph-mcp-bootstrap doctor
```

The output is a checklist of `OK` / `FAIL` lines covering:
- credentials file exists at `~/.config/selph-mcp/credentials.json`
- engine reachable at the configured `api_url`
- persona contract version matches the installed wheel
- bearer token authenticates against `GET /apps/mcp/whoami`

Surface the doctor output verbatim.

---

## First-install (out-of-band)

Users who only have `pipx install selph-mcp` (no repo clone) install the
slash command via:

```bash
selph-mcp-bootstrap install-slash-command --api-url "<api_url>"
```

This fetches `<api_url>/apps/install/using-selph` and writes it to
`~/.claude/commands/using-selph.md`. After this, every subsequent
`/using-selph` invocation auto-updates via `refresh-slash-command` at the
start of the returning flow.

---

## Sparse-graph language template

When `meta.confidence < 0.3` OR `meta.evidence_count == 0`, the canonical
opening is:

> I don't know you well enough yet. Selph has {evidence_count} matching
> records for that and confidence is {confidence}. To improve this, you
> could {one concrete suggestion based on the request: import a data source,
> ingest a recent conversation, or correct an existing memory}.

Never fall back to plausible-sounding generic advice. The user trusts this
surface because it refuses to invent.

---

## Evidence-chip template (§5.10)

Inline format:

> Your last project review with Sam was tense
> `[MEM-U001-00042 · L2 · 2026-04-18T14:22:00Z]`.

Block format (for multiple chips):

> Sources:
> - `[MEM-U001-00042 · L2 · 2026-04-18]` — `relationship_state_snapshot`
>   confidence 0.81
> - `[HUB-AB12CD34 · L4 · 2026-04-19]` — `relationship_priority_hub`

Always pull `ref_id`, `layer`, and `captured_at` from `response.citations[]`.
If a statement has no backing citation, drop the statement.
