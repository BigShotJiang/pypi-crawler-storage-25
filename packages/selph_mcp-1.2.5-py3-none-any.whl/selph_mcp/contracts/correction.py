"""Correction payload (`correction_payload_v1`).

Implements §3.4 of the implementation plan. Persona `correct(...)` MUST
compile 1:1 to a concrete kernel op via the table embedded in
`CorrectionAction`'s docstring. Any `action × target_type` cell that is
empty blocks the feature on adding the corresponding kernel route — no
persona-side workaround is permitted.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class CorrectionTargetType(str, Enum):
    """What is being corrected."""

    entity_field_observation = "entity_field_observation"
    memory = "memory"
    identity_claim = "identity_claim"
    recommendation = "recommendation"


class CorrectionAction(str, Enum):
    """Persona-layer correction verb.

    Persona → kernel compile table (§3.4 of the implementation plan):

    | Persona action          | Persona target_type           | Kernel route                          | Kernel op           |
    |-------------------------|-------------------------------|---------------------------------------|---------------------|
    | replace                 | entity_field_observation      | POST /api/corrections/entity-field    | replace             |
    | retract                 | entity_field_observation      | POST /api/corrections/entity-field    | retract             |
    | expire                  | entity_field_observation      | POST /api/corrections/entity-field    | expire              |
    | reattribute             | entity_field_observation      | POST /api/corrections/entity-field    | reattribute         |
    | replace                 | memory                        | POST /api/corrections/memory          | replace_field       |
    | retract                 | memory                        | POST /api/corrections/memory          | retract             |
    | expire                  | memory                        | POST /api/corrections/memory          | expire              |
    | reinstate               | memory                        | POST /api/corrections/memory          | reinstate           |
    | reattribute             | memory                        | POST /api/corrections/memory          | reattribute_entity  |
    | supersede               | memory or identity_claim      | NEW kernel route (Phase 3)            | supersede           |
    | reject_recommendation   | recommendation                | NEW kernel route (Phase 3)            | reject_recommendation |

    `supersede` and `reject_recommendation` do not exist in
    `correction_routes.py` today. Phase 3 of the implementation plan adds
    those kernel routes; until then, persona `correct(...)` calls using
    those actions must fail loudly rather than silently re-route to a
    different kernel op.
    """

    replace = "replace"
    retract = "retract"
    expire = "expire"
    reattribute = "reattribute"
    reinstate = "reinstate"
    supersede = "supersede"
    reject_recommendation = "reject_recommendation"


class ObservedIn(BaseModel):
    """Where the correction originated — consumer/harness/session triple."""

    model_config = ConfigDict(extra="forbid")

    consumer_id: str
    harness_id: str
    session_id: str


class CorrectionPayload(BaseModel):
    """Structured revision request from a persona consumer."""

    model_config = ConfigDict(extra="forbid")

    target_type: CorrectionTargetType
    target_id: str = Field(
        ...,
        description=(
            "What is being corrected: an `observation_id`, a `MEM-…` id, an "
            "`entity_id+field` composite, or a `feedback_event_key` for "
            "recommendation rejections."
        ),
    )
    action: CorrectionAction
    reason: str = Field(..., description="Human-readable rationale required for audit.")
    new_state: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Replacement payload — required for `replace`/`supersede`, optional otherwise.",
    )
    effective_at: Optional[datetime] = Field(
        default=None,
        description="ISO-8601 timestamp at which the correction takes effect.",
    )
    confidence_override: Optional[float] = Field(
        default=None,
        ge=0.0,
        le=1.0,
        description="Optional override for the post-correction confidence score.",
    )
    observed_in: ObservedIn


__all__ = [
    "CorrectionTargetType",
    "CorrectionAction",
    "ObservedIn",
    "CorrectionPayload",
]
