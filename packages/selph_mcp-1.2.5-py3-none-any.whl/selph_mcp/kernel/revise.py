"""Kernel ``revise`` adapter (Phase 1b §1, §3.4 compile table).

Dispatches a :class:`CorrectionPayload` from a persona consumer to the
correct kernel revision op per the §3.4 persona-to-kernel compile
table.

Compile table — every (action, target_type) pair the persona surface
may emit (Phase 3 complete — all 12 cells wired to live ops):

    | Persona action       | Persona target_type            | Kernel route       |
    |----------------------|--------------------------------|--------------------|
    | replace              | entity_field_observation       | revise()/CORRECT   |
    | retract              | entity_field_observation       | revise()/RETRACT   |
    | expire               | entity_field_observation       | efc.expire (manager) |
    | reattribute          | entity_field_observation       | efc.reattribute (manager) |
    | replace              | memory                         | revise()/CORRECT   |
    | retract              | memory                         | revise()/RETRACT   |
    | expire               | memory                         | revise()/REJECT    |
    | reinstate            | memory                         | revise()/ACCEPT    |
    | reattribute          | memory                         | mcm.reattribute_memory_entity (manager) |
    | supersede            | memory                         | revise()/SUPERSEDE |
    | supersede            | identity_claim                 | revise()/SUPERSEDE (target_type=identity_claim) |
    | reject_recommendation| recommendation                 | mcp_recommendation_feedback_manager.insert_feedback(outcome="rejected") |

Implementation note (deviation from brief)
------------------------------------------
The brief says "call corresponding correction-routes handler in-process",
but the import-linter ``mcp-surface-boundary`` contract forbids
``selph_mcp`` from importing ``ingestion_api``. The compile table
therefore targets the **Core** entry points the FastAPI route handlers
themselves wrap: :func:`selph_core.revise.revise` for
``revise()``-shaped ops, plus the two underlying
``selph_db.entity_field_correction_manager`` /
``selph_db.memory_correction_manager`` calls that
``correction_routes.py`` still calls directly today (``efc.expire``,
``efc.reattribute``, ``mcm.reattribute_memory_entity``). The kernel
behavior is identical because both the FastAPI route and this
adapter funnel through the same Core/manager surface.

Phase 3 implementation (2026-04-21)
-----------------------------------
``supersede`` (memory, identity_claim) now delegates to
:func:`selph_core.revise.revise` with :attr:`RevisionAction.SUPERSEDE`.
The memory handler maps SUPERSEDE → ``mcm.replace_memory_field`` (same
as CORRECT) under the hood; the identity_claim handler treats it as a
full-replacement revision (requires non-empty ``claim_text`` +
``claim_structured`` in ``new_state``).

``reject_recommendation`` writes to
``selph_recommendation_feedback`` via
:func:`selph_db.mcp_recommendation_feedback_manager.insert_feedback`
with ``outcome="rejected"``. It does NOT touch the persona graph —
rejection is a signal for the Phase 5 ranker, not a revision. Symmetric
with the Phase 3 ``recommendation_feedback(outcome="rejected")`` persona
tool; both paths share the same idempotent ``ON CONFLICT DO NOTHING``
insert.

After every successful dispatch the kernel emits the matching etag
invalidation row(s) via
:func:`selph_mcp.persona.etag.emit_invalidations`. Invalidation writes
are non-fatal (logged at WARNING on failure) so primary revisions
stay durable even when the invalidation log is temporarily unavailable.
"""
from __future__ import annotations

import logging
import time as _time
from typing import Any, Dict, Optional

from fastapi import HTTPException, status

from selph_mcp._client import EngineUpstreamError, RevisionTargetNotFoundError, get_client
from selph_mcp.adapters.engine import EngineAdapter, HttpEngineAdapter
from selph_mcp.contracts.consumer import Consumer
from selph_mcp.contracts.correction import (
    CorrectionAction,
    CorrectionPayload,
    CorrectionTargetType,
)
from selph_mcp.persona.etag import emit_invalidations
from selph_mcp._log import get_logger, log_event

_log = get_logger("selph_mcp.kernel.revise")


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_user_id(
    *,
    consumer: Consumer,
    payload_user_id: Optional[str],
) -> str:
    """Apply the §3.5.1 consumer-to-user binding."""
    if not payload_user_id:
        return consumer.user_id
    if payload_user_id != consumer.user_id:
        log_event(
            _log, logging.WARNING, "mcp.kernel.revise.user_binding_violation",
            consumer_id=consumer.consumer_id,
            consumer_user_id=consumer.user_id,
            payload_user_id=payload_user_id,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "Payload user_id does not match the consumer-bound user_id."
            ),
        )
    return payload_user_id


def _initiated_by(consumer: Consumer) -> str:
    """Stable consumer attribution for ``RevisionRequest.initiated_by``."""
    return f"consumer:{consumer.consumer_id}"


def _audit_manager_result(data: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize the engine revise response to the persona surface shape."""
    return data


# ─────────────────────────────────────────────────────────────────────────────
# Dispatcher arms — one per compile-table cell, all via HTTP to the engine
# ─────────────────────────────────────────────────────────────────────────────

async def _entity_field_replace(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    if payload.new_state is None or "value" not in payload.new_state:
        raise HTTPException(
            status_code=400,
            detail="`new_state.value` is required for replace × entity_field_observation.",
        )
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    return await _eng.post("/core/revise/", json={
        "user_id": user_id,
        "target_type": "entity_field",
        "target_id": payload.target_id,
        "action": "CORRECT",
        "new_value": {"value": payload.new_state["value"]},
        "reason": payload.reason,
        "evidence_ids": [],
        "initiated_by": _initiated_by(consumer),
    })


async def _entity_field_retract(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    return await _eng.post("/core/revise/", json={
        "user_id": user_id,
        "target_type": "entity_field",
        "target_id": payload.target_id,
        "action": "RETRACT",
        "new_value": None,
        "reason": payload.reason,
        "evidence_ids": [],
        "initiated_by": _initiated_by(consumer),
    })


async def _entity_field_expire(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
) -> Dict[str, Any]:
    try:
        observation_id = int(payload.target_id)
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=(
                "expire × entity_field_observation requires a numeric "
                "observation_id in target_id."
            ),
        ) from exc
    return await get_client().post(
        f"/apps/correction/corrections/entity-field/{observation_id}/expire",
        json={"user_id": user_id, "reason": payload.reason, "actor_id": _initiated_by(consumer)},
    )


async def _entity_field_reattribute(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
) -> Dict[str, Any]:
    if not payload.new_state or not payload.new_state.get("destination_entity_id"):
        raise HTTPException(
            status_code=400,
            detail=(
                "reattribute × entity_field_observation requires "
                "`new_state.destination_entity_id`."
            ),
        )
    try:
        observation_id = int(payload.target_id)
    except (TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=400,
            detail=(
                "reattribute × entity_field_observation requires a numeric "
                "observation_id in target_id."
            ),
        ) from exc
    return await get_client().post(
        f"/apps/correction/corrections/entity-field/{observation_id}/reattribute",
        json={
            "user_id": user_id,
            "destination_entity_id": payload.new_state["destination_entity_id"],
            "reason": payload.reason,
            "actor_id": _initiated_by(consumer),
        },
    )


async def _memory_replace(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    if (
        payload.new_state is None
        or "field_path" not in payload.new_state
        or "value" not in payload.new_state
    ):
        raise HTTPException(
            status_code=400,
            detail="replace × memory requires `new_state.field_path` and `new_state.value`.",
        )
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    return await _eng.post("/core/revise/", json={
        "user_id": user_id,
        "target_type": "memory",
        "target_id": payload.target_id,
        "action": "CORRECT",
        "new_value": {
            "field_path": payload.new_state["field_path"],
            "value": payload.new_state["value"],
        },
        "reason": payload.reason,
        "evidence_ids": [],
        "initiated_by": _initiated_by(consumer),
    })


async def _memory_retract(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    return await _eng.post("/core/revise/", json={
        "user_id": user_id,
        "target_type": "memory",
        "target_id": payload.target_id,
        "action": "RETRACT",
        "new_value": None,
        "reason": payload.reason,
        "evidence_ids": [],
        "initiated_by": _initiated_by(consumer),
    })


async def _memory_expire(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    return await _eng.post("/core/revise/", json={
        "user_id": user_id,
        "target_type": "memory",
        "target_id": payload.target_id,
        "action": "REJECT",
        "new_value": None,
        "reason": payload.reason,
        "evidence_ids": [],
        "initiated_by": _initiated_by(consumer),
    })


async def _memory_reinstate(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    return await _eng.post("/core/revise/", json={
        "user_id": user_id,
        "target_type": "memory",
        "target_id": payload.target_id,
        "action": "ACCEPT",
        "new_value": None,
        "reason": payload.reason,
        "evidence_ids": [],
        "initiated_by": _initiated_by(consumer),
    })


async def _memory_reattribute(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
) -> Dict[str, Any]:
    if (
        not payload.new_state
        or "old_entity_id" not in payload.new_state
        or "new_entity_id" not in payload.new_state
    ):
        raise HTTPException(
            status_code=400,
            detail=(
                "reattribute × memory requires `new_state.old_entity_id` "
                "and `new_state.new_entity_id`."
            ),
        )
    return await get_client().post(
        f"/apps/correction/corrections/memory/{payload.target_id}/reattribute",
        json={
            "user_id": user_id,
            "old_entity_id": payload.new_state["old_entity_id"],
            "new_entity_id": payload.new_state["new_entity_id"],
            "reason": payload.reason,
            "actor_id": _initiated_by(consumer),
        },
    )


# ─────────────────────────────────────────────────────────────────────────────
# Phase 3 arms
# ─────────────────────────────────────────────────────────────────────────────

async def _memory_supersede(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    if (
        payload.new_state is None
        or "field_path" not in payload.new_state
        or "value" not in payload.new_state
    ):
        raise HTTPException(
            status_code=400,
            detail="supersede × memory requires `new_state.field_path` and `new_state.value`.",
        )
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    return await _eng.post("/core/revise/", json={
        "user_id": user_id,
        "target_type": "memory",
        "target_id": payload.target_id,
        "action": "SUPERSEDE",
        "new_value": {
            "field_path": payload.new_state["field_path"],
            "value": payload.new_state["value"],
        },
        "reason": payload.reason,
        "evidence_ids": [],
        "initiated_by": _initiated_by(consumer),
    })


async def _identity_claim_supersede(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
    engine: Optional[EngineAdapter] = None,
) -> Dict[str, Any]:
    ns = payload.new_state or {}
    claim_text = ns.get("claim_text")
    claim_structured = ns.get("claim_structured")
    if not claim_text or not str(claim_text).strip():
        raise HTTPException(
            status_code=400,
            detail="supersede × identity_claim requires a non-empty `new_state.claim_text`.",
        )
    if not claim_structured or (
        isinstance(claim_structured, (list, dict, str)) and not claim_structured
    ):
        raise HTTPException(
            status_code=400,
            detail="supersede × identity_claim requires a non-empty `new_state.claim_structured` payload.",
        )
    _eng: EngineAdapter = engine if engine is not None else HttpEngineAdapter(get_client())
    return await _eng.post("/core/revise/", json={
        "user_id": user_id,
        "target_type": "identity_claim",
        "target_id": payload.target_id,
        "action": "SUPERSEDE",
        "new_value": dict(ns),
        "reason": payload.reason,
        "evidence_ids": [],
        "initiated_by": _initiated_by(consumer),
    })


async def _recommendation_reject(
    *, user_id: str, payload: CorrectionPayload, consumer: Consumer,
) -> Dict[str, Any]:
    target_id = (payload.target_id or "").strip()
    if not target_id:
        raise HTTPException(
            status_code=400,
            detail=(
                "reject_recommendation × recommendation requires a "
                "non-empty `feedback_event_key` in target_id."
            ),
        )
    try:
        return await get_client().post(
            "/apps/correction/corrections/recommendation-feedback",
            json={
                "feedback_event_key": target_id,
                "consumer_id": consumer.consumer_id,
                "user_id": user_id,
                "outcome": "rejected",
                "notes": payload.reason,
            },
        )
    except EngineUpstreamError as exc:
        if exc.status_code == 400:
            raise HTTPException(status_code=400, detail=exc.body[:300]) from exc
        raise
    return {
        "status": "ok",
        "channel": "recommendation_feedback",
        "feedback_event_key": target_id,
        "outcome": "rejected",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Public dispatcher
# ─────────────────────────────────────────────────────────────────────────────

# Compile-table key: (action, target_type) → handler coroutine.
# Stored as a constant so a missing pair surfaces as a single 400.
# Phase 3 (2026-04-21): supersede (memory + identity_claim) and
# reject_recommendation moved from the former _PHASE3_TABLE into
# _DISPATCH_TABLE as live ops.
_DISPATCH_TABLE = {
    (CorrectionAction.replace, CorrectionTargetType.entity_field_observation): _entity_field_replace,
    (CorrectionAction.retract, CorrectionTargetType.entity_field_observation): _entity_field_retract,
    (CorrectionAction.expire, CorrectionTargetType.entity_field_observation): _entity_field_expire,
    (CorrectionAction.reattribute, CorrectionTargetType.entity_field_observation): _entity_field_reattribute,
    (CorrectionAction.replace, CorrectionTargetType.memory): _memory_replace,
    (CorrectionAction.retract, CorrectionTargetType.memory): _memory_retract,
    (CorrectionAction.expire, CorrectionTargetType.memory): _memory_expire,
    (CorrectionAction.reinstate, CorrectionTargetType.memory): _memory_reinstate,
    (CorrectionAction.reattribute, CorrectionTargetType.memory): _memory_reattribute,
    (CorrectionAction.supersede, CorrectionTargetType.memory): _memory_supersede,
    (CorrectionAction.supersede, CorrectionTargetType.identity_claim): _identity_claim_supersede,
    (CorrectionAction.reject_recommendation, CorrectionTargetType.recommendation): _recommendation_reject,
}


# ─────────────────────────────────────────────────────────────────────────────
# Post-dispatch etag invalidation mapping (Phase 3)
# ─────────────────────────────────────────────────────────────────────────────

def _invalidation_event_for(cell: tuple) -> Optional[str]:
    """Map a ``(action, target_type)`` cell to the Phase-3 etag event kind.

    Returns ``None`` when the cell should NOT emit an invalidation row
    (currently every cell does emit one, but the helper leaves room for
    future opt-outs without rewiring the dispatcher).
    """
    action, target_type = cell
    if target_type == CorrectionTargetType.entity_field_observation:
        return "entity_field_correction"
    if target_type == CorrectionTargetType.memory:
        return "memory_correction"
    if target_type == CorrectionTargetType.identity_claim:
        return "identity_claim_correction"
    if action == CorrectionAction.reject_recommendation:
        return "recommendation_rejection"
    return None


def _invalidation_target_for(payload: CorrectionPayload) -> Optional[str]:
    """Extract the ``target_id`` to embed in the ``kind_prefix`` when the
    Phase-3 event mapping wants one.

    For entity-field + memory corrections the persona-side target_id is a
    memory id / observation id. The mapping in
    :func:`selph_mcp.persona.etag._invalidation_prefixes` uses it to
    narrow ``entity:{target_id}:*`` — when absent the mapping falls back
    to ``entity:*`` (whole-persona invalidation).
    """
    if payload.target_id and payload.target_id.strip():
        return payload.target_id
    return None


async def revise(
    *,
    consumer: Consumer,
    payload: CorrectionPayload,
    user_id: Optional[str] = None,
    engine: Optional[EngineAdapter] = None,
    mcp_transport: str = "stdio",
) -> Dict[str, Any]:
    """Dispatch a persona-layer :class:`CorrectionPayload` to the kernel.

    Returns the underlying manager result for every executed cell. After
    a successful dispatch the kernel emits the matching etag
    invalidation row(s) via
    :func:`selph_mcp.persona.etag.emit_invalidations`; invalidation
    failures are logged at WARNING and never abort the primary revision.

    Phase 3 (2026-04-21): all 12 compile-table cells are live; there is
    no longer a ``not_yet_implemented`` path.

    Args:
        consumer: Authenticated consumer (binding source).
        payload: The structured persona correction request.
        user_id: Optional caller-supplied user_id; must match
            ``consumer.user_id`` when present.

    Raises:
        HTTPException(400): unmapped (action, target_type) pair OR
            handler-level bad request (missing required ``new_state``
            fields).
        HTTPException(401): consumer/user binding violation.
        HTTPException(404): unknown user_id OR target row missing.
        HTTPException(500): unexpected failure.
    """
    t0 = _time.perf_counter()
    resolved_user_id = _resolve_user_id(consumer=consumer, payload_user_id=user_id)

    log_event(
        _log, logging.INFO, "mcp.kernel.revise.entry",
        consumer_id=consumer.consumer_id,
        user_id=resolved_user_id,
        action=payload.action.value,
        target_type=payload.target_type.value,
        target_id=payload.target_id,
        mcp_transport=mcp_transport,
    )

    cell = (payload.action, payload.target_type)
    handler = _DISPATCH_TABLE.get(cell)
    if handler is None:
        log_event(
            _log, logging.WARNING, "mcp.kernel.revise.invalid_cell",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            action=payload.action.value,
            target_type=payload.target_type.value,
        )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"invalid action × target_type: "
                f"({payload.action.value}, {payload.target_type.value})"
            ),
        )

    try:
        # Every dispatcher arm is async — revise()-backed handlers await
        # the Core syscall directly, manager-direct arms wrap the sync
        # call with `loop.run_in_executor` so the event loop stays free.
        # Arms that call /core/revise/ accept engine=; arms that call
        # /apps/correction/* (expire, reattribute, recommendation_reject)
        # MUST stay on HTTP to preserve the ENABLE_CORRECTION_LAYER gate.
        import inspect as _inspect
        _handler_sig = _inspect.signature(handler)
        if "engine" in _handler_sig.parameters:
            result = await handler(
                user_id=resolved_user_id, payload=payload, consumer=consumer,
                engine=engine,
            )
        else:
            result = await handler(
                user_id=resolved_user_id, payload=payload, consumer=consumer,
            )
    except RevisionTargetNotFoundError as exc:
        log_event(
            _log, logging.WARNING, "mcp.kernel.revise.target_not_found",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            action=payload.action.value,
            target_type=payload.target_type.value,
            target_id=payload.target_id,
            error=str(exc),
        )
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except EngineUpstreamError as exc:
        if exc.status_code == 404:
            log_event(
                _log, logging.WARNING, "mcp.kernel.revise.target_not_found",
                consumer_id=consumer.consumer_id,
                user_id=resolved_user_id,
                action=payload.action.value,
                target_type=payload.target_type.value,
                target_id=payload.target_id,
                error=str(exc),
            )
            raise HTTPException(status_code=404, detail=exc.body[:300]) from exc
        status_code = exc.status_code if exc.status_code in (400, 422) else 500
        raise HTTPException(status_code=status_code, detail=exc.body[:300]) from exc
    except ValueError as exc:
        log_event(
            _log, logging.WARNING, "mcp.kernel.revise.bad_request",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            action=payload.action.value,
            target_type=payload.target_type.value,
            target_id=payload.target_id,
            error=str(exc),
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        log_event(
            _log, logging.ERROR, "mcp.kernel.revise.failed",
            consumer_id=consumer.consumer_id,
            user_id=resolved_user_id,
            action=payload.action.value,
            target_type=payload.target_type.value,
            target_id=payload.target_id,
            error_type=type(exc).__name__,
            error=str(exc)[:300],
        )
        raise HTTPException(
            status_code=500,
            detail=f"revise failed: {exc}",
        ) from exc

    # ── Post-dispatch etag invalidation (Phase 3, non-fatal) ─────────
    # Every successful revision emits the matching invalidation
    # row(s) so downstream reads bust their caches on the next call.
    # ``emit_invalidations`` is contractually non-fatal: exceptions
    # are swallowed + logged inside the helper, so a temporary
    # invalidation-log outage NEVER aborts the primary revision.
    event_kind = _invalidation_event_for(cell)
    if event_kind is not None:
        try:
            await emit_invalidations(
                consumer,
                event_kind,
                target_id=_invalidation_target_for(payload),
            )
        except Exception as exc:  # noqa: BLE001 — defence-in-depth
            log_event(
                _log, logging.WARNING, "mcp.kernel.revise.invalidation_failed",
                consumer_id=consumer.consumer_id,
                user_id=resolved_user_id,
                event_kind=event_kind,
                action=payload.action.value,
                target_type=payload.target_type.value,
                error_type=type(exc).__name__,
                error=str(exc)[:300],
            )

    duration_ms = round((_time.perf_counter() - t0) * 1000, 2)
    log_event(
        _log, logging.INFO, "mcp.kernel.revise.complete",
        consumer_id=consumer.consumer_id,
        user_id=resolved_user_id,
        action=payload.action.value,
        target_type=payload.target_type.value,
        target_id=payload.target_id,
        revision_id=(result or {}).get("revision_id") if isinstance(result, dict) else None,
        duration_ms=duration_ms,
        mcp_transport=mcp_transport,
    )
    return result


__all__ = ["revise"]
