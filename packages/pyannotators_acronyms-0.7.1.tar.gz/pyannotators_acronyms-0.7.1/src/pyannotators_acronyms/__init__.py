"""Annotator based on Spacy NER"""
__version__ = "0.7.1"
