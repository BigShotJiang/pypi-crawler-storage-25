"""Launcher for the packaged Retrace CPython executable."""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _runtime_root() -> Path:
    return Path(__file__).resolve().parent / "_runtime"


def _find_executable() -> Path:
    names = ("python.exe", "python")
    root = _runtime_root()
    for name in names:
        for path in root.rglob(name):
            if path.is_file():
                return path
    raise RuntimeError(f"no packaged CPython executable found under {root}")


def main() -> None:
    executable = _find_executable()
    env = os.environ.copy()
    env.setdefault("PYTHONHOME", sys.base_prefix)
    argv = [str(executable), *sys.argv[1:]]
    os.execvpe(str(executable), argv, env)


if __name__ == "__main__":
    main()
