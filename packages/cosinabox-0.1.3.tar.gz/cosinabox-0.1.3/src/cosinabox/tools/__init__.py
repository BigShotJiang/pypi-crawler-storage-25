"""Built-in tool catalog."""
