"""Schema migrations registry."""
