"""Scheduling poll check — 30-min cron that advances POLLING requests.

For each POLLING scheduling request:
  1. Fetch Gmail replies via ``coordinator.check_polling_status`` — that
     function parses and records any new responses.
  2. Use the consensus slot returned by ``check_polling_status`` (which
     calls ``find_consensus`` internally with fresh calendar re-score).
     If consensus exists, transition POLLING -> CONVERGED and notify owner.
  3. Otherwise, for each participant that still has not responded, compute
     the age of their outreach:
       - >= 24h since outreach_sent_at and status == 'sent' -> nudge
         (status becomes 'nudged'; no dedicated nudged_at column exists --
         the status flip guards against re-nudging).
       - >= 48h since outreach_sent_at -> expire (status 'no_response').
  4. If ALL non-responded participants have expired, transition POLLING ->
     OWNER_REVIEW and notify the owner.

Returns a summary string: e.g.
    "checked 3 requests, 1 converged, 2 nudged, 1 expired"
    or "skipped -- no active polls"

Notes for OSS users:
- ``send_fn(text)`` is a single callable; this job does not know about
  Telegram chat IDs. App wiring chooses where messages land.
- Nudge messages are plain text sent via ``send_fn``. Sending a Telegram
  DM directly to the participant is an app-level concern (Phase B M6).
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from cosinabox.jobs.base import Job
from cosinabox.scheduling import db as sched_db
from cosinabox.scheduling.coordinator import (
    InvalidTransition,
    check_polling_status,
    transition,
)
from cosinabox.scheduling.models import SchedulingStatus

logger = logging.getLogger(__name__)


_NUDGE_HOURS = 24
_EXPIRE_HOURS = 48
# Safety cap: if the bot was down through the nudge window, we still want to
# nudge once before expiring -- but not after 3 days (too stale to be useful).
_NUDGE_SAFETY_CAP_HOURS = 72


class SchedulingPollCheckJob(Job):
    name = "scheduling_poll_check"

    def __init__(
        self,
        *,
        ctx: Any,
        send_fn: Callable[[str], None],
    ) -> None:
        self.ctx = ctx
        self.send_fn = send_fn

    @property
    def db(self) -> Any:
        return self.ctx.db

    def _send_nudge(self, participant: Any, title: str, age_hours: float) -> None:
        """Send a nudge notification.

        When ``ctx.nudge_participants_directly`` is True and the participant
        has a channel-specific target (telegram_id or email), send the nudge
        directly to them via the appropriate adapter. Otherwise, fall back to
        ``send_fn`` (owner's DM).

        Either way, the owner always gets a summary via ``send_fn``.
        """
        nudge_text = (
            f"Scheduling nudge: {participant.name} hasn't responded to "
            f"'{title}' in {int(age_hours)}h. "
            "Consider reaching out directly."
        )

        if self.ctx.nudge_participants_directly:
            sent_direct = False
            if participant.channel == "telegram" and participant.telegram_id and self.ctx.bot:
                try:
                    self.ctx.bot.send_message(
                        chat_id=participant.telegram_id,
                        text=(
                            f"Friendly reminder: please respond to the "
                            f"scheduling poll for '{title}'."
                        ),
                    )
                    sent_direct = True
                except Exception:  # noqa: BLE001
                    logger.warning(
                        "Direct Telegram nudge failed for %s",
                        participant.name,
                        exc_info=True,
                    )
            elif participant.channel == "gmail" and participant.email and self.ctx.gmail:
                try:
                    self.ctx.gmail.compose_draft(
                        to=participant.email,
                        subject=f"Reminder: scheduling poll for '{title}'",
                        body=(
                            f"Hi {participant.name}, this is a friendly reminder "
                            f"to respond to the scheduling poll for '{title}'."
                        ),
                    )
                    sent_direct = True
                except Exception:  # noqa: BLE001
                    logger.warning(
                        "Direct Gmail nudge failed for %s",
                        participant.name,
                        exc_info=True,
                    )
            if sent_direct:
                nudge_text += " (direct nudge sent)"

        self.send_fn(nudge_text)

    def run(self, context: Any = None) -> str:
        active = sched_db.get_active_requests(
            self.db,
            status_filter=[SchedulingStatus.POLLING.value],
        )
        if not active:
            return "skipped -- no active polls"

        now = datetime.now(UTC)
        converged = 0
        nudged_total = 0
        expired_total = 0
        owner_review_total = 0

        for req in active:
            # 1. Poll Gmail / parse responses + run consensus in one call.
            try:
                poll_result = check_polling_status(self.ctx, req.id)
            except Exception:  # noqa: BLE001
                logger.exception(
                    "check_polling_status failed for %s",
                    req.id,
                )
                poll_result = {}

            # 2. Consensus? check_polling_status already called find_consensus
            # with the SchedulingContext (fresh calendar re-score included).
            consensus_slot_id = poll_result.get("consensus_slot_id")
            if consensus_slot_id is not None:
                # Recover the slot object for the notification message.
                slots = sched_db.get_slots(self.db, req.id)
                consensus = next((s for s in slots if s.db_id == consensus_slot_id), None)
                try:
                    transition(
                        self.db,
                        req.id,
                        SchedulingStatus.POLLING,
                        SchedulingStatus.CONVERGED,
                    )
                    converged += 1
                    if consensus:
                        self.send_fn(
                            f"Scheduling: consensus reached for '{req.title}' -- "
                            f"slot {consensus.start_time.isoformat()}. "
                            "Use the book action to confirm."
                        )
                except InvalidTransition:
                    logger.warning(
                        "Could not transition %s to converged",
                        req.id,
                    )
                continue

            # 3. Nudge / expire participants by outreach age.
            nudged_names: list[str] = []
            expired_names: list[str] = []
            remaining_active = 0

            # Re-load participants (status may have flipped to 'responded'
            # inside check_polling_status).
            fresh_participants = sched_db.get_participants(self.db, req.id)
            for p in fresh_participants:
                if p.status in ("responded", "no_response"):
                    continue
                if p.db_id is None:
                    continue

                sent_at = sched_db.get_participant_outreach_sent_at(
                    self.db,
                    p.db_id,
                )
                if sent_at is None:
                    # Outreach never sent (or draft-only Gmail). Skip.
                    remaining_active += 1
                    continue

                # Normalise timezone for comparison.
                if sent_at.tzinfo is None:
                    sent_at = sent_at.replace(tzinfo=UTC)

                age_hours = (now - sent_at).total_seconds() / 3600.0

                # Nudge-before-expire guard: if we're past the expire window
                # but never nudged (e.g. bot was down 24-48h window), send the
                # nudge first and defer expire to the next cycle -- but only if
                # we're still within the safety cap (72h). Past the cap, expire
                # without nudging (the nudge would be too stale to matter).
                in_expire_window = age_hours >= _EXPIRE_HOURS
                in_nudge_window = age_hours >= _NUDGE_HOURS
                can_still_nudge = age_hours < _NUDGE_SAFETY_CAP_HOURS

                if in_expire_window and p.status == "sent" and can_still_nudge:
                    # Bot-down-during-nudge-window recovery path.
                    self._send_nudge(p, req.title, age_hours)
                    sched_db.record_nudge(self.db, p.db_id)
                    nudged_names.append(p.name)
                    remaining_active += 1
                elif in_expire_window:
                    # Either already nudged, or past safety cap -- expire.
                    sched_db.update_participant_status(
                        self.db,
                        p.db_id,
                        "no_response",
                    )
                    expired_names.append(p.name)
                elif in_nudge_window and p.status == "sent":
                    self._send_nudge(p, req.title, age_hours)
                    sched_db.record_nudge(self.db, p.db_id)
                    nudged_names.append(p.name)
                    remaining_active += 1
                else:
                    remaining_active += 1

            nudged_total += len(nudged_names)
            expired_total += len(expired_names)

            # 4. All non-responded participants expired -> owner review.
            if expired_names and remaining_active == 0:
                try:
                    transition(
                        self.db,
                        req.id,
                        SchedulingStatus.POLLING,
                        SchedulingStatus.OWNER_REVIEW,
                    )
                    owner_review_total += 1
                    self.send_fn(
                        f"Scheduling: '{req.title}' returned for review -- "
                        f"expired without response: {', '.join(expired_names)}. "
                        "Book with partial responses, extend, or cancel."
                    )
                except InvalidTransition:
                    logger.warning(
                        "Could not transition %s to owner_review",
                        req.id,
                    )

        parts = [
            f"checked {len(active)} request(s)",
            f"{converged} converged",
            f"{nudged_total} nudged",
            f"{expired_total} expired",
        ]
        if owner_review_total:
            parts.append(f"{owner_review_total} to owner review")
        return ", ".join(parts)


__all__ = ["SchedulingPollCheckJob"]
