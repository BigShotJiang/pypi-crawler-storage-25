"""Interview state machine."""
