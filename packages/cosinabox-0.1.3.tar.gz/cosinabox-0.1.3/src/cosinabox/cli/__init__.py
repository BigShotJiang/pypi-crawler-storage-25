"""cosinabox CLI."""
