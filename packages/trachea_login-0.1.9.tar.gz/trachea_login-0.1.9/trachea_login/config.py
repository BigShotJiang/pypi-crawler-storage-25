import json
from pydantic_settings import BaseSettings, SettingsConfigDict


class TracheaSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="TRACHEA_",
        env_file=".env",
        extra="ignore",
    )

    app_id: str
    app_secret: str
    mongo_uri: str
    firebase_credentials: str  # JSON string or file path
    jwt_secret: str
    access_token_expire_minutes: int = 7200  # 5 days
    refresh_token_expire_days: int = 30
    password_min_length: int = 8
    db_name: str = "trachea"

    def get_firebase_credentials_dict(self) -> dict:
        from trachea_login.exceptions import TracheaConfigError
        try:
            return json.loads(self.firebase_credentials)
        except (json.JSONDecodeError, ValueError):
            try:
                with open(self.firebase_credentials) as f:
                    return json.load(f)
            except FileNotFoundError:
                raise TracheaConfigError(
                    f"Firebase credentials file not found: {self.firebase_credentials}"
                )
