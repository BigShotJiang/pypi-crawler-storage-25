from __future__ import annotations
from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorDatabase

from trachea_login.config import TracheaSettings
from trachea_login.db.user_repo import (
    build_user_response, delete_user,
    get_by_firebase_uid, get_by_email, update_profile, upgrade_plan,
)
from trachea_login.exceptions import ErrorCode, TracheaError
from trachea_login.models import CurrentUser, UpdatePlanRequest, UpdateProfileRequest, UserResponse
from trachea_login.tokens import verify_access_token

_bearer = HTTPBearer()


def create_users_router(settings: TracheaSettings, db: AsyncIOMotorDatabase) -> APIRouter:
    router = APIRouter(tags=["users"])

    def _current_user(credentials: HTTPAuthorizationCredentials = Depends(_bearer)) -> CurrentUser:
        payload = verify_access_token(settings, credentials.credentials)
        return CurrentUser(**payload)

    async def _load_user(current: CurrentUser = Depends(_current_user)) -> dict:
        user = (
            await get_by_firebase_uid(db, current.sub)
            if current.provider != "username"
            else await get_by_email(db, current.sub)
        )
        if user is None or not user.get("is_active"):
            raise TracheaError(ErrorCode.USER_INACTIVE, "User not found or inactive", 403)
        return user

    @router.get("/me", response_model=UserResponse)
    async def get_me(
        current: CurrentUser = Depends(_current_user),
        user: dict = Depends(_load_user),
    ):
        return build_user_response(user, current.app_id)

    @router.patch("/me", response_model=UserResponse)
    async def patch_me(
        body: UpdateProfileRequest,
        current: CurrentUser = Depends(_current_user),
        user: dict = Depends(_load_user),
    ):
        updates: dict = {}
        if body.name is not None:
            updates["name"] = body.name
        if body.phone is not None:
            updates["phone"] = body.phone
        if body.date_of_birth is not None:
            updates["date_of_birth"] = body.date_of_birth
        if body.address is not None:
            updates["address"] = body.address.model_dump(exclude_none=True)

        updated = await update_profile(db, user["_id"], updates) if updates else user
        return build_user_response(updated, current.app_id)

    @router.delete("/me")
    async def delete_me(
        current: CurrentUser = Depends(_current_user),
        user: dict = Depends(_load_user),
    ):
        await delete_user(db, user["_id"])
        return {"message": "Account deleted successfully"}

    @router.patch("/me/plan", response_model=UserResponse)
    async def patch_plan(
        body: UpdatePlanRequest,
        current: CurrentUser = Depends(_current_user),
        user: dict = Depends(_load_user),
    ):
        paid_plans = {"pro", "enterprise"}
        if body.plan in paid_plans and not user.get("email") and not body.email:
            raise TracheaError(
                ErrorCode.EMAIL_REQUIRED_FOR_PAID,
                "Email is required to upgrade to a paid plan",
                422,
            )
        updated = await upgrade_plan(db, user["_id"], current.app_id, body.plan, body.email)
        return build_user_response(updated, current.app_id)

    return router
