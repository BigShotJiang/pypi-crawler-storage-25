from __future__ import annotations
from fastapi import APIRouter, Depends, Header
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorDatabase
from passlib.context import CryptContext

from trachea_login.config import TracheaSettings
from trachea_login.db.app_repo import get_app
from trachea_login.db.user_repo import (
    build_user_response, create_email_user,
    get_by_firebase_uid, get_by_email, upsert_firebase_user,
)
from trachea_login.exceptions import ErrorCode, TracheaError
from trachea_login.firebase import get_provider_from_firebase, verify_firebase_token
from trachea_login.models import LoginRequest, LoginResponse, RefreshRequest, RegisterRequest, TokenResponse
from trachea_login.tokens import (
    issue_access_token, issue_refresh_token,
    revoke_all_refresh_tokens, rotate_refresh_token, verify_access_token,
)

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
_bearer = HTTPBearer()


def _validate_app(app_doc: dict | None, method: str) -> None:
    if app_doc is None:
        raise TracheaError(ErrorCode.APP_NOT_FOUND, "App not found", 404)
    if not app_doc.get("is_active"):
        raise TracheaError(ErrorCode.APP_INACTIVE, "App is inactive", 403)
    if method not in app_doc.get("allowed_auth_methods", []):
        raise TracheaError(
            ErrorCode.AUTH_METHOD_NOT_ALLOWED,
            f"Auth method '{method}' is not allowed for this app",
            403,
        )


def create_auth_router(settings: TracheaSettings, db: AsyncIOMotorDatabase) -> APIRouter:
    router = APIRouter(tags=["auth"])

    @router.post("/login", response_model=LoginResponse)
    async def login(request: LoginRequest, x_app_id: str = Header(..., alias="X-App-Id")):
        app_doc = await get_app(db, x_app_id)

        # Firebase path
        if request.firebase_token:
            decoded = verify_firebase_token(request.firebase_token)
            provider = get_provider_from_firebase(decoded)
            _validate_app(app_doc, provider)

            user = await upsert_firebase_user(
                db,
                firebase_uid=decoded["uid"],
                app_id=x_app_id,
                email=decoded.get("email", ""),
                name=decoded.get("name"),
                avatar=decoded.get("picture"),
                provider=provider,
            )
            if not user.get("is_active"):
                raise TracheaError(ErrorCode.USER_INACTIVE, "User account is deactivated", 403)

            user_resp = build_user_response(user, x_app_id)
            access_token = issue_access_token(
                settings, decoded["uid"], x_app_id,
                user_resp["role"], user_resp["plan"], provider
            )
            refresh_token = await issue_refresh_token(db, settings, decoded["uid"], None, x_app_id)
            return LoginResponse(
                access_token=access_token,
                refresh_token=refresh_token,
                user=user_resp,
            )

        # Email/password path
        if request.email and request.password:
            _validate_app(app_doc, "username")
            user = await get_by_email(db, request.email)
            if user is None or not _pwd.verify(request.password, user.get("password_hash", "")):
                raise TracheaError(ErrorCode.INVALID_CREDENTIALS, "Invalid email or password", 401)
            if not user.get("is_active"):
                raise TracheaError(ErrorCode.USER_INACTIVE, "User account is deactivated", 403)

            user_resp = build_user_response(user, x_app_id)
            access_token = issue_access_token(
                settings, request.email, x_app_id,
                user_resp["role"], user_resp["plan"], "username"
            )
            refresh_token = await issue_refresh_token(db, settings, None, request.email, x_app_id)
            return LoginResponse(access_token=access_token, refresh_token=refresh_token, user=user_resp)

        raise TracheaError(
            ErrorCode.VALIDATION_ERROR,
            "Provide either firebase_token or email+password",
            422,
        )

    async def _register(request: RegisterRequest, x_app_id: str):
        if len(request.password) < settings.password_min_length:
            raise TracheaError(
                ErrorCode.VALIDATION_ERROR,
                f"Password must be at least {settings.password_min_length} characters",
                422,
            )
        app_doc = await get_app(db, x_app_id)
        _validate_app(app_doc, "username")

        existing = await get_by_email(db, request.email)
        if existing:
            raise TracheaError(ErrorCode.USERNAME_TAKEN, "Email already registered", 409)

        password_hash = _pwd.hash(request.password)
        user = await create_email_user(db, request.email, password_hash, request.name, x_app_id)
        user_resp = build_user_response(user, x_app_id)
        access_token = issue_access_token(
            settings, request.email, x_app_id,
            user_resp["role"], user_resp["plan"], "username"
        )
        refresh_token = await issue_refresh_token(db, settings, None, request.email, x_app_id)
        return LoginResponse(access_token=access_token, refresh_token=refresh_token, user=user_resp)

    @router.post("/register", response_model=LoginResponse)
    async def register(request: RegisterRequest, x_app_id: str = Header(..., alias="X-App-Id")):
        return await _register(request, x_app_id)

    @router.post("/signup", response_model=LoginResponse)
    async def signup(request: RegisterRequest, x_app_id: str = Header(..., alias="X-App-Id")):
        return await _register(request, x_app_id)

    @router.post("/refresh", response_model=TokenResponse)
    async def refresh(request: RefreshRequest, x_app_id: str = Header(..., alias="X-App-Id")):
        app_doc = await get_app(db, x_app_id)
        if app_doc is None:
            raise TracheaError(ErrorCode.APP_NOT_FOUND, "App not found", 404)
        if not app_doc.get("is_active"):
            raise TracheaError(ErrorCode.APP_INACTIVE, "App is inactive", 403)

        new_raw, firebase_uid, username = await rotate_refresh_token(
            db, settings, request.refresh_token, x_app_id
        )
        sub = firebase_uid or username
        user = (
            await get_by_firebase_uid(db, firebase_uid)
            if firebase_uid
            else await get_by_email(db, username)
        )
        user_resp = build_user_response(user, x_app_id)
        access_token = issue_access_token(
            settings, sub, x_app_id,
            user_resp["role"], user_resp["plan"], user_resp["provider"]
        )
        return TokenResponse(access_token=access_token, refresh_token=new_raw)

    @router.post("/logout")
    async def logout(credentials: HTTPAuthorizationCredentials = Depends(_bearer)):
        payload = verify_access_token(settings, credentials.credentials)
        firebase_uid = payload["sub"] if payload.get("provider") != "username" else None
        username = payload["sub"] if payload.get("provider") == "username" else None
        await revoke_all_refresh_tokens(db, firebase_uid, username, payload["app_id"])
        return {"message": "Successfully logged out"}

    return router
