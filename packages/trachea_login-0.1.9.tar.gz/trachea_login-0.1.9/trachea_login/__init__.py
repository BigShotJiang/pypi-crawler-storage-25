from __future__ import annotations
from typing import Any, Optional, Callable

from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from trachea_login.config import TracheaSettings
from trachea_login.db.mongo import create_indexes
from trachea_login.exceptions import ErrorCode, TracheaConfigError, TracheaError
from trachea_login.firebase import init_firebase
from trachea_login.models import CurrentUser
from trachea_login.tokens import verify_access_token

_settings: Optional[TracheaSettings] = None
_db: Optional[Any] = None
_bearer = HTTPBearer()

ROLE_HIERARCHY = {"guest": 0, "member": 1, "admin": 2}
PLAN_HIERARCHY = {"free": 0, "pro": 1, "enterprise": 2}


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
) -> CurrentUser:
    if _settings is None:
        raise TracheaError(ErrorCode.INVALID_TOKEN, "TracheaLogin has not been initialized", 503)
    payload = verify_access_token(_settings, credentials.credentials)
    return CurrentUser(**payload)


def require_role(role: Optional[str] = None, plan: Optional[str] = None) -> Callable:
    async def dependency(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if role and ROLE_HIERARCHY.get(user.role, 0) < ROLE_HIERARCHY.get(role, 0):
            raise TracheaError(ErrorCode.INSUFFICIENT_ROLE, f"Role '{role}' or higher required", 403)
        if plan and PLAN_HIERARCHY.get(user.plan, 0) < PLAN_HIERARCHY.get(plan, 0):
            raise TracheaError(ErrorCode.INSUFFICIENT_PLAN, f"Plan '{plan}' or higher required", 403)
        return user
    return dependency


class TracheaLogin:
    def __init__(self, mongo_client=None, **overrides):
        global _settings, _db
        self.settings = TracheaSettings(**overrides)
        _settings = self.settings

        from motor.motor_asyncio import AsyncIOMotorClient
        self._client = mongo_client or AsyncIOMotorClient(self.settings.mongo_uri)
        self._db = self._client[self.settings.db_name]
        _db = self._db

        init_firebase(self.settings)
        self._router = self._build_router()

    def _build_router(self) -> APIRouter:
        from trachea_login.routers.auth import create_auth_router
        from trachea_login.routers.users import create_users_router

        main = APIRouter()
        main.include_router(create_auth_router(self.settings, self._db))
        main.include_router(create_users_router(self.settings, self._db), prefix="/users")
        return main

    @property
    def router(self) -> APIRouter:
        return self._router

    async def startup(self) -> None:
        """Call from FastAPI lifespan to create indexes and validate app registration."""
        from trachea_login.db.app_repo import get_app, verify_app_secret
        await create_indexes(self._db)
        app_doc = await get_app(self._db, self.settings.app_id)
        if app_doc is None:
            raise TracheaConfigError(
                f"App '{self.settings.app_id}' not found in database. "
                "Register it before starting the application."
            )
        if not await verify_app_secret(app_doc["app_secret"], self.settings.app_secret):
            raise TracheaConfigError(
                f"Invalid app_secret for app '{self.settings.app_id}'."
            )
