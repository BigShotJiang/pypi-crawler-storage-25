from __future__ import annotations
import firebase_admin
from firebase_admin import auth, credentials

from trachea_login.config import TracheaSettings
from trachea_login.exceptions import ErrorCode, TracheaError

_PROVIDER_MAP = {
    "google.com": "google",
    "facebook.com": "facebook",
    "apple.com": "apple",
    "password": "password",
}


def init_firebase(settings: TracheaSettings) -> None:
    """Initialize Firebase Admin SDK. Safe to call multiple times (no-op if already initialized)."""
    if not firebase_admin._apps:
        cred_dict = settings.get_firebase_credentials_dict()
        cred = credentials.Certificate(cred_dict)
        firebase_admin.initialize_app(cred)


def verify_firebase_token(token: str) -> dict:
    """Verify a Firebase ID token. Returns decoded token dict with uid, email, name, picture."""
    try:
        return auth.verify_id_token(token)
    except Exception:
        raise TracheaError(
            ErrorCode.INVALID_FIREBASE_TOKEN, "Invalid or expired Firebase token", 401
        )


def get_provider_from_firebase(decoded_token: dict) -> str:
    """Extract normalized provider name from a decoded Firebase token."""
    sign_in_provider = decoded_token.get("firebase", {}).get("sign_in_provider", "password")
    return _PROVIDER_MAP.get(sign_in_provider, "password")
