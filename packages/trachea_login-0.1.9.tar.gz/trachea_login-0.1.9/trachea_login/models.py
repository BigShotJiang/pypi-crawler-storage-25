from __future__ import annotations
from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class Address(BaseModel):
    street: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    zip: Optional[str] = None


class CurrentUser(BaseModel):
    """Decoded JWT payload — used in FastAPI dependencies."""
    sub: str        # firebase_uid or username
    app_id: str
    role: str
    plan: str
    provider: str


class UserResponse(BaseModel):
    firebase_uid: Optional[str] = None
    username: Optional[str] = None
    email: Optional[str] = None
    name: Optional[str] = None
    avatar: Optional[str] = None
    provider: str
    app_id: str
    role: str
    plan: str
    joined_at: datetime


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class LoginResponse(TokenResponse):
    user: UserResponse


class LoginRequest(BaseModel):
    firebase_token: Optional[str] = None
    email: Optional[str] = None
    password: Optional[str] = None


class RegisterRequest(BaseModel):
    email: str
    password: str
    name: Optional[str] = None


class RefreshRequest(BaseModel):
    refresh_token: str


class UpdateProfileRequest(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    address: Optional[Address] = None


class UpdatePlanRequest(BaseModel):
    plan: str
    email: Optional[str] = None
