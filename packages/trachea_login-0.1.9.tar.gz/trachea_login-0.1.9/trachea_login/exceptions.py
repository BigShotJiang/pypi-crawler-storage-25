from fastapi import Request
from fastapi.responses import JSONResponse


class TracheaError(Exception):
    def __init__(self, error: str, message: str, status_code: int):
        self.error = error
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class TracheaConfigError(Exception):
    pass


class ErrorCode:
    APP_NOT_FOUND = "APP_NOT_FOUND"
    APP_INACTIVE = "APP_INACTIVE"
    AUTH_METHOD_NOT_ALLOWED = "AUTH_METHOD_NOT_ALLOWED"
    INVALID_FIREBASE_TOKEN = "INVALID_FIREBASE_TOKEN"
    INVALID_CREDENTIALS = "INVALID_CREDENTIALS"
    USERNAME_TAKEN = "USERNAME_TAKEN"
    EMAIL_TAKEN = "EMAIL_TAKEN"
    INVALID_TOKEN = "INVALID_TOKEN"
    TOKEN_EXPIRED = "TOKEN_EXPIRED"
    REFRESH_TOKEN_INVALID = "REFRESH_TOKEN_INVALID"
    REFRESH_TOKEN_REUSE = "REFRESH_TOKEN_REUSE"
    INSUFFICIENT_ROLE = "INSUFFICIENT_ROLE"
    INSUFFICIENT_PLAN = "INSUFFICIENT_PLAN"
    EMAIL_REQUIRED_FOR_PAID = "EMAIL_REQUIRED_FOR_PAID"
    USER_INACTIVE = "USER_INACTIVE"
    VALIDATION_ERROR = "VALIDATION_ERROR"


async def trachea_exception_handler(request: Request, exc: TracheaError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.error, "message": exc.message, "status_code": exc.status_code},
    )
