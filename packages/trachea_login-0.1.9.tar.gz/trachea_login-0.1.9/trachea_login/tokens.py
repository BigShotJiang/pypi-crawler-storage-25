from __future__ import annotations
import hashlib
import secrets
from datetime import datetime, timezone, timedelta
from typing import Optional

from jose import ExpiredSignatureError, JWTError
from jose import jwt as jose_jwt
from motor.motor_asyncio import AsyncIOMotorDatabase

from trachea_login.config import TracheaSettings
from trachea_login.exceptions import ErrorCode, TracheaError


def issue_access_token(
    settings: TracheaSettings,
    sub: str,
    app_id: str,
    role: str,
    plan: str,
    provider: str,
) -> str:
    now = datetime.now(timezone.utc)
    expire = now + timedelta(minutes=settings.access_token_expire_minutes)
    payload = {
        "sub": sub,
        "app_id": app_id,
        "role": role,
        "plan": plan,
        "provider": provider,
        "exp": expire,
        "iat": now,
    }
    return jose_jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def verify_access_token(settings: TracheaSettings, token: str) -> dict:
    try:
        return jose_jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
    except ExpiredSignatureError:
        raise TracheaError(ErrorCode.TOKEN_EXPIRED, "Access token has expired", 401)
    except JWTError:
        raise TracheaError(ErrorCode.INVALID_TOKEN, "Invalid access token", 401)


def _hash_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


async def issue_refresh_token(
    db: AsyncIOMotorDatabase,
    settings: TracheaSettings,
    firebase_uid: Optional[str],
    username: Optional[str],
    app_id: str,
) -> str:
    raw = secrets.token_urlsafe(64)
    now = datetime.now(timezone.utc)
    await db.refresh_tokens.insert_one({
        "token_hash": _hash_token(raw),
        "firebase_uid": firebase_uid,
        "username": username,
        "app_id": app_id,
        "expires_at": now + timedelta(days=settings.refresh_token_expire_days),
        "revoked": False,
        "created_at": now,
    })
    return raw


async def rotate_refresh_token(
    db: AsyncIOMotorDatabase,
    settings: TracheaSettings,
    raw_token: str,
    app_id: str,
) -> tuple[str, Optional[str], Optional[str]]:
    """Returns (new_raw_token, firebase_uid, username). Raises TracheaError on any problem."""
    stored = await db.refresh_tokens.find_one(
        {"token_hash": _hash_token(raw_token), "app_id": app_id}
    )

    if stored is None:
        raise TracheaError(ErrorCode.REFRESH_TOKEN_INVALID, "Refresh token not found", 401)

    if stored["revoked"]:
        # Reuse attack: revoke all tokens for this identity + app
        query: dict = {"app_id": app_id}
        if stored.get("firebase_uid"):
            query["firebase_uid"] = stored["firebase_uid"]
        elif stored.get("username"):
            query["username"] = stored["username"]
        await db.refresh_tokens.update_many(query, {"$set": {"revoked": True}})
        raise TracheaError(ErrorCode.REFRESH_TOKEN_REUSE, "Refresh token reuse detected", 401)

    expires_at = stored["expires_at"]
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at < datetime.now(timezone.utc):
        raise TracheaError(ErrorCode.REFRESH_TOKEN_INVALID, "Refresh token has expired", 401)

    await db.refresh_tokens.update_one(
        {"token_hash": _hash_token(raw_token), "app_id": app_id}, {"$set": {"revoked": True}}
    )

    firebase_uid: Optional[str] = stored.get("firebase_uid")
    username: Optional[str] = stored.get("username")
    new_raw = await issue_refresh_token(db, settings, firebase_uid, username, app_id)
    return new_raw, firebase_uid, username


async def revoke_all_refresh_tokens(
    db: AsyncIOMotorDatabase,
    firebase_uid: Optional[str],
    username: Optional[str],
    app_id: str,
) -> None:
    query: dict = {"app_id": app_id}
    if firebase_uid:
        query["firebase_uid"] = firebase_uid
    elif username:
        query["username"] = username
    await db.refresh_tokens.update_many(query, {"$set": {"revoked": True}})
