from typing import Optional
from motor.motor_asyncio import AsyncIOMotorDatabase
import bcrypt as _bcrypt_lib


async def get_app(db: AsyncIOMotorDatabase, app_id: str) -> Optional[dict]:
    return await db.apps.find_one({"app_id": app_id})


async def verify_app_secret(stored_hash: str, secret: str) -> bool:
    return _bcrypt_lib.checkpw(secret.encode(), stored_hash.encode())


async def hash_secret(secret: str) -> str:
    return _bcrypt_lib.hashpw(secret.encode(), _bcrypt_lib.gensalt()).decode()
