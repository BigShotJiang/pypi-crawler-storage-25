from __future__ import annotations
from datetime import datetime, timezone
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorDatabase


async def get_by_firebase_uid(db: AsyncIOMotorDatabase, firebase_uid: str) -> Optional[dict]:
    return await db.users.find_one({"firebase_uid": firebase_uid})


async def get_by_username(db: AsyncIOMotorDatabase, username: str) -> Optional[dict]:
    return await db.users.find_one({"username": username})


async def get_by_email(db: AsyncIOMotorDatabase, email: str) -> Optional[dict]:
    return await db.users.find_one({"email": email})


def get_app_entry(user_doc: dict, app_id: str) -> Optional[dict]:
    for entry in user_doc.get("apps", []):
        if entry["app_id"] == app_id:
            return entry
    return None


def build_user_response(user_doc: dict, app_id: str) -> dict:
    entry = get_app_entry(user_doc, app_id) or {
        "role": "member", "plan": "free", "joined_at": datetime.now(timezone.utc)
    }
    return {
        "firebase_uid": user_doc.get("firebase_uid"),
        "username": user_doc.get("username"),
        "email": user_doc.get("email"),
        "name": user_doc.get("name"),
        "avatar": user_doc.get("avatar"),
        "provider": user_doc["provider"],
        "app_id": app_id,
        "role": entry["role"],
        "plan": entry["plan"],
        "joined_at": entry["joined_at"],
    }


async def upsert_firebase_user(db, firebase_uid, app_id, email, name, avatar, provider) -> dict:
    now = datetime.now(timezone.utc)
    existing = await get_by_firebase_uid(db, firebase_uid)
    # Fall back to email lookup — links firebase_uid to accounts created before Google sign-in
    if existing is None and email:
        existing = await get_by_email(db, email)
        if existing is not None:
            await db.users.update_one({"_id": existing["_id"]}, {"$set": {"firebase_uid": firebase_uid}})
            existing["firebase_uid"] = firebase_uid
    if existing is None:
        doc = {
            "firebase_uid": firebase_uid, "name": name, "avatar": avatar,
            "phone": None, "date_of_birth": None, "address": None,
            "provider": provider, "is_active": True,
            "apps": [{"app_id": app_id, "role": "member", "plan": "free", "joined_at": now}],
            "created_at": now, "updated_at": now,
        }
        if email:
            doc["email"] = email
        await db.users.insert_one(doc)
    else:
        app_ids = [a["app_id"] for a in existing.get("apps", [])]
        set_fields: dict = {"updated_at": now, "name": name, "avatar": avatar}
        update: dict = {"$set": set_fields}
        if app_id not in app_ids:
            update["$push"] = {"apps": {"app_id": app_id, "role": "member", "plan": "free", "joined_at": now}}
        await db.users.update_one({"firebase_uid": firebase_uid}, update)
    return await get_by_firebase_uid(db, firebase_uid)


async def create_username_user(db, username, password_hash, name, app_id) -> dict:
    now = datetime.now(timezone.utc)
    doc = {
        "username": username, "password_hash": password_hash, "name": name,
        "avatar": None, "phone": None, "date_of_birth": None, "address": None,
        "provider": "username", "is_active": True,
        "apps": [{"app_id": app_id, "role": "member", "plan": "free", "joined_at": now}],
        "created_at": now, "updated_at": now,
    }
    await db.users.insert_one(doc)
    return await get_by_username(db, username)


async def create_email_user(db, email, password_hash, name, app_id) -> dict:
    now = datetime.now(timezone.utc)
    doc = {
        "email": email, "password_hash": password_hash, "name": name,
        "avatar": None, "phone": None, "date_of_birth": None, "address": None,
        "provider": "username", "is_active": True,
        "apps": [{"app_id": app_id, "role": "member", "plan": "free", "joined_at": now}],
        "created_at": now, "updated_at": now,
    }
    await db.users.insert_one(doc)
    return await get_by_email(db, email)


async def update_profile(db, user_id, updates: dict) -> dict:
    updates["updated_at"] = datetime.now(timezone.utc)
    await db.users.update_one({"_id": user_id}, {"$set": updates})
    return await db.users.find_one({"_id": user_id})


async def delete_user(db, user_id) -> None:
    await db.users.delete_one({"_id": user_id})


async def upgrade_plan(db, user_id, app_id, plan, email=None) -> dict:
    now = datetime.now(timezone.utc)
    user = await db.users.find_one({"_id": user_id})
    apps = user.get("apps", [])
    for entry in apps:
        if entry["app_id"] == app_id:
            entry["plan"] = plan
    set_fields: dict = {"apps": apps, "updated_at": now}
    if email:
        set_fields["email"] = email
    await db.users.update_one({"_id": user_id}, {"$set": set_fields})
    return await db.users.find_one({"_id": user_id})
