from motor.motor_asyncio import AsyncIOMotorDatabase


async def create_indexes(db: AsyncIOMotorDatabase) -> None:
    """Create all required MongoDB indexes. Safe to call multiple times."""
    await db.users.create_index("firebase_uid", unique=True, sparse=True)
    await db.users.create_index("email", unique=True, sparse=True)
    await db.users.create_index("username", unique=True, sparse=True)
    await db.users.create_index("apps.app_id")
    await db.apps.create_index("app_id", unique=True)
    await db.refresh_tokens.create_index("token_hash")
    await db.refresh_tokens.create_index(
        "expires_at", expireAfterSeconds=0
    )
