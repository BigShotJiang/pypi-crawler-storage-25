#!/usr/bin/env python3
"""
End-to-end integration test for trachea-login.
Tests username/password flow (no Firebase token needed).

Usage:
    # With the server running (uvicorn e2e_app:app --port 8000):
    python e2e_test.py

    # Or run against any base URL:
    BASE_URL=https://your-api.com python e2e_test.py

    # To also test Firebase login, set FIREBASE_ID_TOKEN:
    FIREBASE_ID_TOKEN=<token_from_client_sdk> python e2e_test.py
"""
import os
import sys
import httpx

BASE_URL = os.getenv("BASE_URL", "http://localhost:8000")
APP_ID = os.getenv("TRACHEA_APP_ID", "Trachea-Test-App")
FIREBASE_TOKEN = os.getenv("FIREBASE_ID_TOKEN", "")

PASS = "✅"
FAIL = "❌"
results = []


def check(label: str, condition: bool, detail: str = ""):
    status = PASS if condition else FAIL
    msg = f"  {status} {label}"
    if not condition and detail:
        msg += f"\n     → {detail}"
    print(msg)
    results.append(condition)
    return condition


def section(title: str):
    print(f"\n{'─'*50}\n  {title}\n{'─'*50}")


def run():
    client = httpx.Client(base_url=BASE_URL, timeout=15)
    access_token = None
    refresh_token = None
    username = f"e2e_user_{os.getpid()}"
    password = "E2eTestPass99"

    # ── Server health ──────────────────────────────────────
    section("1. Server Health")
    try:
        r = client.get("/")
        check("Server is reachable", r.status_code == 200, r.text)
    except Exception as e:
        check("Server is reachable", False, str(e))
        print("\n❌ Cannot connect to server. Start it with:\n   uvicorn e2e_app:app --reload --port 8000\n")
        sys.exit(1)

    # ── Username Registration ──────────────────────────────
    section("2. Username Registration")
    r = client.post("/auth/register", json={"username": username, "password": password, "app_id": APP_ID})
    ok = check("Register new user — 200", r.status_code == 200, r.text)
    if ok:
        data = r.json()
        check("Response has access_token", "access_token" in data)
        check("Response has refresh_token", "refresh_token" in data)
        check("User provider is 'username'", data["user"]["provider"] == "username")
        check("User plan is 'free'", data["user"]["plan"] == "free")
        check("User role is 'member'", data["user"]["role"] == "member")
        check("Username matches", data["user"]["username"] == username)
        access_token = data["access_token"]
        refresh_token = data["refresh_token"]

    # Duplicate username
    r2 = client.post("/auth/register", json={"username": username, "password": password, "app_id": APP_ID})
    check("Duplicate username — 409 USERNAME_TAKEN", r2.status_code == 409 and r2.json().get("error") == "USERNAME_TAKEN")

    # Short password
    r3 = client.post("/auth/register", json={"username": "x", "password": "ab", "app_id": APP_ID})
    check("Short password — 422 VALIDATION_ERROR", r3.status_code == 422 and r3.json().get("error") == "VALIDATION_ERROR")

    # ── Username Login ─────────────────────────────────────
    section("3. Username Login")
    r = client.post("/auth/login", json={"username": username, "password": password, "app_id": APP_ID})
    ok = check("Login success — 200", r.status_code == 200, r.text)
    if ok:
        data = r.json()
        access_token = data["access_token"]
        refresh_token = data["refresh_token"]
        check("Access token returned", bool(access_token))

    r = client.post("/auth/login", json={"username": username, "password": "WrongPass1", "app_id": APP_ID})
    check("Wrong password — 401 INVALID_CREDENTIALS", r.status_code == 401 and r.json().get("error") == "INVALID_CREDENTIALS")

    r = client.post("/auth/login", json={"username": "ghost_nobody", "password": password, "app_id": APP_ID})
    check("Unknown user — 401 INVALID_CREDENTIALS", r.status_code == 401 and r.json().get("error") == "INVALID_CREDENTIALS")

    r = client.post("/auth/login", json={"app_id": APP_ID})
    check("No credentials — 422 VALIDATION_ERROR", r.status_code == 422 and r.json().get("error") == "VALIDATION_ERROR")

    # ── Protected Routes ───────────────────────────────────
    section("4. Protected Routes (JWT)")
    if access_token:
        auth = {"Authorization": f"Bearer {access_token}"}

        r = client.get("/protected", headers=auth)
        ok = check("GET /protected with valid token — 200", r.status_code == 200, r.text)
        if ok:
            check("sub matches username", r.json()["sub"] == username)

        r = client.get("/protected")
        check("GET /protected with no token — 401", r.status_code == 401)

        r = client.get("/protected", headers={"Authorization": "Bearer bad.token.here"})
        check("GET /protected with bad token — 401", r.status_code == 401)

        r = client.get("/members-only", headers=auth)
        check("GET /members-only (member role) — 200", r.status_code == 200, r.text)

        r = client.get("/pro-only", headers=auth)
        check("GET /pro-only (free plan) — 403 INSUFFICIENT_PLAN", r.status_code == 403 and r.json().get("error") == "INSUFFICIENT_PLAN")

        r = client.get("/admin-only", headers=auth)
        check("GET /admin-only (member role) — 403 INSUFFICIENT_ROLE", r.status_code == 403 and r.json().get("error") == "INSUFFICIENT_ROLE")

    # ── User Profile ───────────────────────────────────────
    section("5. User Profile (GET/PATCH /auth/users/me)")
    if access_token:
        auth = {"Authorization": f"Bearer {access_token}"}

        r = client.get("/auth/users/me", headers=auth)
        check("GET /users/me — 200", r.status_code == 200, r.text)

        r = client.patch("/auth/users/me", json={"name": "E2E Tester", "phone": "+1234567890"}, headers=auth)
        ok = check("PATCH /users/me name+phone — 200", r.status_code == 200, r.text)
        if ok:
            check("Name updated", r.json()["name"] == "E2E Tester")

        r = client.patch("/auth/users/me", json={"address": {"city": "San Francisco", "country": "US"}}, headers=auth)
        check("PATCH /users/me address — 200", r.status_code == 200, r.text)

        r = client.patch("/auth/users/me/plan", json={"plan": "pro"}, headers=auth)
        check("PATCH /users/me/plan to pro (no email) — 422 EMAIL_REQUIRED_FOR_PAID",
              r.status_code == 422 and r.json().get("error") == "EMAIL_REQUIRED_FOR_PAID")

        r = client.patch("/auth/users/me/plan", json={"plan": "pro", "email": f"{username}@example.com"}, headers=auth)
        check("PATCH /users/me/plan to pro with email — 200", r.status_code == 200, r.text)

    # ── Token Refresh ──────────────────────────────────────
    section("6. Token Refresh")
    if refresh_token:
        r = client.post("/auth/refresh", json={"refresh_token": refresh_token, "app_id": APP_ID})
        ok = check("POST /auth/refresh — 200", r.status_code == 200, r.text)
        if ok:
            new_refresh = r.json()["refresh_token"]
            check("New refresh token differs from old", new_refresh != refresh_token)

            # Reuse old token — should trigger reuse detection
            r2 = client.post("/auth/refresh", json={"refresh_token": refresh_token, "app_id": APP_ID})
            check("Reuse old refresh token — 401 REFRESH_TOKEN_REUSE",
                  r2.status_code == 401 and r2.json().get("error") == "REFRESH_TOKEN_REUSE")

            # New token also revoked after reuse attack
            r3 = client.post("/auth/refresh", json={"refresh_token": new_refresh, "app_id": APP_ID})
            check("New token revoked after reuse attack — 401", r3.status_code == 401)

        r = client.post("/auth/refresh", json={"refresh_token": "totally-invalid-token", "app_id": APP_ID})
        check("Invalid refresh token — 401 REFRESH_TOKEN_INVALID",
              r.status_code == 401 and r.json().get("error") == "REFRESH_TOKEN_INVALID")

    # ── Logout ─────────────────────────────────────────────
    section("7. Logout")
    # Re-login to get a fresh token for logout test
    r = client.post("/auth/login", json={"username": username, "password": password, "app_id": APP_ID})
    if r.status_code == 200:
        fresh_token = r.json()["access_token"]
        auth = {"Authorization": f"Bearer {fresh_token}"}
        r = client.post("/auth/logout", headers=auth)
        check("POST /auth/logout — 200", r.status_code == 200, r.text)
        if r.status_code == 200:
            check("Logout message correct", "logged out" in r.json().get("message", "").lower())

    # ── App Validation ─────────────────────────────────────
    section("8. App Validation")
    r = client.post("/auth/login", json={"username": username, "password": password, "app_id": "nonexistent-app"})
    check("Unknown app_id — 404 APP_NOT_FOUND",
          r.status_code == 404 and r.json().get("error") == "APP_NOT_FOUND")

    # ── Firebase Login (optional) ──────────────────────────
    if FIREBASE_TOKEN:
        section("9. Firebase Login (FIREBASE_ID_TOKEN provided)")
        r = client.post("/auth/login", json={"firebase_token": FIREBASE_TOKEN, "app_id": APP_ID})
        ok = check("Firebase login — 200", r.status_code == 200, r.text)
        if ok:
            data = r.json()
            check("Provider is not 'username'", data["user"]["provider"] != "username")
            check("Access token returned", bool(data.get("access_token")))
    else:
        section("9. Firebase Login")
        print("  ⏭  Skipped — set FIREBASE_ID_TOKEN env var to test Firebase login")

    # ── Summary ────────────────────────────────────────────
    total = len(results)
    passed = sum(results)
    failed = total - passed
    print(f"\n{'='*50}")
    print(f"  Results: {passed}/{total} passed", end="")
    if failed:
        print(f"  ({failed} FAILED)")
    else:
        print("  — ALL PASSED 🎉")
    print(f"{'='*50}\n")

    if failed:
        sys.exit(1)


if __name__ == "__main__":
    print(f"\n🔍 trachea-login E2E Integration Test")
    print(f"   Base URL : {BASE_URL}")
    print(f"   App ID   : {APP_ID}")
    run()
