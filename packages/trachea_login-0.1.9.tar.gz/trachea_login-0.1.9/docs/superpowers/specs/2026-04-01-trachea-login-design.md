# trachea-login — Architecture Design Spec

**Date:** 2026-04-01
**Status:** Approved
**Package:** `trachea-login` (PyPI)
**Author:** Trachea Inc

---

## Problem Statement

Trachea Inc builds multiple apps (App1, App2, App3 — mobile and web). Each app needs authentication. Without a shared package, auth logic is duplicated across every app, bugs are fixed multiple times, and user data is fragmented.

`trachea-login` solves this by providing a single pip-installable FastAPI auth package that all apps share. One MongoDB database holds all users. Apps mount the package in 2 lines and get full auth functionality.

---

## Chosen Approach: Layered Auth Package

Firebase handles **identity verification only**. After any successful verification, `trachea-login` takes ownership — issues its own JWTs, manages MongoDB, enforces roles and plans.

```
[Social/Email login]  Client → Firebase SDK → Firebase ID Token → POST /auth/login
[Username login]      Client → POST /auth/login (username + password, no Firebase)

trachea-login:
  1. Verifies identity (Firebase token OR bcrypt)
  2. Upserts user in MongoDB with AppId context
  3. Issues app JWT (access token 15min + refresh token 30d)

Subsequent requests:
  Client → Authorization: Bearer <access_token>
  App    → Depends(get_current_user)  [no DB hit — decoded from JWT]
```

Firebase is used at login time only. All subsequent requests use the app JWT. Firebase is swappable.

---

## Package Structure

```
trachea_login/
├── __init__.py          # exports: TracheaLogin, get_current_user, require_role
├── config.py            # pydantic-settings, TRACHEA_ env prefix
├── firebase.py          # verify_firebase_token()
├── tokens.py            # issue_access_token(), issue_refresh_token(), verify_token()
├── models.py            # Pydantic request/response schemas
├── db/
│   ├── mongo.py         # Motor async client, index creation
│   ├── user_repo.py     # upsert_user(), get_user(), update_user(), deactivate_user()
│   └── app_repo.py      # get_app(), validate_app_secret()
├── routers/
│   ├── auth.py          # /login, /register, /refresh, /logout
│   └── users.py         # /me GET/PATCH/DELETE, /me/plan PATCH
└── dependencies.py      # get_current_user, require_role(role, plan)
```

**Public API** (what apps import):
```python
from trachea_login import TracheaLogin, get_current_user, require_role
```

---

## Configuration

All config from environment variables with `TRACHEA_` prefix.

```
TRACHEA_APP_ID                      required
TRACHEA_APP_SECRET                  required
TRACHEA_MONGO_URI                   required   (connection string to shared MongoDB)
TRACHEA_FIREBASE_CREDENTIALS        required   (file path or raw JSON string)
TRACHEA_JWT_SECRET                  required
TRACHEA_ACCESS_TOKEN_EXPIRE_MINUTES default=15
TRACHEA_REFRESH_TOKEN_EXPIRE_DAYS   default=30
TRACHEA_PASSWORD_MIN_LENGTH         default=8
TRACHEA_DB_NAME                     default=trachea
```

`TracheaLogin()` validates app_id + app_secret against MongoDB at startup. Fails fast with `TracheaConfigError` if misconfigured.

---

## Data Model

### `users` collection

```
firebase_uid     str | null    sparse unique   null for username/password users
email            str | null    sparse unique   null for free username users
username         str | null    sparse unique   null for Firebase users
password_hash    str | null                    bcrypt, only for username users
name             str
avatar           str | null
phone            str | null
date_of_birth    str | null
address          object | null  {street, city, state, country, zip}
provider         str            google|facebook|apple|password|username
is_active        bool
apps             array          [{app_id, role, plan, joined_at}]
created_at       datetime
updated_at       datetime
```

**Business rules:**
- `username` users: email optional, plan locked to `free`
- Plan upgrade to paid: email required before allowed
- One user document per person; apps[] array tracks per-app role/plan
- `apps.app_id` multikey index for per-app user queries

### `apps` collection

```
app_id                str         unique
app_secret            str         bcrypt hashed
name                  str
allowed_auth_methods  array       [google, facebook, apple, password, username]
allowed_domains       array
is_active             bool
created_at            datetime
```

### `refresh_tokens` collection

```
token_hash      str (sha256)    indexed
firebase_uid    str | null
username        str | null
app_id          str
expires_at      datetime        TTL index — auto-deleted when expired
revoked         bool
created_at      datetime
```

---

## Auth Flows

### Flow 1/2: Firebase (social + email/password)
1. Client → Firebase SDK → Firebase ID Token
2. `POST /auth/login` `{firebase_token, app_id}`
3. Verify Firebase token → upsert MongoDB user → issue JWT pair
4. Return `{access_token, refresh_token, user}`

### Flow 3: Username register (native)
1. `POST /auth/register` `{username, password, name, app_id}`
2. Validate uniqueness → bcrypt hash → create user (plan=free locked) → issue JWT pair

### Flow 4: Username login (native)
1. `POST /auth/login` `{username, password, app_id}`
2. Lookup by username → bcrypt verify → issue JWT pair

### Flow 5: Token refresh
1. `POST /auth/refresh` `{refresh_token, app_id}`
2. SHA256 hash → lookup in `refresh_tokens` → verify not revoked/expired
3. Revoke old token → issue new JWT pair (rotation)
4. Reuse detected → revoke ALL tokens for user+app (attack protection)

### Flow 6: Logout
1. `POST /auth/logout` + Bearer token
2. Revoke all `refresh_tokens` for user + app_id

### JWT payload
```json
{"sub": "firebase_uid_or_username", "app_id": "app1",
 "role": "member", "plan": "free", "provider": "google",
 "exp": ..., "iat": ...}
```

---

## API Routes

```
POST   /auth/login          Firebase token OR username+password
POST   /auth/register       Username+password only
POST   /auth/refresh        Rotate refresh token
POST   /auth/logout         Revoke tokens (Bearer required)

GET    /users/me            Current user profile (Bearer required)
PATCH  /users/me            Update name/phone/dob/address (Bearer required)
DELETE /users/me            Soft deactivate (Bearer required)
PATCH  /users/me/plan       Upgrade plan — email required if missing (Bearer required)
```

---

## Error Handling

Consistent error shape: `{"error": "CODE", "message": "...", "status_code": N}`

```
APP_NOT_FOUND             404    app_id not in MongoDB
APP_INACTIVE              403    app is disabled
AUTH_METHOD_NOT_ALLOWED   403    method not in allowed_auth_methods
INVALID_FIREBASE_TOKEN    401    Firebase verification failed
INVALID_CREDENTIALS       401    wrong username or password
USERNAME_TAKEN            409    username already exists
EMAIL_TAKEN               409    email already registered
INVALID_TOKEN             401    JWT invalid/malformed
TOKEN_EXPIRED             401    JWT expired
REFRESH_TOKEN_INVALID     401    refresh token not found or revoked
REFRESH_TOKEN_REUSE       401    old token reused → all tokens revoked
INSUFFICIENT_ROLE         403    role too low
INSUFFICIENT_PLAN         403    plan too low
EMAIL_REQUIRED_FOR_PAID   422    upgrading plan without email
USER_INACTIVE             403    account deactivated
VALIDATION_ERROR          422    Pydantic validation failure
```

---

## Dependencies

```toml
fastapi>=0.110.0
motor>=3.3.0               # async MongoDB
pydantic>=2.0.0
pydantic-settings>=2.0.0
python-jose[cryptography]  # JWT
passlib[bcrypt]            # password hashing
firebase-admin>=6.0.0
httpx>=0.27.0
```

Dev: `pytest`, `pytest-asyncio`, `mongomock-motor`, `httpx`

---

## Testing

- MongoDB: `mongomock-motor` (no real DB)
- Firebase: mock `verify_id_token()`
- Routes: `httpx.AsyncClient`
- Coverage target: >80%
- All 6 flows, all error codes, reuse attack, plan upgrade validation

---

## PyPI

```
name: trachea-login
python: >=3.10
publish: GitHub Actions on git tag v*
versioning: 0.1.0 → 0.2.0 → 1.0.0
```

---

## Out of Scope (v0.1.0)

- Phone/OTP auth
- Email verification flow (Firebase handles this for email/password users)
- Password reset for username users (no email — deferred)
- Admin dashboard / app registration UI
- `trachea-login serve` CLI (standalone microservice mode)
- Rate limiting (handled at infrastructure level)
- Multi-factor authentication
