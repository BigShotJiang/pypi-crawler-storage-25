# trachea-login Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and publish `trachea-login`, a pip-installable FastAPI auth package with Firebase identity verification, native username/password auth, MongoDB user storage, JWT tokens, and role/plan-based access control.

**Architecture:** Firebase handles identity verification (social + email/password). After verification, trachea-login issues its own JWT access+refresh tokens and manages all user data in MongoDB. Username+password users bypass Firebase entirely (free plan only). All apps share one MongoDB database; users are scoped per-app via an `apps[]` array.

**Tech Stack:** FastAPI, Motor (async MongoDB), Firebase Admin SDK, python-jose (JWT), passlib/bcrypt, pydantic-settings, mongomock-motor (tests), pytest-asyncio

---

## File Map

```
trachea_login/
├── __init__.py          # TracheaLogin class, get_current_user, require_role (module-level)
├── config.py            # TracheaSettings (pydantic-settings, TRACHEA_ prefix)
├── exceptions.py        # TracheaError, TracheaConfigError, ErrorCode, exception_handler
├── models.py            # All Pydantic request/response schemas + CurrentUser
├── firebase.py          # init_firebase(), verify_firebase_token(), get_provider_from_firebase()
├── tokens.py            # issue_access_token(), verify_access_token(), issue_refresh_token(),
│                        # rotate_refresh_token(), revoke_all_refresh_tokens()
├── db/
│   ├── __init__.py
│   ├── mongo.py         # create_indexes()
│   ├── app_repo.py      # get_app(), verify_app_secret(), hash_secret()
│   └── user_repo.py     # get_by_firebase_uid/username/email, upsert_firebase_user,
│                        # create_username_user, get_app_entry, build_user_response,
│                        # update_profile, deactivate_user, upgrade_plan
├── routers/
│   ├── __init__.py
│   ├── auth.py          # create_auth_router(settings, db) -> APIRouter
│   └── users.py         # create_users_router(settings, db) -> APIRouter
tests/
├── conftest.py          # Shared fixtures: mongo, db, app, client, firebase mock
├── test_config.py
├── test_exceptions.py
├── test_models.py
├── test_mongo.py
├── test_app_repo.py
├── test_user_repo.py
├── test_tokens.py
├── test_firebase.py
├── test_auth_social.py
├── test_auth_username.py
├── test_auth_tokens.py
├── test_users.py
└── test_dependencies.py
pyproject.toml
.env.example
.github/workflows/ci.yml
.github/workflows/publish.yml
README.md
```

---

### Task 1: Project Scaffold

**Files:**
- Create: `pyproject.toml`
- Create: `trachea_login/__init__.py` (empty)
- Create: `trachea_login/db/__init__.py` (empty)
- Create: `trachea_login/routers/__init__.py` (empty)
- Create: `tests/__init__.py` (empty)
- Create: `.env.example`

- [ ] **Step 1: Create directory structure**

```bash
mkdir -p trachea_login/db trachea_login/routers tests
touch trachea_login/__init__.py trachea_login/db/__init__.py trachea_login/routers/__init__.py tests/__init__.py
```

- [ ] **Step 2: Create `pyproject.toml`**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "trachea-login"
version = "0.1.0"
description = "Multi-app authentication package for FastAPI with Firebase and MongoDB"
requires-python = ">=3.10"
dependencies = [
    "fastapi>=0.110.0",
    "motor>=3.3.0",
    "pydantic>=2.0.0",
    "pydantic-settings>=2.0.0",
    "python-jose[cryptography]>=3.3.0",
    "passlib[bcrypt]>=1.7.4",
    "firebase-admin>=6.0.0",
    "httpx>=0.27.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
    "mongomock-motor>=0.0.21",
    "httpx>=0.27.0",
    "pytest-cov>=5.0.0",
]

[project.urls]
Homepage = "https://github.com/trachea-inc/trachea-login"

[tool.pytest.ini_options]
asyncio_mode = "auto"

[tool.hatch.build.targets.wheel]
packages = ["trachea_login"]
```

- [ ] **Step 3: Create `.env.example`**

```bash
# Required
TRACHEA_APP_ID=app1
TRACHEA_APP_SECRET=your-app-secret-key
TRACHEA_MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/trachea
TRACHEA_FIREBASE_CREDENTIALS=path/to/firebase-service-account.json
TRACHEA_JWT_SECRET=your-super-secret-jwt-key-min-32-chars

# Optional (defaults shown)
TRACHEA_ACCESS_TOKEN_EXPIRE_MINUTES=15
TRACHEA_REFRESH_TOKEN_EXPIRE_DAYS=30
TRACHEA_PASSWORD_MIN_LENGTH=8
TRACHEA_DB_NAME=trachea
```

- [ ] **Step 4: Install dev dependencies**

```bash
pip install -e ".[dev]"
```

Expected: installs fastapi, motor, pydantic-settings, python-jose, passlib, firebase-admin, httpx, pytest, pytest-asyncio, mongomock-motor

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml .env.example trachea_login/ tests/
git commit -m "chore: scaffold project structure and pyproject.toml"
```

---

### Task 2: Exceptions

**Files:**
- Create: `trachea_login/exceptions.py`
- Create: `tests/test_exceptions.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_exceptions.py
import pytest
from trachea_login.exceptions import TracheaError, TracheaConfigError, ErrorCode

def test_trachea_error_attributes():
    err = TracheaError(ErrorCode.APP_NOT_FOUND, "App not found", 404)
    assert err.error == "APP_NOT_FOUND"
    assert err.message == "App not found"
    assert err.status_code == 404

def test_trachea_error_is_exception():
    with pytest.raises(TracheaError):
        raise TracheaError(ErrorCode.INVALID_TOKEN, "bad token", 401)

def test_all_error_codes_exist():
    codes = [
        "APP_NOT_FOUND", "APP_INACTIVE", "AUTH_METHOD_NOT_ALLOWED",
        "INVALID_FIREBASE_TOKEN", "INVALID_CREDENTIALS", "USERNAME_TAKEN",
        "EMAIL_TAKEN", "INVALID_TOKEN", "TOKEN_EXPIRED", "REFRESH_TOKEN_INVALID",
        "REFRESH_TOKEN_REUSE", "INSUFFICIENT_ROLE", "INSUFFICIENT_PLAN",
        "EMAIL_REQUIRED_FOR_PAID", "USER_INACTIVE", "VALIDATION_ERROR",
    ]
    for code in codes:
        assert hasattr(ErrorCode, code), f"Missing error code: {code}"
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_exceptions.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.exceptions'`

- [ ] **Step 3: Create `trachea_login/exceptions.py`**

```python
from fastapi import Request
from fastapi.responses import JSONResponse


class TracheaError(Exception):
    def __init__(self, error: str, message: str, status_code: int):
        self.error = error
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class TracheaConfigError(Exception):
    pass


class ErrorCode:
    APP_NOT_FOUND = "APP_NOT_FOUND"
    APP_INACTIVE = "APP_INACTIVE"
    AUTH_METHOD_NOT_ALLOWED = "AUTH_METHOD_NOT_ALLOWED"
    INVALID_FIREBASE_TOKEN = "INVALID_FIREBASE_TOKEN"
    INVALID_CREDENTIALS = "INVALID_CREDENTIALS"
    USERNAME_TAKEN = "USERNAME_TAKEN"
    EMAIL_TAKEN = "EMAIL_TAKEN"
    INVALID_TOKEN = "INVALID_TOKEN"
    TOKEN_EXPIRED = "TOKEN_EXPIRED"
    REFRESH_TOKEN_INVALID = "REFRESH_TOKEN_INVALID"
    REFRESH_TOKEN_REUSE = "REFRESH_TOKEN_REUSE"
    INSUFFICIENT_ROLE = "INSUFFICIENT_ROLE"
    INSUFFICIENT_PLAN = "INSUFFICIENT_PLAN"
    EMAIL_REQUIRED_FOR_PAID = "EMAIL_REQUIRED_FOR_PAID"
    USER_INACTIVE = "USER_INACTIVE"
    VALIDATION_ERROR = "VALIDATION_ERROR"


async def trachea_exception_handler(request: Request, exc: TracheaError) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.error, "message": exc.message, "status_code": exc.status_code},
    )
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_exceptions.py -v
```

Expected: 3 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/exceptions.py tests/test_exceptions.py
git commit -m "feat: add custom exceptions and error codes"
```

---

### Task 3: Configuration

**Files:**
- Create: `trachea_login/config.py`
- Create: `tests/test_config.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_config.py
import pytest
from trachea_login.config import TracheaSettings


def test_settings_load_from_env(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "testapp")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "secret123")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost:27017/test")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", '{"type": "service_account"}')
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "jwt-secret-key-32-chars-minimum!!")

    settings = TracheaSettings()
    assert settings.app_id == "testapp"
    assert settings.app_secret == "secret123"
    assert settings.access_token_expire_minutes == 15
    assert settings.refresh_token_expire_days == 30
    assert settings.db_name == "trachea"


def test_settings_defaults(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "s")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", "{}")
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "secret")

    settings = TracheaSettings()
    assert settings.password_min_length == 8


def test_get_firebase_credentials_from_json_string(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "s")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", '{"type":"service_account","project_id":"proj"}')
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "secret")

    settings = TracheaSettings()
    creds = settings.get_firebase_credentials_dict()
    assert creds["type"] == "service_account"
    assert creds["project_id"] == "proj"
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_config.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.config'`

- [ ] **Step 3: Create `trachea_login/config.py`**

```python
import json
from pydantic_settings import BaseSettings, SettingsConfigDict


class TracheaSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="TRACHEA_",
        env_file=".env",
        extra="ignore",
    )

    app_id: str
    app_secret: str
    mongo_uri: str
    firebase_credentials: str  # JSON string or file path
    jwt_secret: str
    access_token_expire_minutes: int = 15
    refresh_token_expire_days: int = 30
    password_min_length: int = 8
    db_name: str = "trachea"

    def get_firebase_credentials_dict(self) -> dict:
        try:
            return json.loads(self.firebase_credentials)
        except (json.JSONDecodeError, ValueError):
            with open(self.firebase_credentials) as f:
                return json.load(f)
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_config.py -v
```

Expected: 3 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/config.py tests/test_config.py
git commit -m "feat: add TracheaSettings with pydantic-settings"
```

---

### Task 4: Pydantic Models

**Files:**
- Create: `trachea_login/models.py`
- Create: `tests/test_models.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_models.py
import pytest
from datetime import datetime, timezone
from trachea_login.models import (
    LoginRequest, RegisterRequest, RefreshRequest,
    UpdateProfileRequest, UpdatePlanRequest,
    UserResponse, LoginResponse, TokenResponse, CurrentUser,
)


def test_login_request_firebase():
    req = LoginRequest(firebase_token="tok123", app_id="app1")
    assert req.firebase_token == "tok123"
    assert req.username is None


def test_login_request_username():
    req = LoginRequest(username="johndoe", password="pass123", app_id="app1")
    assert req.username == "johndoe"
    assert req.firebase_token is None


def test_register_request():
    req = RegisterRequest(username="johndoe", password="pass123", app_id="app1")
    assert req.name is None


def test_update_plan_requires_plan_field():
    req = UpdatePlanRequest(plan="pro")
    assert req.plan == "pro"
    assert req.email is None


def test_current_user_from_jwt_payload():
    user = CurrentUser(sub="uid123", app_id="app1", role="member", plan="free", provider="google")
    assert user.sub == "uid123"


def test_user_response_fields():
    now = datetime.now(timezone.utc)
    user = UserResponse(
        provider="google", app_id="app1", role="member", plan="free", joined_at=now
    )
    assert user.firebase_uid is None
    assert user.email is None
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_models.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.models'`

- [ ] **Step 3: Create `trachea_login/models.py`**

```python
from __future__ import annotations
from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class Address(BaseModel):
    street: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    zip: Optional[str] = None


class CurrentUser(BaseModel):
    """Decoded JWT payload — used in FastAPI dependencies."""
    sub: str        # firebase_uid or username
    app_id: str
    role: str
    plan: str
    provider: str


class UserResponse(BaseModel):
    firebase_uid: Optional[str] = None
    username: Optional[str] = None
    email: Optional[str] = None
    name: Optional[str] = None
    avatar: Optional[str] = None
    provider: str
    app_id: str
    role: str
    plan: str
    joined_at: datetime


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class LoginResponse(TokenResponse):
    user: UserResponse


class LoginRequest(BaseModel):
    firebase_token: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    app_id: str


class RegisterRequest(BaseModel):
    username: str
    password: str
    name: Optional[str] = None
    app_id: str


class RefreshRequest(BaseModel):
    refresh_token: str
    app_id: str


class UpdateProfileRequest(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    date_of_birth: Optional[str] = None
    address: Optional[Address] = None


class UpdatePlanRequest(BaseModel):
    plan: str
    email: Optional[str] = None
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_models.py -v
```

Expected: 6 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/models.py tests/test_models.py
git commit -m "feat: add Pydantic request/response models"
```

---

### Task 5: MongoDB Connection + Indexes

**Files:**
- Create: `trachea_login/db/mongo.py`
- Create: `tests/test_mongo.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_mongo.py
import pytest
import mongomock_motor
from trachea_login.db.mongo import create_indexes


@pytest.fixture
def db():
    client = mongomock_motor.AsyncMongoMockClient()
    return client["trachea_test"]


async def test_create_indexes_runs_without_error(db):
    # Should not raise
    await create_indexes(db)


async def test_create_indexes_idempotent(db):
    # Running twice should not raise
    await create_indexes(db)
    await create_indexes(db)
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_mongo.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.db.mongo'`

- [ ] **Step 3: Create `trachea_login/db/mongo.py`**

```python
from motor.motor_asyncio import AsyncIOMotorDatabase


async def create_indexes(db: AsyncIOMotorDatabase) -> None:
    """Create all required MongoDB indexes. Safe to call multiple times."""
    await db.users.create_index("firebase_uid", unique=True, sparse=True)
    await db.users.create_index("email", unique=True, sparse=True)
    await db.users.create_index("username", unique=True, sparse=True)
    await db.users.create_index("apps.app_id")
    await db.apps.create_index("app_id", unique=True)
    await db.refresh_tokens.create_index("token_hash")
    await db.refresh_tokens.create_index(
        "expires_at", expireAfterSeconds=0
    )
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_mongo.py -v
```

Expected: 2 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/db/mongo.py tests/test_mongo.py
git commit -m "feat: add MongoDB connection and index creation"
```

---

### Task 6: App Repository

**Files:**
- Create: `trachea_login/db/app_repo.py`
- Create: `tests/test_app_repo.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_app_repo.py
import pytest
import mongomock_motor
from datetime import datetime, timezone
from trachea_login.db.app_repo import get_app, verify_app_secret, hash_secret


@pytest.fixture
def db():
    client = mongomock_motor.AsyncMongoMockClient()
    return client["trachea_test"]


@pytest.fixture
async def sample_app(db):
    secret_hash = await hash_secret("mysecret")
    doc = {
        "app_id": "app1",
        "app_secret": secret_hash,
        "name": "Test App",
        "allowed_auth_methods": ["google", "password", "username"],
        "allowed_domains": ["localhost"],
        "is_active": True,
        "created_at": datetime.now(timezone.utc),
    }
    await db.apps.insert_one(doc)
    return doc


async def test_get_app_found(db, sample_app):
    app = await get_app(db, "app1")
    assert app is not None
    assert app["app_id"] == "app1"


async def test_get_app_not_found(db):
    app = await get_app(db, "nonexistent")
    assert app is None


async def test_verify_app_secret_correct(db, sample_app):
    result = await verify_app_secret(sample_app["app_secret"], "mysecret")
    assert result is True


async def test_verify_app_secret_wrong(db, sample_app):
    result = await verify_app_secret(sample_app["app_secret"], "wrongsecret")
    assert result is False
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_app_repo.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.db.app_repo'`

- [ ] **Step 3: Create `trachea_login/db/app_repo.py`**

```python
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorDatabase
from passlib.context import CryptContext

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


async def get_app(db: AsyncIOMotorDatabase, app_id: str) -> Optional[dict]:
    return await db.apps.find_one({"app_id": app_id})


async def verify_app_secret(stored_hash: str, secret: str) -> bool:
    return _pwd.verify(secret, stored_hash)


async def hash_secret(secret: str) -> str:
    return _pwd.hash(secret)
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_app_repo.py -v
```

Expected: 4 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/db/app_repo.py tests/test_app_repo.py
git commit -m "feat: add app repository (get, verify secret)"
```

---

### Task 7: User Repository

**Files:**
- Create: `trachea_login/db/user_repo.py`
- Create: `tests/test_user_repo.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_user_repo.py
import pytest
import mongomock_motor
from datetime import datetime, timezone
from trachea_login.db.user_repo import (
    get_by_firebase_uid, get_by_username, upsert_firebase_user,
    create_username_user, get_app_entry, build_user_response,
    update_profile, deactivate_user, upgrade_plan,
)


@pytest.fixture
def db():
    client = mongomock_motor.AsyncMongoMockClient()
    return client["trachea_test"]


async def test_upsert_firebase_user_creates_new(db):
    user = await upsert_firebase_user(
        db, firebase_uid="uid1", app_id="app1",
        email="a@b.com", name="Alice", avatar=None, provider="google"
    )
    assert user["firebase_uid"] == "uid1"
    assert len(user["apps"]) == 1
    assert user["apps"][0]["app_id"] == "app1"
    assert user["apps"][0]["plan"] == "free"


async def test_upsert_firebase_user_adds_new_app(db):
    await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    user = await upsert_firebase_user(db, "uid1", "app2", "a@b.com", "Alice", None, "google")
    assert len(user["apps"]) == 2


async def test_upsert_firebase_user_same_app_no_duplicate(db):
    await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice Updated", None, "google")
    assert len(user["apps"]) == 1
    assert user["name"] == "Alice Updated"


async def test_create_username_user(db):
    user = await create_username_user(db, "johndoe", "hashed", "John", "app1")
    assert user["username"] == "johndoe"
    assert user["firebase_uid"] is None
    assert user["apps"][0]["plan"] == "free"


async def test_get_by_firebase_uid(db):
    await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    user = await get_by_firebase_uid(db, "uid1")
    assert user is not None


async def test_get_by_username(db):
    await create_username_user(db, "johndoe", "hashed", "John", "app1")
    user = await get_by_username(db, "johndoe")
    assert user is not None


async def test_get_app_entry(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "A", None, "google")
    entry = get_app_entry(user, "app1")
    assert entry["role"] == "member"


async def test_get_app_entry_missing_returns_none(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "A", None, "google")
    assert get_app_entry(user, "app99") is None


async def test_build_user_response(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    resp = build_user_response(user, "app1")
    assert resp["app_id"] == "app1"
    assert resp["role"] == "member"
    assert resp["plan"] == "free"
    assert resp["provider"] == "google"


async def test_deactivate_user(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    await deactivate_user(db, user["_id"])
    updated = await get_by_firebase_uid(db, "uid1")
    assert updated["is_active"] is False


async def test_upgrade_plan_requires_email_for_username_user(db):
    user = await create_username_user(db, "johndoe", "hashed", "John", "app1")
    updated = await upgrade_plan(db, user["_id"], "app1", "pro", email="john@example.com")
    entry = get_app_entry(updated, "app1")
    assert entry["plan"] == "pro"
    assert updated["email"] == "john@example.com"
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_user_repo.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.db.user_repo'`

- [ ] **Step 3: Create `trachea_login/db/user_repo.py`**

```python
from __future__ import annotations
from datetime import datetime, timezone
from typing import Optional
from motor.motor_asyncio import AsyncIOMotorDatabase


async def get_by_firebase_uid(db: AsyncIOMotorDatabase, firebase_uid: str) -> Optional[dict]:
    return await db.users.find_one({"firebase_uid": firebase_uid})


async def get_by_username(db: AsyncIOMotorDatabase, username: str) -> Optional[dict]:
    return await db.users.find_one({"username": username})


async def get_by_email(db: AsyncIOMotorDatabase, email: str) -> Optional[dict]:
    return await db.users.find_one({"email": email})


def get_app_entry(user_doc: dict, app_id: str) -> Optional[dict]:
    for entry in user_doc.get("apps", []):
        if entry["app_id"] == app_id:
            return entry
    return None


def build_user_response(user_doc: dict, app_id: str) -> dict:
    entry = get_app_entry(user_doc, app_id) or {
        "role": "member", "plan": "free", "joined_at": datetime.now(timezone.utc)
    }
    return {
        "firebase_uid": user_doc.get("firebase_uid"),
        "username": user_doc.get("username"),
        "email": user_doc.get("email"),
        "name": user_doc.get("name"),
        "avatar": user_doc.get("avatar"),
        "provider": user_doc["provider"],
        "app_id": app_id,
        "role": entry["role"],
        "plan": entry["plan"],
        "joined_at": entry["joined_at"],
    }


async def upsert_firebase_user(
    db: AsyncIOMotorDatabase,
    firebase_uid: str,
    app_id: str,
    email: str,
    name: Optional[str],
    avatar: Optional[str],
    provider: str,
) -> dict:
    now = datetime.now(timezone.utc)
    existing = await get_by_firebase_uid(db, firebase_uid)

    if existing is None:
        doc = {
            "firebase_uid": firebase_uid,
            "email": email,
            "username": None,
            "password_hash": None,
            "name": name,
            "avatar": avatar,
            "phone": None,
            "date_of_birth": None,
            "address": None,
            "provider": provider,
            "is_active": True,
            "apps": [{"app_id": app_id, "role": "member", "plan": "free", "joined_at": now}],
            "created_at": now,
            "updated_at": now,
        }
        await db.users.insert_one(doc)
    else:
        app_ids = [a["app_id"] for a in existing.get("apps", [])]
        set_fields: dict = {"updated_at": now, "name": name, "avatar": avatar}
        push_fields: dict = {}
        if app_id not in app_ids:
            push_fields["apps"] = {"app_id": app_id, "role": "member", "plan": "free", "joined_at": now}
        update: dict = {"$set": set_fields}
        if push_fields:
            update["$push"] = push_fields
        await db.users.update_one({"firebase_uid": firebase_uid}, update)

    return await get_by_firebase_uid(db, firebase_uid)


async def create_username_user(
    db: AsyncIOMotorDatabase,
    username: str,
    password_hash: str,
    name: Optional[str],
    app_id: str,
) -> dict:
    now = datetime.now(timezone.utc)
    doc = {
        "firebase_uid": None,
        "email": None,
        "username": username,
        "password_hash": password_hash,
        "name": name,
        "avatar": None,
        "phone": None,
        "date_of_birth": None,
        "address": None,
        "provider": "username",
        "is_active": True,
        "apps": [{"app_id": app_id, "role": "member", "plan": "free", "joined_at": now}],
        "created_at": now,
        "updated_at": now,
    }
    await db.users.insert_one(doc)
    return await get_by_username(db, username)


async def update_profile(db: AsyncIOMotorDatabase, user_id, updates: dict) -> dict:
    updates["updated_at"] = datetime.now(timezone.utc)
    await db.users.update_one({"_id": user_id}, {"$set": updates})
    return await db.users.find_one({"_id": user_id})


async def deactivate_user(db: AsyncIOMotorDatabase, user_id) -> None:
    await db.users.update_one(
        {"_id": user_id},
        {"$set": {"is_active": False, "updated_at": datetime.now(timezone.utc)}},
    )


async def upgrade_plan(
    db: AsyncIOMotorDatabase,
    user_id,
    app_id: str,
    plan: str,
    email: Optional[str],
) -> dict:
    now = datetime.now(timezone.utc)
    set_fields: dict = {"apps.$[elem].plan": plan, "updated_at": now}
    if email:
        set_fields["email"] = email
    await db.users.update_one(
        {"_id": user_id},
        {"$set": set_fields},
        array_filters=[{"elem.app_id": app_id}],
    )
    return await db.users.find_one({"_id": user_id})
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_user_repo.py -v
```

Expected: 11 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/db/user_repo.py tests/test_user_repo.py
git commit -m "feat: add user repository (upsert, create, profile, plan upgrade)"
```

---

### Task 8: Token Management

**Files:**
- Create: `trachea_login/tokens.py`
- Create: `tests/test_tokens.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_tokens.py
import pytest
import mongomock_motor
from datetime import datetime, timezone, timedelta
from trachea_login.config import TracheaSettings
from trachea_login.exceptions import TracheaError, ErrorCode
from trachea_login.tokens import (
    issue_access_token, verify_access_token,
    issue_refresh_token, rotate_refresh_token, revoke_all_refresh_tokens,
)


@pytest.fixture
def settings(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "s")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", "{}")
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "test-secret-key-for-jwt-signing!!")
    return TracheaSettings()


@pytest.fixture
def db():
    client = mongomock_motor.AsyncMongoMockClient()
    return client["trachea_test"]


def test_issue_and_verify_access_token(settings):
    token = issue_access_token(settings, "uid1", "app1", "member", "free", "google")
    payload = verify_access_token(settings, token)
    assert payload["sub"] == "uid1"
    assert payload["app_id"] == "app1"
    assert payload["role"] == "member"
    assert payload["plan"] == "free"
    assert payload["provider"] == "google"


def test_verify_access_token_invalid(settings):
    with pytest.raises(TracheaError) as exc_info:
        verify_access_token(settings, "not-a-valid-token")
    assert exc_info.value.error == ErrorCode.INVALID_TOKEN


def test_verify_access_token_expired(settings):
    from jose import jwt as jose_jwt
    import time
    payload = {
        "sub": "uid1", "app_id": "app1", "role": "member",
        "plan": "free", "provider": "google",
        "exp": int(time.time()) - 1,  # already expired
        "iat": int(time.time()) - 60,
    }
    token = jose_jwt.encode(payload, settings.jwt_secret, algorithm="HS256")
    with pytest.raises(TracheaError) as exc_info:
        verify_access_token(settings, token)
    assert exc_info.value.error == ErrorCode.TOKEN_EXPIRED


async def test_issue_and_rotate_refresh_token(db, settings):
    raw = await issue_refresh_token(db, settings, "uid1", None, "app1")
    assert isinstance(raw, str)
    assert len(raw) > 20

    new_raw, firebase_uid, username = await rotate_refresh_token(db, settings, raw, "app1")
    assert firebase_uid == "uid1"
    assert username is None
    assert new_raw != raw


async def test_rotate_refresh_token_reuse_revokes_all(db, settings):
    raw = await issue_refresh_token(db, settings, "uid1", None, "app1")
    # First rotation is valid
    new_raw, _, _ = await rotate_refresh_token(db, settings, raw, "app1")
    # Reusing the old token triggers reuse detection
    with pytest.raises(TracheaError) as exc_info:
        await rotate_refresh_token(db, settings, raw, "app1")
    assert exc_info.value.error == ErrorCode.REFRESH_TOKEN_REUSE
    # New token should also be revoked now
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, new_raw, "app1")


async def test_revoke_all_refresh_tokens(db, settings):
    raw1 = await issue_refresh_token(db, settings, "uid1", None, "app1")
    raw2 = await issue_refresh_token(db, settings, "uid1", None, "app1")
    await revoke_all_refresh_tokens(db, "uid1", None, "app1")
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, raw1, "app1")
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, raw2, "app1")
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_tokens.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.tokens'`

- [ ] **Step 3: Create `trachea_login/tokens.py`**

```python
from __future__ import annotations
import hashlib
import secrets
from datetime import datetime, timezone, timedelta
from typing import Optional

from jose import ExpiredSignatureError, JWTError
from jose import jwt as jose_jwt
from motor.motor_asyncio import AsyncIOMotorDatabase

from trachea_login.config import TracheaSettings
from trachea_login.exceptions import ErrorCode, TracheaError


def issue_access_token(
    settings: TracheaSettings,
    sub: str,
    app_id: str,
    role: str,
    plan: str,
    provider: str,
) -> str:
    now = datetime.now(timezone.utc)
    expire = now + timedelta(minutes=settings.access_token_expire_minutes)
    payload = {
        "sub": sub,
        "app_id": app_id,
        "role": role,
        "plan": plan,
        "provider": provider,
        "exp": expire,
        "iat": now,
    }
    return jose_jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def verify_access_token(settings: TracheaSettings, token: str) -> dict:
    try:
        return jose_jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])
    except ExpiredSignatureError:
        raise TracheaError(ErrorCode.TOKEN_EXPIRED, "Access token has expired", 401)
    except JWTError:
        raise TracheaError(ErrorCode.INVALID_TOKEN, "Invalid access token", 401)


def _hash_token(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


async def issue_refresh_token(
    db: AsyncIOMotorDatabase,
    settings: TracheaSettings,
    firebase_uid: Optional[str],
    username: Optional[str],
    app_id: str,
) -> str:
    raw = secrets.token_urlsafe(64)
    now = datetime.now(timezone.utc)
    await db.refresh_tokens.insert_one({
        "token_hash": _hash_token(raw),
        "firebase_uid": firebase_uid,
        "username": username,
        "app_id": app_id,
        "expires_at": now + timedelta(days=settings.refresh_token_expire_days),
        "revoked": False,
        "created_at": now,
    })
    return raw


async def rotate_refresh_token(
    db: AsyncIOMotorDatabase,
    settings: TracheaSettings,
    raw_token: str,
    app_id: str,
) -> tuple[str, Optional[str], Optional[str]]:
    """Returns (new_raw_token, firebase_uid, username). Raises TracheaError on any problem."""
    stored = await db.refresh_tokens.find_one(
        {"token_hash": _hash_token(raw_token), "app_id": app_id}
    )

    if stored is None:
        raise TracheaError(ErrorCode.REFRESH_TOKEN_INVALID, "Refresh token not found", 401)

    if stored["revoked"]:
        # Reuse attack: revoke all tokens for this identity + app
        query: dict = {"app_id": app_id}
        if stored.get("firebase_uid"):
            query["firebase_uid"] = stored["firebase_uid"]
        elif stored.get("username"):
            query["username"] = stored["username"]
        await db.refresh_tokens.update_many(query, {"$set": {"revoked": True}})
        raise TracheaError(ErrorCode.REFRESH_TOKEN_REUSE, "Refresh token reuse detected", 401)

    if stored["expires_at"].replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        raise TracheaError(ErrorCode.REFRESH_TOKEN_INVALID, "Refresh token has expired", 401)

    await db.refresh_tokens.update_one(
        {"token_hash": _hash_token(raw_token)}, {"$set": {"revoked": True}}
    )

    firebase_uid: Optional[str] = stored.get("firebase_uid")
    username: Optional[str] = stored.get("username")
    new_raw = await issue_refresh_token(db, settings, firebase_uid, username, app_id)
    return new_raw, firebase_uid, username


async def revoke_all_refresh_tokens(
    db: AsyncIOMotorDatabase,
    firebase_uid: Optional[str],
    username: Optional[str],
    app_id: str,
) -> None:
    query: dict = {"app_id": app_id}
    if firebase_uid:
        query["firebase_uid"] = firebase_uid
    elif username:
        query["username"] = username
    await db.refresh_tokens.update_many(query, {"$set": {"revoked": True}})
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_tokens.py -v
```

Expected: 7 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/tokens.py tests/test_tokens.py
git commit -m "feat: add JWT access tokens and opaque refresh token rotation"
```

---

### Task 9: Firebase Integration

**Files:**
- Create: `trachea_login/firebase.py`
- Create: `tests/test_firebase.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_firebase.py
import pytest
from unittest.mock import patch, MagicMock
from trachea_login.exceptions import TracheaError, ErrorCode
from trachea_login.firebase import verify_firebase_token, get_provider_from_firebase


@pytest.fixture
def decoded_google_token():
    return {
        "uid": "firebase-uid-123",
        "email": "test@example.com",
        "name": "Test User",
        "picture": "https://avatar.url/photo.jpg",
        "firebase": {"sign_in_provider": "google.com"},
    }


def test_verify_firebase_token_success(decoded_google_token):
    with patch("firebase_admin.auth.verify_id_token", return_value=decoded_google_token):
        result = verify_firebase_token("valid-firebase-token")
    assert result["uid"] == "firebase-uid-123"
    assert result["email"] == "test@example.com"


def test_verify_firebase_token_failure():
    with patch("firebase_admin.auth.verify_id_token", side_effect=Exception("invalid")):
        with pytest.raises(TracheaError) as exc_info:
            verify_firebase_token("bad-token")
    assert exc_info.value.error == ErrorCode.INVALID_FIREBASE_TOKEN
    assert exc_info.value.status_code == 401


def test_get_provider_google(decoded_google_token):
    assert get_provider_from_firebase(decoded_google_token) == "google"


def test_get_provider_facebook():
    token = {"firebase": {"sign_in_provider": "facebook.com"}}
    assert get_provider_from_firebase(token) == "facebook"


def test_get_provider_apple():
    token = {"firebase": {"sign_in_provider": "apple.com"}}
    assert get_provider_from_firebase(token) == "apple"


def test_get_provider_password():
    token = {"firebase": {"sign_in_provider": "password"}}
    assert get_provider_from_firebase(token) == "password"
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_firebase.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.firebase'`

- [ ] **Step 3: Create `trachea_login/firebase.py`**

```python
from __future__ import annotations
import firebase_admin
from firebase_admin import auth, credentials

from trachea_login.config import TracheaSettings
from trachea_login.exceptions import ErrorCode, TracheaError

_PROVIDER_MAP = {
    "google.com": "google",
    "facebook.com": "facebook",
    "apple.com": "apple",
    "password": "password",
}


def init_firebase(settings: TracheaSettings) -> None:
    """Initialize Firebase Admin SDK. Safe to call multiple times (no-op if already initialized)."""
    if not firebase_admin._apps:
        cred_dict = settings.get_firebase_credentials_dict()
        cred = credentials.Certificate(cred_dict)
        firebase_admin.initialize_app(cred)


def verify_firebase_token(token: str) -> dict:
    """Verify a Firebase ID token. Returns decoded token dict with uid, email, name, picture."""
    try:
        return auth.verify_id_token(token)
    except Exception:
        raise TracheaError(
            ErrorCode.INVALID_FIREBASE_TOKEN, "Invalid or expired Firebase token", 401
        )


def get_provider_from_firebase(decoded_token: dict) -> str:
    """Extract normalized provider name from a decoded Firebase token."""
    sign_in_provider = decoded_token.get("firebase", {}).get("sign_in_provider", "password")
    return _PROVIDER_MAP.get(sign_in_provider, "password")
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_firebase.py -v
```

Expected: 6 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/firebase.py tests/test_firebase.py
git commit -m "feat: add Firebase token verification and provider mapping"
```

---

### Task 10: Shared Test Fixtures (conftest.py)

**Files:**
- Create: `tests/conftest.py`

- [ ] **Step 1: Create `tests/conftest.py`**

```python
# tests/conftest.py
import pytest
import mongomock_motor
from datetime import datetime, timezone
from unittest.mock import patch, AsyncMock
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport

from trachea_login.config import TracheaSettings
from trachea_login.db.app_repo import hash_secret
from trachea_login.db.mongo import create_indexes
from trachea_login.db.user_repo import upsert_firebase_user, create_username_user
from trachea_login.tokens import issue_access_token, issue_refresh_token
from passlib.context import CryptContext

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


@pytest.fixture
def settings(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "appsecret123")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", '{"type":"service_account"}')
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "test-jwt-secret-key-for-tests-only!!")
    return TracheaSettings()


@pytest.fixture
def mongo_client():
    return mongomock_motor.AsyncMongoMockClient()


@pytest.fixture
def db(mongo_client):
    return mongo_client["trachea_test"]


@pytest.fixture
async def initialized_db(db):
    await create_indexes(db)
    return db


@pytest.fixture
async def sample_app(initialized_db):
    secret_hash = await hash_secret("appsecret123")
    doc = {
        "app_id": "app1",
        "app_secret": secret_hash,
        "name": "Test App",
        "allowed_auth_methods": ["google", "facebook", "apple", "password", "username"],
        "allowed_domains": ["localhost"],
        "is_active": True,
        "created_at": datetime.now(timezone.utc),
    }
    await initialized_db.apps.insert_one(doc)
    return doc


@pytest.fixture
async def firebase_user(initialized_db, sample_app):
    return await upsert_firebase_user(
        initialized_db, "firebase-uid-123", "app1",
        "test@example.com", "Test User", "https://avatar.url", "google"
    )


@pytest.fixture
async def username_user(initialized_db, sample_app):
    return await create_username_user(
        initialized_db, "johndoe", _pwd.hash("Password123"), "John Doe", "app1"
    )


@pytest.fixture
def access_token(settings, firebase_user):
    return issue_access_token(
        settings, "firebase-uid-123", "app1", "member", "free", "google"
    )


@pytest.fixture
def username_access_token(settings, username_user):
    return issue_access_token(
        settings, "johndoe", "app1", "member", "free", "username"
    )


@pytest.fixture
def mock_firebase():
    decoded = {
        "uid": "firebase-uid-123",
        "email": "test@example.com",
        "name": "Test User",
        "picture": "https://avatar.url",
        "firebase": {"sign_in_provider": "google.com"},
    }
    with patch("trachea_login.firebase.auth.verify_id_token", return_value=decoded):
        yield decoded


@pytest.fixture
def mock_firebase_init():
    with patch("trachea_login.firebase.init_firebase"):
        yield


@pytest.fixture
async def app_and_client(settings, initialized_db, sample_app, mock_firebase_init):
    """Returns (fastapi_app, httpx_client) with trachea router mounted."""
    from trachea_login.routers.auth import create_auth_router
    from trachea_login.routers.users import create_users_router
    from trachea_login.exceptions import TracheaError, trachea_exception_handler

    fastapi_app = FastAPI()
    fastapi_app.add_exception_handler(TracheaError, trachea_exception_handler)
    fastapi_app.include_router(create_auth_router(settings, initialized_db), prefix="/auth")
    fastapi_app.include_router(create_users_router(settings, initialized_db), prefix="/users")

    async with AsyncClient(
        transport=ASGITransport(app=fastapi_app), base_url="http://test"
    ) as client:
        yield fastapi_app, client
```

- [ ] **Step 2: Verify conftest loads without errors**

```bash
pytest tests/ --collect-only 2>&1 | head -20
```

Expected: no import errors, test collection begins

- [ ] **Step 3: Commit**

```bash
git add tests/conftest.py
git commit -m "test: add shared fixtures in conftest.py"
```

---

### Task 11: Auth Router — Firebase Login

**Files:**
- Create: `trachea_login/routers/auth.py` (Firebase login endpoint only)
- Create: `tests/test_auth_social.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_auth_social.py
import pytest


async def test_firebase_login_success(app_and_client, mock_firebase):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "firebase_token": "valid-firebase-token",
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["token_type"] == "bearer"
    assert data["user"]["email"] == "test@example.com"
    assert data["user"]["provider"] == "google"
    assert data["user"]["plan"] == "free"
    assert data["user"]["role"] == "member"


async def test_firebase_login_invalid_app(app_and_client, mock_firebase):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "firebase_token": "tok",
        "app_id": "nonexistent"
    })
    assert resp.status_code == 404
    assert resp.json()["error"] == "APP_NOT_FOUND"


async def test_firebase_login_inactive_app(app_and_client, mock_firebase, initialized_db):
    await initialized_db.apps.update_one({"app_id": "app1"}, {"$set": {"is_active": False}})
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "firebase_token": "tok",
        "app_id": "app1"
    })
    assert resp.status_code == 403
    assert resp.json()["error"] == "APP_INACTIVE"


async def test_firebase_login_method_not_allowed(app_and_client, mock_firebase, initialized_db):
    await initialized_db.apps.update_one(
        {"app_id": "app1"}, {"$set": {"allowed_auth_methods": ["username"]}}
    )
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "firebase_token": "tok",
        "app_id": "app1"
    })
    assert resp.status_code == 403
    assert resp.json()["error"] == "AUTH_METHOD_NOT_ALLOWED"


async def test_firebase_login_invalid_token(app_and_client):
    from unittest.mock import patch
    _, client = app_and_client
    with patch("trachea_login.firebase.auth.verify_id_token", side_effect=Exception("bad")):
        resp = await client.post("/auth/login", json={
            "firebase_token": "bad-token",
            "app_id": "app1"
        })
    assert resp.status_code == 401
    assert resp.json()["error"] == "INVALID_FIREBASE_TOKEN"


async def test_second_login_same_user_same_app(app_and_client, mock_firebase):
    _, client = app_and_client
    resp1 = await client.post("/auth/login", json={"firebase_token": "tok", "app_id": "app1"})
    resp2 = await client.post("/auth/login", json={"firebase_token": "tok", "app_id": "app1"})
    assert resp1.status_code == 200
    assert resp2.status_code == 200
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_auth_social.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.routers.auth'`

- [ ] **Step 3: Create `trachea_login/routers/auth.py`**

```python
from __future__ import annotations
from fastapi import APIRouter
from motor.motor_asyncio import AsyncIOMotorDatabase

from trachea_login.config import TracheaSettings
from trachea_login.db.app_repo import get_app
from trachea_login.db.user_repo import (
    build_user_response, create_username_user,
    get_by_firebase_uid, get_by_username, upsert_firebase_user,
)
from trachea_login.exceptions import ErrorCode, TracheaError
from trachea_login.firebase import get_provider_from_firebase, verify_firebase_token
from trachea_login.models import LoginRequest, LoginResponse, RefreshRequest, RegisterRequest, TokenResponse
from trachea_login.tokens import (
    issue_access_token, issue_refresh_token,
    revoke_all_refresh_tokens, rotate_refresh_token,
)
from fastapi import Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from trachea_login.tokens import verify_access_token
from passlib.context import CryptContext

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
_bearer = HTTPBearer()


def _validate_app(app_doc: dict | None, method: str) -> None:
    if app_doc is None:
        raise TracheaError(ErrorCode.APP_NOT_FOUND, f"App not found", 404)
    if not app_doc.get("is_active"):
        raise TracheaError(ErrorCode.APP_INACTIVE, "App is inactive", 403)
    if method not in app_doc.get("allowed_auth_methods", []):
        raise TracheaError(
            ErrorCode.AUTH_METHOD_NOT_ALLOWED,
            f"Auth method '{method}' is not allowed for this app",
            403,
        )


def create_auth_router(settings: TracheaSettings, db: AsyncIOMotorDatabase) -> APIRouter:
    router = APIRouter(tags=["auth"])

    @router.post("/login", response_model=LoginResponse)
    async def login(request: LoginRequest):
        app_doc = await get_app(db, request.app_id)

        # Firebase path
        if request.firebase_token:
            decoded = verify_firebase_token(request.firebase_token)
            provider = get_provider_from_firebase(decoded)
            _validate_app(app_doc, provider)

            user = await upsert_firebase_user(
                db,
                firebase_uid=decoded["uid"],
                app_id=request.app_id,
                email=decoded.get("email", ""),
                name=decoded.get("name"),
                avatar=decoded.get("picture"),
                provider=provider,
            )
            if not user.get("is_active"):
                raise TracheaError(ErrorCode.USER_INACTIVE, "User account is deactivated", 403)

            user_resp = build_user_response(user, request.app_id)
            access_token = issue_access_token(
                settings, decoded["uid"], request.app_id,
                user_resp["role"], user_resp["plan"], provider
            )
            refresh_token = await issue_refresh_token(db, settings, decoded["uid"], None, request.app_id)
            return LoginResponse(
                access_token=access_token,
                refresh_token=refresh_token,
                user=user_resp,
            )

        # Username path
        if request.username and request.password:
            _validate_app(app_doc, "username")
            user = await get_by_username(db, request.username)
            if user is None or not _pwd.verify(request.password, user.get("password_hash", "")):
                raise TracheaError(ErrorCode.INVALID_CREDENTIALS, "Invalid username or password", 401)
            if not user.get("is_active"):
                raise TracheaError(ErrorCode.USER_INACTIVE, "User account is deactivated", 403)

            user_resp = build_user_response(user, request.app_id)
            access_token = issue_access_token(
                settings, request.username, request.app_id,
                user_resp["role"], user_resp["plan"], "username"
            )
            refresh_token = await issue_refresh_token(db, settings, None, request.username, request.app_id)
            return LoginResponse(access_token=access_token, refresh_token=refresh_token, user=user_resp)

        raise TracheaError(
            ErrorCode.VALIDATION_ERROR,
            "Provide either firebase_token or username+password",
            422,
        )

    @router.post("/register", response_model=LoginResponse)
    async def register(request: RegisterRequest):
        if len(request.password) < settings.password_min_length:
            raise TracheaError(
                ErrorCode.VALIDATION_ERROR,
                f"Password must be at least {settings.password_min_length} characters",
                422,
            )
        app_doc = await get_app(db, request.app_id)
        _validate_app(app_doc, "username")

        existing = await get_by_username(db, request.username)
        if existing:
            raise TracheaError(ErrorCode.USERNAME_TAKEN, "Username already taken", 409)

        password_hash = _pwd.hash(request.password)
        user = await create_username_user(db, request.username, password_hash, request.name, request.app_id)
        user_resp = build_user_response(user, request.app_id)
        access_token = issue_access_token(
            settings, request.username, request.app_id,
            user_resp["role"], user_resp["plan"], "username"
        )
        refresh_token = await issue_refresh_token(db, settings, None, request.username, request.app_id)
        return LoginResponse(access_token=access_token, refresh_token=refresh_token, user=user_resp)

    @router.post("/refresh", response_model=TokenResponse)
    async def refresh(request: RefreshRequest):
        app_doc = await get_app(db, request.app_id)
        if app_doc is None:
            raise TracheaError(ErrorCode.APP_NOT_FOUND, "App not found", 404)
        if not app_doc.get("is_active"):
            raise TracheaError(ErrorCode.APP_INACTIVE, "App is inactive", 403)

        new_raw, firebase_uid, username = await rotate_refresh_token(
            db, settings, request.refresh_token, request.app_id
        )
        sub = firebase_uid or username
        user = (
            await get_by_firebase_uid(db, firebase_uid)
            if firebase_uid
            else await get_by_username(db, username)
        )
        user_resp = build_user_response(user, request.app_id)
        access_token = issue_access_token(
            settings, sub, request.app_id,
            user_resp["role"], user_resp["plan"], user_resp["provider"]
        )
        return TokenResponse(access_token=access_token, refresh_token=new_raw)

    @router.post("/logout")
    async def logout(credentials: HTTPAuthorizationCredentials = Depends(_bearer)):
        payload = verify_access_token(settings, credentials.credentials)
        firebase_uid = payload["sub"] if payload.get("provider") != "username" else None
        username = payload["sub"] if payload.get("provider") == "username" else None
        await revoke_all_refresh_tokens(db, firebase_uid, username, payload["app_id"])
        return {"message": "Successfully logged out"}

    return router
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_auth_social.py -v
```

Expected: 6 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/routers/auth.py tests/test_auth_social.py
git commit -m "feat: add auth router with Firebase login"
```

---

### Task 12: Auth Router — Username Register + Login

**Files:**
- Modify: `trachea_login/routers/auth.py` (already contains register/login — verify tests pass)
- Create: `tests/test_auth_username.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_auth_username.py
import pytest


async def test_register_success(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/register", json={
        "username": "newuser",
        "password": "Password123",
        "name": "New User",
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["user"]["username"] == "newuser"
    assert data["user"]["plan"] == "free"
    assert data["user"]["provider"] == "username"
    assert "access_token" in data


async def test_register_duplicate_username(app_and_client, username_user):
    _, client = app_and_client
    resp = await client.post("/auth/register", json={
        "username": "johndoe",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 409
    assert resp.json()["error"] == "USERNAME_TAKEN"


async def test_register_password_too_short(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/register", json={
        "username": "shortpass",
        "password": "abc",
        "app_id": "app1"
    })
    assert resp.status_code == 422
    assert resp.json()["error"] == "VALIDATION_ERROR"


async def test_register_method_not_allowed(app_and_client, initialized_db):
    await initialized_db.apps.update_one(
        {"app_id": "app1"}, {"$set": {"allowed_auth_methods": ["google"]}}
    )
    _, client = app_and_client
    resp = await client.post("/auth/register", json={
        "username": "someone",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 403


async def test_username_login_success(app_and_client, username_user):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "username": "johndoe",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["user"]["username"] == "johndoe"
    assert "access_token" in data


async def test_username_login_wrong_password(app_and_client, username_user):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "username": "johndoe",
        "password": "WrongPassword",
        "app_id": "app1"
    })
    assert resp.status_code == 401
    assert resp.json()["error"] == "INVALID_CREDENTIALS"


async def test_username_login_not_found(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "username": "ghost",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 401
    assert resp.json()["error"] == "INVALID_CREDENTIALS"
```

- [ ] **Step 2: Run tests**

```bash
pytest tests/test_auth_username.py -v
```

Expected: 7 passed (register/login already implemented in Task 11)

- [ ] **Step 3: Commit**

```bash
git add tests/test_auth_username.py
git commit -m "test: add username register and login tests"
```

---

### Task 13: Auth Router — Refresh + Logout

**Files:**
- Create: `tests/test_auth_tokens.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_auth_tokens.py
import pytest


async def test_refresh_token_success(app_and_client, initialized_db, settings, firebase_user):
    from trachea_login.tokens import issue_refresh_token
    raw_refresh = await issue_refresh_token(initialized_db, settings, "firebase-uid-123", None, "app1")

    _, client = app_and_client
    resp = await client.post("/auth/refresh", json={
        "refresh_token": raw_refresh,
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["refresh_token"] != raw_refresh  # rotated


async def test_refresh_token_invalid(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/refresh", json={
        "refresh_token": "completely-invalid-token",
        "app_id": "app1"
    })
    assert resp.status_code == 401
    assert resp.json()["error"] == "REFRESH_TOKEN_INVALID"


async def test_refresh_token_reuse_revokes_all(app_and_client, initialized_db, settings, firebase_user):
    from trachea_login.tokens import issue_refresh_token
    raw = await issue_refresh_token(initialized_db, settings, "firebase-uid-123", None, "app1")

    _, client = app_and_client
    # First use — valid
    resp1 = await client.post("/auth/refresh", json={"refresh_token": raw, "app_id": "app1"})
    assert resp1.status_code == 200
    new_refresh = resp1.json()["refresh_token"]

    # Reuse old token — triggers attack detection
    resp2 = await client.post("/auth/refresh", json={"refresh_token": raw, "app_id": "app1"})
    assert resp2.status_code == 401
    assert resp2.json()["error"] == "REFRESH_TOKEN_REUSE"

    # New token is also revoked now
    resp3 = await client.post("/auth/refresh", json={"refresh_token": new_refresh, "app_id": "app1"})
    assert resp3.status_code == 401


async def test_logout_success(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.post(
        "/auth/logout",
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200
    assert resp.json()["message"] == "Successfully logged out"


async def test_logout_invalid_token(app_and_client):
    _, client = app_and_client
    resp = await client.post(
        "/auth/logout",
        headers={"Authorization": "Bearer invalid.token.here"}
    )
    assert resp.status_code == 401
```

- [ ] **Step 2: Run tests**

```bash
pytest tests/test_auth_tokens.py -v
```

Expected: 5 passed

- [ ] **Step 3: Commit**

```bash
git add tests/test_auth_tokens.py
git commit -m "test: add token refresh and logout tests"
```

---

### Task 14: Users Router

**Files:**
- Create: `trachea_login/routers/users.py`
- Create: `tests/test_users.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_users.py
import pytest


async def test_get_me(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.get("/users/me", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["email"] == "test@example.com"
    assert data["provider"] == "google"
    assert data["plan"] == "free"


async def test_get_me_no_token(app_and_client):
    _, client = app_and_client
    resp = await client.get("/users/me")
    assert resp.status_code == 403


async def test_patch_me(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me",
        json={"name": "Updated Name", "phone": "+1234567890"},
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200
    assert resp.json()["name"] == "Updated Name"


async def test_patch_me_address(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me",
        json={"address": {"city": "New York", "country": "US"}},
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200


async def test_delete_me(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.delete("/users/me", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 200
    assert "deactivated" in resp.json()["message"].lower()


async def test_upgrade_plan_requires_email_for_username_user(
    app_and_client, username_access_token, username_user
):
    _, client = app_and_client
    # No email on username user — must provide email when upgrading
    resp = await client.patch(
        "/users/me/plan",
        json={"plan": "pro"},
        headers={"Authorization": f"Bearer {username_access_token}"}
    )
    assert resp.status_code == 422
    assert resp.json()["error"] == "EMAIL_REQUIRED_FOR_PAID"


async def test_upgrade_plan_with_email(app_and_client, username_access_token, username_user):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me/plan",
        json={"plan": "pro", "email": "john@example.com"},
        headers={"Authorization": f"Bearer {username_access_token}"}
    )
    assert resp.status_code == 200


async def test_upgrade_plan_firebase_user_no_email_needed(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me/plan",
        json={"plan": "pro"},
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_users.py -v
```

Expected: `ModuleNotFoundError: No module named 'trachea_login.routers.users'`

- [ ] **Step 3: Create `trachea_login/routers/users.py`**

```python
from __future__ import annotations
from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from motor.motor_asyncio import AsyncIOMotorDatabase

from trachea_login.config import TracheaSettings
from trachea_login.db.user_repo import (
    build_user_response, deactivate_user,
    get_by_firebase_uid, get_by_username, update_profile, upgrade_plan,
)
from trachea_login.exceptions import ErrorCode, TracheaError
from trachea_login.models import CurrentUser, UpdatePlanRequest, UpdateProfileRequest, UserResponse
from trachea_login.tokens import verify_access_token

_bearer = HTTPBearer()


def create_users_router(settings: TracheaSettings, db: AsyncIOMotorDatabase) -> APIRouter:
    router = APIRouter(tags=["users"])

    def _current_user(credentials: HTTPAuthorizationCredentials = Depends(_bearer)) -> CurrentUser:
        payload = verify_access_token(settings, credentials.credentials)
        return CurrentUser(**payload)

    async def _load_user(current: CurrentUser = Depends(_current_user)) -> dict:
        user = (
            await get_by_firebase_uid(db, current.sub)
            if current.provider != "username"
            else await get_by_username(db, current.sub)
        )
        if user is None or not user.get("is_active"):
            raise TracheaError(ErrorCode.USER_INACTIVE, "User not found or inactive", 403)
        return user

    @router.get("/me", response_model=UserResponse)
    async def get_me(
        current: CurrentUser = Depends(_current_user),
        user: dict = Depends(_load_user),
    ):
        return build_user_response(user, current.app_id)

    @router.patch("/me", response_model=UserResponse)
    async def patch_me(
        body: UpdateProfileRequest,
        current: CurrentUser = Depends(_current_user),
        user: dict = Depends(_load_user),
    ):
        updates: dict = {}
        if body.name is not None:
            updates["name"] = body.name
        if body.phone is not None:
            updates["phone"] = body.phone
        if body.date_of_birth is not None:
            updates["date_of_birth"] = body.date_of_birth
        if body.address is not None:
            updates["address"] = body.address.model_dump(exclude_none=True)

        updated = await update_profile(db, user["_id"], updates) if updates else user
        return build_user_response(updated, current.app_id)

    @router.delete("/me")
    async def delete_me(
        current: CurrentUser = Depends(_current_user),
        user: dict = Depends(_load_user),
    ):
        await deactivate_user(db, user["_id"])
        return {"message": "Account deactivated successfully"}

    @router.patch("/me/plan", response_model=UserResponse)
    async def patch_plan(
        body: UpdatePlanRequest,
        current: CurrentUser = Depends(_current_user),
        user: dict = Depends(_load_user),
    ):
        paid_plans = {"pro", "enterprise"}
        if body.plan in paid_plans and not user.get("email") and not body.email:
            raise TracheaError(
                ErrorCode.EMAIL_REQUIRED_FOR_PAID,
                "Email is required to upgrade to a paid plan",
                422,
            )
        updated = await upgrade_plan(db, user["_id"], current.app_id, body.plan, body.email)
        return build_user_response(updated, current.app_id)

    return router
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_users.py -v
```

Expected: 9 passed

- [ ] **Step 5: Commit**

```bash
git add trachea_login/routers/users.py tests/test_users.py
git commit -m "feat: add users router (GET/PATCH/DELETE /me, plan upgrade)"
```

---

### Task 15: FastAPI Dependencies (Public API)

**Files:**
- Create: `tests/test_dependencies.py`
- Modify: `trachea_login/__init__.py`

- [ ] **Step 1: Write failing test**

```python
# tests/test_dependencies.py
import pytest
from fastapi import FastAPI, Depends
from httpx import AsyncClient, ASGITransport
from unittest.mock import patch

from trachea_login.exceptions import TracheaError, trachea_exception_handler


@pytest.fixture
async def secured_app(settings, initialized_db, sample_app, mock_firebase_init):
    """A minimal FastAPI app that uses the public get_current_user and require_role."""
    import trachea_login
    from trachea_login import TracheaLogin

    trachea = TracheaLogin(mongo_client=initialized_db.client, jwt_secret=settings.jwt_secret)

    from trachea_login import get_current_user, require_role

    app = FastAPI()
    app.add_exception_handler(TracheaError, trachea_exception_handler)
    app.include_router(trachea.router, prefix="/auth")

    @app.get("/open")
    async def open_route():
        return {"open": True}

    @app.get("/protected")
    async def protected(user=Depends(get_current_user)):
        return {"sub": user.sub, "plan": user.plan}

    @app.get("/admin-only")
    async def admin_only(user=Depends(require_role(role="admin"))):
        return {"sub": user.sub}

    @app.get("/pro-only")
    async def pro_only(user=Depends(require_role(plan="pro"))):
        return {"sub": user.sub}

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        yield client


async def test_get_current_user_valid(secured_app, access_token):
    resp = await secured_app.get("/protected", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 200
    assert resp.json()["sub"] == "firebase-uid-123"


async def test_get_current_user_no_token(secured_app):
    resp = await secured_app.get("/protected")
    assert resp.status_code == 403


async def test_require_role_admin_denied_for_member(secured_app, access_token):
    resp = await secured_app.get("/admin-only", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 403
    assert resp.json()["error"] == "INSUFFICIENT_ROLE"


async def test_require_plan_pro_denied_for_free(secured_app, access_token):
    resp = await secured_app.get("/pro-only", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 403
    assert resp.json()["error"] == "INSUFFICIENT_PLAN"


async def test_require_role_admin_allowed(secured_app, settings):
    from trachea_login.tokens import issue_access_token
    admin_token = issue_access_token(settings, "uid1", "app1", "admin", "pro", "google")
    resp = await secured_app.get("/admin-only", headers={"Authorization": f"Bearer {admin_token}"})
    assert resp.status_code == 200
```

- [ ] **Step 2: Run to confirm failure**

```bash
pytest tests/test_dependencies.py -v
```

Expected: errors related to `TracheaLogin` not being importable from `trachea_login`

- [ ] **Step 3: Write `trachea_login/__init__.py`**

```python
from __future__ import annotations
from typing import Optional, Callable

from fastapi import APIRouter, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from trachea_login.config import TracheaSettings
from trachea_login.db.mongo import create_indexes
from trachea_login.exceptions import ErrorCode, TracheaConfigError, TracheaError
from trachea_login.firebase import init_firebase
from trachea_login.models import CurrentUser
from trachea_login.tokens import verify_access_token

_settings: Optional[TracheaSettings] = None
_bearer = HTTPBearer()

ROLE_HIERARCHY = {"guest": 0, "member": 1, "admin": 2}
PLAN_HIERARCHY = {"free": 0, "pro": 1, "enterprise": 2}


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
) -> CurrentUser:
    if _settings is None:
        raise TracheaConfigError("TracheaLogin has not been initialized")
    payload = verify_access_token(_settings, credentials.credentials)
    return CurrentUser(**payload)


def require_role(role: Optional[str] = None, plan: Optional[str] = None) -> Callable:
    async def dependency(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if role and ROLE_HIERARCHY.get(user.role, 0) < ROLE_HIERARCHY.get(role, 0):
            raise TracheaError(ErrorCode.INSUFFICIENT_ROLE, f"Role '{role}' or higher required", 403)
        if plan and PLAN_HIERARCHY.get(user.plan, 0) < PLAN_HIERARCHY.get(plan, 0):
            raise TracheaError(ErrorCode.INSUFFICIENT_PLAN, f"Plan '{plan}' or higher required", 403)
        return user
    return dependency


class TracheaLogin:
    def __init__(self, mongo_client=None, **overrides):
        global _settings
        self.settings = TracheaSettings(**overrides)
        _settings = self.settings

        from motor.motor_asyncio import AsyncIOMotorClient
        self._client = mongo_client or AsyncIOMotorClient(self.settings.mongo_uri)
        self._db = self._client[self.settings.db_name]

        init_firebase(self.settings)
        self._router = self._build_router()

    def _build_router(self) -> APIRouter:
        from trachea_login.exceptions import TracheaError, trachea_exception_handler
        from trachea_login.routers.auth import create_auth_router
        from trachea_login.routers.users import create_users_router

        main = APIRouter()
        main.include_router(create_auth_router(self.settings, self._db))
        main.include_router(create_users_router(self.settings, self._db), prefix="/users")
        return main

    @property
    def router(self) -> APIRouter:
        return self._router

    async def startup(self) -> None:
        """Call from FastAPI lifespan to create indexes and validate app registration."""
        from trachea_login.db.app_repo import get_app, verify_app_secret
        await create_indexes(self._db)
        app_doc = await get_app(self._db, self.settings.app_id)
        if app_doc is None:
            raise TracheaConfigError(
                f"App '{self.settings.app_id}' not found in database. "
                "Register it before starting the application."
            )
        if not await verify_app_secret(app_doc["app_secret"], self.settings.app_secret):
            raise TracheaConfigError(
                f"Invalid app_secret for app '{self.settings.app_id}'."
            )
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_dependencies.py -v
```

Expected: 5 passed

- [ ] **Step 5: Run full test suite**

```bash
pytest tests/ -v --tb=short
```

Expected: all tests pass

- [ ] **Step 6: Commit**

```bash
git add trachea_login/__init__.py tests/test_dependencies.py
git commit -m "feat: add TracheaLogin class and public get_current_user/require_role API"
```

---

### Task 16: GitHub Actions CI/CD

**Files:**
- Create: `.github/workflows/ci.yml`
- Create: `.github/workflows/publish.yml`

- [ ] **Step 1: Create CI workflow**

```bash
mkdir -p .github/workflows
```

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.10", "3.11", "3.12"]

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python ${{ matrix.python-version }}
        uses: actions/setup-python@v5
        with:
          python-version: ${{ matrix.python-version }}

      - name: Install dependencies
        run: pip install -e ".[dev]"

      - name: Run tests with coverage
        run: pytest tests/ -v --cov=trachea_login --cov-report=term-missing --cov-fail-under=80
```

- [ ] **Step 2: Create publish workflow**

```yaml
# .github/workflows/publish.yml
name: Publish to PyPI

on:
  push:
    tags:
      - "v*"

jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install build tools
        run: pip install build

      - name: Run tests
        run: |
          pip install -e ".[dev]"
          pytest tests/ -v --cov=trachea_login --cov-fail-under=80

      - name: Build package
        run: python -m build

      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
```

- [ ] **Step 3: Commit**

```bash
git add .github/
git commit -m "ci: add GitHub Actions for test and PyPI publish"
```

---

### Task 17: README

**Files:**
- Create: `README.md`

- [ ] **Step 1: Create `README.md`**

```markdown
# trachea-login

Multi-app authentication package for FastAPI with Firebase and MongoDB.

## Installation

\```bash
pip install trachea-login
\```

## Quick Start

### 1. Register your app in MongoDB

Insert a document into the `apps` collection in your shared MongoDB database:

\```python
from trachea_login.db.app_repo import hash_secret
import asyncio

async def register():
    from motor.motor_asyncio import AsyncIOMotorClient
    client = AsyncIOMotorClient("your-mongo-uri")
    db = client["trachea"]
    await db.apps.insert_one({
        "app_id": "app1",
        "app_secret": await hash_secret("your-app-secret"),
        "name": "My App",
        "allowed_auth_methods": ["google", "facebook", "apple", "password", "username"],
        "allowed_domains": ["myapp.com"],
        "is_active": True,
    })

asyncio.run(register())
\```

### 2. Configure environment variables

\```bash
# .env
TRACHEA_APP_ID=app1
TRACHEA_APP_SECRET=your-app-secret
TRACHEA_MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/trachea
TRACHEA_FIREBASE_CREDENTIALS=path/to/firebase-service-account.json
TRACHEA_JWT_SECRET=your-jwt-secret-key
\```

### 3. Mount in your FastAPI app

\```python
from fastapi import FastAPI, Depends
from trachea_login import TracheaLogin, get_current_user, require_role

app = FastAPI()
trachea = TracheaLogin()
app.include_router(trachea.router, prefix="/auth")

@app.get("/dashboard")
async def dashboard(user=Depends(get_current_user)):
    return {"hello": user.sub, "plan": user.plan}

@app.get("/premium")
async def premium(user=Depends(require_role(plan="pro"))):
    return {"feature": "premium content"}

@app.delete("/admin/users/{id}")
async def admin_delete(id: str, user=Depends(require_role(role="admin"))):
    return {"deleted": id}
\```

## Auth Methods

| Method | Client SDK | Firebase Used | Plan |
|---|---|---|---|
| Google | Firebase SDK | Yes | All |
| Facebook | Firebase SDK | Yes | All |
| Apple | Firebase SDK | Yes | All |
| Email + Password | Firebase SDK | Yes | All |
| Username + Password | Direct API | No | Free only |

## API Endpoints

| Method | Path | Description |
|---|---|---|
| POST | `/auth/login` | Firebase token or username+password |
| POST | `/auth/register` | Username+password registration |
| POST | `/auth/refresh` | Rotate refresh token |
| POST | `/auth/logout` | Revoke tokens |
| GET | `/users/me` | Get current user |
| PATCH | `/users/me` | Update profile |
| DELETE | `/users/me` | Deactivate account |
| PATCH | `/users/me/plan` | Upgrade plan |

## Multiple Apps

All apps share the same MongoDB database. Users are linked across apps via a single document:

\```json
{
  "email": "user@example.com",
  "apps": [
    { "app_id": "app1", "role": "admin", "plan": "pro" },
    { "app_id": "app2", "role": "member", "plan": "free" }
  ]
}
\```
```

- [ ] **Step 2: Commit**

```bash
git add README.md
git commit -m "docs: add README with quick start guide"
```

---

### Task 18: Final Check + Coverage

- [ ] **Step 1: Run full test suite with coverage**

```bash
pytest tests/ -v --cov=trachea_login --cov-report=term-missing
```

Expected: all tests pass, coverage >80%

- [ ] **Step 2: Check for any import issues**

```bash
python -c "from trachea_login import TracheaLogin, get_current_user, require_role; print('OK')"
```

Expected: `OK`

- [ ] **Step 3: Build the package locally**

```bash
pip install build
python -m build
ls dist/
```

Expected: `trachea_login-0.1.0.tar.gz` and `trachea_login-0.1.0-py3-none-any.whl`

- [ ] **Step 4: Final commit**

```bash
git add -A
git commit -m "chore: final build verification and coverage check"
```

---

## Self-Review Against Spec

| Spec Requirement | Covered By Task |
|---|---|
| Mountable FastAPI router | Task 15 (TracheaLogin.router) |
| Firebase social login (Google/Facebook/Apple) | Task 11 |
| Firebase email+password login | Task 11 (same Firebase path) |
| Username+password native auth (free only) | Task 12 |
| App-owned JWT (access + refresh tokens) | Task 8 |
| Refresh token rotation | Task 8, Task 13 |
| Reuse attack detection | Task 8, Task 13 |
| MongoDB Motor async | Task 5 |
| App registration via MongoDB | Task 6 |
| Per-app allowed_auth_methods | Task 11, Task 12 |
| User upsert with apps[] array | Task 7 |
| Cross-app user linking | Task 7 |
| role (admin/member/guest) | Task 14, Task 15 |
| plan (free/pro/enterprise) | Task 14, Task 15 |
| Email required for paid plan | Task 14 |
| Username plan locked to free | Task 7, Task 12 |
| Standard profile fields | Task 7, Task 14 |
| All 16 error codes | Task 2, Tasks 11-14 |
| get_current_user dependency | Task 15 |
| require_role dependency | Task 15 |
| pydantic-settings config | Task 3 |
| TRACHEA_ env prefix | Task 3 |
| Firebase credentials as JSON or file | Task 3, Task 9 |
| Startup validation | Task 15 (TracheaLogin.startup) |
| mongomock-motor in tests | Tasks 5-14 |
| Firebase mocked in tests | Tasks 10-14 |
| GitHub Actions CI | Task 16 |
| GitHub Actions PyPI publish | Task 16 |
| pyproject.toml / PyPI packaging | Task 1 |
| README | Task 17 |
