# trachea-login

Multi-app authentication package for FastAPI with Firebase and MongoDB.

## Installation

```bash
pip install trachea-login
```

## Quick Start

### 1. Register your app in MongoDB

Insert a document into the `apps` collection in your shared MongoDB database:

```python
from trachea_login.db.app_repo import hash_secret
import asyncio

async def register():
    from motor.motor_asyncio import AsyncIOMotorClient
    client = AsyncIOMotorClient("your-mongo-uri")
    db = client["trachea"]
    await db.apps.insert_one({
        "app_id": "app1",
        "app_secret": await hash_secret("your-app-secret"),
        "name": "My App",
        "allowed_auth_methods": ["google", "facebook", "apple", "password", "username"],
        "allowed_domains": ["myapp.com"],
        "is_active": True,
    })

asyncio.run(register())
```

### 2. Configure environment variables

```bash
# .env
TRACHEA_APP_ID=app1
TRACHEA_APP_SECRET=your-app-secret
TRACHEA_MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/trachea
TRACHEA_FIREBASE_CREDENTIALS=path/to/firebase-service-account.json
TRACHEA_JWT_SECRET=your-jwt-secret-key
```

### 3. Mount in your FastAPI app

```python
from fastapi import FastAPI, Depends
from trachea_login import TracheaLogin, get_current_user, require_role

app = FastAPI()
trachea = TracheaLogin()
app.include_router(trachea.router, prefix="/auth")

@app.get("/dashboard")
async def dashboard(user=Depends(get_current_user)):
    return {"hello": user.sub, "plan": user.plan}

@app.get("/premium")
async def premium(user=Depends(require_role(plan="pro"))):
    return {"feature": "premium content"}

@app.delete("/admin/users/{id}")
async def admin_delete(id: str, user=Depends(require_role(role="admin"))):
    return {"deleted": id}
```

## Auth Methods

| Method | Client SDK | Firebase Used | Plan |
|---|---|---|---|
| Google | Firebase SDK | Yes | All |
| Facebook | Firebase SDK | Yes | All |
| Apple | Firebase SDK | Yes | All |
| Email + Password | Firebase SDK | Yes | All |
| Username + Password | Direct API | No | Free only |

## API Endpoints

| Method | Path | Description |
|---|---|---|
| POST | `/auth/login` | Firebase token or username+password |
| POST | `/auth/register` | Username+password registration |
| POST | `/auth/refresh` | Rotate refresh token |
| POST | `/auth/logout` | Revoke tokens |
| GET | `/users/me` | Get current user |
| PATCH | `/users/me` | Update profile |
| DELETE | `/users/me` | Deactivate account |
| PATCH | `/users/me/plan` | Upgrade plan |

## Enabling Facebook Login

The server-side code is already complete — Facebook flows through the same Firebase token path as Google. You only need configuration.

### Step 1 — Create a Facebook App

1. Go to [developers.facebook.com](https://developers.facebook.com) and create an app (or open an existing one)
2. Under **Facebook Login → Settings**, note your **App ID** and **App Secret**

### Step 2 — Enable Facebook in Firebase Console

1. Firebase Console → **Authentication → Sign-in method → Facebook**
2. Toggle it on, enter your Facebook **App ID** and **App Secret**
3. Copy the **OAuth redirect URI** Firebase provides (e.g. `https://your-project.firebaseapp.com/__/auth/handler`)
4. Paste that URI into your Facebook app under **Facebook Login → Settings → Valid OAuth Redirect URIs**

### Step 3 — Allow Facebook in your MongoDB app document

Make sure `"facebook"` is included in `allowed_auth_methods` when registering your app:

```python
await db.apps.insert_one({
    "app_id": "app1",
    "app_secret": await hash_secret("your-app-secret"),
    "name": "My App",
    "allowed_auth_methods": ["google", "facebook", "apple", "password", "username"],
    ...
})
```

To add it to an existing app without re-registering:

```python
await db.apps.update_one(
    {"app_id": "app1"},
    {"$addToSet": {"allowed_auth_methods": "facebook"}}
)
```

### Step 4 — Client-side Firebase call

Use the Firebase SDK on your client to sign in with Facebook, then send the resulting ID token to `POST /auth/login` — same as Google:

**Web:**
```js
import { getAuth, FacebookAuthProvider, signInWithPopup } from "firebase/auth";

const provider = new FacebookAuthProvider();
const result = await signInWithPopup(getAuth(), provider);
const idToken = await result.user.getIdToken();

// Send to your backend
await fetch("/auth/login", {
  method: "POST",
  headers: { "Content-Type": "application/json", "X-App-Id": "app1" },
  body: JSON.stringify({ firebase_token: idToken }),
});
```

**iOS (Swift):**
```swift
let provider = OAuthProvider(providerID: "facebook.com")
provider.getCredentialWith(nil) { credential, error in
    Auth.auth().signIn(with: credential!) { result, error in
        result?.user.getIDToken { idToken, _ in
            // POST idToken to /auth/login
        }
    }
}
```

**Android (Kotlin):**
```kotlin
val provider = OAuthProvider.newBuilder("facebook.com")
firebaseAuth.startActivityForSignInWithProvider(activity, provider.build())
    .addOnSuccessListener { result ->
        result.user?.getIdToken(false)?.addOnSuccessListener { tokenResult ->
            // POST tokenResult.token to /auth/login
        }
    }
```

The backend detects the provider automatically from the Firebase token — no extra parameters needed.

---

## Multiple Apps

All apps share the same MongoDB database. Users are linked across apps via a single document:

```json
{
  "email": "user@example.com",
  "apps": [
    { "app_id": "app1", "role": "admin", "plan": "pro" },
    { "app_id": "app2", "role": "member", "plan": "free" }
  ]
}
```

## Important Files

| File | Purpose |
|---|---|
| `.env` | Real credentials, ready to use |
| `e2e_app.py` | Minimal FastAPI app that mounts trachea-login — run with `uvicorn e2e_app:app --reload` |
| `e2e_test.py` | Integration test script — runs 36 checks against a live server |
| `trachea-login.postman_collection.json` | Import into Postman — all endpoints pre-configured, tokens saved automatically |

## E2E Testing

Run the full 36-check integration suite against a live server:

```bash
# Terminal 1 — start the server
uvicorn e2e_app:app --reload --port 8000

# Terminal 2 — run tests
python e2e_test.py
```

To also run the Firebase login check, grab a Firebase ID token from your client app and pass it as an env var:

```bash
FIREBASE_ID_TOKEN=<token> python e2e_test.py
```

To test via Postman: **File → Import → select `trachea-login.postman_collection.json`**. Tokens are saved automatically after login/register via the collection's test scripts.

https://pypi.org/project/trachea-login/0.1.4/

