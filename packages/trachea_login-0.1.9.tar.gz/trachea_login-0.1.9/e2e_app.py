"""
Minimal FastAPI app for E2E testing trachea-login.
Run: uvicorn e2e_app:app --reload --port 8000
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends
from trachea_login import TracheaLogin, get_current_user, require_role
from trachea_login.exceptions import TracheaError, trachea_exception_handler
from trachea_login.models import CurrentUser

trachea = TracheaLogin()


@asynccontextmanager
async def lifespan(app: FastAPI):
    await trachea.startup()
    print("✅ trachea-login started — indexes created, app validated")
    yield


app = FastAPI(title="trachea-login E2E Test App", lifespan=lifespan)
app.add_exception_handler(TracheaError, trachea_exception_handler)
app.include_router(trachea.router, prefix="/auth")


@app.get("/")
def root():
    return {"status": "ok", "message": "trachea-login E2E test server running"}


@app.get("/protected")
async def protected(user: CurrentUser = Depends(get_current_user)):
    return {"sub": user.sub, "app_id": user.app_id, "role": user.role, "plan": user.plan, "provider": user.provider}


@app.get("/members-only")
async def members_only(user: CurrentUser = Depends(require_role(role="member"))):
    return {"message": f"Hello member {user.sub}"}


@app.get("/pro-only")
async def pro_only(user: CurrentUser = Depends(require_role(plan="pro"))):
    return {"message": "Pro feature — you have access"}


@app.get("/admin-only")
async def admin_only(user: CurrentUser = Depends(require_role(role="admin"))):
    return {"message": f"Admin panel — {user.sub}"}
