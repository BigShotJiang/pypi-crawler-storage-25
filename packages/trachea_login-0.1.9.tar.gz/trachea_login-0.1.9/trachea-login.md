# trachea-login — Design & Knowledge Base

> **Package:** `trachea-login`
> **Version:** 0.1.0
> **Owner:** Trachea Inc
> **Last Updated:** 2026-04-01
> **Purpose:** Multi-app authentication package for FastAPI with Firebase and MongoDB

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture Approach](#architecture-approach)
3. [Technology Stack](#technology-stack)
4. [Package Structure](#package-structure)
5. [Configuration](#configuration)
6. [Data Models](#data-models)
7. [Authentication Flows](#authentication-flows)
8. [API Routes](#api-routes)
9. [Error Handling](#error-handling)
10. [Testing Strategy](#testing-strategy)
11. [PyPI Packaging](#pypi-packaging)
12. [Integration Example](#integration-example)
13. [Key Design Decisions](#key-design-decisions)

---

## Overview

`trachea-login` is a pip-installable Python package that provides complete authentication and authorization functionality for FastAPI applications. It is designed to be shared across multiple apps (App1, App2, App3 etc.) — whether mobile or web — with a single MongoDB database storing all user data across all apps.

### Goals

- One pip install gives any FastAPI app full login functionality
- Support social login (Google, Facebook, Apple) via Firebase
- Support email + password login via Firebase
- Support username + password login natively (free users only)
- Identify which app the user logged into via `AppId`
- Store all user data in a shared MongoDB database
- Issue app-owned JWT tokens (access + refresh) after identity verification
- Role-based access control (`role` + `plan`) per user per app
- Published to PyPI as `trachea-login`

---

## Architecture Approach

### Pattern: Embedded Library with Mountable FastAPI Router

`trachea-login` is a **pip-installable package that exposes mountable API routes**. Each app installs the package, mounts the router in 2 lines, and gets full auth functionality. All apps share the same MongoDB cluster.

```
pip install trachea-login
```

```python
from trachea_login import TracheaLogin
app.include_router(TracheaLogin().router, prefix="/auth")
```

### Identity Provider: Firebase + Native

- **Firebase** handles identity verification for: Google, Facebook, Apple, Email+Password
- **trachea-login** handles username+password natively (no Firebase involved)
- After any successful verification, **trachea-login issues its own app JWT** (access + refresh tokens)
- Apps are decoupled from Firebase after the initial login step

### Auth Flow Summary

```
[Social / Email+Password]
Client → Firebase SDK → Firebase ID Token
       → POST /auth/login → trachea-login verifies token → MongoDB upsert → App JWT issued

[Username + Password]
Client → POST /auth/login → trachea-login bcrypt verify → MongoDB lookup → App JWT issued

[Subsequent Requests]
Client → Authorization: Bearer <access_token> → app validates via Depends(get_current_user)
```

---

## Technology Stack

| Component | Technology |
|---|---|
| Web framework | FastAPI |
| Database | MongoDB (Motor — async driver) |
| Identity provider | Firebase Admin SDK |
| JWT | python-jose |
| Password hashing | passlib (bcrypt) |
| Config management | pydantic-settings |
| Python version | >= 3.10 |
| Package distribution | PyPI |

---

## Package Structure

```
trachea-login/
├── trachea_login/
│   ├── __init__.py              # Public API: TracheaLogin, get_current_user, require_role
│   ├── config.py                # Settings via pydantic-settings (env vars)
│   ├── firebase.py              # Firebase ID token verification
│   ├── tokens.py                # JWT access + refresh token issue/verify
│   ├── models.py                # Pydantic models (request/response schemas)
│   ├── db/
│   │   ├── mongo.py             # MongoDB connection (Motor async client)
│   │   ├── user_repo.py         # User CRUD operations
│   │   └── app_repo.py          # App registration CRUD
│   ├── routers/
│   │   ├── auth.py              # /auth/login, /auth/register, /auth/refresh, /auth/logout
│   │   └── users.py             # /users/me (GET, PATCH, DELETE), /users/me/plan
│   └── dependencies.py          # FastAPI deps: get_current_user, require_role
├── tests/
│   ├── conftest.py
│   ├── test_auth_social.py
│   ├── test_auth_username.py
│   ├── test_auth_tokens.py
│   ├── test_users.py
│   ├── test_dependencies.py
│   ├── test_config.py
│   └── test_models.py
├── pyproject.toml
└── README.md
```

---

## Configuration

### Environment Variables

All settings use the `TRACHEA_` prefix and are loaded from `.env` automatically.

```bash
# Required
TRACHEA_APP_ID=app1
TRACHEA_APP_SECRET=your-app-secret-key
TRACHEA_MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/trachea
TRACHEA_FIREBASE_CREDENTIALS=path/to/firebase-service-account.json
TRACHEA_JWT_SECRET=your-super-secret-jwt-key

# Optional (defaults shown)
TRACHEA_ACCESS_TOKEN_EXPIRE_MINUTES=15
TRACHEA_REFRESH_TOKEN_EXPIRE_DAYS=30
TRACHEA_PASSWORD_MIN_LENGTH=8
TRACHEA_DB_NAME=trachea
```

### Firebase Credentials — Two Options

```bash
# Option A — path to JSON file
TRACHEA_FIREBASE_CREDENTIALS=path/to/serviceAccount.json

# Option B — raw JSON string (recommended for Docker/cloud deployments)
TRACHEA_FIREBASE_CREDENTIALS={"type":"service_account","project_id":"..."}
```

### Startup Validation

At startup, `TracheaLogin()` automatically:
1. Connects to MongoDB and verifies connection
2. Validates `app_id` + `app_secret` against `apps` collection
3. Initializes Firebase Admin SDK
4. Creates MongoDB indexes if they don't exist

Fails fast with a clear error if any validation fails:
```
TracheaConfigError: App 'app1' not found in database.
  Did you register it? Run: trachea-login register-app --app-id app1
```

---

## Data Models

### MongoDB Database: `trachea`

Three collections: `users`, `apps`, `refresh_tokens`

---

### Collection: `users`

```json
{
  "_id": "ObjectId",
  "firebase_uid": "abc123xyz",
  "email": "john@example.com",
  "username": "johndoe",
  "password_hash": "bcrypt...",
  "name": "John Doe",
  "avatar": "https://...",
  "phone": "+1234567890",
  "date_of_birth": "1990-01-01",
  "address": {
    "street": "123 Main St",
    "city": "New York",
    "state": "NY",
    "country": "US",
    "zip": "10001"
  },
  "provider": "google",
  "is_active": true,
  "apps": [
    {
      "app_id": "app1",
      "role": "member",
      "plan": "free",
      "joined_at": "2026-01-01T00:00:00Z"
    },
    {
      "app_id": "app2",
      "role": "admin",
      "plan": "pro",
      "joined_at": "2026-02-15T00:00:00Z"
    }
  ],
  "created_at": "2026-01-01T00:00:00Z",
  "updated_at": "2026-01-01T00:00:00Z"
}
```

**Field rules:**

| Field | Required | Notes |
|---|---|---|
| `firebase_uid` | Conditional | Required for social/email/password users. `null` for username users. |
| `email` | Conditional | Required for paid plan. Optional for free/username users. |
| `username` | Conditional | Only for username/password auth. Globally unique. |
| `password_hash` | Conditional | Only for username/password auth. bcrypt hashed. |
| `provider` | Always | `google`, `facebook`, `apple`, `password`, `username` |
| `apps[].role` | Always | `admin`, `member`, `guest` |
| `apps[].plan` | Always | `free`, `pro`, `enterprise` |

**Business rules:**
- Username users: `email` optional, `plan` locked to `free`
- Plan upgrade (`free` → `pro`/`enterprise`): email **required** before upgrade allowed
- One user document per person across all apps (linked via `firebase_uid` or `username`)

**MongoDB indexes:**
- `firebase_uid` — sparse unique index
- `email` — sparse unique index
- `username` — sparse unique index
- `apps.app_id` — multikey index

---

### Collection: `apps`

```json
{
  "_id": "ObjectId",
  "app_id": "app1",
  "app_secret": "bcrypt-hashed-secret",
  "name": "My App One",
  "allowed_auth_methods": [
    "google",
    "facebook",
    "apple",
    "password",
    "username"
  ],
  "allowed_domains": [
    "app1.com",
    "localhost"
  ],
  "is_active": true,
  "created_at": "2026-01-01T00:00:00Z"
}
```

**Auth method rules per app:**

| Auth Method | Email Required | Firebase Used | Plan Allowed |
|---|---|---|---|
| `google` | Auto-filled by Firebase | Yes | All |
| `facebook` | Auto-filled by Firebase | Yes | All |
| `apple` | Auto-filled by Firebase | Yes | All |
| `password` | Yes | Yes | All |
| `username` | No | No | `free` only |

---

### Collection: `refresh_tokens`

```json
{
  "_id": "ObjectId",
  "token_hash": "sha256-hashed-token",
  "firebase_uid": "abc123xyz",
  "username": "johndoe",
  "app_id": "app1",
  "expires_at": "2026-02-01T00:00:00Z",
  "revoked": false,
  "created_at": "2026-01-01T00:00:00Z"
}
```

> MongoDB TTL index on `expires_at` automatically removes expired tokens.

---

## Authentication Flows

### Flow 1 & 2: Social Login + Email/Password (via Firebase)

```
1. Client authenticates with Firebase SDK (social or email+password)
   → receives Firebase ID Token

2. Client: POST /auth/login
   Body: { "firebase_token": "...", "app_id": "app1" }

3. trachea-login:
   a. Validates app_id is registered and active
   b. Checks auth method is in app's allowed_auth_methods
   c. Verifies Firebase ID Token with Firebase Admin SDK
   d. Extracts: firebase_uid, email, name, avatar, provider
   e. Upserts user in MongoDB:
      - New user → create document, add app entry (role=member, plan=free)
      - Existing user, new app → append to apps[]
      - Existing user, same app → update profile fields
   f. Issues access_token (JWT, 15min) + refresh_token (stored hashed)

4. Returns: { access_token, refresh_token, token_type, user }
```

---

### Flow 3: Username + Password — Register (Native)

```
1. Client: POST /auth/register
   Body: { "username": "johndoe", "password": "...", "name": "John", "app_id": "app1" }

2. trachea-login:
   a. Validates app_id allows "username" auth method
   b. Checks username is globally unique in MongoDB
   c. Validates password strength (min 8 chars)
   d. Bcrypt hashes the password
   e. Creates user (firebase_uid=null, email=null, provider="username", plan="free" locked)
   f. Issues access_token + refresh_token

3. Returns: { access_token, refresh_token, token_type, user }
```

---

### Flow 4: Username + Password — Login (Native)

```
1. Client: POST /auth/login
   Body: { "username": "johndoe", "password": "...", "app_id": "app1" }

2. trachea-login:
   a. Validates app_id allows "username" auth method
   b. Looks up user by username in MongoDB
   c. Bcrypt verifies password
   d. Checks user is_active
   e. Issues access_token + refresh_token

3. Returns: { access_token, refresh_token, token_type, user }
```

---

### Flow 5: Token Refresh

```
1. Client: POST /auth/refresh
   Body: { "refresh_token": "...", "app_id": "app1" }

2. trachea-login:
   a. SHA256 hashes the incoming token
   b. Looks up hash in refresh_tokens collection
   c. Checks: not revoked, not expired, app_id matches
   d. Revokes old refresh token (rotation — one-time use)
   e. Issues new access_token + new refresh_token

3. Returns: { access_token, refresh_token, token_type }
```

> **Refresh token rotation:** Every refresh issues a new token and revokes the old one.
> Reuse of an old token triggers immediate revocation of ALL tokens for that user+app (reuse attack detection).

---

### Flow 6: Logout

```
1. Client: POST /auth/logout
   Header: Authorization: Bearer <access_token>

2. trachea-login:
   a. Verifies access token
   b. Revokes ALL refresh tokens for that user + app_id

3. Returns: { "message": "Successfully logged out" }
```

---

### JWT Access Token Payload

```json
{
  "sub": "firebase_uid_or_username",
  "app_id": "app1",
  "role": "member",
  "plan": "free",
  "provider": "google",
  "exp": 1234567890,
  "iat": 1234567890
}
```

---

## API Routes

### Auth Routes

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `POST` | `/auth/login` | Firebase token OR username/password login | No |
| `POST` | `/auth/register` | Username/password registration only | No |
| `POST` | `/auth/refresh` | Refresh access token | No |
| `POST` | `/auth/logout` | Revoke refresh tokens | Yes |

### User Routes

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `GET` | `/users/me` | Get current user profile | Yes |
| `PATCH` | `/users/me` | Update profile fields | Yes |
| `DELETE` | `/users/me` | Deactivate account (soft delete) | Yes |
| `PATCH` | `/users/me/plan` | Upgrade plan (requires email) | Yes |

---

### Request / Response Schemas

#### POST `/auth/login`

```json
// Firebase login request
{ "firebase_token": "eyJ...", "app_id": "app1" }

// Username login request
{ "username": "johndoe", "password": "secret123", "app_id": "app1" }

// Response (both)
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "token_type": "bearer",
  "user": {
    "firebase_uid": "abc123",
    "username": null,
    "email": "john@example.com",
    "name": "John Doe",
    "avatar": "https://...",
    "provider": "google",
    "app_id": "app1",
    "role": "member",
    "plan": "free"
  }
}
```

#### POST `/auth/register`

```json
// Request
{
  "username": "johndoe",
  "password": "securepass123",
  "name": "John Doe",
  "app_id": "app1"
}
// Response — same shape as /auth/login response
```

#### POST `/auth/refresh`

```json
// Request
{ "refresh_token": "eyJ...", "app_id": "app1" }

// Response
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "token_type": "bearer"
}
```

#### PATCH `/users/me`

```json
// Request (all fields optional)
{
  "name": "John Updated",
  "phone": "+1987654321",
  "date_of_birth": "1990-06-15",
  "address": { "city": "LA", "country": "US" }
}
```

#### PATCH `/users/me/plan`

```json
// Request
{
  "plan": "pro",
  "email": "john@example.com"   // required if user has no email on account
}
```

---

### FastAPI Dependencies (for app routes)

```python
from trachea_login import get_current_user, require_role

# Any authenticated user
@app.get("/dashboard")
async def dashboard(user = Depends(get_current_user)):
    return {"hello": user.name}

# Role-based
@app.delete("/posts/{id}")
async def delete_post(id: str, user = Depends(require_role("admin"))):
    ...

# Plan-based
@app.get("/premium-feature")
async def premium(user = Depends(require_role(plan="pro"))):
    ...
```

---

## Error Handling

All errors return a consistent JSON shape — no raw Python exceptions exposed.

```json
{
  "error": "INVALID_TOKEN",
  "message": "The access token has expired",
  "status_code": 401
}
```

### Error Catalogue

| Error Code | HTTP Status | When Triggered |
|---|---|---|
| `APP_NOT_FOUND` | 404 | app_id not registered in MongoDB |
| `APP_INACTIVE` | 403 | app exists but is_active = false |
| `AUTH_METHOD_NOT_ALLOWED` | 403 | app doesn't allow this login method |
| `INVALID_FIREBASE_TOKEN` | 401 | Firebase token verification failed |
| `INVALID_CREDENTIALS` | 401 | Wrong username or password |
| `USERNAME_TAKEN` | 409 | Username already exists |
| `EMAIL_TAKEN` | 409 | Email already registered |
| `INVALID_TOKEN` | 401 | JWT access token invalid or malformed |
| `TOKEN_EXPIRED` | 401 | JWT access token expired |
| `REFRESH_TOKEN_INVALID` | 401 | Refresh token not found or revoked |
| `REFRESH_TOKEN_REUSE` | 401 | Old refresh token reused — possible attack |
| `INSUFFICIENT_ROLE` | 403 | User role too low for this route |
| `INSUFFICIENT_PLAN` | 403 | User plan too low for this route |
| `EMAIL_REQUIRED_FOR_PAID` | 422 | Upgrading plan but no email on account |
| `USER_INACTIVE` | 403 | User account has been deactivated |
| `VALIDATION_ERROR` | 422 | Request body failed Pydantic validation |

> **Reuse attack:** When `REFRESH_TOKEN_REUSE` is triggered, ALL refresh tokens for that user+app are immediately revoked. User must log in again.

---

## Testing Strategy

```
tests/
├── conftest.py              # shared fixtures: test app, mock MongoDB, mock Firebase
├── test_auth_social.py      # Flow 1 & 2 — Firebase social + email/password
├── test_auth_username.py    # Flow 3 & 4 — username/password register + login
├── test_auth_tokens.py      # Flow 5 & 6 — refresh rotation, logout, reuse attack
├── test_users.py            # GET/PATCH/DELETE /users/me + plan upgrade
├── test_dependencies.py     # get_current_user, require_role, require_plan
├── test_config.py           # startup validation, missing env vars, bad app_id
└── test_models.py           # Pydantic model validation
```

| Component | Tool |
|---|---|
| MongoDB | `mongomock-motor` (async mock — no real DB needed) |
| Firebase | Mock `firebase_admin.auth.verify_id_token()` |
| HTTP routes | `httpx.AsyncClient` with FastAPI `TestClient` |
| Coverage target | > 80% |

---

## PyPI Packaging

### `pyproject.toml`

```toml
[project]
name = "trachea-login"
version = "0.1.0"
description = "Multi-app authentication package for FastAPI with Firebase and MongoDB"
authors = [{ name = "Trachea Inc" }]
requires-python = ">=3.10"
dependencies = [
    "fastapi>=0.110.0",
    "motor>=3.3.0",
    "pydantic>=2.0.0",
    "pydantic-settings>=2.0.0",
    "python-jose[cryptography]",
    "passlib[bcrypt]",
    "firebase-admin>=6.0.0",
    "httpx>=0.27.0",
]

[project.optional-dependencies]
dev = [
    "pytest",
    "pytest-asyncio",
    "mongomock-motor",
    "httpx",
]

[project.urls]
Homepage = "https://github.com/trachea-inc/trachea-login"
```

### Version Strategy

| Version | Milestone |
|---|---|
| `0.1.0` | Initial release — core auth flows |
| `0.2.0` | Phone/OTP auth (future) |
| `1.0.0` | Stable, production-ready |

### CI/CD (GitHub Actions)

```
on push to main:     → run tests → check coverage > 80%
on git tag v*:       → run tests → build package → publish to PyPI
```

---

## Integration Example

### App1 — Full Setup

```python
# pip install trachea-login fastapi uvicorn

from fastapi import FastAPI, Depends
from trachea_login import TracheaLogin, get_current_user, require_role

app = FastAPI()
trachea = TracheaLogin()
app.include_router(trachea.router, prefix="/auth")

@app.get("/")
async def root():
    return {"message": "Welcome to App1"}

@app.get("/dashboard")
async def dashboard(user = Depends(get_current_user)):
    return {"hello": user.name, "plan": user.plan}

@app.get("/premium")
async def premium(user = Depends(require_role(plan="pro"))):
    return {"feature": "premium content"}

@app.delete("/users/{id}")
async def delete_user(id: str, user = Depends(require_role("admin"))):
    return {"deleted": id}
```

### App1 `.env`

```bash
TRACHEA_APP_ID=app1
TRACHEA_APP_SECRET=secret123
TRACHEA_MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/trachea
TRACHEA_FIREBASE_CREDENTIALS=path/to/firebase.json
TRACHEA_JWT_SECRET=jwt-secret-key
```

---

## Key Design Decisions

| Decision | Choice | Reason |
|---|---|---|
| Package type | Mountable FastAPI router | 2-line integration, no separate service needed |
| Identity provider | Firebase + Native | Firebase handles OAuth complexity; native handles username-only |
| Token strategy | App-owned JWT (access + refresh) | Decoupled from Firebase after login, full token control |
| Refresh token storage | MongoDB (hashed) | Enables revocation, rotation, and reuse attack detection |
| Multi-app user model | One user doc, `apps[]` array | Single source of truth, clean profile updates |
| App registration | MongoDB `apps` collection | Central registry, disable apps without redeployment |
| Auth method control | Per-app `allowed_auth_methods` | Each app decides what login methods it supports |
| Username plan lock | Free only | Email required for paid plan (billing, notifications) |
| Email optionality | Optional for free/username | Username users don't need email until upgrading |
| MongoDB driver | Motor (async) | Matches FastAPI's async architecture |
