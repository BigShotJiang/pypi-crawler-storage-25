# tests/test_auth_tokens.py
import pytest


async def test_refresh_token_success(app_and_client, initialized_db, settings, firebase_user):
    from trachea_login.tokens import issue_refresh_token
    raw_refresh = await issue_refresh_token(initialized_db, settings, "firebase-uid-123", None, "app1")

    _, client = app_and_client
    resp = await client.post("/auth/refresh", json={
        "refresh_token": raw_refresh,
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["refresh_token"] != raw_refresh  # rotated


async def test_refresh_token_invalid(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/refresh", json={
        "refresh_token": "completely-invalid-token",
        "app_id": "app1"
    })
    assert resp.status_code == 401
    assert resp.json()["error"] == "REFRESH_TOKEN_INVALID"


async def test_refresh_token_reuse_revokes_all(app_and_client, initialized_db, settings, firebase_user):
    from trachea_login.tokens import issue_refresh_token
    raw = await issue_refresh_token(initialized_db, settings, "firebase-uid-123", None, "app1")

    _, client = app_and_client
    resp1 = await client.post("/auth/refresh", json={"refresh_token": raw, "app_id": "app1"})
    assert resp1.status_code == 200
    new_refresh = resp1.json()["refresh_token"]

    resp2 = await client.post("/auth/refresh", json={"refresh_token": raw, "app_id": "app1"})
    assert resp2.status_code == 401
    assert resp2.json()["error"] == "REFRESH_TOKEN_REUSE"

    resp3 = await client.post("/auth/refresh", json={"refresh_token": new_refresh, "app_id": "app1"})
    assert resp3.status_code == 401


async def test_logout_success(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.post(
        "/auth/logout",
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200
    assert resp.json()["message"] == "Successfully logged out"


async def test_logout_invalid_token(app_and_client):
    _, client = app_and_client
    resp = await client.post(
        "/auth/logout",
        headers={"Authorization": "Bearer invalid.token.here"}
    )
    assert resp.status_code == 401


async def test_refresh_invalid_app_id(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/refresh", json={
        "refresh_token": "some-token",
        "app_id": "nonexistent"
    })
    assert resp.status_code == 404
    assert resp.json()["error"] == "APP_NOT_FOUND"


async def test_refresh_inactive_app(app_and_client, initialized_db):
    await initialized_db.apps.update_one({"app_id": "app1"}, {"$set": {"is_active": False}})
    _, client = app_and_client
    resp = await client.post("/auth/refresh", json={
        "refresh_token": "some-token",
        "app_id": "app1"
    })
    assert resp.status_code == 403
    assert resp.json()["error"] == "APP_INACTIVE"
