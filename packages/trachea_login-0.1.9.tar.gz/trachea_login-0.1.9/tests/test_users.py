# tests/test_users.py
import pytest


async def test_get_me(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.get("/users/me", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["email"] == "test@example.com"
    assert data["provider"] == "google"
    assert data["plan"] == "free"


async def test_get_me_no_token(app_and_client):
    _, client = app_and_client
    resp = await client.get("/users/me")
    assert resp.status_code == 401


async def test_patch_me(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me",
        json={"name": "Updated Name", "phone": "+1234567890"},
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200
    assert resp.json()["name"] == "Updated Name"


async def test_patch_me_address(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me",
        json={"address": {"city": "New York", "country": "US"}},
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200


async def test_delete_me(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.delete("/users/me", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 200
    assert "deleted" in resp.json()["message"].lower()


async def test_upgrade_plan_email_user(app_and_client, email_access_token, email_user):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me/plan",
        json={"plan": "pro"},
        headers={"Authorization": f"Bearer {email_access_token}"}
    )
    assert resp.status_code == 200


async def test_upgrade_plan_firebase_user_no_email_needed(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me/plan",
        json={"plan": "pro"},
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200


async def test_patch_me_date_of_birth(app_and_client, access_token):
    _, client = app_and_client
    resp = await client.patch(
        "/users/me",
        json={"date_of_birth": "1990-06-15"},
        headers={"Authorization": f"Bearer {access_token}"}
    )
    assert resp.status_code == 200


async def test_get_me_deactivated_user(app_and_client, access_token, initialized_db):
    await initialized_db.users.update_one(
        {"firebase_uid": "firebase-uid-123"}, {"$set": {"is_active": False}}
    )
    _, client = app_and_client
    resp = await client.get("/users/me", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 403
    assert resp.json()["error"] == "USER_INACTIVE"
