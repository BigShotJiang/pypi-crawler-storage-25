import pytest
from datetime import datetime, timezone
from trachea_login.models import (
    LoginRequest, RegisterRequest, RefreshRequest,
    UpdateProfileRequest, UpdatePlanRequest,
    UserResponse, LoginResponse, TokenResponse, CurrentUser,
)


def test_login_request_firebase():
    req = LoginRequest(firebase_token="tok123", app_id="app1")
    assert req.firebase_token == "tok123"
    assert req.email is None


def test_login_request_email():
    req = LoginRequest(email="john@example.com", password="pass123", app_id="app1")
    assert req.email == "john@example.com"
    assert req.firebase_token is None


def test_register_request():
    req = RegisterRequest(email="john@example.com", password="pass123", app_id="app1")
    assert req.name is None


def test_update_plan_requires_plan_field():
    req = UpdatePlanRequest(plan="pro")
    assert req.plan == "pro"
    assert req.email is None


def test_current_user_from_jwt_payload():
    user = CurrentUser(sub="uid123", app_id="app1", role="member", plan="free", provider="google")
    assert user.sub == "uid123"


def test_user_response_fields():
    now = datetime.now(timezone.utc)
    user = UserResponse(
        provider="google", app_id="app1", role="member", plan="free", joined_at=now
    )
    assert user.firebase_uid is None
    assert user.email is None
