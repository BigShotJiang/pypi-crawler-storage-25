import pytest
import mongomock_motor
from datetime import datetime, timezone
from trachea_login.db.user_repo import (
    get_by_firebase_uid, get_by_username, get_by_email, upsert_firebase_user,
    create_username_user, create_email_user, get_app_entry, build_user_response,
    update_profile, delete_user, upgrade_plan,
)


@pytest.fixture
def db():
    client = mongomock_motor.AsyncMongoMockClient()
    return client["trachea_test"]


async def test_upsert_firebase_user_creates_new(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    assert user["firebase_uid"] == "uid1"
    assert len(user["apps"]) == 1
    assert user["apps"][0]["app_id"] == "app1"
    assert user["apps"][0]["plan"] == "free"


async def test_upsert_firebase_user_adds_new_app(db):
    await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    user = await upsert_firebase_user(db, "uid1", "app2", "a@b.com", "Alice", None, "google")
    assert len(user["apps"]) == 2


async def test_upsert_firebase_user_same_app_no_duplicate(db):
    await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice Updated", None, "google")
    assert len(user["apps"]) == 1
    assert user["name"] == "Alice Updated"


async def test_create_username_user(db):
    user = await create_username_user(db, "johndoe", "hashed", "John", "app1")
    assert user["username"] == "johndoe"
    assert "firebase_uid" not in user
    assert user["apps"][0]["plan"] == "free"


async def test_get_by_firebase_uid(db):
    await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    user = await get_by_firebase_uid(db, "uid1")
    assert user is not None


async def test_get_by_username(db):
    await create_username_user(db, "johndoe", "hashed", "John", "app1")
    user = await get_by_username(db, "johndoe")
    assert user is not None


async def test_get_app_entry(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "A", None, "google")
    entry = get_app_entry(user, "app1")
    assert entry["role"] == "member"


async def test_get_app_entry_missing_returns_none(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "A", None, "google")
    assert get_app_entry(user, "app99") is None


async def test_build_user_response(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    resp = build_user_response(user, "app1")
    assert resp["app_id"] == "app1"
    assert resp["role"] == "member"
    assert resp["plan"] == "free"
    assert resp["provider"] == "google"


async def test_delete_user(db):
    user = await upsert_firebase_user(db, "uid1", "app1", "a@b.com", "Alice", None, "google")
    await delete_user(db, user["_id"])
    deleted = await get_by_firebase_uid(db, "uid1")
    assert deleted is None


async def test_upgrade_plan_requires_email_for_username_user(db):
    user = await create_username_user(db, "johndoe", "hashed", "John", "app1")
    updated = await upgrade_plan(db, user["_id"], "app1", "pro", email="john@example.com")
    entry = get_app_entry(updated, "app1")
    assert entry["plan"] == "pro"
    assert updated["email"] == "john@example.com"


async def test_create_email_user(db):
    user = await create_email_user(db, "john@example.com", "hashed", "John", "app1")
    assert user["email"] == "john@example.com"
    assert "username" not in user
    assert user["apps"][0]["plan"] == "free"


async def test_get_by_email_for_email_user(db):
    await create_email_user(db, "john@example.com", "hashed", "John", "app1")
    user = await get_by_email(db, "john@example.com")
    assert user is not None
    assert user["email"] == "john@example.com"


async def test_get_by_email(db):
    await upsert_firebase_user(db, "uid1", "app1", "alice@example.com", "Alice", None, "google")
    user = await get_by_email(db, "alice@example.com")
    assert user is not None
    assert user["firebase_uid"] == "uid1"


async def test_get_by_email_not_found(db):
    user = await get_by_email(db, "nobody@example.com")
    assert user is None
