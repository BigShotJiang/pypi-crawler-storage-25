# tests/test_auth_username.py
import pytest


async def test_register_success(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/register", json={
        "email": "newuser@example.com",
        "password": "Password123",
        "name": "New User",
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["user"]["email"] == "newuser@example.com"
    assert data["user"]["plan"] == "free"
    assert data["user"]["provider"] == "username"
    assert "access_token" in data


async def test_signup_endpoint(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/signup", json={
        "email": "signup@example.com",
        "password": "Password123",
        "name": "Signup User",
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["user"]["email"] == "signup@example.com"
    assert "access_token" in data


async def test_register_duplicate_email(app_and_client, email_user):
    _, client = app_and_client
    resp = await client.post("/auth/register", json={
        "email": "john@example.com",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 409
    assert resp.json()["error"] == "USERNAME_TAKEN"


async def test_register_password_too_short(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/register", json={
        "email": "shortpass@example.com",
        "password": "abc",
        "app_id": "app1"
    })
    assert resp.status_code == 422
    assert resp.json()["error"] == "VALIDATION_ERROR"


async def test_register_method_not_allowed(app_and_client, initialized_db):
    await initialized_db.apps.update_one(
        {"app_id": "app1"}, {"$set": {"allowed_auth_methods": ["google"]}}
    )
    _, client = app_and_client
    resp = await client.post("/auth/register", json={
        "email": "someone@example.com",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 403


async def test_email_login_success(app_and_client, email_user):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "email": "john@example.com",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert data["user"]["email"] == "john@example.com"
    assert "access_token" in data


async def test_email_login_wrong_password(app_and_client, email_user):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "email": "john@example.com",
        "password": "WrongPassword",
        "app_id": "app1"
    })
    assert resp.status_code == 401
    assert resp.json()["error"] == "INVALID_CREDENTIALS"


async def test_email_login_not_found(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "email": "ghost@example.com",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 401
    assert resp.json()["error"] == "INVALID_CREDENTIALS"


async def test_email_login_deactivated_user(app_and_client, email_user, initialized_db):
    await initialized_db.users.update_one(
        {"email": "john@example.com"}, {"$set": {"is_active": False}}
    )
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "email": "john@example.com",
        "password": "Password123",
        "app_id": "app1"
    })
    assert resp.status_code == 403
    assert resp.json()["error"] == "USER_INACTIVE"
