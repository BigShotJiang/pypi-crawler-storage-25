# tests/test_dependencies.py
import pytest
from fastapi import FastAPI, Depends
from httpx import AsyncClient, ASGITransport
from unittest.mock import patch

from trachea_login.exceptions import TracheaError, trachea_exception_handler


@pytest.fixture
async def secured_app(settings, initialized_db, sample_app, mock_firebase_init):
    """A minimal FastAPI app that uses the public get_current_user and require_role."""
    from trachea_login import TracheaLogin
    from trachea_login import get_current_user, require_role

    with patch("trachea_login.init_firebase"):
        trachea = TracheaLogin(mongo_client=initialized_db.client)

    app = FastAPI()
    app.add_exception_handler(TracheaError, trachea_exception_handler)
    app.include_router(trachea.router, prefix="/auth")

    @app.get("/open")
    async def open_route():
        return {"open": True}

    @app.get("/protected")
    async def protected(user=Depends(get_current_user)):
        return {"sub": user.sub, "plan": user.plan}

    @app.get("/admin-only")
    async def admin_only(user=Depends(require_role(role="admin"))):
        return {"sub": user.sub}

    @app.get("/pro-only")
    async def pro_only(user=Depends(require_role(plan="pro"))):
        return {"sub": user.sub}

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        yield client


async def test_get_current_user_valid(secured_app, access_token):
    resp = await secured_app.get("/protected", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 200
    assert resp.json()["sub"] == "firebase-uid-123"


async def test_get_current_user_no_token(secured_app):
    resp = await secured_app.get("/protected")
    assert resp.status_code in (401, 403)


async def test_require_role_admin_denied_for_member(secured_app, access_token):
    resp = await secured_app.get("/admin-only", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 403
    assert resp.json()["error"] == "INSUFFICIENT_ROLE"


async def test_require_plan_pro_denied_for_free(secured_app, access_token):
    resp = await secured_app.get("/pro-only", headers={"Authorization": f"Bearer {access_token}"})
    assert resp.status_code == 403
    assert resp.json()["error"] == "INSUFFICIENT_PLAN"


async def test_require_role_admin_allowed(secured_app, settings):
    from trachea_login.tokens import issue_access_token
    admin_token = issue_access_token(settings, "uid1", "app1", "admin", "pro", "google")
    resp = await secured_app.get("/admin-only", headers={"Authorization": f"Bearer {admin_token}"})
    assert resp.status_code == 200


async def test_startup_validates_app(settings, initialized_db, sample_app, mock_firebase_init, monkeypatch):
    monkeypatch.setenv("TRACHEA_DB_NAME", "trachea_test")
    from trachea_login import TracheaLogin
    from unittest.mock import patch
    with patch("trachea_login.init_firebase"):
        trachea = TracheaLogin(mongo_client=initialized_db.client)
    await trachea.startup()


async def test_startup_fails_unknown_app(settings, initialized_db, mock_firebase_init, monkeypatch):
    monkeypatch.setenv("TRACHEA_DB_NAME", "trachea_test")
    from trachea_login import TracheaLogin
    from trachea_login.exceptions import TracheaConfigError
    from unittest.mock import patch
    with patch("trachea_login.init_firebase"):
        trachea = TracheaLogin(mongo_client=initialized_db.client)
    with pytest.raises(TracheaConfigError):
        await trachea.startup()
