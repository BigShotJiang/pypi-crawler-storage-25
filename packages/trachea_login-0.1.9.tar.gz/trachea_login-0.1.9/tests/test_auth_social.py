# tests/test_auth_social.py
import pytest


async def test_firebase_login_success(app_and_client, mock_firebase):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "firebase_token": "valid-firebase-token",
        "app_id": "app1"
    })
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert "refresh_token" in data
    assert data["token_type"] == "bearer"
    assert data["user"]["email"] == "test@example.com"
    assert data["user"]["provider"] == "google"
    assert data["user"]["plan"] == "free"
    assert data["user"]["role"] == "member"


async def test_firebase_login_invalid_app(app_and_client, mock_firebase):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "firebase_token": "tok",
        "app_id": "nonexistent"
    })
    assert resp.status_code == 404
    assert resp.json()["error"] == "APP_NOT_FOUND"


async def test_firebase_login_inactive_app(app_and_client, mock_firebase, initialized_db):
    await initialized_db.apps.update_one({"app_id": "app1"}, {"$set": {"is_active": False}})
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "firebase_token": "tok",
        "app_id": "app1"
    })
    assert resp.status_code == 403
    assert resp.json()["error"] == "APP_INACTIVE"


async def test_firebase_login_method_not_allowed(app_and_client, mock_firebase, initialized_db):
    await initialized_db.apps.update_one(
        {"app_id": "app1"}, {"$set": {"allowed_auth_methods": ["username"]}}
    )
    _, client = app_and_client
    resp = await client.post("/auth/login", json={
        "firebase_token": "tok",
        "app_id": "app1"
    })
    assert resp.status_code == 403
    assert resp.json()["error"] == "AUTH_METHOD_NOT_ALLOWED"


async def test_firebase_login_invalid_token(app_and_client):
    from unittest.mock import patch
    _, client = app_and_client
    with patch("trachea_login.firebase.auth.verify_id_token", side_effect=Exception("bad")):
        resp = await client.post("/auth/login", json={
            "firebase_token": "bad-token",
            "app_id": "app1"
        })
    assert resp.status_code == 401
    assert resp.json()["error"] == "INVALID_FIREBASE_TOKEN"


async def test_second_login_same_user_same_app(app_and_client, mock_firebase):
    _, client = app_and_client
    resp1 = await client.post("/auth/login", json={"firebase_token": "tok", "app_id": "app1"})
    resp2 = await client.post("/auth/login", json={"firebase_token": "tok", "app_id": "app1"})
    assert resp1.status_code == 200
    assert resp2.status_code == 200


async def test_firebase_login_deactivated_user(app_and_client, mock_firebase, initialized_db):
    # First login creates the user
    _, client = app_and_client
    await client.post("/auth/login", json={"firebase_token": "tok", "app_id": "app1"})
    # Deactivate the user
    await initialized_db.users.update_one(
        {"firebase_uid": "firebase-uid-123"}, {"$set": {"is_active": False}}
    )
    resp = await client.post("/auth/login", json={"firebase_token": "tok", "app_id": "app1"})
    assert resp.status_code == 403
    assert resp.json()["error"] == "USER_INACTIVE"


async def test_login_no_credentials(app_and_client):
    _, client = app_and_client
    resp = await client.post("/auth/login", json={"app_id": "app1"})
    assert resp.status_code == 422
    assert resp.json()["error"] == "VALIDATION_ERROR"
