import pytest
import mongomock_motor
from datetime import datetime, timezone
from trachea_login.config import TracheaSettings
from trachea_login.exceptions import TracheaError, ErrorCode
from trachea_login.tokens import (
    issue_access_token, verify_access_token,
    issue_refresh_token, rotate_refresh_token, revoke_all_refresh_tokens,
)


@pytest.fixture
def settings(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "s")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", "{}")
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "test-secret-key-for-jwt-signing!!")
    return TracheaSettings()


@pytest.fixture
def db():
    client = mongomock_motor.AsyncMongoMockClient()
    return client["trachea_test"]


def test_issue_and_verify_access_token(settings):
    token = issue_access_token(settings, "uid1", "app1", "member", "free", "google")
    payload = verify_access_token(settings, token)
    assert payload["sub"] == "uid1"
    assert payload["app_id"] == "app1"
    assert payload["role"] == "member"
    assert payload["plan"] == "free"
    assert payload["provider"] == "google"


def test_verify_access_token_invalid(settings):
    with pytest.raises(TracheaError) as exc_info:
        verify_access_token(settings, "not-a-valid-token")
    assert exc_info.value.error == ErrorCode.INVALID_TOKEN


def test_verify_access_token_expired(settings):
    from jose import jwt as jose_jwt
    import time
    payload = {
        "sub": "uid1", "app_id": "app1", "role": "member",
        "plan": "free", "provider": "google",
        "exp": int(time.time()) - 1,
        "iat": int(time.time()) - 60,
    }
    token = jose_jwt.encode(payload, settings.jwt_secret, algorithm="HS256")
    with pytest.raises(TracheaError) as exc_info:
        verify_access_token(settings, token)
    assert exc_info.value.error == ErrorCode.TOKEN_EXPIRED


async def test_issue_and_rotate_refresh_token(db, settings):
    raw = await issue_refresh_token(db, settings, "uid1", None, "app1")
    assert isinstance(raw, str) and len(raw) > 20
    new_raw, firebase_uid, username = await rotate_refresh_token(db, settings, raw, "app1")
    assert firebase_uid == "uid1"
    assert username is None
    assert new_raw != raw


async def test_rotate_refresh_token_reuse_revokes_all(db, settings):
    raw = await issue_refresh_token(db, settings, "uid1", None, "app1")
    new_raw, _, _ = await rotate_refresh_token(db, settings, raw, "app1")
    with pytest.raises(TracheaError) as exc_info:
        await rotate_refresh_token(db, settings, raw, "app1")
    assert exc_info.value.error == ErrorCode.REFRESH_TOKEN_REUSE
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, new_raw, "app1")


async def test_revoke_all_refresh_tokens(db, settings):
    raw1 = await issue_refresh_token(db, settings, "uid1", None, "app1")
    raw2 = await issue_refresh_token(db, settings, "uid1", None, "app1")
    await revoke_all_refresh_tokens(db, "uid1", None, "app1")
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, raw1, "app1")
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, raw2, "app1")


async def test_revoke_all_refresh_tokens_by_username(db, settings):
    raw1 = await issue_refresh_token(db, settings, None, "johndoe", "app1")
    raw2 = await issue_refresh_token(db, settings, None, "johndoe", "app1")
    await revoke_all_refresh_tokens(db, None, "johndoe", "app1")
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, raw1, "app1")
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, raw2, "app1")


async def test_rotate_refresh_token_reuse_username_revokes_all(db, settings):
    raw = await issue_refresh_token(db, settings, None, "johndoe", "app1")
    new_raw, firebase_uid, username = await rotate_refresh_token(db, settings, raw, "app1")
    assert firebase_uid is None
    assert username == "johndoe"
    # Reuse the old token — should trigger reuse detection
    with pytest.raises(TracheaError) as exc_info:
        await rotate_refresh_token(db, settings, raw, "app1")
    assert exc_info.value.error == ErrorCode.REFRESH_TOKEN_REUSE
    # New token should also be revoked now
    with pytest.raises(TracheaError):
        await rotate_refresh_token(db, settings, new_raw, "app1")


async def test_rotate_refresh_token_expired(db, settings):
    from datetime import timedelta
    raw = await issue_refresh_token(db, settings, "uid1", None, "app1")
    # Manually expire the token in the DB
    from trachea_login.tokens import _hash_token
    past = datetime(2000, 1, 1, tzinfo=timezone.utc)
    await db.refresh_tokens.update_one(
        {"token_hash": _hash_token(raw)},
        {"$set": {"expires_at": past}}
    )
    with pytest.raises(TracheaError) as exc_info:
        await rotate_refresh_token(db, settings, raw, "app1")
    assert exc_info.value.error == ErrorCode.REFRESH_TOKEN_INVALID
