import pytest
from trachea_login.exceptions import TracheaError, TracheaConfigError, ErrorCode

def test_trachea_error_attributes():
    err = TracheaError(ErrorCode.APP_NOT_FOUND, "App not found", 404)
    assert err.error == "APP_NOT_FOUND"
    assert err.message == "App not found"
    assert err.status_code == 404

def test_trachea_error_is_exception():
    with pytest.raises(TracheaError):
        raise TracheaError(ErrorCode.INVALID_TOKEN, "bad token", 401)

def test_all_error_codes_exist():
    codes = [
        "APP_NOT_FOUND", "APP_INACTIVE", "AUTH_METHOD_NOT_ALLOWED",
        "INVALID_FIREBASE_TOKEN", "INVALID_CREDENTIALS", "USERNAME_TAKEN",
        "EMAIL_TAKEN", "INVALID_TOKEN", "TOKEN_EXPIRED", "REFRESH_TOKEN_INVALID",
        "REFRESH_TOKEN_REUSE", "INSUFFICIENT_ROLE", "INSUFFICIENT_PLAN",
        "EMAIL_REQUIRED_FOR_PAID", "USER_INACTIVE", "VALIDATION_ERROR",
    ]
    for code in codes:
        assert hasattr(ErrorCode, code), f"Missing error code: {code}"
