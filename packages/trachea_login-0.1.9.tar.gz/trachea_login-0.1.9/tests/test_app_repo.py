import pytest
import mongomock_motor
from datetime import datetime, timezone
from trachea_login.db.app_repo import get_app, verify_app_secret, hash_secret


@pytest.fixture
def db():
    client = mongomock_motor.AsyncMongoMockClient()
    return client["trachea_test"]


@pytest.fixture
async def sample_app(db):
    secret_hash = await hash_secret("mysecret")
    doc = {
        "app_id": "app1",
        "app_secret": secret_hash,
        "name": "Test App",
        "allowed_auth_methods": ["google", "password", "username"],
        "allowed_domains": ["localhost"],
        "is_active": True,
        "created_at": datetime.now(timezone.utc),
    }
    await db.apps.insert_one(doc)
    return doc


async def test_get_app_found(db, sample_app):
    app = await get_app(db, "app1")
    assert app is not None
    assert app["app_id"] == "app1"


async def test_get_app_not_found(db):
    app = await get_app(db, "nonexistent")
    assert app is None


async def test_verify_app_secret_correct(db, sample_app):
    result = await verify_app_secret(sample_app["app_secret"], "mysecret")
    assert result is True


async def test_verify_app_secret_wrong(db, sample_app):
    result = await verify_app_secret(sample_app["app_secret"], "wrongsecret")
    assert result is False
