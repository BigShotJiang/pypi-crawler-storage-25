import pytest
import mongomock_motor
from trachea_login.db.mongo import create_indexes


@pytest.fixture
def db():
    client = mongomock_motor.AsyncMongoMockClient()
    return client["trachea_test"]


async def test_create_indexes_runs_without_error(db):
    # Should not raise
    await create_indexes(db)


async def test_create_indexes_idempotent(db):
    # Running twice should not raise
    await create_indexes(db)
    await create_indexes(db)
