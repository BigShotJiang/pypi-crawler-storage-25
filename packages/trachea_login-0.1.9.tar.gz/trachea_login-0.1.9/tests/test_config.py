import pytest
from trachea_login.config import TracheaSettings


def test_settings_load_from_env(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "testapp")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "secret123")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost:27017/test")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", '{"type": "service_account"}')
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "jwt-secret-key-32-chars-minimum!!")
    monkeypatch.setenv("TRACHEA_DB_NAME", "trachea")

    settings = TracheaSettings()
    assert settings.app_id == "testapp"
    assert settings.app_secret == "secret123"
    assert settings.access_token_expire_minutes == 15
    assert settings.refresh_token_expire_days == 30
    assert settings.db_name == "trachea"


def test_settings_defaults(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "s")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", "{}")
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "secret")

    settings = TracheaSettings()
    assert settings.password_min_length == 8


def test_get_firebase_credentials_from_json_string(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "s")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", '{"type":"service_account","project_id":"proj"}')
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "secret")

    settings = TracheaSettings()
    creds = settings.get_firebase_credentials_dict()
    assert creds["type"] == "service_account"
    assert creds["project_id"] == "proj"


def test_get_firebase_credentials_from_file(monkeypatch, tmp_path):
    creds = {"type": "service_account", "project_id": "from-file"}
    creds_file = tmp_path / "firebase.json"
    creds_file.write_text('{"type":"service_account","project_id":"from-file"}')

    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "s")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", str(creds_file))
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "secret")

    settings = TracheaSettings()
    result = settings.get_firebase_credentials_dict()
    assert result["project_id"] == "from-file"


def test_get_firebase_credentials_missing_file_raises(monkeypatch):
    from trachea_login.exceptions import TracheaConfigError

    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "s")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", "/nonexistent/path/firebase.json")
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "secret")

    settings = TracheaSettings()
    with pytest.raises(TracheaConfigError):
        settings.get_firebase_credentials_dict()
