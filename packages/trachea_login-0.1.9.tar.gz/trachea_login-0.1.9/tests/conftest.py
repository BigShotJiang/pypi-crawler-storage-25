# tests/conftest.py
import pytest
import mongomock_motor
from datetime import datetime, timezone
from unittest.mock import patch, AsyncMock
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport

from trachea_login.config import TracheaSettings
from trachea_login.db.app_repo import hash_secret
from trachea_login.db.mongo import create_indexes
from trachea_login.db.user_repo import upsert_firebase_user, create_email_user
from trachea_login.tokens import issue_access_token, issue_refresh_token
from passlib.context import CryptContext

_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")


@pytest.fixture
def settings(monkeypatch):
    monkeypatch.setenv("TRACHEA_APP_ID", "app1")
    monkeypatch.setenv("TRACHEA_APP_SECRET", "appsecret123")
    monkeypatch.setenv("TRACHEA_MONGO_URI", "mongodb://localhost")
    monkeypatch.setenv("TRACHEA_FIREBASE_CREDENTIALS", '{"type":"service_account"}')
    monkeypatch.setenv("TRACHEA_JWT_SECRET", "test-jwt-secret-key-for-tests-only!!")
    return TracheaSettings()


@pytest.fixture
def mongo_client():
    return mongomock_motor.AsyncMongoMockClient()


@pytest.fixture
def db(mongo_client):
    return mongo_client["trachea_test"]


@pytest.fixture
async def initialized_db(db):
    await create_indexes(db)
    return db


@pytest.fixture
async def sample_app(initialized_db):
    secret_hash = await hash_secret("appsecret123")
    doc = {
        "app_id": "app1",
        "app_secret": secret_hash,
        "name": "Test App",
        "allowed_auth_methods": ["google", "facebook", "apple", "password", "username"],
        "allowed_domains": ["localhost"],
        "is_active": True,
        "created_at": datetime.now(timezone.utc),
    }
    await initialized_db.apps.insert_one(doc)
    return doc


@pytest.fixture
async def firebase_user(initialized_db, sample_app):
    return await upsert_firebase_user(
        initialized_db, "firebase-uid-123", "app1",
        "test@example.com", "Test User", "https://avatar.url", "google"
    )


@pytest.fixture
async def email_user(initialized_db, sample_app):
    return await create_email_user(
        initialized_db, "john@example.com", _pwd.hash("Password123"), "John Doe", "app1"
    )


@pytest.fixture
def access_token(settings, firebase_user):
    return issue_access_token(
        settings, "firebase-uid-123", "app1", "member", "free", "google"
    )


@pytest.fixture
def email_access_token(settings, email_user):
    return issue_access_token(
        settings, "john@example.com", "app1", "member", "free", "username"
    )


@pytest.fixture
def mock_firebase():
    decoded = {
        "uid": "firebase-uid-123",
        "email": "test@example.com",
        "name": "Test User",
        "picture": "https://avatar.url",
        "firebase": {"sign_in_provider": "google.com"},
    }
    with patch("trachea_login.firebase.auth.verify_id_token", return_value=decoded):
        yield decoded


@pytest.fixture
def mock_firebase_init():
    with patch("trachea_login.firebase.init_firebase"):
        yield


@pytest.fixture
async def app_and_client(settings, initialized_db, sample_app, mock_firebase_init):
    """Returns (fastapi_app, httpx_client) with trachea router mounted."""
    from trachea_login.routers.auth import create_auth_router
    from trachea_login.routers.users import create_users_router
    from trachea_login.exceptions import TracheaError, trachea_exception_handler

    fastapi_app = FastAPI()
    fastapi_app.add_exception_handler(TracheaError, trachea_exception_handler)
    fastapi_app.include_router(create_auth_router(settings, initialized_db), prefix="/auth")
    fastapi_app.include_router(create_users_router(settings, initialized_db), prefix="/users")

    async with AsyncClient(
        transport=ASGITransport(app=fastapi_app), base_url="http://test"
    ) as client:
        yield fastapi_app, client
