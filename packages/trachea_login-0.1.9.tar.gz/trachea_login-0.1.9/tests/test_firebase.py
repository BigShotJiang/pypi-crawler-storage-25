# tests/test_firebase.py
import pytest
from unittest.mock import patch, MagicMock
from trachea_login.exceptions import TracheaError, ErrorCode
from trachea_login.firebase import verify_firebase_token, get_provider_from_firebase


@pytest.fixture
def decoded_google_token():
    return {
        "uid": "firebase-uid-123",
        "email": "test@example.com",
        "name": "Test User",
        "picture": "https://avatar.url/photo.jpg",
        "firebase": {"sign_in_provider": "google.com"},
    }


def test_verify_firebase_token_success(decoded_google_token):
    with patch("firebase_admin.auth.verify_id_token", return_value=decoded_google_token):
        result = verify_firebase_token("valid-firebase-token")
    assert result["uid"] == "firebase-uid-123"
    assert result["email"] == "test@example.com"


def test_verify_firebase_token_failure():
    with patch("firebase_admin.auth.verify_id_token", side_effect=Exception("invalid")):
        with pytest.raises(TracheaError) as exc_info:
            verify_firebase_token("bad-token")
    assert exc_info.value.error == ErrorCode.INVALID_FIREBASE_TOKEN
    assert exc_info.value.status_code == 401


def test_get_provider_google(decoded_google_token):
    assert get_provider_from_firebase(decoded_google_token) == "google"


def test_get_provider_facebook():
    token = {"firebase": {"sign_in_provider": "facebook.com"}}
    assert get_provider_from_firebase(token) == "facebook"


def test_get_provider_apple():
    token = {"firebase": {"sign_in_provider": "apple.com"}}
    assert get_provider_from_firebase(token) == "apple"


def test_get_provider_password():
    token = {"firebase": {"sign_in_provider": "password"}}
    assert get_provider_from_firebase(token) == "password"
