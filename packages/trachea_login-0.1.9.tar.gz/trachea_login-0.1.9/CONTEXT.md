# trachea-login — AI Agent Context

> This file is intended for AI agents and code editors. It is a dense, factual reference for implementing `trachea-login` in a FastAPI application. Read this file before writing any integration code.

---

## Package Identity

- **PyPI name:** `trachea-login`
- **Latest version:** `0.1.3`
- **Install:** `pip install trachea-login`
- **Python:** 3.10+
- **Framework:** FastAPI + Motor (async MongoDB) + Firebase Admin SDK
- **Source:** https://github.com/Trachea-Inc/trachea-login

---

## What It Provides

| Feature | Detail |
|---|---|
| Firebase social login | Google, Facebook, Apple, email/password via Firebase Identity Platform |
| Native username/password | No Firebase required; registers and logs in with bcrypt-hashed passwords |
| JWT access tokens | Short-lived (default 15 min), signed HS256, verified by signature only (no DB lookup) |
| Opaque refresh tokens | Long-lived (default 30 days), stored as SHA-256 hash in MongoDB, auto-rotated |
| Refresh token reuse detection | Reusing a rotated token revokes ALL tokens for that user+app |
| Role-based access control | `guest` (0) < `member` (1) < `admin` (2) — hierarchical, minimum enforcement |
| Plan-based access control | `free` (0) < `pro` (1) < `enterprise` (2) — hierarchical, minimum enforcement |
| Multi-app support | One MongoDB database, many apps; users have per-app role+plan in an `apps[]` array |

---

## Known Constraints / Gotchas

- **`bcrypt<4.1` is required.** `bcrypt>=4.1` removed `__about__`, which `passlib` uses for version detection. The package pins this automatically since `0.1.3`.
- **Sparse index fields must be absent, not null.** MongoDB sparse unique indexes skip documents where the field is absent, but still index explicit `null`. Since `0.1.3`, the package omits `firebase_uid`, `email`, and `username` from user documents when they have no value (rather than storing `None`).
- **`trachea.startup()` must be called** before serving requests. It creates MongoDB indexes and validates `app_id`/`app_secret` against the database. If not called, indexes may be missing and app validation is skipped.
- **Firebase is optional.** If you only need username/password auth, you can omit `TRACHEA_FIREBASE_CREDENTIALS` and exclude Firebase providers from `allowed_auth_methods`.

---

## Dependencies (auto-installed with pip)

```
fastapi>=0.110.0
motor>=3.3.0
pydantic>=2.0.0
pydantic-settings>=2.0.0
python-jose[cryptography]>=3.3.0
passlib[bcrypt]>=1.7.4
bcrypt<4.1
firebase-admin>=6.0.0
httpx>=0.27.0
```

---

## Environment Variables

All use the `TRACHEA_` prefix. Load via `.env` (python-dotenv is not a dependency — use `uvicorn --env-file .env` or load it yourself before importing).

| Variable | Required | Default | Description |
|---|---|---|---|
| `TRACHEA_APP_ID` | Yes | — | Unique app identifier; must match a document in the `apps` collection |
| `TRACHEA_APP_SECRET` | Yes | — | Plain-text secret; verified against bcrypt hash stored in `apps` collection |
| `TRACHEA_MONGO_URI` | Yes | — | MongoDB connection string (Atlas SRV or standard URI) |
| `TRACHEA_FIREBASE_CREDENTIALS` | Yes* | — | Path to Firebase service account JSON file, OR the raw JSON string |
| `TRACHEA_JWT_SECRET` | Yes | — | Secret for signing JWT access tokens — use 32+ random chars |
| `TRACHEA_DB_NAME` | No | `trachea` | MongoDB database name |
| `TRACHEA_ACCESS_TOKEN_EXPIRE_MINUTES` | No | `15` | Access token lifetime in minutes |
| `TRACHEA_REFRESH_TOKEN_EXPIRE_DAYS` | No | `30` | Refresh token lifetime in days |
| `TRACHEA_PASSWORD_MIN_LENGTH` | No | `8` | Minimum password length for username/password registration |

*Firebase credentials are required unless you only use `username` auth method and never call Firebase login.

---

## One-Time Setup: Register Your App in MongoDB

Must be done once before starting the application. Run this script:

```python
# register_app.py
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from trachea_login.db.app_repo import hash_secret

async def register():
    client = AsyncIOMotorClient("mongodb+srv://...")
    db = client["trachea"]  # must match TRACHEA_DB_NAME
    await db.apps.insert_one({
        "app_id": "myapp",                              # must match TRACHEA_APP_ID
        "app_secret": await hash_secret("my-secret"),  # must match TRACHEA_APP_SECRET
        "name": "My Application",
        "allowed_auth_methods": ["google", "facebook", "apple", "password", "username"],
        "allowed_domains": ["myapp.com", "localhost"],
        "is_active": True,
    })

asyncio.run(register())
```

`allowed_auth_methods` values: `"google"`, `"facebook"`, `"apple"`, `"password"` (Firebase email/password), `"username"` (native).

---

## FastAPI Integration — Minimal

```python
from fastapi import FastAPI
from trachea_login import TracheaLogin
from trachea_login.exceptions import TracheaError, trachea_exception_handler

trachea = TracheaLogin()

app = FastAPI()
app.add_exception_handler(TracheaError, trachea_exception_handler)  # required for clean error JSON
app.include_router(trachea.router, prefix="/auth")
```

## FastAPI Integration — Recommended (with lifespan)

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from trachea_login import TracheaLogin
from trachea_login.exceptions import TracheaError, trachea_exception_handler

trachea = TracheaLogin()

@asynccontextmanager
async def lifespan(app: FastAPI):
    await trachea.startup()  # creates indexes, validates app credentials
    yield

app = FastAPI(lifespan=lifespan)
app.add_exception_handler(TracheaError, trachea_exception_handler)
app.include_router(trachea.router, prefix="/auth")
```

## FastAPI Integration — With Existing Motor Client

```python
from motor.motor_asyncio import AsyncIOMotorClient
from trachea_login import TracheaLogin

mongo_client = AsyncIOMotorClient("mongodb+srv://...")
trachea = TracheaLogin(mongo_client=mongo_client)
```

---

## Protecting Routes

```python
from fastapi import Depends
from trachea_login import get_current_user, require_role
from trachea_login.models import CurrentUser

# Any authenticated user
@app.get("/dashboard")
async def dashboard(user: CurrentUser = Depends(get_current_user)):
    return {"sub": user.sub, "role": user.role, "plan": user.plan}

# Minimum role: member (default for all users — effectively same as get_current_user)
@app.get("/members")
async def members(user: CurrentUser = Depends(require_role(role="member"))):
    ...

# Minimum role: admin
@app.get("/admin")
async def admin(user: CurrentUser = Depends(require_role(role="admin"))):
    ...

# Minimum plan: pro
@app.get("/pro-feature")
async def pro(user: CurrentUser = Depends(require_role(plan="pro"))):
    ...

# Both role and plan enforced simultaneously
@app.get("/enterprise-admin")
async def ent_admin(user: CurrentUser = Depends(require_role(role="admin", plan="enterprise"))):
    ...
```

`require_role` enforces minimum level — `admin` passes a `member` check; `enterprise` passes a `pro` check.

---

## CurrentUser Model (JWT payload, injected by dependencies)

```python
class CurrentUser:
    sub: str        # firebase_uid (Firebase users) or username (native users)
    app_id: str     # the app this token was issued for
    role: str       # "guest" | "member" | "admin"
    plan: str       # "free" | "pro" | "enterprise"
    provider: str   # "google" | "facebook" | "apple" | "password" | "username"
```

---

## API Endpoints

### `POST /auth/login`

Firebase login:
```json
{ "firebase_token": "<Firebase ID token>", "app_id": "myapp" }
```

Username/password login:
```json
{ "username": "johndoe", "password": "MyPass123", "app_id": "myapp" }
```

Response `200`:
```json
{
  "access_token": "eyJ...",
  "refresh_token": "<opaque>",
  "token_type": "bearer",
  "user": {
    "firebase_uid": "abc123",
    "username": null,
    "email": "user@example.com",
    "name": "Jane Doe",
    "avatar": "https://...",
    "provider": "google",
    "app_id": "myapp",
    "role": "member",
    "plan": "free",
    "joined_at": "2026-04-01T10:00:00Z"
  }
}
```

---

### `POST /auth/register`

Register a new username/password user. Requires `"username"` in app's `allowed_auth_methods`.

```json
{ "username": "johndoe", "password": "MyPass123", "name": "John Doe", "app_id": "myapp" }
```

`name` is optional. Response `200`: same shape as `/login`.

Errors: `409 USERNAME_TAKEN`, `422 VALIDATION_ERROR` (password too short), `404 APP_NOT_FOUND`, `403 AUTH_METHOD_NOT_ALLOWED`.

---

### `POST /auth/refresh`

```json
{ "refresh_token": "<opaque>", "app_id": "myapp" }
```

Response `200`:
```json
{ "access_token": "eyJ...", "refresh_token": "<new opaque>", "token_type": "bearer" }
```

**Always store the new refresh token.** Presenting an already-rotated token triggers reuse detection — all tokens for that user+app are immediately revoked.

Errors: `401 REFRESH_TOKEN_INVALID`, `401 REFRESH_TOKEN_REUSE`.

---

### `POST /auth/logout`

Requires `Authorization: Bearer <access_token>`.

Response `200`: `{ "message": "Successfully logged out" }`

---

### `GET /auth/users/me`

Requires `Authorization: Bearer <access_token>`.

Response `200`: `UserResponse` (same as `user` object in login response).

---

### `PATCH /auth/users/me`

Requires `Authorization: Bearer <access_token>`. All fields optional.

```json
{
  "name": "Jane Smith",
  "phone": "+12125551234",
  "date_of_birth": "1990-06-15",
  "address": {
    "street": "123 Main St",
    "city": "New York",
    "state": "NY",
    "country": "US",
    "zip": "10001"
  }
}
```

Response `200`: updated `UserResponse`.

---

### `DELETE /auth/users/me`

Requires `Authorization: Bearer <access_token>`.

Deactivates the account. User can no longer log in.

Response `200`: `{ "message": "Account deactivated successfully" }`

---

### `PATCH /auth/users/me/plan`

Requires `Authorization: Bearer <access_token>`.

```json
{ "plan": "pro", "email": "jane@example.com" }
```

`email` is required when upgrading to `pro`/`enterprise` if the user has no email on file (username/password users have no email by default).

Response `200`: updated `UserResponse`.

Errors: `422 EMAIL_REQUIRED_FOR_PAID`.

---

## Error Response Shape

All errors:
```json
{ "error": "ERROR_CODE", "message": "Human-readable description", "status_code": 403 }
```

| Error Code | HTTP | Trigger |
|---|---|---|
| `APP_NOT_FOUND` | 404 | `app_id` not in database |
| `APP_INACTIVE` | 403 | App's `is_active` is `false` |
| `AUTH_METHOD_NOT_ALLOWED` | 403 | Login method not in `allowed_auth_methods` |
| `INVALID_FIREBASE_TOKEN` | 401 | Firebase ID token invalid or expired |
| `INVALID_CREDENTIALS` | 401 | Wrong username or password |
| `USERNAME_TAKEN` | 409 | Username already registered |
| `INVALID_TOKEN` | 401 | JWT is malformed |
| `TOKEN_EXPIRED` | 401 | JWT has expired |
| `REFRESH_TOKEN_INVALID` | 401 | Refresh token not found or expired |
| `REFRESH_TOKEN_REUSE` | 401 | Refresh token already rotated — all tokens revoked |
| `INSUFFICIENT_ROLE` | 403 | User role below required level |
| `INSUFFICIENT_PLAN` | 403 | User plan below required level |
| `EMAIL_REQUIRED_FOR_PAID` | 422 | Upgrading paid plan with no email on file |
| `USER_INACTIVE` | 403 | Account deactivated |
| `VALIDATION_ERROR` | 422 | Missing or invalid request body fields |

---

## MongoDB Collections

### `apps`
One document per registered application. Unique index on `app_id`.

### `users`
One document per unique identity. Indexes:
- `firebase_uid` — unique, sparse (absent for username/password users)
- `email` — unique, sparse (absent when no email exists)
- `username` — unique, sparse (absent for Firebase users)
- `apps.app_id` — non-unique

User document shape:
```json
{
  "_id": "ObjectId",
  "firebase_uid": "google-uid-abc",
  "email": "user@example.com",
  "name": "Jane Doe",
  "avatar": "https://...",
  "provider": "google",
  "phone": null,
  "date_of_birth": null,
  "address": null,
  "is_active": true,
  "created_at": "2026-04-01T10:00:00Z",
  "updated_at": "2026-04-01T10:00:00Z",
  "apps": [
    { "app_id": "app1", "role": "member", "plan": "pro", "joined_at": "..." },
    { "app_id": "app2", "role": "admin", "plan": "free", "joined_at": "..." }
  ]
}
```

### `refresh_tokens`
One document per issued refresh token. Indexes:
- `token_hash` — non-unique
- `expires_at` — TTL (MongoDB auto-deletes after expiry)

---

## Role & Plan Assignment

New users always start with `role: "member"` and `plan: "free"` for the app they join.

**Roles are not updatable via API** — update directly in MongoDB:
```python
await db.users.update_one(
    {"firebase_uid": "uid-abc", "apps.app_id": "myapp"},
    {"$set": {"apps.$.role": "admin"}}
)
```

**Plans** can be upgraded by the user via `PATCH /auth/users/me/plan` or directly in MongoDB:
```python
await db.users.update_one(
    {"username": "johndoe", "apps.app_id": "myapp"},
    {"$set": {"apps.$.plan": "enterprise"}}
)
```

---

## Multi-App Setup

Multiple apps share one MongoDB database. Each app has its own `TracheaLogin` instance with its own env vars (`TRACHEA_APP_ID`, `TRACHEA_APP_SECRET`). They share `TRACHEA_MONGO_URI` and `TRACHEA_DB_NAME`.

A user signing in to multiple apps gets one user document with one entry per app in `apps[]`.

---

## Complete Working Example

```python
# main.py
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends
from trachea_login import TracheaLogin, get_current_user, require_role
from trachea_login.exceptions import TracheaError, trachea_exception_handler
from trachea_login.models import CurrentUser

trachea = TracheaLogin()

@asynccontextmanager
async def lifespan(app: FastAPI):
    await trachea.startup()
    yield

app = FastAPI(lifespan=lifespan)
app.add_exception_handler(TracheaError, trachea_exception_handler)
app.include_router(trachea.router, prefix="/auth")

@app.get("/")
async def root():
    return {"status": "ok"}

@app.get("/profile")
async def profile(user: CurrentUser = Depends(get_current_user)):
    return {"sub": user.sub, "plan": user.plan, "role": user.role, "provider": user.provider}

@app.get("/pro-feature")
async def pro_feature(user: CurrentUser = Depends(require_role(plan="pro"))):
    return {"feature": "available"}

@app.get("/admin-panel")
async def admin_panel(user: CurrentUser = Depends(require_role(role="admin"))):
    return {"panel": "access granted"}

@app.get("/enterprise-admin")
async def enterprise_admin(user: CurrentUser = Depends(require_role(role="admin", plan="enterprise"))):
    return {"console": "access granted"}
```

`.env`:
```
TRACHEA_APP_ID=myapp
TRACHEA_APP_SECRET=my-secret
TRACHEA_MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/trachea
TRACHEA_FIREBASE_CREDENTIALS=/path/to/firebase-service-account.json
TRACHEA_JWT_SECRET=a-very-long-random-secret-key-at-least-32-chars
```

Run:
```bash
uvicorn main:app --reload
```

---

## Security Notes for Implementers

- **Never expose `TRACHEA_JWT_SECRET` or `TRACHEA_APP_SECRET`** in client-side code or version control.
- **Access tokens are stateless** — they cannot be revoked before expiry. Keep `TRACHEA_ACCESS_TOKEN_EXPIRE_MINUTES` short (15 min default).
- **Refresh tokens can be revoked** via logout, or automatically via reuse detection.
- The Firebase ID token is verified against Firebase's public keys on every `/auth/login` call — no caching is done by this package.
- Roles and plans are embedded in the JWT — a user's role/plan change in MongoDB will not be reflected until the next login or token refresh.
