# trachea-login — How To Use

A complete guide to installing, configuring, and integrating `trachea-login` into your FastAPI application.

---

## Table of Contents

1. [What It Does](#1-what-it-does)
2. [Prerequisites](#2-prerequisites)
3. [Installation](#3-installation)
4. [Firebase Setup](#4-firebase-setup)
5. [Environment Variables](#5-environment-variables)
6. [MongoDB App Registration](#6-mongodb-app-registration)
7. [Mounting in FastAPI](#7-mounting-in-fastapi)
8. [Protecting Routes](#8-protecting-routes)
9. [API Reference](#9-api-reference)
10. [Request & Response Schemas](#10-request--response-schemas)
11. [Error Reference](#11-error-reference)
12. [Multi-App Setup](#12-multi-app-setup)
13. [Role & Plan Hierarchy](#13-role--plan-hierarchy)
14. [Auth Flows — Step by Step](#14-auth-flows--step-by-step)
15. [MongoDB Collections](#15-mongodb-collections)
16. [Advanced Usage](#16-advanced-usage)

---

## 1. What It Does

`trachea-login` is a drop-in FastAPI authentication package that provides:

- **Firebase social login** — Google, Facebook, Apple, email/password via Firebase Identity Platform
- **Native username/password login** — no Firebase required, free-plan users only
- **JWT access tokens** — short-lived (15 min default), signed with your secret
- **Opaque refresh tokens** — long-lived (30 days default), stored hashed in MongoDB, with automatic rotation and reuse detection
- **Role-based access control** — `guest`, `member`, `admin` with hierarchy enforcement
- **Plan-based access control** — `free`, `pro`, `enterprise` with hierarchy enforcement
- **Multi-app support** — one MongoDB database serves multiple applications; users are scoped per-app

---

## 2. Prerequisites

- Python 3.10+
- MongoDB (Atlas or self-hosted)
- Firebase project (required for social/email login; not needed if only using username/password)

---

## 3. Installation

```bash
pip install trachea-login
```

Or install from source:

```bash
git clone https://github.com/trachea-inc/trachea-login
cd trachea-login
pip install -e ".[dev]"
```

---

## 4. Firebase Setup

> Skip this section if you only need username/password authentication.

1. Go to the [Firebase Console](https://console.firebase.google.com) and create a project.
2. Enable **Authentication** and turn on the providers you want (Google, Facebook, Apple, Email/Password).
3. Go to **Project Settings → Service Accounts → Generate new private key**.
4. Download the JSON file. You can either:
   - Pass the **file path** as `TRACHEA_FIREBASE_CREDENTIALS=/path/to/service-account.json`
   - Pass the **JSON content directly** as a string: `TRACHEA_FIREBASE_CREDENTIALS='{"type":"service_account",...}'`

On the **client side**, your frontend uses the Firebase Client SDK to authenticate and obtain a Firebase ID token, then passes that token to `POST /auth/login`.

---

## 5. Environment Variables

All settings use the `TRACHEA_` prefix. Create a `.env` file in your project root:

```bash
# .env

# --- Required ---

# Your app's unique identifier (must match an entry in the apps collection)
TRACHEA_APP_ID=myapp

# Secret used to verify your app's identity at startup
TRACHEA_APP_SECRET=your-app-secret-key

# MongoDB connection URI
TRACHEA_MONGO_URI=mongodb+srv://user:password@cluster.mongodb.net/trachea

# Firebase service account — file path OR raw JSON string
TRACHEA_FIREBASE_CREDENTIALS=/path/to/firebase-service-account.json
# OR
TRACHEA_FIREBASE_CREDENTIALS='{"type":"service_account","project_id":"my-proj",...}'

# Secret used to sign JWT access tokens — use a strong random value (32+ chars)
TRACHEA_JWT_SECRET=a-very-long-random-secret-key-at-least-32-characters

# --- Optional (defaults shown) ---

# How long access tokens are valid (minutes)
TRACHEA_ACCESS_TOKEN_EXPIRE_MINUTES=15

# How long refresh tokens are valid (days)
TRACHEA_REFRESH_TOKEN_EXPIRE_DAYS=30

# Minimum password length for username/password registration
TRACHEA_PASSWORD_MIN_LENGTH=8

# MongoDB database name
TRACHEA_DB_NAME=trachea
```

All optional fields fall back to the shown defaults if not set.

---

## 6. MongoDB App Registration

Before starting your application, you must insert a document into the `apps` collection that represents your app. This is a one-time setup step.

```python
# register_app.py
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from trachea_login.db.app_repo import hash_secret


async def register():
    client = AsyncIOMotorClient("mongodb+srv://user:password@cluster.mongodb.net/trachea")
    db = client["trachea"]

    await db.apps.insert_one({
        "app_id": "myapp",                        # must match TRACHEA_APP_ID
        "app_secret": await hash_secret("your-app-secret-key"),  # must match TRACHEA_APP_SECRET
        "name": "My Application",
        "allowed_auth_methods": [                 # which login methods this app permits
            "google",
            "facebook",
            "apple",
            "password",   # Firebase email/password
            "username",   # native username/password (free plan only)
        ],
        "allowed_domains": ["myapp.com", "localhost"],
        "is_active": True,
    })
    print("App registered.")


asyncio.run(register())
```

Run this script once:

```bash
python register_app.py
```

### App document fields

| Field | Type | Description |
|-------|------|-------------|
| `app_id` | str | Unique identifier — must match `TRACHEA_APP_ID` |
| `app_secret` | str | Bcrypt hash of your app secret |
| `name` | str | Human-readable app name |
| `allowed_auth_methods` | list[str] | One or more of: `google`, `facebook`, `apple`, `password`, `username` |
| `allowed_domains` | list[str] | Informational — allowed origin domains |
| `is_active` | bool | Set to `False` to disable all logins for this app |

---

## 7. Mounting in FastAPI

### Minimal setup

```python
# main.py
from fastapi import FastAPI
from trachea_login import TracheaLogin
from trachea_login.exceptions import TracheaError, trachea_exception_handler

app = FastAPI()

# Register the error handler so auth errors return clean JSON
app.add_exception_handler(TracheaError, trachea_exception_handler)

# Initialize trachea-login (reads all config from environment / .env)
trachea = TracheaLogin()

# Mount the auth + users router under /auth
app.include_router(trachea.router, prefix="/auth")
```

### With startup validation (recommended)

Use the `lifespan` pattern to run `trachea.startup()` on boot. This creates MongoDB indexes and validates that your `app_id` / `app_secret` are correctly registered.

```python
from contextlib import asynccontextmanager
from fastapi import FastAPI
from trachea_login import TracheaLogin
from trachea_login.exceptions import TracheaError, trachea_exception_handler


@asynccontextmanager
async def lifespan(app: FastAPI):
    await trachea.startup()   # creates indexes + validates app credentials
    yield


app = FastAPI(lifespan=lifespan)
app.add_exception_handler(TracheaError, trachea_exception_handler)

trachea = TracheaLogin()
app.include_router(trachea.router, prefix="/auth")
```

### With a custom MongoDB client

If your app already manages its own Motor client, pass it in to avoid creating a second connection:

```python
from motor.motor_asyncio import AsyncIOMotorClient
from trachea_login import TracheaLogin

mongo_client = AsyncIOMotorClient("mongodb+srv://...")
trachea = TracheaLogin(mongo_client=mongo_client)
```

---

## 8. Protecting Routes

Import `get_current_user` and `require_role` from `trachea_login` and use them as FastAPI dependencies.

### Get the current user (any authenticated user)

```python
from fastapi import FastAPI, Depends
from trachea_login import get_current_user
from trachea_login.models import CurrentUser

app = FastAPI()

@app.get("/dashboard")
async def dashboard(user: CurrentUser = Depends(get_current_user)):
    return {
        "sub": user.sub,       # firebase_uid or username
        "app_id": user.app_id,
        "role": user.role,     # "guest" | "member" | "admin"
        "plan": user.plan,     # "free" | "pro" | "enterprise"
        "provider": user.provider,  # "google" | "facebook" | "apple" | "password" | "username"
    }
```

### Require a minimum role

```python
from trachea_login import require_role

@app.get("/admin/dashboard")
async def admin_dashboard(user: CurrentUser = Depends(require_role(role="admin"))):
    return {"message": f"Welcome admin {user.sub}"}
```

### Require a minimum plan

```python
@app.get("/premium-feature")
async def premium_feature(user: CurrentUser = Depends(require_role(plan="pro"))):
    return {"feature": "premium content"}
```

### Require both role and plan

```python
@app.get("/enterprise-admin")
async def enterprise_admin(user: CurrentUser = Depends(require_role(role="admin", plan="enterprise"))):
    return {"access": "granted"}
```

`require_role` enforces both conditions simultaneously. If either fails, a `403` is returned.

---

## 9. API Reference

All endpoints are mounted at the prefix you choose (e.g., `/auth`). The users sub-router is mounted at `/auth/users`.

### Auth Endpoints

#### `POST /auth/login`

Authenticate with a Firebase ID token **or** a username/password pair.

**Firebase login request:**
```json
{
  "firebase_token": "<Firebase ID token from client SDK>",
  "app_id": "myapp"
}
```

**Username/password login request:**
```json
{
  "username": "johndoe",
  "password": "MyPassword123",
  "app_id": "myapp"
}
```

**Response `200`:**
```json
{
  "access_token": "eyJ...",
  "refresh_token": "dGhpcyBpcyBhbiBvcGFxdWUgdG9rZW4...",
  "token_type": "bearer",
  "user": {
    "firebase_uid": "abc123",
    "username": null,
    "email": "user@example.com",
    "name": "Jane Doe",
    "avatar": "https://...",
    "provider": "google",
    "app_id": "myapp",
    "role": "member",
    "plan": "free",
    "joined_at": "2026-04-01T10:00:00Z"
  }
}
```

---

#### `POST /auth/register`

Register a new username/password user. Only available if `username` is in the app's `allowed_auth_methods`.

**Request:**
```json
{
  "username": "johndoe",
  "password": "MyPassword123",
  "name": "John Doe",      // optional
  "app_id": "myapp"
}
```

**Response `200`:** Same shape as `/login`.

---

#### `POST /auth/refresh`

Exchange a refresh token for a new access token + new refresh token. The old refresh token is immediately invalidated (rotation).

**Request:**
```json
{
  "refresh_token": "<opaque refresh token>",
  "app_id": "myapp"
}
```

**Response `200`:**
```json
{
  "access_token": "eyJ...",
  "refresh_token": "<new opaque refresh token>",
  "token_type": "bearer"
}
```

> Always replace the stored refresh token with the new one. Reusing an old refresh token triggers reuse detection and revokes **all** refresh tokens for that user+app.

---

#### `POST /auth/logout`

Revokes all refresh tokens for the authenticated user in this app. Requires a valid access token in the `Authorization` header.

**Headers:** `Authorization: Bearer <access_token>`

**Response `200`:**
```json
{ "message": "Successfully logged out" }
```

---

### User Endpoints

All user endpoints require `Authorization: Bearer <access_token>`.

#### `GET /auth/users/me`

Returns the current user's profile.

**Response `200`:** `UserResponse` object (see [schemas](#10-request--response-schemas)).

---

#### `PATCH /auth/users/me`

Update profile fields. Only provided fields are updated (all are optional).

**Request:**
```json
{
  "name": "Jane Smith",
  "phone": "+12125551234",
  "date_of_birth": "1990-06-15",
  "address": {
    "street": "123 Main St",
    "city": "New York",
    "state": "NY",
    "country": "US",
    "zip": "10001"
  }
}
```

**Response `200`:** Updated `UserResponse`.

---

#### `DELETE /auth/users/me`

Deactivates the current user's account. The user can no longer log in.

**Response `200`:**
```json
{ "message": "Account deactivated successfully" }
```

---

#### `PATCH /auth/users/me/plan`

Upgrade or change the user's plan for this app.

**Request:**
```json
{
  "plan": "pro",
  "email": "jane@example.com"   // required if upgrading to "pro"/"enterprise" and no email on file
}
```

**Response `200`:** Updated `UserResponse`.

> Username/password users have no email by default. When upgrading to a paid plan (`pro` or `enterprise`), you must include `email` in this request unless the user already has one on file.

---

## 10. Request & Response Schemas

### `CurrentUser` (JWT payload, injected by dependencies)

```python
class CurrentUser:
    sub: str        # firebase_uid for Firebase users; username for native users
    app_id: str
    role: str       # "guest" | "member" | "admin"
    plan: str       # "free" | "pro" | "enterprise"
    provider: str   # "google" | "facebook" | "apple" | "password" | "username"
```

### `UserResponse`

```python
class UserResponse:
    firebase_uid: str | None
    username: str | None
    email: str | None
    name: str | None
    avatar: str | None
    provider: str
    app_id: str
    role: str
    plan: str
    joined_at: datetime
```

### `LoginRequest`

```python
class LoginRequest:
    firebase_token: str | None  # use this for Firebase login
    username: str | None        # use these for native login
    password: str | None
    app_id: str                 # required
```

### `RegisterRequest`

```python
class RegisterRequest:
    username: str
    password: str
    name: str | None   # optional display name
    app_id: str
```

### `RefreshRequest`

```python
class RefreshRequest:
    refresh_token: str
    app_id: str
```

### `UpdateProfileRequest`

```python
class UpdateProfileRequest:
    name: str | None
    phone: str | None
    date_of_birth: str | None
    address: Address | None
```

### `Address`

```python
class Address:
    street: str | None
    city: str | None
    state: str | None
    country: str | None
    zip: str | None
```

### `UpdatePlanRequest`

```python
class UpdatePlanRequest:
    plan: str              # "free" | "pro" | "enterprise"
    email: str | None      # required when upgrading paid plan with no email on file
```

### `LoginResponse`

```python
class LoginResponse:
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: UserResponse
```

### `TokenResponse`

```python
class TokenResponse:
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
```

---

## 11. Error Reference

All errors return this JSON shape:

```json
{
  "error": "ERROR_CODE",
  "message": "Human-readable description",
  "status_code": 403
}
```

| Error Code | HTTP Status | When It Occurs |
|---|---|---|
| `APP_NOT_FOUND` | 404 | `app_id` does not exist in the database |
| `APP_INACTIVE` | 403 | App's `is_active` is `False` |
| `AUTH_METHOD_NOT_ALLOWED` | 403 | Login method not in app's `allowed_auth_methods` |
| `INVALID_FIREBASE_TOKEN` | 401 | Firebase ID token is invalid or expired |
| `INVALID_CREDENTIALS` | 401 | Wrong username or password |
| `USERNAME_TAKEN` | 409 | Username already registered |
| `INVALID_TOKEN` | 401 | JWT access token is malformed |
| `TOKEN_EXPIRED` | 401 | JWT access token has expired |
| `REFRESH_TOKEN_INVALID` | 401 | Refresh token not found or expired |
| `REFRESH_TOKEN_REUSE` | 401 | Refresh token was already used — all tokens revoked |
| `INSUFFICIENT_ROLE` | 403 | User's role is below the required level |
| `INSUFFICIENT_PLAN` | 403 | User's plan is below the required level |
| `EMAIL_REQUIRED_FOR_PAID` | 422 | Upgrading to paid plan with no email on file |
| `USER_INACTIVE` | 403 | User account has been deactivated |
| `VALIDATION_ERROR` | 422 | Request body is missing required fields |

### Handling errors on the client

```javascript
const resp = await fetch("/auth/login", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ firebase_token: idToken, app_id: "myapp" }),
});

if (!resp.ok) {
  const err = await resp.json();
  // err.error  → "INVALID_FIREBASE_TOKEN"
  // err.message → "Invalid or expired Firebase token"
  // err.status_code → 401
}
```

---

## 12. Multi-App Setup

All apps share one MongoDB database. Each user document has an `apps` array that tracks per-app role and plan. A user who signs into both `app1` and `app2` with the same Google account will have a single user document with two entries in `apps`.

### Registering a second app

```python
await db.apps.insert_one({
    "app_id": "app2",
    "app_secret": await hash_secret("app2-secret"),
    "name": "Second App",
    "allowed_auth_methods": ["google", "username"],
    "allowed_domains": ["app2.example.com"],
    "is_active": True,
})
```

Each app runs its own `TracheaLogin` instance with its own env vars (`TRACHEA_APP_ID=app2`, `TRACHEA_APP_SECRET=app2-secret`). They share the same `TRACHEA_MONGO_URI` and `TRACHEA_DB_NAME`.

### User document shape in MongoDB

```json
{
  "_id": "...",
  "firebase_uid": "google-uid-abc",
  "username": null,
  "email": "user@example.com",
  "name": "Jane Doe",
  "avatar": "https://...",
  "provider": "google",
  "phone": null,
  "date_of_birth": null,
  "address": null,
  "is_active": true,
  "created_at": "2026-04-01T10:00:00Z",
  "updated_at": "2026-04-01T10:00:00Z",
  "apps": [
    {
      "app_id": "app1",
      "role": "member",
      "plan": "pro",
      "joined_at": "2026-04-01T10:00:00Z"
    },
    {
      "app_id": "app2",
      "role": "admin",
      "plan": "free",
      "joined_at": "2026-04-02T08:00:00Z"
    }
  ]
}
```

---

## 13. Role & Plan Hierarchy

Roles and plans have a numeric hierarchy. `require_role` enforces **minimum** levels — a user with `admin` passes a `member` check.

### Roles

| Role | Level | Description |
|------|-------|-------------|
| `guest` | 0 | Unauthenticated placeholder |
| `member` | 1 | Default for all new users |
| `admin` | 2 | Elevated privileges |

### Plans

| Plan | Level | Notes |
|------|-------|-------|
| `free` | 0 | Default for all new users |
| `pro` | 1 | Requires email on file |
| `enterprise` | 2 | Requires email on file |

Users are assigned `role: "member"` and `plan: "free"` when they first join an app. Roles must be updated directly in MongoDB (no endpoint is provided — role assignment is an admin/backend concern).

### Updating a user's role (admin operation)

```python
from motor.motor_asyncio import AsyncIOMotorClient

client = AsyncIOMotorClient("mongodb+srv://...")
db = client["trachea"]

await db.users.update_one(
    {"firebase_uid": "user-uid", "apps.app_id": "myapp"},
    {"$set": {"apps.$.role": "admin"}}
)
```

---

## 14. Auth Flows — Step by Step

### Flow A: Firebase (Google / Facebook / Apple / Email-Password)

```
Client                          Your API                    Firebase
  │                                │                            │
  │── Firebase SDK login ──────────────────────────────────────►│
  │◄─────────────────── ID token (short-lived) ─────────────────│
  │                                │                            │
  │── POST /auth/login ────────────►│                           │
  │   { firebase_token, app_id }   │── verify_id_token() ──────►│
  │                                │◄── decoded token ──────────│
  │                                │  upsert user in MongoDB    │
  │                                │  issue access + refresh    │
  │◄── { access_token,             │                            │
  │      refresh_token, user } ────│                            │
```

### Flow B: Username/Password

```
Client                          Your API
  │                                │
  │── POST /auth/register ─────────►│
  │   { username, password,        │  validate password length
  │     name, app_id }             │  hash password (bcrypt)
  │                                │  insert user in MongoDB
  │◄── { access_token,             │  issue access + refresh
  │      refresh_token, user } ────│
```

### Flow C: Token Refresh

```
Client                          Your API                    MongoDB
  │                                │                            │
  │── POST /auth/refresh ──────────►│                           │
  │   { refresh_token, app_id }    │── look up token hash ─────►│
  │                                │  mark old token revoked    │
  │                                │  insert new token          │
  │◄── { access_token,             │  re-fetch user data        │
  │      new_refresh_token } ──────│                            │
```

> Store the new refresh token after every successful refresh call. Presenting an old (already-rotated) token triggers reuse detection and revokes all refresh tokens for that user.

### Flow D: Making Authenticated Requests

```
Client                          Your API
  │                                │
  │── GET /dashboard ──────────────►│
  │   Authorization: Bearer <jwt>  │  verify JWT signature
  │                                │  decode claims → CurrentUser
  │◄── { ... } ────────────────────│
```

The access token is never stored in MongoDB — it is verified purely by signature. No database lookup is needed per request.

---

## 15. MongoDB Collections

### `apps`

One document per registered application.

| Field | Index |
|-------|-------|
| `app_id` | Unique |

### `users`

One document per unique identity (Firebase UID or username).

| Field | Index |
|-------|-------|
| `firebase_uid` | Unique, sparse |
| `email` | Unique, sparse |
| `username` | Unique, sparse |
| `apps.app_id` | Non-unique |

### `refresh_tokens`

One document per issued refresh token. MongoDB TTL index automatically expires old tokens.

| Field | Index |
|-------|-------|
| `token_hash` | Non-unique |
| `expires_at` | TTL (auto-delete after expiry) |

Indexes are created automatically by `trachea.startup()`. You can also call them manually:

```python
from trachea_login.db.mongo import create_indexes
await create_indexes(db)
```

---

## 16. Advanced Usage

### Accessing the raw MongoDB client

```python
trachea = TracheaLogin()
db = trachea._db          # AsyncIOMotorDatabase
client = trachea._client  # AsyncIOMotorClient
```

### Using the routers without TracheaLogin

If you want more control, you can use the router factories directly instead of `TracheaLogin`:

```python
from fastapi import FastAPI
from motor.motor_asyncio import AsyncIOMotorClient
from trachea_login.config import TracheaSettings
from trachea_login.routers.auth import create_auth_router
from trachea_login.routers.users import create_users_router
from trachea_login.exceptions import TracheaError, trachea_exception_handler

settings = TracheaSettings()
client = AsyncIOMotorClient(settings.mongo_uri)
db = client[settings.db_name]

app = FastAPI()
app.add_exception_handler(TracheaError, trachea_exception_handler)
app.include_router(create_auth_router(settings, db), prefix="/auth")
app.include_router(create_users_router(settings, db), prefix="/auth/users")
```

### Generating a secure JWT secret

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

### Generating a secure app secret

```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

### Setting a user's role or plan from the backend

Roles and plans are not updatable through the API (by design — they are admin concerns). Update them directly in MongoDB:

```python
# Promote a Firebase user to admin in app1
await db.users.update_one(
    {"firebase_uid": "uid-abc", "apps.app_id": "app1"},
    {"$set": {"apps.$.role": "admin"}}
)

# Manually set a plan (bypassing email requirement)
await db.users.update_one(
    {"username": "johndoe", "apps.app_id": "app1"},
    {"$set": {"apps.$.plan": "enterprise"}}
)
```

### Disabling an app

```python
await db.apps.update_one({"app_id": "myapp"}, {"$set": {"is_active": False}})
```

All subsequent login and refresh attempts for this app will return `403 APP_INACTIVE`.

### Restricting auth methods per app

```python
# Only allow Google login for this app
await db.apps.update_one(
    {"app_id": "myapp"},
    {"$set": {"allowed_auth_methods": ["google"]}}
)
```

### Complete working example

```python
# main.py
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends
from trachea_login import TracheaLogin, get_current_user, require_role
from trachea_login.exceptions import TracheaError, trachea_exception_handler
from trachea_login.models import CurrentUser

trachea = TracheaLogin()  # reads .env automatically


@asynccontextmanager
async def lifespan(app: FastAPI):
    await trachea.startup()
    yield


app = FastAPI(lifespan=lifespan)
app.add_exception_handler(TracheaError, trachea_exception_handler)
app.include_router(trachea.router, prefix="/auth")


# Open endpoint
@app.get("/")
async def root():
    return {"status": "ok"}


# Any logged-in user
@app.get("/profile")
async def profile(user: CurrentUser = Depends(get_current_user)):
    return {"sub": user.sub, "plan": user.plan, "role": user.role}


# Pro plan or higher
@app.get("/pro-feature")
async def pro_feature(user: CurrentUser = Depends(require_role(plan="pro"))):
    return {"feature": "available"}


# Admin only
@app.delete("/admin/user/{uid}")
async def delete_user(uid: str, user: CurrentUser = Depends(require_role(role="admin"))):
    return {"deleted": uid}


# Admin with enterprise plan
@app.get("/enterprise-console")
async def enterprise_console(user: CurrentUser = Depends(require_role(role="admin", plan="enterprise"))):
    return {"console": "access granted"}
```
