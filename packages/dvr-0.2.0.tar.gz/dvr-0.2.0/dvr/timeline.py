"""Timeline, track, and clip wrappers.

The Resolve API distinguishes between *MediaPoolItem* (a clip in the bin)
and *TimelineItem* (an instance of a clip placed on a track). This module
mirrors that, but flattens the navigation: you almost never need to call
``GetItemListInTrack`` yourself.

A single :meth:`Timeline.inspect` call returns a structured snapshot of
the whole timeline — tracks, clips, markers, settings — that is the
recommended way to read state. Mutations go through dedicated methods.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Iterable, Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, List  # noqa: UP035 — `List` avoids `list` method shadow

from . import errors
from ._wrap import require

if TYPE_CHECKING:
    from .color import ColorOps
    from .media import Asset

logger = logging.getLogger("dvr.timeline")


# ---------------------------------------------------------------------------
# Track helpers
# ---------------------------------------------------------------------------


_TRACK_TYPES = ("video", "audio", "subtitle")


def _validate_track_type(track_type: str) -> str:
    if track_type not in _TRACK_TYPES:
        raise errors.TrackError(
            f"Unknown track type {track_type!r}.",
            cause=f"Track type must be one of {_TRACK_TYPES}.",
            fix=f"Use one of {_TRACK_TYPES}.",
            state={"requested": track_type},
        )
    return track_type


# ---------------------------------------------------------------------------
# TimelineItem (a clip placed on a timeline)
# ---------------------------------------------------------------------------


class Clip:
    """A clip placed on a timeline (Resolve's ``TimelineItem``)."""

    def __init__(self, raw: Any, *, track_type: str, track_index: int) -> None:
        self._raw = raw
        self._track_type = track_type
        self._track_index = track_index

    @property
    def raw(self) -> Any:
        return self._raw

    @property
    def name(self) -> str:
        return self._raw.GetName()

    @property
    def start(self) -> int:
        return self._raw.GetStart()

    @property
    def end(self) -> int:
        return self._raw.GetEnd()

    @property
    def duration(self) -> int:
        return self._raw.GetDuration()

    @property
    def track_type(self) -> str:
        return self._track_type

    @property
    def track_index(self) -> int:
        return self._track_index

    @property
    def enabled(self) -> bool:
        return bool(self._raw.GetClipEnabled())

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._raw.SetClipEnabled(bool(value))

    def get_property(self, key: str | None = None) -> Any:
        return self._raw.GetProperty(key) if key else self._raw.GetProperty()

    def set_property(self, key: str, value: Any) -> None:
        if not self._raw.SetProperty(key, value):
            raise errors.ClipError(
                f"Could not set clip property {key!r}.",
                cause="SetProperty returned False — invalid key, type, or value range.",
                fix="See `dvr schema clip-properties` for valid keys per Resolve version.",
                state={"clip": self.name, "key": key, "value": value},
            )

    def add_marker(
        self,
        *,
        frame: int | None = None,
        color: str = "Blue",
        name: str = "",
        note: str = "",
        duration: int = 1,
        custom_data: str = "",
    ) -> None:
        """Add a marker on this clip."""
        target = frame if frame is not None else self.start
        ok = self._raw.AddMarker(target, color, name, note, duration, custom_data)
        if not ok:
            raise errors.ClipError(
                f"Could not add marker on clip {self.name!r}.",
                cause="AddMarker returned False — frame may be out of range, or color invalid.",
                state={
                    "clip": self.name,
                    "frame": target,
                    "color": color,
                },
            )

    def replace(self, source_path: str, *, preserve_subclip: bool = True) -> None:
        """Relink to a new source file. Preserves grades / Fusion / tracking."""
        mp_item = self._raw.GetMediaPoolItem()
        if mp_item is None:
            raise errors.ClipError(
                f"Clip {self.name!r} has no underlying MediaPoolItem.",
                cause="GetMediaPoolItem returned None — the clip may be a generator or compound.",
                state={"clip": self.name},
            )
        ok = (
            mp_item.ReplaceClipPreserveSubClip(source_path)
            if preserve_subclip and hasattr(mp_item, "ReplaceClipPreserveSubClip")
            else mp_item.ReplaceClip(source_path)
        )
        if not ok:
            raise errors.ClipError(
                f"Could not relink {self.name!r} to {source_path!r}.",
                cause="ReplaceClip returned False — the source path may be missing or invalid.",
                fix="Confirm the file exists and is readable.",
                state={"clip": self.name, "source_path": source_path},
            )

    # --- accessors to other domains ------------------------------------

    @property
    def asset(self) -> Asset | None:
        """The underlying media-pool asset, if any."""
        from .media import Asset as _Asset

        raw = self._raw.GetMediaPoolItem()
        return _Asset(raw) if raw is not None else None

    @property
    def color(self) -> ColorOps:
        """Color-page operations on this clip (CDL, LUT, versions, masks)."""
        from .color import ColorOps as _ColorOps

        return _ColorOps(self)

    @property
    def fusion(self) -> ClipFusion:
        """Fusion-comp operations on this clip (add, import, export, switch)."""
        return ClipFusion(self)

    @property
    def takes(self) -> Takes:
        """Take/variant operations on this clip."""
        return Takes(self)

    # --- output cache --------------------------------------------------

    def set_color_cache(self, mode: str = "auto") -> None:
        """Set color page output caching: ``auto`` | ``on`` | ``off``."""
        try:
            value = {"auto": 0, "on": 1, "off": 2}[mode]
        except KeyError as exc:
            raise errors.ClipError(
                f"Color cache mode must be auto/on/off, got {mode!r}.",
            ) from exc
        self._raw.SetColorOutputCache(value)

    def set_fusion_cache(self, mode: str = "auto") -> None:
        try:
            value = {"auto": 0, "on": 1, "off": 2}[mode]
        except KeyError as exc:
            raise errors.ClipError(
                f"Fusion cache mode must be auto/on/off, got {mode!r}.",
            ) from exc
        self._raw.SetFusionOutputCache(value)

    # --- inspection ---------------------------------------------------

    def inspect(self) -> dict[str, Any]:
        try:
            props = dict(self._raw.GetProperty() or {})
        except Exception:
            props = {}
        try:
            fusion_comps = list(self._raw.GetFusionCompNameList() or [])
        except Exception:
            fusion_comps = []
        try:
            versions = list(self._raw.GetVersionNameList(0) or [])
        except Exception:
            versions = []
        return {
            "name": self.name,
            "track_type": self._track_type,
            "track_index": self._track_index,
            "start": self.start,
            "end": self.end,
            "duration": self.duration,
            "enabled": self.enabled,
            "properties": props,
            "fusion_comps": fusion_comps,
            "color_versions": versions,
        }


# ---------------------------------------------------------------------------
# Fusion comps on a Clip
# ---------------------------------------------------------------------------


class ClipFusion:
    """Per-clip Fusion comp operations."""

    def __init__(self, clip: Clip) -> None:
        self._clip = clip
        self._raw = clip.raw

    def names(self) -> List[str]:  # noqa: UP006
        return [str(n) for n in (self._raw.GetFusionCompNameList() or [])]

    def add(self) -> Any:
        comp = self._raw.AddFusionComp()
        if comp is None:
            raise errors.FusionError(
                f"Could not add a Fusion comp on clip {self._clip.name!r}.",
                cause="AddFusionComp returned None.",
                state={"clip": self._clip.name},
            )
        return comp

    def load(self, name: str) -> Any:
        comp = self._raw.LoadFusionCompByName(name)
        if comp is None:
            raise errors.FusionError(
                f"Could not load Fusion comp {name!r}.",
                cause="LoadFusionCompByName returned None.",
                state={"clip": self._clip.name, "name": name},
            )
        return comp

    def import_(self, file_path: str) -> Any:
        comp = self._raw.ImportFusionComp(file_path)
        if comp is None:
            raise errors.FusionError(
                f"Could not import Fusion comp from {file_path!r}.",
                cause="ImportFusionComp returned None.",
                state={"clip": self._clip.name, "file_path": file_path},
            )
        return comp

    def export(self, name: str, file_path: str) -> None:
        if not self._raw.ExportFusionComp(name, file_path):
            raise errors.FusionError(
                f"Could not export Fusion comp {name!r} to {file_path!r}.",
                state={"clip": self._clip.name, "name": name, "file_path": file_path},
            )

    def rename(self, old: str, new: str) -> None:
        if not self._raw.RenameFusionCompByName(old, new):
            raise errors.FusionError(
                f"Could not rename Fusion comp {old!r} to {new!r}.",
                state={"clip": self._clip.name, "old": old, "new": new},
            )

    def delete(self, name: str) -> None:
        if not self._raw.DeleteFusionCompByName(name):
            raise errors.FusionError(
                f"Could not delete Fusion comp {name!r}.",
                state={"clip": self._clip.name, "name": name},
            )


# ---------------------------------------------------------------------------
# Takes on a Clip
# ---------------------------------------------------------------------------


class Takes:
    """Take / variant management on a single clip."""

    def __init__(self, clip: Clip) -> None:
        self._clip = clip
        self._raw = clip.raw

    @property
    def count(self) -> int:
        return int(self._raw.GetTakesCount())

    @property
    def selected_index(self) -> int:
        return int(self._raw.GetSelectedTakeIndex())

    def add(
        self,
        asset: Any,
        *,
        start_frame: int | None = None,
        end_frame: int | None = None,
    ) -> None:
        from .media import Asset as _Asset

        raw_asset = asset.raw if isinstance(asset, _Asset) else asset
        ok = (
            self._raw.AddTake(raw_asset, start_frame, end_frame)
            if start_frame is not None and end_frame is not None
            else self._raw.AddTake(raw_asset)
        )
        if not ok:
            raise errors.ClipError(
                f"Could not add take to clip {self._clip.name!r}.",
                state={"clip": self._clip.name},
            )

    def select(self, index: int) -> None:
        if not self._raw.SelectTakeByIndex(index):
            raise errors.ClipError(
                f"Could not select take {index}.",
                state={"clip": self._clip.name, "index": index, "count": self.count},
            )

    def get(self, index: int) -> dict[str, Any]:
        return dict(self._raw.GetTakeByIndex(index) or {})

    def delete(self, index: int) -> None:
        if not self._raw.DeleteTakeByIndex(index):
            raise errors.ClipError(
                f"Could not delete take {index}.",
                state={"clip": self._clip.name, "index": index},
            )

    def finalize(self) -> None:
        self._raw.FinalizeTake()


# ---------------------------------------------------------------------------
# Track wrapper
# ---------------------------------------------------------------------------


class Track:
    """A single video/audio/subtitle track on a timeline."""

    def __init__(self, timeline: Timeline, track_type: str, index: int) -> None:
        self._timeline = timeline
        self._raw = timeline.raw
        self._track_type = _validate_track_type(track_type)
        self._index = index

    @property
    def type(self) -> str:
        return self._track_type

    @property
    def index(self) -> int:
        return self._index

    @property
    def name(self) -> str:
        return self._raw.GetTrackName(self._track_type, self._index)

    @name.setter
    def name(self, value: str) -> None:
        if not self._raw.SetTrackName(self._track_type, self._index, value):
            raise errors.TrackError(
                f"Could not rename {self._track_type} track {self._index}.",
                state={"track_type": self._track_type, "index": self._index, "value": value},
            )

    @property
    def enabled(self) -> bool:
        return bool(self._raw.GetIsTrackEnabled(self._track_type, self._index))

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._raw.SetTrackEnable(self._track_type, self._index, bool(value))

    @property
    def locked(self) -> bool:
        return bool(self._raw.GetIsTrackLocked(self._track_type, self._index))

    @locked.setter
    def locked(self, value: bool) -> None:
        self._raw.SetTrackLock(self._track_type, self._index, bool(value))

    @property
    def subtype(self) -> str | None:
        """Audio channel format (mono/stereo/5.1/7.1/adaptive). None for V/S."""
        if self._track_type != "audio":
            return None
        return self._raw.GetTrackSubType(self._track_index)

    @property
    def _track_index(self) -> int:
        # Older API surface uses ``GetTrackSubType(index)`` without type arg.
        return self._index

    def clips(self) -> list[Clip]:
        items = self._raw.GetItemListInTrack(self._track_type, self._index) or []
        return [Clip(it, track_type=self._track_type, track_index=self._index) for it in items]

    def inspect(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "type": self._track_type,
            "index": self._index,
            "name": self.name,
            "enabled": self.enabled,
            "locked": self.locked,
            "clip_count": len(self.clips()),
        }
        if self._track_type == "audio":
            result["subtype"] = self.subtype
        return result


# ---------------------------------------------------------------------------
# Timeline
# ---------------------------------------------------------------------------


class Timeline:
    """A single timeline within a project."""

    def __init__(self, raw: Any, project: Any) -> None:
        self._raw = raw
        self._project_raw = project

    @property
    def raw(self) -> Any:
        return self._raw

    @property
    def name(self) -> str:
        return self._raw.GetName()

    @name.setter
    def name(self, value: str) -> None:
        if not self._raw.SetName(value):
            raise errors.TimelineError(
                f"Could not rename timeline to {value!r}.",
                cause="A timeline with this name may already exist in this project.",
                state={"current": self.name, "requested": value},
            )

    @property
    def start_frame(self) -> int:
        return self._raw.GetStartFrame()

    @property
    def end_frame(self) -> int:
        return self._raw.GetEndFrame()

    @property
    def duration_frames(self) -> int:
        return self.end_frame - self.start_frame

    @property
    def start_timecode(self) -> str:
        return self._raw.GetStartTimecode()

    @property
    def current_timecode(self) -> str:
        return self._raw.GetCurrentTimecode()

    @current_timecode.setter
    def current_timecode(self, value: str) -> None:
        if not self._raw.SetCurrentTimecode(value):
            raise errors.TimelineError(
                f"Could not seek to timecode {value!r}.",
                cause="SetCurrentTimecode returned False — value may be out of range.",
                state={"requested": value, "duration_frames": self.duration_frames},
            )

    @property
    def fps(self) -> float:
        return float(self._raw.GetSetting("timelineFrameRate") or 0.0)

    # --- tracks -----------------------------------------------------------

    def track_count(self, track_type: str) -> int:
        return self._raw.GetTrackCount(_validate_track_type(track_type))

    def tracks(self, track_type: str | None = None) -> list[Track]:
        types: Iterable[str] = (track_type,) if track_type else _TRACK_TYPES
        result: list[Track] = []
        for t in types:
            count = self.track_count(t)
            for i in range(1, count + 1):
                result.append(Track(self, t, i))
        return result

    def track(self, track_type: str, index: int) -> Track:
        _validate_track_type(track_type)
        count = self.track_count(track_type)
        if index < 1 or index > count:
            raise errors.TrackError(
                f"{track_type} track {index} does not exist.",
                cause=f"Timeline has {count} {track_type} track(s).",
                state={"track_type": track_type, "requested_index": index, "count": count},
            )
        return Track(self, track_type, index)

    def add_track(self, track_type: str, *, subtype: str | None = None) -> Track:
        validated = _validate_track_type(track_type)
        ok = self._raw.AddTrack(validated, subtype) if subtype else self._raw.AddTrack(validated)
        if not ok:
            raise errors.TrackError(
                f"Could not add {validated} track.",
                cause="AddTrack returned False.",
                state={"track_type": validated, "subtype": subtype},
            )
        new_index = self.track_count(validated)
        return Track(self, validated, new_index)

    # --- clips ------------------------------------------------------------

    def clips(self, track_type: str | None = None) -> ClipQuery:
        """Return a query over clips on the given track type (or all)."""
        all_clips: list[Clip] = []
        for track in self.tracks(track_type):
            all_clips.extend(track.clips())
        return ClipQuery(all_clips)

    # --- markers ----------------------------------------------------------

    def markers(self) -> dict[int, dict[str, Any]]:
        """All markers as ``{frame: {color, name, note, duration, customData}}``."""
        return dict(self._raw.GetMarkers() or {})

    def add_marker(
        self,
        frame: int,
        *,
        color: str = "Blue",
        name: str = "",
        note: str = "",
        duration: int = 1,
        custom_data: str = "",
    ) -> None:
        ok = self._raw.AddMarker(frame, color, name, note, duration, custom_data)
        if not ok:
            raise errors.TimelineError(
                f"Could not add marker at frame {frame}.",
                cause="AddMarker returned False — frame may be outside the timeline.",
                state={"frame": frame, "duration_frames": self.duration_frames},
            )

    # --- settings ---------------------------------------------------------

    def get_setting(self, key: str | None = None) -> Any:
        return self._raw.GetSetting(key) if key else self._raw.GetSetting()

    def set_setting(self, key: str, value: Any) -> None:
        if not self._raw.SetSetting(key, str(value)):
            raise errors.SettingsError(
                f"Could not set timeline setting {key!r} to {value!r}.",
                cause="SetSetting returned False — invalid key or value for this Resolve version.",
                state={"key": key, "value": value, "current": self._raw.GetSetting(key)},
            )

    # --- inspection -------------------------------------------------------

    def inspect(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "fps": self.fps,
            "start_frame": self.start_frame,
            "end_frame": self.end_frame,
            "duration_frames": self.duration_frames,
            "start_timecode": self.start_timecode,
            "tracks": {t: [tr.inspect() for tr in self.tracks(t)] for t in _TRACK_TYPES},
            "marker_count": len(self.markers()),
        }


# ---------------------------------------------------------------------------
# ClipQuery — fluent filter / map over clips
# ---------------------------------------------------------------------------


class ClipQuery:
    """A composable, lazy query over a sequence of :class:`Clip`.

    ``where`` returns a new ``ClipQuery``; iteration / ``list()`` /
    ``apply`` materialize it. Predicates receive the wrapped :class:`Clip`,
    so you have access to ``c.duration``, ``c.start``, etc.
    """

    def __init__(self, clips: list[Clip]) -> None:
        self._clips = clips

    def where(self, predicate: Callable[[Clip], bool]) -> ClipQuery:
        return ClipQuery([c for c in self._clips if predicate(c)])

    def __iter__(self) -> Iterator[Clip]:
        return iter(self._clips)

    def __len__(self) -> int:
        return len(self._clips)

    def first(self) -> Clip | None:
        return self._clips[0] if self._clips else None

    def list(self) -> list[Clip]:
        return list(self._clips)

    def apply(self, fn: Callable[[Clip], None]) -> int:
        """Run ``fn`` against every clip; return the count."""
        for clip in self._clips:
            fn(clip)
        return len(self._clips)


# ---------------------------------------------------------------------------
# Namespace exposed at Resolve.timeline / Project.timeline
# ---------------------------------------------------------------------------


class TimelineNamespace:
    """Operations on the timelines of a project."""

    def __init__(self, parent: Any) -> None:
        # ``parent`` may be a :class:`Resolve` or a :class:`Project`. We
        # accept both so that ``r.timeline`` and ``r.project.current.timeline``
        # work.
        from .project import Project
        from .resolve import Resolve

        if isinstance(parent, Resolve):
            current = parent.project.current
            if current is None:
                raise errors.ProjectError(
                    "No project is currently loaded.",
                    cause="Resolve.project.current is None.",
                    fix="Load or create a project: `resolve.project.ensure('MyShow')`",
                )
            self._project: Project = current
        elif isinstance(parent, Project):
            self._project = parent
        else:
            # Assume it's a raw project handle (used internally).
            self._project = Project(parent, None)

        self._raw = self._project.raw

    # --- read -------------------------------------------------------------

    @property
    def current(self) -> Timeline | None:
        raw = self._raw.GetCurrentTimeline()
        return Timeline(raw, self._raw) if raw is not None else None

    def list(self) -> List[Timeline]:  # noqa: UP006
        count = self._raw.GetTimelineCount()
        return [
            Timeline(self._raw.GetTimelineByIndex(i), self._raw)
            for i in range(1, count + 1)
            if self._raw.GetTimelineByIndex(i) is not None
        ]

    def names(self) -> List[str]:  # noqa: UP006
        return [tl.name for tl in self.list()]

    def get(self, name: str) -> Timeline:
        for tl in self.list():
            if tl.name == name:
                return tl
        raise errors.TimelineError(
            f"No timeline named {name!r} in project {self._project.name!r}.",
            fix="Check available timelines via `resolve.timeline.names()`.",
            state={"requested": name, "available": self.names()},
        )

    # --- mutate -----------------------------------------------------------

    def create(self, name: str) -> Timeline:
        media_pool = require(
            self._raw.GetMediaPool(),
            error=errors.TimelineError,
            message="Could not get the project's media pool.",
            cause="GetMediaPool() returned None.",
        )
        raw = media_pool.CreateEmptyTimeline(name)
        if raw is None:
            raise errors.TimelineError(
                f"Could not create timeline {name!r}.",
                cause="CreateEmptyTimeline returned None — a timeline with this name may exist.",
                fix=f"Use `resolve.timeline.ensure({name!r})` for get-or-create.",
                state={"requested": name, "existing": self.names()},
            )
        return Timeline(raw, self._raw)

    def ensure(self, name: str) -> Timeline:
        if name in self.names():
            return self.get(name)
        return self.create(name)

    def set_current(self, timeline: Timeline | str) -> Timeline:
        target = timeline if isinstance(timeline, Timeline) else self.get(timeline)
        if not self._raw.SetCurrentTimeline(target.raw):
            raise errors.TimelineError(
                f"Could not set current timeline to {target.name!r}.",
                cause="SetCurrentTimeline returned False.",
                state={"requested": target.name},
            )
        return target

    @contextmanager
    def use(self, name: str) -> Iterator[Timeline]:
        previous = self.current
        target = self.set_current(name)
        try:
            yield target
        finally:
            if previous is not None and previous.name != name:
                try:
                    self.set_current(previous)
                except errors.DvrError as exc:
                    logger.warning("could not restore previous timeline %r: %s", previous.name, exc)

    def delete(self, timelines: Timeline | str | Iterable[Timeline | str]) -> None:
        media_pool = self._raw.GetMediaPool()
        if isinstance(timelines, (Timeline, str)):
            timelines = [timelines]
        raw_list = []
        for t in timelines:
            target = t if isinstance(t, Timeline) else self.get(t)
            raw_list.append(target.raw)
        if not media_pool.DeleteTimelines(raw_list):
            raise errors.TimelineError(
                "DeleteTimelines returned False.",
                state={"count": len(raw_list)},
            )


__all__ = ["Clip", "ClipQuery", "Timeline", "TimelineNamespace", "Track"]
