"""Render queue, jobs, and progress monitoring.

The Resolve render API is poll-only — there is no event stream. We turn
that into something usable in three ways:

* :class:`RenderJob` wraps a single job ID and exposes ``status``,
  ``percent``, ``eta``, and ``wait()`` with stall detection.
* :class:`RenderNamespace.watch` is a generator that yields structured
  status events (``{"type": "progress", ...}``, ``{"type": "complete",
  ...}``) as the render proceeds.
* :class:`RenderNamespace.submit` configures a job, queues it, optionally
  starts it, and returns a :class:`RenderJob` you can ``.wait()`` on.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Iterator
from typing import Any

from . import errors

logger = logging.getLogger("dvr.render")


# Sentinel for "no progress in N seconds → stalled".
_DEFAULT_STALL_SECONDS = 300.0


class RenderJob:
    """A single job in Resolve's render queue."""

    def __init__(self, namespace: RenderNamespace, job_id: str) -> None:
        self._ns = namespace
        self._job_id = job_id

    @property
    def id(self) -> str:
        return self._job_id

    @property
    def status(self) -> str:
        return self._ns._project_raw.GetRenderJobStatus(self._job_id).get("JobStatus", "Unknown")

    @property
    def percent(self) -> float:
        s = self._ns._project_raw.GetRenderJobStatus(self._job_id) or {}
        return float(s.get("CompletionPercentage", 0))

    @property
    def eta_seconds(self) -> float | None:
        s = self._ns._project_raw.GetRenderJobStatus(self._job_id) or {}
        ms = s.get("EstimatedTimeRemainingInMs")
        return float(ms) / 1000.0 if ms is not None else None

    @property
    def output_path(self) -> str | None:
        for job in self._ns._project_raw.GetRenderJobList() or []:
            if job.get("JobId") == self._job_id:
                return job.get("OutputFilename")
        return None

    def cancel(self) -> None:
        self._ns._project_raw.DeleteRenderJob(self._job_id)

    def status_dict(self) -> dict[str, Any]:
        return dict(self._ns._project_raw.GetRenderJobStatus(self._job_id) or {})

    def inspect(self) -> dict[str, Any]:
        s = self.status_dict()
        return {
            "id": self._job_id,
            "status": s.get("JobStatus", "Unknown"),
            "percent": float(s.get("CompletionPercentage", 0)),
            "eta_seconds": (
                float(s["EstimatedTimeRemainingInMs"]) / 1000.0
                if "EstimatedTimeRemainingInMs" in s
                else None
            ),
            "output_path": self.output_path,
            "error": s.get("Error"),
        }

    def wait(
        self,
        *,
        poll_interval: float = 1.0,
        timeout: float | None = None,
        stall_seconds: float = _DEFAULT_STALL_SECONDS,
    ) -> RenderJob:
        """Block until this job finishes; return self.

        Raises :class:`RenderError` on failure or timeout/stall.
        """
        start = time.monotonic()
        last_pct = -1.0
        last_progress_at = start

        while True:
            s = self.status_dict()
            status = s.get("JobStatus", "Unknown")
            pct = float(s.get("CompletionPercentage", 0))

            if status == "Complete":
                return self
            if status == "Failed":
                raise errors.RenderError(
                    f"Render job {self._job_id} failed.",
                    cause=s.get("Error", "Resolve did not provide an error message."),
                    state={"job_id": self._job_id, "status": s},
                )
            if status == "Cancelled":
                raise errors.RenderError(
                    f"Render job {self._job_id} was cancelled.",
                    state={"job_id": self._job_id},
                )

            if pct > last_pct:
                last_pct = pct
                last_progress_at = time.monotonic()

            now = time.monotonic()
            if timeout is not None and now - start > timeout:
                raise errors.RenderError(
                    f"Render job {self._job_id} exceeded timeout of {timeout:.0f}s.",
                    cause="The render did not complete in the allotted time.",
                    state={"job_id": self._job_id, "elapsed_s": now - start, "percent": pct},
                )
            if now - last_progress_at > stall_seconds:
                raise errors.RenderError(
                    f"Render job {self._job_id} appears stalled.",
                    cause=f"No progress for {stall_seconds:.0f} seconds.",
                    fix="Inspect Resolve for a hung dialog or unresponsive UI.",
                    state={"job_id": self._job_id, "percent": pct},
                )

            time.sleep(poll_interval)


class RenderNamespace:
    """Render queue operations exposed at :attr:`Resolve.render`."""

    def __init__(self, resolve: Any) -> None:
        self._resolve = resolve  # dvr.Resolve
        current = self._resolve.project.current
        if current is None:
            raise errors.ProjectError(
                "No project is currently loaded.",
                fix="Load or create a project before submitting renders.",
            )
        self._project_raw = current.raw

    # --- formats / codecs / presets --------------------------------------

    def formats(self) -> dict[str, str]:
        return dict(self._project_raw.GetRenderFormats() or {})

    def codecs(self, format_name: str) -> dict[str, str]:
        return dict(self._project_raw.GetRenderCodecs(format_name) or {})

    def current_format_and_codec(self) -> dict[str, str]:
        return dict(self._project_raw.GetCurrentRenderFormatAndCodec() or {})

    def set_format_and_codec(self, format_name: str, codec: str) -> None:
        # Resolve returns None on success and silently fails on error;
        # caller should verify via GetCurrentRenderFormatAndCodec or
        # by inspecting the next AddRenderJob's VideoCodec field.
        self._project_raw.SetCurrentRenderFormatAndCodec(format_name, codec)

    def presets(self) -> list[str]:
        return list(self._project_raw.GetRenderPresetList() or [])

    def load_preset(self, name: str) -> None:
        if not self._project_raw.LoadRenderPreset(name):
            raise errors.RenderError(
                f"Could not load render preset {name!r}.",
                cause="LoadRenderPreset returned False — preset may not exist.",
                fix=f"Available presets: {self.presets()}",
                state={"requested": name},
            )

    # --- queue ------------------------------------------------------------

    def queue(self) -> list[dict[str, Any]]:
        return list(self._project_raw.GetRenderJobList() or [])

    def is_rendering(self) -> bool:
        return bool(self._project_raw.IsRenderingInProgress())

    def stop(self) -> None:
        self._project_raw.StopRendering()

    def clear(self) -> None:
        self._project_raw.DeleteAllRenderJobs()

    # --- submit -----------------------------------------------------------

    def submit(
        self,
        *,
        target_dir: str,
        custom_name: str | None = None,
        preset: str | None = None,
        format: str | None = None,
        codec: str | None = None,
        settings: dict[str, Any] | None = None,
        start: bool = True,
    ) -> RenderJob:
        """Configure and queue a render of the current timeline.

        Args:
            target_dir:  Output directory (must exist).
            custom_name: Filename without extension. Defaults to timeline name.
            preset:      Render preset to load before applying overrides.
            format:      Container format (``mov``, ``mxf`` ...).
            codec:       Codec name (e.g. ``ProRes4444XQ``).
            settings:    Extra ``SetRenderSettings`` keys (e.g. ``{"MarkIn": 24}``).
            start:       If True, start rendering immediately.

        Returns:
            A :class:`RenderJob`. If ``start=False``, the job is queued
            but not yet running; call :meth:`RenderJob.wait` after starting.
        """
        # Switch to deliver page so render queue operations are reliable.
        self._resolve.app.page = "deliver"

        if preset:
            self.load_preset(preset)
        if format and codec:
            self.set_format_and_codec(format, codec)

        merged: dict[str, Any] = {"SelectAllFrames": True, "TargetDir": target_dir}
        if custom_name:
            merged["CustomName"] = custom_name
        if settings:
            merged.update(settings)

        if not self._project_raw.SetRenderSettings(merged):
            raise errors.RenderError(
                "Could not apply render settings.",
                cause="SetRenderSettings returned False.",
                fix="Check that target_dir exists and the requested keys are valid.",
                state={"settings": merged},
            )

        before = {j["JobId"] for j in self.queue()}
        self._project_raw.AddRenderJob()
        after = self.queue()
        new_jobs = [j["JobId"] for j in after if j["JobId"] not in before]
        if not new_jobs:
            raise errors.RenderError(
                "Could not add a render job.",
                cause=(
                    "AddRenderJob produced no new entry. Common causes: no current timeline; "
                    "format/codec invalid; an unsaved render is open."
                ),
                fix="Verify a timeline is loaded and the format/codec pair is supported.",
                state={
                    "queue_size": len(after),
                    "format_codec": self.current_format_and_codec(),
                },
            )
        job = RenderJob(self, new_jobs[0])

        if start and not self._project_raw.StartRendering([job.id], False):
            raise errors.RenderError(
                f"Could not start render job {job.id}.",
                cause="StartRendering returned False.",
                state={"job_id": job.id},
            )

        return job

    # --- streaming watch --------------------------------------------------

    def watch(
        self,
        job_ids: list[str] | None = None,
        *,
        poll_interval: float = 1.0,
    ) -> Iterator[dict[str, Any]]:
        """Yield structured status events until all jobs finish.

        Each event is a dict::

            {"type": "progress", "job_id": "...", "percent": 47, "eta_s": 180}
            {"type": "complete", "job_id": "...", "output_path": "..."}
            {"type": "failed",   "job_id": "...", "error": "..."}
        """
        targets = job_ids or [j["JobId"] for j in self.queue()]
        finished: set[str] = set()

        while len(finished) < len(targets):
            for jid in targets:
                if jid in finished:
                    continue
                s = self._project_raw.GetRenderJobStatus(jid) or {}
                status = s.get("JobStatus", "Unknown")
                if status == "Complete":
                    finished.add(jid)
                    yield {
                        "type": "complete",
                        "job_id": jid,
                        "output_path": RenderJob(self, jid).output_path,
                        "time_s": float(s.get("TimeTakenToRenderInMs", 0)) / 1000.0,
                    }
                elif status in ("Failed", "Cancelled"):
                    finished.add(jid)
                    yield {
                        "type": "failed" if status == "Failed" else "cancelled",
                        "job_id": jid,
                        "error": s.get("Error"),
                    }
                else:
                    yield {
                        "type": "progress",
                        "job_id": jid,
                        "status": status,
                        "percent": float(s.get("CompletionPercentage", 0)),
                        "eta_s": (
                            float(s["EstimatedTimeRemainingInMs"]) / 1000.0
                            if "EstimatedTimeRemainingInMs" in s
                            else None
                        ),
                    }
            if len(finished) < len(targets):
                time.sleep(poll_interval)


__all__ = ["RenderJob", "RenderNamespace"]
