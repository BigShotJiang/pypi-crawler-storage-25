"""Media pool, media-pool items, bins, and media storage.

Three things this module covers:

* :class:`MediaStorage` — Resolve's view of the filesystem (mounted
  volumes, sub-folders, files). Used for bulk imports and "reveal in
  finder" style operations.
* :class:`MediaPool` — the project-scoped clip database, organized into
  bins (folders). Imports media, creates timelines, links proxies,
  performs auto-sync.
* :class:`MediaPoolItem` (:class:`Asset`) — a single clip in a bin, with
  its metadata, markers, flags, audio mapping, and proxy links.

The naming is deliberate: ``Asset`` reads better than ``MediaPoolItem``
in user code, but the class is also exported under both names for
discoverability.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Iterable, List  # noqa: UP035

from . import errors
from ._wrap import require

if TYPE_CHECKING:
    from .timeline import Timeline

logger = logging.getLogger("dvr.media")


# ---------------------------------------------------------------------------
# MediaPoolItem (Asset)
# ---------------------------------------------------------------------------


class Asset:
    """A clip in the media pool (Resolve's ``MediaPoolItem``)."""

    def __init__(self, raw: Any) -> None:
        self._raw = raw

    @property
    def raw(self) -> Any:
        return self._raw

    @property
    def name(self) -> str:
        return self._raw.GetName()

    @name.setter
    def name(self, value: str) -> None:
        if not self._raw.SetClipProperty("Clip Name", value):
            raise errors.MediaError(
                f"Could not rename asset to {value!r}.",
                cause="SetClipProperty('Clip Name', ...) returned False.",
                state={"current": self.name, "requested": value},
            )

    @property
    def duration(self) -> str:
        """Duration as a timecode string."""
        return self._raw.GetClipProperty("Duration") or ""

    @property
    def file_path(self) -> str:
        return self._raw.GetClipProperty("File Path") or ""

    @property
    def fps(self) -> float:
        try:
            return float(self._raw.GetClipProperty("FPS") or 0.0)
        except (TypeError, ValueError):
            return 0.0

    @property
    def resolution(self) -> str:
        """e.g. ``3840x2160``."""
        return self._raw.GetClipProperty("Resolution") or ""

    # --- generic property surface ---------------------------------------

    def get_property(self, key: str | None = None) -> Any:
        return self._raw.GetClipProperty(key) if key else self._raw.GetClipProperty()

    def set_property(self, key: str, value: Any) -> None:
        if not self._raw.SetClipProperty(key, value):
            current = self._raw.GetClipProperty(key)
            raise errors.MediaError(
                f"Could not set asset property {key!r} to {value!r}.",
                cause="SetClipProperty returned False.",
                fix="See `dvr schema asset-properties` for valid keys per Resolve version.",
                state={"asset": self.name, "key": key, "value": value, "current": current},
            )

    # --- metadata -------------------------------------------------------

    def get_metadata(self, key: str | None = None) -> Any:
        return self._raw.GetMetadata(key) if key else self._raw.GetMetadata()

    def set_metadata(self, key_or_dict: str | dict[str, Any], value: Any = None) -> None:
        if isinstance(key_or_dict, dict):
            ok = self._raw.SetMetadata(key_or_dict)
        else:
            ok = self._raw.SetMetadata(key_or_dict, value)
        if not ok:
            raise errors.MediaError(
                f"Could not set metadata on asset {self.name!r}.",
                cause="SetMetadata returned False — invalid key or unsupported value type.",
                state={"asset": self.name},
            )

    # --- flags / colors / markers ---------------------------------------

    @property
    def color(self) -> str:
        return self._raw.GetClipColor() or ""

    @color.setter
    def color(self, value: str) -> None:
        if value:
            self._raw.SetClipColor(value)
        else:
            self._raw.ClearClipColor()

    def flags(self) -> list[str]:
        return list(self._raw.GetFlagList() or [])

    def add_flag(self, color: str) -> None:
        if not self._raw.AddFlag(color):
            raise errors.MediaError(
                f"Could not add {color!r} flag.",
                cause="AddFlag returned False — color may be invalid.",
                state={"asset": self.name, "color": color},
            )

    def clear_flags(self, color: str | None = None) -> None:
        self._raw.ClearFlags(color) if color else self._raw.ClearFlags()

    def markers(self) -> dict[int, dict[str, Any]]:
        return dict(self._raw.GetMarkers() or {})

    def add_marker(
        self,
        frame: int,
        *,
        color: str = "Blue",
        name: str = "",
        note: str = "",
        duration: int = 1,
        custom_data: str = "",
    ) -> None:
        if not self._raw.AddMarker(frame, color, name, note, duration, custom_data):
            raise errors.MediaError(
                f"Could not add marker on asset {self.name!r}.",
                cause="AddMarker returned False — frame may be out of range.",
                state={"asset": self.name, "frame": frame, "color": color},
            )

    def delete_markers(self, color: str | None = None) -> None:
        if color is not None:
            self._raw.DeleteMarkersByColor(color)
        else:
            self._raw.DeleteMarkersByColor("All")

    # --- in/out ---------------------------------------------------------

    def get_mark_in_out(self, media_type: str = "all") -> dict[str, dict[str, int]]:
        return dict(self._raw.GetMarkInOut() or {})

    def set_mark_in_out(self, in_frame: int, out_frame: int, *, media_type: str = "all") -> None:
        if not self._raw.SetMarkInOut(in_frame, out_frame, media_type):
            raise errors.MediaError(
                "Could not set mark in/out.",
                state={
                    "asset": self.name,
                    "in_frame": in_frame,
                    "out_frame": out_frame,
                    "media_type": media_type,
                },
            )

    def clear_mark_in_out(self, *, media_type: str = "all") -> None:
        self._raw.ClearMarkInOut(media_type)

    # --- proxy ----------------------------------------------------------

    def link_proxy(self, proxy_path: str) -> None:
        if not self._raw.LinkProxyMedia(proxy_path):
            raise errors.MediaError(
                f"Could not link proxy {proxy_path!r}.",
                cause="LinkProxyMedia returned False — file may be missing or wrong format.",
                state={"asset": self.name, "proxy_path": proxy_path},
            )

    def unlink_proxy(self) -> None:
        self._raw.UnlinkProxyMedia()

    def link_full_resolution(self) -> None:
        self._raw.LinkFullResolutionMedia()

    # --- replace / relink -----------------------------------------------

    def replace(self, source_path: str, *, preserve_subclip: bool = True) -> None:
        """Replace the underlying source file.

        ``preserve_subclip=True`` keeps trim/marks if the API exposes
        ``ReplaceClipPreserveSubClip`` (newer Resolve versions). Otherwise
        falls back to ``ReplaceClip`` which resets the clip extents.
        """
        ok = (
            self._raw.ReplaceClipPreserveSubClip(source_path)
            if preserve_subclip and hasattr(self._raw, "ReplaceClipPreserveSubClip")
            else self._raw.ReplaceClip(source_path)
        )
        if not ok:
            raise errors.MediaError(
                f"Could not replace asset {self.name!r} with {source_path!r}.",
                cause="ReplaceClip returned False — path may be missing or unreadable.",
                state={"asset": self.name, "source_path": source_path},
            )

    # --- transcribe -----------------------------------------------------

    def transcribe(self, language: str = "auto") -> None:
        """Run Resolve's Whisper-based audio transcription on this clip."""
        if not self._raw.TranscribeAudio(language):
            raise errors.MediaError(
                f"Could not transcribe asset {self.name!r}.",
                cause="TranscribeAudio returned False.",
                fix="Open Resolve's Edit page to verify Whisper models are downloaded.",
                state={"asset": self.name, "language": language},
            )

    def clear_transcription(self) -> None:
        self._raw.ClearTranscription()

    # --- inspection -----------------------------------------------------

    def inspect(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "file_path": self.file_path,
            "duration": self.duration,
            "fps": self.fps,
            "resolution": self.resolution,
            "color": self.color,
            "flags": self.flags(),
            "marker_count": len(self.markers()),
        }


# Alias for users who prefer Resolve's terminology.
MediaPoolItem = Asset


# ---------------------------------------------------------------------------
# Bin (MediaPool folder)
# ---------------------------------------------------------------------------


class Bin:
    """A folder in the media pool (Resolve's ``Folder``)."""

    def __init__(self, raw: Any, pool: MediaPool) -> None:
        self._raw = raw
        self._pool = pool

    @property
    def raw(self) -> Any:
        return self._raw

    @property
    def name(self) -> str:
        return self._raw.GetName()

    def assets(self) -> list[Asset]:
        return [Asset(c) for c in (self._raw.GetClipList() or [])]

    def subbins(self) -> list[Bin]:
        return [Bin(f, self._pool) for f in (self._raw.GetSubFolderList() or [])]

    def is_stale(self) -> bool:
        """In collaboration mode, returns True if the folder needs refresh."""
        return bool(self._raw.GetIsFolderStale())

    def transcribe(self, language: str = "auto") -> None:
        """Bulk-transcribe every asset in the bin."""
        if not self._raw.TranscribeAudio(language):
            raise errors.MediaError(
                f"Could not transcribe bin {self.name!r}.",
                cause="Folder.TranscribeAudio returned False.",
                state={"bin": self.name, "language": language},
            )

    def export(self, file_path: str) -> None:
        """Export the bin as a ``.drb``."""
        if not self._raw.Export(file_path):
            raise errors.MediaError(
                f"Could not export bin {self.name!r}.",
                state={"bin": self.name, "file_path": file_path},
            )

    def inspect(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "asset_count": len(self.assets()),
            "subbin_count": len(self.subbins()),
        }


# ---------------------------------------------------------------------------
# MediaStorage (filesystem view)
# ---------------------------------------------------------------------------


class MediaStorage:
    """Resolve's view of the local/connected filesystem."""

    def __init__(self, raw: Any, pool: MediaPool) -> None:
        self._raw = raw
        self._pool = pool

    def volumes(self) -> List[str]:  # noqa: UP006
        return [str(v) for v in (self._raw.GetMountedVolumeList() or [])]

    def subfolders(self, path: str) -> List[str]:  # noqa: UP006
        return [str(p) for p in (self._raw.GetSubFolderList(path) or [])]

    def files(self, path: str) -> List[str]:  # noqa: UP006
        return [str(p) for p in (self._raw.GetFileList(path) or [])]

    def reveal(self, path: str) -> None:
        self._raw.RevealInStorage(path)

    def add_to_pool(
        self,
        items: Iterable[str | dict[str, Any]],
        *,
        bin: Bin | None = None,
    ) -> list[Asset]:
        """Import file paths (or ``{"FilePath": ..., "StartIndex": ...}`` dicts) into the pool."""
        if bin is not None:
            self._pool.set_current_bin(bin)
        item_list = list(items)
        result = self._raw.AddItemListToMediaPool(item_list)
        if not result:
            raise errors.MediaError(
                "Could not import any items from media storage.",
                cause="AddItemListToMediaPool returned no items.",
                fix="Verify the paths exist and are accessible to Resolve.",
                state={"requested_count": len(item_list)},
            )
        return [Asset(it) for it in result]


# ---------------------------------------------------------------------------
# MediaPool
# ---------------------------------------------------------------------------


class MediaPool:
    """The project-scoped media pool."""

    def __init__(self, raw: Any, resolve_raw: Any) -> None:
        self._raw = raw
        self._resolve = resolve_raw

    @property
    def raw(self) -> Any:
        return self._raw

    # --- bins -----------------------------------------------------------

    def root(self) -> Bin:
        return Bin(self._raw.GetRootFolder(), self)

    def current_bin(self) -> Bin:
        raw = require(
            self._raw.GetCurrentFolder(),
            error=errors.MediaError,
            message="Could not determine the current bin.",
            cause="GetCurrentFolder returned None.",
        )
        return Bin(raw, self)

    def set_current_bin(self, bin: Bin | str) -> Bin:
        target = bin if isinstance(bin, Bin) else self._find_bin(bin)
        if not self._raw.SetCurrentFolder(target.raw):
            raise errors.MediaError(
                f"Could not set current bin to {target.name!r}.",
                state={"requested": target.name},
            )
        return target

    def add_subbin(self, name: str, *, parent: Bin | None = None) -> Bin:
        parent_raw = parent.raw if parent else self._raw.GetCurrentFolder()
        raw = self._raw.AddSubFolder(parent_raw, name)
        if raw is None:
            raise errors.MediaError(
                f"Could not create sub-bin {name!r}.",
                cause="AddSubFolder returned None — name may collide.",
                state={"name": name},
            )
        return Bin(raw, self)

    def ensure_bin(self, name: str, *, parent: Bin | None = None) -> Bin:
        """Get-or-create a top-level bin (or sub-bin under ``parent``)."""
        parent_bin = parent or self.root()
        for sub in parent_bin.subbins():
            if sub.name == name:
                return sub
        return self.add_subbin(name, parent=parent_bin)

    def _find_bin(self, name: str) -> Bin:
        # Depth-first search from root.
        stack = [self.root()]
        while stack:
            current = stack.pop()
            if current.name == name:
                return current
            stack.extend(current.subbins())
        raise errors.MediaError(
            f"No bin named {name!r}.",
            fix="Inspect available bins via `pool.root().subbins()`.",
            state={"requested": name},
        )

    def refresh(self) -> None:
        """In collaboration mode, refresh stale folders."""
        self._raw.RefreshFolders()

    # --- import / export -----------------------------------------------

    def import_(
        self,
        paths: Iterable[str],
        *,
        bin: Bin | None = None,
    ) -> list[Asset]:
        if bin is not None:
            self.set_current_bin(bin)
        result = self._raw.ImportMedia(list(paths))
        if not result:
            raise errors.MediaError(
                "Import returned no items.",
                cause="ImportMedia returned an empty list — paths may be unreadable.",
                state={"requested_count": len(list(paths))},
            )
        return [Asset(it) for it in result]

    def import_timeline(
        self,
        file_path: str,
        *,
        options: dict[str, Any] | None = None,
    ) -> Timeline:
        from pathlib import Path

        from .timeline import Timeline

        opts = options or {"timelineName": Path(file_path).stem, "importSourceClips": True}
        raw = self._raw.ImportTimelineFromFile(file_path, opts)
        if raw is None:
            raise errors.InterchangeError(
                f"Could not import timeline from {file_path!r}.",
                cause="ImportTimelineFromFile returned None.",
                fix="Confirm the file is a valid AAF/EDL/XML/FCPXML/DRT/OTIO/ADL.",
                state={"file_path": file_path, "options": opts},
            )
        return Timeline(raw, self._raw.GetCurrentFolder())

    # --- timelines from clips ------------------------------------------

    def create_empty_timeline(self, name: str) -> Timeline:
        from .timeline import Timeline

        raw = self._raw.CreateEmptyTimeline(name)
        if raw is None:
            raise errors.MediaError(
                f"Could not create timeline {name!r}.",
                cause="CreateEmptyTimeline returned None — name may collide.",
                state={"name": name},
            )
        return Timeline(raw, self._raw.GetCurrentFolder())

    def create_timeline_from_assets(
        self,
        name: str,
        assets: Iterable[Asset],
    ) -> Timeline:
        from .timeline import Timeline

        raws = [a.raw for a in assets]
        raw = self._raw.CreateTimelineFromClips(name, raws)
        if raw is None:
            raise errors.MediaError(
                f"Could not create timeline {name!r} from clips.",
                cause="CreateTimelineFromClips returned None.",
                state={"name": name, "asset_count": len(raws)},
            )
        return Timeline(raw, self._raw.GetCurrentFolder())

    def append_to_timeline(
        self,
        items: Iterable[Asset | dict[str, Any]],
    ) -> list[Any]:
        """Append clips to the current timeline.

        Each item is either an :class:`Asset` or a clipInfo dict (e.g.
        ``{"mediaPoolItem": asset.raw, "startFrame": 24, "endFrame": 96}``).
        """
        payload: list[Any] = []
        for item in items:
            payload.append(item.raw if isinstance(item, Asset) else item)
        result = self._raw.AppendToTimeline(payload)
        if not result:
            raise errors.MediaError(
                "Could not append items to the current timeline.",
                cause="AppendToTimeline returned no items.",
                state={"requested_count": len(payload)},
            )
        return list(result)

    # --- selection / mutation -----------------------------------------

    def selected(self) -> list[Asset]:
        return [Asset(it) for it in (self._raw.GetSelectedClips() or [])]

    def select(self, asset: Asset) -> None:
        self._raw.SetSelectedClip(asset.raw)

    def delete(self, assets: Asset | Iterable[Asset]) -> None:
        if isinstance(assets, Asset):
            assets = [assets]
        raws = [a.raw for a in assets]
        if not self._raw.DeleteClips(raws):
            raise errors.MediaError(
                f"Could not delete {len(raws)} asset(s).",
                cause="DeleteClips returned False.",
                state={"count": len(raws)},
            )

    def move(self, assets: Iterable[Asset], target_bin: Bin) -> None:
        raws = [a.raw for a in assets]
        if not self._raw.MoveClips(raws, target_bin.raw):
            raise errors.MediaError(
                f"Could not move {len(raws)} asset(s) to {target_bin.name!r}.",
                state={"count": len(raws), "target_bin": target_bin.name},
            )

    def relink(self, assets: Iterable[Asset], folder: str) -> None:
        raws = [a.raw for a in assets]
        if not self._raw.RelinkClips(raws, folder):
            raise errors.MediaError(
                f"Could not relink {len(raws)} asset(s) to {folder!r}.",
                cause="RelinkClips returned False — folder may not contain matching files.",
                state={"count": len(raws), "folder": folder},
            )

    def unlink(self, assets: Iterable[Asset]) -> None:
        raws = [a.raw for a in assets]
        if not self._raw.UnlinkClips(raws):
            raise errors.MediaError(
                "Could not unlink asset(s).",
                state={"count": len(raws)},
            )

    # --- audio sync ---------------------------------------------------

    def auto_sync_audio(
        self,
        assets: Iterable[Asset],
        *,
        sync_settings: dict[str, Any] | None = None,
    ) -> None:
        raws = [a.raw for a in assets]
        ok = (
            self._raw.AutoSyncAudio(raws, sync_settings)
            if sync_settings
            else self._raw.AutoSyncAudio(raws)
        )
        if not ok:
            raise errors.MediaError(
                f"Could not auto-sync audio for {len(raws)} asset(s).",
                cause="AutoSyncAudio returned False.",
                state={"count": len(raws), "sync_settings": sync_settings},
            )

    # --- inspection ----------------------------------------------------

    def inspect(self) -> dict[str, Any]:
        root = self.root()
        current = self.current_bin()
        return {
            "current_bin": current.name,
            "root": root.inspect(),
            "selected_count": len(self.selected()),
        }


__all__ = ["Asset", "Bin", "MediaPool", "MediaPoolItem", "MediaStorage"]
