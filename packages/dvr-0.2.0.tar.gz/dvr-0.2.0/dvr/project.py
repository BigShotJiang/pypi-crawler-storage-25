"""Project and project-manager wrappers.

A :class:`Project` is the unit Resolve loads, saves, archives, and
imports/exports as a ``.drp``. The :class:`ProjectNamespace` exposed at
``Resolve.project`` is the entry point: it lets you list, load, create,
ensure, delete, and switch between projects.

Idempotent operations:

* :meth:`ProjectNamespace.ensure` — get-or-create. Always returns a
  :class:`Project`. Never raises "already exists".
* :meth:`ProjectNamespace.use` — context manager that switches to a
  project for the duration of a ``with`` block, restoring the previous
  current project on exit.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, List  # noqa: UP035 — `List` avoids `list` method shadow

from . import errors

if TYPE_CHECKING:
    from .gallery import Gallery
    from .media import MediaPool
    from .timeline import TimelineNamespace

logger = logging.getLogger("dvr.project")


class Project:
    """A single Resolve project (loaded or otherwise reachable)."""

    def __init__(self, raw: Any, manager: Any) -> None:
        self._raw = raw
        self._manager = manager

    @property
    def name(self) -> str:
        return self._raw.GetName()

    @property
    def raw(self) -> Any:
        return self._raw

    # --- settings ---------------------------------------------------------

    def get_setting(self, key: str | None = None) -> Any:
        """Return a single setting (or all of them if ``key`` is None)."""
        return self._raw.GetSetting(key) if key else self._raw.GetSetting()

    def set_setting(self, key: str, value: Any) -> None:
        """Set a project setting; raise :class:`SettingsError` on failure."""
        ok = self._raw.SetSetting(key, str(value))
        if not ok:
            current = self._raw.GetSetting(key)
            raise errors.SettingsError(
                f"Could not set project setting {key!r} to {value!r}.",
                cause=(
                    f"SetSetting returned False. Current value is {current!r}; "
                    "the value may be of the wrong type, or this key may not exist "
                    "on this Resolve version."
                ),
                fix=(
                    "Run `dvr schema settings` to see valid keys and values, "
                    "or check Resolve's API docs for the expected type."
                ),
                state={"key": key, "value": value, "current": current},
            )

    # --- save / close -----------------------------------------------------

    def save(self) -> None:
        if not self._manager.SaveProject():
            raise errors.ProjectError(
                f"Failed to save project {self.name!r}.",
                cause="SaveProject() returned False.",
                fix="Check disk space and that the project is not read-only.",
                state={"project": self.name},
            )

    def close(self) -> None:
        if not self._manager.CloseProject(self._raw):
            raise errors.ProjectError(
                f"Failed to close project {self.name!r}.",
                cause="CloseProject() returned False.",
                state={"project": self.name},
            )

    # --- domain accessors -------------------------------------------------

    @property
    def timeline(self) -> TimelineNamespace:
        from .timeline import TimelineNamespace

        return TimelineNamespace(self)

    @property
    def media(self) -> MediaPool:
        """Wrapped media pool for this project."""
        from .media import MediaPool

        raw = self._raw.GetMediaPool()
        if raw is None:
            raise errors.ProjectError(
                "Could not get the project's media pool.",
                cause="GetMediaPool() returned None.",
                state={"project": self.name},
            )
        return MediaPool(raw, self._raw)

    @property
    def media_pool(self) -> Any:
        """Raw ``MediaPool`` handle. Prefer :attr:`media` in new code."""
        return self._raw.GetMediaPool()

    @property
    def gallery(self) -> Gallery:
        """The project's gallery (still and PowerGrade albums)."""
        from .gallery import gallery_for

        return gallery_for(self)

    # --- inspection -------------------------------------------------------

    def inspect(self) -> dict[str, Any]:
        timeline_count = self._raw.GetTimelineCount()
        current_timeline = self._raw.GetCurrentTimeline()
        timelines = []
        for i in range(1, timeline_count + 1):
            tl = self._raw.GetTimelineByIndex(i)
            if tl is not None:
                timelines.append(tl.GetName())
        return {
            "name": self.name,
            "timeline_count": timeline_count,
            "current_timeline": current_timeline.GetName() if current_timeline else None,
            "timelines": timelines,
        }


class ProjectNamespace:
    """Project-manager operations exposed via :attr:`Resolve.project`."""

    def __init__(self, resolve_raw: Any, manager: Any) -> None:
        self._resolve = resolve_raw
        self._manager = manager

    # --- read -------------------------------------------------------------

    @property
    def current(self) -> Project | None:
        raw = self._manager.GetCurrentProject()
        return Project(raw, self._manager) if raw is not None else None

    def list(self) -> List[str]:  # noqa: UP006
        """Return project names in the current PM folder."""
        return [str(n) for n in (self._manager.GetProjectListInCurrentFolder() or [])]

    def folders(self) -> List[str]:  # noqa: UP006
        """Return PM subfolder names in the current folder."""
        return [str(n) for n in (self._manager.GetFolderListInCurrentFolder() or [])]

    # --- mutate -----------------------------------------------------------

    def create(self, name: str) -> Project:
        raw = self._manager.CreateProject(name)
        if raw is None:
            raise errors.ProjectError(
                f"Could not create project {name!r}.",
                cause=(
                    "CreateProject returned None — usually because a project "
                    "with this name already exists in this PM folder."
                ),
                fix=f"Use `resolve.project.ensure({name!r})` for get-or-create semantics.",
                state={"name": name, "folder_listing": self.list()},
            )
        return Project(raw, self._manager)

    def load(self, name: str) -> Project:
        # Don't reload if it's already current.
        current = self._manager.GetCurrentProject()
        if current is not None and current.GetName() == name:
            return Project(current, self._manager)
        raw = self._manager.LoadProject(name)
        if raw is None:
            raise errors.ProjectError(
                f"Could not load project {name!r}.",
                cause="LoadProject returned None — the project may not exist in this PM folder.",
                fix=(
                    "Check available projects with `resolve.project.list()`, or navigate "
                    "into the right PM folder first."
                ),
                state={"name": name, "folder_listing": self.list()},
            )
        return Project(raw, self._manager)

    def ensure(self, name: str) -> Project:
        """Load the project if it exists, otherwise create it."""
        if name in self.list():
            return self.load(name)
        return self.create(name)

    def delete(self, name: str) -> None:
        if not self._manager.DeleteProject(name):
            raise errors.ProjectError(
                f"Could not delete project {name!r}.",
                cause="DeleteProject returned False — the project may be currently loaded.",
                fix="Close the project first (`resolve.project.current.close()`).",
                state={"name": name},
            )

    def archive(
        self,
        name: str,
        path: str,
        *,
        media: bool = True,
        cache: bool = False,
        proxy: bool = False,
    ) -> None:
        ok = self._manager.ArchiveProject(name, path, media, cache, proxy)
        if not ok:
            raise errors.ProjectError(
                f"Failed to archive project {name!r}.",
                cause="ArchiveProject returned False.",
                fix="Check that the destination path is writable.",
                state={"name": name, "path": path, "include_media": media},
            )

    def import_(self, file_path: str, name: str | None = None) -> Project:
        ok = (
            self._manager.ImportProject(file_path, name)
            if name
            else self._manager.ImportProject(file_path)
        )
        if not ok:
            raise errors.ProjectError(
                f"Failed to import project from {file_path!r}.",
                cause="ImportProject returned False.",
                fix="Check that the file is a valid .drp and that the name is unique.",
                state={"file_path": file_path, "requested_name": name},
            )
        target = name or _guess_drp_name(file_path)
        return self.load(target)

    def export(self, name: str, file_path: str, *, with_stills_and_luts: bool = True) -> None:
        ok = self._manager.ExportProject(name, file_path, with_stills_and_luts)
        if not ok:
            raise errors.ProjectError(
                f"Failed to export project {name!r} to {file_path!r}.",
                cause="ExportProject returned False.",
                fix="Check write permissions and that the project name exists.",
                state={"name": name, "file_path": file_path},
            )

    # --- context manager --------------------------------------------------

    @contextmanager
    def use(self, name: str) -> Iterator[Project]:
        """Switch to ``name`` for the duration of the ``with`` block."""
        previous = self.current
        previous_name = previous.name if previous else None
        project = self.ensure(name)
        try:
            yield project
        finally:
            if previous_name and previous_name != name:
                # Best-effort restore; don't mask exceptions from the body.
                try:
                    self.load(previous_name)
                except errors.DvrError as exc:
                    logger.warning("could not restore previous project %r: %s", previous_name, exc)


def _guess_drp_name(path: str) -> str:
    """Default project name when ``ImportProject`` is given no explicit name."""
    from pathlib import Path

    return Path(path).stem


__all__ = ["Project", "ProjectNamespace"]
