# Changelog

All notable changes to `dvr` are documented here.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-04-25

### Added — capabilities that go beyond the raw Resolve API
- `dvr diff`: structured comparison between two timelines, between a snapshot and live state, or between a spec and live state. Resolve has no built-in compare; this is the first one. Lists align by `name`/`id`/`shot_id`/`frame`/`index` to avoid spurious "everything changed" noise.
- `dvr snapshot`: save / list / show / restore / delete project snapshots to disk. Captures color settings, every timeline, every marker. Survives across sessions in a way Resolve's per-action undo stack does not.
- `dvr lint`: pre-flight validation with structured `error` / `warning` / `info` severities. Default rules check: project loaded, timeline loaded, FPS consistency, empty timelines, render format/codec set, color science set. Exit code 1 on errors.
- `dvr schema`: discoverable catalogs that fill the API's introspection gap — `clip-properties`, `settings`, `export-formats`, `color-presets`, plus live `render-formats`, `render-codecs`, `render-presets`. Solves "what values are valid for SetSetting?".
- `dvr eval` / `dvr exec` / `dvr repl`: scripting escape hatches with a connected `r = Resolve()` already bound, plus `project`, `timeline`, `dvr` for convenience.
- `dvr clip ls / set / mark / inspect --where "..."`: bulk operations driven by a safe expression evaluator (Python-like syntax restricted to comparisons / boolean ops / arithmetic — no attribute access, no calls). One CLI invocation replaces a Python loop.
- `dvr completion show bash|zsh|fish`: auto-generated shell completion scripts for the entire CLI.
- Spec engine hooks: `hooks.before` / `hooks.after` shell commands that run around `dvr apply`. Makes hook-driven workflows (S3 upload, Slack notification, frame.io push) declarative.

### Documentation
- Clarified that DaVinci Resolve **Studio** is required (Blackmagic restricted external scripting to Studio in v19.1+). Free edition is supported only in `--dry-run` and inspection-only flows.

### Added — domain coverage
- Media domain: `MediaPool`, `Asset` / `MediaPoolItem`, `Bin`, `MediaStorage` with bins, import, relink, proxy linking, auto-sync
- Color domain: `ColorOps` (CDL, LUT export, magic mask, stabilization, smart reframe, versions), `NodeGraph`, `ColorGroup`
- Audio domain: voice isolation, channel mapping introspection, Fairlight presets, audio insertion
- Gallery domain: still albums, PowerGrade albums, import/export
- Fusion (per-clip): `ClipFusion` for add / load / import / export / rename / delete comps
- Takes: `Takes` for take/variant management on a clip
- Interchange: unified import/export covering 21 formats — AAF, EDL (+ CDL/SDL/missing), FCP7 XML, FCPXML 1.8/1.9/1.10, DRT, OTIO, CSV, TAB, ALE, ALE-CDL, Dolby Vision 2.9/4.0/5.1, HDR10 A/B
- Daemon: `dvr serve start/stop/status/methods` with newline-delimited JSON over a Unix socket
- MCP server: `dvr mcp serve` exposes the library as typed tools for LLM agents
- Declarative specs: `dvr plan` and `dvr apply` reconcile YAML/JSON specs against live state, with built-in HDR color presets
- CLI sub-apps for every domain: `dvr media`, `dvr serve`, `dvr mcp`, `dvr plan`, `dvr apply`
- Docs site: mkdocs-material with concept guides, CLI reference, library tour, daemon and MCP guides, declarative-spec walkthrough, auto-generated API reference

## [0.1.0] - 2026-04-24

### Added
- Initial scaffold: connection layer, error system, Resolve / Project / Timeline / Render core classes
- CLI entry point with structured output (JSON / table / YAML)
- Inspection-first object model
