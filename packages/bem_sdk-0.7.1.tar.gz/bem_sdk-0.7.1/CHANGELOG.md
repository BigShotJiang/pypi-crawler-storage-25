# Changelog

## 0.7.1 (2026-04-11)

Full Changelog: [v0.7.0...v0.7.1](https://github.com/bem-team/bem-python-sdk/compare/v0.7.0...v0.7.1)

### Bug Fixes

* ensure file data are only sent as 1 parameter ([624e222](https://github.com/bem-team/bem-python-sdk/commit/624e222be492d711f5fe6c0d2a637b3a0f7b2dcc))

## 0.7.0 (2026-04-09)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/bem-team/bem-python-sdk/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([5006222](https://github.com/bem-team/bem-python-sdk/commit/5006222d38039d9b82a877d8e6454cc4466fc22c))

## 0.6.0 (2026-04-08)

Full Changelog: [v0.5.1...v0.6.0](https://github.com/bem-team/bem-python-sdk/compare/v0.5.1...v0.6.0)

### Features

* **api:** api update ([d99aa57](https://github.com/bem-team/bem-python-sdk/commit/d99aa57bf335708305876de9958f8e2696ed611b))

## 0.5.1 (2026-04-08)

Full Changelog: [v0.5.0...v0.5.1](https://github.com/bem-team/bem-python-sdk/compare/v0.5.0...v0.5.1)

### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([fd104cb](https://github.com/bem-team/bem-python-sdk/commit/fd104cb30a659e85b686ecb205e13ac7e69c57ea))

## 0.5.0 (2026-04-07)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/bem-team/bem-python-sdk/compare/v0.4.0...v0.5.0)

### Features

* **api:** add new infer-schema endpoint ([68169ac](https://github.com/bem-team/bem-python-sdk/commit/68169acb1be6cff133e3ed675b4a8b3df8483924))

## 0.4.0 (2026-04-07)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/bem-team/bem-python-sdk/compare/v0.3.0...v0.4.0)

### Features

* **api:** api update ([e7d540d](https://github.com/bem-team/bem-python-sdk/commit/e7d540d47e8628fa840e20183def20c6251acaea))
* **api:** fix workflow references in Stainless config ([ec4a7bd](https://github.com/bem-team/bem-python-sdk/commit/ec4a7bd8a0d2276d6bfd63ae94bb332e364d45a1))


### Chores

* configure new SDK language ([7c420ed](https://github.com/bem-team/bem-python-sdk/commit/7c420ed34cf6ba28875e68b689fd36d60d2ae48b))

## 0.3.0 (2026-04-02)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/bem-team/bem-python-sdk/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([0928608](https://github.com/bem-team/bem-python-sdk/commit/092860880521750788391d5957e964b846443e62))

## 0.2.0 (2026-04-01)

Full Changelog: [v0.1.1...v0.2.0](https://github.com/bem-team/bem-python-sdk/compare/v0.1.1...v0.2.0)

### Features

* **api:** add pagination to list endpoints ([d29869b](https://github.com/bem-team/bem-python-sdk/commit/d29869b1b5c1886a18a519f825cc09594caa064b))

## 0.1.1 (2026-04-01)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/bem-team/bem-python-sdk/compare/v0.1.0...v0.1.1)

### Chores

* remove custom code ([0adf736](https://github.com/bem-team/bem-python-sdk/commit/0adf736f9df6ce7e21465f3d6efe62086f853400))
* update SDK settings ([7fbb1f0](https://github.com/bem-team/bem-python-sdk/commit/7fbb1f0471f271252e6eeea7277fd28911ba9663))
* update SDK settings ([e7e40e2](https://github.com/bem-team/bem-python-sdk/commit/e7e40e21aff11c69030f732f9d776612ded23aa4))

## 0.1.0 (2026-04-01)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/bem-team/bem-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** fix duplicate name issue ([c0659dd](https://github.com/bem-team/bem-python-sdk/commit/c0659ddbc2a277ba27433f328e775c680901a694))
* **api:** update OpenAPI spec ([03cf315](https://github.com/bem-team/bem-python-sdk/commit/03cf315a5c4ac1fe13fb4882de192d7e223ce6b7))


### Chores

* update SDK settings ([286d7f4](https://github.com/bem-team/bem-python-sdk/commit/286d7f41bc92c61bc269d95c082e5bf7e7f9c83e))
* update SDK settings ([d9728be](https://github.com/bem-team/bem-python-sdk/commit/d9728be3d5cc763c5dcafe0a24064e9e1c15c19a))
* update SDK settings ([1668be4](https://github.com/bem-team/bem-python-sdk/commit/1668be40799fb37be835bb14be9a28732830febb))
* update SDK settings ([76dec68](https://github.com/bem-team/bem-python-sdk/commit/76dec68526cbbb5ac29006defd022e45abbc8914))
* update SDK settings ([7cfe5c5](https://github.com/bem-team/bem-python-sdk/commit/7cfe5c5b20101227052b83c1906af31d2a7322f1))
