from dataclasses import dataclass


@dataclass
class ScanResult:
    id: str
    injection: bool
    score: float
    verdict: str  # "block", "warn", or "pass"
    model_version: str
    latency_ms: int


class InjectionDetectedError(Exception):
    """Raised when an injection is detected and mode is 'block'."""

    def __init__(self, result: ScanResult):
        self.result = result
        super().__init__(
            f"Injection detected (score={result.score:.4f}, verdict={result.verdict})"
        )
