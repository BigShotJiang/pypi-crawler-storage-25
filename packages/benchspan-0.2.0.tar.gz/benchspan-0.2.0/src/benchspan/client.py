from __future__ import annotations

import functools
import logging
import threading
from typing import Any, Literal

import httpx

from benchspan.types import InjectionDetectedError, ScanResult

logger = logging.getLogger("benchspan")

DEFAULT_API_URL = "https://api.benchspan.com"

_BaseCallbackHandler = None


def _get_base_callback():
    global _BaseCallbackHandler
    if _BaseCallbackHandler is None:
        from langchain_core.callbacks.base import BaseCallbackHandler
        _BaseCallbackHandler = BaseCallbackHandler
    return _BaseCallbackHandler


class BenchGuard:
    """Prompt injection firewall for LLM agents.

    Usage:
        guard = BenchGuard(api_key="ag_live_...", agent="email-agent")

        # Direct scan
        result = guard.scan("some text", role="tool")

        # LangChain / CrewAI callback
        llm.invoke(messages, config={"callbacks": [guard]})

        # OpenAI Agents SDK
        agent = Agent(hooks=guard.as_agent_hooks())

        # Google ADK
        agent = LlmAgent(beforeModelCallback=guard.as_adk_callback())

        # Raw decorator (OpenAI/Anthropic SDK)
        @guard.wrap
        def call_llm(messages):
            return client.chat.completions.create(messages=messages)
    """

    def __init__(
        self,
        api_key: str,
        agent: str | None = None,
        mode: Literal["block", "warn"] = "block",
        api_url: str = DEFAULT_API_URL,
    ):
        self.api_key = api_key
        self.agent = agent
        self.mode = mode
        self.api_url = api_url.rstrip("/")
        self._scanned: set[int] = set()

        # LangChain BaseCallbackHandler attributes — set these so LangChain
        # recognizes us as a valid handler without requiring inheritance
        self.raise_error = True
        self.ignore_llm = False
        self.ignore_chat_model = False
        self.ignore_chain = True
        self.ignore_agent = True
        self.ignore_retriever = True
        self.ignore_retry = True
        self.ignore_custom_event = True

    # --- Direct scan ---

    def scan(self, input: str, role: str = "user", source: str | None = None) -> ScanResult:
        with httpx.Client(timeout=180.0) as client:
            return self._do_scan(client, input, role, source)

    async def scan_async(self, input: str, role: str = "user", source: str | None = None) -> ScanResult:
        async with httpx.AsyncClient(timeout=180.0) as client:
            return await self._do_scan_async(client, input, role, source)

    # --- LangChain / CrewAI callbacks ---

    def on_llm_start(self, serialized: dict[str, Any], prompts: list[str], **kwargs: Any) -> None:
        for prompt in prompts:
            self._scan_and_act(prompt, "user")

    def on_llm_end(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_llm_error(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_chat_model_start(
        self, serialized: dict[str, Any], messages: list[list[Any]], **kwargs: Any
    ) -> None:
        for message_batch in messages:
            for msg in message_batch:
                role = getattr(msg, "type", "user")
                if role in ("system", "ai", "assistant"):
                    continue
                content = getattr(msg, "content", "")
                if not content or not isinstance(content, str):
                    continue
                scan_role = "tool" if role == "tool" else "user"
                source = getattr(msg, "name", None)
                self._scan_and_act(content, scan_role, source)

    # --- OpenAI Agents SDK hooks ---

    def as_agent_hooks(self):
        guard = self

        try:
            from agents.lifecycle import AgentHooksBase
            base_class = AgentHooksBase
        except ImportError:
            base_class = object

        class Hooks(base_class):
            async def on_tool_end(self, context, agent, tool, result):
                """Scan tool output before it feeds back into the LLM."""
                if not result or not isinstance(result, str):
                    return
                if guard.mode == "warn":
                    threading.Thread(
                        target=guard._warn_scan,
                        args=(result, "tool", getattr(tool, "name", None)),
                        daemon=True,
                    ).start()
                else:
                    scan_result = await guard.scan_async(result, role="tool", source=getattr(tool, "name", None))
                    if scan_result.verdict == "block":
                        raise InjectionDetectedError(scan_result)

        return Hooks()

    # --- Google ADK ---

    def as_adk_callback(self):
        """Returns a beforeModelCallback function for Google ADK.

        Usage:
            agent = LlmAgent(
                beforeModelCallback=guard.as_adk_callback(),
            )
        """
        guard = self

        async def before_model_callback(callback_context, llm_request):
            if not hasattr(llm_request, "contents"):
                return None
            for content in llm_request.contents:
                if not hasattr(content, "parts"):
                    continue
                role = getattr(content, "role", "user")
                for part in content.parts:
                    text = getattr(part, "text", None)
                    if not text:
                        continue
                    scan_role = "tool" if role == "model" else "user"
                    if guard.mode == "warn":
                        threading.Thread(
                            target=guard._warn_scan, args=(text, scan_role), daemon=True
                        ).start()
                    else:
                        result = await guard.scan_async(text, role=scan_role)
                        if result.verdict == "block":
                            raise InjectionDetectedError(result)
            return None

        return before_model_callback

    # --- Raw decorator ---

    def wrap(self, fn):
        """Decorator for raw OpenAI/Anthropic SDK calls.

        Scans the messages array before the function executes.
        Raises InjectionDetectedError if an injection is detected in block mode.

        Usage:
            @guard.wrap
            def call_llm(messages):
                return client.chat.completions.create(messages=messages)
        """
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            messages = args[0] if args else kwargs.get("messages", [])
            self._scan_messages(messages)
            return fn(*args, **kwargs)
        return wrapper

    def wrap_async(self, fn):
        """Async version of wrap decorator.

        Usage:
            @guard.wrap_async
            async def call_llm(messages):
                return await client.chat.completions.create(messages=messages)
        """
        @functools.wraps(fn)
        async def wrapper(*args, **kwargs):
            messages = args[0] if args else kwargs.get("messages", [])
            await self._scan_messages_async(messages)
            return await fn(*args, **kwargs)
        return wrapper

    # --- Internal ---

    def _scan_messages(self, messages):
        if not isinstance(messages, list):
            return
        for msg in messages:
            if isinstance(msg, dict):
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if role in ("system", "assistant") or not content or not isinstance(content, str):
                    continue
                scan_role = "tool" if role == "tool" else "user"
                self._scan_and_act(content, scan_role, msg.get("name"))

    async def _scan_messages_async(self, messages):
        if not isinstance(messages, list):
            return
        for msg in messages:
            if isinstance(msg, dict):
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if role in ("system", "assistant") or not content or not isinstance(content, str):
                    continue
                scan_role = "tool" if role == "tool" else "user"
                msg_hash = hash(content)
                if msg_hash in self._scanned:
                    continue
                self._scanned.add(msg_hash)

                if self.mode == "warn":
                    threading.Thread(
                        target=self._warn_scan, args=(content, scan_role, msg.get("name")), daemon=True
                    ).start()
                else:
                    result = await self.scan_async(content, role=scan_role, source=msg.get("name"))
                    if result.verdict == "block":
                        raise InjectionDetectedError(result)

    def _scan_and_act(self, content: str, role: str, source: str | None = None) -> None:
        msg_hash = hash(content)
        if msg_hash in self._scanned:
            return
        self._scanned.add(msg_hash)

        if self.mode == "warn":
            threading.Thread(
                target=self._warn_scan, args=(content, role, source), daemon=True
            ).start()
        else:
            result = self.scan(content, role=role, source=source)
            if result.verdict == "block":
                raise InjectionDetectedError(result)

    def _warn_scan(self, content: str, role: str, source: str | None = None) -> None:
        try:
            result = self.scan(content, role=role, source=source)
            if result.injection:
                logger.warning(f"BenchGuard flagged {role} message (score={result.score:.4f})")
        except Exception as e:
            logger.error(f"BenchGuard warn scan failed: {e}")

    def _do_scan(self, client: httpx.Client, input: str, role: str, source: str | None) -> ScanResult:
        body = {"input": input, "role": role, "mode": self.mode}
        if source:
            body["source"] = source
        if self.agent:
            body["agent"] = self.agent
        resp = client.post(f"{self.api_url}/v1/scan", json=body, headers={"Authorization": f"Bearer {self.api_key}"})
        resp.raise_for_status()
        data = resp.json()
        return ScanResult(id=data["id"], injection=data["injection"], score=data["score"],
                          verdict=data["verdict"], model_version=data["model_version"], latency_ms=data["latency_ms"])

    async def _do_scan_async(self, client: httpx.AsyncClient, input: str, role: str, source: str | None) -> ScanResult:
        body = {"input": input, "role": role, "mode": self.mode}
        if source:
            body["source"] = source
        if self.agent:
            body["agent"] = self.agent
        resp = await client.post(f"{self.api_url}/v1/scan", json=body, headers={"Authorization": f"Bearer {self.api_key}"})
        resp.raise_for_status()
        data = resp.json()
        return ScanResult(id=data["id"], injection=data["injection"], score=data["score"],
                          verdict=data["verdict"], model_version=data["model_version"], latency_ms=data["latency_ms"])
