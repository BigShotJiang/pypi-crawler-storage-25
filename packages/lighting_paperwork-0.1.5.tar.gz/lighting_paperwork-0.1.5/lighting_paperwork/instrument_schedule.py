"""Generator for an instrument hookup."""

import logging
import re
from copy import copy
from pathlib import Path
from typing import Self, Unpack, override

import numpy as np
import openpyxl
import pandas as pd
from natsort import natsort_keygen, natsorted
from pandas.io.formats.style import Styler

from lighting_paperwork import excel_formatter
from lighting_paperwork.helpers import FontStyle, StyledContent, excel_quirks
from lighting_paperwork.paperwork import PaperworkGenerator, StyleDataParams, StyleFieldParams
from lighting_paperwork.style import default_position_style

logger = logging.getLogger(__name__)


class InstrumentSchedule(PaperworkGenerator):
    """Generate an instrument schedule.

    Seperates instruments by position and sorts by U#.
    TODO(eosti): Accessories don't show up.
    """

    @override
    def __init__(self, *args, position_style: FontStyle = default_position_style, **kwargs) -> None:  # noqa: ANN002, ANN003
        super().__init__(*args, **kwargs)
        self.position_style = position_style

    col_widths = (5, 17, 36, 28, 7, 7)
    display_name = "Instrument Schedule"
    # Order of these regexes defines the printed order
    # TODO(eosti): support appending letters like `A`
    # https://github.com/eosti/lighting-paperwork/issues/15
    position_regexes = (
        r"\d*\s?Pipe\s?\d*$",
        r"^\d*\s?E\s?\d*$",
        r"^\d*\s?Elec\s?\d*$",
        r"^\d*\s?LX\s?\d*$",
        r"^\d*\s?AP\s?\d*$",
        r"^\d*\s?Cat\s?\d*$",
        r"^FOH\s?\d*$",
        r"^[DU]?S[RL]? Box Boom\s?\d*$",
        r"^[DU]?S[RL]? Boom\s?\d*$",
        r"^[DU]?S[RL]? Ladder\s?\d*$",
    )

    @override
    def generate_df(self) -> Self:
        filter_fields = [
            "Position",
            "Unit Number",
            "Purpose",
            "Instrument Type",
            "Wattage",
            "Accessory String",
            "Accessory Flag",
            "Color",
            "Gobo 1",
            "Gobo 2",
            "Channel",
            "Absolute Address",
        ]
        self.verify_filter_fields(filter_fields)

        self.df = pd.DataFrame(self.vw_export[filter_fields], columns=filter_fields)
        # Need to have a position to show up in the instrument schedule
        self.df["Position"] = self.df["Position"].replace("", np.nan)
        self.df = self.df.dropna(subset=["Position"])

        self.combine_instrtype().format_address_slash().combine_gelgobo().abbreviate_col_names()
        self.df["Chan"] = self.df["Chan"].replace("", self.formatting_quirks.empty_str)
        self.df = self.df.sort_values(
            by=["Position", "U#", "Accessory Flag", "Purpose"],
            key=natsort_keygen(),  # type: ignore[reportCallIssue, reportArgumentType]
        )
        self.df = self.df.reset_index(drop=True)

        self.df = self.df[
            [
                "Position",
                "U#",
                "Purpose",
                "Instr Type & Load & Acc",
                "Color & Gobo",
                "Chan",
                "Addr",
            ]
        ]

        return self

    def split_by_position(self) -> list[tuple[str, pd.DataFrame]]:
        """Split dataframe into multiple dataframes, one per position.

        Returns:
            List of tuples. Tuples are in the form of (position_name, dataframe) where
                the dataframe only contains the instruments in that position.

        """
        # Step one: sort position names
        unique_vals = self.df["Position"].unique()
        position_names = self.sort_positions(unique_vals.tolist(), self.position_regexes)
        # TODO(eosti): might be nice to force a linebreak between categories
        # https://github.com/eosti/lighting-paperwork/issues/16

        # Step two: create unique dataframes by position name
        sorted_dfs = []
        for i in position_names:
            pos_df = self.df.loc[self.df["Position"] == i].copy()
            pos_df = pos_df.drop(["Position"], axis=1)
            pos_df = pos_df.rename(columns={"Channel": "Chan", "Unit Number": "U#"})
            pos_df = pos_df.sort_values(by=["U#"], key=natsort_keygen())
            pos_df = pos_df.reset_index(drop=True)
            self.repeated_index_val("U#", pos_df)
            sorted_dfs.append((i, pos_df))

        return sorted_dfs

    @staticmethod
    def sort_positions(positions: list[str], regexes: tuple[str, ...]) -> list[str]:
        """Sort position names according to a list of regexes.

        Args:
            positions: List of position names to sort.
            regexes: List of position regexes to sort by. The order of the
                regexes determines the order of the positions.

        Returns:
            A sorted list of positions.

        """
        sorted_positions = []
        for r in regexes:
            pos = natsorted([x for x in positions if re.match(r, x)])
            sorted_positions += pos

        # Gather remaining positions
        sorted_positions += natsorted([x for x in positions if x not in (sorted_positions)])
        return sorted_positions

    @override
    @staticmethod
    def style_data(df: pd.DataFrame, /, **kwargs: Unpack[StyleDataParams]) -> pd.DataFrame:
        chan_border_style = f"{kwargs['border_weight']}px dashed black"
        style_df = pd.DataFrame().reindex_like(df).astype(str)
        # Set borders based on channel data
        prev_row = (None, None)
        for index, data in df.iterrows():
            style_df.loc[index, :] = ""  # type: ignore[reportCallIssue, reportArgumentType]
            if prev_row == (None, None):
                style_df.loc[index, :] += f"border-bottom: {chan_border_style}; "  # type: ignore[reportCallIssue, reportArgumentType]
                prev_row = (index, data)
                continue

            if data["U#"] == kwargs["quirks"].empty_str:
                # Same U#, remove dashed line
                style_df.loc[prev_row[0], :] += "border-bottom: none; "  # type: ignore[reportCallIssue, reportArgumentType]
                style_df.loc[index, :] += f"border-bottom: {chan_border_style}; "  # type: ignore[reportCallIssue, reportArgumentType]
            else:
                style_df.loc[index, :] += f"border-bottom: {chan_border_style}; "  # type: ignore[reportCallIssue, reportArgumentType]

            prev_row = (index, data)

        # Last row gets a solid bottom border
        style_df.loc[prev_row[0], :] += f"border-bottom: {kwargs['border_weight']}px solid black; "  # type: ignore[reportCallIssue, reportArgumentType]

        # Set font based on column
        for col_name in style_df:
            style_df[col_name] += (
                f"{kwargs['body_style'].to_css()}; vertical-align: middle; "
                f"width: {kwargs['col_width'][style_df.columns.get_loc(col_name)]}%; "  # type: ignore[reportCallIssue, reportArgumentType]
            )

            if col_name in ["Chan", "U#", "Addr"]:
                style_df[col_name] += "text-align: center; "
            else:
                style_df[col_name] += "text-align: left; "

        return style_df

    @override
    @staticmethod
    def style_fields(index: pd.Series, /, **kwargs: Unpack[StyleFieldParams]) -> list[str]:
        PaperworkGenerator.verify_width(kwargs["col_width"])
        style = [
            f"{kwargs['header_style'].to_css()}; "
            f"border-top: {kwargs['border_weight']}px solid black; "
            f"border-bottom: {kwargs['border_weight']}px solid black; "
            for _ in index
        ]

        for idx, val in enumerate(index):
            if val in ["Chan", "U#", "Addr"]:
                style[idx] += "text-align: center; "
            else:
                style[idx] += "text-align: left; "

        for idx, _ in enumerate(index):
            style[idx] += f"width: {kwargs['col_width'][idx]}%; "

        return style

    @override
    def _make_common(self) -> pd.io.formats.style.Styler:
        raise NotImplementedError("Use _make_position for instrument schedule")

    def _make_position(
        self, position: tuple[str, pd.DataFrame]
    ) -> tuple[str, pd.io.formats.style.Styler]:
        """Like _make_common, but operates only on one position's df."""
        styled = Styler.from_custom_template(
            str(Path(__file__).parent / "templates"), "header_footer.tpl"
        )(position[1])  # type: ignore[reportCallIssue, reportArgumentType]
        styled = styled.apply(
            type(self).style_data,
            axis=None,
            body_style=self.style.body,
            col_width=self.col_widths,
            quirks=self.formatting_quirks,
            border_weight=self.border_weight,
        )
        styled = styled.hide()
        styled = styled.apply_index(
            type(self).style_fields,  # type: ignore[reportArgumentType]
            header_style=self.style.field,
            col_width=self.col_widths,
            border_weight=self.border_weight,
            axis=1,
        )
        return (position[0], styled)

    @override
    def make_excel(self, excel_path: str) -> None:
        self.formatting_quirks = excel_quirks

        self.generate_df()
        positions = self.split_by_position()
        sheet_names = []

        for idx, pos in enumerate(positions):
            _, styled = self._make_position(pos)
            sheet_names.append(f"inst_sch_tmp_{idx}")
            with pd.ExcelWriter(excel_path, engine="openpyxl", mode="a") as writer:
                styled.to_excel(writer, sheet_name=sheet_names[-1])

        wb = openpyxl.load_workbook(excel_path)
        ws = wb.create_sheet(title=self.display_name, index=-1)

        for idx, sht_name in enumerate(sheet_names):
            excel_formatter.add_section_header(
                ws, positions[idx][0], self.position_style, len(self.df.columns) - 1
            )
            sht = wb[sht_name]
            cur_max = ws.max_row

            # remove index column
            sht.delete_cols(idx=1)

            # Copy cells over with formatting
            for i in range(1, sht.max_row + 1):
                for j in range(1, sht.max_column + 1):
                    dest_cell = ws.cell(row=cur_max + i, column=j)
                    dest_cell.value = sht.cell(row=i, column=j).value
                    if sht.cell(row=i, column=j).has_style:
                        dest_cell._style = copy(sht.cell(row=i, column=j)._style)  # noqa: SLF001, # type: ignore[reportCallIssue, reportArgumentType]

                    # Wrap text here to avoid messing with the headers
                    alignment = copy(dest_cell.alignment)
                    alignment.wrapText = True
                    dest_cell.alignment = alignment

            # Add an empty row at bottom
            ws.cell(ws.max_row + 1, 1).value = None

            del wb[sht_name]

        excel_formatter.add_title(ws, self.display_name, self.show_data)
        excel_formatter.page_setup(ws, 0)
        excel_formatter.set_col_widths(ws, self.col_widths, self.page_width)
        excel_formatter.instr_schedule_pagebreaks(ws)
        wb.save(excel_path)

    @override
    def make_html(self) -> str:
        self.generate_df()
        positions = self.split_by_position()

        header_html, footer_html = self.generate_header_footer("instr")
        page_style = self.generate_page_style(
            "instr", "bottom-right", self.style.marginals.to_css()
        )

        output_html = page_style
        output_html += header_html
        output_html += "<div id='inst-schedule-container'>\n"
        for pos in positions:
            position_name, styled = self._make_position(pos)
            styled = styled.set_table_attributes('class="paperwork-table"')
            styled = styled.set_table_styles(self.default_table_style(), overwrite=False)
            styled = styled.set_table_styles(
                [{"selector": "", "props": "break-inside: avoid; margin-bottom: 5mm;"}],
                overwrite=False,
            )

            header_html = self.generate_header(
                styled.uuid,  # type: ignore[reportAttributeAccessIssue]
                left=StyledContent(position_name, self.position_style.to_css()),
            )

            output_html += styled.to_html(
                generated_header=header_html,
            )

        output_html += "\n</div>"
        output_html += footer_html
        output_html = self.wrap_table(output_html)

        logger.info("Generated instrument schedule.")

        return output_html
