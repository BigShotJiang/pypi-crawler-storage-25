# tspellenckit

Python toolkit for **time-series visualisation and analysis** of multi-machine, 
multi-sensor fleets.

Built for industrial telemetry data where each machine reports dozens of 
timestamped metrics, and where you need to quickly compare behaviour across 
machines, seasons, and sensors.

## Features

- **Multi-machine visualisation** — one subplot per machine, overlaying 
  multiple years on a shared calendar axis
- **Column type detection** — automatically identifies numeric, categorical 
  and other column types in wide DataFrames
- **Adaptive axis scaling** — adaptive margins, filtering by date range or year
- More modules coming (anomaly detection, alerting, aggregations...)

## Installation
```bash
pip install tspellenckit
```

## Quick start
```python
import tspellenckit as tsk

fig = tsk.vis_metric(
    df,
    "PORTEUR_VITESSE_AVANCEMENT",
    years_filter=[2024, 2025],
    period_filter=["06-01", "09-01"]
)
fig.savefig("speed.png", dpi=150)
```

## Expected data format

A pandas DataFrame with a **MultiIndex `(SerialNumber, time)`**, where each row 
is a timestamped reading for a given machine.