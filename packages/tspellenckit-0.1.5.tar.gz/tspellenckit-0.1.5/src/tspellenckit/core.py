"""
Utilities for time-series visualisation of multi-machine multi-sensor data.
"""

import os
import json
import math
import logging
import boto3
import duckdb
import polars as pl
import pandas as pd
import numpy as np
from joblib import Parallel, delayed
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
from typing import Optional
from statsmodels.tsa.stattools import adfuller
from dotenv import load_dotenv
load_dotenv(override=True)



logger = logging.getLogger(__name__)
if not logger.handlers:
    _handler = logging.StreamHandler()
    logger.addHandler(_handler)
    logger.propagate = False
# logging.basicConfig(level=logging.DEBUG)



def find_column_type(type_target: type, df: pd.DataFrame) -> list[str]:
    """
    Return column names whose first non-NaN value matches type_target.

    Example:
        str_cols = find_column_type(str, df_pivoted)
    """
    matches = [
        col for col in df.columns
        if not df[col].dropna().empty
        and type(df[col].dropna().iloc[0]) is type_target
    ]
    logger.info("find_column_type(%s) → %d column(s) found", type_target.__name__, len(matches))
    return matches



def get_y_min_max(series: pd.Series, margin: float = 0.2) -> tuple[float, float]:
    """
    Compute a (y_min, y_max) range for a numeric series.

    Example:
        y_min, y_max = get_y_min_max(clean_series)
    """
    clean = series.dropna()
    if clean.empty:
        return 0.0, 1.0
    lo, hi = clean.min(), clean.max()
    if lo == hi == 0:
        return 0.0, 1.0
    return lo - abs(lo) * margin, hi + abs(hi) * margin



def vis_metric(
    df: pd.DataFrame,
    metric_name: str,
    *,
    n_cols: int = 4,
    show_nan: bool = True,
    adaptive_x: bool = True,
    years_filter: Optional[list[int]] = None,
    period_filter: Optional[list[str]] = None,
    ref_year: int = 2000,
) -> plt.Figure:
    """
    Plot a metric across all machines, overlaying multiple years for a specific metric.

    Args:
        df:            MultiIndex DataFrame with levels (SerialNumber, time).
        metric_name:   Column to visualise.
        n_cols:        Subplots per row.
        show_nan:      Mark NaN timestamps at y_min with ×.
        adaptive_x:    Fit x-axis to data; if False, show full year.
        years_filter:  Restrict to these years only (None = all).
        period_filter: Keep only ['MM-DD', 'MM-DD'] date range.
        ref_year:      Common calendar year used for overlay.

    Example:
        fig = vis_metric(df_pivoted, "PORTEUR_VITESSE_AVANCEMENT",
                         show_nan=False, years_filter=[2025],
                         period_filter=["06-01", "08-01"])
        fig.savefig("speed.png", dpi=150)
    """
    unique_sn = df.index.get_level_values("SerialNumber").unique()
    n_rows = math.ceil(len(unique_sn) / n_cols)

    all_years = sorted(df.index.get_level_values("time").year.unique())
    if years_filter is not None:
        all_years = [y for y in all_years if y in years_filter]

    cmap = plt.get_cmap("tab10")
    year_color = {year: cmap(i) for i, year in enumerate(all_years)}

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(24, 2 * len(unique_sn)), squeeze=False)

    for i, sn in enumerate(unique_sn):
        row, col = divmod(i, n_cols)
        series = df[metric_name].loc[sn]

        if period_filter is not None:
            mmdd = series.index.strftime("%m-%d")
            series = series[(mmdd >= period_filter[0]) & (mmdd <= period_filter[1])]

        ax = axes[row, col]
        ax.set_title(sn)
        y_min, y_max = get_y_min_max(series)

        for year in all_years:
            year_series = series[series.index.year == year]
            ref_idx = year_series.index - pd.DateOffset(years=year - ref_year)
            color = year_color[year]
            ax.plot(ref_idx, year_series, "o-", color=color, label=str(year))

            if show_nan:
                nan_times = series[series.isna()].index.map(lambda t: t.replace(year=ref_year))
                ax.scatter(nan_times, [y_min] * len(nan_times),
                           marker="x", color=color, s=36, label=f"NaN {year}")

        ax.set_ylim(y_min, y_max)
        ax.tick_params(axis="x", rotation=45)
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
        ax.set_ylabel("Value")
        ax.legend(fontsize=7)

        if not adaptive_x:
            ax.set_xlim(datetime(ref_year, 1, 1), datetime(ref_year, 12, 31))

    for ax in axes.flat[len(unique_sn):]:
        fig.delaxes(ax)

    fig.suptitle(metric_name, fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.98])
    return fig



def timestream_query(
    query_ts: str
):
    """
    Apply any timestream query on your AWS timestream database.
    Example:
    -   query_ts: SELECT * FROM "pellenc-connect-prod"."metrics" WHERE time between ago(15m) and now() ORDER BY time DESC LIMIT 10
    """
    client = boto3.client(
        "timestream-query",
        region_name=os.getenv("aws_region"),
        aws_access_key_id=os.getenv("aws_access_key_id"),
        aws_secret_access_key=os.getenv("aws_secret_access_key"),
        aws_session_token=os.getenv("aws_session_token"),
    )
    result = client.query(QueryString=query_ts)

    while "NextToken" in result:
        next_page = client.query(QueryString=query_ts, NextToken=result["NextToken"])
        result["Rows"] += next_page.get("Rows", [])
        if "NextToken" in next_page:
            result["NextToken"] = next_page["NextToken"]
        else:
            del result["NextToken"]

    logger.info(result["QueryStatus"])
    logger.debug("If you export from timestream to a S3 bucket: make sure the bucket is empty.")
    return result



def connect_s3() -> duckdb.DuckDBPyConnection:
    """Return a DuckDB connection configured to read from S3."""

    S3 = boto3.client(
    "s3",
    region_name=os.getenv("aws_region"),
    aws_access_key_id=os.getenv("aws_access_key_id"),
    aws_secret_access_key=os.getenv("aws_secret_access_key"),
    aws_session_token=os.getenv("aws_session_token"),
    )
    

    con = duckdb.connect()
    con.execute(f"""
        INSTALL httpfs;
        LOAD httpfs;
        SET s3_region='{os.getenv("aws_region")}';
        SET s3_access_key_id='{os.getenv("aws_access_key_id")}';
        SET s3_secret_access_key='{os.getenv("aws_secret_access_key")}';
        SET s3_session_token='{os.getenv("aws_session_token")}';
    """)
    return con



def get_df_from_s3(query: str, cleaned: bool = True, compress_size: bool = True) -> pd.DataFrame:
    """Execute a SQL query on S3 and return the result as a DataFrame."""
    con = connect_s3()
    con.execute("SET http_timeout=4800000;")         # 80 minutes
    con.execute("SET http_retries=5;")              # 5 tentatives
    con.execute("SET http_retry_wait_ms=2000;")     # 2s entre chaque retry

    logger.debug('Importing started...')
    df = con.execute(query).df()

    logger.debug('Dataframe imported.')
    logger.debug(f'Dataframe imported: {df.memory_usage(deep=True).sum() / 1e9:.4f} GB')
    if cleaned:
        logger.debug('Cleaning in progress.')
        df = format_df(df, compress_size)

    logger.debug('Cleaning done.')
    logger.debug(f'Cleaning done: {df.memory_usage(deep=True).sum() / 1e9:.4f} GB')
    return df



def format_df(df: pd.DataFrame, compress_size: bool = True) -> pd.DataFrame:
    """Format a raw Timestream Data by: modifying columns types and merge measure_value columns into one."""

    df["time"] = pd.to_datetime(df["time"])

    # Reduce size memory of columns
    if compress_size == True:
        type_map = {
            "serialnumber": "category",
            "time": "datetime64[s]",
            "measure_name": "category",
            "measure_value::double": "float32",
            "measure_value::bigint": "Int32",
            "measure_value::boolean": "boolean",
        }
        df = df.astype({k: v for k, v in type_map.items() if k in df})

    # Group all values in one value column
    values_col = df.columns[df.columns.str.contains("measure_value")].values
    df["value"] = df[values_col[0]].astype(object)
    for col in values_col[1:]:
        df["value"] = df["value"].fillna(df[col])

    # Only keep the column that contains all values
    df.drop(
        columns=values_col,
        inplace=True,
    )
    # sort by chronological order
    df = df.sort_values(by="time")

    return df



def pivot_ts_df(df, id_title: str = 'serialnumber'):
    chunks = []

    for sn, df_id in df.groupby(id_title, observed=True):
        logger.debug('Pivot process started...')
      
        pivoted = df_id.pivot_table(
            index="time",
            columns="measure_name",
            values="value",
            aggfunc="first",
            observed=True,
        )

        # aggfunc = max in case PORTEUR_MOTEUR_ALERTE_ECU_INDICATEUR_CRITIQUE
        if "PORTEUR_MOTEUR_ALERTE_ECU_INDICATEUR_CRITIQUE" in df_id["measure_name"].values:
            max_values = df_id[df_id["measure_name"] == 'PORTEUR_MOTEUR_ALERTE_ECU_INDICATEUR_CRITIQUE'].groupby("time")["value"].max()
            pivoted['PORTEUR_MOTEUR_ALERTE_ECU_INDICATEUR_CRITIQUE'] = max_values

    
        pivoted.index = pd.MultiIndex.from_arrays(
            [[sn] * len(pivoted), pivoted.index], names=["serialnumber", "time"]
        )

        logger.debug(f'Dataframe pivoted: {pivoted.memory_usage(deep=True).sum() / 1e9:.4f} GB')
        
        # Reduce size by transforming all possible columns to float32
        logger.debug('Reducing column types to float32 for possible columns...')
        total_col_reduced = 0
        total_col_not_reduced = 0
        for col in pivoted.select_dtypes(object).columns:
            try:
                pivoted[col] = pivoted[col].astype(np.float32)
                total_col_reduced = total_col_reduced + 1
            except (ValueError, TypeError):
                total_col_not_reduced = total_col_not_reduced + 1
                pass
        logger.debug(f"Total nb of reduced columns to float32 : {total_col_reduced}")
        logger.debug(f"Total nb of not reduced columns to float32 : {total_col_not_reduced}")
        
        chunks.append(pivoted)

    df_pivoted = pd.concat(chunks)
    logger.debug(f'Dataframe reduced to: {df_pivoted.memory_usage(deep=True).sum() / 1e9:.4f} GB')
    df_pivoted.index.names = ["SerialNumber", "time"]
    df_pivoted.columns = df_pivoted.columns.astype(str) # Remove their categorical type 
    logger.debug('Pivoted Dataframe Done.')
    return df_pivoted



# Global
def select_metrics(total_metrics: list, *excluded_lists: list) -> list:
    """
    Return metrics from total_metrics after removing all excluded ones (duplicates handled).
    -    Example:
            select_metrics(all_metrics, excluded_by_variance, excluded_by_correlation, manual_exclusions)
    """

    all_excluded    = [m for lst in excluded_lists for m in lst]
    excluded_metrics = list(set(all_excluded)) # remove duplicates available in several lists.
    selected_metrics = [m for m in total_metrics if m not in excluded_metrics]

    logger.debug(f"Total metrics: {len(total_metrics)}")
    logger.debug(f"Excluded metrics: {len(excluded_metrics)}")
    logger.debug(f"Selected metrics: {len(selected_metrics)}")

    return selected_metrics



def encode_str_cols(
    df: pd.DataFrame,
    mapping_file: str,
    nan_placeholder: str = "0-0",
    output_dtype: type = np.float32,
    mode: str = "fit_transform"
) -> pd.DataFrame:
    """
    An incremental, cross-dataframe persistent mapping using a shared persistent JSON map. Suitable for production pipelines where data arrives over time.
    The JSON map also enables easy decoding.
    Args:
     - mode: fit_transform (both), fit (only), transform (only)
    Returns:
        pd.DataFrame: The input DataFrame with all string columns
                      replaced by float32-encoded numeric values.
    Side Effects:
        - Reads from and writes to ``mapping_file`` on disk.
    Example:
        >>> df_encoded = encode_str_cols(df, mapping_file=map_str_file, nan_placeholder="0-0", output_dtype=np.float32, mode = "fit")
    """
    str_cols = df.select_dtypes(object).columns
    df[str_cols] = df[str_cols].fillna(nan_placeholder)

    # Load or initialize map
    if os.path.exists(mapping_file):
        with open(mapping_file, "r") as f:
            config = json.load(f)
        label_map = config.get("encode_str_map", {nan_placeholder: 0})
    else:
        config = {}
        label_map = {nan_placeholder: 0}

    if mode in ("fit", "fit_transform"):
        logger.debug(f"Fit started...")
        unique_vals = pd.unique(df[str_cols].values.ravel())
        changed = False
        for val in unique_vals:
            if val not in label_map:
                label_map[val] = len(label_map)
                changed = True
        if changed:
            config["encode_str_map"] = label_map
            with open(mapping_file, "w") as f:
                json.dump(config, f)

    if mode in ("transform", "fit_transform"):
        logger.debug(f"Encoding Transformation started...")
        unseen = [v for v in pd.unique(df[str_cols].values.ravel()) if v not in label_map]
        if unseen:
            raise ValueError(f"Unseen values in transform mode: {unseen}")
        for col in str_cols:
            df[col] = df[col].map(label_map).astype(output_dtype)

    logger.debug(f"Done. Global map size: {len(label_map)}")
    return df



def test_stationarity(
    df: pd.DataFrame,
    p_threshold: float = 0.05,
    min_length: int = 6,
    max_lag: int = 1
) -> tuple[list, list, list]:
    """
    Test stationarity of all columns in a DataFrame using the ADFuller test (statsmodels),
    parallelized across columns via joblib. And classifies each feature as constant,
    stationary, or non-stationary based on the p-value threshold.
    Args:
        - p_threshold: p-value cutoff for stationarity. Stationary serie in Adfuller test should be have p-value less than 0.05.
        - min_length: minimum non-null samples required, else classified as constant
    Returns:
        tuple: (constant_features, non_stationary_features, stationary_features)
    Example:
        >>> constant, non_stationary, stationary = test_stationarity(df, p_threshold=0.05)
    """
    def test_feature(feature, series):
        series = series.replace([np.inf, -np.inf], np.nan).dropna()
        if series.nunique() <= 1 or len(series) < min_length:
            return feature, "constant"
        result = adfuller(series, autolag=None, maxlag=max_lag)
        return feature, "non_stationary" if result[1] > p_threshold else "stationary"

    logger.debug("Testing stationarity...")
    results = Parallel(n_jobs=-1, prefer="threads")(
        delayed(test_feature)(feature, df[feature]) for feature in df.columns
    )
    constant_features     = [f for f, t in results if t == "constant"]
    non_stationary_features = [f for f, t in results if t == "non_stationary"]
    stationary_features   = [f for f, t in results if t == "stationary"]
    logger.debug(f"Done. Total: {len(df.columns)}, Constant: {len(constant_features)}, Non-stationary: {len(non_stationary_features)}, Stationary: {len(stationary_features)}")
    return constant_features, non_stationary_features, stationary_features



def resample(
    df: pd.DataFrame,
    agg_dict: dict,
    freq: str = "30s",
    group_keys: list[str] | str | None = None,
    time_level: str = "time",
) -> pd.DataFrame:
    """
    Resample a time-indexed DataFrame using groupby aggregation.

    Args:
        df: DataFrame with a DatetimeIndex (or MultiIndex containing one).
        agg_dict: Aggregation spec passed to .agg(), e.g. {"col": "mean"}.
        freq: Resampling frequency string, e.g. "30s", "1min", "1h".
        group_keys: Column(s) to group by in addition to time. None = no extra grouping.
        time_level: Name of the DatetimeIndex level to resample on.

    Returns:
        Resampled DataFrame with rows where all values are NaN dropped.
    Example:
        resample(df, aggregate_dict, "SerialNumber") # for multiple serialnumber
    """
    groupers = []
    if group_keys:
        keys = [group_keys] if isinstance(group_keys, str) else group_keys
        groupers.extend(keys)
    groupers.append(pd.Grouper(level=time_level, freq=freq))
    
    logger.debug("Resampling started...")
    valid_agg_dict = {col: agg for col, agg in agg_dict.items() if col in df.columns}
    return (df.groupby(groupers).agg(valid_agg_dict).dropna(how="all"))



def apply_stationarity(df, non_stationary_features):
    new_cols = {}
    for feature in non_stationary_features:
        X = df[feature]
        series_sqrt = np.sqrt(X.clip(lower=0))  # attenuate the variance: square root
        series_sqrt_diff = series_sqrt.diff().replace(np.nan, 0)  # regulate the mean
        new_cols[f"{feature}_regulated"] = series_sqrt_diff.round(2)

    # Only add columns that don't already exist
    new_cols = {k: v for k, v in new_cols.items() if k not in df.columns}
    return pd.concat([df, pd.DataFrame(new_cols, index=df.index)], axis=1)



def drop_features(df, features_list: list):
    logger.debug("Dropping constant columns...")
    logger.debug(
        f"Before dropping constant columns:  {df.memory_usage(deep=True).sum() / 1e9:.4f} GB"
    )

    logger.debug(
        f"After dropping constant columns:  {df.drop(columns=features_list).memory_usage(deep=True).sum() / 1e9:.4f} GB"
    )
    return df.drop(columns=features_list)












def pivot_ts_df_pl(df: pl.DataFrame, id_title: str = "serialnumber") -> pl.DataFrame:
    """
    Same as pivot_ts_df() but in polars instead of pandas -> faster & more efficient
    """
    logger.debug("Pivot process started...")
    df = (
        df.group_by([id_title, "time", "measure_name"])
          .agg(
              pl.when(pl.col("measure_name").first() == "PORTEUR_MOTEUR_ALERTE_ECU_INDICATEUR_CRITIQUE")
                .then(pl.col("value").max())
                .otherwise(pl.col("value").first())
                .alias("value")
          )
          .pivot(
              on="measure_name",
              index=[id_title, "time"],
              values="value",
              aggregate_function="first",
          )
    )
    logger.debug(f"Dataframe pivoted: {df.estimated_size('gb'):.4f} GB")
    total_col_reduced = 0
    total_col_not_reduced = 0
    for column in df.columns:
        if column not in {id_title, "time"}:
            try:
                df = df.with_columns(pl.col(column).cast(pl.Float32))
                total_col_reduced += 1
            except (pl.exceptions.InvalidOperationError, pl.exceptions.ComputeError):
                total_col_not_reduced += 1
    logger.debug(f"Total nb of reduced columns to float32: {total_col_reduced}")
    logger.debug(f"Total nb of not reduced columns to float32: {total_col_not_reduced}")
    logger.debug(f"Final Dataframe size: {df.estimated_size('gb'):.4f} GB")

    df = df.rename({id_title: "SerialNumber"})

    logger.debug("Pivoted Dataframe Done.")
    return df

    

def encode_str_cols_pl(
    df: pl.DataFrame,
    mapping_file: str,
    nan_placeholder: str = "0-0",
    output_dtype=pl.Float32,
    mode: str = "fit_transform",
    exclude_cols: list[str] = ["SerialNumber", "time"],
) -> pl.DataFrame:
    """
    Same as encode_str_cols() but in polars instead of pandas -> faster & more efficient
    """
    str_expr = pl.col(pl.String).exclude(exclude_cols)

    df = df.with_columns(str_expr.fill_null(nan_placeholder))

    config = json.load(open(mapping_file)) if os.path.exists(mapping_file) else {}
    label_map = config.get("encode_str_map", {nan_placeholder: 0})

    unique_vals = set(df.select(str_expr).unpivot().get_column("value").unique().drop_nulls().to_list())
    

    if mode in ("fit", "fit_transform"):
        new_vals = {v: len(label_map) + i
                    for i, v in enumerate(v for v in unique_vals if v not in label_map)}
        if new_vals:
            label_map.update(new_vals)
            config["encode_str_map"] = label_map
            json.dump(config, open(mapping_file, "w"))

    if mode in ("transform", "fit_transform"):
        unseen = list(unique_vals - label_map.keys())
        if unseen:
            raise ValueError(f"Unseen values: {unseen}")
        df = df.with_columns(str_expr.replace(label_map).cast(output_dtype))

    return df



def test_stationarity_pl(
    df: pl.DataFrame,
    p_threshold: float = 0.05,
    min_length: int = 6,
    max_lag: int = 1
) -> tuple[list, list, list]:
    """
    Same as test_stationarity() but in polars instead of pandas -> faster & more efficient
    """
    def test_feature(feature):
        series = df[feature].drop_nulls().to_numpy().astype(float)
        if len(np.unique(series)) <= 1 or len(series) < min_length:
            return feature, "constant"
        result = adfuller(series, autolag=None, maxlag=max_lag)
        return feature, "non_stationary" if result[1] > p_threshold else "stationary"

    logger.debug("Testing stationarity...")
    data_cols = [col for col in df.columns if col not in ["SerialNumber", "time"] and df[col].dtype in (pl.Float32, pl.Float64, pl.Int32, pl.Int64)]
    results = Parallel(n_jobs=-1, prefer="threads")(
        delayed(test_feature)(feature) for feature in data_cols
    )
    constant_features       = [f for f, t in results if t == "constant"]
    non_stationary_features = [f for f, t in results if t == "non_stationary"]
    stationary_features     = [f for f, t in results if t == "stationary"]
    logger.debug(f"Done. Total: {len(df.columns)}, Constant: {len(constant_features)}, "
                 f"Non-stationary: {len(non_stationary_features)}, Stationary: {len(stationary_features)}")
    return constant_features, non_stationary_features, stationary_features


def resample_pl(df: pl.LazyFrame, agg_dict: dict, freq: str = "30s") -> pl.LazyFrame:
    """
    Same as resample() but in polars instead of pandas -> faster & more efficient
    """
    existing_cols = set(df.collect_schema().names())
    valid_agg_dict = {col: agg for col, agg in agg_dict.items() if col in existing_cols}

    agg_exprs = []
    for col, agg in valid_agg_dict.items():
        if agg == "max":      agg_exprs.append(pl.col(col).max())
        elif agg == "last":   agg_exprs.append(pl.col(col).last())
        elif agg == "median": agg_exprs.append(pl.col(col).median())
        elif agg == "mean":   agg_exprs.append(pl.col(col).mean())

    return (
        df.group_by_dynamic("time", every=freq, group_by="SerialNumber")
        .agg(agg_exprs)
    )



def apply_stationarity_pl(df: pl.DataFrame, non_stationary_features: list) -> pl.DataFrame:
    """
    Same as apply_stationarity() but in polars instead of pandas -> faster & more efficient
    """
    new_cols = []
    for feature in non_stationary_features:
        if f"{feature}_regulated" not in df.columns:
            new_cols.append(
                pl.col(feature)
                .clip(lower_bound=0)
                .sqrt()
                .diff
                .over("SerialNumber")
                .fill_null(0)
                .round(2)
                .alias(f"{feature}_regulated")
            )
    return df.with_columns(new_cols)



def drop_features_pl(df: pl.DataFrame, features_list: list) -> pl.DataFrame:
    """
    Same as drop_features() but in polars instead of pandas -> faster & more efficient
    """
    cols_to_drop = [col for col in features_list if col in df.columns]
    return df.drop(cols_to_drop)

