"""
QR-Mark: AI-readable invisible watermarking via perceptually-adaptive tiled QR codes.

Embeds metadata as a 2×2 tiled QR code using JND (Just Noticeable Difference) adaptive
masking — the watermark energy is concentrated in edge/texture regions where the human
visual system is least sensitive, and suppressed on smooth regions (sky, skin, solid
backgrounds) where even tiny changes are visible.

Properties:
  - Perceptually invisible: ≈4% opacity on smooth areas, ≤12% in textures
  - Directly readable by AI vision models (GPT-4V, Gemini, Grok, Claude)
    — just ask: "what QR code or watermark is in this image?"
  - Readable by any smartphone QR scanner app with enhanced preprocessing
  - Survives: screenshot, JPEG q≥80, up to 50% crop (2×2 tiling)
  - Works on images AND video frames

Tiling strategy: 2×2 grid, each tile = 50% image dimensions.
Even if the image is cropped to any single quadrant, one full QR remains.
Detection exploits tiling: averaging 4 copies boosts QR SNR while background cancels.
"""

import json
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from typing import Optional

try:
    import qrcode
    import qrcode.constants
    _QRCODE_OK = True
except ImportError:
    _QRCODE_OK = False

try:
    import cv2
    _CV2_OK = True
except ImportError:
    _CV2_OK = False

try:
    from pyzbar import pyzbar as _pyzbar
    _PYZBAR_OK = True
except ImportError:
    _PYZBAR_OK = False


DEFAULT_OPACITY = 0.05   # base opacity (smooth areas); JND masking boosts to ~0.12 in textures
_JND_PEAK_RATIO = 2.5    # textured regions get up to 2.5× the base opacity
_JND_MAX_OPACITY = 0.15  # hard cap — never exceed this even in highly textured areas
MIN_QR_DIM = 100         # minimum pixel size per QR tile to stay decodable


def embed_qr(
    image: Image.Image,
    metadata: dict,
    opacity: float = DEFAULT_OPACITY,
) -> Image.Image:
    """
    Embed metadata as a tiled semi-transparent QR code using JND adaptive masking.

    The watermark is concentrated in edge/texture regions (where human eyes are less
    sensitive) and suppressed on smooth/uniform areas (sky, skin, solid backgrounds).

    Args:
        image:    RGB PIL Image (min 256×256)
        metadata: dict — will be serialised as compact JSON into the QR
        opacity:  base blend strength 0.0–1.0 (default 0.05)
                  This is the MINIMUM opacity; adaptive masking boosts it in textures.
                  0.03 = nearly invisible everywhere (may miss JPEG detection)
                  0.05 = default: invisible on smooth regions, subtle in textures
                  0.10 = more robust to JPEG / aggressive processing
                  0.15 = clearly visible on smooth backgrounds

    Returns:
        Watermarked RGB PIL Image
    """
    if not _QRCODE_OK:
        raise ImportError(
            "qrcode package required: pip install 'qrcode[pil]'"
        )

    img = image.convert('RGB')
    w, h = img.size

    # Compact QR payload — short keys reduce QR version → larger modules → better detection
    _KEY_MAP = {'clawid': 'c', 'uid': 'u', 'platform': 'p', 'asset_id': 'a', 'ts': 't'}
    compact = {_KEY_MAP.get(k, k): v for k, v in metadata.items()}
    payload = json.dumps(compact, separators=(',', ':'), ensure_ascii=False)

    # Generate QR with HIGH error correction (survives 30% module damage)
    qr = qrcode.QRCode(
        version=None,                              # auto-pick smallest version
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=3,
    )
    qr.add_data(payload)
    qr.make(fit=True)
    qr_raw = qr.make_image(fill_color='black', back_color='white').convert('L')

    # Each tile covers one quadrant (w//2 × h//2)
    tile_w = max(w // 2, MIN_QR_DIM)
    tile_h = max(h // 2, MIN_QR_DIM)

    # Resize QR to tile size — LANCZOS then threshold for clean modules
    qr_tile = qr_raw.resize((tile_w, tile_h), Image.LANCZOS)
    # Re-binarise after resize to keep crisp black/white modules
    qr_tile = qr_tile.point(lambda p: 0 if p < 128 else 255, '1').convert('L')

    # Build 2×2 tiled overlay at full image resolution
    tiled = Image.new('L', (w, h), 255)
    for row in range(2):
        for col in range(2):
            tiled.paste(qr_tile, (col * tile_w, row * tile_h))

    # JND adaptive mask: scale opacity with local edge/texture strength
    # Eyes are less sensitive to changes in complex/textured regions — we exploit this
    # to hide the watermark where it won't be seen, and pull back on smooth regions.
    jnd_mask = _jnd_mask(img, base=opacity)   # H×W float32, values in [opacity, peak]

    orig_arr  = np.array(img, dtype=np.float32)                                 # H×W×3
    tiled_rgb = np.stack([np.array(tiled)] * 3, axis=2).astype(np.float32)      # H×W×3
    mask_3d   = jnd_mask[:, :, np.newaxis]                                       # H×W×1
    blended   = orig_arr * (1.0 - mask_3d) + tiled_rgb * mask_3d
    result    = Image.fromarray(np.clip(blended, 0, 255).astype(np.uint8), 'RGB')
    return result


def detect_qr(image: Image.Image) -> Optional[dict]:
    """
    Detect and decode the QR watermark from an image.

    Tries multiple preprocessing strategies to maximise detection rate
    even after JPEG compression, screenshots, or colour shifts.

    Returns:
        Metadata dict if a valid clawID QR watermark is found, None otherwise.
    """
    if not (_CV2_OK or _PYZBAR_OK):
        raise ImportError(
            "OpenCV or pyzbar required: "
            "pip install opencv-python-headless   OR   pip install pyzbar"
        )

    arr = np.array(image.convert('RGB'))

    # Build a pipeline of increasingly aggressive preprocessing variants
    # Most watermarked images will decode on the first or second pass
    variants = _preprocessing_pipeline(arr)

    for variant in variants:
        result = _try_decode(variant)
        if result is not None:
            return result

    return None


# ── JND masking ──────────────────────────────────────────────────────────────

def _jnd_mask(img: Image.Image, base: float) -> np.ndarray:
    """
    Compute a per-pixel adaptive opacity mask using JND (Just Noticeable Difference).

    Principle: the human visual system is least sensitive to luminance changes in
    regions with high spatial frequency content (edges, textures). We detect these
    regions via edge filtering and scale the watermark opacity proportionally.

    Result:
      - Smooth areas (sky, skin, flat colour): opacity ≈ base
      - Edge/texture areas: opacity up to min(base × _JND_PEAK_RATIO, _JND_MAX_OPACITY)

    Args:
        img:  RGB PIL Image
        base: minimum opacity (smooth regions)

    Returns:
        H×W float32 array of per-pixel blend weights
    """
    if base == 0.0:
        return np.zeros(
            (img.size[1], img.size[0]), dtype=np.float32
        )

    gray = img.convert('L')

    # Detect high-frequency content (edges, textures)
    edges = gray.filter(ImageFilter.FIND_EDGES)

    # Smooth the edge map to create gradual opacity transitions (no hard borders)
    edges_smooth = edges.filter(ImageFilter.GaussianBlur(radius=max(img.size[0] // 64, 8)))

    edge_arr = np.array(edges_smooth, dtype=np.float32) / 255.0  # [0, 1]

    # Map to [base, peak] — smooth areas stay near base, textured areas rise toward peak
    peak = min(base * _JND_PEAK_RATIO, _JND_MAX_OPACITY)
    return (base + (peak - base) * edge_arr).astype(np.float32)


# ── internal helpers ──────────────────────────────────────────────────────────

def _try_decode(arr: np.ndarray) -> Optional[dict]:
    """Attempt QR decode with pyzbar (preferred) then OpenCV."""
    gray = _to_gray_cv(arr) if _CV2_OK else _to_gray_np(arr)

    # ── pyzbar ────────────────────────────────────────────────────────────────
    if _PYZBAR_OK:
        codes = _pyzbar.decode(Image.fromarray(gray))
        for code in codes:
            if code.type == 'QRCODE':
                data = _parse_payload(code.data)
                if data is not None:
                    return data

    # ── OpenCV ────────────────────────────────────────────────────────────────
    if _CV2_OK:
        detector = cv2.QRCodeDetector()
        # Standard detect
        raw, _, _ = detector.detectAndDecode(gray)
        if raw:
            data = _parse_payload(raw.encode())
            if data is not None:
                return data
        # detectAndDecodeMulti catches tiled copies
        ok, raws, _, _ = detector.detectAndDecodeMulti(gray)
        if ok:
            for raw in raws:
                if raw:
                    data = _parse_payload(raw.encode())
                    if data is not None:
                        return data

    return None


_KEY_EXPAND = {'c': 'clawid', 'u': 'uid', 'p': 'platform', 'a': 'asset_id', 't': 'ts'}


def _parse_payload(raw: bytes) -> Optional[dict]:
    """Parse QR payload bytes → metadata dict (expands compact keys)."""
    try:
        text = raw.decode('utf-8') if isinstance(raw, bytes) else raw
        data = json.loads(text)
        # Expand compact keys back to full names
        return {_KEY_EXPAND.get(k, k): v for k, v in data.items()}
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
        return None


def _preprocessing_pipeline(arr: np.ndarray):
    """
    Generate preprocessing variants from least to most aggressive.
    Each is a numpy uint8 RGB array.

    Key insight: we tile the QR 2×2, so averaging the 4 quadrants
    reinforces the QR signal (same in all 4) while cancelling the
    background image (different in each quadrant). This dramatically
    improves detection after JPEG compression or on noisy images.
    """
    variants = [arr]  # 1. raw

    # 2. Tile-averaged: average all 4 quadrants → QR signal coherently adds,
    #    background content partially cancels → best for JPEG/noisy images
    h, w = arr.shape[:2]
    th, tw = h // 2, w // 2
    if th >= MIN_QR_DIM and tw >= MIN_QR_DIM:
        q1 = arr[:th,   :tw  ].astype(np.float32)
        q2 = arr[:th,   tw:tw*2].astype(np.float32) if tw*2 <= w else q1
        q3 = arr[th:th*2, :tw  ].astype(np.float32) if th*2 <= h else q1
        q4 = arr[th:th*2, tw:tw*2].astype(np.float32) if th*2 <= h and tw*2 <= w else q1
        averaged = np.clip((q1 + q2 + q3 + q4) / 4, 0, 255).astype(np.uint8)
        variants.append(averaged)

        # 3. Tile-averaged + aggressive CLAHE (boosts local contrast by ~6–8×)
        if _CV2_OK:
            clahe_strong = cv2.createCLAHE(clipLimit=8.0, tileGridSize=(4, 4))
            clahe_mild   = cv2.createCLAHE(clipLimit=4.0, tileGridSize=(4, 4))

            lab = cv2.cvtColor(averaged, cv2.COLOR_RGB2LAB)
            lc, a, b = cv2.split(lab)
            enhanced = cv2.merge([clahe_strong.apply(lc), a, b])
            variants.append(cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB))

            # 4. Tile-averaged + histogram stretching (global contrast amplification)
            gray_avg = _to_gray_cv(averaged)
            lo, hi = np.percentile(gray_avg, [2, 98])
            if hi > lo:
                stretched = np.clip((gray_avg.astype(np.float32) - lo) / (hi - lo) * 255, 0, 255).astype(np.uint8)
            else:
                stretched = gray_avg
            variants.append(cv2.cvtColor(stretched, cv2.COLOR_GRAY2RGB))

            # 5. Tile-averaged + median blur (removes texture noise, preserves QR modules)
            blurred = cv2.medianBlur(averaged, 5)
            variants.append(blurred)

            # 6. Tile-averaged + median blur + strong CLAHE
            lab2 = cv2.cvtColor(blurred, cv2.COLOR_RGB2LAB)
            lc2, a2, b2 = cv2.split(lab2)
            enhanced2 = cv2.merge([clahe_strong.apply(lc2), a2, b2])
            variants.append(cv2.cvtColor(enhanced2, cv2.COLOR_LAB2RGB))

            # 7. Tile-averaged + histogram stretch + median blur
            gray_blur = cv2.medianBlur(gray_avg, 5)
            lo2, hi2 = np.percentile(gray_blur, [2, 98])
            if hi2 > lo2:
                stretched2 = np.clip((gray_blur.astype(np.float32) - lo2) / (hi2 - lo2) * 255, 0, 255).astype(np.uint8)
            else:
                stretched2 = gray_blur
            variants.append(cv2.cvtColor(stretched2, cv2.COLOR_GRAY2RGB))

            # 8. Tile-averaged + Otsu threshold
            _, otsu = cv2.threshold(gray_blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            variants.append(cv2.cvtColor(otsu, cv2.COLOR_GRAY2RGB))

            # 9. Tile-averaged + upscale 4× + unsharp mask (enhances tiny QR modules)
            up = cv2.resize(averaged, (tw * 4, th * 4), interpolation=cv2.INTER_CUBIC)
            blur_up = cv2.GaussianBlur(up, (0, 0), 2.0)
            unsharp = cv2.addWeighted(up, 2.5, blur_up, -1.5, 0)
            variants.append(np.clip(unsharp, 0, 255).astype(np.uint8))

    if not _CV2_OK:
        return variants

    clahe_mild = cv2.createCLAHE(clipLimit=4.0, tileGridSize=(8, 8))
    clahe_strong = cv2.createCLAHE(clipLimit=8.0, tileGridSize=(4, 4))

    # 10. Original + strong CLAHE (fallback if tiling doesn't help)
    lab = cv2.cvtColor(arr, cv2.COLOR_RGB2LAB)
    lc, a, b = cv2.split(lab)
    enhanced = cv2.merge([clahe_strong.apply(lc), a, b])
    variants.append(cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB))

    # 11. Original + unsharp mask
    blur = cv2.GaussianBlur(arr, (0, 0), 2.0)
    unsharp = cv2.addWeighted(arr, 2.5, blur, -1.5, 0)
    variants.append(np.clip(unsharp, 0, 255).astype(np.uint8))

    return variants


def _to_gray_cv(arr: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)


def _to_gray_np(arr: np.ndarray) -> np.ndarray:
    return (0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1]
            + 0.114 * arr[:, :, 2]).astype(np.uint8)
