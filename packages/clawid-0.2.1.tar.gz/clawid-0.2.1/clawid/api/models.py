"""Pydantic request / response models for the clawID REST API."""

from typing import Any
from pydantic import BaseModel


class DetectResponse(BaseModel):
    detected: bool
    clawid: str | None = None
    metadata: dict[str, Any] | None = None


class AssetResponse(BaseModel):
    clawid: str
    metadata: dict[str, Any]


class DeleteResponse(BaseModel):
    deleted: bool
    clawid: str


class HealthResponse(BaseModel):
    status: str
    version: str
    store: str | None = None
