from setuptools import setup, find_packages

setup(
    name='clawid',
    version='0.1.0',
    description='Digital watermarking SDK for AI-generated images and video',
    packages=find_packages(exclude=['tests*']),
    python_requires='>=3.10',
    install_requires=[
        'Pillow>=9.0.0',
        'numpy>=1.21.0',
        'PyWavelets>=1.3.0',
    ],
    extras_require={
        'dev': ['pytest>=7.0.0'],
    },
    entry_points={
        'console_scripts': [
            'clawid=clawid.cli:main',
        ],
    },
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Multimedia :: Graphics',
        'Topic :: Security',
    ],
)
