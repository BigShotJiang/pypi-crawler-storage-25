"""
PyTorch building blocks for DORA (dose- and cell-conditioned gene trajectory).

Contains:
  - ``rrmse`` / ``rrmse_penality``: reconstruction and regularization losses.
  - ``MLP``, ``GeneralizedSigmoid``, ``Basic_ff``: submodules.
  - ``DORA``: full model tying drug/cell embeddings, dose response, and decoder.
"""

import torch
from torch import cat as tcat


class rrmse(torch.nn.Module):
    """Root relative mean squared error over genes, then mean over cells."""

    def __init__(self):
        super().__init__()

    def forward(self, y_real, y_pred):
        # Per-cell RMSE across genes (axis=1), then mean across cells in batch.
        return torch.sqrt(((y_real - y_pred) ** 2).mean(dim=1)).mean()


class rrmse_penality(torch.nn.Module):
    """Penalizes magnitude of predicted deltas (L2-style per cell, then mean)."""

    def __init__(self):
        super().__init__()

    def forward(self, y_pred):
        return torch.sqrt((y_pred**2).mean(dim=1)).mean()


class MLP(torch.nn.Module):
    """
    Fully connected stack with ReLU and optional BatchNorm on hidden layers.

    The final linear output can optionally pass through ReLU or Sigmoid, or stay linear.
    """

    def __init__(self, sizes, bias_f=True, last_layer="linear", batch_norm=True):
        super().__init__()
        layers = []
        for s in range(len(sizes) - 1):
            layers += [
                torch.nn.Linear(sizes[s], sizes[s + 1], bias=bias_f),
                torch.nn.BatchNorm1d(sizes[s + 1])
                if batch_norm and s < len(sizes) - 2
                else None,
                torch.nn.ReLU(),
            ]

        # Drop None placeholders and remove trailing ReLU (output should be raw logits
        # before optional last nonlinearity).
        layers = [l for l in layers if l is not None][:-1]

        self.relu = torch.nn.ReLU()
        self.sigmoid = torch.nn.Sigmoid()

        self.last_layer = last_layer
        self.network = torch.nn.Sequential(*layers)

    def forward(self, x):
        if self.last_layer == "relu":
            return self.relu(self.network(x))
        if self.last_layer == "sigmoid":
            return self.sigmoid(self.network(x))
        return self.network(x)


class GeneralizedSigmoid(torch.nn.Module):
    """
    Per-drug dose–response curve: log1p-scaled dose, learnable scale/bias, sigmoid.

    ``forward`` subtracts ``sigmoid(bias)`` so the response at dose 0 is near zero.
    """

    def __init__(self, dim, device):
        super().__init__()
        self.beta = torch.nn.Parameter(
            torch.ones(1, dim, device=device), requires_grad=True
        )
        self.bias = torch.nn.Parameter(
            torch.zeros(1, dim, device=device), requires_grad=True
        )

    def forward(self, x):
        c0 = self.bias.sigmoid()
        return (torch.log1p(x) * self.beta + self.bias).sigmoid() - c0

    def one_drug(self, x, i):
        """Scalar dose ``x`` for drug index ``i`` (used in multi-drug loops)."""
        c0 = self.bias[0][i].sigmoid()
        return (torch.log1p(x) * self.beta[0][i] + self.bias[0][i]).sigmoid() - c0


class Basic_ff(torch.nn.Module):
    """
    One residual step: concat(state, drug+cell latent) → MLP delta, add to state.

    If ``doses_response`` is provided, the MLP output is scaled by it (per-sample scalar
    broadcast); otherwise the full hidden delta is added to ``x``.
    """

    def __init__(self, in_dim, out_dim, hid, bias_f=True, last_layer="linear"):
        super().__init__()
        self.f1 = torch.nn.Linear(in_dim, hid)
        self.f2 = torch.nn.Linear(hid, out_dim)
        self.rel = torch.nn.ReLU()
        self.bn = torch.nn.BatchNorm1d(hid)

    def forward(self, x, prev=None, doses_response=None):
        x_ = tcat([x, prev], dim=1)
        res = self.rel(self.bn(self.f1(x_)))
        if doses_response is not None:
            delta_emb = doses_response.view(-1, 1) * self.f2(res)
            res = x + delta_emb
        else:
            delta_emb = self.f2(res)
            res = x + delta_emb
        return res, delta_emb


class DORA(torch.nn.Module):
    """
    Drug + cell conditioned latent trajectory with gene decoder.

    Expects hyperparameters in ``hparam`` (dims, layer counts, device, optim settings).
    Training uses ``update``; inference via ``predict``.
    """

    def __init__(self, num_genes, num_drugs, num_cells, genes, dosage_len=20, hparam=None):
        super().__init__()

        self.best_score = -1e3
        self.patience_trials = 0
        self.patience = hparam["max_patience"]
        dim_hid = hparam["dim_hid"]
        dep_hid = hparam["dep_hid"]
        self.module_num = hparam["module"]
        self.genes = genes

        self.decoder = MLP(
            [dim_hid] + [num_genes],
            bias_f=False,
            last_layer=hparam["last_layer"],
            batch_norm=hparam["batch_norm"],
        )

        self.dim_hid = dim_hid
        self.loss_autoencoder = rrmse()
        self.loss_penality = rrmse_penality()

        self.device = hparam["device"]
        self.dosers = GeneralizedSigmoid(num_drugs, self.device)
        self.drug_embeddings_nn = torch.nn.Linear(hparam["dim_drug_feature"], dim_hid)
        self.cell_embeddings_nn = torch.nn.Linear(
            hparam["dim_cell_feature"], hparam["cell_dim_hid"]
        )
        self.drug_embeddings = torch.nn.Embedding(num_drugs, dim_hid)
        self.cell_embeddings = torch.nn.Embedding(num_cells, hparam["cell_dim_hid"])

        # Either a stack of ``Basic_ff`` (multi-step) or a single shared module.
        self.pred_genes = torch.nn.ModuleList()
        if self.module_num != 1:
            for _ in range(hparam["nb_layer"] - 1):
                self.pred_genes.append(
                    Basic_ff(dim_hid * 2 + hparam["cell_dim_hid"], dim_hid, dim_hid * 2)
                )
        else:
            self.pred_genes = Basic_ff(
                dim_hid * 2 + hparam["cell_dim_hid"], dim_hid, dim_hid * 2
            )

        self.optimizer_autoencoder = torch.optim.Adam(
            self.parameters(), lr=hparam["lr"], weight_decay=hparam["wd"]
        )

        self.scheduler_autoencoder = torch.optim.lr_scheduler.StepLR(
            self.optimizer_autoencoder, step_size=hparam["step_size_lr"]
        )

    def early_stopping(self, score):
        """Returns True when validation score has not improved for ``patience`` checks."""
        if score > self.best_score:
            self.best_score = score
            self.patience_trials = 0
        else:
            self.patience_trials += 1

        return self.patience_trials > self.patience

    def compute_drug_reponse(self, drugs, drugs_dose):
        """Per-sample vector of dose responses for the batch (one entry per drug slot)."""
        doses = []
        for d in range(len(drugs)):
            this_drug = drugs[d]
            dosage = drugs_dose[d]
            dose = self.dosers.one_drug(dosage, [this_drug])
            doses.append(dose)
        dose_response = torch.hstack(doses)
        return dose_response

    def predict(
        self,
        drugs,
        drugs_feature,
        cell_feature,
        indices,
        cells,
        drugs_dose,
        return_emb=False,
    ):
        """
        Walk the latent trajectory for each dose step and decode gene profiles.

        ``indices`` columns index rows in ``self.genes`` (control + one per step).
        Reconstructions add the control baseline ``genes_control`` from the first column.
        """
        batch_size, _ = drugs.shape

        if drugs_feature is not None:
            drugs_feature = drugs_feature.to(self.device)
            latent_drug = self.drug_embeddings_nn(drugs_feature)
        else:
            latent_drug = self.drug_embeddings(drugs).squeeze(1)
        if cell_feature is not None:
            cell_feature = cell_feature.to(self.device)
            latent_cell = self.cell_embeddings_nn(cell_feature)
        else:
            latent_cell = self.cell_embeddings(cells).squeeze(1)

        emb = torch.zeros(batch_size, self.dim_hid).to(self.device)
        lat_comp = tcat([latent_drug, latent_cell], dim=1)

        gene_reconstructions_arr = []
        emb_arr = []
        delta_emb_arr = []
        genes_control = self.genes[indices[:, 0]]
        for step in range(indices.shape[1] - 1):
            if drugs_dose is not None:
                dosage_step_pre = drugs_dose[:, step]
                dosage_step_aft = drugs_dose[:, (step + 1)]
                doses_response = self.compute_drug_reponse(
                    drugs, dosage_step_aft
                ) - self.compute_drug_reponse(drugs, dosage_step_pre)
            else:
                doses_response = None
            if self.module_num != 1:
                emb, delta_emb = self.pred_genes[step](emb, lat_comp, doses_response)
            else:
                emb, delta_emb = self.pred_genes(emb, lat_comp, doses_response)

            gene_reconstructions = self.decoder(emb)
            gene_reconstructions_arr.append(gene_reconstructions + genes_control)

            emb_arr.append(emb)
            delta_emb_arr.append(delta_emb)
        if return_emb:
            return gene_reconstructions_arr, emb_arr, delta_emb_arr
        return gene_reconstructions_arr

    def update(self, drugs, drugs_feature, cell_feature, indices, cells, drugs_dose, masks, param_pen=0):
        """One optimization step: masked reconstruction + penalty on latent deltas."""
        gene_reconstructions_arr, _, delta_emb_arr = self.predict(
            drugs,
            drugs_feature,
            cell_feature,
            indices,
            cells,
            drugs_dose,
            return_emb=True,
        )
        reconstruction_loss = 0
        for id_g, gene_reconstructions in enumerate(gene_reconstructions_arr):
            id_gene = indices[:, (id_g + 1)]
            gene_step = self.genes[id_gene]

            mask = masks[:, (id_g + 1)]
            if mask.sum() > 0:
                loss = self.loss_autoencoder(
                    gene_reconstructions[mask == 1], gene_step[mask == 1]
                )
                loss_pena = self.loss_penality(delta_emb_arr[id_g][mask == 1])
                reconstruction_loss += loss + loss_pena * param_pen

        self.optimizer_autoencoder.zero_grad()
        reconstruction_loss.backward()
        self.optimizer_autoencoder.step()

        return {
            "loss_reconstruction": reconstruction_loss.item(),
        }
