"""
Data loading for DORA: AnnData-backed gene matrix, perturbation metadata, masks.

``CustomDataset_mask`` builds tensors aligned to a fixed dose grid ``dosages_standard``.
Use ``dataset_selection`` when paths follow the preprocessed layout on disk.
"""

from torch.utils.data import Dataset
import numpy as np
import torch
import scanpy as sc
import joblib
from sklearn.preprocessing import OneHotEncoder, StandardScaler


def get_normaled_cell(feature_dict_cell):
    """Z-score each cell feature vector across cells (fit on all cells in the dict)."""
    feature_dict_cell_new = {}
    cell_feature = []
    for cell in feature_dict_cell:
        cell_feature += [feature_dict_cell[cell]]
    trans = StandardScaler()
    cell_feature_norm = trans.fit_transform(np.array(cell_feature))
    for i, cell in enumerate(feature_dict_cell):
        feature_dict_cell_new[cell] = cell_feature_norm[i, :]
    return feature_dict_cell_new


class CustomDataset_mask(Dataset):
    """
    PyTorch dataset: (drug_id, cell_id, dose grid, optional features, indices, masks).

    ``dataset`` maps ``(cell_id, drug_name)`` to ``dose``, ``indice`` (row index per dose).
    Missing doses use index ``-666`` and mask 0 so losses can skip them.

    Args:
        adata: AnnData whose ``X`` is the gene expression matrix (cells × genes).
        adata.obs: the metadata of the samples, should contain the following columns (cell_id, pert_iname, pert_dose, response_label)
        dataset: Nested dict as above.
        encoder: Another ``CustomDataset_mask`` to copy fitted OneHotEncoders from.
        feature_dict_drug / feature_dict_cell: Optional continuous embeddings per id.
        dosages_standard: Fixed list of dose values shared by every sample.
        return_response: If True, expects ``adata.obs['response_label']``.
    """

    def __init__(
        self,
        adata,
        dataset: dict,
        encoder=None,
        feature_dict_drug=None,
        feature_dict_cell=None,
        dosages_standard=None,
        return_response=False,
    ):
        # AnnData X can be sparse (scipy) or dense; torch needs a dense array.
        try:
            genes = adata.X
        except Exception:
            genes = adata.X.A
            genes = genes.toarray()
        if hasattr(genes, "toarray"):
            genes = genes.toarray()
        genes = np.asarray(genes)

        self.genes = torch.tensor(genes).to(dtype=torch.float32)
        self.return_response = return_response
        if self.return_response:
            self.response_label = torch.tensor(adata.obs.response_label.values).to(
                dtype=torch.float32
            )

        if encoder is None:
            self.encoder_drug = OneHotEncoder(sparse_output=False)
            drugs_unique = np.array(adata.obs.pert_iname.unique())
            cell_unique = np.array(adata.obs.cell_id.unique())
            self.encoder_drug.fit(drugs_unique.reshape(-1, 1))
            self.encoder_cell = OneHotEncoder(sparse_output=False)
            self.encoder_cell.fit(cell_unique.reshape(-1, 1))
        else:
            self.encoder_drug = encoder.encoder_drug
            self.encoder_cell = encoder.encoder_cell

        drug_names = []
        cell_names = []
        drugs_dose = []
        indices = []
        masks = []
        for cov, drug in dataset:
            dose_cov_drug = dataset[(cov, drug)]["dose"]
            indice_t = [
                dataset[(cov, drug)]["indice"][dose_cov_drug.index(dose)]
                if dose in dataset[(cov, drug)]["dose"]
                else -666
                for dose in dosages_standard
            ]
            mask = [1 if dose in dataset[(cov, drug)]["dose"] else 0 for dose in dosages_standard]

            drugs_dose.append(dosages_standard)
            drug_names.append(drug)
            cell_names.append(cov)
            indices.append(indice_t)
            masks.append(mask)

        drug_names = np.array(drug_names)
        cell_names = np.array(cell_names)
        drugs_ohe = self.encoder_drug.transform(drug_names.reshape(-1, 1))
        cell_ohe = self.encoder_cell.transform(cell_names.reshape(-1, 1))
        self.drugs = torch.tensor(drugs_ohe.argmax(axis=1).reshape(-1, 1))
        self.cells = torch.tensor(cell_ohe.argmax(axis=1).reshape(-1, 1))

        # Must be False if neither feature dict is given (avoids AttributeError in __getitem__).
        self.feature = False
        if feature_dict_drug is not None:
            self.feature = True
            drugs_features = []
            for drug in drug_names:
                drugs_features += [[feature_dict_drug[drug].numpy().T]]

            self.drugs_feature = torch.tensor(np.concatenate(drugs_features)).to(
                dtype=torch.float32
            )

        if feature_dict_cell is not None:
            self.feature = True
            cells_feature = []
            for cell in cell_names:
                cells_feature += [[feature_dict_cell[cell].T]]

            self.cells_feature = torch.tensor(np.concatenate(cells_feature)).to(
                dtype=torch.float32
            )

        self.drugs_dose = torch.tensor(drugs_dose).to(dtype=torch.float32)
        self.indices = torch.tensor(indices).to(dtype=torch.int32)
        self.masks = torch.tensor(masks).to(dtype=torch.int32)

    def __len__(self):
        return len(self.drugs_dose)

    def __getitem__(self, idx):
        if self.feature:
            return (
                self.drugs[idx],
                self.cells[idx],
                self.drugs_dose[idx],
                self.drugs_feature[idx],
                self.cells_feature[idx],
                self.indices[idx],
                self.masks[idx],
            )

        return (
            self.drugs[idx],
            self.cells[idx],
            self.drugs_dose[idx],
            self.indices[idx],
            self.masks[idx],
        )

    def subset(self, idx):
        """View a subset of rows without copying the full gene matrix."""
        return SubDataset(self, idx)


class SubDataset:
    """Lightweight slice of ``CustomDataset_mask`` (shares ``genes`` tensor)."""

    def __init__(self, dataset: CustomDataset_mask, idx):
        self.genes = dataset.genes
        if dataset.return_response:
            self.response_label = dataset.response_label
        self.drugs = dataset.drugs[idx]
        self.cells = dataset.cells[idx]
        self.drugs_dose = dataset.drugs_dose[idx]
        self.indices = dataset.indices[idx]
        self.masks = dataset.masks[idx]
        self.encoder_drug = dataset.encoder_drug
        self.encoder_cell = dataset.encoder_cell

        if dataset.feature:
            self.drugs_feature = dataset.drugs_feature[idx]
            self.cells_feature = dataset.cells_feature[idx]
        self.feature = dataset.feature

    def __len__(self):
        return len(self.drugs_dose)

    def __getitem__(self, idx):
        if self.feature:
            return (
                self.drugs[idx],
                self.cells[idx],
                self.drugs_dose[idx],
                self.drugs_feature[idx],
                self.cells_feature[idx],
                self.indices[idx],
                self.masks[idx],
            )

        return (
            self.drugs[idx],
            self.cells[idx],
            self.drugs_dose[idx],
            self.indices[idx],
            self.masks[idx],
        )


def dataset_selection(data_name, data_path="../data_pre/"):
    """Load preprocessed AnnData, train/test splits, and feature dicts for ``data_name``."""
    adata = sc.read(data_path + str(data_name) + "/adata_no_repeat.h5ad")
    feature_dict_drug = joblib.load(
        data_path + "/drugs_feature" + "/" + str(data_name) + "_chembert.joblib"
    )
    feature_dict_cell = joblib.load(
        data_path + "/cells_feature" + "/" + str(data_name) + "_gene_exp.joblib"
    )
    dataset_train = joblib.load(data_path + str(data_name) + "/data_train.joblib")
    dataset_test = joblib.load(data_path + str(data_name) + "/data_test.joblib")
    feature_dict_cell = get_normaled_cell(feature_dict_cell)
    return adata, dataset_train, dataset_test, feature_dict_cell, feature_dict_drug
