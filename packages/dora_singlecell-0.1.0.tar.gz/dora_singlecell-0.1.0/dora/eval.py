"""
Classification-oriented metrics for binary response / phenotype prediction.

Used alongside training scripts that output probabilities; pairs with the same
``calculate_accuracy`` helper in ``train_clf_test_adam`` when scoring phenotypic heads.
"""

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    auc,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)


def calculate_accuracy(test_prob, test_label):
    """
    Summarize binary predictions given probabilities and ground-truth labels.

    Parameters
    ----------
    test_prob : array-like
        Predicted probabilities (or scores in [0, 1]) per sample.
    test_label : array-like
        Binary ground-truth labels (same length as ``test_prob``).

    Returns
    -------
    list of float
        ``[ROC-AUC, PR-AUC (area under precision–recall curve), accuracy,
        precision, recall]``. If there are no positive labels in ``test_label``,
        ROC/PR/precision/recall are returned as 0. If the model predicts no
        positives, precision and recall are 0 while ROC-AUC and PR-AUC may still
        be computed from scores.

    Notes
    -----
    Hard labels are obtained with threshold 0.5 on ``test_prob``. The docstring
    mention of "RECALL when PRECISION is 0.75" refers to an older metric choice
    and is not implemented in the returned list.
    """
    pred_label = np.array([1 if x > 0.5 else 0 for x in test_prob])
    ACC = accuracy_score(test_label, pred_label)
    if test_label.sum() > 0:
        if pred_label.sum() > 0:
            PREC = precision_score(test_label, pred_label)
            TPR = recall_score(test_label, pred_label)

            precision, recall, _thresholds = precision_recall_curve(test_label, test_prob)

            return [
                roc_auc_score(test_label, test_prob),
                auc(recall, precision),
                ACC,
                PREC,
                TPR,
            ]
        precision, recall, _thresholds = precision_recall_curve(test_label, test_prob)
        return [roc_auc_score(test_label, test_prob), auc(recall, precision), ACC, 0, 0]

    return [0, 0, ACC, 0, 0]
