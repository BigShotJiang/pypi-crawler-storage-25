"""Training and evaluation loops for ``DORA``."""

from .utils import CustomDataset_mask
import torch
import numpy as np
from sklearn.metrics import r2_score
from scipy.stats import pearsonr


def eval_model(model, datasets_test, genes, hparam):
    # eval the model on the test dataset 
    model.eval()
    test_loss = []
    r2_loss = []
    pearson_loss = []
    with torch.no_grad():
        for data in datasets_test:
            data = [tensor.to(model.device) for tensor in data]

            drugs, cells, drugs_dose, drugs_feature, cell_feature, indices, masks = (
                data[0],
                data[1],
                data[2],
                data[3],
                data[4],
                data[5],
                data[6],
            )
            if not hparam["drug_dose_f"]:
                drugs_dose = None
            # reconstruct the gene expressio
            gene_reconstructions_arr = model.predict(
                drugs,
                drugs_feature,
                cell_feature,
                indices,
                cells=cells,
                drugs_dose=drugs_dose,
            )

            reconstruction_loss = 0
            for id_g, gene_reconstructions in enumerate(gene_reconstructions_arr):
                id_gene = indices[:, (id_g + 1)]
                mask = masks[:, (id_g + 1)]
                if mask.sum() > 0:
                    gene_step = genes[id_gene][mask == 1]
                    gene_reconstructions_left = gene_reconstructions[mask == 1]
                    y_true, y_pred = (
                        gene_step.cpu().detach().numpy(),
                        gene_reconstructions_left.cpu().detach().numpy(),
                    )
                    r2_loss += [
                        r2_score(y_true[i, :], y_pred[i, :]) for i in range(len(gene_step))
                    ]
                    pearson_loss += [
                        pearsonr(y_true[i, :], y_pred[i, :])[0]
                        for i in range(len(gene_step))
                    ]

                    loss = model.loss_autoencoder(gene_reconstructions_left, gene_step)

                    reconstruction_loss += loss
            test_loss.append(reconstruction_loss.item())
    return np.mean(test_loss), np.mean(r2_loss), np.mean(pearson_loss)


def train_model(
    model,
    data_train: CustomDataset_mask,
    data_test=None,
    data_val=None,
    hparam=None,
):
    genes = model.genes.to(hparam["device"])
    datasets_train = torch.utils.data.DataLoader(
        data_train, batch_size=hparam["batch_size"], shuffle=True
    )
    if data_test is not None:
        datasets_test = torch.utils.data.DataLoader(
            data_test, batch_size=hparam["batch_size"], shuffle=True
        )
    if data_val is not None:
        datasets_val = torch.utils.data.DataLoader(
            data_val, batch_size=hparam["batch_size"], shuffle=False
        )

    history = {
        "epoch": [],
        "train": [],
        "test": [],
        "r2": [],
        "pearson": [],
    }
    best_model = model
    mean_loss_val = mean_r2_val = mean_pear_val = float("nan")
    epoch = -1
    try:
        for epoch in range(hparam["max_epoch"]):
            train_loss = []
            model.train()
            for data in datasets_train:
                data = [tensor.to(model.device) for tensor in data]

                drugs, cells, drugs_dose, drugs_feature, cell_feature, indices, masks = (
                    data[0],
                    data[1],
                    data[2],
                    data[3],
                    data[4],
                    data[5],
                    data[6],
                )
                if not hparam["drug_dose_f"]:
                    drugs_dose = None
                minibatch_training_stats = model.update(
                    drugs=drugs,
                    drugs_feature=drugs_feature,
                    cell_feature=cell_feature,
                    indices=indices,
                    cells=cells,
                    drugs_dose=drugs_dose,
                    masks=masks,
                    param_pen=hparam["param_pen"],
                )
                train_loss += [minibatch_training_stats["loss_reconstruction"]]

            print(f"epoch: {epoch} with loss: {np.mean(train_loss)}")

            stop = False
            if (data_test is not None) and (epoch % 10 == 0):
                mean_loss, mean_r2, mean_pear = eval_model(
                    model, datasets_test=datasets_test, genes=genes, hparam=hparam
                )

                print(
                    f"epoch: {epoch} with test loss: {mean_loss} with r2: {mean_r2} with pearson: {mean_pear}"
                )
                history["test"] += [mean_loss]
                history["r2"] += [mean_r2]
                history["pearson"] += [mean_pear]
                stop = model.early_stopping(mean_r2)
                if model.patience_trials == 0:
                    best_model = model
                    if data_val is not None:
                        mean_loss_val, mean_r2_val, mean_pear_val = eval_model(
                            best_model,
                            datasets_test=datasets_val,
                            genes=genes,
                            hparam=hparam,
                        )

                        print(
                            f"epoch: {epoch} with validation loss: {mean_loss_val} with r2: {mean_r2_val} with pearson: {mean_pear_val}"
                        )

            history["epoch"] += [epoch]
            history["train"] += [np.mean(train_loss)]
            if stop:
                print("-----early stop------")
                break

    except KeyboardInterrupt:
        print("save model by keyboard interruption")

    if history["test"]:
        loss_test, r2, pearson = history["test"][-1], history["r2"][-1], history["pearson"][-1]
        print(f"epoch: {epoch} with test loss: {loss_test} with r2: {r2} with pearson: {pearson}")
    if data_val is not None:
        print(
            f"epoch: {epoch} with validation loss: {mean_loss_val} with r2: {mean_r2_val} with pearson: {mean_pear_val}"
        )

    return best_model, history
