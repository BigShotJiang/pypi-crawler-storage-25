"""
Joint fine-tuning of DORA (or similar) with a linear phenotypic classifier on latents.

``DeepModel`` wraps a small sigmoid head on concatenated trajectory embeddings while
optionally freezing non-decoder weights in the backbone. **Note:** ``DeepModel.train``
overrides ``nn.Module.train()``; call ``model.eval()`` / ``model.train(mode=True)``
on the backbone separately if you rely on PyTorch’s training-mode flag on ``DeepModel``.
"""

import numpy as np
import torch
from torch import Tensor, nn
from scipy.stats import pearsonr
from sklearn.metrics import (
    accuracy_score,
    auc,
    precision_recall_curve,
    precision_score,
    r2_score,
    recall_score,
    roc_auc_score,
)


def calculate_accuracy(test_prob, test_label):
    """
    Binary classification summary from probabilities and labels.

    Parameters
    ----------
    test_prob : array-like
        Predicted probabilities per sample.
    test_label : array-like
        Binary labels.

    Returns
    -------
    list of float
        ``[ROC-AUC, PR-AUC, accuracy, precision, recall]``; degenerate cases
        return zeros for undefined metrics (see ``eval.calculate_accuracy``).
    """
    pred_label = np.array([1 if x > 0.5 else 0 for x in test_prob])
    ACC = accuracy_score(test_label, pred_label)
    if test_label.sum() > 0:
        if pred_label.sum() > 0:
            PREC = precision_score(test_label, pred_label)
            TPR = recall_score(test_label, pred_label)

            precision, recall, _thresholds = precision_recall_curve(test_label, test_prob)

            return [
                roc_auc_score(test_label, test_prob),
                auc(recall, precision),
                ACC,
                PREC,
                TPR,
            ]
        precision, recall, _thresholds = precision_recall_curve(test_label, test_prob)
        return [roc_auc_score(test_label, test_prob), auc(recall, precision), ACC, 0, 0]

    return [0, 0, ACC, 0, 0]


class DeepModel(nn.Module):
    """
    Linear classifier on latent embeddings plus optional partial unfreezing of a backbone.

    The backbone (``model_dora``) is expected to implement ``predict(..., return_emb=True)``
    This is the pretrained DORA model based on gene expression data 
    and expose ``loss_autoencoder`` for gene reconstruction loss.

    Parameters
    ----------
    in_d : int
        Latent dimension (input size to the linear head).
    hid_d : int
        Reserved for future hidden layers; unused in the current ``Sequential``.
    nb_epoch : int
        Number of training epochs for ``DeepModel.train`` (the training loop method).
    bsize : int
        Train loader batch size (test loader uses full ``test_dataset`` length).
    lr, weight_decay : float
        Defaults for documentation; actual optimizer LRs come from ``hparam`` in ``.train``.
    optimizer : str
        ``"Adam"`` or ``"AdamW"`` for the classifier head only (see ``DICT_OPT``).
    model_dora : nn.Module
        Pretrained trajectory / autoencoder model.
    fine_tune : bool
        If True, only parameters whose name contains ``'decoder'`` are trainable on the
        backbone; otherwise all backbone parameters update.
    """

    def __init__(
        self,
        in_d: int = 384,
        hid_d: int = 64,
        nb_epoch: int = 100,
        bsize: int = 64,
        lr: float = 1e-3,
        weight_decay: float = 0.0,
        optimizer: str = "Adam",
        model_dora=None,
        fine_tune: bool = True,
    ) -> None:
        dict_opt = dict(Adam=torch.optim.Adam, AdamW=torch.optim.AdamW)
        super().__init__()

        self.net = nn.Sequential(
            nn.Linear(in_d, 1),
        )
        self.in_d = in_d
        self.to_proba = nn.Sigmoid()
        self.nb_epoch = nb_epoch
        self.bsize = bsize
        self.lr = lr
        self.weight_decay = weight_decay
        self.optimizer = dict_opt[optimizer]
        self.model_dora = model_dora

        for name, param in self.model_dora.named_parameters():
            if fine_tune:
                param.requires_grad = "decoder" in name
            else:
                param.requires_grad = True

    def forward(self, mol_rep: Tensor) -> Tensor:
        """
        Map latent vectors to class probabilities.

        Parameters
        ----------
        mol_rep : Tensor, shape (n, in_d)
            Concatenated or per-sample latent representations.

        Returns
        -------
        Tensor, shape (n, 1)
            Sigmoid probabilities.
        """
        net_res = self.net(mol_rep)
        return self.to_proba(net_res)

    def train(self, train_dataset, test_dataset, genes, response_label, hparam):
        """
        Alternating batch loop: reconstruction + BCE on response from latent heads.

        **Shadowing warning:** this method name replaces ``nn.Module.train()``; use
        ``nn.Module.train(self, mode)`` if you need to toggle dropout/BatchNorm on this module.

        Parameters
        ----------
        train_dataset, test_dataset : Dataset
            Seven-tensor batches (drugs, cells, dose grid, features, indices, masks).
        genes : Tensor
            Gene expression tensor indexed by batch indices.
        response_label : Tensor
            Binary (or soft) targets aligned with ``genes`` / mask positions.
        hparam : dict
            Must include ``lr_clf``, ``lr_msd``, ``weight_dec``, ``weight_dec_msd``, ``patience``.

        Returns
        -------
        list
            Output of ``calculate_accuracy`` on accumulated test predictions.
        """
        datasets_train = torch.utils.data.DataLoader(
            train_dataset, batch_size=self.bsize, shuffle=True
        )
        datasets_test = torch.utils.data.DataLoader(
            test_dataset, batch_size=len(test_dataset), shuffle=False
        )

        clf_loss_f = torch.nn.BCELoss()

        r2_loss = []
        pearson_loss = []

        optimzer_clf = torch.optim.Adam(
            self.net.parameters(), lr=hparam["lr_clf"], weight_decay=hparam["weight_dec"]
        )
        optimzer_msd = torch.optim.Adam(
            self.model_dora.parameters(),
            lr=hparam["lr_msd"],
            weight_decay=hparam["weight_dec_msd"],
        )

        best_acc = np.inf
        patience = 0
        loss_train = []
        loss_train_recons = []
        for epoch in range(self.nb_epoch):
            for data in datasets_train:
                data = [tensor.to(self.model_dora.device) for tensor in data]
                drugs, cells, drugs_dose, drugs_feature, cell_feature, indices, masks = (
                    data[0],
                    data[1],
                    data[2],
                    data[3],
                    data[4],
                    data[5],
                    data[6],
                )

                gene_reconstructions_arr, emb_arr, _ = self.model_dora.predict(
                    drugs,
                    drugs_feature,
                    cell_feature,
                    indices,
                    cells,
                    drugs_dose,
                    return_emb=True,
                )
                optimzer_clf.zero_grad()
                optimzer_msd.zero_grad()
                emb_all = []
                response_label_all = []
                loss_recon = 0
                for id_g, gene_reconstructions in enumerate(gene_reconstructions_arr):
                    id_gene = indices[:, (id_g + 1)]
                    mask = masks[:, (id_g + 1)]

                    if mask.sum() > 0:
                        gene_step = genes[id_gene][mask == 1]
                        gene_reconstructions_left = gene_reconstructions[mask == 1]
                        emb_ = emb_arr[id_g][mask == 1]
                        emb_all.append(emb_)
                        response_label_ = response_label[id_gene][mask == 1]
                        response_label_all.append(response_label_)
                        loss_recon += self.model_dora.loss_autoencoder(
                            gene_reconstructions_left, gene_step
                        )
                # Classifier on all masked latents in the batch; BCE + reconstruction.
                pred_label = self.forward(torch.concat(emb_all, axis=0))
                loss = clf_loss_f(pred_label, torch.concat(response_label_all, axis=0))
                loss.backward(retain_graph=True)
                loss_recon.backward(retain_graph=True)
                optimzer_clf.step()
                optimzer_msd.step()
                loss_train.append(loss.item())
                loss_train_recons.append(loss_recon.item())
            print("train loss: ", np.mean(loss_train), np.mean(loss_train_recons))

            real_labels = []
            pred_labels = []
            r2_loss = []
            pearson_loss = []
            loss_test = []
            with torch.no_grad():
                for data in datasets_test:
                    data = [tensor.to(self.model_dora.device) for tensor in data]

                    drugs, cells, drugs_dose, drugs_feature, cell_feature, indices, masks = (
                        data[0],
                        data[1],
                        data[2],
                        data[3],
                        data[4],
                        data[5],
                        data[6],
                    )

                    gene_reconstructions_arr, emb_arr, _ = self.model_dora.predict(
                        drugs,
                        drugs_feature,
                        cell_feature,
                        indices,
                        cells,
                        drugs_dose,
                        return_emb=True,
                    )
                    response_label_all = []
                    pred_label_all = []
                    for id_g, gene_reconstructions in enumerate(gene_reconstructions_arr):
                        id_gene = indices[:, (id_g + 1)]
                        mask = masks[:, (id_g + 1)]

                        if mask.sum() > 0:
                            gene_step = genes[id_gene][mask == 1]
                            gene_reconstructions_left = gene_reconstructions[mask == 1]
                            y_true, y_pred = (
                                gene_step.cpu().detach().numpy(),
                                gene_reconstructions_left.cpu().detach().numpy(),
                            )
                            r2_loss += [
                                r2_score(y_true[i, :], y_pred[i, :])
                                for i in range(len(gene_step))
                            ]
                            pearson_loss += [
                                pearsonr(y_true[i, :], y_pred[i, :])[0]
                                for i in range(len(gene_step))
                            ]
                            emb_ = emb_arr[id_g][mask == 1]
                            response_label_ = response_label[id_gene][mask == 1]
                            pred_label = self.forward(emb_)
                            response_label_all.append(response_label_)
                            pred_label_all.append(pred_label)
                            real_labels += list(response_label_.detach().cpu().numpy())
                            pred_labels += list(pred_label.detach().cpu().numpy())
                        # BCE aggregated over steps that produced predictions this batch.
                        loss = clf_loss_f(
                            torch.concat(pred_label_all, axis=0),
                            torch.concat(response_label_all, axis=0),
                        )
                    loss_test.append(loss.item())

                print(np.mean(loss_test))

                if np.mean(loss_test) < best_acc:
                    patience = 0
                    best_acc = np.mean(loss_test)
                    self.best_model = self.net
                else:
                    patience += 1
                if patience > hparam["patience"]:
                    print("---early stop----")
                    break
        acc = calculate_accuracy(np.array(pred_labels), np.array(real_labels))
        print(acc)
        return acc
