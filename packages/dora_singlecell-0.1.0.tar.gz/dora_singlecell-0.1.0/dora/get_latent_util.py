"""
Extract latent embeddings from a trained DORA-style model and package them as AnnData.

``get_latent`` runs the encoder/trajectory stack with dose information disabled
(``drugs_dose=None``), collects per-step latent vectors for masked samples, and
attaches cell / drug / dose metadata via the dataset’s sklearn encoders.
"""

import numpy as np
import scanpy as sc
import torch
from scipy.stats import pearsonr
from torchmetrics import R2Score


def compute_r2(y_true, y_pred):
    """
    R² between two 1D tensors using torchmetrics (GPU-friendly).

    Parameters
    ----------
    y_true, y_pred : torch.Tensor
        Same shape; typically one cell’s gene vector vs reconstruction.

    Returns
    -------
    float
        R² score. Values are clamped internally for numerical stability; NaNs in
        ``y_pred`` are not explicitly handled (torchmetrics may propagate NaN).
    """
    y_pred = torch.clamp(y_pred, -3e12, 3e12)
    metric = R2Score().to(y_true.device)
    metric.update(y_pred, y_true)
    return metric.compute().item()


def get_latent(model, datasets_val, genes, train_dataset):
    """
    Iterate validation batches, collect latent states and reconstruction quality.

    Parameters
    ----------
    model : torch.nn.Module
        Trained model with ``predict(..., return_emb=True)`` (e.g. DORA).
    datasets_val : DataLoader
        Batches matching ``CustomDataset_mask`` layout (7 tensors per batch).
    genes : torch.Tensor
        Full gene matrix indexed by ``indices`` (same convention as training).
    train_dataset : CustomDataset_mask
        Provides ``encoder_cell`` / ``encoder_drug`` to map integer ids back to names.

    Returns
    -------
    anndata.AnnData
        ``.X`` = stacked latent vectors; ``.obs`` contains ``cell_id``,
        ``pert_iname``, ``pert_dose``, composite ``pert_cell_dose``, and per-row
        ``r2_score`` from gene reconstruction.
    """
    r2_loss = []
    pearson_loss = []
    latent_dict = {
        "emb_all": [],
        "cell_id": [],
        "pert_iname": [],
        "drug_dose": [],
        "response_label": [],
        "r2_score": [],
    }
    model.eval()
    for data in datasets_val:
        data = [tensor.to(model.device) for tensor in data]

        drugs, cells, drugs_dose, drugs_feature, cell_feature, indices, masks = (
            data[0],
            data[1],
            data[2],
            data[3],
            data[4],
            data[5],
            data[6],
        )

        # Latent trajectory without dose conditioning (baseline for embedding export).
        gene_reconstructions_arr, emb_arr, _ = model.predict(
            drugs,
            drugs_feature,
            cell_feature,
            indices,
            cells=cells,
            drugs_dose=None,
            return_emb=True,
        )

        for id_g, gene_reconstructions in enumerate(gene_reconstructions_arr):
            id_gene = indices[:, (id_g + 1)]
            mask = masks[:, (id_g + 1)]

            if mask.sum() > 0:
                gene_step = genes[id_gene][mask == 1]
                gene_reconstructions_left = gene_reconstructions[mask == 1]

                r2_iter = [
                    compute_r2(gene_step[i, :], gene_reconstructions_left[i, :])
                    for i in range(len(gene_step))
                ]
                r2_loss += r2_iter

                y_true = gene_step.cpu().detach().numpy()
                y_pred = gene_reconstructions_left.cpu().detach().numpy()

                pearson_loss += [
                    pearsonr(y_true[i, :], y_pred[i, :])[0] for i in range(len(gene_step))
                ]
                latent_dict["emb_all"].append(emb_arr[id_g][mask == 1].cpu().detach().numpy())
                latent_dict["cell_id"].append(cells[mask == 1].cpu().detach().numpy())
                latent_dict["pert_iname"].append(drugs[mask == 1].cpu().detach().numpy())
                latent_dict["drug_dose"].append(
                    drugs_dose[:, (id_g + 1)][mask == 1].cpu().detach().numpy()
                )
                latent_dict["r2_score"].append(r2_iter)

    print("the R2 on gene reconstruction:", np.mean(r2_loss))
    print("the pearson on gene reconstruction", np.mean(pearson_loss))

    # Decode integer cell indices to strings via one-hot trick (inverse_transform).
    index_cell = np.vstack(latent_dict["cell_id"])
    onehot = np.zeros((len(index_cell), len(train_dataset.encoder_cell.categories_[0])))
    for i in range(len(index_cell)):
        onehot[i, index_cell[i]] = 1

    cells_name = train_dataset.encoder_cell.inverse_transform(onehot)

    index_drugs = np.vstack(latent_dict["pert_iname"])
    onehot = np.zeros((len(index_cell), len(train_dataset.encoder_drug.categories_[0])))
    for i in range(len(index_drugs)):
        onehot[i, index_drugs[i]] = 1

    drugs_name = train_dataset.encoder_drug.inverse_transform(onehot)

    dosages = np.hstack(latent_dict["drug_dose"])

    adata_emb = sc.AnnData(np.vstack(latent_dict["emb_all"]))
    adata_emb.obs["cell_id"] = cells_name.flatten()
    adata_emb.obs["pert_iname"] = drugs_name.flatten()
    adata_emb.obs["pert_dose"] = [str(el) for el in dosages]

    adata_emb.obs["pert_cell_dose"] = (
        adata_emb.obs["cell_id"].astype(str)
        + "_"
        + adata_emb.obs["pert_iname"].astype(str)
        + "_"
        + adata_emb.obs["pert_dose"].astype(str)
    )
    adata_emb.obs["r2_score"] = np.hstack(latent_dict["r2_score"])
    return adata_emb
