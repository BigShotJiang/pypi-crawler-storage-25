from __future__ import annotations

from errors import PyHorizonRuntimeError


class Environment:
    def __init__(self, parent: "Environment | None" = None):
        self.parent = parent
        self.values: dict[str, object] = {}

    def define(self, name: str, value: object) -> None:
        self.values[name] = value

    def assign(self, name: str, value: object, line: int | None = None, column: int | None = None) -> None:
        if name in self.values:
            self.values[name] = value
            return
        if self.parent is not None:
            self.parent.assign(name, value, line, column)
            return
        raise PyHorizonRuntimeError(f"Undefined variable '{name}'", line, column)

    def get(self, name: str, line: int | None = None, column: int | None = None) -> object:
        if name in self.values:
            return self.values[name]
        if self.parent is not None:
            return self.parent.get(name, line, column)
        raise PyHorizonRuntimeError(f"Undefined variable '{name}'", line, column)

