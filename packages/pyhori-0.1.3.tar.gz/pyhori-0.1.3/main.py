from __future__ import annotations

import sys
from pathlib import Path

from errors import PyHorizonError
from interpreter import Interpreter
from lexer import Lexer
from parser import Parser

VERSION = "0.1.3"


def run_file(file_path: Path) -> None:
    source = file_path.read_text(encoding="utf-8")
    tokens = Lexer(source, str(file_path)).tokenize()
    program = Parser(tokens).parse()
    interpreter = Interpreter()
    interpreter.execute(program)
    interpreter.run_gui()


def main() -> int:
    args = sys.argv[1:]

    if not args:
        default = Path("example.pyh")
        if default.exists():
            try:
                run_file(default)
                return 0
            except PyHorizonError as error:
                print(f"{default}: {error}")
                return 1

        print("Usage: pyhori program.pyh")
        return 1

    if args[0] in {"-h", "--help"}:
        print("Usage: pyhori program.pyh")
        print("       pyhori --version")
        return 0

    if args[0] in {"-v", "--version"}:
        print(f"pyhori {VERSION}")
        return 0

    file_path = Path(args[0])

    if file_path.suffix.lower() != ".pyh":
        print("Error: the program file must have the .pyh extension")
        return 1

    if not file_path.exists():
        print(f"Error: file not found: {file_path}")
        return 1

    try:
        run_file(file_path)
        return 0
    except PyHorizonError as error:
        print(f"{file_path}: {error}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
