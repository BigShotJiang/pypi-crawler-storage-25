from __future__ import annotations

from ast_nodes import (
    AssignStmt,
    Binary,
    Block,
    Call,
    ExprStmt,
    FuncDefStmt,
    IfStmt,
    LetStmt,
    Literal,
    AskExpr,
    PrintStmt,
    RawValue,
    SayStmt,
    Program,
    ReturnStmt,
    Index,
    WindowStmt,
    Unary,
    Variable,
    WhileStmt,
)
from errors import ParserError
from tokens import Token


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.current = 0

    def parse(self) -> Program:
        statements = []
        self._skip_newlines()

        while not self._check("EOF"):
            statements.append(self._statement())
            self._skip_newlines()

        return Program(statements)

    def _statement(self):
        self._skip_newlines()
        token = self._current_token()

        if token.type == "LET":
            return self._let_statement()
        if token.type == "IMP":
            return self._imp_statement()
        if token.type == "SET":
            return self._set_statement()
        if token.type == "PRINT":
            return self._print_statement()
        if token.type == "SAY":
            return self._say_statement()
        if token.type == "ASK":
            return ExprStmt(self._ask_expression(), token.line, token.column)
        if token.type == "WINDOW":
            return self._window_statement()
        if token.type == "IF":
            return self._if_statement()
        if token.type == "WHILE":
            return self._loop_statement("WHILE")
        if token.type == "LOOP":
            return self._loop_statement("LOOP")
        if token.type == "FUNC":
            return self._func_statement()
        if token.type == "RETURN":
            return self._return_statement()
        if token.type == "IDENT" and self._peek().type == "ASSIGN":
            return self._assignment_statement()

        expr = self._expression()
        return ExprStmt(expr, expr.line, expr.column)

    def _let_statement(self) -> LetStmt:
        keyword = self._consume("LET", "Expected 'let'")
        name = self._consume("IDENT", "Expected variable name after 'let'")
        self._match_optional_colon()
        self._consume("ASSIGN", "Expected '=' after variable name")
        value = self._assignment_value()
        return LetStmt(name.value, value, keyword.line, keyword.column)

    def _imp_statement(self) -> LetStmt:
        keyword = self._consume("IMP", "Expected 'imp'")
        name = self._consume("IDENT", "Expected variable name after 'imp'")
        self._match_optional_colon()
        self._consume("ASSIGN", "Expected '=' after variable name")
        value = self._assignment_value()
        return LetStmt(name.value, value, keyword.line, keyword.column)

    def _set_statement(self) -> AssignStmt:
        keyword = self._consume("SET", "Expected 'set'")
        name = self._consume("IDENT", "Expected variable name after 'set'")
        self._match_optional_colon()
        self._consume("ASSIGN", "Expected '=' after variable name")
        value = self._assignment_value()
        return AssignStmt(name.value, value, keyword.line, keyword.column)

    def _assignment_statement(self) -> AssignStmt:
        name = self._consume("IDENT", "Expected variable name")
        self._consume("ASSIGN", "Expected '=' after variable name")
        value = self._assignment_value()
        return AssignStmt(name.value, value, name.line, name.column)

    def _print_statement(self) -> PrintStmt:
        keyword = self._consume("PRINT", "Expected 'print'")
        value = self._expression()
        return PrintStmt(value, keyword.line, keyword.column)

    def _say_statement(self) -> PrintStmt:
        keyword = self._consume("SAY", "Expected 'say'")
        parts = self._say_parts()
        return SayStmt(parts, keyword.line, keyword.column)

    def _ask_expression(self):
        keyword = self._consume("ASK", "Expected 'ask'")
        parts = self._say_parts()
        return AskExpr(parts, keyword.line, keyword.column)

    def _window_statement(self) -> WindowStmt:
        keyword = self._consume("WINDOW", "Expected 'window'")
        title_tokens = []
        while not self._check("NEWLINE", "EOF", "END", "ELSE"):
            title_tokens.append(self._current_token())
            self.current += 1
        title_parts = [Literal(token.value, token.line, token.column) for token in title_tokens]
        title = RawValue(title_parts, keyword.line, keyword.column)
        return WindowStmt(title, keyword.line, keyword.column)

    def _return_statement(self) -> ReturnStmt:
        keyword = self._consume("RETURN", "Expected 'return'")
        if self._check("NEWLINE", "END", "ELSE", "EOF"):
            return ReturnStmt(None, keyword.line, keyword.column)
        value = self._expression()
        return ReturnStmt(value, keyword.line, keyword.column)

    def _if_statement(self) -> IfStmt:
        keyword = self._consume("IF", "Expected 'if'")
        condition = self._expression()
        self._match_optional_colon()
        self._skip_newlines()

        then_branch = Block(self._parse_block({"ELSE", "END"}))
        else_branch = None

        if self._match("ELSE"):
            self._match_optional_colon()
            self._skip_newlines()
            else_branch = Block(self._parse_block({"END"}))

        self._consume("END", "Expected 'end' to close if block")
        return IfStmt(condition, then_branch, else_branch, keyword.line, keyword.column)

    def _loop_statement(self, keyword_type: str) -> WhileStmt:
        keyword = self._consume(keyword_type, f"Expected '{keyword_type.lower()}'")
        condition = self._expression()
        self._match_optional_colon()
        self._skip_newlines()
        body = Block(self._parse_block({"END"}))
        self._consume("END", "Expected 'end' to close while block")
        return WhileStmt(condition, body, keyword.line, keyword.column)

    def _func_statement(self) -> FuncDefStmt:
        keyword = self._consume("FUNC", "Expected 'func'")
        name = self._consume("IDENT", "Expected function name")
        self._consume("LPAREN", "Expected '(' after function name")

        params = []
        if not self._check("RPAREN"):
            while True:
                param = self._consume("IDENT", "Expected parameter name")
                params.append(param.value)
                if not self._match("COMMA"):
                    break

        self._consume("RPAREN", "Expected ')' after parameter list")
        self._match_optional_colon()
        self._skip_newlines()
        body = Block(self._parse_block({"END"}))
        self._consume("END", "Expected 'end' to close function block")
        return FuncDefStmt(name.value, params, body, keyword.line, keyword.column)

    def _parse_block(self, stop_tokens: set[str]):
        statements = []
        self._skip_newlines()

        while not self._check("EOF") and not self._check_any(stop_tokens):
            statements.append(self._statement())
            self._skip_newlines()

        return statements

    def _assignment_value(self):
        value_start = self.current
        scan = self.current
        has_expression_operator = False

        while scan < len(self.tokens):
            token = self.tokens[scan]
            if token.type in {"NEWLINE", "EOF", "END", "ELSE"}:
                break
            if token.type in {
                "PLUS",
                "MINUS",
                "STAR",
                "SLASH",
                "PERCENT",
                "EQ",
                "NE",
                "LT",
                "LE",
                "GT",
                "GE",
                "LPAREN",
                "RPAREN",
                "LBRACKET",
                "RBRACKET",
                "DOT",
            }:
                has_expression_operator = True
                break
            if token.type == "ASK":
                has_expression_operator = True
                break
            scan += 1

        if has_expression_operator:
            return self._expression()

        while not self._check("NEWLINE", "EOF", "END", "ELSE"):
            self.current += 1

        tokens = self.tokens[value_start:self.current]
        if not tokens:
            raise ParserError("Expected value after '='", self._current_token().line, self._current_token().column)

        if tokens[0].type == "ASK":
            prompt_tokens = tokens[1:]
            return AskExpr(self._tokens_to_parts(prompt_tokens), tokens[0].line, tokens[0].column)

        parts = []
        parts.extend(self._tokens_to_parts(tokens))

        if len(parts) == 1 and isinstance(parts[0], Literal):
            return parts[0]

        first = tokens[0]
        return RawValue(parts, first.line, first.column)

    def _say_parts(self):
        start = self.current
        while not self._check("NEWLINE", "EOF", "END", "ELSE"):
            self.current += 1
        return self._tokens_to_parts(self.tokens[start:self.current])

    def _expression(self):
        return self._or()

    def _or(self):
        expr = self._and()
        while self._match("OR"):
            operator = self._previous()
            right = self._and()
            expr = Binary(expr, operator.value, right, operator.line, operator.column)
        return expr

    def _and(self):
        expr = self._equality()
        while self._match("AND"):
            operator = self._previous()
            right = self._equality()
            expr = Binary(expr, operator.value, right, operator.line, operator.column)
        return expr

    def _equality(self):
        expr = self._comparison()
        while self._match("EQ", "NE"):
            operator = self._previous()
            right = self._comparison()
            expr = Binary(expr, operator.value, right, operator.line, operator.column)
        return expr

    def _comparison(self):
        expr = self._term()
        while self._match("LT", "LE", "GT", "GE"):
            operator = self._previous()
            right = self._term()
            expr = Binary(expr, operator.value, right, operator.line, operator.column)
        return expr

    def _term(self):
        expr = self._factor()
        while self._match("PLUS", "MINUS"):
            operator = self._previous()
            right = self._factor()
            expr = Binary(expr, operator.value, right, operator.line, operator.column)
        return expr

    def _factor(self):
        expr = self._unary()
        while self._match("STAR", "SLASH", "PERCENT"):
            operator = self._previous()
            right = self._unary()
            expr = Binary(expr, operator.value, right, operator.line, operator.column)
        return expr

    def _unary(self):
        if self._match("MINUS", "NOT"):
            operator = self._previous()
            right = self._unary()
            return Unary(operator.value, right, operator.line, operator.column)
        return self._call()

    def _call(self):
        expr = self._primary()

        while True:
            if self._match("LPAREN"):
                lparen = self._previous()
                arguments = []
                if not self._check("RPAREN"):
                    while True:
                        arguments.append(self._expression())
                        if not self._match("COMMA"):
                            break
                self._consume("RPAREN", "Expected ')' after arguments")
                expr = Call(expr, arguments, lparen.line, lparen.column)
                continue

            if self._match("LBRACKET"):
                lbracket = self._previous()
                index = self._expression()
                self._consume("RBRACKET", "Expected ']' after index")
                expr = Index(expr, index, lbracket.line, lbracket.column)
                continue

            break

        return expr

    def _primary(self):
        token = self._current_token()

        if self._match("NUMBER"):
            return Literal(token.value, token.line, token.column)
        if self._match("STRING"):
            return Literal(token.value, token.line, token.column)
        if self._match("TRUE"):
            return Literal(True, token.line, token.column)
        if self._match("FALSE"):
            return Literal(False, token.line, token.column)
        if self._match("NULL"):
            return Literal(None, token.line, token.column)
        if self._match("ASK"):
            return self._ask_expression_from_primary(token)
        if self._match("IDENT"):
            if token.value and token.value[0].isupper():
                return Literal(token.value, token.line, token.column)
            return Variable(token.value, token.line, token.column)
        if self._match("LPAREN"):
            expr = self._expression()
            self._consume("RPAREN", "Expected ')' after expression")
            return expr

        raise ParserError(f"Unexpected token {token.type}", token.line, token.column)

    def _ask_expression_from_primary(self, token: Token):
        parts = self._say_parts()
        return AskExpr(parts, token.line, token.column)

    def _tokens_to_parts(self, tokens: list[Token]):
        parts = []
        for token in tokens:
            if token.type == "STRING":
                parts.append(Literal(token.value, token.line, token.column))
            elif token.type == "NUMBER":
                parts.append(Literal(token.value, token.line, token.column))
            elif token.type == "TRUE":
                parts.append(Literal(True, token.line, token.column))
            elif token.type == "FALSE":
                parts.append(Literal(False, token.line, token.column))
            elif token.type == "NULL":
                parts.append(Literal(None, token.line, token.column))
            elif token.type == "IDENT":
                parts.append(Variable(token.value, token.line, token.column))
            elif token.type in {
                "COMMA",
                "PLUS",
                "MINUS",
                "STAR",
                "SLASH",
                "PERCENT",
                "EQ",
                "NE",
                "LT",
                "LE",
                "GT",
                "GE",
                "LPAREN",
                "RPAREN",
                "COLON",
            }:
                parts.append(Literal(token.value, token.line, token.column))
            else:
                parts.append(Literal(token.value, token.line, token.column))
        return parts

    def _skip_newlines(self) -> None:
        while self._match("NEWLINE"):
            pass

    def _match_optional_colon(self) -> None:
        self._match("COLON")

    def _match(self, *types: str) -> bool:
        for token_type in types:
            if self._check(token_type):
                self.current += 1
                return True
        return False

    def _check(self, *types: str) -> bool:
        if self._is_at_end():
            return "EOF" in types
        return self._current_token().type in types

    def _check_any(self, types: set[str]) -> bool:
        if self._is_at_end():
            return True
        return self._current_token().type in types

    def _consume(self, token_type: str, message: str) -> Token:
        if self._check(token_type):
            token = self._current_token()
            self.current += 1
            return token
        token = self._current_token()
        raise ParserError(message, token.line, token.column)

    def _current_token(self) -> Token:
        return self.tokens[self.current]

    def _peek(self) -> Token:
        if self.current + 1 >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[self.current + 1]

    def _previous(self) -> Token:
        return self.tokens[self.current - 1]

    def _is_at_end(self) -> bool:
        return self._current_token().type == "EOF"
