from dataclasses import dataclass
from typing import Any, List, Optional


@dataclass
class Program:
    statements: List[Any]


@dataclass
class Block:
    statements: List[Any]


@dataclass
class PrintStmt:
    value: Any
    line: int
    column: int


@dataclass
class SayStmt:
    parts: List[Any]
    line: int
    column: int


@dataclass
class RawValue:
    parts: List[Any]
    line: int
    column: int


@dataclass
class AskExpr:
    parts: List[Any]
    line: int
    column: int


@dataclass
class WindowStmt:
    title: Any
    line: int
    column: int


@dataclass
class LetStmt:
    name: str
    value: Any
    line: int
    column: int


@dataclass
class AssignStmt:
    name: str
    value: Any
    line: int
    column: int


@dataclass
class IfStmt:
    condition: Any
    then_branch: Block
    else_branch: Optional[Block]
    line: int
    column: int


@dataclass
class WhileStmt:
    condition: Any
    body: Block
    line: int
    column: int


@dataclass
class FuncDefStmt:
    name: str
    params: List[str]
    body: Block
    line: int
    column: int


@dataclass
class ReturnStmt:
    value: Any
    line: int
    column: int


@dataclass
class ExprStmt:
    value: Any
    line: int
    column: int


@dataclass
class Literal:
    value: Any
    line: int
    column: int


@dataclass
class Variable:
    name: str
    line: int
    column: int


@dataclass
class Unary:
    operator: str
    right: Any
    line: int
    column: int


@dataclass
class Binary:
    left: Any
    operator: str
    right: Any
    line: int
    column: int


@dataclass
class Call:
    callee: Any
    arguments: List[Any]
    line: int
    column: int


@dataclass
class Index:
    value: Any
    index: Any
    line: int
    column: int
