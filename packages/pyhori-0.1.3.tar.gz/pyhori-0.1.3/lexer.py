from __future__ import annotations

from typing import List

from errors import LexerError
from tokens import Token


class Lexer:
    KEYWORDS = {
        "let": "LET",
        "imp": "IMP",
        "set": "SET",
        "print": "PRINT",
        "say": "SAY",
        "ask": "ASK",
        "window": "WINDOW",
        "if": "IF",
        "else": "ELSE",
        "end": "END",
        "while": "WHILE",
        "loop": "LOOP",
        "func": "FUNC",
        "return": "RETURN",
        "and": "AND",
        "or": "OR",
        "not": "NOT",
        "true": "TRUE",
        "false": "FALSE",
        "null": "NULL",
    }

    def __init__(self, source: str, filename: str = "<stdin>"):
        self.source = source
        self.filename = filename
        self.length = len(source)
        self.index = 0
        self.line = 1
        self.column = 1

    def tokenize(self) -> List[Token]:
        tokens: List[Token] = []

        while not self._at_end():
            ch = self._current()

            if ch == "\ufeff":
                self._advance()
                continue

            if ch in " \t\r":
                self._advance()
                continue

            if ch == "\n":
                tokens.append(self._make_token("NEWLINE", "\n"))
                self._advance_line()
                continue

            if ch == "#":
                self._skip_comment()
                continue

            if ch.isdigit():
                tokens.append(self._number())
                continue

            if ch.isalpha() or ch == "_":
                tokens.append(self._identifier())
                continue

            if ch == '"' or ch == "'":
                tokens.append(self._string())
                continue

            tokens.append(self._operator_or_punctuation())

        tokens.append(Token("EOF", None, self.line, self.column))
        return tokens

    def _at_end(self) -> bool:
        return self.index >= self.length

    def _current(self) -> str:
        return self.source[self.index]

    def _peek(self, offset: int = 1) -> str:
        position = self.index + offset
        if position >= self.length:
            return "\0"
        return self.source[position]

    def _advance(self) -> str:
        ch = self.source[self.index]
        self.index += 1
        self.column += 1
        return ch

    def _advance_line(self) -> None:
        self.index += 1
        self.line += 1
        self.column = 1

    def _make_token(self, token_type: str, value) -> Token:
        return Token(token_type, value, self.line, self.column)

    def _skip_comment(self) -> None:
        while not self._at_end() and self._current() != "\n":
            self._advance()

    def _number(self) -> Token:
        start_line = self.line
        start_column = self.column
        text = []
        has_dot = False

        while not self._at_end():
            ch = self._current()
            if ch.isdigit():
                text.append(self._advance())
            elif ch == "." and not has_dot and self._peek().isdigit():
                has_dot = True
                text.append(self._advance())
            else:
                break

        number_text = "".join(text)
        value = float(number_text) if has_dot else int(number_text)
        return Token("NUMBER", value, start_line, start_column)

    def _identifier(self) -> Token:
        start_line = self.line
        start_column = self.column
        text = []

        while not self._at_end():
            ch = self._current()
            if ch.isalnum() or ch == "_":
                text.append(self._advance())
            else:
                break

        word = "".join(text)
        token_type = self.KEYWORDS.get(word, "IDENT")
        value = word if token_type == "IDENT" else word
        return Token(token_type, value, start_line, start_column)

    def _string(self) -> Token:
        quote = self._current()
        start_line = self.line
        start_column = self.column
        self._advance()

        chars = []
        while not self._at_end():
            ch = self._current()
            if ch == quote:
                self._advance()
                return Token("STRING", "".join(chars), start_line, start_column)
            if ch == "\\":
                self._advance()
                if self._at_end():
                    break
                escaped = self._current()
                escapes = {
                    "n": "\n",
                    "r": "\r",
                    "t": "\t",
                    "\\": "\\",
                    '"': '"',
                    "'": "'",
                }
                chars.append(escapes.get(escaped, escaped))
                self._advance()
                continue
            if ch == "\n":
                raise LexerError("Unterminated string literal", start_line, start_column)
            chars.append(self._advance())

        raise LexerError("Unterminated string literal", start_line, start_column)

    def _operator_or_punctuation(self) -> Token:
        ch = self._current()
        start_line = self.line
        start_column = self.column

        two_char_tokens = {
            "==": "EQ",
            "!=": "NE",
            "<=": "LE",
            ">=": "GE",
        }
        candidate = ch + self._peek()
        if candidate in two_char_tokens:
            self._advance()
            self._advance()
            return Token(two_char_tokens[candidate], candidate, start_line, start_column)

        single_char_tokens = {
            "+": "PLUS",
            "-": "MINUS",
            "*": "STAR",
            "/": "SLASH",
            "%": "PERCENT",
            "=": "ASSIGN",
            "<": "LT",
            ">": "GT",
            "(": "LPAREN",
            ")": "RPAREN",
            "[": "LBRACKET",
            "]": "RBRACKET",
            ",": "COMMA",
            ":": "COLON",
            ".": "DOT",
        }

        if ch in single_char_tokens:
            self._advance()
            return Token(single_char_tokens[ch], ch, start_line, start_column)

        raise LexerError(f"Unexpected character {ch!r}", start_line, start_column)
