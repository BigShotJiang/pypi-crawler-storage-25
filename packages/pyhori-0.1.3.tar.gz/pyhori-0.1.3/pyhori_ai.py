from __future__ import annotations

import json


AI_MANIFEST = {
    "project": {
        "name": "pyhori",
        "language": "PyHorizon",
        "extension": ".pyh",
    },
    "capabilities": [
        "variables",
        "math",
        "if_else",
        "loops",
        "functions",
        "gui_window",
        "http_requests",
        "json",
        "command_execution",
    ],
    "builtins": [
        "http_get(url)",
        "http_post(url, body)",
        "http_post_headers(url, body, headers_json)",
        "json_parse(text)",
        "json_stringify(value)",
        "sleep(seconds)",
        "run_cmd(command)",
        "to_text(value)",
    ],
    "examples": {
        "json_access": 'imp data = json_parse("{\\"ok\\": true, \\"n\\": 3}")',
        "index_access": 'imp value = data["n"]',
        "http_bot": "telegram_send.pyh",
        "ai_api": "ait.pyh",
    },
    "ai_notes": [
        "Use json_parse for API responses.",
        "Use http_post_headers when an Authorization header is needed.",
        "Handle HTTP 429 as rate limit or missing quota.",
    ],
}


def as_json() -> str:
    return json.dumps(AI_MANIFEST, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    print(as_json())

