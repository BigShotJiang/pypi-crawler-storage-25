# PyHorizon

PyHorizon is a tiny custom programming language written in Python. Program files use the `.pyh` extension and are executed by `pyhori`.

## Project Structure

- `main.py` - command-line entry point. Reads a `.pyh` file and runs it.
- `lexer.py` - converts source code into tokens.
- `parser.py` - turns tokens into an abstract syntax tree.
- `ast_nodes.py` - AST node definitions.
- `interpreter.py` - executes the AST.
- `environment.py` - variable scope handling.
- `errors.py` - readable lexer, parser, and runtime errors.
- `tokens.py` - token data model.
- `example.pyh` - sample program in the language.
- `calculator.pyh` - interactive calculator app written in PyHorizon.
- `app.pyh` - GUI app that opens a window.
- `telegram_send.pyh` - Telegram Bot API example.
- `ai_request.pyh` - AI HTTP request example.
- `ai_starter.pyh` - AI starter template.
- `pyhori_ai.py` - machine-readable AI manifest.

## Syntax

Supported commands:

- `say "Hello"`
- `say Hello world name`
- `imp x = 10`
- `x = x + 1`
- `if x > 5 ... else ... end`
- `loop x < 10 ... end`
- `func add(a, b) ... end`
- `return value`
- `# comment`

In `say`, plain words without quotes are treated as text, and variables are inserted automatically. Example:

```pyh
imp name = Gh
say Hello name
```

`ask` reads user input and automatically converts numbers and booleans when possible:

```pyh
imp value = ask Введи число
```

Built-ins for bots and AI:

- `http_get(url)`
- `http_post(url, body)`
- `http_post_headers(url, body, headers_json)`
- `json_parse(text)`
- `json_stringify(value)`
- `sleep(seconds)`
- `run_cmd(command)`
- `to_text(value)`

JSON data can be accessed with brackets:

```pyh
imp data = json_parse("{\"ok\": true, \"n\": 3}")
imp value = data["n"]
say value
```

## How It Works

1. The lexer reads text from a `.pyh` file and turns it into tokens.
2. The parser builds a structured tree of statements and expressions.
3. The interpreter walks that tree and executes the program.

## Run

### Install

From PyPI:

```bash
pip install pyhori
```

From local source:

```bash
pip install .
```

### Windows

```powershell
pyhori example.pyh
```

### Linux

```bash
pyhori example.pyh
```

### Termux

```bash
pkg install python
pip install .
pyhori example.pyh
```

You can also run your own file:

```bash
pyhori program.pyh
```

Run the included app:

```bash
pyhori calculator.pyh
```

Open the GUI app:

```bash
pyhori app.pyh
```

Run the Telegram example:

```bash
pyhori telegram_send.pyh
```

Run the AI example:

```bash
pyhori ai_request.pyh
```

Run the AI starter template:

```bash
pyhori ai_starter.pyh
```

Print the machine-readable AI manifest:

```bash
python pyhori_ai.py
```

Show the version:

```bash
pyhori --version
```
