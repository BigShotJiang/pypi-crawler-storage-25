from __future__ import annotations

from dataclasses import dataclass
import json
import re
import subprocess
import time
import urllib.error
import urllib.request
import tkinter as tk
from tkinter import simpledialog

from ast_nodes import (
    AssignStmt,
    AskExpr,
    Binary,
    Block,
    Call,
    ExprStmt,
    FuncDefStmt,
    IfStmt,
    LetStmt,
    Literal,
    PrintStmt,
    RawValue,
    SayStmt,
    Program,
    ReturnStmt,
    Index,
    WindowStmt,
    Unary,
    Variable,
    WhileStmt,
)
from environment import Environment
from errors import PyHorizonRuntimeError


class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value


@dataclass
class FunctionValue:
    name: str
    params: list[str]
    body: Block
    closure: Environment

    def call(self, interpreter: "Interpreter", arguments: list[object]):
        if len(arguments) != len(self.params):
            raise PyHorizonRuntimeError(
                f"Function '{self.name}' expects {len(self.params)} arguments, got {len(arguments)}"
            )

        local_env = Environment(self.closure)
        for param, value in zip(self.params, arguments):
            local_env.define(param, value)

        try:
            interpreter.execute_block(self.body.statements, local_env)
        except ReturnSignal as signal:
            return signal.value

        return None

    def __str__(self) -> str:
        return f"<func {self.name}>"

    __repr__ = __str__


@dataclass
class BuiltinFunction:
    name: str
    arity: int | None
    handler: object
    description: str = ""

    def call(self, interpreter: "Interpreter", arguments: list[object]):
        if self.arity is not None and len(arguments) != self.arity:
            raise PyHorizonRuntimeError(
                f"Function '{self.name}' expects {self.arity} arguments, got {len(arguments)}"
            )
        return self.handler(interpreter, *arguments)

    def __str__(self) -> str:
        return f"<builtin {self.name}>"

    __repr__ = __str__


class Interpreter:
    def __init__(self):
        self.globals = Environment()
        self.environment = self.globals
        self.gui_root: tk.Tk | None = None
        self.gui_text: tk.Text | None = None
        self.gui_enabled = False
        self._install_builtins()

    def execute(self, program: Program) -> None:
        try:
            for statement in program.statements:
                self._execute_statement(statement)
        except ReturnSignal:
            raise PyHorizonRuntimeError("Return used outside of a function")

    def execute_block(self, statements: list, environment: Environment) -> None:
        previous = self.environment
        self.environment = environment
        try:
            for statement in statements:
                self._execute_statement(statement)
        finally:
            self.environment = previous

    def _execute_statement(self, statement) -> None:
        if isinstance(statement, PrintStmt):
            value = self._evaluate(statement.value)
            print(value)
            return

        if isinstance(statement, SayStmt):
            values = [self._evaluate_say_part(part) for part in statement.parts]
            self._emit(self._format_say(" ".join(values)))
            return

        if isinstance(statement, WindowStmt):
            self._open_window(self._evaluate(statement.title))
            return

        if isinstance(statement, LetStmt):
            value = self._evaluate(statement.value)
            self.environment.define(statement.name, value)
            return

        if isinstance(statement, AssignStmt):
            value = self._evaluate(statement.value)
            self.environment.assign(statement.name, value, statement.line, statement.column)
            return

        if isinstance(statement, IfStmt):
            if self._is_truthy(self._evaluate(statement.condition)):
                self.execute_block(statement.then_branch.statements, Environment(self.environment))
            elif statement.else_branch is not None:
                self.execute_block(statement.else_branch.statements, Environment(self.environment))
            return

        if isinstance(statement, WhileStmt):
            while self._is_truthy(self._evaluate(statement.condition)):
                self.execute_block(statement.body.statements, Environment(self.environment))
            return

        if isinstance(statement, FuncDefStmt):
            function = FunctionValue(statement.name, statement.params, statement.body, self.environment)
            self.environment.define(statement.name, function)
            return

        if isinstance(statement, ReturnStmt):
            value = self._evaluate(statement.value) if statement.value is not None else None
            raise ReturnSignal(value)

        if isinstance(statement, ExprStmt):
            self._evaluate(statement.value)
            return

        raise PyHorizonRuntimeError(f"Unknown statement type: {type(statement).__name__}")

    def _evaluate(self, expr):
        if isinstance(expr, Literal):
            return expr.value

        if isinstance(expr, RawValue):
            return self._evaluate_raw_value(expr.parts)

        if isinstance(expr, AskExpr):
            prompt = " ".join(self._render_prompt_part(part) for part in expr.parts).strip()
            raw = self._ask_input(prompt)
            return self._coerce_input(raw)

        if isinstance(expr, Variable):
            return self.environment.get(expr.name, expr.line, expr.column)

        if isinstance(expr, Unary):
            right = self._evaluate(expr.right)
            if expr.operator == "-":
                self._require_number(right, expr.line, expr.column)
                return -right
            if expr.operator == "not":
                return not self._is_truthy(right)
            raise PyHorizonRuntimeError(f"Unknown unary operator '{expr.operator}'", expr.line, expr.column)

        if isinstance(expr, Binary):
            if expr.operator == "and":
                left = self._evaluate(expr.left)
                if not self._is_truthy(left):
                    return False
                return self._is_truthy(self._evaluate(expr.right))

            if expr.operator == "or":
                left = self._evaluate(expr.left)
                if self._is_truthy(left):
                    return True
                return self._is_truthy(self._evaluate(expr.right))

            left = self._evaluate(expr.left)
            right = self._evaluate(expr.right)

            if expr.operator == "+":
                if isinstance(left, str) or isinstance(right, str):
                    return f"{left}{right}"
                self._require_number(left, expr.line, expr.column)
                self._require_number(right, expr.line, expr.column)
                return left + right

            if expr.operator == "-":
                self._require_number(left, expr.line, expr.column)
                self._require_number(right, expr.line, expr.column)
                return left - right

            if expr.operator == "*":
                self._require_number(left, expr.line, expr.column)
                self._require_number(right, expr.line, expr.column)
                return left * right

            if expr.operator == "/":
                self._require_number(left, expr.line, expr.column)
                self._require_number(right, expr.line, expr.column)
                if right == 0:
                    raise PyHorizonRuntimeError("Division by zero", expr.line, expr.column)
                return left / right

            if expr.operator == "%":
                self._require_number(left, expr.line, expr.column)
                self._require_number(right, expr.line, expr.column)
                if right == 0:
                    raise PyHorizonRuntimeError("Modulo by zero", expr.line, expr.column)
                return left % right

            if expr.operator == "==":
                return left == right

            if expr.operator == "!=":
                return left != right

            if expr.operator == "<":
                return left < right

            if expr.operator == "<=":
                return left <= right

            if expr.operator == ">":
                return left > right

            if expr.operator == ">=":
                return left >= right

            raise PyHorizonRuntimeError(f"Unknown binary operator '{expr.operator}'", expr.line, expr.column)

        if isinstance(expr, Call):
            callee = self._evaluate(expr.callee)
            arguments = [self._evaluate(argument) for argument in expr.arguments]
            if not hasattr(callee, "call"):
                raise PyHorizonRuntimeError("Only user-defined functions can be called", expr.line, expr.column)
            return callee.call(self, arguments)

        if isinstance(expr, Index):
            value = self._evaluate(expr.value)
            key = self._evaluate(expr.index)
            try:
                return value[key]
            except (KeyError, IndexError, TypeError):
                raise PyHorizonRuntimeError("Invalid index access", expr.line, expr.column)

        raise PyHorizonRuntimeError(f"Unknown expression type: {type(expr).__name__}")

    def _evaluate_say_part(self, expr) -> str:
        if isinstance(expr, Literal):
            return str(expr.value)

        if isinstance(expr, Variable):
            try:
                return str(self.environment.get(expr.name, expr.line, expr.column))
            except PyHorizonRuntimeError:
                return expr.name

        return str(self._evaluate(expr))

    def _emit(self, text: str) -> None:
        if self.gui_enabled and self.gui_text is not None and self.gui_root is not None:
            self.gui_text.insert("end", text + "\n")
            self.gui_text.see("end")
            self.gui_root.update_idletasks()
            return
        print(text)

    def _format_say(self, text: str) -> str:
        text = re.sub(r"\s+([,.;:!?])", r"\1", text)
        text = re.sub(r"\(\s+", "(", text)
        text = re.sub(r"\s+\)", ")", text)
        text = re.sub(r"\s{2,}", " ", text)
        return text.strip()

    def _ask_input(self, prompt: str) -> str:
        if self.gui_enabled and self.gui_root is not None:
            return simpledialog.askstring("Input", prompt, parent=self.gui_root) or ""
        if prompt:
            prompt = prompt + " "
        try:
            return input(prompt)
        except EOFError:
            return ""

    def _open_window(self, title: object) -> None:
        if self.gui_enabled:
            return

        self.gui_enabled = True
        self.gui_root = tk.Tk()
        self.gui_root.title(str(title))
        self.gui_root.geometry("560x380")
        self.gui_root.configure(bg="#111827")

        header = tk.Label(
            self.gui_root,
            text=str(title),
            fg="#f9fafb",
            bg="#111827",
            font=("Segoe UI", 18, "bold"),
            pady=14,
        )
        header.pack()

        frame = tk.Frame(self.gui_root, bg="#111827")
        frame.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        self.gui_text = tk.Text(
            frame,
            wrap="word",
            height=12,
            bg="#0f172a",
            fg="#e5e7eb",
            insertbackground="#e5e7eb",
            relief="flat",
            font=("Consolas", 11),
        )
        self.gui_text.pack(fill="both", expand=True)

    def run_gui(self) -> None:
        if self.gui_root is not None:
            self.gui_root.mainloop()

    def _evaluate_raw_value(self, parts: list) -> object:
        if len(parts) == 1:
            part = parts[0]
            if isinstance(part, Literal):
                return part.value
            if isinstance(part, Variable):
                try:
                    return self.environment.get(part.name, part.line, part.column)
                except PyHorizonRuntimeError:
                    return part.name

        values = []
        for part in parts:
            if isinstance(part, Literal):
                values.append(str(part.value))
                continue
            if isinstance(part, Variable):
                try:
                    values.append(str(self.environment.get(part.name, part.line, part.column)))
                except PyHorizonRuntimeError:
                    values.append(part.name)
                continue
            values.append(str(self._evaluate(part)))

        return " ".join(values)

    def _render_prompt_part(self, expr) -> str:
        if isinstance(expr, Literal):
            return str(expr.value)
        if isinstance(expr, Variable):
            try:
                return str(self.environment.get(expr.name, expr.line, expr.column))
            except PyHorizonRuntimeError:
                return expr.name
        return str(self._evaluate(expr))

    def _coerce_input(self, raw: str) -> object:
        text = raw.strip()
        if text == "":
            return ""

        lowered = text.lower()
        if lowered == "true":
            return True
        if lowered == "false":
            return False
        if lowered == "null":
            return None

        if self._looks_like_number(text):
            if "." in text:
                return float(text)
            return int(text)

        return text

    def _looks_like_number(self, text: str) -> bool:
        if text.startswith(("+", "-")):
            text = text[1:]
        if not text:
            return False
        if text.count(".") > 1:
            return False
        if "." in text:
            left, right = text.split(".", 1)
            return left.isdigit() and right.isdigit()
        return text.isdigit()

    def _is_truthy(self, value: object) -> bool:
        return bool(value)

    def _require_number(self, value: object, line: int, column: int) -> None:
        if not isinstance(value, (int, float)):
            raise PyHorizonRuntimeError("Expected a number", line, column)

    def _install_builtins(self) -> None:
        self.globals.define("http_get", BuiltinFunction("http_get", 1, self._builtin_http_get))
        self.globals.define("http_post", BuiltinFunction("http_post", 2, self._builtin_http_post))
        self.globals.define("http_post_headers", BuiltinFunction("http_post_headers", 3, self._builtin_http_post_headers))
        self.globals.define("json_parse", BuiltinFunction("json_parse", 1, self._builtin_json_parse))
        self.globals.define("json_stringify", BuiltinFunction("json_stringify", 1, self._builtin_json_stringify))
        self.globals.define("sleep", BuiltinFunction("sleep", 1, self._builtin_sleep))
        self.globals.define("run_cmd", BuiltinFunction("run_cmd", 1, self._builtin_run_cmd))
        self.globals.define("to_text", BuiltinFunction("to_text", 1, self._builtin_to_text))

    def _builtin_http_get(self, _interpreter: "Interpreter", url: object) -> str:
        request = urllib.request.Request(str(url), method="GET")
        return self._request_with_retry(request, "GET")

    def _builtin_http_post(self, _interpreter: "Interpreter", url: object, body: object) -> str:
        data = str(body).encode("utf-8")
        request = urllib.request.Request(str(url), data=data, method="POST")
        request.add_header("Content-Type", "application/json; charset=utf-8")
        return self._request_with_retry(request, "POST")

    def _builtin_http_post_headers(
        self,
        _interpreter: "Interpreter",
        url: object,
        body: object,
        headers_json: object,
    ) -> str:
        data = str(body).encode("utf-8")
        request = urllib.request.Request(str(url), data=data, method="POST")
        request.add_header("Content-Type", "application/json; charset=utf-8")

        try:
            headers = json.loads(str(headers_json)) if str(headers_json).strip() else {}
        except json.JSONDecodeError as error:
            raise PyHorizonRuntimeError(f"Invalid headers JSON: {error.msg}")

        for key, value in headers.items():
            request.add_header(str(key), str(value))

        return self._request_with_retry(request, "POST")

    def _builtin_json_parse(self, _interpreter: "Interpreter", value: object) -> object:
        try:
            return json.loads(str(value))
        except json.JSONDecodeError as error:
            raise PyHorizonRuntimeError(f"Invalid JSON: {error.msg}")

    def _builtin_json_stringify(self, _interpreter: "Interpreter", value: object) -> str:
        return json.dumps(value, ensure_ascii=False)

    def _builtin_sleep(self, _interpreter: "Interpreter", seconds: object) -> None:
        self._require_number(seconds, 0, 0)
        time.sleep(float(seconds))

    def _builtin_run_cmd(self, _interpreter: "Interpreter", command: object) -> str:
        result = subprocess.run(
            str(command),
            shell=True,
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise PyHorizonRuntimeError(result.stderr.strip() or "Command failed")
        return result.stdout

    def _builtin_to_text(self, _interpreter: "Interpreter", value: object) -> str:
        return str(value)

    def _request_with_retry(self, request: urllib.request.Request, method: str) -> str:
        attempts = 3
        last_error = None

        for attempt in range(1, attempts + 1):
            try:
                with urllib.request.urlopen(request) as response:
                    return response.read().decode("utf-8", errors="replace")
            except urllib.error.HTTPError as error:
                body = error.read().decode("utf-8", errors="replace") if error.fp else ""
                if error.code == 429 and attempt < attempts:
                    time.sleep(2 * attempt)
                    last_error = body or str(error)
                    continue
                if error.code == 429:
                    message = "HTTP 429: Too Many Requests. The API rate limit or quota was exceeded."
                    if body:
                        message = f"{message} Server said: {body}"
                    raise PyHorizonRuntimeError(message)
                message = f"HTTP {error.code} during {method}"
                if body:
                    message = f"{message}. Server said: {body}"
                raise PyHorizonRuntimeError(message)
            except urllib.error.URLError as error:
                last_error = str(error)
                if attempt < attempts:
                    time.sleep(2 * attempt)
                    continue
                raise PyHorizonRuntimeError(f"HTTP {method} failed: {error}")

        raise PyHorizonRuntimeError(f"HTTP {method} failed: {last_error or 'unknown error'}")
