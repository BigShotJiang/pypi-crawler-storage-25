from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Token:
    type: str
    value: Any
    line: int
    column: int

    def __repr__(self) -> str:
        return f"Token(type={self.type!r}, value={self.value!r}, line={self.line}, column={self.column})"

