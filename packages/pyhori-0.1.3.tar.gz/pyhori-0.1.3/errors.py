class PyHorizonError(Exception):
    def __init__(self, message: str, line: int | None = None, column: int | None = None):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(self.__str__())

    def __str__(self) -> str:
        if self.line is None:
            return self.message
        if self.column is None:
            return f"Line {self.line}: {self.message}"
        return f"Line {self.line}, column {self.column}: {self.message}"


class LexerError(PyHorizonError):
    pass


class ParserError(PyHorizonError):
    pass


class PyHorizonRuntimeError(PyHorizonError):
    pass

