"""Spot/Preemptible Instance Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SpotInstanceAgent(ShellAgent):
    """Agent for AWS Spot / GCP Preemptible / Azure Spot investigation."""

    COMMAND_PREFIX = ["aws"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "ec2 describe-spot-instance-requests",
        "ec2 describe-spot-price-history",
        "ec2 describe-spot-fleet-requests",
        "ec2 describe-spot-fleet-instances",
        "ec2 describe-instances",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "ec2 request-spot-instances",
        "ec2 cancel-spot-instance-requests",
        "ec2 modify-spot-fleet-request",
        "ec2 terminate-instances",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.instance_id = config.get("instance_id")
        self.region = config.get("region", "us-east-1")
        self.cloud = config.get("cloud", "aws")  # aws, gcp, azure
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.cloud == "aws":
            return ["aws", "--region", self.region]
        elif self.cloud == "gcp":
            return ["gcloud", "compute"]
        elif self.cloud == "azure":
            return ["az", "vm"]
        return ["aws", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are a Spot/Preemptible instance investigation agent.

Available tools:
- aws/gcloud/az: Execute read-only cloud CLI commands
- (cloud)_write: Execute write commands (requires approval)

Investigation approach:
1. Instance Status: Check current spot instance status
2. Price History: Review spot price trends
3. Interruption: Check for interruption notices
4. Fleet Status: Check spot fleet health
5. Capacity: Check availability zone capacity

Common issues:
- Interruptions: Instance terminated due to price/capacity
- Capacity unavailable: No spot capacity in AZ
- Price spikes: Spot price exceeded max price
- Fleet issues: Insufficient instance diversity

For AWS:
- Check metadata for termination notice: curl http://169.254.169.254/latest/meta-data/spot/termination-time
- Check price history: aws ec2 describe-spot-price-history"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "price" in q:
            return "I'll check spot price history.\n\nTOOL: aws ec2 describe-spot-price-history --instance-types t3.medium --product-descriptions 'Linux/UNIX' --max-items 20"
        if "interrupt" in q or "terminat" in q:
            return f"I'll check instance termination status.\n\nTOOL: aws ec2 describe-instances --instance-ids {self.instance_id} --query 'Reservations[].Instances[].State'"
        if "fleet" in q:
            return "I'll check spot fleet requests.\n\nTOOL: aws ec2 describe-spot-fleet-requests"
        if "status" in q or "request" in q:
            return "I'll check spot requests.\n\nTOOL: aws ec2 describe-spot-instance-requests"
        return "I'll check spot instances.\n\nTOOL: aws ec2 describe-spot-instance-requests --query 'SpotInstanceRequests[].{ID:SpotInstanceRequestId,Status:Status.Code,State:State}'"
