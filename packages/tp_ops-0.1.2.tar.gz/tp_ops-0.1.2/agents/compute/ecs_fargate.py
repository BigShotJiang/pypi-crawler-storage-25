"""ECS/Fargate Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ECSFargateAgent(ShellAgent):
    """Agent for AWS ECS/Fargate investigation."""

    COMMAND_PREFIX = ["aws", "ecs"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "list-clusters", "describe-clusters", "list-services", "describe-services",
        "list-tasks", "describe-tasks", "describe-task-definition",
        "list-container-instances", "describe-container-instances",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-cluster", "delete-cluster", "create-service", "delete-service",
        "update-service", "stop-task", "run-task", "start-task",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cluster = config.get("cluster")
        self.service = config.get("service")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "ecs", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are an ECS/Fargate investigation agent for cluster '{self.cluster}'.

Available tools:
- aws: Execute read-only AWS ECS commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Cluster Status: aws ecs describe-clusters --clusters {self.cluster}
2. Services: aws ecs describe-services --cluster {self.cluster} --services {self.service or '<service>'}
3. Tasks: aws ecs list-tasks --cluster {self.cluster}
4. Task Details: aws ecs describe-tasks --cluster {self.cluster} --tasks <task-arn>
5. Events: Check CloudWatch for ECS events

Common issues:
- Task failures: Check stopCode, stoppedReason
- Service instability: Check deployment status, desired vs running
- Capacity: Check container instance availability
- Load balancer health: Check target group health"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "service" in q:
            return f"I'll check service status.\n\nTOOL: aws ecs describe-services --cluster {self.cluster} --services {self.service}"
        if "task" in q:
            return f"I'll list running tasks.\n\nTOOL: aws ecs list-tasks --cluster {self.cluster}"
        if "fail" in q or "error" in q or "stop" in q:
            return f"I'll check for stopped tasks.\n\nTOOL: aws ecs list-tasks --cluster {self.cluster} --desired-status STOPPED"
        return f"I'll check cluster {self.cluster}.\n\nTOOL: aws ecs describe-clusters --clusters {self.cluster}"
