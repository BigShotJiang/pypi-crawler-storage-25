"""HashiCorp Nomad Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NomadAgent(ShellAgent):
    """Agent for HashiCorp Nomad investigation."""

    COMMAND_PREFIX = ["nomad"]
    TOOL_NAME = "nomad"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "status", "job status", "job inspect", "job history",
        "alloc status", "alloc logs",
        "node status", "node-status",
        "deployment status", "deployment list",
        "namespace list", "server members",
        "operator raft list-peers",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "job run", "job stop", "job revert", "job dispatch",
        "alloc stop", "alloc restart",
        "node drain", "node eligibility",
        "deployment promote", "deployment fail",
        "namespace apply", "namespace delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.job = config.get("job")
        self.namespace = config.get("namespace", "default")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["nomad", "-namespace", self.namespace]

    def _get_system_prompt(self) -> str:
        return f"""You are a HashiCorp Nomad investigation agent.

Available tools:
- nomad: Execute read-only Nomad commands
- nomad_write: Execute write commands (requires approval)

Investigation approach:
1. Cluster Status: nomad status
2. Job Status: nomad job status {self.job or '<job>'}
3. Allocations: nomad alloc status <alloc-id>
4. Logs: nomad alloc logs <alloc-id>
5. Node Status: nomad node status

Common issues:
- Job failures: Check allocation events, driver errors
- Scheduling: Check node eligibility, constraints
- Resource exhaustion: Check CPU/memory usage
- Driver issues: Docker, exec, java drivers"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "job" in q:
            return f"I'll check job status.\n\nTOOL: nomad job status {self.job or ''}"
        if "alloc" in q:
            return "I'll list allocations.\n\nTOOL: nomad status"
        if "node" in q:
            return "I'll check node status.\n\nTOOL: nomad node status"
        if "log" in q:
            return "I'll check allocation logs. Which allocation?\n\nTOOL: nomad status"
        return "I'll check Nomad cluster status.\n\nTOOL: nomad status"
