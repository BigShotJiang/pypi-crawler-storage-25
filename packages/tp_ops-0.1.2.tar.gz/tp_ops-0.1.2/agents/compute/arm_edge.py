"""ARM/Edge Compute Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ARMEdgeAgent(ShellAgent):
    """Agent for ARM/edge device investigation (Raspberry Pi, Jetson, etc.)."""

    COMMAND_PREFIX = ["ssh"]
    TOOL_NAME = "ssh"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        # System info
        "uname", "hostname", "uptime", "cat /proc/cpuinfo", "cat /proc/meminfo",
        "vcgencmd measure_temp", "vcgencmd get_throttled", "vcgencmd measure_clock",
        # Disk/Storage
        "df", "lsblk", "cat /sys/block/mmcblk0/device/life_time",  # SD card wear
        # Processes
        "ps", "top", "htop", "free",
        # Network
        "ip", "ifconfig", "iwconfig", "wpa_cli status",
        # Jetson specific
        "tegrastats", "nvpmodel -q", "jetson_clocks --show",
        # GPIO/Peripherals
        "gpio readall", "i2cdetect", "cat /sys/class/thermal/thermal_zone*/temp",
        # Logs
        "journalctl", "dmesg",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "reboot", "shutdown", "halt",
        "systemctl start", "systemctl stop", "systemctl restart",
        "dd", "mkfs", "fdisk",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host")
        self.user = config.get("user", "pi")
        self.device_type = config.get("device_type", "raspberry-pi")  # raspberry-pi, jetson, generic
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["ssh", f"{self.user}@{self.host}"]

    def _get_system_prompt(self) -> str:
        return f"""You are an ARM/edge device investigation agent for {self.host} ({self.device_type}).

Available tools:
- ssh: Execute read-only commands
- ssh_write: Execute write commands (requires approval)

Investigation approach:
1. Temperature: vcgencmd measure_temp (Pi) or cat /sys/class/thermal/thermal_zone*/temp
2. Throttling: vcgencmd get_throttled (Pi) - check for voltage/temp throttling
3. SD Card Health: cat /sys/block/mmcblk0/device/life_time
4. Memory: free -m
5. Processes: top -bn1

Common edge device issues:
- Thermal throttling: Poor cooling, high ambient temp
- SD card wear: High write activity, low quality card
- Power issues: Undervoltage (check throttled flag)
- Network: WiFi interference, power save issues
- Peripheral failures: I2C/SPI device issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "temp" in q or "thermal" in q or "hot" in q:
            return "I'll check temperature.\n\nTOOL: ssh vcgencmd measure_temp 2>/dev/null || cat /sys/class/thermal/thermal_zone*/temp"
        if "throttl" in q or "voltage" in q or "power" in q:
            return "I'll check throttling status.\n\nTOOL: ssh vcgencmd get_throttled"
        if "sd" in q or "storage" in q or "disk" in q:
            return "I'll check SD card health.\n\nTOOL: ssh df -h && cat /sys/block/mmcblk0/device/life_time 2>/dev/null"
        if "memory" in q:
            return "I'll check memory.\n\nTOOL: ssh free -m"
        if "network" in q or "wifi" in q:
            return "I'll check network.\n\nTOOL: ssh ip addr && iwconfig 2>/dev/null"
        return f"I'll check device health.\n\nTOOL: ssh uptime && free -m && df -h"
