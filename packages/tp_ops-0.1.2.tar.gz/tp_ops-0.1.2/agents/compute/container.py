"""Container Investigation Agent (Docker/Podman)."""

from typing import Any
from agents.base.shell import ShellAgent


class ContainerAgent(ShellAgent):
    """Agent for container investigation via Docker/Podman CLI."""

    COMMAND_PREFIX = ["docker"]
    TOOL_NAME = "docker"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "ps", "images", "logs", "inspect", "stats", "top", "port",
        "diff", "history", "events", "info", "version", "search",
        "network ls", "network inspect", "volume ls", "volume inspect",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "run", "start", "stop", "restart", "kill", "rm", "rmi",
        "pull", "push", "build", "exec", "commit", "tag",
        "network create", "network rm", "volume create", "volume rm",
        "system prune", "container prune", "image prune",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.container_id = config.get("container_id")
        self.runtime = config.get("runtime", "docker")  # docker or podman
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return [self.runtime]

    def _get_system_prompt(self) -> str:
        return f"""You are a container investigation agent for {self.container_id or 'all containers'}.

Available tools:
- docker: Execute read-only Docker/Podman commands
- docker_write: Execute write commands (requires approval)
- docker_json: Commands with JSON output

Investigation approach:
1. Container Status: docker ps -a
2. Resource Usage: docker stats --no-stream
3. Logs: docker logs --tail 100 <container>
4. Inspect: docker inspect <container>
5. Processes: docker top <container>

Common issues:
- OOMKill: Check memory limits and usage
- Restart loops: Check exit codes and logs
- Image pull failures: Check registry connectivity
- Network issues: Check network mode and connectivity

Always explain findings and suggest fixes."""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "log" in q:
            return f"I'll check container logs.\n\nTOOL: docker logs --tail 100 {self.container_id or '$(docker ps -q | head -1)'}"
        if "memory" in q or "oom" in q:
            return "I'll check memory usage.\n\nTOOL: docker stats --no-stream --format 'table {{.Name}}\\t{{.MemUsage}}\\t{{.MemPerc}}'"
        if "restart" in q or "crash" in q:
            return "I'll check container status and restart count.\n\nTOOL: docker ps -a --format 'table {{.Names}}\\t{{.Status}}\\t{{.State}}'"
        if "network" in q:
            return "I'll check container networking.\n\nTOOL: docker network ls && docker inspect --format='{{.NetworkSettings.Networks}}' $(docker ps -q | head -1)"
        return "I'll check all containers.\n\nTOOL: docker ps -a"
