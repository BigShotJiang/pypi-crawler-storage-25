"""Batch Compute Investigation Agent (AWS Batch, Azure Batch)."""

from typing import Any
from agents.base.shell import ShellAgent


class BatchComputeAgent(ShellAgent):
    """Agent for batch compute investigation."""

    COMMAND_PREFIX = ["aws", "batch"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "describe-compute-environments", "describe-job-queues",
        "describe-job-definitions", "describe-jobs", "list-jobs",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-compute-environment", "delete-compute-environment",
        "create-job-queue", "delete-job-queue",
        "submit-job", "cancel-job", "terminate-job",
        "register-job-definition", "deregister-job-definition",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.compute_environment = config.get("compute_environment")
        self.job_queue = config.get("job_queue")
        self.region = config.get("region", "us-east-1")
        self.cloud = config.get("cloud", "aws")  # aws or azure
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.cloud == "azure":
            return ["az", "batch"]
        return ["aws", "batch", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are a batch compute investigation agent.

Available tools:
- aws/az: Execute read-only batch commands
- (cloud)_write: Execute write commands (requires approval)

Investigation approach (AWS Batch):
1. Compute Environment: aws batch describe-compute-environments
2. Job Queues: aws batch describe-job-queues
3. Jobs: aws batch list-jobs --job-queue <queue> --job-status FAILED
4. Job Details: aws batch describe-jobs --jobs <job-id>

Common issues:
- Job failures: Check job logs in CloudWatch
- Queue bottlenecks: Check queue depth, priorities
- Compute environment: Check instance availability
- Resource limits: vCPU limits, memory constraints

For failed jobs:
1. Get job ID from failed jobs list
2. Describe job to get log stream name
3. Check CloudWatch logs for error details"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "fail" in q or "error" in q:
            return f"I'll check failed jobs.\n\nTOOL: aws batch list-jobs --job-queue {self.job_queue or 'default'} --job-status FAILED"
        if "queue" in q:
            return "I'll check job queues.\n\nTOOL: aws batch describe-job-queues"
        if "environment" in q or "compute" in q:
            return "I'll check compute environments.\n\nTOOL: aws batch describe-compute-environments"
        if "job" in q:
            return f"I'll list jobs.\n\nTOOL: aws batch list-jobs --job-queue {self.job_queue or 'default'}"
        return "I'll check batch status.\n\nTOOL: aws batch describe-compute-environments && aws batch describe-job-queues"
