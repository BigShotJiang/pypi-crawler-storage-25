"""Windows VM Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class WindowsVMAgent(ShellAgent):
    """Agent for Windows VM investigation via WinRM/SSH."""

    COMMAND_PREFIX = ["ssh"]  # Or winrm
    TOOL_NAME = "winrm"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "Get-Process", "Get-Service", "Get-EventLog", "Get-WmiObject",
        "Get-Counter", "Get-Disk", "Get-Volume", "Get-NetAdapter",
        "Get-NetTCPConnection", "Get-ChildItem", "Get-Content", "Get-Date",
        "Get-ComputerInfo", "Get-HotFix", "systeminfo", "tasklist", "netstat",
        "ipconfig", "hostname", "whoami", "dir", "type", "findstr",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "Stop-Process", "Stop-Service", "Start-Service", "Restart-Service",
        "Remove-Item", "Restart-Computer", "Stop-Computer", "Clear-EventLog",
        "Set-Service", "New-Item", "Copy-Item", "Move-Item",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host")
        self.user = config.get("user")
        self.password = config.get("password")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["ssh", f"{self.user}@{self.host}"] if self.user else ["ssh", self.host]

    def _get_system_prompt(self) -> str:
        return f"""You are a Windows systems investigation agent for {self.host}.

Available tools:
- winrm: Execute read-only PowerShell commands
- winrm_write: Execute write commands (requires approval)

Investigation approach:
1. System Resources: Get-Counter, Get-Process | Sort CPU -Descending
2. Services: Get-Service | Where Status -eq Stopped
3. Event Logs: Get-EventLog -LogName System -Newest 50 -EntryType Error
4. Disk: Get-Volume, Get-Disk
5. Network: Get-NetAdapter, Get-NetTCPConnection

Always explain findings and suggest remediation steps."""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "cpu" in q or "process" in q:
            return "I'll check CPU usage.\n\nTOOL: winrm Get-Process | Sort-Object CPU -Descending | Select-Object -First 20"
        if "memory" in q:
            return "I'll check memory usage.\n\nTOOL: winrm Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 20"
        if "disk" in q:
            return "I'll check disk usage.\n\nTOOL: winrm Get-Volume"
        if "service" in q:
            return "I'll check services.\n\nTOOL: winrm Get-Service | Where-Object {$_.Status -eq 'Stopped'}"
        if "event" in q or "log" in q or "error" in q:
            return "I'll check event logs.\n\nTOOL: winrm Get-EventLog -LogName System -Newest 50 -EntryType Error"
        return f"I'll help investigate this Windows VM ({self.host}).\n\nTOOL: winrm systeminfo"
