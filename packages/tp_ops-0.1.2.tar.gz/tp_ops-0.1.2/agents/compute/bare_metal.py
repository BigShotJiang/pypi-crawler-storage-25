"""Bare Metal Server Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class BareMetalAgent(ShellAgent):
    """Agent for bare metal server investigation via IPMI/SSH."""

    COMMAND_PREFIX = ["ssh"]
    TOOL_NAME = "ssh"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        # Hardware info
        "dmidecode", "lshw", "lscpu", "lsmem", "lspci", "lsusb", "lsscsi",
        # Sensors
        "sensors", "ipmitool sensor list", "ipmitool sdr list",
        "ipmitool sel list", "ipmitool chassis status",
        # RAID
        "megacli -LDInfo -Lall -aALL", "megacli -PDList -aALL",
        "ssacli ctrl all show config", "storcli /c0 show",
        "mdadm --detail", "cat /proc/mdstat",
        # Disk health
        "smartctl -a", "hdparm -I",
        # Network
        "ethtool", "ip link show", "lldpctl",
        # System
        "uptime", "free", "df", "top", "ps", "dmesg",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "ipmitool chassis power", "ipmitool mc reset",
        "megacli -AdpBbuCmd", "megacli -CfgLdDel",
        "mdadm --fail", "mdadm --remove",
        "reboot", "shutdown",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host")
        self.user = config.get("user", "root")
        self.ipmi_host = config.get("ipmi_host")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["ssh", f"{self.user}@{self.host}"]

    def _get_system_prompt(self) -> str:
        return f"""You are a bare metal server investigation agent for {self.host}.

Available tools:
- ssh: Execute read-only hardware/system commands
- ssh_write: Execute write commands (requires approval)

Investigation approach:
1. Hardware Sensors: sensors, ipmitool sensor list
2. IPMI Events: ipmitool sel list (System Event Log)
3. RAID Status: megacli or mdadm --detail
4. Disk Health: smartctl -a /dev/sda
5. Network: ethtool <interface>
6. Memory: dmidecode -t memory

Common hardware issues:
- Disk predictive failure: SMART warnings
- RAID degradation: Failed/missing drives
- Memory ECC errors: Check dmidecode and dmesg
- Fan failures: Check IPMI sensors
- NIC errors: Check ethtool counters
- Power supply: Check IPMI PSU status"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "sensor" in q or "temp" in q or "fan" in q:
            return "I'll check hardware sensors.\n\nTOOL: ssh sensors 2>/dev/null || ipmitool sensor list 2>/dev/null"
        if "raid" in q or "disk" in q or "storage" in q:
            return "I'll check RAID/disk status.\n\nTOOL: ssh cat /proc/mdstat 2>/dev/null && megacli -LDInfo -Lall -aALL 2>/dev/null || lsblk"
        if "smart" in q or "health" in q:
            return "I'll check disk SMART status.\n\nTOOL: ssh smartctl -a /dev/sda 2>/dev/null | head -50"
        if "memory" in q or "ecc" in q:
            return "I'll check memory.\n\nTOOL: ssh dmidecode -t memory | grep -E 'Size|Type|Speed|Error'"
        if "ipmi" in q or "event" in q or "sel" in q:
            return "I'll check IPMI event log.\n\nTOOL: ssh ipmitool sel list | tail -20"
        if "network" in q or "nic" in q:
            return "I'll check network interfaces.\n\nTOOL: ssh ip link show && ethtool eth0 2>/dev/null | head -20"
        return f"I'll check server health.\n\nTOOL: ssh uptime && sensors 2>/dev/null || echo 'sensors not available'"
