"""OpenStack Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class OpenStackAgent(ShellAgent):
    """Agent for OpenStack compute investigation."""

    COMMAND_PREFIX = ["openstack"]
    TOOL_NAME = "openstack"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "server list", "server show", "server event list",
        "flavor list", "flavor show",
        "image list", "image show",
        "network list", "network show", "port list",
        "volume list", "volume show",
        "hypervisor list", "hypervisor show",
        "compute service list", "availability zone list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "server create", "server delete", "server reboot", "server stop", "server start",
        "server resize", "server migrate", "server rebuild",
        "volume create", "volume delete", "volume attach", "volume detach",
        "image create", "image delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.server = config.get("server")
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["openstack"]

    def _get_system_prompt(self) -> str:
        return f"""You are an OpenStack investigation agent.

Available tools:
- openstack: Execute read-only OpenStack CLI commands
- openstack_write: Execute write commands (requires approval)

Investigation approach:
1. Server Status: openstack server show {self.server or '<server>'}
2. Server Events: openstack server event list {self.server or '<server>'}
3. Compute Services: openstack compute service list
4. Hypervisors: openstack hypervisor list

Common issues:
- Instance failures: Check Nova scheduling, events
- Network issues: Check Neutron ports, security groups
- Storage issues: Check Cinder volumes
- Quota issues: Check project quotas"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "server" in q or "instance" in q:
            return f"I'll check server status.\n\nTOOL: openstack server show {self.server} -f json" if self.server else "I'll list servers.\n\nTOOL: openstack server list -f json"
        if "network" in q:
            return "I'll check networks.\n\nTOOL: openstack network list -f json"
        if "volume" in q or "storage" in q:
            return "I'll check volumes.\n\nTOOL: openstack volume list -f json"
        if "hypervisor" in q or "compute" in q:
            return "I'll check hypervisors.\n\nTOOL: openstack hypervisor list -f json"
        return "I'll check OpenStack status.\n\nTOOL: openstack compute service list -f json"
