"""Kubernetes Node Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class KubernetesNodeAgent(ShellAgent):
    """Agent for Kubernetes node investigation."""

    COMMAND_PREFIX = ["kubectl"]
    TOOL_NAME = "kubectl"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "get", "describe", "logs", "top", "explain",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "cordon", "uncordon", "drain", "taint", "label", "delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.node_name = config.get("node")
        self.context = config.get("context")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["kubectl"]
        if self.context:
            prefix.extend(["--context", self.context])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Kubernetes node investigation agent for node '{self.node_name}'.

Available tools:
- kubectl: Execute read-only kubectl commands
- kubectl_write: Execute write commands (requires approval)

Investigation approach:
1. Node Status: kubectl describe node {self.node_name}
2. Node Conditions: Check Ready, MemoryPressure, DiskPressure, PIDPressure
3. Pods on Node: kubectl get pods --all-namespaces --field-selector spec.nodeName={self.node_name}
4. Resource Usage: kubectl top node {self.node_name}
5. Events: kubectl get events --field-selector involvedObject.name={self.node_name}

Common node issues:
- NotReady: kubelet issues, network problems
- MemoryPressure: Need to evict pods or add capacity
- DiskPressure: Clean up images/logs
- PIDPressure: Too many processes
- Taints preventing scheduling"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "status" in q or "health" in q or "condition" in q:
            return f"I'll check node status.\n\nTOOL: kubectl describe node {self.node_name} | grep -A 10 Conditions"
        if "pod" in q:
            return f"I'll check pods on this node.\n\nTOOL: kubectl get pods --all-namespaces --field-selector spec.nodeName={self.node_name}"
        if "resource" in q or "capacity" in q:
            return f"I'll check node resources.\n\nTOOL: kubectl top node {self.node_name}"
        if "taint" in q:
            return f"I'll check node taints.\n\nTOOL: kubectl describe node {self.node_name} | grep -A 5 Taints"
        return f"I'll check node {self.node_name}.\n\nTOOL: kubectl describe node {self.node_name}"
