"""GPU Instance Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GPUInstanceAgent(ShellAgent):
    """Agent for GPU instance/VM investigation."""

    COMMAND_PREFIX = ["ssh"]
    TOOL_NAME = "ssh"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "nvidia-smi", "nvtop", "gpustat",
        "nvidia-smi dmon", "nvidia-smi pmon",
        "nvidia-smi --query-gpu", "nvidia-smi --query-compute-apps",
        "rocm-smi",  # AMD
        "cuda-memcheck", "nvprof",
        "cat /proc/driver/nvidia/version",
        "dmesg | grep -i nvidia", "dmesg | grep -i gpu",
        "lspci | grep -i nvidia", "lspci | grep -i vga",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "nvidia-smi --gpu-reset", "nvidia-smi -pm",
        "kill", "reboot",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host")
        self.user = config.get("user")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.user:
            return ["ssh", f"{self.user}@{self.host}"]
        return ["ssh", self.host]

    def _get_system_prompt(self) -> str:
        return f"""You are a GPU instance investigation agent for {self.host}.

Available tools:
- ssh: Execute read-only GPU commands (nvidia-smi, nvtop, etc.)
- ssh_write: Execute write commands (requires approval)

Investigation approach:
1. GPU Status: nvidia-smi
2. GPU Processes: nvidia-smi pmon -s um -d 1 -c 5
3. Memory Usage: nvidia-smi --query-gpu=memory.used,memory.total --format=csv
4. Temperature: nvidia-smi --query-gpu=temperature.gpu --format=csv
5. Driver Info: nvidia-smi --query-gpu=driver_version --format=csv

Common issues:
- GPU memory overflow: OOM, memory fragmentation
- Thermal throttling: Check temperature, fan speed
- CUDA errors: Driver/toolkit version mismatch
- Underutilization: Check process binding
- Driver issues: Check dmesg for errors"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "memory" in q or "oom" in q:
            return "I'll check GPU memory usage.\n\nTOOL: ssh nvidia-smi --query-gpu=index,name,memory.used,memory.total,memory.free --format=csv"
        if "process" in q:
            return "I'll check GPU processes.\n\nTOOL: ssh nvidia-smi pmon -s um -d 1 -c 5"
        if "temp" in q or "thermal" in q or "hot" in q:
            return "I'll check GPU temperature.\n\nTOOL: ssh nvidia-smi --query-gpu=index,temperature.gpu,fan.speed,power.draw --format=csv"
        if "driver" in q or "cuda" in q:
            return "I'll check CUDA/driver version.\n\nTOOL: ssh nvidia-smi && nvcc --version 2>/dev/null || echo 'NVCC not found'"
        if "error" in q:
            return "I'll check for GPU errors.\n\nTOOL: ssh dmesg | grep -i -E 'nvidia|gpu|cuda' | tail -50"
        return "I'll check GPU status.\n\nTOOL: ssh nvidia-smi"
