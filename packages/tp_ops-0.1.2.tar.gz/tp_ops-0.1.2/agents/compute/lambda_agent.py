"""AWS Lambda Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class LambdaAgent(ShellAgent):
    """Agent for AWS Lambda function investigation."""

    COMMAND_PREFIX = ["aws", "lambda"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "list-functions", "get-function", "get-function-configuration",
        "list-versions-by-function", "list-aliases", "get-policy",
        "list-event-source-mappings", "get-account-settings",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-function", "delete-function", "update-function-code",
        "update-function-configuration", "publish-version", "invoke",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.function_name = config.get("function_name")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "lambda", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are an AWS Lambda investigation agent for function '{self.function_name}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Function Config: aws lambda get-function-configuration --function-name {self.function_name}
2. CloudWatch Logs: aws logs filter-log-events --log-group-name /aws/lambda/{self.function_name}
3. Metrics: Check invocations, errors, duration, throttles
4. Event Sources: aws lambda list-event-source-mappings

Common issues:
- Cold start latency: Check provisioned concurrency, memory, init time
- Timeout errors: Increase timeout, optimize code
- Memory limit: Increase memory allocation
- Throttling: Check reserved concurrency, account limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "config" in q:
            return f"I'll check function configuration.\n\nTOOL: aws lambda get-function-configuration --function-name {self.function_name}"
        if "error" in q or "log" in q:
            return f"I'll check recent errors in logs.\n\nTOOL: aws logs filter-log-events --log-group-name /aws/lambda/{self.function_name} --filter-pattern ERROR --limit 50"
        if "cold" in q or "latency" in q:
            return f"I'll check init duration.\n\nTOOL: aws lambda get-function-configuration --function-name {self.function_name}"
        if "throttl" in q:
            return "I'll check concurrency settings.\n\nTOOL: aws lambda get-function-concurrency --function-name {self.function_name}"
        return f"I'll check Lambda function {self.function_name}.\n\nTOOL: aws lambda get-function --function-name {self.function_name}"
