"""Google Cloud Functions Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GCPFunctionsAgent(ShellAgent):
    """Agent for Google Cloud Functions investigation."""

    COMMAND_PREFIX = ["gcloud", "functions"]
    TOOL_NAME = "gcloud"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "describe", "list", "logs read", "get-iam-policy",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "deploy", "delete", "call", "set-iam-policy",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.function_name = config.get("function_name")
        self.region = config.get("region", "us-central1")
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["gcloud", "functions"]
        if self.project:
            prefix.extend(["--project", self.project])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Google Cloud Functions investigation agent for '{self.function_name}'.

Available tools:
- gcloud: Execute read-only gcloud commands
- gcloud_write: Execute write commands (requires approval)

Investigation approach:
1. Function Details: gcloud functions describe {self.function_name} --region {self.region}
2. Logs: gcloud functions logs read {self.function_name} --region {self.region}
3. Errors: Filter logs for errors
4. Metrics: Check execution count, latency, errors

Common issues:
- Execution errors: Check logs, dependencies
- Resource limits: Memory, timeout settings
- Deployment failures: Check build logs"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "log" in q or "error" in q:
            return f"I'll check function logs.\n\nTOOL: gcloud functions logs read {self.function_name} --region {self.region} --limit 50"
        return f"I'll check function details.\n\nTOOL: gcloud functions describe {self.function_name} --region {self.region}"
