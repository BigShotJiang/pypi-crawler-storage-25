"""Docker Swarm Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class DockerSwarmAgent(ShellAgent):
    """Agent for Docker Swarm investigation."""

    COMMAND_PREFIX = ["docker"]
    TOOL_NAME = "docker"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "node ls", "node inspect", "node ps",
        "service ls", "service inspect", "service ps", "service logs",
        "stack ls", "stack services", "stack ps",
        "network ls", "network inspect",
        "secret ls", "config ls",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "node update", "node rm", "node promote", "node demote",
        "service create", "service update", "service rm", "service scale",
        "stack deploy", "stack rm",
        "secret create", "secret rm", "config create", "config rm",
        "swarm leave", "swarm init", "swarm join",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.stack = config.get("stack")
        self.service = config.get("service")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["docker"]

    def _get_system_prompt(self) -> str:
        return f"""You are a Docker Swarm investigation agent.

Available tools:
- docker: Execute read-only Swarm commands
- docker_write: Execute write commands (requires approval)

Investigation approach:
1. Node Status: docker node ls
2. Services: docker service ls
3. Service Details: docker service inspect <service>
4. Service Tasks: docker service ps <service>
5. Service Logs: docker service logs <service>
6. Stack Status: docker stack services <stack>

Common issues:
- Service failures: Check task status, replicas
- Node drain: Check node availability
- Overlay network: Check network connectivity
- Resource constraints: Check placement constraints"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "node" in q:
            return "I'll check Swarm nodes.\n\nTOOL: docker node ls"
        if "service" in q:
            return "I'll check services.\n\nTOOL: docker service ls"
        if "stack" in q:
            return f"I'll check stack services.\n\nTOOL: docker stack services {self.stack or '--help'}"
        if "log" in q:
            return f"I'll check service logs.\n\nTOOL: docker service logs {self.service or '--help'}"
        return "I'll check Swarm status.\n\nTOOL: docker node ls && docker service ls"
