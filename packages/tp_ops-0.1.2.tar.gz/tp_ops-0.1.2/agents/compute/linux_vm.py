"""Linux VM Investigation Agent.

Agent for investigating Linux VMs via SSH:
- CPU, memory, disk usage
- Process analysis (runaway, zombie, OOM)
- Service status (systemd)
- Log analysis (journalctl)
- Network diagnostics
"""

from typing import Any

from agents.base.shell import ShellAgent


class LinuxVMAgent(ShellAgent):
    """Agent for Linux VM investigation via SSH.

    Inherits from ShellAgent, providing:
    - ssh: Read-only commands
    - ssh_write: Write commands (requires approval)
    - ssh_json: Commands with JSON output parsing
    """

    # ShellAgent configuration
    COMMAND_PREFIX = ["ssh"]
    TOOL_NAME = "ssh"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    # Safe read-only commands
    SAFE_SUBCOMMANDS = [
        # System info
        "uname", "hostname", "uptime", "date", "who", "w", "id", "groups",
        # CPU/Memory
        "top", "htop", "free", "vmstat", "mpstat", "sar",
        # Disk
        "df", "du", "lsblk", "fdisk -l", "findmnt",
        # Processes
        "ps", "pgrep", "pstree", "lsof",
        # Network
        "ip", "ifconfig", "netstat", "ss", "route", "arp", "ping", "traceroute",
        "nslookup", "dig", "host", "curl", "wget",
        # Logs
        "journalctl", "dmesg", "tail", "head", "cat", "less", "more", "grep",
        "zcat", "zgrep",
        # Services
        "systemctl status", "systemctl list-units", "systemctl is-active",
        "service", "chkconfig",
        # Files
        "ls", "stat", "file", "find", "locate", "which", "whereis",
        # Performance
        "iostat", "iotop", "nmon", "perf", "strace",
        # Hardware
        "lscpu", "lsmem", "lspci", "lsusb", "dmidecode",
        # Other
        "env", "printenv", "crontab -l", "timedatectl",
    ]

    # Dangerous commands requiring approval
    DANGEROUS_SUBCOMMANDS = [
        # Process control
        "kill", "killall", "pkill",
        # System control
        "reboot", "shutdown", "poweroff", "halt", "init",
        # Service control
        "systemctl start", "systemctl stop", "systemctl restart",
        "systemctl enable", "systemctl disable", "systemctl reload",
        "service start", "service stop", "service restart",
        # File operations
        "rm", "rmdir", "mv", "cp", "chmod", "chown", "chgrp",
        "mkdir", "touch", "truncate",
        # Disk operations
        "mkfs", "fdisk", "parted", "mount", "umount", "fsck",
        # Package management
        "apt", "apt-get", "yum", "dnf", "pacman", "zypper",
        "pip", "npm", "gem",
        # User management
        "useradd", "userdel", "usermod", "passwd", "groupadd", "groupdel",
        # Network
        "iptables", "firewall-cmd", "ufw",
        # Other
        "dd", "crontab -e", "visudo",
    ]

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal,
        llm=None,
    ):
        """Initialize Linux VM Agent.

        Args:
            name: Agent name (typically the VM hostname)
            config: Configuration dict with:
                - host: SSH target (user@host or just host)
                - user: SSH user (optional, defaults to current user)
                - key_file: Path to SSH private key (optional)
                - port: SSH port (optional, defaults to 22)
            terminal: Terminal for output
            llm: Optional LLM client
        """
        self.host = config.get("host")
        self.user = config.get("user")
        self.key_file = config.get("key_file")
        self.port = config.get("port", 22)
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        """Build SSH command prefix with connection options."""
        prefix = ["ssh"]

        # Add SSH options
        prefix.extend(["-o", "ConnectTimeout=10"])
        prefix.extend(["-o", "BatchMode=yes"])
        prefix.extend(["-o", "StrictHostKeyChecking=accept-new"])

        # Add port if non-standard
        if self.port != 22:
            prefix.extend(["-p", str(self.port)])

        # Add key file if specified
        if self.key_file:
            prefix.extend(["-i", self.key_file])

        # Build target (user@host or just host)
        if self.user:
            target = f"{self.user}@{self.host}"
        else:
            target = self.host

        prefix.append(target)
        return prefix

    def _ensure_json_output(self, args: str) -> str:
        """Override - no standard JSON flag for shell commands.

        For Linux commands, we handle JSON differently per command.
        """
        # Some commands support JSON output
        if args.startswith("journalctl") and "-o json" not in args:
            return f"{args} -o json"
        if args.startswith("systemctl") and "-o json" not in args:
            return f"{args} -o json"
        if args.startswith("ip") and "-j" not in args:
            return f"{args} -j"
        return args

    def _get_system_prompt(self) -> str:
        """System prompt for Linux VM investigation."""
        return f"""You are a Linux systems investigation agent for {self.host}.

Available tools:
- ssh: Execute read-only commands (ps, top, df, journalctl, etc.)
- ssh_write: Execute write commands (requires human approval)
- ssh_json: Execute commands with JSON output parsing

Investigation approach:
1. **System Resources**: Check CPU (top -bn1), memory (free -m), disk (df -h)
2. **Processes**: Find resource hogs (ps aux --sort=-%cpu | head -20)
3. **Services**: Check systemd status (systemctl --failed)
4. **Logs**: Look for errors (journalctl -p err -n 50 --no-pager)
5. **Network**: Check connectivity (ss -tuln, ip addr)

Common issues to look for:
- High CPU: runaway processes, infinite loops, fork bombs
- High memory: memory leaks, OOM killer, swap thrashing
- Disk full: log rotation failure, large files, inode exhaustion
- Service failures: crashed daemons, dependency issues
- Network issues: DNS, firewall, interface down

Always explain what you find in plain English and suggest remediation steps.
For any write operation (kill process, restart service), explain why and use ssh_write."""

    def _mock_response(self, query: str) -> str:
        """Generate mock response for testing without SSH."""
        q = query.lower()

        if "cpu" in q or "process" in q or "slow" in q:
            return """I'll check CPU usage and running processes.

TOOL: ssh top -bn1 | head -20"""

        if "memory" in q or "ram" in q or "oom" in q:
            return """I'll check memory usage and look for memory pressure.

TOOL: ssh free -m && cat /proc/meminfo | grep -E 'MemTotal|MemFree|Buffers|Cached|SwapTotal|SwapFree'"""

        if "disk" in q or "space" in q or "full" in q:
            return """I'll check disk usage across all mounted filesystems.

TOOL: ssh df -h"""

        if "log" in q or "error" in q or "crash" in q:
            return """I'll check system logs for recent errors.

TOOL: ssh journalctl -p err -n 50 --no-pager"""

        if "service" in q or "systemd" in q or "daemon" in q:
            return """I'll check for failed services.

TOOL: ssh systemctl --failed"""

        if "network" in q or "connect" in q or "dns" in q:
            return """I'll check network configuration and connectivity.

TOOL: ssh ip addr && ss -tuln | head -20"""

        if "restart" in q or "kill" in q or "stop" in q:
            return """For service restarts or process termination, I'll need to use ssh_write which requires approval.

What service or process do you need me to manage?"""

        # Default response
        return f"""I'll help investigate this Linux VM ({self.host}).

Let me start with a quick health check.

TOOL: ssh uptime && free -m && df -h | head -10"""

    def _mock_continuation(self, tool_output: str) -> str:
        """Generate mock continuation based on tool output."""
        output_lower = tool_output.lower()

        # Detect various issues
        if "oom" in output_lower or "out of memory" in output_lower:
            return """I detected OOM (Out of Memory) events in the output.

This indicates the system ran out of memory and the OOM killer terminated processes.

**Root cause analysis:**
1. Check which processes were killed: `dmesg | grep -i "killed process"`
2. Look for memory-hungry processes: `ps aux --sort=-%mem | head -10`

**Recommendations:**
- Identify and optimize memory-heavy applications
- Consider adding swap space or increasing RAM
- Set appropriate memory limits for services

Would you like me to investigate which processes are using the most memory?"""

        if "100%" in tool_output or "no space left" in output_lower:
            return """I detected disk space issues - one or more filesystems are full or nearly full.

**Immediate actions needed:**
1. Find large files: `find / -type f -size +100M -exec ls -lh {} \\;`
2. Check log directory: `du -sh /var/log/*`
3. Clean package cache: `apt clean` or `yum clean all`

**Common culprits:**
- Old log files not being rotated
- Docker images/containers
- Core dumps
- Temporary files in /tmp

Would you like me to find the largest files on the system?"""

        if "failed" in output_lower and "service" in output_lower:
            return """I found failed services on this system.

**Next steps:**
1. Check the specific service logs: `journalctl -u <service-name> -n 50`
2. Review service configuration
3. Check dependencies

Would you like me to investigate a specific failed service?"""

        if "load average" in output_lower:
            # Parse load average
            import re
            load_match = re.search(r'load average[:\s]+([0-9.]+)', output_lower)
            if load_match:
                load = float(load_match.group(1))
                if load > 4.0:
                    return f"""The load average ({load:.2f}) is elevated, indicating system stress.

**Investigation steps:**
1. Check CPU-intensive processes: `ps aux --sort=-%cpu | head -10`
2. Check I/O wait: `iostat -x 1 3`
3. Look for stuck processes: `ps aux | grep -E 'D|Z'`

Would you like me to identify what's causing the high load?"""

        if "connection refused" in output_lower or "no route" in output_lower:
            return """I detected network connectivity issues.

**Troubleshooting steps:**
1. Check if the service is running and listening
2. Verify firewall rules: `iptables -L -n`
3. Check DNS resolution: `nslookup <hostname>`
4. Trace the route: `traceroute <destination>`

What service or destination are you trying to reach?"""

        # Default - things look okay
        if any(word in output_lower for word in ["running", "active", "ok", "healthy"]):
            return """The output looks healthy. The system appears to be functioning normally.

Is there a specific issue you'd like me to investigate further?"""

        return """I've gathered the system information above.

Would you like me to:
1. Check specific processes or services
2. Look at logs for errors
3. Investigate network connectivity
4. Analyze resource usage trends

What would you like me to focus on?"""
