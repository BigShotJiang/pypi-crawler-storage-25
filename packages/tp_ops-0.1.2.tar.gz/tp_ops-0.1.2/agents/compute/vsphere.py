"""VMware vSphere Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class VSphereAgent(ShellAgent):
    """Agent for VMware vSphere investigation via govc."""

    COMMAND_PREFIX = ["govc"]
    TOOL_NAME = "govc"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "about", "ls", "find",
        "vm.info", "vm.guest.info", "vm.ip",
        "host.info", "host.storage.info",
        "datastore.info", "datastore.ls",
        "cluster.usage",
        "metric.ls", "metric.sample",
        "events", "tasks",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "vm.power", "vm.destroy", "vm.create", "vm.clone",
        "vm.migrate", "vm.register", "vm.unregister",
        "host.maintenance.enter", "host.maintenance.exit",
        "datastore.create", "datastore.rm",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.vcenter = config.get("vcenter")
        self.datacenter = config.get("datacenter")
        self.vm = config.get("vm")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["govc"]

    def _get_system_prompt(self) -> str:
        return f"""You are a VMware vSphere investigation agent.

Available tools:
- govc: Execute read-only govc commands
- govc_write: Execute write commands (requires approval)

Investigation approach:
1. VM Info: govc vm.info {self.vm or '<vm-name>'}
2. Host Info: govc host.info
3. Datastore: govc datastore.info
4. Events: govc events
5. Tasks: govc tasks

Common issues:
- VM performance: Check CPU/memory metrics
- Storage latency: Check datastore performance
- Network issues: Check port groups, vSwitch
- vMotion failures: Check compatibility, network"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "vm" in q:
            return f"I'll check VM info.\n\nTOOL: govc vm.info {self.vm or '*'}"
        if "host" in q:
            return "I'll check host info.\n\nTOOL: govc host.info"
        if "datastore" in q or "storage" in q:
            return "I'll check datastores.\n\nTOOL: govc datastore.info"
        if "event" in q:
            return "I'll check recent events.\n\nTOOL: govc events -n 50"
        return "I'll list resources.\n\nTOOL: govc ls"
