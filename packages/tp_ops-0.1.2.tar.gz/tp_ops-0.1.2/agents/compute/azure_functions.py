"""Azure Functions Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureFunctionsAgent(ShellAgent):
    """Agent for Azure Functions investigation."""

    COMMAND_PREFIX = ["az", "functionapp"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "show", "list", "config show", "function list", "function show",
        "deployment list", "log", "identity show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create", "delete", "restart", "start", "stop", "update",
        "config set", "deployment", "function delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.function_app = config.get("function_app")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["az", "functionapp"]

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Functions investigation agent for '{self.function_app}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. App Status: az functionapp show -n {self.function_app} -g {self.resource_group}
2. Functions List: az functionapp function list -n {self.function_app} -g {self.resource_group}
3. Logs: az monitor log-analytics query
4. Metrics: Check executions, failures, duration
5. Config: az functionapp config show

Common issues:
- Execution failures: Check bindings, dependencies
- Scaling issues: Check consumption plan limits
- Cold starts: Consider premium plan
- Memory issues: Monitor memory usage"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "status" in q:
            return f"I'll check function app status.\n\nTOOL: az functionapp show -n {self.function_app} -g {self.resource_group}"
        if "function" in q and "list" in q:
            return f"I'll list functions.\n\nTOOL: az functionapp function list -n {self.function_app} -g {self.resource_group}"
        if "error" in q or "fail" in q:
            return "I'll check Application Insights for errors.\n\nTOOL: az monitor app-insights query --apps {self.function_app} --analytics-query 'exceptions | take 50'"
        return f"I'll check Azure Function app {self.function_app}.\n\nTOOL: az functionapp show -n {self.function_app} -g {self.resource_group}"
