"""Proxmox VE Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ProxmoxAgent(ShellAgent):
    """Agent for Proxmox VE investigation."""

    COMMAND_PREFIX = ["pvesh"]
    TOOL_NAME = "pvesh"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "get", "ls",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create", "delete", "set", "post",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.node = config.get("node")
        self.vmid = config.get("vmid")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["pvesh"]

    def _get_system_prompt(self) -> str:
        return f"""You are a Proxmox VE investigation agent for node '{self.node}'.

Available tools:
- pvesh: Execute read-only Proxmox API commands
- pvesh_write: Execute write commands (requires approval)

Investigation approach:
1. Cluster Status: pvesh get /cluster/status
2. Node Status: pvesh get /nodes/{self.node}/status
3. VMs: pvesh get /nodes/{self.node}/qemu
4. Containers: pvesh get /nodes/{self.node}/lxc
5. Storage: pvesh get /nodes/{self.node}/storage

Common issues:
- VM/CT failures: Check status, logs
- Storage issues: Check space, health
- Cluster quorum: Check node connectivity
- Migration failures: Check network, storage access"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "vm" in q or "qemu" in q:
            return f"I'll check VMs.\n\nTOOL: pvesh get /nodes/{self.node}/qemu --output-format json"
        if "container" in q or "lxc" in q:
            return f"I'll check containers.\n\nTOOL: pvesh get /nodes/{self.node}/lxc --output-format json"
        if "storage" in q:
            return f"I'll check storage.\n\nTOOL: pvesh get /nodes/{self.node}/storage --output-format json"
        if "cluster" in q:
            return "I'll check cluster status.\n\nTOOL: pvesh get /cluster/status --output-format json"
        return f"I'll check node {self.node}.\n\nTOOL: pvesh get /nodes/{self.node}/status --output-format json"
