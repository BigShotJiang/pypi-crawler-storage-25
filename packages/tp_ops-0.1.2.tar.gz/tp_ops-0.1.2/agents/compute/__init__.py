"""Compute agents for VMs, containers, serverless, and orchestration."""

from agents.compute.linux_vm import LinuxVMAgent
from agents.compute.windows_vm import WindowsVMAgent
from agents.compute.container import ContainerAgent
from agents.compute.kubernetes_namespace import KubernetesNamespaceAgent
from agents.compute.kubernetes_node import KubernetesNodeAgent
from agents.compute.lambda_agent import LambdaAgent
from agents.compute.azure_functions import AzureFunctionsAgent
from agents.compute.gcp_functions import GCPFunctionsAgent
from agents.compute.ecs_fargate import ECSFargateAgent
from agents.compute.docker_swarm import DockerSwarmAgent
from agents.compute.nomad import NomadAgent
from agents.compute.proxmox import ProxmoxAgent
from agents.compute.vsphere import VSphereAgent
from agents.compute.openstack import OpenStackAgent
from agents.compute.gpu_instance import GPUInstanceAgent
from agents.compute.arm_edge import ARMEdgeAgent
from agents.compute.bare_metal import BareMetalAgent
from agents.compute.spot_instance import SpotInstanceAgent
from agents.compute.batch import BatchComputeAgent

__all__ = [
    "LinuxVMAgent",
    "WindowsVMAgent",
    "ContainerAgent",
    "KubernetesNamespaceAgent",
    "KubernetesNodeAgent",
    "LambdaAgent",
    "AzureFunctionsAgent",
    "GCPFunctionsAgent",
    "ECSFargateAgent",
    "DockerSwarmAgent",
    "NomadAgent",
    "ProxmoxAgent",
    "VSphereAgent",
    "OpenStackAgent",
    "GPUInstanceAgent",
    "ARMEdgeAgent",
    "BareMetalAgent",
    "SpotInstanceAgent",
    "BatchComputeAgent",
]
