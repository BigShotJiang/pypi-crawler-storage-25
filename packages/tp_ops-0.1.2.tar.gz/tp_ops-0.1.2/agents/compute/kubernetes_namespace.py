"""Kubernetes Namespace Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class KubernetesNamespaceAgent(ShellAgent):
    """Agent for Kubernetes namespace investigation."""

    COMMAND_PREFIX = ["kubectl"]
    TOOL_NAME = "kubectl"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "get", "describe", "logs", "top", "explain", "api-resources",
        "cluster-info", "config view", "auth can-i",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete", "apply", "create", "patch", "edit", "replace",
        "scale", "rollout", "cordon", "drain", "taint", "label",
        "exec", "port-forward", "cp",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace", "default")
        self.context = config.get("context")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["kubectl"]
        if self.context:
            prefix.extend(["--context", self.context])
        prefix.extend(["-n", self.namespace])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Kubernetes namespace investigation agent for namespace '{self.namespace}'.

Available tools:
- kubectl: Execute read-only kubectl commands
- kubectl_write: Execute write commands (requires approval)
- kubectl_json: Commands with JSON output (-o json)

Investigation approach:
1. Pod Status: kubectl get pods
2. Events: kubectl get events --sort-by='.lastTimestamp'
3. Pod Details: kubectl describe pod <name>
4. Logs: kubectl logs <pod> --tail=100
5. Resources: kubectl top pods

Common issues in namespace:
- CrashLoopBackOff: Check logs and resource limits
- ImagePullBackOff: Check image name and registry auth
- Pending pods: Check resource quotas and node capacity
- OOMKilled: Check memory limits

All commands are scoped to namespace '{self.namespace}'."""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "pod" in q and ("fail" in q or "crash" in q or "error" in q):
            return f"I'll check pod status in {self.namespace}.\n\nTOOL: kubectl get pods"
        if "event" in q:
            return f"I'll check recent events.\n\nTOOL: kubectl get events --sort-by='.lastTimestamp'"
        if "log" in q:
            return "I'll check pod logs. Which pod?\n\nTOOL: kubectl get pods"
        if "resource" in q or "quota" in q:
            return f"I'll check resource quotas.\n\nTOOL: kubectl describe resourcequota"
        return f"I'll check namespace {self.namespace}.\n\nTOOL: kubectl get all"
