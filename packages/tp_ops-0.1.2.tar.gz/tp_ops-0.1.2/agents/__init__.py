"""TernaryPhysics Ops Agents - AI agents for infrastructure resources."""
