"""Knowledge base for Kubernetes Agent patterns."""
