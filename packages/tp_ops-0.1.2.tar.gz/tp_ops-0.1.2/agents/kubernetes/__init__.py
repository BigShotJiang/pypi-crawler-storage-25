"""Kubernetes Agent for TernaryPhysics Ops."""

from agents.kubernetes.agent import KubernetesAgent

__all__ = ["KubernetesAgent"]
