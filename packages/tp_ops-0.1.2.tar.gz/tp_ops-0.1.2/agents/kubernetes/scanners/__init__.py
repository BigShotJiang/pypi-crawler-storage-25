"""Proactive scanners for Kubernetes Agent."""
