"""Kubernetes Chat Agent - conversational AI for K8s clusters.

This agent lives on your cluster. You talk to it. It investigates.
It uses kubectl to gather information and reasons about what it finds.
"""

import json
import subprocess
from typing import Any, Optional

from cli.output.terminal import Terminal
from agents.base.conversational import ConversationalAgent, ActionType


# Safe kubectl subcommands (read-only operations)
KUBECTL_SAFE_COMMANDS = [
    "get", "describe", "logs", "top", "explain",
    "api-resources", "api-versions", "cluster-info",
    "config view", "config get-contexts", "config current-context",
    "version", "auth can-i",
]

# Dangerous kubectl subcommands (require approval)
KUBECTL_DANGEROUS_COMMANDS = [
    "delete", "exec", "apply", "create", "patch", "replace",
    "edit", "scale", "rollout", "drain", "cordon", "uncordon",
    "taint", "label", "annotate", "set",
]


class KubernetesChatAgent(ConversationalAgent):
    """Conversational agent for Kubernetes clusters.

    You talk to this agent about your cluster. It:
    - Runs kubectl commands to investigate
    - Interprets the results
    - Explains what it finds
    - Recommends actions (requiring your approval)

    Security:
    - Read-only commands (get, describe, logs) run automatically
    - Write/delete commands require explicit user approval
    - Shell injection is blocked via argument sanitization
    """

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal: Terminal,
        llm: Optional[Any] = None,
    ):
        # Build kubectl command prefix
        self.kubectl_base = ["kubectl"]
        if config.get("kubeconfig"):
            self.kubectl_base.extend(["--kubeconfig", config["kubeconfig"]])
        if config.get("context"):
            self.kubectl_base.extend(["--context", config["context"]])
        if config.get("namespace"):
            self.default_namespace = config["namespace"]
        else:
            self.default_namespace = None

        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        """System prompt that defines how the agent thinks and acts."""
        tools_desc = "\n".join(
            f"- {name}: {tool.description}"
            for name, tool in self.tools.items()
        )

        return f"""You are a Kubernetes expert helping with cluster "{self.name}".

Your job is to:
1. Understand the user's question about their cluster
2. Use kubectl to gather relevant information
3. Analyze the results and explain what you find
4. Suggest fixes when appropriate (user will approve before execution)

Available tools:
{tools_desc}

To use a tool, write: TOOL: kubectl <command>
Example: TOOL: kubectl get pods -n default

Guidelines:
- Start with broad queries (get pods -A) then narrow down
- Check events when investigating issues
- Look at logs for crash-looping pods
- Be concise but thorough in explanations
- If you need to make changes, explain what and why first

Safety:
- Read-only commands run automatically
- Write/delete commands will ask for user approval
- You cannot run shell commands or access the filesystem"""

    def _register_tools(self) -> None:
        """Register kubectl tools the agent can use."""

        # Main kubectl tool - read operations are safe, write operations need approval
        self.register_tool(
            name="kubectl",
            description="Run kubectl commands (get, describe, logs, etc.)",
            execute=self._run_kubectl,
            requires_approval=False,  # Approval checked per-command below
            action_type=ActionType.READ,
            blocklist=KUBECTL_DANGEROUS_COMMANDS,  # Block dangerous commands in auto mode
        )

        # Separate tool for write operations (always requires approval)
        self.register_tool(
            name="kubectl_write",
            description="Run kubectl write commands (apply, delete, scale) - requires approval",
            execute=self._run_kubectl_write,
            requires_approval=True,
            action_type=ActionType.WRITE,
            allowlist=KUBECTL_DANGEROUS_COMMANDS,
        )

        # JSON output tool for structured data
        self.register_tool(
            name="kubectl_json",
            description="Run kubectl with JSON output for structured data analysis",
            execute=self._run_kubectl_json,
            action_type=ActionType.READ,
            blocklist=KUBECTL_DANGEROUS_COMMANDS,
        )

    def _run_kubectl(self, args: str) -> str:
        """Execute a read-only kubectl command.

        Args:
            args: kubectl arguments (e.g., "get pods -n default")

        Returns:
            Command output or error message
        """
        # Double-check for dangerous commands (defense in depth)
        args_lower = args.lower()
        for dangerous in KUBECTL_DANGEROUS_COMMANDS:
            if args_lower.startswith(dangerous) or f" {dangerous} " in f" {args_lower} ":
                return f"Error: '{dangerous}' is a write operation. Use kubectl_write instead."

        return self._execute_kubectl(args)

    def _run_kubectl_write(self, args: str) -> str:
        """Execute a kubectl write command (requires prior approval).

        Args:
            args: kubectl arguments for write operation

        Returns:
            Command output or error message
        """
        return self._execute_kubectl(args)

    def _run_kubectl_json(self, args: str) -> str:
        """Execute kubectl with JSON output and return formatted summary.

        Args:
            args: kubectl arguments

        Returns:
            Summarized JSON output
        """
        # Ensure -o json is in the command
        if "-o json" not in args and "-o=json" not in args:
            args = args + " -o json"

        output = self._execute_kubectl(args)

        # Try to parse and summarize JSON
        try:
            data = json.loads(output)
            return self._summarize_json(data, args)
        except json.JSONDecodeError:
            # Return raw output if not valid JSON
            return output[:1000] if len(output) > 1000 else output

    def _execute_kubectl(self, args: str) -> str:
        """Actually execute a kubectl command.

        Args:
            args: kubectl arguments

        Returns:
            Command output or error message
        """
        # Build command - split args carefully
        cmd = self.kubectl_base + args.split()

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.TOOL_TIMEOUT_SEC,
            )

            output = result.stdout
            if result.stderr and result.returncode != 0:
                output += f"\nError: {result.stderr}"

            return output if output else "(no output)"

        except subprocess.TimeoutExpired:
            raise TimeoutError(f"Command timed out after {self.TOOL_TIMEOUT_SEC} seconds")
        except FileNotFoundError:
            return "Error: kubectl not found. Is it installed and in PATH?"
        except Exception as e:
            return f"Error executing command: {e}"

    def _summarize_json(self, data: dict, command: str) -> str:
        """Summarize JSON kubectl output into readable text.

        Args:
            data: Parsed JSON data
            command: Original command (for context)

        Returns:
            Human-readable summary
        """
        items = data.get("items", [data] if "kind" in data else [])

        if not items:
            return "No resources found"

        kind = data.get("kind", "").replace("List", "")
        summaries = []

        for item in items[:20]:  # Limit to 20 items
            meta = item.get("metadata", {})
            name = meta.get("name", "unknown")
            namespace = meta.get("namespace", "")
            status = item.get("status", {})

            if kind == "Pod":
                phase = status.get("phase", "Unknown")
                conditions = status.get("containerStatuses", [])

                restarts = sum(c.get("restartCount", 0) for c in conditions)
                ready = sum(1 for c in conditions if c.get("ready"))
                total = len(conditions)

                state = phase
                for c in conditions:
                    waiting = c.get("waiting", {})
                    if waiting.get("reason"):
                        state = waiting["reason"]
                        break

                line = f"  {namespace}/{name}: {state}"
                if restarts > 0:
                    line += f" (restarts: {restarts})"
                if total > 0:
                    line += f" [{ready}/{total} ready]"
                summaries.append(line)

            elif kind == "Node":
                conditions = status.get("conditions", [])
                ready = "Unknown"
                for c in conditions:
                    if c["type"] == "Ready":
                        ready = "Ready" if c["status"] == "True" else "NotReady"
                        break

                # Get resource info
                allocatable = status.get("allocatable", {})
                cpu = allocatable.get("cpu", "?")
                memory = allocatable.get("memory", "?")
                summaries.append(f"  {name}: {ready} (cpu: {cpu}, mem: {memory})")

            elif kind == "Event":
                reason = item.get("reason", "")
                message = item.get("message", "")[:80]
                event_type = item.get("type", "Normal")
                obj = item.get("involvedObject", {})
                obj_name = obj.get("name", "")

                prefix = "!" if event_type == "Warning" else " "
                summaries.append(f" {prefix}{reason}: {obj_name} - {message}")

            elif kind == "Deployment":
                replicas = status.get("replicas", 0)
                ready = status.get("readyReplicas", 0)
                available = status.get("availableReplicas", 0)
                summaries.append(f"  {namespace}/{name}: {ready}/{replicas} ready, {available} available")

            elif kind == "Service":
                spec = item.get("spec", {})
                svc_type = spec.get("type", "ClusterIP")
                cluster_ip = spec.get("clusterIP", "")
                ports = spec.get("ports", [])
                port_str = ", ".join(f"{p.get('port')}/{p.get('protocol', 'TCP')}" for p in ports[:3])
                summaries.append(f"  {namespace}/{name}: {svc_type} {cluster_ip} [{port_str}]")

            else:
                summaries.append(f"  {namespace}/{name}" if namespace else f"  {name}")

        result = f"{kind}s ({len(items)} found):\n" + "\n".join(summaries)

        if len(items) > 20:
            result += f"\n  ... and {len(items) - 20} more"

        return result

    def _mock_response(self, user_message: str) -> str:
        """Mock response for Kubernetes-specific queries."""
        msg_lower = user_message.lower()

        if any(w in msg_lower for w in ["crash", "fail", "error", "wrong", "not working"]):
            return """Let me check for unhealthy pods across all namespaces.

TOOL: kubectl get pods -A --field-selector=status.phase!=Running"""

        elif any(w in msg_lower for w in ["log", "why"]):
            return """Let me check the logs to understand what's happening.

TOOL: kubectl logs --tail=100"""

        elif any(w in msg_lower for w in ["event", "recent"]):
            return """Let me check recent events in the cluster.

TOOL: kubectl get events -A --sort-by='.lastTimestamp'"""

        elif any(w in msg_lower for w in ["node", "capacity", "resource"]):
            return """Let me check the node status and resources.

TOOL: kubectl_json get nodes"""

        elif any(w in msg_lower for w in ["deploy", "replica", "scale"]):
            return """Let me check the deployments.

TOOL: kubectl_json get deployments -A"""

        elif any(w in msg_lower for w in ["service", "endpoint", "network"]):
            return """Let me check the services.

TOOL: kubectl_json get services -A"""

        elif any(w in msg_lower for w in ["delete", "remove", "kill"]):
            return """I can help with that, but deleting resources requires your approval.

What would you like to delete? Please specify:
- The resource type (pod, deployment, service, etc.)
- The resource name
- The namespace

Once you confirm, I'll prepare the command for your approval."""

        else:
            return """I'm monitoring this Kubernetes cluster. What would you like to know?

I can check:
- Pod status and health (`get pods`)
- Recent events and errors (`get events`)
- Logs from containers (`logs`)
- Node resources and status (`get nodes`)
- Deployments and replica status (`get deployments`)
- Services and networking (`get services`)

What should I investigate?"""

    def _mock_continuation(self, tool_output: str) -> str:
        """Mock continuation for Kubernetes-specific tool results."""
        if "CrashLoopBackOff" in tool_output:
            return """I found pods in CrashLoopBackOff state. This usually means the container is crashing repeatedly. Let me check the logs.

TOOL: kubectl logs --previous --tail=50"""

        elif "ImagePullBackOff" in tool_output or "ErrImagePull" in tool_output:
            return """I see ImagePullBackOff errors. This means Kubernetes can't pull the container image. Common causes:
- Image name or tag is wrong
- Private registry requires authentication
- Image doesn't exist

Let me get more details on the affected pod.

TOOL: kubectl describe pod"""

        elif "Pending" in tool_output and "0/" in tool_output:
            return """I see pods stuck in Pending state. Let me check the events to understand why.

TOOL: kubectl get events --sort-by='.lastTimestamp'"""

        elif "OOMKilled" in tool_output:
            return """I found OOMKilled containers - the pods ran out of memory. You may need to:
1. Increase memory limits
2. Fix a memory leak in the application
3. Check for unexpected memory usage

Would you like me to show the current resource limits?"""

        elif "NotReady" in tool_output and "node" in tool_output.lower():
            return """I see NotReady nodes. Let me check what's wrong.

TOOL: kubectl describe node"""

        elif "Running" in tool_output and "0/" not in tool_output:
            return """All pods are running and healthy. The cluster looks good!

Is there a specific issue you're experiencing, or would you like me to check something else?"""

        elif "BLOCKED" in tool_output:
            return """That command was blocked for security reasons. Let me try a read-only approach instead.

TOOL: kubectl get pods"""

        elif "Error" in tool_output:
            return """I encountered an error. Let me try a different approach to gather the information.

TOOL: kubectl get all -A"""

        else:
            return """I've gathered the information. Based on what I see:

The cluster appears to be functioning normally. Let me know if you'd like me to:
- Dig deeper into specific pods or services
- Check resource utilization
- Review recent deployments
- Look at specific namespaces

What would you like to investigate next?"""
