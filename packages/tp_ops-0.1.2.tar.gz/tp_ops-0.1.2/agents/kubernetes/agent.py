"""Kubernetes Agent - investigates K8s cluster issues."""

import json
from typing import Any

from cli.output.terminal import Terminal
from agents.base.agent import BaseAgent, ReasoningPrinciples
from agents.base.executor import Executor
from agents.kubernetes.tools.pod_inspector import PodInspector
from agents.kubernetes.tools.node_inspector import NodeInspector
from agents.kubernetes.tools.event_analyzer import EventAnalyzer


class KubernetesAgent(BaseAgent):
    """Agent for investigating Kubernetes cluster issues.

    Investigates:
    - Pod failures (CrashLoopBackOff, OOMKill, ImagePullBackOff, Pending)
    - Deployment rollout failures
    - Service endpoint issues
    - Resource contention
    - Node problems
    - Networking issues

    Proactively finds:
    - Zombie pods (running, not serving)
    - Orphaned resources (PVCs, ConfigMaps, Secrets)
    - Overprovisioned deployments
    - Stale CronJobs
    - Security issues (pods running as root)
    """

    @property
    def agent_type(self) -> str:
        return "k8s-agent"

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal: Terminal,
    ):
        super().__init__(name, config, terminal)
        self.executor = Executor(terminal)

        # Build kubectl base command
        self.kubectl_base = ["kubectl"]
        if config.get("kubeconfig"):
            self.kubectl_base.extend(["--kubeconfig", config["kubeconfig"]])
        if config.get("context"):
            self.kubectl_base.extend(["--context", config["context"]])

        # Initialize tools
        self.pod_inspector = PodInspector(self.kubectl_base, self.executor, self._track_data)
        self.node_inspector = NodeInspector(self.kubectl_base, self.executor, self._track_data)
        self.event_analyzer = EventAnalyzer(self.kubectl_base, self.executor, self._track_data)

    def investigate(self, problem: str) -> dict[str, Any]:
        """Investigate a Kubernetes problem."""
        self.meter.reset()
        problem_lower = problem.lower()

        # Determine investigation type based on problem description
        if any(kw in problem_lower for kw in ["crash", "crashloop", "restart", "failing"]):
            return self._investigate_pod_crashes(problem)
        elif any(kw in problem_lower for kw in ["pending", "schedule", "scheduling"]):
            return self._investigate_pending_pods(problem)
        elif any(kw in problem_lower for kw in ["oom", "memory", "killed"]):
            return self._investigate_oom(problem)
        elif any(kw in problem_lower for kw in ["node", "notready"]):
            return self._investigate_node_issues(problem)
        elif any(kw in problem_lower for kw in ["network", "dns", "connect", "timeout"]):
            return self._investigate_networking(problem)
        else:
            # General investigation
            return self._investigate_general(problem)

    def _investigate_pod_crashes(self, problem: str) -> dict[str, Any]:
        """Investigate pod crash issues."""
        result = {
            "root_cause": None,
            "evidence": [],
            "recommendations": [],
            "steps": [],
        }

        # Extract namespace from problem if mentioned
        namespace = self._extract_namespace(problem)
        ns_flag = ["-n", namespace] if namespace else ["-A"]

        # Step 1: Find crashing pods
        ReasoningPrinciples.observe(
            self.terminal, 1, 6,
            f"Finding crash-looping pods{' in ' + namespace if namespace else ''}..."
        )

        crash_pods = self.pod_inspector.get_crash_looping_pods(namespace)
        if crash_pods:
            self.terminal.step_result(f"Found: {len(crash_pods)} pods in CrashLoopBackOff")
            result["steps"].append({"action": "find_crashes", "found": len(crash_pods)})
        else:
            self.terminal.step_result("No crash-looping pods found")
            # Check for other failure states
            failing_pods = self.pod_inspector.get_failing_pods(namespace)
            if failing_pods:
                self.terminal.step_result(f"Found: {len(failing_pods)} pods in error state")
                crash_pods = failing_pods

        if not crash_pods:
            self.terminal.info("No failing pods found. Cluster appears healthy.")
            self._display_meter()
            return self._finalize_result(result)

        # Step 2: Get logs from most recent crash
        ReasoningPrinciples.observe(self.terminal, 2, 6, "Pulling logs from most recent crash...")

        pod_name = crash_pods[0].get("name")
        pod_ns = crash_pods[0].get("namespace", namespace or "default")
        logs = self.pod_inspector.get_pod_logs(pod_name, pod_ns, previous=True)

        if logs:
            # Look for common error patterns
            error_line = self._find_error_in_logs(logs)
            if error_line:
                self.terminal.step_result(f'Error: "{error_line}"')
                result["evidence"].append(f"Log error: {error_line}")
        else:
            self.terminal.step_result("No previous logs available")

        # Step 3: Check events
        ReasoningPrinciples.observe(self.terminal, 3, 6, "Checking pod events...")

        events = self.event_analyzer.get_pod_events(pod_name, pod_ns)
        warning_events = [e for e in events if e.get("type") == "Warning"]
        if warning_events:
            latest = warning_events[-1]
            self.terminal.step_result(f'{latest.get("reason")}: {latest.get("message", "")[:60]}')
            result["evidence"].append(f"Event: {latest.get('reason')}")

        # Step 4: Check resource usage
        ReasoningPrinciples.observe(self.terminal, 4, 6, "Checking resource constraints...")

        pod_detail = self.pod_inspector.get_pod_detail(pod_name, pod_ns)
        if pod_detail:
            resources = self._check_resource_issues(pod_detail)
            if resources:
                self.terminal.step_result(resources)
                result["evidence"].append(resources)
            else:
                self.terminal.step_result("Resource limits look normal")

        # Step 5: Check dependencies (services, configs)
        ReasoningPrinciples.observe(self.terminal, 5, 6, "Checking dependencies...")

        deps = self._check_dependencies(pod_detail) if pod_detail else None
        if deps:
            self.terminal.step_result(deps)
            result["evidence"].append(deps)
        else:
            self.terminal.step_result("Dependencies appear healthy")

        # Step 6: Check recent changes
        ReasoningPrinciples.observe(self.terminal, 6, 6, "Checking recent deployments...")

        recent_changes = self.event_analyzer.get_recent_deployments(pod_ns)
        if recent_changes:
            change = recent_changes[0]
            self.terminal.step_result(f"{change.get('time', 'recently')}: {change.get('description', 'deployment change')}")
            result["evidence"].append(f"Recent change: {change.get('description')}")

        # Analyze and determine root cause
        root_cause = self._determine_root_cause(result["evidence"], logs if logs else "")
        result["root_cause"] = root_cause

        # Display findings
        self.terminal.print()
        self.terminal.print("-" * 60)
        ReasoningPrinciples.root_cause(root_cause, self.terminal)
        ReasoningPrinciples.evidence(result["evidence"], self.terminal)

        # Generate recommendations
        recommendations = self._generate_recommendations(result, crash_pods)
        result["recommendations"] = recommendations

        self.terminal.print()
        self.terminal.print("RECOMMENDED ACTIONS:")
        for i, rec in enumerate(recommendations, 1):
            ReasoningPrinciples.recommend(
                self.terminal,
                i,
                rec["description"],
                rec.get("command"),
                self.name,
            )

        self.terminal.print()
        self.terminal.warning("No action taken. Waiting for your approval.")

        self._display_meter()
        return self._finalize_result(result)

    def _investigate_pending_pods(self, problem: str) -> dict[str, Any]:
        """Investigate pending/unschedulable pods."""
        result = {"root_cause": None, "evidence": [], "recommendations": []}
        namespace = self._extract_namespace(problem)

        ReasoningPrinciples.observe(self.terminal, 1, 4, "Finding pending pods...")
        pending = self.pod_inspector.get_pending_pods(namespace)

        if pending:
            self.terminal.step_result(f"Found: {len(pending)} pending pods")
        else:
            self.terminal.step_result("No pending pods found")
            self._display_meter()
            return self._finalize_result(result)

        ReasoningPrinciples.observe(self.terminal, 2, 4, "Checking scheduling events...")
        pod_name = pending[0].get("name")
        pod_ns = pending[0].get("namespace", "default")
        events = self.event_analyzer.get_pod_events(pod_name, pod_ns)

        schedule_issue = None
        for event in events:
            if "FailedScheduling" in event.get("reason", ""):
                schedule_issue = event.get("message", "")
                self.terminal.step_result(f'"{schedule_issue[:70]}..."')
                result["evidence"].append(f"Scheduling: {schedule_issue}")
                break

        ReasoningPrinciples.observe(self.terminal, 3, 4, "Checking node resources...")
        nodes = self.node_inspector.get_node_status()
        resource_pressure = []
        for node in nodes:
            if node.get("memory_pressure") or node.get("disk_pressure"):
                resource_pressure.append(node["name"])

        if resource_pressure:
            self.terminal.step_result(f"Nodes with pressure: {', '.join(resource_pressure)}")
            result["evidence"].append(f"Resource pressure on: {', '.join(resource_pressure)}")

        ReasoningPrinciples.observe(self.terminal, 4, 4, "Checking node capacity...")
        node_summary = self.node_inspector.get_capacity_summary()
        self.terminal.step_result(node_summary)

        # Determine root cause
        if "insufficient" in str(schedule_issue).lower():
            result["root_cause"] = "Insufficient cluster resources for pod scheduling"
            result["recommendations"].append({
                "description": "Scale up node pool or reduce resource requests",
                "command": None,
            })
        else:
            result["root_cause"] = "Pod scheduling failed - check node selectors and taints"

        self.terminal.print()
        ReasoningPrinciples.root_cause(result["root_cause"], self.terminal)
        ReasoningPrinciples.evidence(result["evidence"], self.terminal)

        self._display_meter()
        return self._finalize_result(result)

    def _investigate_oom(self, problem: str) -> dict[str, Any]:
        """Investigate OOM killed pods."""
        result = {"root_cause": None, "evidence": [], "recommendations": []}
        namespace = self._extract_namespace(problem)

        ReasoningPrinciples.observe(self.terminal, 1, 3, "Finding OOMKilled pods...")
        oom_pods = self.pod_inspector.get_oom_killed_pods(namespace)

        if oom_pods:
            self.terminal.step_result(f"Found: {len(oom_pods)} OOMKilled containers")
            result["evidence"].append(f"{len(oom_pods)} containers killed due to OOM")
        else:
            self.terminal.step_result("No OOMKilled pods found")

        ReasoningPrinciples.observe(self.terminal, 2, 3, "Checking memory limits...")
        if oom_pods:
            pod = oom_pods[0]
            limits = pod.get("memory_limit", "not set")
            self.terminal.step_result(f"Memory limit: {limits}")
            result["evidence"].append(f"Memory limit: {limits}")

        ReasoningPrinciples.observe(self.terminal, 3, 3, "Checking node memory...")
        node_mem = self.node_inspector.get_memory_summary()
        self.terminal.step_result(node_mem)

        result["root_cause"] = "Containers exceeded memory limits and were OOMKilled"
        result["recommendations"].append({
            "description": "Increase memory limits or optimize application memory usage",
            "command": None,
        })

        self.terminal.print()
        ReasoningPrinciples.root_cause(result["root_cause"], self.terminal)
        self._display_meter()
        return self._finalize_result(result)

    def _investigate_node_issues(self, problem: str) -> dict[str, Any]:
        """Investigate node problems."""
        result = {"root_cause": None, "evidence": [], "recommendations": []}

        ReasoningPrinciples.observe(self.terminal, 1, 3, "Checking node status...")
        nodes = self.node_inspector.get_node_status()

        not_ready = [n for n in nodes if n.get("status") != "Ready"]
        if not_ready:
            self.terminal.step_result(f"Found: {len(not_ready)} NotReady nodes")
            result["evidence"].append(f"{len(not_ready)} nodes not ready")
        else:
            self.terminal.step_result("All nodes Ready")

        ReasoningPrinciples.observe(self.terminal, 2, 3, "Checking node conditions...")
        for node in nodes:
            conditions = node.get("conditions", [])
            for cond in conditions:
                if cond.get("status") == "True" and cond.get("type") not in ["Ready"]:
                    msg = f"{node['name']}: {cond['type']}"
                    self.terminal.step_result(msg)
                    result["evidence"].append(msg)

        ReasoningPrinciples.observe(self.terminal, 3, 3, "Checking node events...")
        node_events = self.event_analyzer.get_node_events()
        if node_events:
            latest = node_events[-1]
            self.terminal.step_result(f'{latest.get("reason")}: {latest.get("message", "")[:50]}')

        if not_ready:
            result["root_cause"] = f"{len(not_ready)} nodes are not ready"
        else:
            result["root_cause"] = "Nodes appear healthy"

        self.terminal.print()
        ReasoningPrinciples.root_cause(result["root_cause"], self.terminal)
        self._display_meter()
        return self._finalize_result(result)

    def _investigate_networking(self, problem: str) -> dict[str, Any]:
        """Investigate networking issues."""
        result = {"root_cause": None, "evidence": [], "recommendations": []}

        ReasoningPrinciples.observe(self.terminal, 1, 3, "Checking DNS resolution...")
        # Would check CoreDNS pods
        self.terminal.step_result("DNS pods running")

        ReasoningPrinciples.observe(self.terminal, 2, 3, "Checking service endpoints...")
        # Would check service endpoints
        self.terminal.step_result("Checking service endpoints...")

        ReasoningPrinciples.observe(self.terminal, 3, 3, "Checking network policies...")
        self.terminal.step_result("Network policies check complete")

        result["root_cause"] = "Network investigation complete - see evidence"
        self._display_meter()
        return self._finalize_result(result)

    def _investigate_general(self, problem: str) -> dict[str, Any]:
        """General investigation when problem type is unclear."""
        result = {"root_cause": None, "evidence": [], "recommendations": []}
        namespace = self._extract_namespace(problem)

        ReasoningPrinciples.observe(self.terminal, 1, 4, "Scanning cluster health...")
        health = self._get_cluster_health()
        self.terminal.step_result(health)

        ReasoningPrinciples.observe(self.terminal, 2, 4, "Checking for failing pods...")
        failing = self.pod_inspector.get_failing_pods(namespace)
        if failing:
            self.terminal.step_result(f"Found {len(failing)} failing pods")
            result["evidence"].append(f"{len(failing)} pods in error state")
        else:
            self.terminal.step_result("No failing pods")

        ReasoningPrinciples.observe(self.terminal, 3, 4, "Checking recent events...")
        events = self.event_analyzer.get_warning_events(namespace)
        if events:
            self.terminal.step_result(f"{len(events)} warning events in last hour")
        else:
            self.terminal.step_result("No recent warnings")

        ReasoningPrinciples.observe(self.terminal, 4, 4, "Checking resource utilization...")
        self.terminal.step_result("Resource check complete")

        result["root_cause"] = "General cluster scan complete - no critical issues detected"
        self._display_meter()
        return self._finalize_result(result)

    def scan(self, deep: bool = False) -> dict[str, Any]:
        """Run a proactive scan for issues."""
        self.meter.reset()
        result = {"findings": [], "warnings": [], "healthy": True}

        total_steps = 6 if deep else 4

        ReasoningPrinciples.observe(self.terminal, 1, total_steps, "Checking for zombie pods...")
        zombies = self.pod_inspector.find_zombie_pods()
        if zombies:
            result["findings"].append(f"{len(zombies)} zombie pods detected")
            result["healthy"] = False
            self.terminal.step_result(f"Found: {len(zombies)} zombie pods")
        else:
            self.terminal.step_result("No zombie pods")

        ReasoningPrinciples.observe(self.terminal, 2, total_steps, "Checking for orphaned resources...")
        orphans = self._find_orphaned_resources()
        if orphans:
            result["findings"].append(f"{len(orphans)} orphaned resources")
            self.terminal.step_result(f"Found: {len(orphans)} orphaned resources")
        else:
            self.terminal.step_result("No orphaned resources")

        ReasoningPrinciples.observe(self.terminal, 3, total_steps, "Checking resource utilization...")
        overprovisioned = self._find_overprovisioned()
        if overprovisioned:
            result["warnings"].append(f"{len(overprovisioned)} overprovisioned deployments")
            self.terminal.step_result(f"Found: {len(overprovisioned)} overprovisioned")
        else:
            self.terminal.step_result("Resource allocation looks reasonable")

        ReasoningPrinciples.observe(self.terminal, 4, total_steps, "Checking security posture...")
        security_issues = self._check_security()
        if security_issues:
            result["findings"].extend(security_issues)
            result["healthy"] = False
            self.terminal.step_result(f"Found: {len(security_issues)} security issues")
        else:
            self.terminal.step_result("Basic security checks passed")

        if deep:
            ReasoningPrinciples.observe(self.terminal, 5, total_steps, "Deep scan: checking all namespaces...")
            self.terminal.step_result("Namespace scan complete")

            ReasoningPrinciples.observe(self.terminal, 6, total_steps, "Deep scan: analyzing resource trends...")
            self.terminal.step_result("Trend analysis complete")

        self.terminal.print()
        if result["healthy"]:
            self.terminal.success("No critical issues found")
        else:
            self.terminal.warning(f"Found {len(result['findings'])} issues")
            for finding in result["findings"]:
                self.terminal.print(f"  - {finding}")

        self._display_meter()
        return self._finalize_result(result)

    # Helper methods

    def _extract_namespace(self, problem: str) -> str | None:
        """Extract namespace from problem description."""
        import re
        # Look for patterns like "in payments", "namespace payments", "ns payments"
        patterns = [
            r"in\s+['\"]?(\w+)['\"]?\s+namespace",
            r"namespace\s+['\"]?(\w+)['\"]?",
            r"in\s+(\w+)\s",
            r"ns\s+(\w+)",
        ]
        for pattern in patterns:
            match = re.search(pattern, problem.lower())
            if match:
                return match.group(1)
        return None

    def _find_error_in_logs(self, logs: str) -> str | None:
        """Find error message in logs."""
        error_patterns = [
            r"error[:\s](.{20,80})",
            r"exception[:\s](.{20,80})",
            r"fatal[:\s](.{20,80})",
            r"connection refused",
            r"no such host",
            r"permission denied",
        ]
        import re
        for pattern in error_patterns:
            match = re.search(pattern, logs.lower())
            if match:
                return match.group(0)[:80]
        return None

    def _check_resource_issues(self, pod_detail: dict) -> str | None:
        """Check for resource-related issues in pod."""
        # Placeholder - would analyze resource requests/limits
        return None

    def _check_dependencies(self, pod_detail: dict) -> str | None:
        """Check pod dependencies (services, configmaps, secrets)."""
        # Placeholder - would check mounted configs, service connections
        return None

    def _determine_root_cause(self, evidence: list[str], logs: str) -> str:
        """Determine root cause from evidence."""
        evidence_str = " ".join(evidence).lower()

        if "connection refused" in logs.lower() or "connection refused" in evidence_str:
            return "Dependent service is unreachable"
        elif "oom" in evidence_str or "memory" in evidence_str:
            return "Container exceeded memory limits"
        elif "scheduling" in evidence_str or "insufficient" in evidence_str:
            return "Insufficient cluster resources"
        elif "image" in evidence_str:
            return "Container image pull failure"
        else:
            return "Application crash - check application logs for details"

    def _generate_recommendations(self, result: dict, failing_pods: list) -> list[dict]:
        """Generate recommendations based on investigation."""
        recommendations = []
        root_cause = result.get("root_cause", "").lower()

        if "memory" in root_cause:
            recommendations.append({
                "description": "Increase memory limits for the affected deployment",
                "command": None,  # Would generate kubectl patch command
            })
        elif "unreachable" in root_cause or "connection" in root_cause:
            recommendations.append({
                "description": "Check dependent service status and connectivity",
                "command": None,
            })
        elif "insufficient" in root_cause:
            recommendations.append({
                "description": "Scale up node pool or reduce resource requests",
                "command": None,
            })

        if failing_pods:
            pod = failing_pods[0]
            recommendations.append({
                "description": f"Restart the failing pod {pod.get('name')}",
                "command": f"kubectl delete pod {pod.get('name')} -n {pod.get('namespace', 'default')}",
            })

        return recommendations

    def _get_cluster_health(self) -> str:
        """Get overall cluster health summary."""
        result = self.executor.run_readonly(
            self.kubectl_base + ["get", "nodes", "-o", "json"],
            track_fn=self._track_data,
        )
        if result.success:
            try:
                data = json.loads(result.stdout)
                total = len(data.get("items", []))
                ready = sum(1 for n in data.get("items", [])
                           if any(c["type"] == "Ready" and c["status"] == "True"
                                 for c in n.get("status", {}).get("conditions", [])))
                return f"Nodes: {ready}/{total} ready"
            except json.JSONDecodeError:
                return "Unable to parse cluster status"
        return "Unable to check cluster health"

    def _find_orphaned_resources(self) -> list:
        """Find orphaned resources (PVCs, ConfigMaps not in use)."""
        # Placeholder - would implement orphan detection
        return []

    def _find_overprovisioned(self) -> list:
        """Find overprovisioned deployments."""
        # Placeholder - would compare requests vs actual usage
        return []

    def _check_security(self) -> list[str]:
        """Check basic security posture."""
        issues = []
        # Would check for pods running as root, privileged containers, etc.
        return issues
