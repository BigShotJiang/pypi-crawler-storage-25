"""Pod inspection tools for Kubernetes Agent."""

import json
from typing import Any, Callable

from agents.base.executor import Executor


class PodInspector:
    """Inspect Kubernetes pods."""

    def __init__(
        self,
        kubectl_base: list[str],
        executor: Executor,
        track_fn: Callable[[str], None],
    ):
        self.kubectl = kubectl_base
        self.executor = executor
        self.track = track_fn

    def get_crash_looping_pods(self, namespace: str | None = None) -> list[dict[str, Any]]:
        """Get pods in CrashLoopBackOff state."""
        cmd = self.kubectl + ["get", "pods"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        cmd.extend(["-o", "json"])

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            crash_pods = []

            for pod in data.get("items", []):
                statuses = pod.get("status", {}).get("containerStatuses", [])
                for cs in statuses:
                    waiting = cs.get("waiting", {})
                    if waiting.get("reason") == "CrashLoopBackOff":
                        crash_pods.append({
                            "name": pod["metadata"]["name"],
                            "namespace": pod["metadata"]["namespace"],
                            "container": cs["name"],
                            "restart_count": cs.get("restartCount", 0),
                            "reason": "CrashLoopBackOff",
                        })
                        break

            return crash_pods

        except json.JSONDecodeError:
            return []

    def get_failing_pods(self, namespace: str | None = None) -> list[dict[str, Any]]:
        """Get pods in any failure state."""
        cmd = self.kubectl + ["get", "pods"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        cmd.extend(["-o", "json"])

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            failing = []

            failure_reasons = {
                "CrashLoopBackOff", "Error", "ImagePullBackOff",
                "ErrImagePull", "CreateContainerConfigError",
                "InvalidImageName", "RunContainerError",
            }

            for pod in data.get("items", []):
                phase = pod.get("status", {}).get("phase")
                if phase == "Failed":
                    failing.append({
                        "name": pod["metadata"]["name"],
                        "namespace": pod["metadata"]["namespace"],
                        "reason": "Failed",
                    })
                    continue

                statuses = pod.get("status", {}).get("containerStatuses", [])
                for cs in statuses:
                    waiting = cs.get("waiting", {})
                    reason = waiting.get("reason", "")
                    if reason in failure_reasons:
                        failing.append({
                            "name": pod["metadata"]["name"],
                            "namespace": pod["metadata"]["namespace"],
                            "container": cs["name"],
                            "reason": reason,
                        })
                        break

            return failing

        except json.JSONDecodeError:
            return []

    def get_pending_pods(self, namespace: str | None = None) -> list[dict[str, Any]]:
        """Get pods in Pending state."""
        cmd = self.kubectl + ["get", "pods"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        cmd.extend(["--field-selector=status.phase=Pending", "-o", "json"])

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            return [
                {
                    "name": pod["metadata"]["name"],
                    "namespace": pod["metadata"]["namespace"],
                }
                for pod in data.get("items", [])
            ]
        except json.JSONDecodeError:
            return []

    def get_oom_killed_pods(self, namespace: str | None = None) -> list[dict[str, Any]]:
        """Get pods that were OOMKilled."""
        cmd = self.kubectl + ["get", "pods"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        cmd.extend(["-o", "json"])

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            oom_pods = []

            for pod in data.get("items", []):
                statuses = pod.get("status", {}).get("containerStatuses", [])
                for cs in statuses:
                    last_state = cs.get("lastState", {}).get("terminated", {})
                    if last_state.get("reason") == "OOMKilled":
                        # Get memory limit
                        containers = pod.get("spec", {}).get("containers", [])
                        memory_limit = "not set"
                        for c in containers:
                            if c["name"] == cs["name"]:
                                limits = c.get("resources", {}).get("limits", {})
                                memory_limit = limits.get("memory", "not set")
                                break

                        oom_pods.append({
                            "name": pod["metadata"]["name"],
                            "namespace": pod["metadata"]["namespace"],
                            "container": cs["name"],
                            "memory_limit": memory_limit,
                        })

            return oom_pods

        except json.JSONDecodeError:
            return []

    def get_pod_logs(
        self,
        name: str,
        namespace: str,
        previous: bool = False,
        tail: int = 100,
    ) -> str:
        """Get logs from a pod."""
        cmd = self.kubectl + ["logs", name, "-n", namespace, f"--tail={tail}"]
        if previous:
            cmd.append("--previous")

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        return result.stdout if result.success else ""

    def get_pod_detail(self, name: str, namespace: str) -> dict[str, Any] | None:
        """Get detailed pod information."""
        cmd = self.kubectl + ["get", "pod", name, "-n", namespace, "-o", "json"]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return None

        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return None

    def find_zombie_pods(self) -> list[dict[str, Any]]:
        """Find zombie pods - running but not serving traffic.

        Looks for pods that:
        - Are in Running state
        - Have 0 readiness probe successes
        - Have been running for more than 10 minutes
        """
        cmd = self.kubectl + ["get", "pods", "-A", "-o", "json"]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            zombies = []

            for pod in data.get("items", []):
                phase = pod.get("status", {}).get("phase")
                if phase != "Running":
                    continue

                conditions = pod.get("status", {}).get("conditions", [])
                ready = any(
                    c["type"] == "Ready" and c["status"] == "True"
                    for c in conditions
                )

                if not ready:
                    # Check how long it's been running
                    zombies.append({
                        "name": pod["metadata"]["name"],
                        "namespace": pod["metadata"]["namespace"],
                        "reason": "Running but not Ready",
                    })

            return zombies

        except json.JSONDecodeError:
            return []
