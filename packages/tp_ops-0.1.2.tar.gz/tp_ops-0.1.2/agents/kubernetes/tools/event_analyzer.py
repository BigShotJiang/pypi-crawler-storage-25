"""Event analysis tools for Kubernetes Agent."""

import json
from datetime import datetime, timedelta
from typing import Any, Callable

from agents.base.executor import Executor


class EventAnalyzer:
    """Analyze Kubernetes events."""

    def __init__(
        self,
        kubectl_base: list[str],
        executor: Executor,
        track_fn: Callable[[str], None],
    ):
        self.kubectl = kubectl_base
        self.executor = executor
        self.track = track_fn

    def get_pod_events(self, name: str, namespace: str) -> list[dict[str, Any]]:
        """Get events for a specific pod."""
        cmd = self.kubectl + [
            "get", "events", "-n", namespace,
            f"--field-selector=involvedObject.name={name}",
            "-o", "json"
        ]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            events = []

            for event in data.get("items", []):
                events.append({
                    "type": event.get("type"),
                    "reason": event.get("reason"),
                    "message": event.get("message"),
                    "count": event.get("count", 1),
                    "first_seen": event.get("firstTimestamp"),
                    "last_seen": event.get("lastTimestamp"),
                })

            # Sort by last seen time
            events.sort(key=lambda e: e.get("last_seen") or "")
            return events

        except json.JSONDecodeError:
            return []

    def get_warning_events(self, namespace: str | None = None) -> list[dict[str, Any]]:
        """Get warning events from the last hour."""
        cmd = self.kubectl + ["get", "events", "--field-selector=type=Warning"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        cmd.extend(["-o", "json"])

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            events = []
            cutoff = datetime.utcnow() - timedelta(hours=1)

            for event in data.get("items", []):
                last_ts = event.get("lastTimestamp")
                if last_ts:
                    try:
                        # Parse kubernetes timestamp
                        event_time = datetime.fromisoformat(
                            last_ts.replace("Z", "+00:00")
                        ).replace(tzinfo=None)
                        if event_time < cutoff:
                            continue
                    except ValueError:
                        pass

                events.append({
                    "type": event.get("type"),
                    "reason": event.get("reason"),
                    "message": event.get("message"),
                    "namespace": event.get("metadata", {}).get("namespace"),
                    "involved_object": event.get("involvedObject", {}).get("name"),
                })

            return events

        except json.JSONDecodeError:
            return []

    def get_node_events(self) -> list[dict[str, Any]]:
        """Get events related to nodes."""
        cmd = self.kubectl + [
            "get", "events", "-A",
            "--field-selector=involvedObject.kind=Node",
            "-o", "json"
        ]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            events = []

            for event in data.get("items", []):
                events.append({
                    "type": event.get("type"),
                    "reason": event.get("reason"),
                    "message": event.get("message"),
                    "node": event.get("involvedObject", {}).get("name"),
                    "last_seen": event.get("lastTimestamp"),
                })

            events.sort(key=lambda e: e.get("last_seen") or "")
            return events

        except json.JSONDecodeError:
            return []

    def get_recent_deployments(self, namespace: str | None = None) -> list[dict[str, Any]]:
        """Get recent deployment changes.

        Looks for deployment-related events that indicate changes.
        """
        cmd = self.kubectl + ["get", "events"]
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")
        cmd.extend(["-o", "json"])

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            deployments = []
            cutoff = datetime.utcnow() - timedelta(hours=24)

            deployment_reasons = {
                "ScalingReplicaSet", "SuccessfulCreate",
                "Scheduled", "Pulled", "Started",
            }

            for event in data.get("items", []):
                reason = event.get("reason", "")
                obj = event.get("involvedObject", {})

                if obj.get("kind") in ["Deployment", "ReplicaSet", "StatefulSet"]:
                    last_ts = event.get("lastTimestamp")
                    time_str = "recently"

                    if last_ts:
                        try:
                            event_time = datetime.fromisoformat(
                                last_ts.replace("Z", "+00:00")
                            ).replace(tzinfo=None)
                            if event_time < cutoff:
                                continue

                            delta = datetime.utcnow() - event_time
                            hours = int(delta.total_seconds() / 3600)
                            if hours < 1:
                                time_str = f"{int(delta.total_seconds() / 60)}m ago"
                            else:
                                time_str = f"{hours}h ago"
                        except ValueError:
                            pass

                    deployments.append({
                        "time": time_str,
                        "kind": obj.get("kind"),
                        "name": obj.get("name"),
                        "reason": reason,
                        "description": f"{obj.get('kind', 'resource')} {obj.get('name', 'unknown')} - {event.get('message', reason)[:50]}",
                    })

            # Sort by timestamp (most recent first)
            deployments.sort(key=lambda d: d.get("time", ""), reverse=True)
            return deployments[:5]  # Return top 5

        except json.JSONDecodeError:
            return []
