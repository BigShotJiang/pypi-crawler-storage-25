"""Node inspection tools for Kubernetes Agent."""

import json
from typing import Any, Callable

from agents.base.executor import Executor


class NodeInspector:
    """Inspect Kubernetes nodes."""

    def __init__(
        self,
        kubectl_base: list[str],
        executor: Executor,
        track_fn: Callable[[str], None],
    ):
        self.kubectl = kubectl_base
        self.executor = executor
        self.track = track_fn

    def get_node_status(self) -> list[dict[str, Any]]:
        """Get status of all nodes."""
        cmd = self.kubectl + ["get", "nodes", "-o", "json"]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            nodes = []

            for node in data.get("items", []):
                conditions = node.get("status", {}).get("conditions", [])

                node_info = {
                    "name": node["metadata"]["name"],
                    "status": "Unknown",
                    "conditions": [],
                    "memory_pressure": False,
                    "disk_pressure": False,
                    "pid_pressure": False,
                }

                for cond in conditions:
                    ctype = cond["type"]
                    status = cond["status"]

                    if ctype == "Ready":
                        node_info["status"] = "Ready" if status == "True" else "NotReady"
                    elif ctype == "MemoryPressure" and status == "True":
                        node_info["memory_pressure"] = True
                    elif ctype == "DiskPressure" and status == "True":
                        node_info["disk_pressure"] = True
                    elif ctype == "PIDPressure" and status == "True":
                        node_info["pid_pressure"] = True

                    node_info["conditions"].append({
                        "type": ctype,
                        "status": status,
                    })

                nodes.append(node_info)

            return nodes

        except json.JSONDecodeError:
            return []

    def get_capacity_summary(self) -> str:
        """Get a summary of cluster capacity."""
        cmd = self.kubectl + ["top", "nodes", "--no-headers"]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            # Metrics server might not be installed
            return "Unable to get node metrics (metrics-server may not be installed)"

        lines = result.stdout.strip().split("\n")
        if not lines:
            return "No node metrics available"

        # Parse top output
        summaries = []
        for line in lines:
            parts = line.split()
            if len(parts) >= 5:
                node = parts[0]
                cpu_percent = parts[2].rstrip("%")
                mem_percent = parts[4].rstrip("%")
                summaries.append(f"{node}: CPU {cpu_percent}%, Mem {mem_percent}%")

        return "; ".join(summaries) if summaries else "No metrics data"

    def get_memory_summary(self) -> str:
        """Get memory usage summary."""
        cmd = self.kubectl + ["top", "nodes", "--no-headers"]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return "Unable to get memory metrics"

        lines = result.stdout.strip().split("\n")
        total_percent = 0
        count = 0

        for line in lines:
            parts = line.split()
            if len(parts) >= 5:
                mem_percent = parts[4].rstrip("%")
                try:
                    total_percent += int(mem_percent)
                    count += 1
                except ValueError:
                    pass

        if count > 0:
            avg = total_percent / count
            return f"Average memory utilization: {avg:.0f}%"
        return "No memory data available"

    def get_node_detail(self, name: str) -> dict[str, Any] | None:
        """Get detailed information about a node."""
        cmd = self.kubectl + ["get", "node", name, "-o", "json"]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return None

        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError:
            return None

    def get_pods_on_node(self, node_name: str) -> list[dict[str, Any]]:
        """Get all pods running on a specific node."""
        cmd = self.kubectl + [
            "get", "pods", "-A",
            f"--field-selector=spec.nodeName={node_name}",
            "-o", "json"
        ]

        result = self.executor.run_readonly(cmd, track_fn=self.track)
        if not result.success:
            return []

        try:
            data = json.loads(result.stdout)
            return [
                {
                    "name": pod["metadata"]["name"],
                    "namespace": pod["metadata"]["namespace"],
                    "status": pod.get("status", {}).get("phase", "Unknown"),
                }
                for pod in data.get("items", [])
            ]
        except json.JSONDecodeError:
            return []
