"""E-commerce Platform Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class EcommerceAgent(ShellAgent):
    """Agent for e-commerce platform investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "ecom"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "GET", "/api", "/admin/api", "/products", "/orders",
        "/inventory", "/customers", "health", "status",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "POST", "PUT", "DELETE", "refund", "cancel",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.platform = config.get("platform", "shopify")  # shopify, woocommerce, magento
        self.store_url = config.get("store_url")
        self.api_version = config.get("api_version", "2024-01")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        platform = self.platform.title()
        return f"""You are an E-commerce Platform investigation agent for {platform}.

Store URL: {self.store_url or 'not specified'}
API Version: {self.api_version}

Available tools:
- ecom: Execute read-only e-commerce API calls
- ecom_write: Execute write operations (requires approval)

Investigation approach for Shopify:
1. Shop Info: GET /admin/api/{self.api_version}/shop.json
2. Products: GET /admin/api/{self.api_version}/products.json
3. Orders: GET /admin/api/{self.api_version}/orders.json
4. Inventory: GET /admin/api/{self.api_version}/inventory_levels.json
5. Customers: GET /admin/api/{self.api_version}/customers.json

E-commerce metrics:
- Orders: Count, value, status
- Products: Stock levels, views
- Customers: Active, lifetime value
- Carts: Abandoned, conversion rate
- Revenue: Daily, monthly, yearly

Order states:
- Pending: Awaiting payment
- Paid: Payment received
- Fulfilled: Shipped/delivered
- Cancelled: Order cancelled
- Refunded: Money returned

Common issues:
- Checkout failures: Payment errors
- Inventory sync: Stock mismatches
- Order stuck: Processing delays
- Cart abandonment: High drop-off
- Search issues: Products not found
- Performance: Slow page loads"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        url = self.store_url or "<store-url>"
        version = self.api_version
        if "order" in q:
            return f"I'll check orders.\n\nTOOL: ecom curl -s -H 'X-Shopify-Access-Token: $SHOPIFY_TOKEN' '{url}/admin/api/{version}/orders.json?status=any&limit=10'"
        if "product" in q:
            return f"I'll check products.\n\nTOOL: ecom curl -s -H 'X-Shopify-Access-Token: $SHOPIFY_TOKEN' '{url}/admin/api/{version}/products.json?limit=10'"
        if "inventory" in q or "stock" in q:
            return f"I'll check inventory.\n\nTOOL: ecom curl -s -H 'X-Shopify-Access-Token: $SHOPIFY_TOKEN' '{url}/admin/api/{version}/inventory_levels.json'"
        if "customer" in q:
            return f"I'll check customers.\n\nTOOL: ecom curl -s -H 'X-Shopify-Access-Token: $SHOPIFY_TOKEN' '{url}/admin/api/{version}/customers.json?limit=10'"
        if "shop" in q or "store" in q:
            return f"I'll check shop info.\n\nTOOL: ecom curl -s -H 'X-Shopify-Access-Token: $SHOPIFY_TOKEN' '{url}/admin/api/{version}/shop.json'"
        return f"I'll check shop status.\n\nTOOL: ecom curl -s -H 'X-Shopify-Access-Token: $SHOPIFY_TOKEN' '{url}/admin/api/{version}/shop.json'"
