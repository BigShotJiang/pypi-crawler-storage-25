"""Mobile Backend Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class MobileBackendAgent(ShellAgent):
    """Agent for mobile backend/BaaS investigation."""

    COMMAND_PREFIX = ["firebase"]
    TOOL_NAME = "firebase"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "projects:list", "apps:list", "functions:list",
        "firestore:indexes", "hosting:sites:list",
        "auth:export", "crashlytics:symbols:list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "deploy", "functions:delete", "firestore:delete",
        "auth:import", "hosting:disable",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.platform = config.get("platform", "firebase")  # firebase, amplify, supabase
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        platform = self.platform.title()
        return f"""You are a Mobile Backend investigation agent for {platform}.

Project: {self.project or 'current'}

Available tools:
- firebase: Execute read-only Firebase commands
- firebase_write: Execute write commands (requires approval)

Investigation approach for Firebase:
1. Projects: firebase projects:list
2. Apps: firebase apps:list
3. Functions: firebase functions:list
4. Firestore: firebase firestore:indexes
5. Hosting: firebase hosting:sites:list
6. Auth: Check authentication configuration

Mobile backend components:
- Authentication: User sign-in/sign-up
- Database: Firestore/Realtime DB
- Storage: File uploads/downloads
- Functions: Serverless backend
- Hosting: Web app hosting
- Crashlytics: Crash reporting

Performance areas:
- Cold starts: Function latency
- Query performance: Database queries
- Storage bandwidth: File transfers
- Auth latency: Sign-in time

Common issues:
- Function timeouts: Long-running operations
- Database rules: Security misconfigurations
- Quota exceeded: Usage limits reached
- Auth failures: Provider configuration
- Crashlytics: Unresolved crashes
- Billing spikes: Unexpected costs"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "project" in q:
            return "I'll list projects.\n\nTOOL: firebase firebase projects:list"
        if "function" in q:
            return "I'll list functions.\n\nTOOL: firebase firebase functions:list"
        if "app" in q:
            return "I'll list apps.\n\nTOOL: firebase firebase apps:list"
        if "firestore" in q or "database" in q:
            return "I'll check Firestore indexes.\n\nTOOL: firebase firebase firestore:indexes"
        if "hosting" in q:
            return "I'll check hosting.\n\nTOOL: firebase firebase hosting:sites:list"
        if "crash" in q:
            return "I'll check Crashlytics.\n\nTOOL: firebase firebase crashlytics:symbols:list"
        return "I'll check Firebase status.\n\nTOOL: firebase firebase projects:list"
