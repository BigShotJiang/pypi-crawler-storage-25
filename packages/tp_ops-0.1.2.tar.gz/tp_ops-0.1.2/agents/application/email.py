"""Email Server Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class EmailServerAgent(ShellAgent):
    """Agent for email server investigation."""

    COMMAND_PREFIX = ["postqueue"]
    TOOL_NAME = "mail"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "-p", "postqueue -p", "mailq", "postconf", "doveadm",
        "postcat", "qshape", "postsuper -h",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "postsuper -d", "postqueue -f", "postfix stop",
        "postfix reload",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.mail_server = config.get("mail_server", "postfix")  # postfix, sendmail, exim
        self.host = config.get("host")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Email Server investigation agent.

Mail Server: {self.mail_server}
Host: {self.host or 'localhost'}

Available tools:
- mail: Execute read-only mail server commands
- mail_write: Execute write commands (requires approval)

Investigation approach for Postfix:
1. Queue Status: postqueue -p / mailq
2. Queue Shape: qshape deferred
3. Configuration: postconf -n
4. Mail Logs: tail /var/log/mail.log
5. Connection Test: telnet localhost 25

Queue analysis:
- Active queue: Messages being delivered
- Deferred queue: Messages waiting for retry
- Hold queue: Messages held for review
- Corrupt queue: Malformed messages

Log patterns to check:
- Bounces: status=bounced
- Deferred: status=deferred
- Rejected: NOQUEUE: reject
- Delivered: status=sent

Common issues:
- Queue backlog: High deferred queue count
- DNS issues: Hostname lookup failures
- Relay denied: Unauthorized relay attempts
- Connection timeouts: Remote server unreachable
- Disk full: Queue directory out of space
- Rate limiting: Being throttled by recipient servers
- SPF/DKIM failures: Authentication issues
- Blacklisting: IP on spam blacklists"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "queue" in q or "backlog" in q:
            return "I'll check mail queue.\n\nTOOL: mail postqueue -p | head -50"
        if "defer" in q:
            return "I'll check deferred queue.\n\nTOOL: mail qshape deferred"
        if "log" in q or "error" in q:
            return "I'll check mail logs.\n\nTOOL: mail tail -100 /var/log/mail.log | grep -E 'error|warning|reject|bounced|deferred'"
        if "config" in q:
            return "I'll check Postfix configuration.\n\nTOOL: mail postconf -n"
        if "bounce" in q:
            return "I'll check bounced messages.\n\nTOOL: mail grep 'status=bounced' /var/log/mail.log | tail -20"
        if "connect" in q or "test" in q:
            return "I'll test SMTP connection.\n\nTOOL: mail echo 'QUIT' | nc -w5 localhost 25"
        return "I'll check mail server status.\n\nTOOL: mail postqueue -p | head -20 && systemctl status postfix"
