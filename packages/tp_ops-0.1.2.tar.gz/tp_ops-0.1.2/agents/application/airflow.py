"""Apache Airflow Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AirflowAgent(ShellAgent):
    """Agent for Apache Airflow investigation."""

    COMMAND_PREFIX = ["airflow"]
    TOOL_NAME = "airflow"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "dags list", "dags show", "dags state", "dags report",
        "tasks list", "tasks state", "tasks test",
        "jobs list", "pools list", "variables list",
        "connections list", "providers list", "version",
        "config list", "info",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "dags trigger", "dags pause", "dags unpause", "dags delete",
        "tasks clear", "tasks run", "pools set", "pools delete",
        "variables set", "variables delete",
        "connections add", "connections delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.airflow_home = config.get("airflow_home", "~/airflow")
        self.dag_id = config.get("dag_id")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        dag_id = self.dag_id or "all"
        return f"""You are an Apache Airflow investigation agent.

AIRFLOW_HOME: {self.airflow_home}
DAG ID: {dag_id}

Available tools:
- airflow: Execute read-only Airflow CLI commands
- airflow_write: Execute write commands (requires approval)

Investigation approach:
1. DAG Status: airflow dags list
2. DAG Details: airflow dags show {dag_id if self.dag_id else '<dag_id>'}
3. Task Instances: airflow tasks list {dag_id if self.dag_id else '<dag_id>'}
4. Failed Tasks: airflow dags state {dag_id if self.dag_id else '<dag_id>'} <execution_date>
5. Scheduler Health: airflow jobs list
6. Worker Status: Check Celery/Kubernetes workers

DAG analysis:
- Execution history: Success/failure patterns
- Task duration: Identify slow tasks
- Dependencies: Upstream/downstream tasks
- Retries: Tasks requiring multiple attempts

Common issues:
- Scheduler not running: No new DAG runs scheduled
- Worker issues: Tasks stuck in queued state
- Database connection: Metadata DB unavailable
- DAG parsing errors: Syntax errors in DAG files
- Dependency failures: Upstream tasks failing
- Resource exhaustion: Workers out of memory
- Pool saturation: All pool slots occupied
- Sensor timeouts: Sensors never triggering"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        dag_id = self.dag_id or "<dag_id>"
        if "list" in q or "dag" in q:
            return "I'll list DAGs.\n\nTOOL: airflow airflow dags list"
        if "fail" in q or "error" in q:
            return f"I'll check failed tasks.\n\nTOOL: airflow airflow dags report"
        if "task" in q:
            return f"I'll list tasks.\n\nTOOL: airflow airflow tasks list {dag_id}"
        if "pool" in q:
            return "I'll check pool status.\n\nTOOL: airflow airflow pools list"
        if "job" in q or "scheduler" in q:
            return "I'll check scheduler jobs.\n\nTOOL: airflow airflow jobs list"
        if "worker" in q:
            return "I'll check worker status.\n\nTOOL: airflow airflow celery inspect active"
        return "I'll check Airflow status.\n\nTOOL: airflow airflow info && airflow dags list"
