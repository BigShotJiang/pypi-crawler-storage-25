"""Server-Side Rendered Application Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SSRAppAgent(ShellAgent):
    """Agent for SSR application investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "curl"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "-I", "-s", "-o", "-w", "--head",
        "GET", "/health", "/api",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "POST", "PUT", "DELETE", "build", "deploy",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.framework = config.get("framework", "nextjs")  # nextjs, nuxt, sveltekit
        self.app_url = config.get("app_url")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        framework = self.framework.title()
        return f"""You are an SSR Application investigation agent for {framework}.

App URL: {self.app_url or 'not specified'}

Available tools:
- curl: Execute HTTP requests
- npm: Node.js package commands
- curl_write: Execute builds (requires approval)

Investigation approach:
1. Health Check: curl {self.app_url or '<url>'}
2. Response Headers: curl -I {self.app_url or '<url>'}
3. API Routes: curl {self.app_url or '<url>'}/api/health
4. Cache Headers: Check caching behavior
5. Performance: Response times

Rendering modes:
- SSR: Server-side rendering (per request)
- SSG: Static site generation (build time)
- ISR: Incremental static regeneration
- CSR: Client-side rendering (hydration)

Performance metrics:
- TTFB: Time to first byte
- FCP: First contentful paint
- LCP: Largest contentful paint
- CLS: Cumulative layout shift

Cache headers:
- Cache-Control: Caching directives
- CDN-Cache-Control: Edge caching
- Stale-While-Revalidate: Background refresh
- ETag: Content versioning

Common issues:
- Slow TTFB: Server rendering time
- Hydration errors: Client/server mismatch
- Build failures: Compilation errors
- ISR stale: Revalidation not working
- Memory leaks: Growing memory usage
- API timeouts: Backend latency"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        url = self.app_url or "<url>"
        if "health" in q or "status" in q:
            return f"I'll check app health.\n\nTOOL: curl curl -s {url}"
        if "header" in q or "cache" in q:
            return f"I'll check response headers.\n\nTOOL: curl curl -sI {url}"
        if "time" in q or "ttfb" in q or "performance" in q:
            return f"I'll measure response time.\n\nTOOL: curl curl -w 'TTFB: %{{time_starttransfer}}s\\nTotal: %{{time_total}}s\\n' -o /dev/null -s {url}"
        if "api" in q:
            return f"I'll check API routes.\n\nTOOL: curl curl -s {url}/api/health"
        return f"I'll check SSR app.\n\nTOOL: curl curl -sI {url} | head -15"
