"""Static Site Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class StaticSiteAgent(ShellAgent):
    """Agent for static site investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "curl"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "-I", "-s", "-o", "-w", "--head", "GET",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "deploy", "delete", "purge",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.site_url = config.get("site_url")
        self.hosting = config.get("hosting", "cdn")  # cdn, s3, netlify, vercel
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        hosting = self.hosting.title()
        return f"""You are a Static Site investigation agent hosted on {hosting}.

Site URL: {self.site_url or 'not specified'}

Available tools:
- curl: Execute HTTP requests
- curl_write: Execute cache purges (requires approval)

Investigation approach:
1. Site Check: curl {self.site_url or '<url>'}
2. Headers: curl -I {self.site_url or '<url>'}
3. Cache Status: Check CDN headers
4. SSL/TLS: Certificate validation
5. Performance: Load times

CDN headers to check:
- X-Cache: HIT or MISS
- CF-Cache-Status: Cloudflare status
- Age: Cache age in seconds
- Cache-Control: Caching directives
- X-CDN: CDN identifier

Performance metrics:
- DNS lookup: Domain resolution
- TCP connect: Connection time
- TLS handshake: SSL setup
- TTFB: Time to first byte
- Transfer: Content download

Content types:
- HTML: Main pages
- CSS: Stylesheets
- JS: JavaScript bundles
- Images: Media assets
- Fonts: Web fonts

Common issues:
- Cache misses: Low hit rate
- Stale content: Old cached files
- 404 errors: Missing assets
- SSL errors: Certificate issues
- CORS: Cross-origin blocks
- Slow loading: Large assets"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        url = self.site_url or "<url>"
        if "cache" in q:
            return f"I'll check cache headers.\n\nTOOL: curl curl -sI {url} | grep -iE 'cache|age|x-cache|cf-cache'"
        if "header" in q:
            return f"I'll check all headers.\n\nTOOL: curl curl -sI {url}"
        if "ssl" in q or "tls" in q or "cert" in q:
            return f"I'll check SSL certificate.\n\nTOOL: curl echo | openssl s_client -connect {url.replace('https://', '').replace('http://', '').split('/')[0]}:443 2>/dev/null | openssl x509 -noout -dates"
        if "performance" in q or "time" in q:
            return f"I'll measure performance.\n\nTOOL: curl curl -w 'DNS: %{{time_namelookup}}s\\nConnect: %{{time_connect}}s\\nTTFB: %{{time_starttransfer}}s\\nTotal: %{{time_total}}s\\n' -o /dev/null -s {url}"
        return f"I'll check static site.\n\nTOOL: curl curl -sI {url}"
