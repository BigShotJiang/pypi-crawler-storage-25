"""WebSocket Server Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class WebSocketAgent(ShellAgent):
    """Agent for WebSocket server investigation."""

    COMMAND_PREFIX = ["websocat"]
    TOOL_NAME = "ws"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "-t", "--text", "-1", "--one-message",
        "ping", "health", "status",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "broadcast", "disconnect", "close",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.ws_url = config.get("ws_url")
        self.protocol = config.get("protocol", "ws")  # ws, wss
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a WebSocket Server investigation agent.

WebSocket URL: {self.ws_url or 'not specified'}
Protocol: {self.protocol}

Available tools:
- ws: Execute WebSocket connection tests
- ws_write: Send messages (requires approval)

Investigation approach:
1. Connection Test: websocat -t {self.ws_url or 'ws://host/path'}
2. Ping: Test connection latency
3. Message Send: Send test message
4. Subscription: Test pub/sub
5. Metrics: Check server metrics

WebSocket states:
- CONNECTING: Handshake in progress
- OPEN: Connection established
- CLOSING: Close handshake
- CLOSED: Connection terminated

Connection metrics:
- Active connections: Current WebSocket count
- Messages/second: Throughput
- Latency: Round-trip time
- Error rate: Failed connections

Message analysis:
- Frame types: Text, binary, ping, pong
- Payload size: Message bytes
- Compression: Per-message deflate
- Heartbeat: Keep-alive interval

Common issues:
- Connection drops: Network instability
- Handshake failures: Auth/protocol errors
- Memory leaks: Unclosed connections
- Scaling limits: Connection capacity
- Message queue: Backpressure
- TLS errors: Certificate issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        url = self.ws_url or "ws://localhost:8080"
        if "connect" in q or "test" in q:
            return f"I'll test WebSocket connection.\n\nTOOL: ws echo 'ping' | websocat -t -1 {url}"
        if "ping" in q or "latency" in q:
            return f"I'll test ping latency.\n\nTOOL: ws time (echo 'ping' | websocat -t -1 {url})"
        if "status" in q or "health" in q:
            return f"I'll check WebSocket health.\n\nTOOL: ws curl -I --http1.1 -H 'Connection: Upgrade' -H 'Upgrade: websocket' -H 'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==' -H 'Sec-WebSocket-Version: 13' {url.replace('ws://', 'http://').replace('wss://', 'https://')}"
        return f"I'll test WebSocket.\n\nTOOL: ws echo 'test' | websocat -t -1 {url}"
