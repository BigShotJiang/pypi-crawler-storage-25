"""Cron/Scheduler Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SchedulerAgent(ShellAgent):
    """Agent for cron and scheduler investigation."""

    COMMAND_PREFIX = ["crontab"]
    TOOL_NAME = "cron"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "-l", "systemctl list-timers", "systemctl status",
        "journalctl -u", "at -l", "batch",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "-e", "-r", "systemctl stop", "systemctl disable",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.scheduler_type = config.get("scheduler_type", "cron")  # cron, systemd, kubernetes
        self.host = config.get("host")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Cron/Scheduler investigation agent.

Scheduler Type: {self.scheduler_type}
Host: {self.host or 'localhost'}

Available tools:
- cron: View cron configurations
- systemctl: Manage systemd timers
- kubectl: Kubernetes CronJobs

Investigation approach:

For Cron:
1. User Crontabs: crontab -l
2. System Crontabs: cat /etc/crontab
3. Cron Directories: ls -la /etc/cron.d/ /etc/cron.daily/ /etc/cron.hourly/
4. Cron Logs: grep CRON /var/log/syslog

For Systemd Timers:
1. List Timers: systemctl list-timers --all
2. Timer Status: systemctl status <timer>.timer
3. Timer Logs: journalctl -u <timer>.service
4. Timer Config: systemctl cat <timer>.timer

For Kubernetes CronJobs:
1. List CronJobs: kubectl get cronjobs -A
2. CronJob Status: kubectl describe cronjob <name>
3. Job History: kubectl get jobs --selector=cronjob-name=<name>
4. Pod Logs: kubectl logs -l job-name=<job>

Common issues:
- Job failures: Check exit codes and logs
- Overlapping jobs: Jobs running longer than interval
- Missing executions: Timer not triggered
- Resource issues: Jobs hitting memory/CPU limits
- Permission errors: Wrong user/permissions
- Path issues: Commands not found in cron environment"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.scheduler_type == "systemd":
            if "list" in q or "timer" in q:
                return "I'll list systemd timers.\n\nTOOL: cron systemctl list-timers --all"
            if "log" in q or "status" in q:
                return "I'll check timer status.\n\nTOOL: cron systemctl list-timers --all && journalctl -u '*'.timer -n 50"
            return "I'll list systemd timers.\n\nTOOL: cron systemctl list-timers --all"
        elif self.scheduler_type == "kubernetes":
            if "list" in q:
                return "I'll list CronJobs.\n\nTOOL: cron kubectl get cronjobs -A"
            if "fail" in q or "error" in q:
                return "I'll check failed jobs.\n\nTOOL: cron kubectl get jobs -A --field-selector=status.successful=0"
            return "I'll list CronJobs.\n\nTOOL: cron kubectl get cronjobs -A"
        else:
            if "list" in q:
                return "I'll list cron jobs.\n\nTOOL: cron crontab -l && cat /etc/crontab 2>/dev/null"
            if "log" in q or "fail" in q:
                return "I'll check cron logs.\n\nTOOL: cron grep CRON /var/log/syslog | tail -50"
            return "I'll check cron configuration.\n\nTOOL: cron crontab -l && ls -la /etc/cron.d/"
