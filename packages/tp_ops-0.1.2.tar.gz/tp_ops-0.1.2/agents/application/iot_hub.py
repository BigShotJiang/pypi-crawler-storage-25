"""IoT Hub Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class IoTHubAgent(ShellAgent):
    """Agent for IoT hub investigation."""

    COMMAND_PREFIX = ["az", "iot", "hub"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "show", "list", "device-identity list", "device-identity show",
        "device-twin show", "query", "monitor-events",
        "connection-string show", "statistics",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "device-identity create", "device-identity delete",
        "device-twin update", "invoke-device-method",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.hub_name = config.get("hub_name")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        hub = self.hub_name or "default"
        return f"""You are an IoT Hub investigation agent for '{hub}'.

Resource Group: {self.resource_group or 'default'}

Available tools:
- az: Execute read-only IoT Hub commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Hub Info: az iot hub show --name {hub}
2. Device List: az iot hub device-identity list --hub-name {hub}
3. Device Twin: az iot hub device-twin show --hub-name {hub} --device-id <device>
4. Query: az iot hub query --hub-name {hub} --query-command "SELECT * FROM devices"
5. Monitor: az iot hub monitor-events --hub-name {hub}
6. Statistics: az iot hub statistics --hub-name {hub}

Device states:
- Enabled: Device can connect
- Disabled: Device blocked
- Connected: Currently online
- Disconnected: Offline

Telemetry analysis:
- Message count: Messages per device
- Frequency: Message rate
- Payload size: Data volume
- Latency: Message delivery time

Common issues:
- Device offline: Connection failures
- Throttling: Too many messages
- Twin sync: Desired vs reported state
- Authentication: SAS token issues
- Routing: Message not reaching endpoint
- Quota limits: Daily message limit"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        hub = self.hub_name or "<hub-name>"
        if "device" in q and "list" in q:
            return f"I'll list devices.\n\nTOOL: az az iot hub device-identity list --hub-name {hub} --output json"
        if "twin" in q:
            return f"I'll check device twin.\n\nTOOL: az az iot hub device-twin show --hub-name {hub} --device-id <device-id> --output json"
        if "monitor" in q or "event" in q:
            return f"I'll monitor events.\n\nTOOL: az az iot hub monitor-events --hub-name {hub} --timeout 10"
        if "query" in q:
            return f"I'll query devices.\n\nTOOL: az az iot hub query --hub-name {hub} --query-command \"SELECT * FROM devices WHERE connectionState = 'Disconnected'\" --output json"
        if "statistic" in q:
            return f"I'll check statistics.\n\nTOOL: az az iot hub show --name {hub} --query 'properties.cloudToDevice' --output json"
        return f"I'll check hub info.\n\nTOOL: az az iot hub show --name {hub} --output json"
