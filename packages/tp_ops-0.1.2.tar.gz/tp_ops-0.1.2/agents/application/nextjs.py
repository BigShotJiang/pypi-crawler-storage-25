"""Next.js/Vercel Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NextJSAgent(ShellAgent):
    """Agent for Next.js/Vercel investigation."""

    COMMAND_PREFIX = ["vercel"]
    TOOL_NAME = "vercel"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "list", "ls", "inspect", "logs", "env ls",
        "domains ls", "dns ls", "projects ls",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "deploy", "remove", "rm", "env add", "env rm",
        "domains add", "domains rm", "alias",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.project_name = config.get("project_name")
        self.project_path = config.get("project_path", ".")
        self.team = config.get("team")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["vercel"]
        if self.team:
            prefix.extend(["--scope", self.team])
        return prefix

    def _get_system_prompt(self) -> str:
        project = self.project_name or "current"
        return f"""You are a Next.js/Vercel investigation agent for project '{project}'.

Project Path: {self.project_path}
Team: {self.team or 'personal'}

Available tools:
- vercel: Execute read-only Vercel CLI commands
- npm: Execute npm commands for local analysis
- vercel_write: Execute write commands (requires approval)

Investigation approach:
1. Deployments: vercel ls
2. Deployment Info: vercel inspect <url>
3. Logs: vercel logs <url>
4. Environment: vercel env ls
5. Domains: vercel domains ls
6. Build Logs: vercel logs <url> --build

Local analysis:
- Build: npm run build
- Type check: npm run type-check
- Lint: npm run lint
- Bundle analysis: npm run analyze

Performance checks:
- Bundle size: Check .next/analyze
- Edge functions: Check middleware
- Static generation: Check getStaticProps
- Server components: Check RSC payload

Common issues:
- Build failures: TypeScript/ESLint errors
- Runtime errors: Check function logs
- Edge timeout: Edge functions > 30s
- Cold starts: Serverless function latency
- Memory limits: Function exceeding 1024MB
- API rate limits: Too many requests
- ISR issues: Stale revalidation
- Image optimization: unoptimized images"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        project = self.project_name or "<project>"
        if "deploy" in q or "list" in q:
            return "I'll list deployments.\n\nTOOL: vercel vercel ls"
        if "log" in q:
            return f"I'll check deployment logs.\n\nTOOL: vercel vercel logs {project} --follow=false"
        if "env" in q or "environment" in q:
            return "I'll check environment variables.\n\nTOOL: vercel vercel env ls"
        if "domain" in q:
            return "I'll list domains.\n\nTOOL: vercel vercel domains ls"
        if "build" in q:
            return f"I'll check build logs.\n\nTOOL: vercel vercel logs {project} --build"
        if "inspect" in q or "detail" in q:
            return f"I'll inspect deployment.\n\nTOOL: vercel vercel inspect {project}"
        if "error" in q or "fail" in q:
            return f"I'll check for errors.\n\nTOOL: vercel vercel logs {project} | grep -i error"
        return f"I'll check Vercel project status.\n\nTOOL: vercel vercel ls && vercel inspect {project}"
