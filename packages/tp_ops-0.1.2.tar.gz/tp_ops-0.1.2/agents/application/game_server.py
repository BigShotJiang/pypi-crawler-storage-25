"""Game Server Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GameServerAgent(ShellAgent):
    """Agent for game server investigation."""

    COMMAND_PREFIX = []
    TOOL_NAME = "game"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "status", "list", "players", "metrics",
        "logs", "version", "info",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "restart", "stop", "kick", "ban",
        "update", "backup",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.game_type = config.get("game_type", "generic")  # minecraft, unity, unreal
        self.server_host = config.get("server_host")
        self.rcon_port = config.get("rcon_port")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        game = self.game_type.title()
        return f"""You are a Game Server investigation agent for {game}.

Server Host: {self.server_host or 'localhost'}
RCON Port: {self.rcon_port or 'not configured'}

Available tools:
- game: Execute read-only game server commands
- game_write: Execute admin commands (requires approval)

Investigation approach:
1. Server Status: Check server health
2. Player Count: Current players online
3. Performance: TPS, memory, CPU usage
4. Logs: Recent server logs
5. World Stats: Game world information
6. Network: Connection quality

Performance metrics:
- TPS (Ticks Per Second): Game loop performance
- Memory usage: RAM consumption
- CPU usage: Processor load
- Network latency: Player ping times
- Chunk loading: World generation speed

Matchmaking (if applicable):
- Queue times: Player wait times
- Match quality: Skill-based matching
- Region distribution: Player locations
- Session duration: Average game length

Common issues:
- Low TPS: Server lag
- Memory leaks: Growing memory usage
- Player disconnects: Network issues
- Crash loops: Repeated crashes
- World corruption: Save file issues
- Anti-cheat: Detection failures"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "status" in q or "health" in q:
            return "I'll check server status.\n\nTOOL: game rcon status"
        if "player" in q:
            return "I'll list players.\n\nTOOL: game rcon list"
        if "tps" in q or "performance" in q:
            return "I'll check TPS.\n\nTOOL: game rcon tps"
        if "memory" in q:
            return "I'll check memory.\n\nTOOL: game rcon memory"
        if "log" in q:
            return "I'll check logs.\n\nTOOL: game tail -100 /var/log/gameserver/latest.log"
        return "I'll check server status.\n\nTOOL: game rcon status"
