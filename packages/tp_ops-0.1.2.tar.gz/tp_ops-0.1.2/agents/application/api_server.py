"""REST API Server Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class APIServerAgent(ShellAgent):
    """Agent for REST API server investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "curl"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "-I", "-s", "-o", "-w", "--head", "GET",
        "/health", "/status", "/metrics", "/info",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "POST", "PUT", "DELETE", "PATCH",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.api_url = config.get("api_url")
        self.api_type = config.get("api_type", "rest")  # rest, graphql, grpc
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        api_type = self.api_type.upper()
        return f"""You are a {api_type} API Server investigation agent.

API URL: {self.api_url or 'not specified'}

Available tools:
- curl: Execute HTTP requests
- curl_write: Execute mutating requests (requires approval)

Investigation approach:
1. Health Check: curl {self.api_url or '<url>'}/health
2. Response Time: curl -w '%{{time_total}}' -o /dev/null -s {self.api_url or '<url>'}
3. Headers: curl -I {self.api_url or '<url>'}
4. Metrics: curl {self.api_url or '<url>'}/metrics
5. OpenAPI: curl {self.api_url or '<url>'}/openapi.json

HTTP analysis:
- Status codes: 2xx success, 4xx client error, 5xx server error
- Response time: Total request duration
- Headers: Content-Type, Cache-Control, CORS
- Body size: Response payload size

Performance metrics:
- Latency: P50, P95, P99
- Throughput: Requests per second
- Error rate: 4xx/5xx percentage
- Availability: Uptime percentage

Common issues:
- 502/503/504: Upstream/timeout errors
- Slow responses: Database or external calls
- Rate limiting: 429 Too Many Requests
- Auth failures: 401/403 errors
- CORS issues: Cross-origin blocks
- Payload errors: Invalid request/response"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        url = self.api_url or "<url>"
        if "health" in q or "status" in q:
            return f"I'll check health endpoint.\n\nTOOL: curl curl -s {url}/health"
        if "time" in q or "latency" in q or "slow" in q:
            return f"I'll measure response time.\n\nTOOL: curl curl -w 'Time: %{{time_total}}s\\nStatus: %{{http_code}}\\n' -o /dev/null -s {url}"
        if "header" in q:
            return f"I'll check headers.\n\nTOOL: curl curl -sI {url}"
        if "metric" in q:
            return f"I'll check metrics.\n\nTOOL: curl curl -s {url}/metrics"
        if "openapi" in q or "swagger" in q:
            return f"I'll get OpenAPI spec.\n\nTOOL: curl curl -s {url}/openapi.json | head -50"
        return f"I'll check API health.\n\nTOOL: curl curl -sI {url} | head -10"
