"""Web Application Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class WebAppAgent(ShellAgent):
    """Agent for web application investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "curl"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "-I", "-s", "-o", "-w", "--head",
        "php artisan", "python manage.py", "rails", "npm run",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "php artisan migrate", "python manage.py migrate",
        "rails db:migrate", "npm run build",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.framework = config.get("framework", "generic")  # laravel, django, rails, nodejs
        self.app_url = config.get("app_url")
        self.app_path = config.get("app_path")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        framework = self.framework.title()
        return f"""You are a Web Application investigation agent for a {framework} application.

App URL: {self.app_url or 'not specified'}
App Path: {self.app_path or 'not specified'}

Available tools:
- curl: HTTP requests to check endpoints
- app_cmd: Framework-specific commands
- log: Application log analysis

Investigation approach:
1. Health Check: curl -I {self.app_url or '<url>'}
2. Response Time: curl -w '%{{time_total}}' -o /dev/null -s {self.app_url or '<url>'}
3. Error Pages: Check 4xx/5xx responses
4. Logs: Tail application logs

Framework-specific commands:

Laravel:
- php artisan route:list
- php artisan queue:work --once
- php artisan config:cache
- Storage: storage/logs/laravel.log

Django:
- python manage.py check
- python manage.py showmigrations
- python manage.py dbshell
- Logs: Check LOGGING config

Rails:
- rails routes
- rails db:migrate:status
- rails console
- Logs: log/production.log

Node.js/Express:
- npm run start
- pm2 status
- pm2 logs
- Logs: Check logging middleware

Common issues:
- 502/503 errors: Application crashed or unavailable
- Slow responses: Database queries, external API calls
- Memory leaks: Growing memory usage over time
- Connection errors: Database or cache connectivity
- Session issues: Redis/session store problems"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        url = self.app_url or "<url>"
        if "health" in q or "status" in q or "check" in q:
            return f"I'll check application health.\n\nTOOL: curl curl -sI {url} | head -10"
        if "response" in q or "time" in q or "slow" in q:
            return f"I'll measure response time.\n\nTOOL: curl curl -w 'Time: %{{time_total}}s\\n' -o /dev/null -s {url}"
        if "log" in q or "error" in q:
            return "I'll check application logs.\n\nTOOL: curl tail -100 storage/logs/laravel.log 2>/dev/null || tail -100 log/production.log 2>/dev/null || echo 'Check framework-specific log path'"
        if "route" in q:
            return "I'll list routes.\n\nTOOL: curl php artisan route:list 2>/dev/null || python manage.py show_urls 2>/dev/null || rails routes 2>/dev/null"
        return f"I'll check the application.\n\nTOOL: curl curl -sI {url}"
