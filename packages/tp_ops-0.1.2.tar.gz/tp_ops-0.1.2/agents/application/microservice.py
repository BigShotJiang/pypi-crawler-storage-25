"""Microservice Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class MicroserviceAgent(ShellAgent):
    """Agent for microservice investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "svc"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "GET", "/health", "/ready", "/live", "/metrics",
        "/info", "/env", "/actuator",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "POST", "PUT", "DELETE", "/shutdown", "/restart",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.service_name = config.get("service_name")
        self.service_url = config.get("service_url")
        self.framework = config.get("framework", "generic")  # spring, fastapi, express
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        framework = self.framework.title()
        service = self.service_name or "service"
        return f"""You are a Microservice investigation agent for '{service}'.

Framework: {framework}
Service URL: {self.service_url or 'not specified'}

Available tools:
- svc: Execute read-only service calls
- svc_write: Execute mutations (requires approval)

Investigation approach:
1. Health: GET /health or /actuator/health
2. Readiness: GET /ready or /actuator/health/readiness
3. Liveness: GET /live or /actuator/health/liveness
4. Metrics: GET /metrics or /actuator/prometheus
5. Info: GET /info or /actuator/info

Health check patterns:
- Spring Boot: /actuator/health
- FastAPI: /health
- Express: /health or /healthz
- gRPC: grpc.health.v1.Health/Check

Observability endpoints:
- /metrics: Prometheus format
- /traces: Distributed tracing
- /logs: Log aggregation
- /debug/pprof: Go profiling

Dependency checks:
- Database connectivity
- Cache availability
- External API health
- Message queue status

Common issues:
- Dependency failures: Downstream services
- Connection exhaustion: Pool limits
- Memory leaks: Growing heap
- Circuit breaker: Open state
- Rate limiting: Throttled requests
- Timeout cascades: Slow dependencies"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        url = self.service_url or "<service-url>"
        if "health" in q:
            return f"I'll check health.\n\nTOOL: svc curl -s {url}/health || curl -s {url}/actuator/health"
        if "ready" in q:
            return f"I'll check readiness.\n\nTOOL: svc curl -s {url}/ready || curl -s {url}/actuator/health/readiness"
        if "live" in q:
            return f"I'll check liveness.\n\nTOOL: svc curl -s {url}/live || curl -s {url}/actuator/health/liveness"
        if "metric" in q:
            return f"I'll check metrics.\n\nTOOL: svc curl -s {url}/metrics || curl -s {url}/actuator/prometheus"
        if "info" in q:
            return f"I'll get service info.\n\nTOOL: svc curl -s {url}/info || curl -s {url}/actuator/info"
        if "env" in q:
            return f"I'll check environment.\n\nTOOL: svc curl -s {url}/actuator/env"
        return f"I'll check service health.\n\nTOOL: svc curl -s {url}/health"
