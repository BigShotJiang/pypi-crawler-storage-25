"""WordPress Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class WordPressAgent(ShellAgent):
    """Agent for WordPress investigation."""

    COMMAND_PREFIX = ["wp"]
    TOOL_NAME = "wp"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "core version", "plugin list", "theme list", "user list",
        "option list", "db check", "cache type", "cron event list",
        "post list", "site list", "config list", "transient list",
        "rewrite list", "media list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "core update", "plugin update", "plugin activate", "plugin deactivate",
        "theme activate", "user create", "user delete",
        "db repair", "cache flush", "transient delete",
        "rewrite flush", "config set",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.wp_path = config.get("wp_path", "/var/www/html")
        self.site_url = config.get("site_url")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["wp", f"--path={self.wp_path}"]

    def _get_system_prompt(self) -> str:
        return f"""You are a WordPress investigation agent.

WordPress Path: {self.wp_path}
Site URL: {self.site_url or 'not specified'}

Available tools:
- wp: Execute read-only WP-CLI commands
- wp_write: Execute write commands (requires approval)

Investigation approach:
1. Core Version: wp core version
2. Plugin Status: wp plugin list
3. Theme Status: wp theme list
4. Database Check: wp db check
5. Cron Events: wp cron event list
6. Cache Type: wp cache type

Health checks:
- Core updates: wp core check-update
- Plugin updates: wp plugin list --update=available
- Database integrity: wp db check
- File permissions: ls -la wp-config.php
- Debug mode: wp config get WP_DEBUG

Performance analysis:
- Object cache: wp cache type (should be redis/memcached)
- Transients: wp transient list --format=count
- Autoload options: wp option list --autoload=yes --format=count
- Cron health: wp cron event list

Common issues:
- White screen: Fatal PHP error
- Plugin conflicts: Deactivate plugins to isolate
- Memory exhaustion: WP_MEMORY_LIMIT too low
- Database corruption: wp db repair
- Slow queries: Check slow_query_log
- Cron not running: wp cron test
- Cache issues: Stale or corrupted cache
- .htaccess issues: Missing rewrite rules"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "version" in q:
            return "I'll check WordPress version.\n\nTOOL: wp wp core version --extra"
        if "plugin" in q:
            return "I'll list plugins.\n\nTOOL: wp wp plugin list"
        if "theme" in q:
            return "I'll list themes.\n\nTOOL: wp wp theme list"
        if "database" in q or "db" in q:
            return "I'll check database.\n\nTOOL: wp wp db check"
        if "cron" in q:
            return "I'll check cron events.\n\nTOOL: wp wp cron event list"
        if "cache" in q:
            return "I'll check cache status.\n\nTOOL: wp wp cache type"
        if "update" in q:
            return "I'll check for updates.\n\nTOOL: wp wp core check-update && wp plugin list --update=available"
        if "config" in q:
            return "I'll check configuration.\n\nTOOL: wp wp config list"
        return "I'll check WordPress status.\n\nTOOL: wp wp core version && wp plugin list --status=active && wp cache type"
