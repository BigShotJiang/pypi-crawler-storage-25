"""ML Platform Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class MLPlatformAgent(ShellAgent):
    """Agent for ML platform investigation."""

    COMMAND_PREFIX = ["az", "ml"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "workspace list", "workspace show", "compute list",
        "job list", "job show", "model list", "model show",
        "endpoint list", "endpoint show", "data list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "job create", "job cancel", "model delete",
        "endpoint delete", "compute delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.platform = config.get("platform", "azure")  # azure, sagemaker, vertex
        self.workspace = config.get("workspace")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        platform = self.platform.title()
        return f"""You are an ML Platform investigation agent for {platform} ML.

Workspace: {self.workspace or 'default'}
Resource Group: {self.resource_group or 'default'}

Available tools:
- az: Execute read-only Azure ML commands
- az_write: Execute write commands (requires approval)

Investigation approach for Azure ML:
1. Workspace: az ml workspace show
2. Compute: az ml compute list
3. Jobs: az ml job list
4. Models: az ml model list
5. Endpoints: az ml endpoint list
6. Data: az ml data list

Job states:
- Running: Training in progress
- Completed: Successfully finished
- Failed: Error occurred
- Canceled: Manually stopped

Compute types:
- Compute instance: Dev/test VMs
- Compute cluster: Training clusters
- Inference cluster: AKS endpoints
- Attached compute: External resources

Common issues:
- Job failures: Training errors
- Quota exceeded: Compute limits
- Model drift: Performance degradation
- Endpoint errors: Inference failures
- Data issues: Missing or corrupt data
- Scaling problems: Endpoint capacity"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        ws = self.workspace or "<workspace>"
        rg = self.resource_group or "<resource-group>"
        if "job" in q:
            return f"I'll list jobs.\n\nTOOL: az az ml job list --workspace-name {ws} --resource-group {rg} --output json"
        if "model" in q:
            return f"I'll list models.\n\nTOOL: az az ml model list --workspace-name {ws} --resource-group {rg} --output json"
        if "endpoint" in q:
            return f"I'll list endpoints.\n\nTOOL: az az ml endpoint list --workspace-name {ws} --resource-group {rg} --output json"
        if "compute" in q:
            return f"I'll list compute.\n\nTOOL: az az ml compute list --workspace-name {ws} --resource-group {rg} --output json"
        if "data" in q:
            return f"I'll list data assets.\n\nTOOL: az az ml data list --workspace-name {ws} --resource-group {rg} --output json"
        return f"I'll check workspace.\n\nTOOL: az az ml workspace show --name {ws} --resource-group {rg} --output json"
