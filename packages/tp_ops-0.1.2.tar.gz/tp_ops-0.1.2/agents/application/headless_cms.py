"""Headless CMS Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class HeadlessCMSAgent(ShellAgent):
    """Agent for headless CMS investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "cms"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "GET", "/api", "/content", "/assets",
        "entries", "content-types", "spaces",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "POST", "PUT", "DELETE", "publish", "unpublish",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cms_type = config.get("cms_type", "contentful")  # contentful, strapi, sanity
        self.api_url = config.get("api_url")
        self.space_id = config.get("space_id")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        cms = self.cms_type.title()
        return f"""You are a Headless CMS investigation agent for {cms}.

API URL: {self.api_url or 'not specified'}
Space ID: {self.space_id or 'default'}

Available tools:
- cms: Execute read-only CMS API calls
- cms_write: Execute write operations (requires approval)

Investigation approach for Contentful:
1. Space Info: GET /spaces/{{space_id}}
2. Content Types: GET /spaces/{{space_id}}/content_types
3. Entries: GET /spaces/{{space_id}}/entries
4. Assets: GET /spaces/{{space_id}}/assets
5. Webhooks: GET /spaces/{{space_id}}/webhook_definitions

For Strapi:
1. Content Types: GET /content-types
2. Entries: GET /api/{{content-type}}
3. Media: GET /api/upload/files
4. Users: GET /api/users

For Sanity:
1. Datasets: GET /projects/{{project}}/datasets
2. Query: POST /query/{{dataset}}
3. Assets: GET /assets

API analysis:
- Rate limits: Request quotas
- Response times: API latency
- Payload sizes: Content volume
- Caching: CDN behavior

Common issues:
- Rate limiting: Too many requests
- Stale content: Cache invalidation
- Missing assets: Broken references
- Webhook failures: Delivery errors
- API errors: Schema mismatches
- Large payloads: Performance impact"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.cms_type == "contentful":
            space = self.space_id or "<space-id>"
            if "content type" in q or "model" in q:
                return f"I'll list content types.\n\nTOOL: cms curl -s -H 'Authorization: Bearer $CMS_TOKEN' 'https://api.contentful.com/spaces/{space}/content_types'"
            if "entry" in q or "content" in q:
                return f"I'll list entries.\n\nTOOL: cms curl -s -H 'Authorization: Bearer $CMS_TOKEN' 'https://cdn.contentful.com/spaces/{space}/entries?limit=10'"
            if "asset" in q or "media" in q:
                return f"I'll list assets.\n\nTOOL: cms curl -s -H 'Authorization: Bearer $CMS_TOKEN' 'https://cdn.contentful.com/spaces/{space}/assets?limit=10'"
            return f"I'll check space info.\n\nTOOL: cms curl -s -H 'Authorization: Bearer $CMS_TOKEN' 'https://api.contentful.com/spaces/{space}'"
        return "I'll check CMS status.\n\nTOOL: cms curl -s $CMS_URL/api/health"
