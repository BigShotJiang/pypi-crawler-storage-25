"""Application investigation agents."""

from agents.application.web_app import WebAppAgent
from agents.application.scheduler import SchedulerAgent
from agents.application.airflow import AirflowAgent
from agents.application.email import EmailServerAgent
from agents.application.wordpress import WordPressAgent
from agents.application.nextjs import NextJSAgent
from agents.application.mobile_backend import MobileBackendAgent
from agents.application.game_server import GameServerAgent
from agents.application.iot_hub import IoTHubAgent
from agents.application.ml_platform import MLPlatformAgent
from agents.application.api_server import APIServerAgent
from agents.application.websocket import WebSocketAgent
from agents.application.ssr_app import SSRAppAgent
from agents.application.static_site import StaticSiteAgent
from agents.application.headless_cms import HeadlessCMSAgent
from agents.application.ecommerce import EcommerceAgent
from agents.application.microservice import MicroserviceAgent

__all__ = [
    "WebAppAgent",
    "SchedulerAgent",
    "AirflowAgent",
    "EmailServerAgent",
    "WordPressAgent",
    "NextJSAgent",
    "MobileBackendAgent",
    "GameServerAgent",
    "IoTHubAgent",
    "MLPlatformAgent",
    "APIServerAgent",
    "WebSocketAgent",
    "SSRAppAgent",
    "StaticSiteAgent",
    "HeadlessCMSAgent",
    "EcommerceAgent",
    "MicroserviceAgent",
]
