"""GitLab CI Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GitLabCIAgent(ShellAgent):
    """Agent for GitLab CI pipeline investigation."""

    COMMAND_PREFIX = ["glab"]
    TOOL_NAME = "glab"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "ci list", "ci view", "ci status", "ci trace",
        "pipeline list", "pipeline view", "pipeline status",
        "job list", "job view", "job trace",
        "variable list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "ci run", "ci retry", "ci cancel",
        "pipeline run", "pipeline delete", "pipeline retry",
        "variable set", "variable delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.project = config.get("project")
        self.pipeline_id = config.get("pipeline_id")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["glab"]
        if self.project:
            prefix.extend(["-R", self.project])
        return prefix

    def _get_system_prompt(self) -> str:
        project = self.project or "current project"
        return f"""You are a GitLab CI investigation agent for '{project}'.

Available tools:
- glab: Execute read-only GitLab CLI commands
- glab_write: Execute write commands (requires approval)

Investigation approach:
1. Pipelines: glab ci list
2. Pipeline Status: glab ci status
3. Pipeline View: glab ci view <id>
4. Job Trace: glab ci trace
5. Variables: glab variable list

Common issues:
- Job failures: Check job trace for errors
- Runner issues: Shared runners busy, tags not matching
- Artifacts: Expiration, download failures
- Dependencies: Job dependency failures
- Cache: Cache key issues, expiration"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "fail" in q or "error" in q:
            return "I'll check CI status.\n\nTOOL: glab ci status"
        if "trace" in q or "log" in q:
            return "I'll check job trace.\n\nTOOL: glab ci trace"
        if "pipeline" in q:
            return "I'll list pipelines.\n\nTOOL: glab ci list"
        return "I'll check CI status.\n\nTOOL: glab ci status"
