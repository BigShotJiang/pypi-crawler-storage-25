"""Flux CD Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class FluxAgent(ShellAgent):
    """Agent for Flux CD GitOps investigation."""

    COMMAND_PREFIX = ["flux"]
    TOOL_NAME = "flux"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "get all", "get sources", "get kustomizations", "get helmreleases",
        "get receivers", "get alerts", "get providers",
        "logs", "events", "stats", "tree",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "reconcile", "suspend", "resume", "delete",
        "create", "bootstrap", "uninstall",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace", "flux-system")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["flux"]
        if self.kubeconfig:
            prefix.extend(["--kubeconfig", self.kubeconfig])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Flux CD investigation agent for namespace '{self.namespace}'.

Available tools:
- flux: Execute read-only Flux commands
- flux_write: Execute write commands (requires approval)

Investigation approach:
1. All Resources: flux get all -A
2. Sources: flux get sources all -A
3. Kustomizations: flux get kustomizations -A
4. Helm Releases: flux get helmreleases -A
5. Events: flux events
6. Logs: flux logs

Common issues:
- Reconciliation failures: Source or apply errors
- Source issues: Git auth, branch not found
- Kustomization errors: Patch or overlay failures
- Helm release failures: Values errors, chart issues
- Suspended resources: Accidentally suspended"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "source" in q:
            return "I'll check sources.\n\nTOOL: flux get sources all -A"
        if "kustomization" in q:
            return "I'll check kustomizations.\n\nTOOL: flux get kustomizations -A"
        if "helm" in q:
            return "I'll check helm releases.\n\nTOOL: flux get helmreleases -A"
        if "fail" in q or "error" in q:
            return "I'll check events.\n\nTOOL: flux events"
        return "I'll check all resources.\n\nTOOL: flux get all -A"
