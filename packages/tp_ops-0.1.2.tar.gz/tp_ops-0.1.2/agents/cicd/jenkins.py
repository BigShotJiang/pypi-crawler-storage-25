"""Jenkins Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class JenkinsAgent(ShellAgent):
    """Agent for Jenkins investigation."""

    COMMAND_PREFIX = ["jenkins-cli"]
    TOOL_NAME = "jenkins"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-jobs", "get-job", "console", "list-builds",
        "list-plugins", "who-am-i", "version",
        "get-node", "list-credentials",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "build", "stop-builds", "delete-job", "delete-builds",
        "disable-job", "enable-job", "restart", "safe-restart",
        "install-plugin", "uninstall-plugin",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.url = config.get("url", "http://localhost:8080")
        self.job = config.get("job")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["jenkins-cli", "-s", self.url]

    def _get_system_prompt(self) -> str:
        return f"""You are a Jenkins investigation agent for {self.url}.

Available tools:
- jenkins: Execute read-only Jenkins CLI commands
- jenkins_write: Execute write commands (requires approval)

Investigation approach:
1. Jobs: jenkins-cli list-jobs
2. Job Details: jenkins-cli get-job <job>
3. Console Output: jenkins-cli console <job> <build>
4. Plugins: jenkins-cli list-plugins
5. Nodes: jenkins-cli get-node <node>

Common issues:
- Build failures: Check console output
- Plugin issues: Conflicts, outdated versions
- Executor starvation: Not enough executors
- Disk space: Workspace and artifacts filling up
- Orphaned jobs: Jobs not running, stale configs"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        job = self.job or "<job>"
        if "fail" in q or "error" in q or "console" in q:
            return f"I'll check console output.\n\nTOOL: jenkins console {job} lastBuild"
        if "plugin" in q:
            return "I'll check plugins.\n\nTOOL: jenkins list-plugins"
        if "node" in q or "executor" in q:
            return "I'll check nodes.\n\nTOOL: jenkins get-node master"
        return "I'll list jobs.\n\nTOOL: jenkins list-jobs"
