"""Azure DevOps Pipelines Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureDevOpsAgent(ShellAgent):
    """Agent for Azure DevOps pipeline investigation."""

    COMMAND_PREFIX = ["az", "pipelines"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list", "show", "runs list", "runs show",
        "build list", "build show", "release list", "release show",
        "variable list", "variable-group list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create", "delete", "update", "run",
        "variable create", "variable delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.organization = config.get("organization")
        self.project = config.get("project")
        self.pipeline_id = config.get("pipeline_id")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["az", "pipelines"]
        if self.organization:
            prefix.extend(["--organization", f"https://dev.azure.com/{self.organization}"])
        if self.project:
            prefix.extend(["--project", self.project])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure DevOps Pipelines investigation agent.

Organization: {self.organization}
Project: {self.project}

Available tools:
- az: Execute read-only Azure DevOps CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Pipelines: az pipelines list
2. Recent Runs: az pipelines runs list --pipeline-id <id>
3. Run Details: az pipelines runs show --id <run-id>
4. Builds: az pipelines build list
5. Variables: az pipelines variable list --pipeline-id <id>

Common issues:
- Build failures: Check logs, agent issues
- Agent pool: Agents offline or overloaded
- Artifact issues: Publish/download failures
- Gate failures: Approval or check failures
- Variable groups: Permission or value issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "fail" in q or "error" in q:
            return "I'll check failed runs.\n\nTOOL: az pipelines runs list --status failed"
        if "run" in q:
            return "I'll list recent runs.\n\nTOOL: az pipelines runs list"
        if "build" in q:
            return "I'll list builds.\n\nTOOL: az pipelines build list"
        return "I'll list pipelines.\n\nTOOL: az pipelines list"
