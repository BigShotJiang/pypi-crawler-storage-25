"""Spinnaker Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SpinnakerAgent(ShellAgent):
    """Agent for Spinnaker deployment investigation."""

    COMMAND_PREFIX = ["spin"]
    TOOL_NAME = "spin"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "application list", "application get",
        "pipeline list", "pipeline get", "pipeline execution list",
        "pipeline execution get",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "application save", "application delete",
        "pipeline save", "pipeline delete", "pipeline execute",
        "pipeline execution cancel",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.gate_endpoint = config.get("gate_endpoint")
        self.application = config.get("application")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["spin"]
        if self.gate_endpoint:
            prefix.extend(["--gate-endpoint", self.gate_endpoint])
        return prefix

    def _get_system_prompt(self) -> str:
        app = self.application or "all"
        return f"""You are a Spinnaker deployment investigation agent for application '{app}'.

Gate Endpoint: {self.gate_endpoint}

Available tools:
- spin: Execute read-only Spinnaker CLI commands
- spin_write: Execute write commands (requires approval)

Investigation approach:
1. Applications: spin application list
2. App Details: spin application get --application {app}
3. Pipelines: spin pipeline list --application {app}
4. Executions: spin pipeline execution list --application {app}
5. Execution Details: spin pipeline execution get --id <id>

Common issues:
- Pipeline failures: Stage errors, timeouts
- Deployment strategy: Canary, blue-green issues
- Approval gates: Stuck waiting for approval
- Cloud provider: Account/region issues
- Triggers: Webhook, docker trigger problems"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        app = self.application or "<app>"
        if "execution" in q or "run" in q:
            return f"I'll check executions.\n\nTOOL: spin pipeline execution list --application {app}"
        if "pipeline" in q:
            return f"I'll list pipelines.\n\nTOOL: spin pipeline list --application {app}"
        if "fail" in q or "error" in q:
            return f"I'll check recent executions.\n\nTOOL: spin pipeline execution list --application {app}"
        return "I'll list applications.\n\nTOOL: spin application list"
