"""Docker Build Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class DockerBuildAgent(ShellAgent):
    """Agent for Docker build pipeline investigation."""

    COMMAND_PREFIX = ["docker"]
    TOOL_NAME = "docker"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "images", "image ls", "image inspect", "image history",
        "buildx ls", "buildx inspect", "buildx imagetools inspect",
        "system df", "system info",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "build", "buildx build", "push", "tag",
        "rmi", "image rm", "image prune",
        "system prune", "builder prune",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.image = config.get("image")
        self.dockerfile = config.get("dockerfile", "Dockerfile")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        image = self.image or "unknown"
        return f"""You are a Docker build investigation agent for image '{image}'.

Available tools:
- docker: Execute read-only Docker commands
- docker_write: Execute write commands (requires approval)

Investigation approach:
1. Images: docker images
2. Image History: docker image history {image}
3. Image Inspect: docker image inspect {image}
4. Build Cache: docker system df
5. Buildx Builders: docker buildx ls
6. System Info: docker system info

Common issues:
- Build failures: Layer errors, missing dependencies
- Cache misses: Layer order, COPY invalidation
- Image size: Large layers, unnecessary files
- Multi-stage: Build stage issues
- Platform: Multi-arch build problems"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        image = self.image or "<image>"
        if "history" in q or "layer" in q:
            return f"I'll check image history.\n\nTOOL: docker image history {image}"
        if "size" in q or "cache" in q:
            return "I'll check system disk usage.\n\nTOOL: docker system df -v"
        if "inspect" in q:
            return f"I'll inspect the image.\n\nTOOL: docker image inspect {image}"
        if "buildx" in q:
            return "I'll check buildx.\n\nTOOL: docker buildx ls"
        return "I'll list images.\n\nTOOL: docker images"
