"""Helm Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class HelmAgent(ShellAgent):
    """Agent for Helm release investigation."""

    COMMAND_PREFIX = ["helm"]
    TOOL_NAME = "helm"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list", "status", "history", "get all", "get values",
        "get manifest", "get notes", "get hooks",
        "search repo", "search hub", "show chart", "show values",
        "repo list", "template",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "install", "upgrade", "uninstall", "rollback",
        "repo add", "repo remove", "repo update",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.release = config.get("release")
        self.namespace = config.get("namespace", "default")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["helm"]
        if self.kubeconfig:
            prefix.extend(["--kubeconfig", self.kubeconfig])
        return prefix

    def _get_system_prompt(self) -> str:
        release = self.release or "all"
        return f"""You are a Helm release investigation agent for release '{release}'.

Namespace: {self.namespace}

Available tools:
- helm: Execute read-only Helm commands
- helm_write: Execute write commands (requires approval)

Investigation approach:
1. List Releases: helm list -n {self.namespace}
2. Status: helm status {release} -n {self.namespace}
3. History: helm history {release} -n {self.namespace}
4. Values: helm get values {release} -n {self.namespace}
5. Manifest: helm get manifest {release} -n {self.namespace}
6. Template: helm template <chart>

Common issues:
- Upgrade failures: Values conflicts, chart bugs
- Rollback needed: Bad deployment
- Stale releases: Old revisions consuming resources
- Chart issues: Deprecated charts, version mismatch
- Value overrides: Wrong values applied"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        release = self.release or "<release>"
        ns = self.namespace
        if "status" in q:
            return f"I'll check release status.\n\nTOOL: helm status {release} -n {ns}"
        if "history" in q or "rollback" in q:
            return f"I'll check history.\n\nTOOL: helm history {release} -n {ns}"
        if "value" in q:
            return f"I'll check values.\n\nTOOL: helm get values {release} -n {ns}"
        if "manifest" in q:
            return f"I'll get manifest.\n\nTOOL: helm get manifest {release} -n {ns}"
        return f"I'll list releases.\n\nTOOL: helm list -n {ns}"
