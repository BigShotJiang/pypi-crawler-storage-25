"""ArgoCD Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ArgoCDAgent(ShellAgent):
    """Agent for ArgoCD GitOps investigation."""

    COMMAND_PREFIX = ["argocd"]
    TOOL_NAME = "argocd"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "app list", "app get", "app diff", "app history",
        "app manifests", "app resources", "app logs",
        "cluster list", "repo list", "proj list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "app sync", "app delete", "app rollback",
        "app set", "app create", "app terminate-op",
        "cluster add", "cluster rm", "repo add", "repo rm",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.server = config.get("server")
        self.app = config.get("app")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["argocd"]
        if self.server:
            prefix.extend(["--server", self.server])
        return prefix

    def _get_system_prompt(self) -> str:
        app = self.app or "all"
        return f"""You are an ArgoCD investigation agent for application '{app}'.

Available tools:
- argocd: Execute read-only ArgoCD commands
- argocd_write: Execute write commands (requires approval)

Investigation approach:
1. Applications: argocd app list
2. App Status: argocd app get {app}
3. App Diff: argocd app diff {app}
4. History: argocd app history {app}
5. Resources: argocd app resources {app}
6. Logs: argocd app logs {app}

Common issues:
- Sync failures: Git access, manifest errors
- Out of sync: Drift from desired state
- Degraded: Resources failing health checks
- Hook failures: PreSync/PostSync hook errors
- Repo access: SSH keys, authentication"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        app = self.app or "<app>"
        if "sync" in q or "out" in q:
            return f"I'll check app status.\n\nTOOL: argocd app get {app}"
        if "diff" in q or "drift" in q:
            return f"I'll check diff.\n\nTOOL: argocd app diff {app}"
        if "fail" in q or "error" in q:
            return f"I'll check app logs.\n\nTOOL: argocd app logs {app}"
        if "history" in q:
            return f"I'll check history.\n\nTOOL: argocd app history {app}"
        return "I'll list applications.\n\nTOOL: argocd app list"
