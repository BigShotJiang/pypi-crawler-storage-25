"""Artifact Repository Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ArtifactRepoAgent(ShellAgent):
    """Agent for artifact repository investigation (Nexus, Artifactory, npm)."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "artifact"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "repositories", "artifacts", "search", "info",
        "npm view", "npm search", "mvn dependency:tree",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete", "upload", "npm publish", "mvn deploy",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.repo_type = config.get("type", "nexus")  # nexus, artifactory, npm
        self.url = config.get("url")
        self.repository = config.get("repository")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        repo_type = self.repo_type.title()
        return f"""You are an artifact repository ({repo_type}) investigation agent.

URL: {self.url}
Repository: {self.repository}

Available tools:
- artifact: Execute read-only repository API calls
- artifact_write: Execute write operations (requires approval)

Investigation approach for Nexus:
1. Repositories: curl {self.url}/service/rest/v1/repositories
2. Components: curl {self.url}/service/rest/v1/components?repository={self.repository}
3. Search: curl {self.url}/service/rest/v1/search?repository={self.repository}&name=<artifact>

Investigation approach for Artifactory:
1. Repositories: curl {self.url}/api/repositories
2. Storage: curl {self.url}/api/storageinfo
3. Search: curl {self.url}/api/search/artifact?name=<artifact>

Common issues:
- Storage growth: Old artifacts, snapshots
- Replication failures: Remote repo sync issues
- Authentication: Token expiration, permissions
- Proxy issues: Remote repository unavailable
- Cleanup: Retention policies not applied"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "repo" in q:
            return f"I'll list repositories.\n\nTOOL: artifact curl {self.url}/service/rest/v1/repositories"
        if "storage" in q or "space" in q:
            return f"I'll check storage.\n\nTOOL: artifact curl {self.url}/api/storageinfo"
        if "search" in q:
            return f"I'll search artifacts.\n\nTOOL: artifact curl {self.url}/service/rest/v1/search"
        return f"I'll list repositories.\n\nTOOL: artifact curl {self.url}/service/rest/v1/repositories"
