"""Ansible Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AnsibleAgent(ShellAgent):
    """Agent for Ansible investigation."""

    COMMAND_PREFIX = ["ansible"]
    TOOL_NAME = "ansible"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "--list-hosts", "--list-tasks", "--syntax-check",
        "ansible-inventory --list", "ansible-inventory --graph",
        "ansible-doc", "ansible-config list",
        "ansible-galaxy list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "ansible-playbook", "ansible", "ansible-pull",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.inventory = config.get("inventory", "inventory")
        self.playbook = config.get("playbook")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["ansible", "-i", self.inventory]

    def _get_system_prompt(self) -> str:
        return f"""You are an Ansible investigation agent.

Inventory: {self.inventory}

Available tools:
- ansible: Execute read-only Ansible commands
- ansible_write: Execute playbooks (requires approval)

Investigation approach:
1. Inventory: ansible-inventory -i {self.inventory} --list
2. Host Graph: ansible-inventory -i {self.inventory} --graph
3. Playbook Syntax: ansible-playbook --syntax-check <playbook>
4. List Tasks: ansible-playbook --list-tasks <playbook>
5. List Hosts: ansible-playbook --list-hosts <playbook>
6. Config: ansible-config list

Common issues:
- Connection failures: SSH keys, hosts unreachable
- Module errors: Missing module, wrong parameters
- Idempotency: Tasks not idempotent
- Variable precedence: Unexpected variable values
- Inventory: Hosts not in expected groups"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        playbook = self.playbook or "<playbook.yml>"
        if "inventory" in q or "host" in q:
            return f"I'll check inventory.\n\nTOOL: ansible ansible-inventory -i {self.inventory} --graph"
        if "syntax" in q or "valid" in q:
            return f"I'll check syntax.\n\nTOOL: ansible ansible-playbook --syntax-check {playbook}"
        if "task" in q:
            return f"I'll list tasks.\n\nTOOL: ansible ansible-playbook --list-tasks {playbook}"
        return f"I'll list inventory.\n\nTOOL: ansible ansible-inventory -i {self.inventory} --list"
