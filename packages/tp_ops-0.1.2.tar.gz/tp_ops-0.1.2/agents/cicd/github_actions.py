"""GitHub Actions Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GitHubActionsAgent(ShellAgent):
    """Agent for GitHub Actions workflow investigation."""

    COMMAND_PREFIX = ["gh"]
    TOOL_NAME = "gh"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "run list", "run view", "workflow list", "workflow view",
        "cache list", "release list", "secret list",
        "api repos", "api actions",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "run rerun", "run cancel", "workflow enable", "workflow disable",
        "cache delete", "secret set", "secret delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.repo = config.get("repo")
        self.workflow = config.get("workflow")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["gh"]
        if self.repo:
            prefix.extend(["-R", self.repo])
        return prefix

    def _get_system_prompt(self) -> str:
        repo = self.repo or "current repo"
        return f"""You are a GitHub Actions investigation agent for '{repo}'.

Available tools:
- gh: Execute read-only GitHub CLI commands
- gh_write: Execute write commands (requires approval)

Investigation approach:
1. Workflows: gh workflow list
2. Recent Runs: gh run list
3. Run Details: gh run view <run-id>
4. Run Logs: gh run view <run-id> --log
5. Cache: gh cache list
6. API: gh api repos/{repo}/actions/runs

Common issues:
- Workflow failures: Check run logs for errors
- Slow steps: Cache misses, unnecessary steps
- Runner issues: Self-hosted runner offline
- Secret access: Permission errors
- Concurrency: Jobs queued too long"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "fail" in q or "error" in q:
            return "I'll check failed runs.\n\nTOOL: gh run list --status failure"
        if "run" in q:
            return "I'll list recent runs.\n\nTOOL: gh run list"
        if "cache" in q:
            return "I'll check cache.\n\nTOOL: gh cache list"
        if "workflow" in q:
            return "I'll list workflows.\n\nTOOL: gh workflow list"
        return "I'll list recent workflow runs.\n\nTOOL: gh run list"
