"""Terraform Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class TerraformAgent(ShellAgent):
    """Agent for Terraform/OpenTofu investigation."""

    COMMAND_PREFIX = ["terraform"]
    TOOL_NAME = "terraform"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "show", "state list", "state show", "output",
        "providers", "version", "validate", "fmt -check",
        "graph", "workspace list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "apply", "destroy", "import", "taint", "untaint",
        "state rm", "state mv", "state push", "state pull",
        "workspace new", "workspace delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.workspace = config.get("workspace", "default")
        self.working_dir = config.get("working_dir", ".")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["terraform", "-chdir=" + self.working_dir]

    def _get_system_prompt(self) -> str:
        return f"""You are a Terraform investigation agent for workspace '{self.workspace}'.

Working Directory: {self.working_dir}

Available tools:
- terraform: Execute read-only Terraform commands
- terraform_write: Execute write commands (requires approval)

Investigation approach:
1. State List: terraform state list
2. State Show: terraform state show <resource>
3. Show Plan: terraform show
4. Outputs: terraform output
5. Providers: terraform providers
6. Validate: terraform validate

Common issues:
- State lock: Another process holding lock
- Drift: Resources changed outside Terraform
- Provider errors: Authentication, API limits
- State corruption: Manual state edits
- Plan failures: Invalid references, missing vars"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "state" in q and "list" in q:
            return "I'll list state resources.\n\nTOOL: terraform state list"
        if "drift" in q or "change" in q:
            return "I'll show current state.\n\nTOOL: terraform show"
        if "output" in q:
            return "I'll show outputs.\n\nTOOL: terraform output"
        if "valid" in q:
            return "I'll validate configuration.\n\nTOOL: terraform validate"
        return "I'll list state resources.\n\nTOOL: terraform state list"
