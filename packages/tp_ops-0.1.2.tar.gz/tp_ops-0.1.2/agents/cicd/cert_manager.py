"""Certificate Manager Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CertManagerAgent(ShellAgent):
    """Agent for certificate management investigation (cert-manager, Let's Encrypt)."""

    COMMAND_PREFIX = ["kubectl"]
    TOOL_NAME = "kubectl"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "get certificates", "get certificaterequests", "get issuers",
        "get clusterissuers", "get orders", "get challenges",
        "describe certificate", "describe issuer",
        "get secrets",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete certificate", "delete secret",
        "apply", "create", "patch",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace", "default")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["kubectl"]
        if self.kubeconfig:
            prefix.extend(["--kubeconfig", self.kubeconfig])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a certificate management (cert-manager) investigation agent.

Namespace: {self.namespace}

Available tools:
- kubectl: Execute read-only kubectl commands
- kubectl_write: Execute write commands (requires approval)

Investigation approach:
1. Certificates: kubectl get certificates -A
2. Certificate Details: kubectl describe certificate <name> -n <ns>
3. Issuers: kubectl get issuers -A
4. Cluster Issuers: kubectl get clusterissuers
5. Orders: kubectl get orders -A
6. Challenges: kubectl get challenges -A
7. Secrets: kubectl get secrets -n <ns> | grep tls

Common issues:
- Renewal failures: ACME challenges failing
- Issuer errors: ClusterIssuer/Issuer not ready
- Challenge failures: DNS or HTTP validation issues
- Rate limits: Let's Encrypt rate limits
- Expiring certs: Certificates not renewing"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "issuer" in q:
            return "I'll check issuers.\n\nTOOL: kubectl get clusterissuers"
        if "challeng" in q or "acme" in q:
            return "I'll check challenges.\n\nTOOL: kubectl get challenges -A"
        if "order" in q:
            return "I'll check orders.\n\nTOOL: kubectl get orders -A"
        if "expir" in q or "renew" in q:
            return "I'll check certificates.\n\nTOOL: kubectl get certificates -A"
        return "I'll list certificates.\n\nTOOL: kubectl get certificates -A"
