"""SonarQube Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SonarQubeAgent(ShellAgent):
    """Agent for SonarQube code quality investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "sonar"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "api/projects/search", "api/measures/component",
        "api/issues/search", "api/qualitygates/project_status",
        "api/system/status", "api/system/health",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "api/projects/delete", "api/issues/set_severity",
        "api/qualitygates/create", "api/qualitygates/delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.url = config.get("url", "http://localhost:9000")
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        project = self.project or "unknown"
        return f"""You are a SonarQube investigation agent for project '{project}'.

URL: {self.url}

Available tools:
- sonar: Execute read-only SonarQube API calls
- sonar_write: Execute write operations (requires approval)

Investigation approach:
1. System Status: curl {self.url}/api/system/status
2. Projects: curl {self.url}/api/projects/search
3. Quality Gate: curl {self.url}/api/qualitygates/project_status?projectKey={project}
4. Measures: curl {self.url}/api/measures/component?component={project}&metricKeys=bugs,vulnerabilities,code_smells
5. Issues: curl {self.url}/api/issues/search?componentKeys={project}

Common issues:
- Analysis failures: Scanner configuration
- Quality gate: Failing quality gate conditions
- Plugin issues: Outdated or conflicting plugins
- Performance: Large analysis, memory issues
- Technical debt: Growing debt over time"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        project = self.project or "<project>"
        if "quality gate" in q or "gate" in q:
            return f"I'll check quality gate.\n\nTOOL: sonar curl {self.url}/api/qualitygates/project_status?projectKey={project}"
        if "issue" in q or "bug" in q:
            return f"I'll search issues.\n\nTOOL: sonar curl {self.url}/api/issues/search?componentKeys={project}"
        if "measure" in q or "metric" in q:
            return f"I'll check measures.\n\nTOOL: sonar curl {self.url}/api/measures/component?component={project}"
        return f"I'll check system status.\n\nTOOL: sonar curl {self.url}/api/system/status"
