"""HashiCorp Vault Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class VaultAgent(ShellAgent):
    """Agent for HashiCorp Vault investigation."""

    COMMAND_PREFIX = ["vault"]
    TOOL_NAME = "vault"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "status", "secrets list", "auth list", "policy list",
        "token lookup", "lease lookup", "audit list",
        "operator raft list-peers", "operator members",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "secrets enable", "secrets disable", "kv put", "kv delete",
        "auth enable", "auth disable", "policy write", "policy delete",
        "token create", "token revoke", "lease revoke",
        "operator seal", "operator unseal",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.addr = config.get("addr", "http://localhost:8200")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["vault"]

    def _get_system_prompt(self) -> str:
        return f"""You are a HashiCorp Vault investigation agent.

Vault Address: {self.addr}

Available tools:
- vault: Execute read-only Vault commands
- vault_write: Execute write commands (requires approval)

Investigation approach:
1. Status: vault status
2. Secrets Engines: vault secrets list
3. Auth Methods: vault auth list
4. Policies: vault policy list
5. Token Info: vault token lookup
6. Audit: vault audit list
7. Raft Peers: vault operator raft list-peers

Common issues:
- Seal/unseal: Vault sealed, need unseal keys
- Auth failures: Token expired, policy issues
- Secret engine: Mount or configuration issues
- Performance: Slow responses, storage backend
- HA: Leader election, standby issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "status" in q or "seal" in q:
            return "I'll check Vault status.\n\nTOOL: vault status"
        if "secret" in q:
            return "I'll list secret engines.\n\nTOOL: vault secrets list"
        if "auth" in q or "token" in q:
            return "I'll list auth methods.\n\nTOOL: vault auth list"
        if "policy" in q:
            return "I'll list policies.\n\nTOOL: vault policy list"
        return "I'll check Vault status.\n\nTOOL: vault status"
