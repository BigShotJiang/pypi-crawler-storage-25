"""Amazon Kinesis Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class KinesisAgent(ShellAgent):
    """Agent for Amazon Kinesis investigation."""

    COMMAND_PREFIX = ["aws", "kinesis"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-streams", "describe-stream", "describe-stream-summary",
        "list-shards", "get-shard-iterator", "describe-limits",
        "list-stream-consumers",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-stream", "delete-stream", "put-record", "put-records",
        "merge-shards", "split-shard", "increase-stream-retention-period",
        "update-shard-count",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.stream_name = config.get("stream_name")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "kinesis", "--region", self.region]

    def _get_system_prompt(self) -> str:
        stream = self.stream_name or "unknown"
        return f"""You are an Amazon Kinesis investigation agent for stream '{stream}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. List Streams: aws kinesis list-streams
2. Describe Stream: aws kinesis describe-stream --stream-name {stream}
3. Stream Summary: aws kinesis describe-stream-summary --stream-name {stream}
4. List Shards: aws kinesis list-shards --stream-name {stream}
5. CloudWatch: Check GetRecords.IteratorAgeMilliseconds, WriteProvisionedThroughputExceeded

Common issues:
- Iterator age: Consumer falling behind (high GetRecords.IteratorAgeMilliseconds)
- Shard throttling: WriteProvisionedThroughputExceeded
- Hot shards: Uneven partition key distribution
- Consumer failures: Enhanced fan-out issues
- Scaling: Need to split/merge shards"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        stream = self.stream_name or "<stream-name>"
        if "shard" in q:
            return f"I'll list shards.\n\nTOOL: aws kinesis list-shards --stream-name {stream}"
        if "describe" in q or "detail" in q:
            return f"I'll describe the stream.\n\nTOOL: aws kinesis describe-stream-summary --stream-name {stream}"
        if "lag" in q or "behind" in q:
            return "I'll check CloudWatch for iterator age.\n\nTOOL: aws cloudwatch get-metric-statistics --namespace AWS/Kinesis --metric-name GetRecords.IteratorAgeMilliseconds"
        return "I'll list Kinesis streams.\n\nTOOL: aws kinesis list-streams"
