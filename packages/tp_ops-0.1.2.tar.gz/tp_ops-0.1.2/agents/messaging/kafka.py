"""Apache Kafka Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class KafkaAgent(ShellAgent):
    """Agent for Apache Kafka investigation."""

    COMMAND_PREFIX = ["kafka-topics"]
    TOOL_NAME = "kafka"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "--list", "--describe", "--bootstrap-server",
        "kafka-consumer-groups --list", "kafka-consumer-groups --describe",
        "kafka-configs --describe",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "--create", "--delete", "--alter",
        "kafka-consumer-groups --reset-offsets", "--execute",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.brokers = config.get("brokers", "localhost:9092")
        self.topic = config.get("topic")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Kafka investigation agent for brokers '{self.brokers}'.

Available tools:
- kafka: Execute read-only Kafka commands
- kafka_write: Execute write commands (requires approval)

Investigation approach:
1. List Topics: kafka-topics --list --bootstrap-server {self.brokers}
2. Describe Topic: kafka-topics --describe --bootstrap-server {self.brokers} --topic <topic>
3. Consumer Groups: kafka-consumer-groups --list --bootstrap-server {self.brokers}
4. Group Lag: kafka-consumer-groups --describe --bootstrap-server {self.brokers} --group <group>
5. Configs: kafka-configs --describe --bootstrap-server {self.brokers} --entity-type topics

Common issues:
- Consumer lag: Consumers falling behind producers
- Partition hot spots: Uneven message distribution
- ISR shrink: Under-replicated partitions
- Producer failures: Broker connectivity, ACL issues
- DLQ buildup: Failed message handling"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "lag" in q or "consumer" in q:
            return f"I'll check consumer groups.\n\nTOOL: kafka kafka-consumer-groups --list --bootstrap-server {self.brokers}"
        if "topic" in q and "list" in q:
            return f"I'll list topics.\n\nTOOL: kafka kafka-topics --list --bootstrap-server {self.brokers}"
        if "partition" in q or "describe" in q:
            topic = self.topic or "<topic>"
            return f"I'll describe the topic.\n\nTOOL: kafka kafka-topics --describe --bootstrap-server {self.brokers} --topic {topic}"
        return f"I'll list Kafka topics.\n\nTOOL: kafka kafka-topics --list --bootstrap-server {self.brokers}"
