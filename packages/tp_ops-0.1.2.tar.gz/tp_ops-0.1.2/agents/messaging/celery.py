"""Celery Task Queue Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CeleryAgent(ShellAgent):
    """Agent for Celery task queue investigation."""

    COMMAND_PREFIX = ["celery"]
    TOOL_NAME = "celery"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "inspect active", "inspect scheduled", "inspect reserved",
        "inspect stats", "inspect registered", "inspect ping",
        "inspect active_queues", "inspect conf", "inspect query_task",
        "status", "events",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "control shutdown", "control pool_restart", "control pool_shrink",
        "purge", "control revoke", "control terminate",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.app = config.get("app")
        self.broker = config.get("broker", "redis://localhost:6379/0")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["celery"]
        if self.app:
            prefix.extend(["-A", self.app])
        prefix.extend(["-b", self.broker])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Celery task queue investigation agent.

Broker: {self.broker}

Available tools:
- celery: Execute read-only Celery commands
- celery_write: Execute write commands (requires approval)

Investigation approach:
1. Worker Status: celery status
2. Active Tasks: celery inspect active
3. Scheduled Tasks: celery inspect scheduled
4. Reserved Tasks: celery inspect reserved
5. Worker Stats: celery inspect stats
6. Registered Tasks: celery inspect registered

Common issues:
- Task failures: Check task exceptions, retry storms
- Queue backlog: Too many tasks, not enough workers
- Worker health: Workers not responding, memory leaks
- Task timeout: Long-running tasks blocking workers
- Prefetch issues: Too many reserved tasks per worker"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "active" in q or "running" in q:
            return "I'll check active tasks.\n\nTOOL: celery inspect active"
        if "fail" in q or "error" in q:
            return "I'll check worker stats.\n\nTOOL: celery inspect stats"
        if "queue" in q or "backlog" in q:
            return "I'll check active queues.\n\nTOOL: celery inspect active_queues"
        if "worker" in q:
            return "I'll check worker status.\n\nTOOL: celery status"
        return "I'll check Celery status.\n\nTOOL: celery status"
