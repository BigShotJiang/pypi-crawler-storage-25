"""Sidekiq Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SidekiqAgent(ShellAgent):
    """Agent for Sidekiq job processing investigation."""

    COMMAND_PREFIX = ["redis-cli"]
    TOOL_NAME = "sidekiq"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "LLEN", "SCARD", "ZCARD", "SMEMBERS", "INFO",
        "KEYS sidekiq:*", "TYPE", "TTL",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "DEL", "LPUSH", "RPUSH", "ZADD", "ZREM",
        "FLUSHDB", "FLUSHALL",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.redis_host = config.get("redis_host", "localhost")
        self.redis_port = config.get("redis_port", 6379)
        self.redis_db = config.get("redis_db", 0)
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["redis-cli", "-h", self.redis_host, "-p", str(self.redis_port), "-n", str(self.redis_db)]

    def _get_system_prompt(self) -> str:
        return f"""You are a Sidekiq investigation agent for Redis at {self.redis_host}:{self.redis_port}.

Available tools:
- sidekiq: Execute read-only Redis commands to inspect Sidekiq
- sidekiq_write: Execute write commands (requires approval)

Sidekiq Redis Keys:
- sidekiq:queue:<name>: Queue lists (LLEN for depth)
- sidekiq:retry: Retry set (ZCARD for count)
- sidekiq:dead: Dead job set (ZCARD for count)
- sidekiq:schedule: Scheduled set (ZCARD for count)
- sidekiq:processes: Active processes (SMEMBERS)

Investigation approach:
1. Queue Depths: LLEN sidekiq:queue:default
2. Retry Queue: ZCARD sidekiq:retry
3. Dead Jobs: ZCARD sidekiq:dead
4. Scheduled: ZCARD sidekiq:schedule
5. Processes: SMEMBERS sidekiq:processes

Common issues:
- Queue latency: Jobs waiting too long
- Dead jobs: Too many failed jobs
- Retry buildup: Jobs failing repeatedly
- Memory bloat: Large job payloads
- Process crashes: Workers disappearing"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "queue" in q or "depth" in q:
            return "I'll check queue depths.\n\nTOOL: sidekiq LLEN sidekiq:queue:default"
        if "dead" in q or "fail" in q:
            return "I'll check dead jobs.\n\nTOOL: sidekiq ZCARD sidekiq:dead"
        if "retry" in q:
            return "I'll check retry queue.\n\nTOOL: sidekiq ZCARD sidekiq:retry"
        if "process" in q or "worker" in q:
            return "I'll check active processes.\n\nTOOL: sidekiq SMEMBERS sidekiq:processes"
        return "I'll check Sidekiq keys.\n\nTOOL: sidekiq KEYS sidekiq:*"
