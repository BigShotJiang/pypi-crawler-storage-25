"""Redis Streams Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class RedisStreamsAgent(ShellAgent):
    """Agent for Redis Streams investigation."""

    COMMAND_PREFIX = ["redis-cli"]
    TOOL_NAME = "redis"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "XINFO", "XLEN", "XRANGE", "XREAD", "XPENDING",
        "INFO", "MEMORY", "CLIENT LIST", "SLOWLOG",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "XADD", "XTRIM", "XDEL", "XGROUP", "XACK",
        "FLUSHALL", "FLUSHDB", "DEL",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 6379)
        self.stream_key = config.get("stream_key")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["redis-cli", "-h", self.host, "-p", str(self.port)]

    def _get_system_prompt(self) -> str:
        stream = self.stream_key or "<stream-key>"
        return f"""You are a Redis Streams investigation agent for {self.host}:{self.port}.

Available tools:
- redis: Execute read-only Redis commands
- redis_write: Execute write commands (requires approval)

Investigation approach:
1. Stream Info: XINFO STREAM {stream}
2. Stream Length: XLEN {stream}
3. Consumer Groups: XINFO GROUPS {stream}
4. Pending Messages: XPENDING {stream} <group>
5. Consumer Info: XINFO CONSUMERS {stream} <group>
6. Memory: MEMORY USAGE {stream}

Common issues:
- Consumer group lag: XPENDING shows unacknowledged messages
- Memory pressure: Stream growing without trimming
- Idle consumers: Consumers not processing
- PEL growth: Pending entries list too large
- Stream not trimmed: MAXLEN not configured"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        stream = self.stream_key or "<stream-key>"
        if "consumer" in q or "group" in q:
            return f"I'll check consumer groups.\n\nTOOL: redis XINFO GROUPS {stream}"
        if "pending" in q or "lag" in q:
            return f"I'll check pending messages.\n\nTOOL: redis XPENDING {stream} <group>"
        if "memory" in q or "size" in q:
            return f"I'll check memory usage.\n\nTOOL: redis MEMORY USAGE {stream}"
        return f"I'll check stream info.\n\nTOOL: redis XINFO STREAM {stream}"
