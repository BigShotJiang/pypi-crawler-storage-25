"""Amazon SQS Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SQSAgent(ShellAgent):
    """Agent for Amazon SQS investigation."""

    COMMAND_PREFIX = ["aws", "sqs"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-queues", "get-queue-url", "get-queue-attributes",
        "list-dead-letter-source-queues", "list-queue-tags",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-queue", "delete-queue", "purge-queue",
        "send-message", "receive-message", "delete-message",
        "set-queue-attributes",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.queue_url = config.get("queue_url")
        self.queue_name = config.get("queue_name")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "sqs", "--region", self.region]

    def _get_system_prompt(self) -> str:
        queue_id = self.queue_name or self.queue_url or "unknown"
        return f"""You are an Amazon SQS investigation agent for queue '{queue_id}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. List Queues: aws sqs list-queues
2. Queue Attributes: aws sqs get-queue-attributes --queue-url <url> --attribute-names All
3. DLQ Sources: aws sqs list-dead-letter-source-queues --queue-url <dlq-url>
4. CloudWatch Metrics: Check ApproximateNumberOfMessagesVisible, etc.

Key metrics:
- ApproximateNumberOfMessages: Messages available
- ApproximateNumberOfMessagesNotVisible: Messages in-flight
- ApproximateNumberOfMessagesDelayed: Delayed messages

Common issues:
- DLQ accumulation: Failed message handling
- Visibility timeout: Messages reappearing before processing
- Throttling: Too many API calls
- Message retention: Messages expiring unprocessed"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        queue_url = self.queue_url or "<queue-url>"
        if "dlq" in q or "dead" in q:
            return f"I'll check dead letter queue sources.\n\nTOOL: aws sqs list-dead-letter-source-queues --queue-url {queue_url}"
        if "attribute" in q or "depth" in q or "message" in q:
            return f"I'll check queue attributes.\n\nTOOL: aws sqs get-queue-attributes --queue-url {queue_url} --attribute-names All"
        return "I'll list SQS queues.\n\nTOOL: aws sqs list-queues"
