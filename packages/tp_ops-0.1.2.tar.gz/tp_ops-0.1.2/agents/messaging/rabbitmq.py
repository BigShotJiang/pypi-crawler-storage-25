"""RabbitMQ Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class RabbitMQAgent(ShellAgent):
    """Agent for RabbitMQ investigation."""

    COMMAND_PREFIX = ["rabbitmqctl"]
    TOOL_NAME = "rabbitmq"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "status", "list_queues", "list_exchanges", "list_bindings",
        "list_connections", "list_channels", "list_consumers",
        "list_vhosts", "list_users", "cluster_status",
        "report", "node_health_check",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete_queue", "purge_queue", "close_connection",
        "add_user", "delete_user", "set_permissions",
        "stop_app", "start_app", "reset",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 5672)
        self.vhost = config.get("vhost", "/")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a RabbitMQ investigation agent for {self.host}:{self.port}.

Available tools:
- rabbitmq: Execute read-only rabbitmqctl commands
- rabbitmq_write: Execute write commands (requires approval)

Investigation approach:
1. Status: rabbitmqctl status
2. Queues: rabbitmqctl list_queues name messages consumers
3. Connections: rabbitmqctl list_connections
4. Channels: rabbitmqctl list_channels
5. Cluster: rabbitmqctl cluster_status

Common issues:
- Queue depth spikes: Consumer failures or slow consumers
- Unacknowledged messages: Consumer crashes, timeout issues
- Memory alarms: Memory threshold exceeded
- Cluster partition: Network split, node failures
- Connection leaks: Clients not closing connections"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "queue" in q:
            return "I'll check queue depths.\n\nTOOL: rabbitmq rabbitmqctl list_queues name messages consumers"
        if "connection" in q:
            return "I'll check connections.\n\nTOOL: rabbitmq rabbitmqctl list_connections"
        if "cluster" in q:
            return "I'll check cluster status.\n\nTOOL: rabbitmq rabbitmqctl cluster_status"
        if "memory" in q or "alarm" in q:
            return "I'll check node status.\n\nTOOL: rabbitmq rabbitmqctl status"
        return "I'll check RabbitMQ status.\n\nTOOL: rabbitmq rabbitmqctl status"
