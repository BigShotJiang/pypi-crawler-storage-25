"""Amazon SNS Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SNSAgent(ShellAgent):
    """Agent for Amazon SNS investigation."""

    COMMAND_PREFIX = ["aws", "sns"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-topics", "list-subscriptions", "list-subscriptions-by-topic",
        "get-topic-attributes", "get-subscription-attributes",
        "list-platform-applications", "get-endpoint-attributes",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-topic", "delete-topic", "subscribe", "unsubscribe",
        "publish", "set-topic-attributes", "set-subscription-attributes",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.topic_arn = config.get("topic_arn")
        self.topic_name = config.get("topic_name")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "sns", "--region", self.region]

    def _get_system_prompt(self) -> str:
        topic_id = self.topic_name or self.topic_arn or "unknown"
        return f"""You are an Amazon SNS investigation agent for topic '{topic_id}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. List Topics: aws sns list-topics
2. Topic Attributes: aws sns get-topic-attributes --topic-arn <arn>
3. Subscriptions: aws sns list-subscriptions-by-topic --topic-arn <arn>
4. Subscription Details: aws sns get-subscription-attributes --subscription-arn <arn>
5. CloudWatch Metrics: Check NumberOfMessagesPublished, NumberOfNotificationsFailed

Common issues:
- Delivery failures: Endpoint unreachable, permissions
- Subscription health: Pending confirmations, invalid endpoints
- Filter policies: Message filtering issues
- Delivery retry: DLQ configuration for failed deliveries
- Cost: Unused subscriptions, excessive notifications"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        topic_arn = self.topic_arn or "<topic-arn>"
        if "subscription" in q:
            return f"I'll list subscriptions.\n\nTOOL: aws sns list-subscriptions-by-topic --topic-arn {topic_arn}"
        if "attribute" in q or "detail" in q:
            return f"I'll check topic attributes.\n\nTOOL: aws sns get-topic-attributes --topic-arn {topic_arn}"
        return "I'll list SNS topics.\n\nTOOL: aws sns list-topics"
