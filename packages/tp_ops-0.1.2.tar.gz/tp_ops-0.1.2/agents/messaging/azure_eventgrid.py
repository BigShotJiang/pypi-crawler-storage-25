"""Azure Event Grid Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureEventGridAgent(ShellAgent):
    """Agent for Azure Event Grid investigation."""

    COMMAND_PREFIX = ["az", "eventgrid"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "topic list", "topic show",
        "system-topic list", "system-topic show",
        "event-subscription list", "event-subscription show",
        "domain list", "domain show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "topic create", "topic delete",
        "event-subscription create", "event-subscription delete",
        "domain create", "domain delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.topic_name = config.get("topic_name")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        topic = self.topic_name or "unknown"
        return f"""You are an Azure Event Grid investigation agent for topic '{topic}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Topics: az eventgrid topic list -g {self.resource_group}
2. Topic Details: az eventgrid topic show -g {self.resource_group} -n {topic}
3. Subscriptions: az eventgrid event-subscription list --source-resource-id <topic-id>
4. Subscription Details: az eventgrid event-subscription show --name <sub> --source-resource-id <topic-id>
5. Metrics: Check Azure Monitor for PublishSuccessCount, DeliverySuccessCount

Common issues:
- Delivery failures: Dead-letter events accumulating
- Event subscription: Filter expression issues
- Retry policy: Max retries exceeded
- Validation: Webhook validation failures
- Throttling: Events per second limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        topic = self.topic_name or "<topic>"
        if "subscription" in q:
            return "I'll list event subscriptions.\n\nTOOL: az eventgrid event-subscription list"
        if "dead" in q or "fail" in q:
            return f"I'll check topic metrics.\n\nTOOL: az eventgrid topic show -g {self.resource_group} -n {topic}"
        return f"I'll list Event Grid topics.\n\nTOOL: az eventgrid topic list -g {self.resource_group}"
