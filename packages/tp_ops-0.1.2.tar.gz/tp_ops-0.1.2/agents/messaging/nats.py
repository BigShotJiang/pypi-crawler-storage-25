"""NATS Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NATSAgent(ShellAgent):
    """Agent for NATS messaging investigation."""

    COMMAND_PREFIX = ["nats"]
    TOOL_NAME = "nats"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "server info", "server list", "server check",
        "account info", "stream ls", "stream info",
        "consumer ls", "consumer info", "sub",
        "rtt", "events", "latency",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "stream add", "stream rm", "stream purge",
        "consumer add", "consumer rm",
        "pub", "request",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.server = config.get("server", "nats://localhost:4222")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["nats", "-s", self.server]

    def _get_system_prompt(self) -> str:
        return f"""You are a NATS investigation agent for {self.server}.

Available tools:
- nats: Execute read-only NATS commands
- nats_write: Execute write commands (requires approval)

Investigation approach:
1. Server Info: nats server info
2. Streams: nats stream ls
3. Stream Details: nats stream info <stream>
4. Consumers: nats consumer ls <stream>
5. Consumer Info: nats consumer info <stream> <consumer>
6. RTT: nats rtt

Common issues:
- Slow consumers: Consumer can't keep up with messages
- JetStream issues: Stream replication, storage limits
- Connection storms: Too many reconnecting clients
- Subject namespace: Wildcard subscription issues
- Clustering: Raft consensus, leader election"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "stream" in q:
            return "I'll list streams.\n\nTOOL: nats stream ls"
        if "consumer" in q:
            return "I'll list consumers.\n\nTOOL: nats consumer ls <stream>"
        if "slow" in q or "lag" in q:
            return "I'll check server info.\n\nTOOL: nats server info"
        return "I'll check NATS server.\n\nTOOL: nats server info"
