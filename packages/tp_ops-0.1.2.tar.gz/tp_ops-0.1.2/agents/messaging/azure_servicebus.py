"""Azure Service Bus Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureServiceBusAgent(ShellAgent):
    """Agent for Azure Service Bus investigation."""

    COMMAND_PREFIX = ["az", "servicebus"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "namespace show", "namespace list",
        "queue list", "queue show",
        "topic list", "topic show",
        "topic subscription list", "topic subscription show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "namespace create", "namespace delete",
        "queue create", "queue delete",
        "topic create", "topic delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Service Bus investigation agent for namespace '{self.namespace}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Namespace Info: az servicebus namespace show -g {self.resource_group} -n {self.namespace}
2. Queues: az servicebus queue list -g {self.resource_group} --namespace-name {self.namespace}
3. Topics: az servicebus topic list -g {self.resource_group} --namespace-name {self.namespace}
4. Subscriptions: az servicebus topic subscription list -g {self.resource_group} --namespace-name {self.namespace} --topic-name <topic>

Common issues:
- Dead letter accumulation: Failed message processing
- Session lock issues: Session-enabled queue contention
- Message TTL: Messages expiring before processing
- Namespace throttling: TU/MU limits exceeded
- Subscription filters: Filter expression issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "queue" in q:
            return f"I'll list queues.\n\nTOOL: az servicebus queue list -g {self.resource_group} --namespace-name {self.namespace}"
        if "topic" in q:
            return f"I'll list topics.\n\nTOOL: az servicebus topic list -g {self.resource_group} --namespace-name {self.namespace}"
        if "dead" in q or "dlq" in q:
            return f"I'll check namespace for dead letter info.\n\nTOOL: az servicebus queue list -g {self.resource_group} --namespace-name {self.namespace} --query '[].{{name:name,deadLetteringOnMessageExpiration:deadLetteringOnMessageExpiration}}'"
        return f"I'll check namespace info.\n\nTOOL: az servicebus namespace show -g {self.resource_group} -n {self.namespace}"
