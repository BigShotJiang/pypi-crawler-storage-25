"""Message queue and streaming agents for Kafka, SQS, RabbitMQ, and more."""

from agents.messaging.kafka import KafkaAgent
from agents.messaging.rabbitmq import RabbitMQAgent
from agents.messaging.sqs import SQSAgent
from agents.messaging.azure_servicebus import AzureServiceBusAgent
from agents.messaging.sns import SNSAgent
from agents.messaging.nats import NATSAgent
from agents.messaging.kinesis import KinesisAgent
from agents.messaging.redis_streams import RedisStreamsAgent
from agents.messaging.pulsar import PulsarAgent
from agents.messaging.eventbridge import EventBridgeAgent
from agents.messaging.azure_eventgrid import AzureEventGridAgent
from agents.messaging.azure_eventhubs import AzureEventHubsAgent
from agents.messaging.celery import CeleryAgent
from agents.messaging.sidekiq import SidekiqAgent
from agents.messaging.bullmq import BullMQAgent

__all__ = [
    "KafkaAgent",
    "RabbitMQAgent",
    "SQSAgent",
    "AzureServiceBusAgent",
    "SNSAgent",
    "NATSAgent",
    "KinesisAgent",
    "RedisStreamsAgent",
    "PulsarAgent",
    "EventBridgeAgent",
    "AzureEventGridAgent",
    "AzureEventHubsAgent",
    "CeleryAgent",
    "SidekiqAgent",
    "BullMQAgent",
]
