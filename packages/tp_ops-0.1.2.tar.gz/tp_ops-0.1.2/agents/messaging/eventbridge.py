"""Amazon EventBridge Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class EventBridgeAgent(ShellAgent):
    """Agent for Amazon EventBridge investigation."""

    COMMAND_PREFIX = ["aws", "events"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-event-buses", "describe-event-bus",
        "list-rules", "describe-rule", "list-targets-by-rule",
        "list-archives", "describe-archive",
        "list-replays", "describe-replay",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "put-rule", "delete-rule", "put-targets", "remove-targets",
        "put-events", "create-event-bus", "delete-event-bus",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.event_bus = config.get("event_bus", "default")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "events", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are an Amazon EventBridge investigation agent for event bus '{self.event_bus}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Event Buses: aws events list-event-buses
2. Rules: aws events list-rules --event-bus-name {self.event_bus}
3. Rule Details: aws events describe-rule --name <rule> --event-bus-name {self.event_bus}
4. Targets: aws events list-targets-by-rule --rule <rule> --event-bus-name {self.event_bus}
5. CloudWatch: Check MatchedEvents, FailedInvocations, Invocations

Common issues:
- Rule matching failures: Event pattern not matching
- Target delivery issues: Lambda throttling, SQS errors
- Throttling: Too many events, account limits
- Unused rules: Rules without matching events
- Cost: High event volume, unnecessary rules"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "rule" in q:
            return f"I'll list rules.\n\nTOOL: aws events list-rules --event-bus-name {self.event_bus}"
        if "target" in q:
            return "I'll check targets.\n\nTOOL: aws events list-targets-by-rule --rule <rule>"
        if "fail" in q or "error" in q:
            return "I'll check CloudWatch for failures.\n\nTOOL: aws cloudwatch get-metric-statistics --namespace AWS/Events --metric-name FailedInvocations"
        return f"I'll list event buses.\n\nTOOL: aws events list-event-buses"
