"""Azure Event Hubs Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureEventHubsAgent(ShellAgent):
    """Agent for Azure Event Hubs investigation."""

    COMMAND_PREFIX = ["az", "eventhubs"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "namespace list", "namespace show",
        "eventhub list", "eventhub show",
        "eventhub consumer-group list", "eventhub consumer-group show",
        "eventhub authorization-rule list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "namespace create", "namespace delete",
        "eventhub create", "eventhub delete",
        "eventhub consumer-group create", "eventhub consumer-group delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace")
        self.eventhub_name = config.get("eventhub_name")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        hub = self.eventhub_name or "unknown"
        return f"""You are an Azure Event Hubs investigation agent for namespace '{self.namespace}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Namespace: az eventhubs namespace show -g {self.resource_group} -n {self.namespace}
2. Event Hubs: az eventhubs eventhub list -g {self.resource_group} --namespace-name {self.namespace}
3. Hub Details: az eventhubs eventhub show -g {self.resource_group} --namespace-name {self.namespace} -n {hub}
4. Consumer Groups: az eventhubs eventhub consumer-group list -g {self.resource_group} --namespace-name {self.namespace} --eventhub-name {hub}
5. Metrics: Azure Monitor for IncomingMessages, OutgoingMessages, ThrottledRequests

Common issues:
- Throughput unit saturation: Need to scale TUs
- Consumer lag: Checkpoint lag in processing
- Partition distribution: Uneven partition ownership
- Capture failures: Storage account issues
- Quota exceeded: Message size or throughput limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        hub = self.eventhub_name or "<eventhub>"
        if "consumer" in q or "group" in q:
            return f"I'll list consumer groups.\n\nTOOL: az eventhubs eventhub consumer-group list -g {self.resource_group} --namespace-name {self.namespace} --eventhub-name {hub}"
        if "partition" in q:
            return f"I'll check event hub details.\n\nTOOL: az eventhubs eventhub show -g {self.resource_group} --namespace-name {self.namespace} -n {hub}"
        if "throttl" in q or "limit" in q:
            return f"I'll check namespace status.\n\nTOOL: az eventhubs namespace show -g {self.resource_group} -n {self.namespace}"
        return f"I'll list event hubs.\n\nTOOL: az eventhubs eventhub list -g {self.resource_group} --namespace-name {self.namespace}"
