"""Apache Pulsar Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class PulsarAgent(ShellAgent):
    """Agent for Apache Pulsar investigation."""

    COMMAND_PREFIX = ["pulsar-admin"]
    TOOL_NAME = "pulsar"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "tenants list", "tenants get",
        "namespaces list", "namespaces policies",
        "topics list", "topics stats", "topics partitioned-stats",
        "subscriptions list", "subscriptions stats",
        "brokers list", "broker-stats",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "tenants create", "tenants delete",
        "namespaces create", "namespaces delete",
        "topics create", "topics delete",
        "subscriptions create", "subscriptions delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.admin_url = config.get("admin_url", "http://localhost:8080")
        self.tenant = config.get("tenant")
        self.namespace = config.get("namespace")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["pulsar-admin", "--admin-url", self.admin_url]

    def _get_system_prompt(self) -> str:
        tenant = self.tenant or "<tenant>"
        namespace = self.namespace or "<namespace>"
        return f"""You are an Apache Pulsar investigation agent for {self.admin_url}.

Available tools:
- pulsar: Execute read-only pulsar-admin commands
- pulsar_write: Execute write commands (requires approval)

Investigation approach:
1. Tenants: pulsar-admin tenants list
2. Namespaces: pulsar-admin namespaces list {tenant}
3. Topics: pulsar-admin topics list {tenant}/{namespace}
4. Topic Stats: pulsar-admin topics stats <topic>
5. Subscriptions: pulsar-admin subscriptions list <topic>
6. Brokers: pulsar-admin brokers list

Common issues:
- Subscription backlog: Messages accumulating
- Bookie failures: Storage tier issues
- Broker load: Uneven topic distribution
- Namespace isolation: Resource contention
- Partition optimization: Hot partitions"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        tenant = self.tenant or "<tenant>"
        namespace = self.namespace or "<namespace>"
        if "topic" in q:
            return f"I'll list topics.\n\nTOOL: pulsar topics list {tenant}/{namespace}"
        if "subscription" in q or "backlog" in q:
            return "I'll check subscriptions.\n\nTOOL: pulsar subscriptions list <topic>"
        if "broker" in q:
            return "I'll check brokers.\n\nTOOL: pulsar brokers list"
        return "I'll list tenants.\n\nTOOL: pulsar tenants list"
