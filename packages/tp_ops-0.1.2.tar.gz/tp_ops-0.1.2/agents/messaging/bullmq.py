"""BullMQ Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class BullMQAgent(ShellAgent):
    """Agent for BullMQ job queue investigation."""

    COMMAND_PREFIX = ["redis-cli"]
    TOOL_NAME = "bullmq"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "LLEN", "ZCARD", "HGETALL", "KEYS", "TYPE",
        "XLEN", "XINFO",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "DEL", "LPUSH", "RPUSH", "ZADD", "ZREM",
        "FLUSHDB", "FLUSHALL", "XDEL", "XTRIM",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.redis_host = config.get("redis_host", "localhost")
        self.redis_port = config.get("redis_port", 6379)
        self.queue_name = config.get("queue_name", "myqueue")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["redis-cli", "-h", self.redis_host, "-p", str(self.redis_port)]

    def _get_system_prompt(self) -> str:
        queue = self.queue_name
        return f"""You are a BullMQ investigation agent for queue '{queue}'.

Redis: {self.redis_host}:{self.redis_port}

Available tools:
- bullmq: Execute read-only Redis commands to inspect BullMQ
- bullmq_write: Execute write commands (requires approval)

BullMQ Redis Keys (using prefix 'bull:<queue>:'):
- bull:{queue}:wait: Waiting jobs (LLEN)
- bull:{queue}:active: Active jobs (LLEN)
- bull:{queue}:completed: Completed jobs (ZCARD)
- bull:{queue}:failed: Failed jobs (ZCARD)
- bull:{queue}:delayed: Delayed jobs (ZCARD)
- bull:{queue}:stalled: Stalled jobs (ZCARD)
- bull:{queue}:events: Event stream (XLEN)

Investigation approach:
1. Waiting Jobs: LLEN bull:{queue}:wait
2. Active Jobs: LLEN bull:{queue}:active
3. Failed Jobs: ZCARD bull:{queue}:failed
4. Delayed Jobs: ZCARD bull:{queue}:delayed
5. Stalled Jobs: ZCARD bull:{queue}:stalled

Common issues:
- Stalled jobs: Worker crashed during processing
- Rate limiting: Too many concurrent jobs
- Connection issues: Redis connectivity problems
- Flow optimization: Complex job dependencies
- Worker scaling: Not enough workers for load"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        queue = self.queue_name
        if "wait" in q or "pending" in q:
            return f"I'll check waiting jobs.\n\nTOOL: bullmq LLEN bull:{queue}:wait"
        if "active" in q:
            return f"I'll check active jobs.\n\nTOOL: bullmq LLEN bull:{queue}:active"
        if "fail" in q:
            return f"I'll check failed jobs.\n\nTOOL: bullmq ZCARD bull:{queue}:failed"
        if "stall" in q:
            return f"I'll check stalled jobs.\n\nTOOL: bullmq ZCARD bull:{queue}:stalled"
        return f"I'll check queue keys.\n\nTOOL: bullmq KEYS bull:{queue}:*"
