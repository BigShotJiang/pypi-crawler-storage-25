"""Health check utilities for agents.

Common health check patterns for infrastructure agents:
- TCP connectivity checks
- HTTP/HTTPS health endpoints
- Process status checks
- Service availability
- DNS resolution
"""

import socket
import subprocess
import urllib.request
import urllib.error
import ssl
from dataclasses import dataclass, field
from typing import Optional, Any
from datetime import datetime
from enum import Enum


class HealthStatus(Enum):
    """Health check status."""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DEGRADED = "degraded"
    UNKNOWN = "unknown"


@dataclass
class HealthResult:
    """Result of a health check."""

    status: HealthStatus
    message: str = ""
    latency_ms: float = 0.0
    details: dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)

    def __str__(self) -> str:
        icon = {
            HealthStatus.HEALTHY: "🟢",
            HealthStatus.UNHEALTHY: "🔴",
            HealthStatus.DEGRADED: "🟡",
            HealthStatus.UNKNOWN: "⚪",
        }.get(self.status, "⚪")
        latency = f" ({self.latency_ms:.1f}ms)" if self.latency_ms > 0 else ""
        return f"{icon} {self.status.value}{latency}: {self.message}"

    @property
    def is_healthy(self) -> bool:
        return self.status == HealthStatus.HEALTHY


@dataclass
class ServiceHealth:
    """Health status of a service with multiple checks."""

    name: str
    checks: list[HealthResult] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def overall_status(self) -> HealthStatus:
        if not self.checks:
            return HealthStatus.UNKNOWN
        if all(c.status == HealthStatus.HEALTHY for c in self.checks):
            return HealthStatus.HEALTHY
        if any(c.status == HealthStatus.UNHEALTHY for c in self.checks):
            return HealthStatus.UNHEALTHY
        return HealthStatus.DEGRADED

    @property
    def is_healthy(self) -> bool:
        return self.overall_status == HealthStatus.HEALTHY

    def __str__(self) -> str:
        icon = {
            HealthStatus.HEALTHY: "🟢",
            HealthStatus.UNHEALTHY: "🔴",
            HealthStatus.DEGRADED: "🟡",
            HealthStatus.UNKNOWN: "⚪",
        }.get(self.overall_status, "⚪")
        lines = [f"{icon} {self.name}: {self.overall_status.value}"]
        for check in self.checks:
            lines.append(f"  {check}")
        return "\n".join(lines)


# =============================================================================
# TCP/Network Checks
# =============================================================================

def check_tcp_connectivity(
    host: str,
    port: int,
    timeout: int = 5,
) -> HealthResult:
    """Check TCP connectivity to a host:port.

    Args:
        host: Target hostname or IP
        port: Target port
        timeout: Connection timeout in seconds

    Returns:
        HealthResult with status and latency
    """
    start = datetime.now()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()

        latency = (datetime.now() - start).total_seconds() * 1000

        if result == 0:
            return HealthResult(
                status=HealthStatus.HEALTHY,
                message=f"TCP connection to {host}:{port} successful",
                latency_ms=latency,
                details={"host": host, "port": port},
            )
        else:
            return HealthResult(
                status=HealthStatus.UNHEALTHY,
                message=f"TCP connection to {host}:{port} refused (error {result})",
                latency_ms=latency,
                details={"host": host, "port": port, "error_code": result},
            )

    except socket.timeout:
        latency = (datetime.now() - start).total_seconds() * 1000
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"TCP connection to {host}:{port} timed out after {timeout}s",
            latency_ms=latency,
            details={"host": host, "port": port, "timeout": timeout},
        )
    except socket.gaierror as e:
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"DNS resolution failed for {host}: {e}",
            details={"host": host, "port": port, "error": str(e)},
        )
    except Exception as e:
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"TCP check failed for {host}:{port}: {e}",
            details={"host": host, "port": port, "error": str(e)},
        )


def check_dns_resolution(
    hostname: str,
    timeout: int = 5,
) -> HealthResult:
    """Check DNS resolution for a hostname.

    Args:
        hostname: Hostname to resolve
        timeout: Resolution timeout in seconds

    Returns:
        HealthResult with resolved IPs
    """
    start = datetime.now()
    original_timeout = socket.getdefaulttimeout()

    try:
        socket.setdefaulttimeout(timeout)
        ips = socket.gethostbyname_ex(hostname)
        latency = (datetime.now() - start).total_seconds() * 1000

        return HealthResult(
            status=HealthStatus.HEALTHY,
            message=f"DNS resolved {hostname} to {', '.join(ips[2])}",
            latency_ms=latency,
            details={"hostname": hostname, "ips": ips[2], "aliases": ips[1]},
        )

    except socket.gaierror as e:
        latency = (datetime.now() - start).total_seconds() * 1000
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"DNS resolution failed for {hostname}: {e}",
            latency_ms=latency,
            details={"hostname": hostname, "error": str(e)},
        )
    except socket.timeout:
        latency = (datetime.now() - start).total_seconds() * 1000
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"DNS resolution timed out for {hostname}",
            latency_ms=latency,
            details={"hostname": hostname, "timeout": timeout},
        )
    finally:
        socket.setdefaulttimeout(original_timeout)


def check_port_range(
    host: str,
    ports: list[int],
    timeout: int = 2,
) -> list[HealthResult]:
    """Check multiple ports on a host.

    Args:
        host: Target hostname or IP
        ports: List of ports to check
        timeout: Timeout per port check

    Returns:
        List of HealthResults for each port
    """
    results = []
    for port in ports:
        results.append(check_tcp_connectivity(host, port, timeout))
    return results


# =============================================================================
# HTTP/HTTPS Checks
# =============================================================================

def check_http_health(
    url: str,
    expected_status: int = 200,
    timeout: int = 10,
    method: str = "GET",
    headers: Optional[dict] = None,
    verify_ssl: bool = True,
) -> HealthResult:
    """Check HTTP/HTTPS endpoint health.

    Args:
        url: URL to check
        expected_status: Expected HTTP status code
        timeout: Request timeout in seconds
        method: HTTP method (GET, HEAD, etc.)
        headers: Optional request headers
        verify_ssl: Whether to verify SSL certificates

    Returns:
        HealthResult with status and response details
    """
    start = datetime.now()

    try:
        req = urllib.request.Request(url, method=method)

        if headers:
            for key, value in headers.items():
                req.add_header(key, value)

        # SSL context
        context = None
        if url.startswith("https://"):
            context = ssl.create_default_context()
            if not verify_ssl:
                context.check_hostname = False
                context.verify_mode = ssl.CERT_NONE

        with urllib.request.urlopen(req, timeout=timeout, context=context) as response:
            latency = (datetime.now() - start).total_seconds() * 1000
            status_code = response.getcode()
            content_length = response.headers.get("Content-Length", "unknown")

            if status_code == expected_status:
                return HealthResult(
                    status=HealthStatus.HEALTHY,
                    message=f"HTTP {status_code} from {url}",
                    latency_ms=latency,
                    details={
                        "url": url,
                        "status_code": status_code,
                        "content_length": content_length,
                    },
                )
            else:
                return HealthResult(
                    status=HealthStatus.DEGRADED,
                    message=f"HTTP {status_code} from {url} (expected {expected_status})",
                    latency_ms=latency,
                    details={
                        "url": url,
                        "status_code": status_code,
                        "expected_status": expected_status,
                    },
                )

    except urllib.error.HTTPError as e:
        latency = (datetime.now() - start).total_seconds() * 1000
        if e.code == expected_status:
            return HealthResult(
                status=HealthStatus.HEALTHY,
                message=f"HTTP {e.code} from {url}",
                latency_ms=latency,
                details={"url": url, "status_code": e.code},
            )
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"HTTP {e.code} from {url}: {e.reason}",
            latency_ms=latency,
            details={"url": url, "status_code": e.code, "reason": e.reason},
        )
    except urllib.error.URLError as e:
        latency = (datetime.now() - start).total_seconds() * 1000
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"Failed to connect to {url}: {e.reason}",
            latency_ms=latency,
            details={"url": url, "error": str(e.reason)},
        )
    except ssl.SSLError as e:
        latency = (datetime.now() - start).total_seconds() * 1000
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"SSL error for {url}: {e}",
            latency_ms=latency,
            details={"url": url, "error": str(e)},
        )
    except Exception as e:
        latency = (datetime.now() - start).total_seconds() * 1000
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"HTTP check failed for {url}: {e}",
            latency_ms=latency,
            details={"url": url, "error": str(e)},
        )


def check_http_json(
    url: str,
    expected_field: Optional[str] = None,
    expected_value: Optional[Any] = None,
    timeout: int = 10,
) -> HealthResult:
    """Check HTTP endpoint that returns JSON.

    Args:
        url: URL to check
        expected_field: JSON field to check (dot notation: "status.health")
        expected_value: Expected value for the field
        timeout: Request timeout

    Returns:
        HealthResult with parsed JSON details
    """
    import json

    start = datetime.now()

    try:
        req = urllib.request.Request(url)
        req.add_header("Accept", "application/json")

        with urllib.request.urlopen(req, timeout=timeout) as response:
            latency = (datetime.now() - start).total_seconds() * 1000
            data = json.loads(response.read().decode())

            # Check specific field if requested
            if expected_field:
                value = data
                for key in expected_field.split("."):
                    if isinstance(value, dict):
                        value = value.get(key)
                    else:
                        value = None
                        break

                if expected_value is not None and value != expected_value:
                    return HealthResult(
                        status=HealthStatus.DEGRADED,
                        message=f"{expected_field}={value} (expected {expected_value})",
                        latency_ms=latency,
                        details={"url": url, "field": expected_field, "value": value},
                    )

            return HealthResult(
                status=HealthStatus.HEALTHY,
                message=f"JSON response from {url}",
                latency_ms=latency,
                details={"url": url, "response": data},
            )

    except Exception as e:
        latency = (datetime.now() - start).total_seconds() * 1000
        return HealthResult(
            status=HealthStatus.UNHEALTHY,
            message=f"JSON check failed for {url}: {e}",
            latency_ms=latency,
            details={"url": url, "error": str(e)},
        )


# =============================================================================
# Process Checks
# =============================================================================

def check_process_running(
    process_name: str,
    exact_match: bool = False,
) -> HealthResult:
    """Check if a process is running.

    Args:
        process_name: Process name to search for
        exact_match: Whether to match exactly or substring

    Returns:
        HealthResult with process details
    """
    try:
        # Use pgrep for efficiency
        cmd = ["pgrep"]
        if exact_match:
            cmd.append("-x")
        cmd.append(process_name)

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode == 0:
            pids = [p.strip() for p in result.stdout.strip().split("\n") if p.strip()]
            return HealthResult(
                status=HealthStatus.HEALTHY,
                message=f"Process '{process_name}' running ({len(pids)} instance(s))",
                details={"process": process_name, "pids": pids, "count": len(pids)},
            )
        else:
            return HealthResult(
                status=HealthStatus.UNHEALTHY,
                message=f"Process '{process_name}' not found",
                details={"process": process_name},
            )

    except FileNotFoundError:
        # pgrep not available, fall back to ps
        try:
            result = subprocess.run(
                ["ps", "aux"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            lines = [l for l in result.stdout.split("\n") if process_name in l]
            if lines:
                return HealthResult(
                    status=HealthStatus.HEALTHY,
                    message=f"Process '{process_name}' running ({len(lines)} match(es))",
                    details={"process": process_name, "matches": len(lines)},
                )
            return HealthResult(
                status=HealthStatus.UNHEALTHY,
                message=f"Process '{process_name}' not found",
                details={"process": process_name},
            )
        except Exception as e:
            return HealthResult(
                status=HealthStatus.UNKNOWN,
                message=f"Could not check process: {e}",
                details={"process": process_name, "error": str(e)},
            )
    except subprocess.TimeoutExpired:
        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message=f"Process check timed out for '{process_name}'",
            details={"process": process_name},
        )
    except Exception as e:
        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message=f"Process check failed: {e}",
            details={"process": process_name, "error": str(e)},
        )


def check_service_status(
    service_name: str,
    use_systemctl: bool = True,
) -> HealthResult:
    """Check systemd service status.

    Args:
        service_name: Service name (e.g., 'nginx', 'postgresql')
        use_systemctl: Use systemctl (Linux) vs service command

    Returns:
        HealthResult with service status
    """
    try:
        if use_systemctl:
            cmd = ["systemctl", "is-active", service_name]
        else:
            cmd = ["service", service_name, "status"]

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,
        )

        output = result.stdout.strip()

        if use_systemctl:
            if output == "active":
                return HealthResult(
                    status=HealthStatus.HEALTHY,
                    message=f"Service '{service_name}' is active",
                    details={"service": service_name, "state": "active"},
                )
            elif output == "inactive":
                return HealthResult(
                    status=HealthStatus.UNHEALTHY,
                    message=f"Service '{service_name}' is inactive",
                    details={"service": service_name, "state": "inactive"},
                )
            elif output == "failed":
                return HealthResult(
                    status=HealthStatus.UNHEALTHY,
                    message=f"Service '{service_name}' has failed",
                    details={"service": service_name, "state": "failed"},
                )
            else:
                return HealthResult(
                    status=HealthStatus.DEGRADED,
                    message=f"Service '{service_name}' state: {output}",
                    details={"service": service_name, "state": output},
                )
        else:
            if result.returncode == 0:
                return HealthResult(
                    status=HealthStatus.HEALTHY,
                    message=f"Service '{service_name}' is running",
                    details={"service": service_name, "output": output},
                )
            else:
                return HealthResult(
                    status=HealthStatus.UNHEALTHY,
                    message=f"Service '{service_name}' check failed",
                    details={"service": service_name, "output": output},
                )

    except FileNotFoundError:
        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message="systemctl/service command not found",
            details={"service": service_name},
        )
    except subprocess.TimeoutExpired:
        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message=f"Service check timed out for '{service_name}'",
            details={"service": service_name},
        )
    except Exception as e:
        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message=f"Service check failed: {e}",
            details={"service": service_name, "error": str(e)},
        )


# =============================================================================
# Disk/Resource Checks
# =============================================================================

def check_disk_space(
    path: str = "/",
    warning_percent: int = 80,
    critical_percent: int = 90,
) -> HealthResult:
    """Check disk space usage.

    Args:
        path: Path to check
        warning_percent: Warning threshold percentage
        critical_percent: Critical threshold percentage

    Returns:
        HealthResult with disk usage details
    """
    try:
        result = subprocess.run(
            ["df", "-P", path],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode != 0:
            return HealthResult(
                status=HealthStatus.UNKNOWN,
                message=f"Could not check disk space for {path}",
                details={"path": path, "error": result.stderr},
            )

        # Parse df output
        lines = result.stdout.strip().split("\n")
        if len(lines) < 2:
            return HealthResult(
                status=HealthStatus.UNKNOWN,
                message=f"Unexpected df output for {path}",
                details={"path": path},
            )

        parts = lines[1].split()
        if len(parts) < 5:
            return HealthResult(
                status=HealthStatus.UNKNOWN,
                message=f"Could not parse df output for {path}",
                details={"path": path},
            )

        usage_percent = int(parts[4].rstrip("%"))
        total_kb = int(parts[1])
        used_kb = int(parts[2])
        available_kb = int(parts[3])

        details = {
            "path": path,
            "usage_percent": usage_percent,
            "total_gb": round(total_kb / 1024 / 1024, 2),
            "used_gb": round(used_kb / 1024 / 1024, 2),
            "available_gb": round(available_kb / 1024 / 1024, 2),
        }

        if usage_percent >= critical_percent:
            return HealthResult(
                status=HealthStatus.UNHEALTHY,
                message=f"Disk {path} at {usage_percent}% (critical >= {critical_percent}%)",
                details=details,
            )
        elif usage_percent >= warning_percent:
            return HealthResult(
                status=HealthStatus.DEGRADED,
                message=f"Disk {path} at {usage_percent}% (warning >= {warning_percent}%)",
                details=details,
            )
        else:
            return HealthResult(
                status=HealthStatus.HEALTHY,
                message=f"Disk {path} at {usage_percent}%",
                details=details,
            )

    except Exception as e:
        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message=f"Disk check failed for {path}: {e}",
            details={"path": path, "error": str(e)},
        )


def check_memory_usage(
    warning_percent: int = 85,
    critical_percent: int = 95,
) -> HealthResult:
    """Check memory usage.

    Args:
        warning_percent: Warning threshold percentage
        critical_percent: Critical threshold percentage

    Returns:
        HealthResult with memory usage details
    """
    try:
        result = subprocess.run(
            ["free", "-m"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode != 0:
            return HealthResult(
                status=HealthStatus.UNKNOWN,
                message="Could not check memory usage",
                details={"error": result.stderr},
            )

        # Parse free output
        lines = result.stdout.strip().split("\n")
        for line in lines:
            if line.startswith("Mem:"):
                parts = line.split()
                total_mb = int(parts[1])
                used_mb = int(parts[2])
                available_mb = int(parts[6]) if len(parts) > 6 else total_mb - used_mb

                usage_percent = int((used_mb / total_mb) * 100)

                details = {
                    "usage_percent": usage_percent,
                    "total_mb": total_mb,
                    "used_mb": used_mb,
                    "available_mb": available_mb,
                }

                if usage_percent >= critical_percent:
                    return HealthResult(
                        status=HealthStatus.UNHEALTHY,
                        message=f"Memory at {usage_percent}% (critical >= {critical_percent}%)",
                        details=details,
                    )
                elif usage_percent >= warning_percent:
                    return HealthResult(
                        status=HealthStatus.DEGRADED,
                        message=f"Memory at {usage_percent}% (warning >= {warning_percent}%)",
                        details=details,
                    )
                else:
                    return HealthResult(
                        status=HealthStatus.HEALTHY,
                        message=f"Memory at {usage_percent}%",
                        details=details,
                    )

        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message="Could not parse memory info",
            details={},
        )

    except FileNotFoundError:
        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message="'free' command not found",
            details={},
        )
    except Exception as e:
        return HealthResult(
            status=HealthStatus.UNKNOWN,
            message=f"Memory check failed: {e}",
            details={"error": str(e)},
        )


# =============================================================================
# Composite Health Checks
# =============================================================================

def check_service_health(
    name: str,
    tcp_checks: Optional[list[tuple[str, int]]] = None,
    http_checks: Optional[list[str]] = None,
    process_checks: Optional[list[str]] = None,
) -> ServiceHealth:
    """Run multiple health checks for a service.

    Args:
        name: Service name
        tcp_checks: List of (host, port) tuples
        http_checks: List of URLs
        process_checks: List of process names

    Returns:
        ServiceHealth with all check results
    """
    health = ServiceHealth(name=name)

    if tcp_checks:
        for host, port in tcp_checks:
            result = check_tcp_connectivity(host, port)
            result.message = f"TCP {host}:{port} - {result.message}"
            health.checks.append(result)

    if http_checks:
        for url in http_checks:
            result = check_http_health(url)
            health.checks.append(result)

    if process_checks:
        for process in process_checks:
            result = check_process_running(process)
            health.checks.append(result)

    return health


def format_health_report(services: list[ServiceHealth]) -> str:
    """Format multiple service health checks into a report.

    Args:
        services: List of ServiceHealth objects

    Returns:
        Formatted report string
    """
    lines = ["Health Report", "=" * 50, ""]

    healthy = sum(1 for s in services if s.is_healthy)
    total = len(services)

    lines.append(f"Overall: {healthy}/{total} services healthy")
    lines.append("")

    for service in services:
        lines.append(str(service))
        lines.append("")

    return "\n".join(lines)
