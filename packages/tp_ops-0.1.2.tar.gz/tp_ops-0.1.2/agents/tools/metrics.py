"""Metrics analysis and anomaly detection utilities.

Shared utilities for metrics-based agents:
- Time series aggregation
- Statistical anomaly detection
- Spike and dip detection
- Baseline comparison
"""

import math
from dataclasses import dataclass, field
from typing import Optional, Any
from datetime import datetime, timedelta
from enum import Enum


class MetricType(Enum):
    """Types of metrics."""
    COUNTER = "counter"      # Monotonically increasing
    GAUGE = "gauge"          # Point-in-time value
    HISTOGRAM = "histogram"  # Distribution
    SUMMARY = "summary"      # Quantiles


class AnomalyType(Enum):
    """Types of anomalies."""
    SPIKE = "spike"          # Sudden increase
    DIP = "dip"              # Sudden decrease
    TREND = "trend"          # Gradual change
    ABSENCE = "absence"      # Missing data
    THRESHOLD = "threshold"  # Crossed threshold


@dataclass
class MetricPoint:
    """A single metric data point."""

    timestamp: datetime
    value: float
    labels: dict = field(default_factory=dict)

    def __str__(self) -> str:
        return f"{self.timestamp.isoformat()}: {self.value}"


@dataclass
class MetricSeries:
    """A time series of metric points."""

    name: str
    points: list[MetricPoint] = field(default_factory=list)
    metric_type: MetricType = MetricType.GAUGE
    labels: dict = field(default_factory=dict)
    unit: str = ""

    def __str__(self) -> str:
        if not self.points:
            return f"{self.name}: (no data)"
        return f"{self.name}: {len(self.points)} points, latest={self.points[-1].value}"

    @property
    def values(self) -> list[float]:
        return [p.value for p in self.points]

    @property
    def latest(self) -> Optional[float]:
        return self.points[-1].value if self.points else None

    def mean(self) -> float:
        """Calculate mean of all values."""
        if not self.points:
            return 0.0
        return sum(self.values) / len(self.points)

    def stddev(self) -> float:
        """Calculate standard deviation."""
        if len(self.points) < 2:
            return 0.0
        mean = self.mean()
        variance = sum((v - mean) ** 2 for v in self.values) / len(self.points)
        return math.sqrt(variance)

    def min(self) -> float:
        """Get minimum value."""
        return min(self.values) if self.points else 0.0

    def max(self) -> float:
        """Get maximum value."""
        return max(self.values) if self.points else 0.0

    def percentile(self, p: float) -> float:
        """Calculate percentile (0-100)."""
        if not self.points:
            return 0.0
        sorted_values = sorted(self.values)
        idx = int(len(sorted_values) * p / 100)
        return sorted_values[min(idx, len(sorted_values) - 1)]


@dataclass
class Anomaly:
    """A detected anomaly in metrics."""

    anomaly_type: AnomalyType
    metric_name: str
    timestamp: datetime
    current_value: float
    expected_value: float
    severity: str = "warning"  # info, warning, critical
    message: str = ""

    def __str__(self) -> str:
        return f"[{self.severity.upper()}] {self.anomaly_type.value}: {self.message}"


@dataclass
class Baseline:
    """A baseline for comparison."""

    metric_name: str
    mean: float
    stddev: float
    min: float
    max: float
    p50: float = 0.0
    p95: float = 0.0
    p99: float = 0.0
    sample_count: int = 0
    period_hours: int = 24

    @classmethod
    def from_series(cls, series: MetricSeries, period_hours: int = 24) -> "Baseline":
        """Create baseline from a metric series."""
        return cls(
            metric_name=series.name,
            mean=series.mean(),
            stddev=series.stddev(),
            min=series.min(),
            max=series.max(),
            p50=series.percentile(50),
            p95=series.percentile(95),
            p99=series.percentile(99),
            sample_count=len(series.points),
            period_hours=period_hours,
        )

    def __str__(self) -> str:
        return f"{self.metric_name}: mean={self.mean:.2f}, stddev={self.stddev:.2f}, range=[{self.min:.2f}, {self.max:.2f}]"


# =============================================================================
# Anomaly Detection Functions
# =============================================================================

def detect_spike(
    current: float,
    baseline: Baseline,
    threshold_stddev: float = 3.0,
) -> Optional[Anomaly]:
    """Detect if current value is a spike above baseline.

    Args:
        current: Current metric value
        baseline: Historical baseline
        threshold_stddev: Number of standard deviations for spike

    Returns:
        Anomaly if detected, None otherwise
    """
    if baseline.stddev == 0:
        # No variation in baseline, use percentage threshold
        if baseline.mean > 0 and current > baseline.mean * 1.5:
            return Anomaly(
                anomaly_type=AnomalyType.SPIKE,
                metric_name=baseline.metric_name,
                timestamp=datetime.now(),
                current_value=current,
                expected_value=baseline.mean,
                severity="warning",
                message=f"{baseline.metric_name} is {current:.2f}, 50%+ above baseline {baseline.mean:.2f}",
            )
        return None

    z_score = (current - baseline.mean) / baseline.stddev

    if z_score > threshold_stddev:
        severity = "critical" if z_score > 5 else "warning"
        return Anomaly(
            anomaly_type=AnomalyType.SPIKE,
            metric_name=baseline.metric_name,
            timestamp=datetime.now(),
            current_value=current,
            expected_value=baseline.mean,
            severity=severity,
            message=f"{baseline.metric_name} is {current:.2f}, {z_score:.1f} stddev above baseline {baseline.mean:.2f}",
        )

    return None


def detect_dip(
    current: float,
    baseline: Baseline,
    threshold_stddev: float = 3.0,
) -> Optional[Anomaly]:
    """Detect if current value is a dip below baseline.

    Args:
        current: Current metric value
        baseline: Historical baseline
        threshold_stddev: Number of standard deviations for dip

    Returns:
        Anomaly if detected, None otherwise
    """
    if baseline.stddev == 0:
        if baseline.mean > 0 and current < baseline.mean * 0.5:
            return Anomaly(
                anomaly_type=AnomalyType.DIP,
                metric_name=baseline.metric_name,
                timestamp=datetime.now(),
                current_value=current,
                expected_value=baseline.mean,
                severity="warning",
                message=f"{baseline.metric_name} is {current:.2f}, 50%+ below baseline {baseline.mean:.2f}",
            )
        return None

    z_score = (baseline.mean - current) / baseline.stddev

    if z_score > threshold_stddev:
        severity = "critical" if z_score > 5 else "warning"
        return Anomaly(
            anomaly_type=AnomalyType.DIP,
            metric_name=baseline.metric_name,
            timestamp=datetime.now(),
            current_value=current,
            expected_value=baseline.mean,
            severity=severity,
            message=f"{baseline.metric_name} is {current:.2f}, {z_score:.1f} stddev below baseline {baseline.mean:.2f}",
        )

    return None


def detect_threshold_breach(
    current: float,
    metric_name: str,
    warning_threshold: Optional[float] = None,
    critical_threshold: Optional[float] = None,
    direction: str = "above",  # "above" or "below"
) -> Optional[Anomaly]:
    """Detect if current value breaches a threshold.

    Args:
        current: Current metric value
        metric_name: Name of the metric
        warning_threshold: Warning level threshold
        critical_threshold: Critical level threshold
        direction: Whether to check "above" or "below" threshold

    Returns:
        Anomaly if threshold breached, None otherwise
    """
    if direction == "above":
        if critical_threshold is not None and current > critical_threshold:
            return Anomaly(
                anomaly_type=AnomalyType.THRESHOLD,
                metric_name=metric_name,
                timestamp=datetime.now(),
                current_value=current,
                expected_value=critical_threshold,
                severity="critical",
                message=f"{metric_name} is {current:.2f}, above critical threshold {critical_threshold:.2f}",
            )
        if warning_threshold is not None and current > warning_threshold:
            return Anomaly(
                anomaly_type=AnomalyType.THRESHOLD,
                metric_name=metric_name,
                timestamp=datetime.now(),
                current_value=current,
                expected_value=warning_threshold,
                severity="warning",
                message=f"{metric_name} is {current:.2f}, above warning threshold {warning_threshold:.2f}",
            )
    else:  # below
        if critical_threshold is not None and current < critical_threshold:
            return Anomaly(
                anomaly_type=AnomalyType.THRESHOLD,
                metric_name=metric_name,
                timestamp=datetime.now(),
                current_value=current,
                expected_value=critical_threshold,
                severity="critical",
                message=f"{metric_name} is {current:.2f}, below critical threshold {critical_threshold:.2f}",
            )
        if warning_threshold is not None and current < warning_threshold:
            return Anomaly(
                anomaly_type=AnomalyType.THRESHOLD,
                metric_name=metric_name,
                timestamp=datetime.now(),
                current_value=current,
                expected_value=warning_threshold,
                severity="warning",
                message=f"{metric_name} is {current:.2f}, below warning threshold {warning_threshold:.2f}",
            )

    return None


def detect_trend(
    series: MetricSeries,
    window_points: int = 10,
    threshold_percent: float = 20.0,
) -> Optional[Anomaly]:
    """Detect if there's a significant trend in the metric.

    Args:
        series: Metric time series
        window_points: Number of recent points to analyze
        threshold_percent: Percentage change to consider significant

    Returns:
        Anomaly if trend detected, None otherwise
    """
    if len(series.points) < window_points:
        return None

    recent = series.points[-window_points:]
    first_half = recent[:window_points // 2]
    second_half = recent[window_points // 2:]

    first_mean = sum(p.value for p in first_half) / len(first_half)
    second_mean = sum(p.value for p in second_half) / len(second_half)

    if first_mean == 0:
        return None

    change_percent = ((second_mean - first_mean) / first_mean) * 100

    if abs(change_percent) > threshold_percent:
        direction = "increasing" if change_percent > 0 else "decreasing"
        return Anomaly(
            anomaly_type=AnomalyType.TREND,
            metric_name=series.name,
            timestamp=datetime.now(),
            current_value=second_mean,
            expected_value=first_mean,
            severity="warning",
            message=f"{series.name} is {direction} by {abs(change_percent):.1f}% ({first_mean:.2f} -> {second_mean:.2f})",
        )

    return None


def compare_periods(
    current_series: MetricSeries,
    previous_series: MetricSeries,
    threshold_percent: float = 25.0,
) -> list[Anomaly]:
    """Compare current period to previous period.

    Args:
        current_series: Current period data
        previous_series: Previous period data (e.g., same time yesterday)
        threshold_percent: Percentage difference to flag

    Returns:
        List of anomalies detected
    """
    anomalies = []

    current_mean = current_series.mean()
    previous_mean = previous_series.mean()

    if previous_mean == 0:
        return anomalies

    change_percent = ((current_mean - previous_mean) / previous_mean) * 100

    if abs(change_percent) > threshold_percent:
        direction = "higher" if change_percent > 0 else "lower"
        anomalies.append(Anomaly(
            anomaly_type=AnomalyType.TREND,
            metric_name=current_series.name,
            timestamp=datetime.now(),
            current_value=current_mean,
            expected_value=previous_mean,
            severity="warning",
            message=f"{current_series.name} is {abs(change_percent):.1f}% {direction} than previous period",
        ))

    return anomalies


# =============================================================================
# Aggregation Functions
# =============================================================================

def aggregate_series(
    series: MetricSeries,
    interval_seconds: int = 60,
    aggregation: str = "mean",  # mean, sum, max, min, count
) -> MetricSeries:
    """Aggregate a metric series into fixed intervals.

    Args:
        series: Input metric series
        interval_seconds: Aggregation interval
        aggregation: Aggregation function

    Returns:
        Aggregated metric series
    """
    if not series.points:
        return MetricSeries(name=series.name, labels=series.labels)

    # Group points by interval
    buckets: dict[datetime, list[float]] = {}
    interval = timedelta(seconds=interval_seconds)

    for point in series.points:
        # Round down to interval
        bucket_ts = datetime.fromtimestamp(
            (point.timestamp.timestamp() // interval_seconds) * interval_seconds
        )
        if bucket_ts not in buckets:
            buckets[bucket_ts] = []
        buckets[bucket_ts].append(point.value)

    # Aggregate each bucket
    aggregated_points = []
    for ts in sorted(buckets.keys()):
        values = buckets[ts]
        if aggregation == "mean":
            value = sum(values) / len(values)
        elif aggregation == "sum":
            value = sum(values)
        elif aggregation == "max":
            value = max(values)
        elif aggregation == "min":
            value = min(values)
        elif aggregation == "count":
            value = float(len(values))
        else:
            value = sum(values) / len(values)  # Default to mean

        aggregated_points.append(MetricPoint(timestamp=ts, value=value))

    return MetricSeries(
        name=series.name,
        points=aggregated_points,
        metric_type=series.metric_type,
        labels=series.labels,
        unit=series.unit,
    )


def format_metric_summary(series: MetricSeries) -> str:
    """Format a metric series as a readable summary.

    Args:
        series: Metric series to summarize

    Returns:
        Formatted summary string
    """
    if not series.points:
        return f"{series.name}: No data"

    lines = [
        f"Metric: {series.name}",
        f"  Type: {series.metric_type.value}",
        f"  Points: {len(series.points)}",
        f"  Latest: {series.latest:.2f}",
        f"  Mean: {series.mean():.2f}",
        f"  Std Dev: {series.stddev():.2f}",
        f"  Range: [{series.min():.2f}, {series.max():.2f}]",
        f"  P50: {series.percentile(50):.2f}",
        f"  P95: {series.percentile(95):.2f}",
        f"  P99: {series.percentile(99):.2f}",
    ]

    if series.unit:
        lines[0] = f"Metric: {series.name} ({series.unit})"

    return "\n".join(lines)
