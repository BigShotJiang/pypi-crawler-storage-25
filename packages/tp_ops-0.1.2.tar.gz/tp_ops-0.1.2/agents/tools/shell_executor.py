"""Shell command execution utilities.

Safe shell execution with timeout, output capture, and parsing.
Used by ShellAgent and all CLI-based agents.
"""

import json
import re
import subprocess
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class CommandResult:
    """Result of a shell command execution."""

    success: bool
    stdout: str
    stderr: str
    return_code: int
    command: list[str] = field(default_factory=list)
    timed_out: bool = False

    def __str__(self) -> str:
        if self.success:
            return self.stdout if self.stdout else "(no output)"
        if self.timed_out:
            return f"Command timed out: {' '.join(self.command)}"
        return f"Error (code {self.return_code}): {self.stderr or self.stdout}"


def execute_command(
    cmd: list[str],
    timeout: int = 60,
    env: Optional[dict] = None,
    capture_stderr: bool = True,
    cwd: Optional[str] = None,
) -> CommandResult:
    """Execute a shell command safely with timeout.

    Args:
        cmd: Command as list of strings (e.g., ["kubectl", "get", "pods"])
        timeout: Timeout in seconds (default 60)
        env: Optional environment variables to set
        capture_stderr: Whether to capture stderr (default True)
        cwd: Working directory for command

    Returns:
        CommandResult with success status, output, and metadata
    """
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
            cwd=cwd,
        )

        return CommandResult(
            success=result.returncode == 0,
            stdout=result.stdout.strip(),
            stderr=result.stderr.strip() if capture_stderr else "",
            return_code=result.returncode,
            command=cmd,
        )

    except subprocess.TimeoutExpired:
        return CommandResult(
            success=False,
            stdout="",
            stderr=f"Command timed out after {timeout} seconds",
            return_code=-1,
            command=cmd,
            timed_out=True,
        )

    except FileNotFoundError:
        return CommandResult(
            success=False,
            stdout="",
            stderr=f"Command not found: {cmd[0]}",
            return_code=-1,
            command=cmd,
        )

    except Exception as e:
        return CommandResult(
            success=False,
            stdout="",
            stderr=str(e),
            return_code=-1,
            command=cmd,
        )


def parse_json_output(raw: str) -> dict:
    """Parse JSON output from CLI commands.

    Handles common edge cases:
    - Empty output
    - Output with leading/trailing whitespace
    - Output with non-JSON prefix (e.g., warnings)

    Args:
        raw: Raw string output from command

    Returns:
        Parsed dict, or {"error": "message"} on failure
    """
    if not raw or not raw.strip():
        return {"items": [], "_empty": True}

    text = raw.strip()

    # Try direct parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to find JSON object or array in output
    # (handles cases where there's warning text before JSON)
    for start_char, end_char in [('{', '}'), ('[', ']')]:
        start_idx = text.find(start_char)
        if start_idx != -1:
            # Find matching end bracket
            depth = 0
            for i, c in enumerate(text[start_idx:], start_idx):
                if c == start_char:
                    depth += 1
                elif c == end_char:
                    depth -= 1
                    if depth == 0:
                        try:
                            return json.loads(text[start_idx:i+1])
                        except json.JSONDecodeError:
                            break

    return {"error": "Failed to parse JSON", "raw": text[:500]}


def parse_table_output(
    raw: str,
    headers: Optional[list[str]] = None,
    separator: Optional[str] = None,
) -> list[dict]:
    """Parse tabular CLI output into list of dicts.

    Handles common CLI table formats:
    - Space-separated columns (kubectl, docker, ps)
    - Tab-separated columns
    - Fixed-width columns

    Args:
        raw: Raw string output from command
        headers: Optional list of header names (auto-detected if not provided)
        separator: Column separator regex (auto-detected if not provided)

    Returns:
        List of dicts, one per row
    """
    if not raw or not raw.strip():
        return []

    lines = raw.strip().split('\n')
    if len(lines) < 1:
        return []

    # Auto-detect headers from first line if not provided
    if headers is None:
        header_line = lines[0]
        # Try to split by 2+ spaces (common in CLI output)
        headers = re.split(r'\s{2,}', header_line.strip())
        if len(headers) == 1:
            # Fall back to single space split
            headers = header_line.split()
        lines = lines[1:]

    # Normalize headers (lowercase, replace spaces with underscores)
    headers = [h.lower().replace(' ', '_').replace('-', '_') for h in headers]

    results = []
    for line in lines:
        if not line.strip():
            continue

        # Split values - try 2+ spaces first, then single space
        values = re.split(r'\s{2,}', line.strip())
        if len(values) == 1 or len(values) < len(headers):
            values = line.split()

        # Pad values if fewer than headers
        while len(values) < len(headers):
            values.append("")

        # If more values than headers, combine extras into last column
        if len(values) > len(headers):
            values = values[:len(headers)-1] + [' '.join(values[len(headers)-1:])]

        row = dict(zip(headers, values))
        results.append(row)

    return results


def format_command_for_display(cmd: list[str], max_length: int = 80) -> str:
    """Format a command list for display, truncating if needed.

    Args:
        cmd: Command as list of strings
        max_length: Maximum display length

    Returns:
        Formatted string representation
    """
    full = ' '.join(cmd)
    if len(full) <= max_length:
        return full
    return full[:max_length-3] + "..."


def mask_sensitive_args(cmd: list[str], sensitive_flags: list[str] = None) -> list[str]:
    """Mask sensitive arguments in a command for logging.

    Args:
        cmd: Command as list of strings
        sensitive_flags: Flags whose values should be masked
                        (default: --password, --token, --key, --secret)

    Returns:
        Command list with sensitive values replaced by ***
    """
    if sensitive_flags is None:
        sensitive_flags = ['--password', '--token', '--key', '--secret', '-p']

    result = []
    mask_next = False

    for arg in cmd:
        if mask_next:
            result.append('***')
            mask_next = False
        elif any(arg.startswith(f) for f in sensitive_flags):
            if '=' in arg:
                # --password=secret -> --password=***
                flag, _ = arg.split('=', 1)
                result.append(f"{flag}=***")
            else:
                result.append(arg)
                mask_next = True
        else:
            result.append(arg)

    return result
