"""Database connection and query utilities.

Safe database query execution with connection pooling,
query sanitization, and result formatting.
Used by DatabaseAgent and all database agents.
"""

import re
from dataclasses import dataclass, field
from typing import Optional, Any
from enum import Enum


class DatabaseType(Enum):
    """Supported database types."""
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"
    MONGODB = "mongodb"
    REDIS = "redis"
    SQLITE = "sqlite"
    MSSQL = "mssql"
    AZURE_SQL = "azure sql"
    CASSANDRA = "cassandra"
    CITUS = "citus"
    CLICKHOUSE = "clickhouse"
    COCKROACHDB = "cockroachdb"
    ELASTICSEARCH = "elasticsearch"
    NEO4J = "neo4j"
    ORACLE = "oracle"
    SNOWFLAKE = "snowflake"
    SQLSERVER = "sql server"
    TIMESCALEDB = "timescaledb"


@dataclass
class QueryResult:
    """Result of a database query."""

    success: bool
    rows: list[dict] = field(default_factory=list)
    columns: list[str] = field(default_factory=list)
    row_count: int = 0
    error: str = ""
    query: str = ""
    execution_time_ms: float = 0.0

    def __str__(self) -> str:
        if self.success:
            if self.rows:
                return format_results_table(self.rows, self.columns)
            return f"Query OK, {self.row_count} rows affected"
        return f"Error: {self.error}"


@dataclass
class ConnectionConfig:
    """Database connection configuration."""

    db_type: DatabaseType
    host: str = "localhost"
    port: int = 0  # 0 means use default for db_type
    database: str = ""
    user: str = ""
    password: str = ""
    ssl: bool = False
    connection_string: str = ""  # Alternative to individual params

    def get_port(self) -> int:
        """Get port, using default if not specified."""
        if self.port > 0:
            return self.port

        defaults = {
            DatabaseType.POSTGRESQL: 5432,
            DatabaseType.MYSQL: 3306,
            DatabaseType.MONGODB: 27017,
            DatabaseType.REDIS: 6379,
            DatabaseType.SQLITE: 0,
            DatabaseType.MSSQL: 1433,
        }
        return defaults.get(self.db_type, 0)


# =============================================================================
# Query Sanitization
# =============================================================================

# SQL keywords that indicate dangerous operations
DANGEROUS_SQL_KEYWORDS = [
    "DROP", "DELETE", "TRUNCATE", "ALTER", "CREATE", "INSERT", "UPDATE",
    "GRANT", "REVOKE", "EXEC", "EXECUTE", "MERGE", "REPLACE",
    "LOAD", "BACKUP", "RESTORE", "SHUTDOWN",
]

# Safe SQL keywords for read operations
SAFE_SQL_KEYWORDS = [
    "SELECT", "SHOW", "DESCRIBE", "DESC", "EXPLAIN", "ANALYZE",
    "WITH",  # CTEs are safe when followed by SELECT
]

# Patterns that indicate SQL injection attempts
INJECTION_PATTERNS = [
    r";\s*(?:DROP|DELETE|INSERT|UPDATE|ALTER|CREATE)",  # Statement chaining
    r"--",  # SQL comment
    r"/\*",  # Block comment start
    r"'\s*OR\s+'",  # OR injection
    r"'\s*OR\s+\d",  # OR injection with number
    r"UNION\s+(?:ALL\s+)?SELECT",  # UNION injection
    r"INTO\s+(?:OUT|DUMP)FILE",  # File operations
    r"LOAD_FILE",  # File read
    r"@@",  # System variables
]


class QueryValidationError(Exception):
    """Raised when query validation fails."""
    pass


def validate_query(
    query: str,
    db_type: DatabaseType,
    allow_writes: bool = False,
) -> str:
    """Validate and sanitize a database query.

    Args:
        query: SQL query string
        db_type: Type of database
        allow_writes: Whether to allow write operations

    Returns:
        Validated query string

    Raises:
        QueryValidationError: If query is invalid or dangerous
    """
    if not query or not query.strip():
        raise QueryValidationError("Empty query")

    query = query.strip()

    # Check for injection patterns
    for pattern in INJECTION_PATTERNS:
        if re.search(pattern, query, re.IGNORECASE):
            raise QueryValidationError(f"Potential SQL injection detected")

    # Get first keyword
    first_word = query.split()[0].upper() if query.split() else ""

    if not allow_writes:
        # Check if query starts with dangerous keyword
        if first_word in DANGEROUS_SQL_KEYWORDS:
            raise QueryValidationError(
                f"Write operation '{first_word}' not allowed. "
                f"Use the write tool for modifications."
            )

        # Check if query contains dangerous keywords after semicolon
        if ";" in query:
            parts = query.split(";")
            for part in parts[1:]:  # Skip first statement
                part_first = part.strip().split()[0].upper() if part.strip().split() else ""
                if part_first in DANGEROUS_SQL_KEYWORDS:
                    raise QueryValidationError(
                        f"Statement chaining with write operations not allowed"
                    )

    return query


def validate_redis_command(command: str, allow_writes: bool = False) -> str:
    """Validate a Redis command.

    Args:
        command: Redis command string
        allow_writes: Whether to allow write operations

    Returns:
        Validated command string

    Raises:
        QueryValidationError: If command is invalid or dangerous
    """
    if not command or not command.strip():
        raise QueryValidationError("Empty command")

    command = command.strip()
    cmd_upper = command.split()[0].upper() if command.split() else ""

    # Dangerous Redis commands
    dangerous_commands = [
        "DEL", "FLUSHALL", "FLUSHDB", "SHUTDOWN", "DEBUG",
        "CONFIG", "SLAVEOF", "REPLICAOF", "MIGRATE", "DUMP",
        "RESTORE", "CLUSTER", "SCRIPT", "EVAL", "EVALSHA",
        "MODULE", "ACL", "BGSAVE", "BGREWRITEAOF",
    ]

    # Write commands (not immediately dangerous but modify data)
    write_commands = [
        "SET", "SETNX", "SETEX", "PSETEX", "MSET", "MSETNX",
        "APPEND", "INCR", "INCRBY", "INCRBYFLOAT", "DECR", "DECRBY",
        "LPUSH", "RPUSH", "LPOP", "RPOP", "LSET", "LREM", "LTRIM",
        "SADD", "SREM", "SPOP", "SMOVE",
        "ZADD", "ZREM", "ZINCRBY", "ZREMRANGEBYRANK", "ZREMRANGEBYSCORE",
        "HSET", "HSETNX", "HMSET", "HDEL", "HINCRBY", "HINCRBYFLOAT",
        "EXPIRE", "EXPIREAT", "PEXPIRE", "PEXPIREAT", "PERSIST",
        "RENAME", "RENAMENX", "COPY", "MOVE",
        "PUBLISH", "XADD", "XTRIM", "XDEL",
    ]

    if cmd_upper in dangerous_commands:
        raise QueryValidationError(
            f"Dangerous command '{cmd_upper}' not allowed"
        )

    if not allow_writes and cmd_upper in write_commands:
        raise QueryValidationError(
            f"Write command '{cmd_upper}' not allowed. "
            f"Use the write tool for modifications."
        )

    return command


def validate_mongodb_query(query: str, allow_writes: bool = False) -> str:
    """Validate a MongoDB query/command.

    Args:
        query: MongoDB command string
        allow_writes: Whether to allow write operations

    Returns:
        Validated query string

    Raises:
        QueryValidationError: If query is invalid or dangerous
    """
    if not query or not query.strip():
        raise QueryValidationError("Empty query")

    query = query.strip()

    # Dangerous MongoDB operations
    dangerous_ops = [
        "dropDatabase", "dropCollection", "drop(",
        "createUser", "dropUser", "updateUser",
        "createRole", "dropRole", "grantRolesToUser",
        "shutdownServer", "fsync", "repairDatabase",
    ]

    # Write operations
    write_ops = [
        "insert", "insertOne", "insertMany",
        "update", "updateOne", "updateMany",
        "delete", "deleteOne", "deleteMany",
        "remove", "save", "replaceOne",
        "findOneAndUpdate", "findOneAndDelete", "findOneAndReplace",
        "bulkWrite", "createIndex", "dropIndex",
    ]

    query_lower = query.lower()

    for op in dangerous_ops:
        if op.lower() in query_lower:
            raise QueryValidationError(
                f"Dangerous operation '{op}' not allowed"
            )

    if not allow_writes:
        for op in write_ops:
            if op.lower() in query_lower:
                raise QueryValidationError(
                    f"Write operation '{op}' not allowed. "
                    f"Use the write tool for modifications."
                )

    return query


# =============================================================================
# Result Formatting
# =============================================================================

def format_results_table(
    rows: list[dict],
    columns: Optional[list[str]] = None,
    max_rows: int = 50,
    max_col_width: int = 40,
) -> str:
    """Format query results as an ASCII table.

    Args:
        rows: List of row dictionaries
        columns: Column names (auto-detected if not provided)
        max_rows: Maximum rows to display
        max_col_width: Maximum column width

    Returns:
        Formatted table string
    """
    if not rows:
        return "(no rows)"

    # Get columns from first row if not provided
    if columns is None:
        columns = list(rows[0].keys())

    # Calculate column widths
    widths = {}
    for col in columns:
        widths[col] = min(
            max(
                len(str(col)),
                max(len(str(row.get(col, ""))) for row in rows[:max_rows])
            ),
            max_col_width
        )

    # Build header
    header = " | ".join(
        str(col).ljust(widths[col])[:widths[col]]
        for col in columns
    )
    separator = "-+-".join("-" * widths[col] for col in columns)

    # Build rows
    lines = [header, separator]
    for row in rows[:max_rows]:
        line = " | ".join(
            str(row.get(col, "")).ljust(widths[col])[:widths[col]]
            for col in columns
        )
        lines.append(line)

    if len(rows) > max_rows:
        lines.append(f"... ({len(rows) - max_rows} more rows)")

    return "\n".join(lines)


def summarize_query_result(result: QueryResult, db_type: DatabaseType) -> str:
    """Generate a human-readable summary of query results.

    Args:
        result: Query result to summarize
        db_type: Type of database

    Returns:
        Summary string
    """
    if not result.success:
        return f"Query failed: {result.error}"

    if not result.rows:
        return f"Query returned no rows ({result.execution_time_ms:.1f}ms)"

    summary_lines = [
        f"Found {len(result.rows)} row(s) ({result.execution_time_ms:.1f}ms)",
        "",
        str(result),
    ]

    return "\n".join(summary_lines)


# =============================================================================
# Common Database Queries
# =============================================================================

# PostgreSQL performance queries
POSTGRESQL_QUERIES = {
    "active_connections": """
        SELECT pid, usename, application_name, client_addr, state, query
        FROM pg_stat_activity
        WHERE state != 'idle'
        ORDER BY query_start DESC
        LIMIT 20
    """,
    "slow_queries": """
        SELECT query, calls, mean_exec_time, total_exec_time
        FROM pg_stat_statements
        ORDER BY mean_exec_time DESC
        LIMIT 10
    """,
    "table_sizes": """
        SELECT schemaname, tablename,
               pg_size_pretty(pg_total_relation_size(schemaname || '.' || tablename)) as size
        FROM pg_tables
        WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
        ORDER BY pg_total_relation_size(schemaname || '.' || tablename) DESC
        LIMIT 20
    """,
    "index_usage": """
        SELECT schemaname, tablename, indexname, idx_scan, idx_tup_read
        FROM pg_stat_user_indexes
        ORDER BY idx_scan DESC
        LIMIT 20
    """,
    "locks": """
        SELECT blocked_locks.pid AS blocked_pid,
               blocking_locks.pid AS blocking_pid,
               blocked_activity.usename AS blocked_user,
               blocking_activity.usename AS blocking_user,
               blocked_activity.query AS blocked_query
        FROM pg_catalog.pg_locks blocked_locks
        JOIN pg_catalog.pg_stat_activity blocked_activity ON blocked_activity.pid = blocked_locks.pid
        JOIN pg_catalog.pg_locks blocking_locks ON blocking_locks.locktype = blocked_locks.locktype
        JOIN pg_catalog.pg_stat_activity blocking_activity ON blocking_activity.pid = blocking_locks.pid
        WHERE NOT blocked_locks.granted AND blocking_locks.granted
        LIMIT 10
    """,
    "replication_status": """
        SELECT client_addr, state, sent_lsn, write_lsn, flush_lsn, replay_lsn
        FROM pg_stat_replication
    """,
}

# MySQL performance queries
MYSQL_QUERIES = {
    "active_connections": """
        SELECT id, user, host, db, command, time, state, info
        FROM information_schema.processlist
        WHERE command != 'Sleep'
        ORDER BY time DESC
        LIMIT 20
    """,
    "slow_queries": """
        SHOW GLOBAL STATUS LIKE 'Slow_queries'
    """,
    "table_sizes": """
        SELECT table_schema, table_name,
               ROUND((data_length + index_length) / 1024 / 1024, 2) AS size_mb
        FROM information_schema.tables
        WHERE table_schema NOT IN ('mysql', 'information_schema', 'performance_schema')
        ORDER BY (data_length + index_length) DESC
        LIMIT 20
    """,
    "innodb_status": """
        SHOW ENGINE INNODB STATUS
    """,
}

# Redis info commands
REDIS_COMMANDS = {
    "info": "INFO",
    "memory": "INFO memory",
    "clients": "INFO clients",
    "stats": "INFO stats",
    "replication": "INFO replication",
    "keyspace": "INFO keyspace",
    "slowlog": "SLOWLOG GET 10",
    "big_keys": "DEBUG OBJECT",  # Note: requires specific key
}

# MongoDB diagnostic commands
MONGODB_COMMANDS = {
    "server_status": "db.serverStatus()",
    "current_ops": "db.currentOp()",
    "replication_status": "rs.status()",
    "collection_stats": "db.stats()",
    "top": "db.adminCommand({top: 1})",
}
