"""Log parsing and error extraction utilities.

Common log parsing patterns and utilities for log-based agents.
Used by LogAgent and all logging/monitoring agents.
"""

import re
from dataclasses import dataclass, field
from typing import Optional, Any
from datetime import datetime
from enum import Enum


class LogLevel(Enum):
    """Standard log levels."""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"
    FATAL = "fatal"


@dataclass
class LogEntry:
    """Parsed log entry."""

    timestamp: Optional[datetime] = None
    level: LogLevel = LogLevel.INFO
    message: str = ""
    source: str = ""
    raw: str = ""
    line_number: int = 0
    fields: dict = field(default_factory=dict)

    def __str__(self) -> str:
        ts = self.timestamp.strftime("%Y-%m-%d %H:%M:%S") if self.timestamp else "unknown"
        return f"[{ts}] [{self.level.value.upper()}] {self.message}"


@dataclass
class ErrorMatch:
    """A matched error in logs."""

    pattern_name: str
    line: str
    line_number: int
    context_before: list[str] = field(default_factory=list)
    context_after: list[str] = field(default_factory=list)
    timestamp: Optional[datetime] = None
    severity: str = "error"

    def __str__(self) -> str:
        return f"{self.pattern_name}: {self.line}"


@dataclass
class EventChain:
    """A chain of correlated events."""

    events: list[LogEntry] = field(default_factory=list)
    root_cause: Optional[LogEntry] = None
    window_seconds: int = 300

    def __str__(self) -> str:
        if not self.events:
            return "(no events)"
        return f"Chain of {len(self.events)} events starting with: {self.root_cause or self.events[0]}"


# =============================================================================
# Common Error Patterns
# =============================================================================

# Patterns that indicate errors across various log formats
COMMON_ERROR_PATTERNS = {
    # General error indicators
    "exception": r"(?i)(exception|error|fatal|panic|critical|fail(?:ed|ure)?)",
    "stack_trace": r"^\s+at\s+.*\(.*:\d+\)",
    "python_traceback": r"Traceback \(most recent call last\):",
    "java_exception": r"(?:Exception|Error):\s",

    # System errors
    "oom_killer": r"Out of memory: Kill(?:ed)? process",
    "segfault": r"segfault at|segmentation fault",
    "kernel_panic": r"Kernel panic",
    "disk_error": r"I/O error|disk error|read.only file system",

    # Network errors
    "connection_refused": r"Connection refused|ECONNREFUSED",
    "connection_timeout": r"Connection timed? ?out|ETIMEDOUT",
    "connection_reset": r"Connection reset|ECONNRESET",
    "dns_error": r"Name or service not known|NXDOMAIN|DNS resolution failed",

    # Application errors
    "null_pointer": r"NullPointerException|TypeError: .* is null|undefined is not",
    "assertion_failed": r"AssertionError|assertion failed",
    "permission_denied": r"Permission denied|EACCES|EPERM|403 Forbidden",
    "not_found": r"(?:File |Resource )?[Nn]ot [Ff]ound|ENOENT|404 Not Found",

    # Database errors
    "db_connection": r"Connection to .* failed|Unable to connect to database",
    "deadlock": r"[Dd]eadlock|lock wait timeout|DEADLOCK DETECTED",
    "query_timeout": r"[Qq]uery timeout|statement timeout",

    # Kubernetes/container errors
    "crash_loop": r"CrashLoopBackOff|Back-off restarting",
    "image_pull": r"ImagePullBackOff|Failed to pull image",
    "liveness_failed": r"Liveness probe failed",
    "readiness_failed": r"Readiness probe failed",
}

# Timestamp patterns for common log formats
TIMESTAMP_PATTERNS = [
    # ISO 8601: 2024-01-15T14:30:00.000Z
    (r"(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)", "%Y-%m-%dT%H:%M:%S"),
    # Syslog: Jan 15 14:30:00
    (r"([A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})", "%b %d %H:%M:%S"),
    # Apache/Nginx: 15/Jan/2024:14:30:00
    (r"(\d{2}/[A-Z][a-z]{2}/\d{4}:\d{2}:\d{2}:\d{2})", "%d/%b/%Y:%H:%M:%S"),
    # Unix timestamp
    (r"^(\d{10})(?:\.\d+)?", "unix"),
]

# Log level patterns
LOG_LEVEL_PATTERNS = {
    LogLevel.DEBUG: r"(?i)\b(DEBUG|TRACE|VERBOSE)\b",
    LogLevel.INFO: r"(?i)\b(INFO|NOTICE)\b",
    LogLevel.WARNING: r"(?i)\b(WARN(?:ING)?|ALERT)\b",
    LogLevel.ERROR: r"(?i)\b(ERROR|ERR)\b",
    LogLevel.CRITICAL: r"(?i)\b(CRITICAL|CRIT)\b",
    LogLevel.FATAL: r"(?i)\b(FATAL|EMERG(?:ENCY)?|PANIC)\b",
}


# =============================================================================
# Parsing Functions
# =============================================================================

def extract_timestamp(line: str) -> Optional[datetime]:
    """Extract timestamp from a log line.

    Args:
        line: Log line to parse

    Returns:
        datetime if found, None otherwise
    """
    for pattern, fmt in TIMESTAMP_PATTERNS:
        match = re.search(pattern, line)
        if match:
            ts_str = match.group(1)
            try:
                if fmt == "unix":
                    return datetime.fromtimestamp(int(ts_str))
                # Handle timezone-aware timestamps
                ts_str = re.sub(r'Z$', '+00:00', ts_str)
                ts_str = re.sub(r'([+-]\d{2})(\d{2})$', r'\1:\2', ts_str)
                return datetime.fromisoformat(ts_str)
            except ValueError:
                try:
                    return datetime.strptime(ts_str, fmt)
                except ValueError:
                    continue
    return None


def extract_log_level(line: str) -> LogLevel:
    """Extract log level from a log line.

    Args:
        line: Log line to parse

    Returns:
        LogLevel enum value
    """
    # Check from most to least severe
    for level in [LogLevel.FATAL, LogLevel.CRITICAL, LogLevel.ERROR,
                  LogLevel.WARNING, LogLevel.INFO, LogLevel.DEBUG]:
        if re.search(LOG_LEVEL_PATTERNS[level], line):
            return level
    return LogLevel.INFO


def parse_log_line(line: str, line_number: int = 0) -> LogEntry:
    """Parse a single log line into a LogEntry.

    Args:
        line: Raw log line
        line_number: Line number in source file

    Returns:
        Parsed LogEntry
    """
    return LogEntry(
        timestamp=extract_timestamp(line),
        level=extract_log_level(line),
        message=line.strip(),
        raw=line,
        line_number=line_number,
    )


def extract_errors(
    logs: str,
    patterns: Optional[dict[str, str]] = None,
    context_lines: int = 3,
) -> list[ErrorMatch]:
    """Extract error patterns from logs with context.

    Args:
        logs: Log content to search
        patterns: Custom patterns to use (defaults to COMMON_ERROR_PATTERNS)
        context_lines: Number of context lines to include

    Returns:
        List of ErrorMatch objects
    """
    if patterns is None:
        patterns = COMMON_ERROR_PATTERNS

    lines = logs.split('\n')
    matches = []

    for pattern_name, pattern in patterns.items():
        compiled = re.compile(pattern, re.IGNORECASE)

        for i, line in enumerate(lines):
            if compiled.search(line):
                # Get context
                start = max(0, i - context_lines)
                end = min(len(lines), i + context_lines + 1)

                match = ErrorMatch(
                    pattern_name=pattern_name,
                    line=line,
                    line_number=i + 1,
                    context_before=lines[start:i],
                    context_after=lines[i+1:end],
                    timestamp=extract_timestamp(line),
                    severity="error" if "error" in pattern_name.lower() else "warning",
                )
                matches.append(match)

    return matches


def correlate_events(
    events: list[LogEntry],
    window_seconds: int = 300,
) -> list[EventChain]:
    """Find causally related events within a time window.

    Groups events that occur close together in time,
    potentially indicating a cascade of related issues.

    Args:
        events: List of log entries (should be sorted by timestamp)
        window_seconds: Time window for correlation

    Returns:
        List of EventChain objects
    """
    if not events:
        return []

    # Filter to events with timestamps
    timestamped = [e for e in events if e.timestamp]
    if not timestamped:
        return []

    # Sort by timestamp
    timestamped.sort(key=lambda e: e.timestamp)

    chains = []
    current_chain = [timestamped[0]]

    for event in timestamped[1:]:
        # Check if within window of last event in chain
        last_ts = current_chain[-1].timestamp
        delta = (event.timestamp - last_ts).total_seconds()

        if delta <= window_seconds:
            current_chain.append(event)
        else:
            # Start new chain
            if len(current_chain) > 1:
                chains.append(EventChain(
                    events=current_chain,
                    root_cause=current_chain[0],
                    window_seconds=window_seconds,
                ))
            current_chain = [event]

    # Don't forget last chain
    if len(current_chain) > 1:
        chains.append(EventChain(
            events=current_chain,
            root_cause=current_chain[0],
            window_seconds=window_seconds,
        ))

    return chains


def summarize_errors(matches: list[ErrorMatch], max_display: int = 10) -> str:
    """Summarize error matches into a readable format.

    Args:
        matches: List of ErrorMatch objects
        max_display: Maximum number of errors to display in detail

    Returns:
        Formatted summary string
    """
    if not matches:
        return "No errors found."

    # Group by pattern
    by_pattern = {}
    for match in matches:
        if match.pattern_name not in by_pattern:
            by_pattern[match.pattern_name] = []
        by_pattern[match.pattern_name].append(match)

    lines = [f"Found {len(matches)} error(s) across {len(by_pattern)} pattern(s):\n"]

    for pattern_name, pattern_matches in sorted(by_pattern.items(), key=lambda x: -len(x[1])):
        lines.append(f"\n## {pattern_name} ({len(pattern_matches)} occurrences)")

        for match in pattern_matches[:max_display]:
            lines.append(f"  Line {match.line_number}: {match.line[:80]}...")
            if match.timestamp:
                lines.append(f"    Time: {match.timestamp}")

        if len(pattern_matches) > max_display:
            lines.append(f"  ... and {len(pattern_matches) - max_display} more")

    return "\n".join(lines)


def filter_logs_by_level(
    logs: str,
    min_level: LogLevel = LogLevel.WARNING,
) -> str:
    """Filter log lines to only those at or above a minimum level.

    Args:
        logs: Raw log content
        min_level: Minimum log level to include

    Returns:
        Filtered log content
    """
    level_order = [LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARNING,
                   LogLevel.ERROR, LogLevel.CRITICAL, LogLevel.FATAL]
    min_index = level_order.index(min_level)

    filtered = []
    for line in logs.split('\n'):
        line_level = extract_log_level(line)
        if level_order.index(line_level) >= min_index:
            filtered.append(line)

    return '\n'.join(filtered)


def tail_logs(
    logs: str,
    lines: int = 100,
    filter_pattern: Optional[str] = None,
) -> str:
    """Get the last N lines of logs, optionally filtered.

    Args:
        logs: Raw log content
        lines: Number of lines to return
        filter_pattern: Optional regex pattern to filter lines

    Returns:
        Last N lines of logs
    """
    all_lines = logs.split('\n')

    if filter_pattern:
        compiled = re.compile(filter_pattern, re.IGNORECASE)
        all_lines = [l for l in all_lines if compiled.search(l)]

    return '\n'.join(all_lines[-lines:])


def grep_logs(
    logs: str,
    pattern: str,
    context: int = 3,
    max_matches: int = 50,
) -> str:
    """Search logs with grep-like functionality.

    Args:
        logs: Raw log content
        pattern: Regex pattern to search for
        context: Number of context lines around matches
        max_matches: Maximum number of matches to return

    Returns:
        Matching lines with context
    """
    lines = logs.split('\n')
    compiled = re.compile(pattern, re.IGNORECASE)

    results = []
    match_count = 0

    for i, line in enumerate(lines):
        if compiled.search(line):
            if match_count >= max_matches:
                results.append(f"\n... ({len(lines)} more matches)")
                break

            # Get context
            start = max(0, i - context)
            end = min(len(lines), i + context + 1)

            if results:
                results.append("--")

            for j in range(start, end):
                prefix = ">" if j == i else " "
                results.append(f"{prefix} {j+1}: {lines[j]}")

            match_count += 1

    if not results:
        return f"No matches for pattern: {pattern}"

    return '\n'.join(results)
