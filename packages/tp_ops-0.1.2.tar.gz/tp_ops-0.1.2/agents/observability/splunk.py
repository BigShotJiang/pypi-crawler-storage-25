"""Splunk Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SplunkAgent(ShellAgent):
    """Agent for Splunk investigation."""

    COMMAND_PREFIX = ["splunk"]
    TOOL_NAME = "splunk"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "search", "list index", "list user", "list app",
        "show index", "show jobs", "show config",
        "btool", "display index",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "remove index", "edit index", "restart",
        "add user", "remove user", "clean",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 8089)
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Splunk investigation agent for {self.host}:{self.port}.

Available tools:
- splunk: Execute read-only Splunk commands
- splunk_write: Execute write commands (requires approval)

Investigation approach:
1. Search: splunk search "index=main | head 100"
2. Index List: splunk list index
3. Index Stats: splunk show index <index>
4. Apps: splunk list app
5. Jobs: splunk show jobs

Common SPL patterns:
- Errors: index=* error | stats count by source
- Top Sources: index=* | top source
- Time Chart: index=* | timechart count by host

Common issues:
- Search performance: Expensive searches, no time bounds
- Index issues: Indexer queue backed up
- Forwarder health: Forwarders not reporting
- License consumption: Approaching daily limit
- Unused indexes: Indexes with no data"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "error" in q:
            return "I'll search for errors.\n\nTOOL: splunk search 'index=* error | stats count by sourcetype | head 20'"
        if "index" in q:
            return "I'll list indexes.\n\nTOOL: splunk list index"
        if "forwarder" in q:
            return "I'll check forwarders.\n\nTOOL: splunk search 'index=_internal sourcetype=splunkd | stats latest(_time) by host'"
        return "I'll list indexes.\n\nTOOL: splunk list index"
