"""Zabbix Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ZabbixAgent(ShellAgent):
    """Agent for Zabbix monitoring investigation."""

    COMMAND_PREFIX = ["zabbix_get"]
    TOOL_NAME = "zabbix"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "host.get", "hostgroup.get", "item.get", "trigger.get",
        "problem.get", "event.get", "alert.get", "template.get",
        "history.get", "trend.get", "maintenance.get",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "host.create", "host.delete", "host.update",
        "trigger.update", "maintenance.create",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.server_url = config.get("server_url")
        self.api_token = config.get("api_token")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Zabbix investigation agent for server '{self.server_url}'.

Available tools:
- zabbix: Execute read-only Zabbix API calls
- zabbix_write: Execute write operations (requires approval)

Investigation approach:
1. Active Problems: zabbix_api problem.get
2. Recent Triggers: zabbix_api trigger.get (filter: value=1)
3. Host Status: zabbix_api host.get
4. Item History: zabbix_api history.get
5. Alerts: zabbix_api alert.get
6. Events: zabbix_api event.get

Problem triage:
- Severity levels: Disaster > High > Average > Warning > Information
- Acknowledged vs unacknowledged
- Problem duration and escalation status
- Related events and triggers

Host analysis:
- Availability status
- Item collection status
- Template assignments
- Agent connectivity

Common issues:
- Agent unreachable: Network or firewall issues
- Item collection failures: Timeouts, permissions
- Trigger storms: Cascading alerts
- Template misconfiguration: Wrong thresholds
- Maintenance gaps: Critical systems not covered
- Stale items: Disabled or broken data collection"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "problem" in q or "alert" in q:
            return "I'll check active problems.\n\nTOOL: zabbix zabbix_api problem.get --recent"
        if "trigger" in q:
            return "I'll check triggered alerts.\n\nTOOL: zabbix zabbix_api trigger.get --filter value=1"
        if "host" in q:
            return "I'll check host status.\n\nTOOL: zabbix zabbix_api host.get"
        if "history" in q or "metric" in q:
            return "I'll check item history.\n\nTOOL: zabbix zabbix_api history.get --itemids <id>"
        return "I'll check Zabbix status.\n\nTOOL: zabbix zabbix_api problem.get --recent"
