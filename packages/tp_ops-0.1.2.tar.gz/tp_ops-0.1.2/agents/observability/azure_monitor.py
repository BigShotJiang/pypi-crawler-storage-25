"""Azure Monitor Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureMonitorAgent(ShellAgent):
    """Agent for Azure Monitor / Log Analytics investigation."""

    COMMAND_PREFIX = ["az", "monitor"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "log-analytics workspace list", "log-analytics workspace show",
        "log-analytics query", "metrics list", "metrics list-definitions",
        "app-insights component show", "app-insights query",
        "activity-log list", "diagnostic-settings list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "log-analytics workspace create", "log-analytics workspace delete",
        "diagnostic-settings create", "diagnostic-settings delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.workspace_id = config.get("workspace_id")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Monitor investigation agent.

Workspace: {self.workspace_id}

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Workspace: az monitor log-analytics workspace show
2. KQL Query: az monitor log-analytics query --workspace {self.workspace_id} --analytics-query "<KQL>"
3. App Insights: az monitor app-insights query --apps <app> --analytics-query "<KQL>"
4. Metrics: az monitor metrics list --resource <resource-id>
5. Activity Log: az monitor activity-log list

Common KQL patterns:
- Exceptions: AppExceptions | summarize count() by problemId
- Requests: AppRequests | where success == false
- Performance: AppPerformanceCounters | where name == "% Processor Time"

Common issues:
- Cost waste: High data ingestion, unused tables
- Alert misconfig: Missing or noisy alerts
- Query performance: Expensive KQL queries"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "exception" in q or "error" in q:
            return f"I'll query exceptions.\n\nTOOL: az monitor log-analytics query --workspace {self.workspace_id} --analytics-query 'AppExceptions | take 50'"
        if "request" in q or "failure" in q:
            return f"I'll query failed requests.\n\nTOOL: az monitor log-analytics query --workspace {self.workspace_id} --analytics-query 'AppRequests | where success == false | take 50'"
        return f"I'll check the workspace.\n\nTOOL: az monitor log-analytics workspace show"
