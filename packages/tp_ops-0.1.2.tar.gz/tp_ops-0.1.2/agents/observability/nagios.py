"""Nagios Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NagiosAgent(ShellAgent):
    """Agent for Nagios monitoring investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "nagios"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "statusjson.cgi", "objectjson.cgi", "archivejson.cgi",
        "status.cgi", "extinfo.cgi", "showlog.cgi",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "cmd.cgi", "SCHEDULE_HOST_DOWNTIME", "DISABLE_HOST_CHECK",
        "ACKNOWLEDGE_HOST_PROBLEM",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.nagios_url = config.get("nagios_url")
        self.username = config.get("username")
        self.password = config.get("password")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Nagios investigation agent for '{self.nagios_url}'.

Available tools:
- nagios: Execute read-only Nagios CGI/API queries
- nagios_write: Execute commands (requires approval)

Investigation approach:
1. Host Status: /nagios/cgi-bin/statusjson.cgi?query=hostlist
2. Service Status: /nagios/cgi-bin/statusjson.cgi?query=servicelist
3. Problems: /nagios/cgi-bin/statusjson.cgi?query=servicelist&servicestatus=critical
4. Host Details: /nagios/cgi-bin/extinfo.cgi?type=1&host=<hostname>
5. Service Details: /nagios/cgi-bin/extinfo.cgi?type=2&host=<host>&service=<svc>
6. Logs: /nagios/cgi-bin/showlog.cgi

Status codes:
- Hosts: UP (0), DOWN (1), UNREACHABLE (2)
- Services: OK (0), WARNING (1), CRITICAL (2), UNKNOWN (3)

Analysis areas:
- Flapping services: Frequent state changes
- Stale checks: Check results not received
- Notification failures: Alerts not sent
- Check latency: Plugin execution time
- Scheduled downtime: Maintenance windows

Common issues:
- NRPE timeouts: Remote plugin execution slow
- Plugin failures: Check scripts erroring
- Notification storms: Mass alerting
- Check scheduling: Overloaded Nagios server
- Passive check gaps: External data not arriving
- Performance data loss: RRD/graphing issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        base = self.nagios_url or "http://nagios"
        if "critical" in q or "problem" in q:
            return f"I'll check critical services.\n\nTOOL: nagios curl -s '{base}/nagios/cgi-bin/statusjson.cgi?query=servicelist&servicestatus=critical'"
        if "host" in q:
            return f"I'll check host status.\n\nTOOL: nagios curl -s '{base}/nagios/cgi-bin/statusjson.cgi?query=hostlist'"
        if "service" in q:
            return f"I'll check service status.\n\nTOOL: nagios curl -s '{base}/nagios/cgi-bin/statusjson.cgi?query=servicelist'"
        if "log" in q:
            return f"I'll check logs.\n\nTOOL: nagios curl -s '{base}/nagios/cgi-bin/showlog.cgi'"
        return f"I'll check Nagios status.\n\nTOOL: nagios curl -s '{base}/nagios/cgi-bin/statusjson.cgi?query=programstatus'"
