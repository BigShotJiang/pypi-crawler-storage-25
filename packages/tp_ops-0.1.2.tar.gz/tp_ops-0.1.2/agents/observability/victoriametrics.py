"""VictoriaMetrics Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class VictoriaMetricsAgent(ShellAgent):
    """Agent for VictoriaMetrics investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "vm"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "api/v1/query", "api/v1/query_range", "api/v1/series",
        "api/v1/labels", "api/v1/label/__name__/values",
        "api/v1/status/tsdb", "api/v1/status/active_queries",
        "metrics", "flags",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "api/v1/admin/tsdb/delete_series",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.url = config.get("url", "http://localhost:8428")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a VictoriaMetrics investigation agent for {self.url}.

Available tools:
- vm: Execute read-only VictoriaMetrics API calls

Investigation approach:
1. Query: curl '{self.url}/api/v1/query?query=up'
2. TSDB Status: curl {self.url}/api/v1/status/tsdb
3. Active Queries: curl {self.url}/api/v1/status/active_queries
4. Labels: curl {self.url}/api/v1/labels
5. Series Count: curl {self.url}/api/v1/series/count
6. Metrics: curl {self.url}/metrics

Common issues:
- Ingestion rate: High ingest causing backpressure
- Query performance: Slow queries, high cardinality
- Storage: Disk space, retention
- High cardinality: Too many unique series
- Merge issues: Slow merges on large datasets"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "cardinality" in q or "series" in q:
            return f"I'll check TSDB status.\n\nTOOL: vm curl {self.url}/api/v1/status/tsdb"
        if "query" in q or "slow" in q:
            return f"I'll check active queries.\n\nTOOL: vm curl {self.url}/api/v1/status/active_queries"
        if "label" in q:
            return f"I'll list labels.\n\nTOOL: vm curl {self.url}/api/v1/labels"
        return f"I'll check TSDB status.\n\nTOOL: vm curl {self.url}/api/v1/status/tsdb"
