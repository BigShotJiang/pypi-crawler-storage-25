"""New Relic Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NewRelicAgent(ShellAgent):
    """Agent for New Relic investigation."""

    COMMAND_PREFIX = ["newrelic"]
    TOOL_NAME = "newrelic"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "nrql query", "entity search", "entity get",
        "apm application list", "apm application get",
        "alert policy list", "alert condition list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "alert policy create", "alert policy delete",
        "alert condition create", "alert condition delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.account_id = config.get("account_id")
        self.app_name = config.get("app_name")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        app = self.app_name or "all"
        return f"""You are a New Relic investigation agent for application '{app}'.

Account ID: {self.account_id}

Available tools:
- newrelic: Execute read-only New Relic CLI commands
- newrelic_write: Execute write commands (requires approval)

Investigation approach:
1. Entities: newrelic entity search --name "<pattern>"
2. APM Apps: newrelic apm application list
3. NRQL Query: newrelic nrql query --query "SELECT * FROM Transaction"
4. Alert Policies: newrelic alert policy list
5. Alert Conditions: newrelic alert condition list --policy-id <id>

Common NRQL patterns:
- Errors: SELECT count(*) FROM TransactionError FACET error.message
- Latency: SELECT average(duration) FROM Transaction
- Throughput: SELECT rate(count(*), 1 minute) FROM Transaction

Common issues:
- APM anomalies: Latency or error spikes
- Synthetic failures: Synthetic monitor failures
- Alert fatigue: Too many noisy alerts
- Cost: Unused instrumentation, high ingest"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "error" in q:
            return "I'll query errors.\n\nTOOL: newrelic nrql query --query 'SELECT count(*) FROM TransactionError FACET error.message SINCE 1 hour ago'"
        if "latency" in q or "slow" in q:
            return "I'll check latency.\n\nTOOL: newrelic nrql query --query 'SELECT average(duration) FROM Transaction FACET name SINCE 1 hour ago'"
        if "alert" in q:
            return "I'll list alert policies.\n\nTOOL: newrelic alert policy list"
        return "I'll list APM applications.\n\nTOOL: newrelic apm application list"
