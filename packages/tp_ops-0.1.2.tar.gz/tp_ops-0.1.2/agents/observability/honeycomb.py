"""Honeycomb Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class HoneycombAgent(ShellAgent):
    """Agent for Honeycomb observability investigation."""

    COMMAND_PREFIX = ["curl", "-H", "X-Honeycomb-Team: $HONEYCOMB_API_KEY"]
    TOOL_NAME = "honeycomb"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "datasets", "columns", "boards", "queries", "triggers",
        "markers", "slos", "derived_columns",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "DELETE", "PUT", "POST columns", "POST triggers",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.dataset = config.get("dataset")
        self.environment = config.get("environment")
        self.api_key = config.get("api_key")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        dataset = self.dataset or "all"
        return f"""You are a Honeycomb investigation agent for dataset '{dataset}'.

Environment: {self.environment or 'production'}

Available tools:
- honeycomb: Execute read-only Honeycomb API queries
- honeycomb_write: Execute write operations (requires approval)

Investigation approach:
1. Datasets: GET /1/datasets
2. Columns: GET /1/columns/{dataset if self.dataset else '<dataset>'}
3. Query: POST /1/queries/{dataset if self.dataset else '<dataset>'} (read-only query)
4. Boards: GET /1/boards
5. Triggers: GET /1/triggers/{dataset if self.dataset else '<dataset>'}
6. SLOs: GET /1/slos

Query analysis:
- Breakdown: GROUP BY for segmentation
- Filters: WHERE clauses for focus
- Calculations: COUNT, AVG, P99, HEATMAP
- Time range: Last hour, day, week

BubbleUp analysis:
- Anomaly detection: Find contributing factors
- Comparison: Baseline vs anomaly period
- Correlation: Find related attributes

Tracing:
- Trace waterfall: Span timing analysis
- Service map: Dependencies
- Error traces: Exception propagation
- Slow traces: Latency bottlenecks

Common issues:
- High cardinality: Too many unique values
- Missing instrumentation: Gaps in tracing
- Query performance: Complex queries timeout
- Data volume: Exceeding event quota
- Alert fatigue: Noisy triggers
- SLO burn rate: Budget consumption"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        dataset = self.dataset or "__all__"
        if "dataset" in q or "list" in q:
            return "I'll list datasets.\n\nTOOL: honeycomb curl -s 'https://api.honeycomb.io/1/datasets' -H 'X-Honeycomb-Team: $HONEYCOMB_API_KEY'"
        if "column" in q or "field" in q:
            return f"I'll list columns.\n\nTOOL: honeycomb curl -s 'https://api.honeycomb.io/1/columns/{dataset}' -H 'X-Honeycomb-Team: $HONEYCOMB_API_KEY'"
        if "trigger" in q or "alert" in q:
            return f"I'll check triggers.\n\nTOOL: honeycomb curl -s 'https://api.honeycomb.io/1/triggers/{dataset}' -H 'X-Honeycomb-Team: $HONEYCOMB_API_KEY'"
        if "slo" in q:
            return "I'll check SLOs.\n\nTOOL: honeycomb curl -s 'https://api.honeycomb.io/1/slos' -H 'X-Honeycomb-Team: $HONEYCOMB_API_KEY'"
        if "board" in q:
            return "I'll list boards.\n\nTOOL: honeycomb curl -s 'https://api.honeycomb.io/1/boards' -H 'X-Honeycomb-Team: $HONEYCOMB_API_KEY'"
        return "I'll list datasets.\n\nTOOL: honeycomb curl -s 'https://api.honeycomb.io/1/datasets' -H 'X-Honeycomb-Team: $HONEYCOMB_API_KEY'"
