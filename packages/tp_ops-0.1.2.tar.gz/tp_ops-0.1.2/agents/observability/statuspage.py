"""Status Page Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class StatusPageAgent(ShellAgent):
    """Agent for status page investigation (Statuspage, Betteruptime, Instatus)."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "statuspage"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "api/pages", "api/components", "api/incidents",
        "api/scheduled-maintenances", "api/metrics",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "api/incidents POST", "api/components PUT",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.api_url = config.get("api_url", "https://api.statuspage.io/v1")
        self.page_id = config.get("page_id")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a status page investigation agent.

API URL: {self.api_url}
Page ID: {self.page_id}

Available tools:
- statuspage: Execute read-only status page API calls
- statuspage_write: Execute write operations (requires approval)

Investigation approach:
1. Components: curl {self.api_url}/pages/{self.page_id}/components
2. Incidents: curl {self.api_url}/pages/{self.page_id}/incidents
3. Unresolved: curl {self.api_url}/pages/{self.page_id}/incidents/unresolved
4. Scheduled: curl {self.api_url}/pages/{self.page_id}/scheduled_maintenances

Common issues:
- Stale status: Components not updated
- Missing incidents: Incidents not communicated
- Component accuracy: Status doesn't match reality
- Maintenance: Unfinished scheduled maintenance
- Subscriber issues: Notifications not sending"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        page_id = self.page_id or "<page-id>"
        if "incident" in q:
            return f"I'll check incidents.\n\nTOOL: statuspage curl {self.api_url}/pages/{page_id}/incidents/unresolved"
        if "component" in q:
            return f"I'll check components.\n\nTOOL: statuspage curl {self.api_url}/pages/{page_id}/components"
        if "maintenance" in q:
            return f"I'll check scheduled maintenance.\n\nTOOL: statuspage curl {self.api_url}/pages/{page_id}/scheduled_maintenances/upcoming"
        return f"I'll check components.\n\nTOOL: statuspage curl {self.api_url}/pages/{page_id}/components"
