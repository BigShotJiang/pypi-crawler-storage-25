"""Observability agents for monitoring, logging, tracing, and alerting platforms."""

from agents.observability.azure_monitor import AzureMonitorAgent
from agents.observability.datadog import DatadogAgent
from agents.observability.grafana import GrafanaAgent
from agents.observability.pagerduty import PagerDutyAgent
from agents.observability.splunk import SplunkAgent
from agents.observability.newrelic import NewRelicAgent
from agents.observability.loki import LokiAgent
from agents.observability.jaeger import JaegerAgent
from agents.observability.otel import OTelCollectorAgent
from agents.observability.alertmanager import AlertmanagerAgent
from agents.observability.statuspage import StatusPageAgent
from agents.observability.uptime import UptimeMonitorAgent
from agents.observability.victoriametrics import VictoriaMetricsAgent
from agents.observability.thanos import ThanosAgent
from agents.observability.mimir import MimirAgent
from agents.observability.zabbix import ZabbixAgent
from agents.observability.nagios import NagiosAgent
from agents.observability.sentry import SentryAgent
from agents.observability.honeycomb import HoneycombAgent
from agents.observability.lightstep import LightstepAgent

__all__ = [
    "AzureMonitorAgent",
    "DatadogAgent",
    "GrafanaAgent",
    "PagerDutyAgent",
    "SplunkAgent",
    "NewRelicAgent",
    "LokiAgent",
    "JaegerAgent",
    "OTelCollectorAgent",
    "AlertmanagerAgent",
    "StatusPageAgent",
    "UptimeMonitorAgent",
    "VictoriaMetricsAgent",
    "ThanosAgent",
    "MimirAgent",
    "ZabbixAgent",
    "NagiosAgent",
    "SentryAgent",
    "HoneycombAgent",
    "LightstepAgent",
]
