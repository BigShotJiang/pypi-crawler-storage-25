"""Sentry Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SentryAgent(ShellAgent):
    """Agent for Sentry error tracking investigation."""

    COMMAND_PREFIX = ["sentry-cli"]
    TOOL_NAME = "sentry"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "projects list", "releases list", "issues list",
        "events list", "monitors list", "organizations list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "releases delete", "issues resolve", "issues ignore",
        "releases set-commits",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.org = config.get("org")
        self.project = config.get("project")
        self.auth_token = config.get("auth_token")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["sentry-cli"]
        if self.org:
            prefix.extend(["--org", self.org])
        return prefix

    def _get_system_prompt(self) -> str:
        project = self.project or "all"
        return f"""You are a Sentry investigation agent for project '{project}'.

Organization: {self.org or 'default'}

Available tools:
- sentry: Execute read-only Sentry CLI commands
- sentry_write: Execute write commands (requires approval)

Investigation approach:
1. Projects: sentry-cli projects list
2. Issues: sentry-cli issues list --project {project if self.project else '<project>'}
3. Releases: sentry-cli releases list
4. Events: Check recent error events
5. Monitors: sentry-cli monitors list (cron monitoring)

Issue analysis:
- Error frequency: Events per hour/day
- Users affected: Impact scope
- First/last seen: Error timeline
- Stack traces: Root cause identification
- Breadcrumbs: User actions before error

Release tracking:
- Release health: Crash-free sessions
- Regression detection: New errors in release
- Deploy tracking: Release correlation

Performance monitoring:
- Transaction duration: P50, P75, P95, P99
- Web vitals: LCP, FID, CLS
- Database queries: Slow queries

Common issues:
- Error storms: Sudden spike in errors
- Regressions: New errors after deploy
- Quota exceeded: Event limit reached
- SDK misconfiguration: Missing source maps
- Alert fatigue: Too many notifications
- Unhandled rejections: Promise errors"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        project = self.project or "<project>"
        if "issue" in q or "error" in q:
            return f"I'll list issues.\n\nTOOL: sentry sentry-cli issues list --project {project}"
        if "release" in q or "deploy" in q:
            return "I'll list releases.\n\nTOOL: sentry sentry-cli releases list"
        if "project" in q:
            return "I'll list projects.\n\nTOOL: sentry sentry-cli projects list"
        if "monitor" in q or "cron" in q:
            return "I'll check monitors.\n\nTOOL: sentry sentry-cli monitors list"
        return f"I'll check Sentry issues.\n\nTOOL: sentry sentry-cli issues list --project {project}"
