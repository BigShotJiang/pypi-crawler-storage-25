"""Grafana Mimir Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class MimirAgent(ShellAgent):
    """Agent for Grafana Mimir investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "mimir"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "api/v1/query", "api/v1/query_range", "api/v1/series",
        "api/v1/labels", "api/v1/status/buildinfo",
        "runtime_config", "services", "memberlist",
        "metrics", "ready", "config",
    ]

    DANGEROUS_SUBCOMMANDS = []  # Mimir API is read-only

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.url = config.get("url", "http://localhost:8080")
        self.tenant = config.get("tenant", "anonymous")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Grafana Mimir investigation agent for {self.url}.

Tenant: {self.tenant}

Available tools:
- mimir: Execute read-only Mimir API calls

Investigation approach:
1. Query: curl -H 'X-Scope-OrgID: {self.tenant}' '{self.url}/api/v1/query?query=up'
2. Services: curl {self.url}/services
3. Memberlist: curl {self.url}/memberlist
4. Runtime Config: curl {self.url}/runtime_config
5. Metrics: curl {self.url}/metrics
6. Ready: curl {self.url}/ready

Mimir components:
- Distributor: Receives samples from Prometheus
- Ingester: Writes samples to long-term storage
- Querier: Queries ingesters and store-gateway
- Store-gateway: Queries long-term storage
- Compactor: Compacts TSDB blocks

Common issues:
- Ingest failures: Distributor/ingester issues
- Ring health: Unhealthy members in hash ring
- Compactor: Compaction failures or lag
- Query performance: Slow queries, high cardinality
- Tenant limits: Rate limits, cardinality limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "ring" in q or "member" in q:
            return f"I'll check memberlist.\n\nTOOL: mimir curl {self.url}/memberlist"
        if "service" in q:
            return f"I'll check services.\n\nTOOL: mimir curl {self.url}/services"
        if "ready" in q or "health" in q:
            return f"I'll check readiness.\n\nTOOL: mimir curl {self.url}/ready"
        if "metric" in q:
            return f"I'll check Mimir metrics.\n\nTOOL: mimir curl {self.url}/metrics"
        return f"I'll check services.\n\nTOOL: mimir curl {self.url}/services"
