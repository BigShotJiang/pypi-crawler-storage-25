"""OpenTelemetry Collector Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class OTelCollectorAgent(ShellAgent):
    """Agent for OpenTelemetry Collector investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "otel"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "/metrics", "/debug/pipelinez", "/debug/tracez",
        "/debug/configz", "/health", "/ready",
    ]

    DANGEROUS_SUBCOMMANDS = []  # OTel collector endpoints are read-only

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.endpoint = config.get("endpoint", "http://localhost:55679")
        self.metrics_endpoint = config.get("metrics_endpoint", "http://localhost:8888/metrics")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an OpenTelemetry Collector investigation agent.

Endpoint: {self.endpoint}
Metrics: {self.metrics_endpoint}

Available tools:
- otel: Execute read-only OTel collector API calls

Investigation approach:
1. Health: curl {self.endpoint}/health
2. Metrics: curl {self.metrics_endpoint}
3. Config (zpages): curl {self.endpoint}/debug/configz
4. Pipelines (zpages): curl {self.endpoint}/debug/pipelinez
5. Traces (zpages): curl {self.endpoint}/debug/tracez

Key metrics to check:
- otelcol_receiver_accepted_metric_points
- otelcol_receiver_refused_metric_points
- otelcol_exporter_sent_metric_points
- otelcol_exporter_send_failed_metric_points
- otelcol_processor_dropped_metric_points

Common issues:
- Pipeline failures: Exporter connection issues
- Dropped data: Processor bottlenecks, queue full
- Configuration: Invalid config, missing receivers
- Resource usage: Memory/CPU pressure
- Export failures: Backend unavailable"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "metric" in q:
            return f"I'll check collector metrics.\n\nTOOL: otel curl {self.metrics_endpoint}"
        if "health" in q:
            return f"I'll check health.\n\nTOOL: otel curl {self.endpoint}/health"
        if "config" in q:
            return f"I'll check config.\n\nTOOL: otel curl {self.endpoint}/debug/configz"
        if "pipeline" in q:
            return f"I'll check pipelines.\n\nTOOL: otel curl {self.endpoint}/debug/pipelinez"
        return f"I'll check collector health.\n\nTOOL: otel curl {self.endpoint}/health"
