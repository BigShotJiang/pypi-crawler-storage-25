"""Uptime Monitor Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class UptimeMonitorAgent(ShellAgent):
    """Agent for uptime monitoring investigation (Pingdom, UptimeRobot, etc.)."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "uptime"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "getMonitors", "getAlertContacts", "getAccountDetails",
        "getMWindows", "getPSPs",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "newMonitor", "editMonitor", "deleteMonitor",
        "resetMonitor", "newAlertContact", "deleteAlertContact",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.provider = config.get("provider", "uptimerobot")  # uptimerobot, pingdom
        self.api_url = config.get("api_url", "https://api.uptimerobot.com/v2")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an uptime monitoring ({self.provider}) investigation agent.

API URL: {self.api_url}

Available tools:
- uptime: Execute read-only uptime monitoring API calls
- uptime_write: Execute write operations (requires approval)

Investigation approach:
1. Monitors: Get all monitors and their status
2. Response Times: Check response time trends
3. Alerts: Check alert contact configuration
4. Downtime: Check recent downtime events
5. Coverage: Identify monitoring gaps

Common issues:
- False positives: Monitors alerting incorrectly
- Coverage gaps: Critical endpoints not monitored
- Response time: Degraded performance trends
- Alert fatigue: Too many notifications
- Stale monitors: Monitors for decommissioned services"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "down" in q or "status" in q:
            return f"I'll check monitor status.\n\nTOOL: uptime curl -X POST {self.api_url}/getMonitors -d 'statuses=8-9'"
        if "response" in q or "slow" in q:
            return f"I'll check response times.\n\nTOOL: uptime curl -X POST {self.api_url}/getMonitors -d 'response_times=1'"
        if "alert" in q:
            return f"I'll check alert contacts.\n\nTOOL: uptime curl -X POST {self.api_url}/getAlertContacts"
        return f"I'll list monitors.\n\nTOOL: uptime curl -X POST {self.api_url}/getMonitors"
