"""Grafana Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GrafanaAgent(ShellAgent):
    """Agent for Grafana investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "grafana"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "api/search", "api/dashboards", "api/datasources",
        "api/alerts", "api/alertmanager", "api/folders",
        "api/org", "api/health",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "api/dashboards POST", "api/dashboards DELETE",
        "api/datasources POST", "api/datasources DELETE",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.url = config.get("url", "http://localhost:3000")
        self.api_key = config.get("api_key")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Grafana investigation agent for {self.url}.

Available tools:
- grafana: Execute read-only Grafana API calls
- grafana_write: Execute write operations (requires approval)

Investigation approach:
1. Health: curl {self.url}/api/health
2. Dashboards: curl {self.url}/api/search
3. Data Sources: curl {self.url}/api/datasources
4. Alerts: curl {self.url}/api/alerts
5. Alert Rules: curl {self.url}/api/ruler/grafana/api/v1/rules

Common issues:
- Dashboard load failures: Data source errors
- Data source errors: Connection, authentication
- Alert rule issues: Query errors, evaluation failures
- Unused dashboards: Dashboards no one views
- Broken panels: Missing metrics, schema changes"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "dashboard" in q:
            return f"I'll search dashboards.\n\nTOOL: grafana curl {self.url}/api/search"
        if "datasource" in q or "data source" in q:
            return f"I'll check data sources.\n\nTOOL: grafana curl {self.url}/api/datasources"
        if "alert" in q:
            return f"I'll check alerts.\n\nTOOL: grafana curl {self.url}/api/alerts"
        return f"I'll check Grafana health.\n\nTOOL: grafana curl {self.url}/api/health"
