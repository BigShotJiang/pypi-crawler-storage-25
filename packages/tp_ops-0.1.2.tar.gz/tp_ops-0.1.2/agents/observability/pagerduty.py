"""PagerDuty Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class PagerDutyAgent(ShellAgent):
    """Agent for PagerDuty investigation."""

    COMMAND_PREFIX = ["pd"]
    TOOL_NAME = "pagerduty"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "incident list", "incident get",
        "service list", "service get",
        "oncall list", "schedule list",
        "escalation-policy list", "user list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "incident acknowledge", "incident resolve", "incident snooze",
        "service create", "service delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.service = config.get("service")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        service = self.service or "all"
        return f"""You are a PagerDuty investigation agent for service '{service}'.

Available tools:
- pagerduty: Execute read-only PagerDuty CLI commands
- pagerduty_write: Execute write commands (requires approval)

Investigation approach:
1. Incidents: pd incident list --statuses triggered,acknowledged
2. Incident Details: pd incident get <id>
3. Services: pd service list
4. On-Call: pd oncall list
5. Schedules: pd schedule list

Common issues:
- Escalation failures: No one to escalate to
- On-call gaps: Missing coverage
- Noisy services: Too many incidents
- Integration issues: Events not creating incidents
- Response time: Slow acknowledgment"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "incident" in q:
            return "I'll list triggered incidents.\n\nTOOL: pagerduty pd incident list --statuses triggered,acknowledged"
        if "oncall" in q or "on-call" in q:
            return "I'll check who's on call.\n\nTOOL: pagerduty pd oncall list"
        if "service" in q:
            return "I'll list services.\n\nTOOL: pagerduty pd service list"
        return "I'll list active incidents.\n\nTOOL: pagerduty pd incident list --statuses triggered"
