"""Grafana Loki Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class LokiAgent(ShellAgent):
    """Agent for Grafana Loki investigation."""

    COMMAND_PREFIX = ["logcli"]
    TOOL_NAME = "loki"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "query", "labels", "series", "instant-query",
    ]

    DANGEROUS_SUBCOMMANDS = []  # Loki queries are read-only

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.addr = config.get("addr", "http://localhost:3100")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["logcli", "--addr", self.addr]

    def _get_system_prompt(self) -> str:
        return f"""You are a Grafana Loki investigation agent for {self.addr}.

Available tools:
- loki: Execute LogQL queries via logcli

Investigation approach:
1. Query: logcli query '{{app="myapp"}}'
2. Labels: logcli labels
3. Label Values: logcli labels <label>
4. Series: logcli series '{{namespace="prod"}}'

LogQL patterns:
- Filter: {{namespace="prod"}} |= "error"
- Regex: {{app=~"api-.*"}} |~ "status=[45][0-9][0-9]"
- Parse: {{app="nginx"}} | json | status >= 500
- Metrics: rate({{app="api"}}[5m])

Common issues:
- Ingestion rate: High volume causing drops
- Query performance: Expensive queries
- High cardinality: Too many unique label values
- Retention: Old logs not being deleted
- Chunk storage: S3/GCS connectivity issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "error" in q:
            return "I'll search for errors.\n\nTOOL: loki query '{namespace=\"prod\"} |= \"error\"' --limit 100"
        if "label" in q:
            return "I'll list labels.\n\nTOOL: loki labels"
        if "rate" in q or "metric" in q:
            return "I'll check log rates.\n\nTOOL: loki instant-query 'sum(rate({namespace=\"prod\"}[5m])) by (app)'"
        return "I'll list labels.\n\nTOOL: loki labels"
