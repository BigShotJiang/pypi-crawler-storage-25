"""Jaeger/Tempo Tracing Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class JaegerAgent(ShellAgent):
    """Agent for Jaeger/Tempo distributed tracing investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "tracing"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "api/services", "api/traces", "api/operations",
        "api/dependencies",
    ]

    DANGEROUS_SUBCOMMANDS = []  # Jaeger API is read-only

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.url = config.get("url", "http://localhost:16686")
        self.backend = config.get("backend", "jaeger")  # jaeger or tempo
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        backend = self.backend.title()
        return f"""You are a {backend} distributed tracing investigation agent for {self.url}.

Available tools:
- tracing: Execute read-only tracing API calls

Investigation approach for Jaeger:
1. Services: curl {self.url}/api/services
2. Operations: curl {self.url}/api/services/<service>/operations
3. Traces: curl {self.url}/api/traces?service=<service>
4. Dependencies: curl {self.url}/api/dependencies

Investigation approach for Tempo:
1. Search: curl {self.url}/api/search?q={{status=error}}
2. Trace by ID: curl {self.url}/api/traces/<traceID>
3. Services: Via Tempo/Grafana UI

Common issues:
- Trace collection gaps: Missing spans
- Storage issues: Cassandra/Elasticsearch backend problems
- Sampling: Important traces not captured
- Service map gaps: Missing dependencies
- High cardinality: Tag explosion"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "service" in q:
            return f"I'll list services.\n\nTOOL: tracing curl {self.url}/api/services"
        if "depend" in q:
            return f"I'll check dependencies.\n\nTOOL: tracing curl {self.url}/api/dependencies"
        if "trace" in q:
            return f"I'll search traces.\n\nTOOL: tracing curl '{self.url}/api/traces?service=<service>&limit=20'"
        return f"I'll list services.\n\nTOOL: tracing curl {self.url}/api/services"
