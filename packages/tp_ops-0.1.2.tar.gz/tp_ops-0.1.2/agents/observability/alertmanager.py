"""Prometheus Alertmanager Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AlertmanagerAgent(ShellAgent):
    """Agent for Prometheus Alertmanager investigation."""

    COMMAND_PREFIX = ["amtool"]
    TOOL_NAME = "alertmanager"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "alert query", "silence query", "config show",
        "check-config", "cluster show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "silence add", "silence expire",
        "config routes", "config update",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.url = config.get("url", "http://localhost:9093")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["amtool", "--alertmanager.url", self.url]

    def _get_system_prompt(self) -> str:
        return f"""You are a Prometheus Alertmanager investigation agent for {self.url}.

Available tools:
- alertmanager: Execute read-only amtool commands
- alertmanager_write: Execute write commands (requires approval)

Investigation approach:
1. Active Alerts: amtool alert query
2. Silences: amtool silence query
3. Config: amtool config show
4. Config Check: amtool check-config /etc/alertmanager/alertmanager.yml
5. Cluster: amtool cluster show

Common issues:
- Silenced alerts: Important alerts silenced
- Inhibition: Alerts being inhibited unexpectedly
- Notification failures: Slack/PagerDuty/email not working
- Routing: Alerts going to wrong receiver
- Duplicate alerts: Same alert from multiple sources"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "alert" in q:
            return "I'll query active alerts.\n\nTOOL: alertmanager alert query"
        if "silence" in q:
            return "I'll check silences.\n\nTOOL: alertmanager silence query"
        if "config" in q:
            return "I'll show config.\n\nTOOL: alertmanager config show"
        if "cluster" in q:
            return "I'll check cluster status.\n\nTOOL: alertmanager cluster show"
        return "I'll query alerts.\n\nTOOL: alertmanager alert query"
