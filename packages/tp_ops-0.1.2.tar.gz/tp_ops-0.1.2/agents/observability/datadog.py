"""Datadog Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class DatadogAgent(ShellAgent):
    """Agent for Datadog investigation."""

    COMMAND_PREFIX = ["dog"]
    TOOL_NAME = "datadog"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "metric query", "metric metadata show",
        "monitor show", "monitor search",
        "host list", "host mute show",
        "event stream", "dashboard list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "monitor mute", "monitor unmute", "monitor create", "monitor delete",
        "host mute", "host unmute",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.site = config.get("site", "datadoghq.com")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Datadog investigation agent.

Site: {self.site}

Available tools:
- datadog: Execute read-only Datadog CLI commands
- datadog_write: Execute write commands (requires approval)

Investigation approach:
1. Monitors: dog monitor search --query "status:alert"
2. Monitor Details: dog monitor show <id>
3. Metrics: dog metric query --query "avg:system.cpu.user{{*}}"
4. Hosts: dog host list
5. Events: dog event stream

Common issues:
- Monitor alert storms: Flapping monitors, noisy alerts
- APM latency: Service performance degradation
- Log index issues: Indexing errors, quota exceeded
- Custom metrics cost: High cardinality metrics
- Agent issues: Agents not reporting"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "alert" in q or "monitor" in q:
            return "I'll check alerting monitors.\n\nTOOL: datadog dog monitor search --query 'status:alert'"
        if "host" in q:
            return "I'll list hosts.\n\nTOOL: datadog dog host list"
        if "metric" in q or "cpu" in q:
            return "I'll query metrics.\n\nTOOL: datadog dog metric query --query 'avg:system.cpu.user{*}'"
        return "I'll check monitors.\n\nTOOL: datadog dog monitor search"
