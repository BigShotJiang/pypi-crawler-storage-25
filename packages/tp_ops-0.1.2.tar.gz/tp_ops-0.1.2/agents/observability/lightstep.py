"""Lightstep (ServiceNow Observability) Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class LightstepAgent(ShellAgent):
    """Agent for Lightstep/ServiceNow Cloud Observability investigation."""

    COMMAND_PREFIX = ["curl", "-H", "Authorization: Bearer $LIGHTSTEP_API_KEY"]
    TOOL_NAME = "lightstep"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "projects", "services", "streams", "dashboards",
        "conditions", "notebooks", "snapshots",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "DELETE", "PUT", "POST conditions",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.project = config.get("project")
        self.organization = config.get("organization")
        self.api_key = config.get("api_key")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        project = self.project or "default"
        return f"""You are a Lightstep (ServiceNow Cloud Observability) investigation agent.

Project: {project}
Organization: {self.organization or 'default'}

Available tools:
- lightstep: Execute read-only Lightstep API queries
- lightstep_write: Execute write operations (requires approval)

Investigation approach:
1. Services: GET /public/v0.2/{self.organization or '<org>'}/projects/{project}/services
2. Streams: GET /public/v0.2/{self.organization or '<org>'}/projects/{project}/streams
3. Dashboards: GET /public/v0.2/{self.organization or '<org>'}/projects/{project}/dashboards
4. Conditions: GET /public/v0.2/{self.organization or '<org>'}/projects/{project}/conditions
5. Notebooks: GET /public/v0.2/{self.organization or '<org>'}/projects/{project}/notebooks

Service analysis:
- Latency: P50, P99, P999 response times
- Error rate: 4xx, 5xx percentages
- Throughput: Requests per second
- Dependencies: Upstream/downstream services

Stream queries:
- Real-time analysis: Live trace data
- Filtering: Attribute-based selection
- Grouping: Aggregate by service/operation
- Percentiles: Latency distribution

Change Intelligence:
- Regression detection: Performance changes
- Deployment correlation: Release impact
- Root cause: Contributing factors

Common issues:
- Latency spikes: P99 degradation
- Error rate increase: New failure modes
- Throughput changes: Traffic patterns
- Service dependencies: Cascading failures
- Missing traces: Instrumentation gaps
- Alert noise: Condition tuning needed"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        org = self.organization or "<org>"
        project = self.project or "<project>"
        base = f"https://api.lightstep.com/public/v0.2/{org}/projects/{project}"
        if "service" in q:
            return f"I'll list services.\n\nTOOL: lightstep curl -s '{base}/services' -H 'Authorization: Bearer $LIGHTSTEP_API_KEY'"
        if "stream" in q:
            return f"I'll list streams.\n\nTOOL: lightstep curl -s '{base}/streams' -H 'Authorization: Bearer $LIGHTSTEP_API_KEY'"
        if "dashboard" in q:
            return f"I'll list dashboards.\n\nTOOL: lightstep curl -s '{base}/dashboards' -H 'Authorization: Bearer $LIGHTSTEP_API_KEY'"
        if "condition" in q or "alert" in q:
            return f"I'll check conditions.\n\nTOOL: lightstep curl -s '{base}/conditions' -H 'Authorization: Bearer $LIGHTSTEP_API_KEY'"
        return f"I'll list services.\n\nTOOL: lightstep curl -s '{base}/services' -H 'Authorization: Bearer $LIGHTSTEP_API_KEY'"
