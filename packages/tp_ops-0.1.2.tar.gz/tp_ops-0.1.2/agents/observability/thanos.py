"""Thanos Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ThanosAgent(ShellAgent):
    """Agent for Thanos investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "thanos"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "api/v1/query", "api/v1/query_range", "api/v1/stores",
        "api/v1/targets", "api/v1/rules", "api/v1/alerts",
        "-/healthy", "-/ready",
    ]

    DANGEROUS_SUBCOMMANDS = []  # Thanos query is read-only

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.query_url = config.get("query_url", "http://localhost:9090")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Thanos investigation agent for {self.query_url}.

Available tools:
- thanos: Execute read-only Thanos API calls

Investigation approach:
1. Stores: curl {self.query_url}/api/v1/stores
2. Targets: curl {self.query_url}/api/v1/targets
3. Query: curl '{self.query_url}/api/v1/query?query=up'
4. Rules: curl {self.query_url}/api/v1/rules
5. Alerts: curl {self.query_url}/api/v1/alerts
6. Health: curl {self.query_url}/-/healthy

Thanos components:
- Sidecar: Uploads blocks to object storage
- Store: Serves historical data from object storage
- Compactor: Compacts and downsamples blocks
- Query: Aggregates data from all stores
- Ruler: Evaluates rules across stores

Common issues:
- Store gateway: Store not returning data
- Compaction: Compactor failing or slow
- Deduplication: Duplicate series not being deduped
- Query performance: Slow queries across many stores
- Sidecar: Not uploading blocks to object storage"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "store" in q:
            return f"I'll check stores.\n\nTOOL: thanos curl {self.query_url}/api/v1/stores"
        if "target" in q or "sidecar" in q:
            return f"I'll check targets.\n\nTOOL: thanos curl {self.query_url}/api/v1/targets"
        if "compact" in q:
            return f"I'll query compactor metrics.\n\nTOOL: thanos curl '{self.query_url}/api/v1/query?query=thanos_compactor_group_compactions_total'"
        return f"I'll check stores.\n\nTOOL: thanos curl {self.query_url}/api/v1/stores"
