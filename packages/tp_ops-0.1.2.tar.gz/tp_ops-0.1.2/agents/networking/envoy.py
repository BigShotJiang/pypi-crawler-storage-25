"""Envoy Proxy Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class EnvoyAgent(ShellAgent):
    """Agent for Envoy proxy investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "envoy"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "/stats", "/clusters", "/config_dump", "/server_info",
        "/listeners", "/routes", "/certs", "/runtime",
        "/stats/prometheus", "/ready", "/healthcheck",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "/quitquitquit", "/healthcheck/fail", "/healthcheck/ok",
        "/drain_listeners", "/logging",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.admin_url = config.get("admin_url", "http://localhost:9901")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["curl", "-s", self.admin_url]

    def _get_system_prompt(self) -> str:
        return f"""You are an Envoy proxy investigation agent for {self.admin_url}.

Available tools:
- envoy: Execute read-only Envoy admin API calls
- envoy_write: Execute write operations (requires approval)

Investigation approach:
1. Server Info: curl {self.admin_url}/server_info
2. Clusters: curl {self.admin_url}/clusters
3. Stats: curl {self.admin_url}/stats
4. Config Dump: curl {self.admin_url}/config_dump
5. Listeners: curl {self.admin_url}/listeners

Common issues:
- Upstream connection failures: Check /clusters for health
- Circuit breaker: Check cluster stats for ejections
- Route matching: Check /config_dump for route config
- Retry storms: Check retry statistics
- Outlier detection: Check ejection stats"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "cluster" in q or "upstream" in q:
            return f"I'll check cluster health.\n\nTOOL: envoy /clusters"
        if "stat" in q:
            return f"I'll check stats.\n\nTOOL: envoy /stats"
        if "config" in q:
            return f"I'll dump config.\n\nTOOL: envoy /config_dump"
        if "listener" in q:
            return f"I'll check listeners.\n\nTOOL: envoy /listeners"
        return f"I'll check server info.\n\nTOOL: envoy /server_info"
