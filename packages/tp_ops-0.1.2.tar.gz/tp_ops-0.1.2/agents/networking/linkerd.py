"""Linkerd Service Mesh Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class LinkerdAgent(ShellAgent):
    """Agent for Linkerd service mesh investigation."""

    COMMAND_PREFIX = ["linkerd"]
    TOOL_NAME = "linkerd"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "version", "check", "stat", "top", "tap",
        "routes", "edges", "profile", "dashboard",
        "diagnostics", "viz stat", "viz top",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "install", "uninstall", "upgrade", "inject",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace", "default")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["linkerd"]
        if self.kubeconfig:
            prefix.extend(["--kubeconfig", self.kubeconfig])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Linkerd service mesh investigation agent for namespace '{self.namespace}'.

Available tools:
- linkerd: Execute read-only linkerd commands
- linkerd_write: Execute write commands (requires approval)

Investigation approach:
1. Check: linkerd check
2. Stats: linkerd stat deploy -n {self.namespace}
3. Top: linkerd top deploy -n {self.namespace}
4. Tap: linkerd tap deploy/<deployment> -n {self.namespace}
5. Routes: linkerd routes deploy/<deployment> -n {self.namespace}

Common issues:
- Proxy errors: Check linkerd check, proxy injection
- Traffic split: ServiceProfile issues
- Latency: Check stat for P50/P99
- Retries: ServiceProfile retry configuration
- mTLS: Certificate issues, trust anchor"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "check" in q:
            return "I'll run Linkerd health check.\n\nTOOL: linkerd check"
        if "stat" in q:
            return f"I'll check stats.\n\nTOOL: linkerd stat deploy -n {self.namespace}"
        if "top" in q:
            return f"I'll check live traffic.\n\nTOOL: linkerd top deploy -n {self.namespace}"
        if "route" in q:
            return f"I'll check routes.\n\nTOOL: linkerd routes deploy -n {self.namespace}"
        return "I'll check mesh health.\n\nTOOL: linkerd check"
