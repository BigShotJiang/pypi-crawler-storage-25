"""BGP Router Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class BGPAgent(ShellAgent):
    """Agent for BGP router investigation."""

    COMMAND_PREFIX = ["vtysh", "-c"]
    TOOL_NAME = "bgp"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "show ip bgp", "show ip bgp summary", "show ip bgp neighbors",
        "show ip bgp routes", "show ip bgp community",
        "show ip route", "show running-config",
        "show bgp ipv6", "show bgp ipv6 summary",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "configure", "router bgp", "neighbor", "network",
        "clear ip bgp", "restart",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.router_id = config.get("router_id")
        self.asn = config.get("asn")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a BGP router investigation agent for AS{self.asn or 'unknown'}.

Available tools:
- bgp: Execute read-only BGP commands (via vtysh or birdc)
- bgp_write: Execute configuration commands (requires approval)

Investigation approach:
1. Summary: vtysh -c "show ip bgp summary"
2. Neighbors: vtysh -c "show ip bgp neighbors"
3. Routes: vtysh -c "show ip bgp"
4. Specific Prefix: vtysh -c "show ip bgp <prefix>"
5. AS Path: vtysh -c "show ip bgp regexp <asn>"

Common issues:
- Peer flaps: Session instability, hold timer expiry
- Route leaks: Incorrect filtering, missing route policies
- Path changes: AS path hijacking, suboptimal routing
- Prefix hijacks: Unexpected origin AS
- Convergence: Slow convergence, route oscillation"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "neighbor" in q or "peer" in q:
            return "I'll check BGP neighbors.\n\nTOOL: bgp show ip bgp neighbors"
        if "summary" in q:
            return "I'll check BGP summary.\n\nTOOL: bgp show ip bgp summary"
        if "route" in q:
            return "I'll check BGP routes.\n\nTOOL: bgp show ip bgp"
        if "flap" in q:
            return "I'll check neighbor details for flaps.\n\nTOOL: bgp show ip bgp neighbors | grep -A 20 'Last reset'"
        return "I'll check BGP summary.\n\nTOOL: bgp show ip bgp summary"
