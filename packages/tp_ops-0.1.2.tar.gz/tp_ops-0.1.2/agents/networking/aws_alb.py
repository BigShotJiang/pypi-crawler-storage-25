"""AWS ALB/NLB Load Balancer Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AWSALBAgent(ShellAgent):
    """Agent for AWS Application/Network Load Balancer investigation."""

    COMMAND_PREFIX = ["aws", "elbv2"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "describe-load-balancers", "describe-target-groups",
        "describe-target-health", "describe-listeners",
        "describe-rules", "describe-tags", "describe-ssl-policies",
        "describe-target-group-attributes", "describe-load-balancer-attributes",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-load-balancer", "delete-load-balancer", "modify-load-balancer-attributes",
        "create-target-group", "delete-target-group", "register-targets",
        "deregister-targets", "modify-target-group", "set-security-groups",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.load_balancer_arn = config.get("load_balancer_arn")
        self.load_balancer_name = config.get("name")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "elbv2", "--region", self.region]

    def _get_system_prompt(self) -> str:
        lb_id = self.load_balancer_name or self.load_balancer_arn or "unknown"
        return f"""You are an AWS ALB/NLB investigation agent for '{lb_id}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Load Balancer Info: aws elbv2 describe-load-balancers
2. Target Groups: aws elbv2 describe-target-groups
3. Target Health: aws elbv2 describe-target-health --target-group-arn <arn>
4. Listeners: aws elbv2 describe-listeners --load-balancer-arn <arn>
5. CloudWatch Metrics: Check RequestCount, TargetResponseTime, HTTPCode_Target_5XX

Common issues:
- Unhealthy targets: Health check failures
- 5xx errors: Backend service issues
- High latency: Target response time spike
- SSL certificate: Certificate expiring or misconfigured
- Security groups: Port not open between ALB and targets"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "health" in q or "target" in q:
            return "I'll check target health.\n\nTOOL: aws elbv2 describe-target-groups"
        if "listener" in q or "rule" in q:
            return "I'll check listeners and rules.\n\nTOOL: aws elbv2 describe-listeners"
        if "5xx" in q or "error" in q:
            return "I'll check CloudWatch for error metrics.\n\nTOOL: aws cloudwatch get-metric-statistics --namespace AWS/ApplicationELB --metric-name HTTPCode_Target_5XX_Count"
        return "I'll check load balancer details.\n\nTOOL: aws elbv2 describe-load-balancers"
