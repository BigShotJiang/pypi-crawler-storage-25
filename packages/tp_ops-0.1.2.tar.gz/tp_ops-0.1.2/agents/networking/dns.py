"""DNS Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class DNSAgent(ShellAgent):
    """Agent for DNS infrastructure investigation."""

    COMMAND_PREFIX = ["dig"]
    TOOL_NAME = "dns"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "+short", "+trace", "+noall", "+answer", "+stats",
        "A", "AAAA", "CNAME", "MX", "TXT", "NS", "SOA", "PTR", "SRV",
        "ANY", "AXFR", "nslookup", "host",
    ]

    DANGEROUS_SUBCOMMANDS = []  # DNS queries are read-only

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.nameserver = config.get("nameserver")
        self.zone = config.get("zone")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.nameserver:
            return ["dig", f"@{self.nameserver}"]
        return ["dig"]

    def _get_system_prompt(self) -> str:
        ns = f"using nameserver {self.nameserver}" if self.nameserver else ""
        zone = f"for zone {self.zone}" if self.zone else ""
        return f"""You are a DNS investigation agent {ns} {zone}.

Available tools:
- dns: Execute DNS queries (dig, nslookup, host)

Investigation approach:
1. Basic Resolution: dig <domain> A +short
2. Trace: dig <domain> +trace
3. MX Records: dig <domain> MX
4. TXT Records: dig <domain> TXT
5. Nameservers: dig <domain> NS
6. SOA: dig <domain> SOA
7. Reverse: dig -x <ip>

Common issues:
- Resolution failures: Check NS delegation, SOA
- Propagation delays: Compare authoritative vs recursive
- DNSSEC issues: Check DS, DNSKEY, RRSIG records
- Zone transfer failures: AXFR denied
- TTL issues: Stale cached records"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        domain = self.zone or "example.com"
        if "mx" in q or "mail" in q:
            return f"I'll check MX records.\n\nTOOL: dns {domain} MX"
        if "trace" in q or "propagat" in q:
            return f"I'll trace DNS resolution.\n\nTOOL: dns {domain} +trace"
        if "ns" in q or "nameserver" in q:
            return f"I'll check nameservers.\n\nTOOL: dns {domain} NS"
        if "txt" in q or "spf" in q or "dkim" in q:
            return f"I'll check TXT records.\n\nTOOL: dns {domain} TXT"
        return f"I'll resolve the domain.\n\nTOOL: dns {domain} A +short"
