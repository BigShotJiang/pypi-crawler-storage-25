"""gRPC Service Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GRPCAgent(ShellAgent):
    """Agent for gRPC service investigation."""

    COMMAND_PREFIX = ["grpcurl"]
    TOOL_NAME = "grpc"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "list", "describe", "-plaintext", "-insecure",
        "grpc.health.v1.Health/Check",
    ]

    DANGEROUS_SUBCOMMANDS = []  # gRPC calls are typically read-only unless invoking mutating methods

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.endpoint = config.get("endpoint", "localhost:50051")
        self.plaintext = config.get("plaintext", True)
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["grpcurl"]
        if self.plaintext:
            prefix.append("-plaintext")
        prefix.append(self.endpoint)
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a gRPC service investigation agent for {self.endpoint}.

Available tools:
- grpc: Execute read-only gRPC calls via grpcurl
- grpc_write: Execute mutating gRPC calls (requires approval)

Investigation approach:
1. List Services: grpcurl -plaintext {self.endpoint} list
2. Describe Service: grpcurl -plaintext {self.endpoint} describe <service>
3. Health Check: grpcurl -plaintext {self.endpoint} grpc.health.v1.Health/Check
4. Call Method: grpcurl -plaintext {self.endpoint} <service>/<method>

Common issues:
- Stream errors: Connection drops, deadline exceeded
- Status codes: UNAVAILABLE, RESOURCE_EXHAUSTED, DEADLINE_EXCEEDED
- Load balancing: Client-side vs proxy-based balancing
- Reflection: Missing reflection service for discovery
- TLS: Certificate validation, mTLS configuration"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "list" in q or "service" in q:
            return f"I'll list gRPC services.\n\nTOOL: grpc list"
        if "health" in q:
            return f"I'll check health.\n\nTOOL: grpc grpc.health.v1.Health/Check"
        if "describe" in q:
            return f"I'll describe the service.\n\nTOOL: grpc describe"
        return f"I'll list services.\n\nTOOL: grpc list"
