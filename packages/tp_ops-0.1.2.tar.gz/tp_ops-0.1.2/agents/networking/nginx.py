"""NGINX Load Balancer Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NginxAgent(ShellAgent):
    """Agent for NGINX load balancer investigation."""

    COMMAND_PREFIX = ["nginx"]
    TOOL_NAME = "nginx"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "-t", "-T", "-V", "-v", "-s", "status",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "-s stop", "-s quit", "-s reload", "-s reopen",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.config_path = config.get("config_path", "/etc/nginx/nginx.conf")
        self.access_log = config.get("access_log", "/var/log/nginx/access.log")
        self.error_log = config.get("error_log", "/var/log/nginx/error.log")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an NGINX investigation agent for {self.host}.

Available tools:
- nginx: Execute read-only NGINX commands
- nginx_write: Execute write commands (requires approval)

Investigation approach:
1. Config Test: nginx -t
2. Full Config: nginx -T
3. Access Logs: tail {self.access_log}
4. Error Logs: tail {self.error_log}
5. Status: Check upstream health via status module

Common issues:
- 502 Bad Gateway: Upstream servers down or timeout
- 503 Service Unavailable: All upstreams failing health checks
- 504 Gateway Timeout: Upstream taking too long
- SSL issues: Certificate expired or misconfigured
- Connection limits: worker_connections exhausted"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "config" in q or "test" in q:
            return "I'll test the NGINX configuration.\n\nTOOL: nginx -t"
        if "502" in q or "upstream" in q:
            return f"I'll check error logs for upstream issues.\n\nTOOL: nginx tail -100 {self.error_log} | grep -i upstream"
        if "error" in q:
            return f"I'll check error logs.\n\nTOOL: nginx tail -100 {self.error_log}"
        if "ssl" in q or "cert" in q:
            return "I'll check SSL configuration.\n\nTOOL: nginx -T | grep -A 10 ssl_certificate"
        return "I'll check NGINX configuration.\n\nTOOL: nginx -T"
