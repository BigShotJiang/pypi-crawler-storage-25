"""Overlay Network (ZeroTier/Tailscale) Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class OverlayNetworkAgent(ShellAgent):
    """Agent for overlay network (ZeroTier, Tailscale) investigation."""

    COMMAND_PREFIX = ["zerotier-cli"]
    TOOL_NAME = "overlay"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "info", "listnetworks", "listpeers", "peers",
        "status", "netcheck", "ping", "debug",
        "tailscale status", "tailscale netcheck", "tailscale ping",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "join", "leave", "set", "down", "up",
        "tailscale up", "tailscale down", "tailscale set",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.overlay_type = config.get("type", "zerotier")  # zerotier, tailscale
        self.network_id = config.get("network_id")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.overlay_type == "tailscale":
            return ["tailscale"]
        return ["zerotier-cli"]

    def _get_system_prompt(self) -> str:
        return f"""You are an overlay network ({self.overlay_type}) investigation agent.

Available tools:
- overlay: Execute read-only overlay network commands
- overlay_write: Execute write commands (requires approval)

Investigation approach for ZeroTier:
1. Status: zerotier-cli info
2. Networks: zerotier-cli listnetworks
3. Peers: zerotier-cli listpeers
4. Network Details: zerotier-cli get <network-id>

Investigation approach for Tailscale:
1. Status: tailscale status
2. Netcheck: tailscale netcheck
3. Ping: tailscale ping <peer>
4. Debug: tailscale debug

Common issues:
- Peer connectivity: NAT traversal, relay usage
- Latency: DERP relay instead of direct connection
- Stale nodes: Offline or expired nodes
- ACL issues: Access denied to resources
- DNS: MagicDNS resolution failures"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.overlay_type == "tailscale":
            if "peer" in q or "connect" in q:
                return "I'll check peer connectivity.\n\nTOOL: overlay tailscale status"
            if "net" in q:
                return "I'll check network.\n\nTOOL: overlay tailscale netcheck"
            return "I'll check Tailscale status.\n\nTOOL: overlay tailscale status"
        else:
            if "peer" in q:
                return "I'll check peers.\n\nTOOL: overlay zerotier-cli listpeers"
            if "network" in q:
                return "I'll check networks.\n\nTOOL: overlay zerotier-cli listnetworks"
            return "I'll check ZeroTier info.\n\nTOOL: overlay zerotier-cli info"
