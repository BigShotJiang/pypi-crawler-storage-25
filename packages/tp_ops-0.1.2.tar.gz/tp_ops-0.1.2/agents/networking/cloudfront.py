"""AWS CloudFront CDN Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CloudFrontAgent(ShellAgent):
    """Agent for AWS CloudFront CDN investigation."""

    COMMAND_PREFIX = ["aws", "cloudfront"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-distributions", "get-distribution", "get-distribution-config",
        "list-invalidations", "get-invalidation", "list-cache-policies",
        "list-origin-request-policies", "list-response-headers-policies",
        "get-cache-policy", "list-functions", "describe-function",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-distribution", "delete-distribution", "update-distribution",
        "create-invalidation", "create-cache-policy", "delete-cache-policy",
        "create-function", "delete-function", "publish-function",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.distribution_id = config.get("distribution_id")
        self.domain = config.get("domain")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        dist_id = self.distribution_id or "unknown"
        return f"""You are an AWS CloudFront CDN investigation agent for distribution '{dist_id}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Distribution Info: aws cloudfront get-distribution --id {dist_id}
2. Cache Policies: aws cloudfront list-cache-policies
3. Invalidations: aws cloudfront list-invalidations --distribution-id {dist_id}
4. CloudWatch Metrics: Check Requests, BytesDownloaded, 4xx/5xx rates
5. Real-time Logs: Check Kinesis stream if configured

Common issues:
- Low cache hit ratio: Cache policy, TTL, query string handling
- Origin errors: Origin health, SSL, timeouts
- High latency by region: Edge location issues
- SSL certificate: Certificate renewal, CNAMEs
- Cost: Origin shield not enabled, cache inefficiency"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        dist_id = self.distribution_id or "<distribution-id>"
        if "cache" in q or "hit" in q:
            return "I'll check cache policy.\n\nTOOL: aws cloudfront list-cache-policies"
        if "invalidat" in q:
            return f"I'll check invalidations.\n\nTOOL: aws cloudfront list-invalidations --distribution-id {dist_id}"
        if "origin" in q or "error" in q:
            return f"I'll check distribution config.\n\nTOOL: aws cloudfront get-distribution-config --id {dist_id}"
        return "I'll list distributions.\n\nTOOL: aws cloudfront list-distributions"
