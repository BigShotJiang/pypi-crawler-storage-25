"""Wireless Access Point Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class WirelessAPAgent(ShellAgent):
    """Agent for wireless access point investigation."""

    COMMAND_PREFIX = ["iwconfig"]
    TOOL_NAME = "wifi"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "iwconfig", "iwlist", "iw dev", "iw phy", "iw reg",
        "hostapd_cli status", "hostapd_cli all_sta",
        "wpa_cli status", "wpa_cli scan_results",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "iwconfig set", "hostapd_cli disable", "hostapd_cli enable",
        "wpa_cli disconnect", "wpa_cli reassociate",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.interface = config.get("interface", "wlan0")
        self.host = config.get("host", "localhost")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a wireless access point investigation agent for interface {self.interface}.

Available tools:
- wifi: Execute read-only wireless commands
- wifi_write: Execute write commands (requires approval)

Investigation approach:
1. Interface Status: iwconfig {self.interface}
2. Scan: iwlist {self.interface} scan
3. AP Status: hostapd_cli status
4. Connected Clients: hostapd_cli all_sta
5. Channel Info: iw dev {self.interface} info

Common issues:
- Interference: Channel congestion, overlapping networks
- Client failures: Association failures, auth issues
- Throughput: Signal strength, PHY rate
- Roaming: Sticky clients, poor handoff
- Channel: DFS events, radar detection"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "client" in q or "sta" in q:
            return "I'll check connected clients.\n\nTOOL: wifi hostapd_cli all_sta"
        if "scan" in q or "interference" in q or "channel" in q:
            return f"I'll scan for networks.\n\nTOOL: wifi iwlist {self.interface} scan"
        if "status" in q:
            return "I'll check AP status.\n\nTOOL: wifi hostapd_cli status"
        return f"I'll check interface status.\n\nTOOL: wifi iwconfig {self.interface}"
