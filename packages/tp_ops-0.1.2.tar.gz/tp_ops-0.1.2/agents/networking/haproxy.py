"""HAProxy Load Balancer Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class HAProxyAgent(ShellAgent):
    """Agent for HAProxy load balancer investigation."""

    COMMAND_PREFIX = ["haproxy"]
    TOOL_NAME = "haproxy"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "-c", "-vv", "-V", "show stat", "show info", "show servers state",
        "show pools", "show sess", "show errors", "show backend",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "disable server", "enable server", "shutdown", "set weight",
        "set server", "set maxconn",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.stats_socket = config.get("stats_socket", "/var/run/haproxy.sock")
        self.config_path = config.get("config_path", "/etc/haproxy/haproxy.cfg")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an HAProxy investigation agent for {self.host}.

Available tools:
- haproxy: Execute read-only HAProxy commands
- haproxy_write: Execute write commands (requires approval)

Investigation approach:
1. Config Check: haproxy -c -f {self.config_path}
2. Stats: echo "show stat" | socat {self.stats_socket} stdio
3. Info: echo "show info" | socat {self.stats_socket} stdio
4. Backend Status: echo "show servers state" | socat {self.stats_socket} stdio
5. Errors: echo "show errors" | socat {self.stats_socket} stdio

Common issues:
- Backend health: Servers marked DOWN
- Connection queuing: Queue depth growing
- Session persistence: Session stickiness failures
- Timeout tuning: Client/server/connect timeouts
- SSL termination: Certificate or cipher issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "backend" in q or "server" in q or "health" in q:
            return f"I'll check backend health.\n\nTOOL: haproxy echo 'show servers state' | socat {self.stats_socket} stdio"
        if "stat" in q:
            return f"I'll check HAProxy stats.\n\nTOOL: haproxy echo 'show stat' | socat {self.stats_socket} stdio"
        if "error" in q:
            return f"I'll check recent errors.\n\nTOOL: haproxy echo 'show errors' | socat {self.stats_socket} stdio"
        if "config" in q:
            return f"I'll validate configuration.\n\nTOOL: haproxy -c -f {self.config_path}"
        return f"I'll check HAProxy info.\n\nTOOL: haproxy echo 'show info' | socat {self.stats_socket} stdio"
