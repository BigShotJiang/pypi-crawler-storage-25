"""Linux Firewall (iptables/nftables) Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class IptablesAgent(ShellAgent):
    """Agent for Linux firewall (iptables/nftables) investigation."""

    COMMAND_PREFIX = ["iptables"]
    TOOL_NAME = "firewall"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "-L", "-S", "-n", "-v", "--list", "--list-rules",
        "-t nat", "-t mangle", "-t raw", "-t filter",
        "nft list", "nft list ruleset", "nft list tables",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "-A", "-D", "-I", "-R", "-F", "-X", "-P",
        "--append", "--delete", "--insert", "--replace",
        "--flush", "--delete-chain", "--policy",
        "nft add", "nft delete", "nft flush",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.use_nftables = config.get("nftables", False)
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.use_nftables:
            return ["nft"]
        return ["iptables"]

    def _get_system_prompt(self) -> str:
        fw_type = "nftables" if self.use_nftables else "iptables"
        return f"""You are a Linux firewall ({fw_type}) investigation agent for {self.host}.

Available tools:
- firewall: Execute read-only firewall commands
- firewall_write: Execute write commands (requires approval)

Investigation approach for iptables:
1. List Rules: iptables -L -n -v
2. NAT Table: iptables -t nat -L -n -v
3. Rule Count: iptables -L -n -v | grep -c ""
4. Specific Chain: iptables -L INPUT -n -v

Investigation approach for nftables:
1. List All: nft list ruleset
2. List Tables: nft list tables
3. Specific Table: nft list table inet filter

Common issues:
- Blocked legitimate traffic: Check rule order, logging
- Rule conflicts: Overlapping rules, wrong chain
- Performance: Too many rules, conntrack exhaustion
- NAT issues: SNAT/DNAT configuration
- Chain ordering: PREROUTING vs FORWARD vs POSTROUTING"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.use_nftables:
            if "table" in q:
                return "I'll list nftables tables.\n\nTOOL: firewall nft list tables"
            return "I'll list nftables ruleset.\n\nTOOL: firewall nft list ruleset"
        else:
            if "nat" in q:
                return "I'll check NAT rules.\n\nTOOL: firewall iptables -t nat -L -n -v"
            if "input" in q:
                return "I'll check INPUT chain.\n\nTOOL: firewall iptables -L INPUT -n -v"
            return "I'll list firewall rules.\n\nTOOL: firewall iptables -L -n -v"
