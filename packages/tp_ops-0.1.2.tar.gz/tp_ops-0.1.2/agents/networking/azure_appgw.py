"""Azure Application Gateway Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureAppGatewayAgent(ShellAgent):
    """Agent for Azure Application Gateway investigation."""

    COMMAND_PREFIX = ["az", "network", "application-gateway"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "show", "list", "show-backend-health",
        "http-settings list", "frontend-ip list", "frontend-port list",
        "rule list", "url-path-map list", "probe list",
        "ssl-cert list", "waf-config show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create", "delete", "update", "stop", "start",
        "http-settings create", "http-settings delete",
        "rule create", "rule delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.gateway_name = config.get("name")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Application Gateway investigation agent for '{self.gateway_name}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Gateway Info: az network application-gateway show -g {self.resource_group} -n {self.gateway_name}
2. Backend Health: az network application-gateway show-backend-health -g {self.resource_group} -n {self.gateway_name}
3. Probes: az network application-gateway probe list -g {self.resource_group} --gateway-name {self.gateway_name}
4. WAF Config: az network application-gateway waf-config show -g {self.resource_group} --gateway-name {self.gateway_name}

Common issues:
- Backend health probes failing
- WAF blocking legitimate traffic
- SSL termination issues
- Routing rules misconfigured
- Capacity issues (v2 SKU autoscaling)"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "health" in q or "backend" in q:
            return f"I'll check backend health.\n\nTOOL: az network application-gateway show-backend-health -g {self.resource_group} -n {self.gateway_name}"
        if "waf" in q or "block" in q:
            return f"I'll check WAF configuration.\n\nTOOL: az network application-gateway waf-config show -g {self.resource_group} --gateway-name {self.gateway_name}"
        if "probe" in q:
            return f"I'll check health probes.\n\nTOOL: az network application-gateway probe list -g {self.resource_group} --gateway-name {self.gateway_name}"
        return f"I'll check gateway details.\n\nTOOL: az network application-gateway show -g {self.resource_group} -n {self.gateway_name}"
