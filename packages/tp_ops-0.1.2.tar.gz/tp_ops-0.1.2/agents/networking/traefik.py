"""Traefik Proxy Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class TraefikAgent(ShellAgent):
    """Agent for Traefik proxy investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "traefik"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "/api/overview", "/api/entrypoints", "/api/http/routers",
        "/api/http/services", "/api/http/middlewares",
        "/api/tcp/routers", "/api/tcp/services",
        "/api/rawdata", "/api/version", "/health", "/ping",
    ]

    DANGEROUS_SUBCOMMANDS = []  # Traefik API is mostly read-only

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.api_url = config.get("api_url", "http://localhost:8080")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["curl", "-s", self.api_url]

    def _get_system_prompt(self) -> str:
        return f"""You are a Traefik proxy investigation agent for {self.api_url}.

Available tools:
- traefik: Execute read-only Traefik API calls

Investigation approach:
1. Overview: curl {self.api_url}/api/overview
2. Routers: curl {self.api_url}/api/http/routers
3. Services: curl {self.api_url}/api/http/services
4. Middlewares: curl {self.api_url}/api/http/middlewares
5. Entrypoints: curl {self.api_url}/api/entrypoints

Common issues:
- Routing errors: Router rule conflicts, priority issues
- Certificate renewal: Let's Encrypt rate limits, ACME issues
- Middleware issues: Auth, rate limiting, headers
- Service discovery: Provider sync (Docker, K8s, file)
- Health checks: Service marked unhealthy"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "router" in q or "route" in q:
            return f"I'll check routers.\n\nTOOL: traefik /api/http/routers"
        if "service" in q:
            return f"I'll check services.\n\nTOOL: traefik /api/http/services"
        if "middleware" in q:
            return f"I'll check middlewares.\n\nTOOL: traefik /api/http/middlewares"
        if "cert" in q or "tls" in q:
            return f"I'll check raw data for certificates.\n\nTOOL: traefik /api/rawdata"
        return f"I'll check Traefik overview.\n\nTOOL: traefik /api/overview"
