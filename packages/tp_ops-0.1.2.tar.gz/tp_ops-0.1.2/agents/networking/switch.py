"""Network Switch/Router Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NetworkSwitchAgent(ShellAgent):
    """Agent for network switch/router investigation via SNMP."""

    COMMAND_PREFIX = ["snmpwalk"]
    TOOL_NAME = "snmp"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "-v2c", "-v3", "ifTable", "ifXTable", "sysDescr",
        "sysUpTime", "ifOperStatus", "ifInErrors", "ifOutErrors",
        "dot1dTpFdbTable", "ipRouteTable", "arpTable",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "snmpset", "set",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host")
        self.community = config.get("community", "public")
        self.snmp_version = config.get("version", "2c")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["snmpwalk", f"-v{self.snmp_version}", "-c", self.community, self.host]

    def _get_system_prompt(self) -> str:
        return f"""You are a network switch/router investigation agent for {self.host}.

Available tools:
- snmp: Execute SNMP queries
- snmp_write: Execute SNMP sets (requires approval)

Investigation approach:
1. System Info: snmpwalk -v2c -c {self.community} {self.host} sysDescr
2. Interfaces: snmpwalk -v2c -c {self.community} {self.host} ifTable
3. Interface Status: snmpwalk -v2c -c {self.community} {self.host} ifOperStatus
4. Errors: snmpwalk -v2c -c {self.community} {self.host} ifInErrors
5. MAC Table: snmpwalk -v2c -c {self.community} {self.host} dot1dTpFdbTable

Common issues:
- Port errors: CRC, collisions, drops
- Spanning tree: Blocked ports, topology changes
- VLAN: Misconfigurations, trunk issues
- Bandwidth: Interface saturation
- Broadcast storms: High broadcast traffic"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "error" in q:
            return f"I'll check interface errors.\n\nTOOL: snmp snmpwalk -v{self.snmp_version} -c {self.community} {self.host} ifInErrors"
        if "interface" in q or "port" in q:
            return f"I'll check interfaces.\n\nTOOL: snmp snmpwalk -v{self.snmp_version} -c {self.community} {self.host} ifTable"
        if "mac" in q:
            return f"I'll check MAC table.\n\nTOOL: snmp snmpwalk -v{self.snmp_version} -c {self.community} {self.host} dot1dTpFdbTable"
        return f"I'll check system info.\n\nTOOL: snmp snmpwalk -v{self.snmp_version} -c {self.community} {self.host} sysDescr"
