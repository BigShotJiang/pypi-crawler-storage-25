"""Networking agents for load balancers, API gateways, service mesh, CDN, and firewalls."""

from agents.networking.nginx import NginxAgent
from agents.networking.haproxy import HAProxyAgent
from agents.networking.aws_alb import AWSALBAgent
from agents.networking.azure_appgw import AzureAppGatewayAgent
from agents.networking.dns import DNSAgent
from agents.networking.azure_apim import AzureAPIMAgent
from agents.networking.kong import KongAgent
from agents.networking.aws_apigateway import AWSAPIGatewayAgent
from agents.networking.istio import IstioAgent
from agents.networking.linkerd import LinkerdAgent
from agents.networking.cloudfront import CloudFrontAgent
from agents.networking.azure_frontdoor import AzureFrontDoorAgent
from agents.networking.iptables import IptablesAgent
from agents.networking.azure_nsg import AzureNSGAgent
from agents.networking.vpn import VPNAgent
from agents.networking.envoy import EnvoyAgent
from agents.networking.traefik import TraefikAgent
from agents.networking.caddy import CaddyAgent
from agents.networking.switch import NetworkSwitchAgent
from agents.networking.wireless import WirelessAPAgent
from agents.networking.bgp import BGPAgent
from agents.networking.consul import ConsulAgent
from agents.networking.overlay import OverlayNetworkAgent
from agents.networking.grpc import GRPCAgent
from agents.networking.graphql import GraphQLAgent

__all__ = [
    "NginxAgent",
    "HAProxyAgent",
    "AWSALBAgent",
    "AzureAppGatewayAgent",
    "DNSAgent",
    "AzureAPIMAgent",
    "KongAgent",
    "AWSAPIGatewayAgent",
    "IstioAgent",
    "LinkerdAgent",
    "CloudFrontAgent",
    "AzureFrontDoorAgent",
    "IptablesAgent",
    "AzureNSGAgent",
    "VPNAgent",
    "EnvoyAgent",
    "TraefikAgent",
    "CaddyAgent",
    "NetworkSwitchAgent",
    "WirelessAPAgent",
    "BGPAgent",
    "ConsulAgent",
    "OverlayNetworkAgent",
    "GRPCAgent",
    "GraphQLAgent",
]
