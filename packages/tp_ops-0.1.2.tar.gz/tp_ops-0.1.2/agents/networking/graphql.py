"""GraphQL Service Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GraphQLAgent(ShellAgent):
    """Agent for GraphQL service investigation."""

    COMMAND_PREFIX = ["curl", "-s", "-X", "POST"]
    TOOL_NAME = "graphql"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "__schema", "__type", "query", "introspection",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "mutation", "delete", "update", "create",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.endpoint = config.get("endpoint", "http://localhost:4000/graphql")
        self.headers = config.get("headers", {})
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["curl", "-s", "-X", "POST", "-H", "Content-Type: application/json"]
        for key, value in self.headers.items():
            prefix.extend(["-H", f"{key}: {value}"])
        prefix.append(self.endpoint)
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a GraphQL service investigation agent for {self.endpoint}.

Available tools:
- graphql: Execute read-only GraphQL queries
- graphql_write: Execute mutations (requires approval)

Investigation approach:
1. Introspection: {{{{ __schema {{ types {{ name }} }} }}}}
2. Type Details: {{{{ __type(name: "Query") {{ fields {{ name }} }} }}}}
3. Sample Query: Execute a simple query to test connectivity
4. Error Analysis: Check response for errors array

Common issues:
- N+1 queries: Missing DataLoader, resolver inefficiency
- Depth limit: Query too deep, complexity exceeded
- Schema errors: Missing types, invalid fields
- Auth: Token validation, permission errors
- Performance: Slow resolvers, database queries"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "schema" in q or "introspect" in q:
            return f"I'll introspect the schema.\n\nTOOL: graphql -d '{{\"query\": \"{{ __schema {{ types {{ name }} }} }}\"}}'  {self.endpoint}"
        if "type" in q:
            return f"I'll check types.\n\nTOOL: graphql -d '{{\"query\": \"{{ __type(name: \\\"Query\\\") {{ fields {{ name }} }} }}\"}}'  {self.endpoint}"
        if "error" in q:
            return "I'll analyze error patterns in the schema.\n\nTOOL: graphql introspection"
        return f"I'll introspect the schema.\n\nTOOL: graphql -d '{{\"query\": \"{{ __schema {{ queryType {{ name }} }} }}\"}}'  {self.endpoint}"
