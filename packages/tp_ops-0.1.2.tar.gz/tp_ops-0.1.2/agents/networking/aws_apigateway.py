"""AWS API Gateway Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AWSAPIGatewayAgent(ShellAgent):
    """Agent for AWS API Gateway investigation."""

    COMMAND_PREFIX = ["aws", "apigateway"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "get-rest-apis", "get-rest-api", "get-resources",
        "get-stages", "get-stage", "get-deployments",
        "get-authorizers", "get-usage-plans", "get-api-keys",
        "get-domain-names", "get-base-path-mappings",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-rest-api", "delete-rest-api", "create-deployment",
        "delete-stage", "update-stage", "create-resource",
        "delete-resource", "put-method", "delete-method",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.api_id = config.get("api_id")
        self.api_name = config.get("name")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "apigateway", "--region", self.region]

    def _get_system_prompt(self) -> str:
        api_id = self.api_id or "unknown"
        return f"""You are an AWS API Gateway investigation agent for API '{api_id}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. List APIs: aws apigateway get-rest-apis
2. Resources: aws apigateway get-resources --rest-api-id {api_id}
3. Stages: aws apigateway get-stages --rest-api-id {api_id}
4. Deployments: aws apigateway get-deployments --rest-api-id {api_id}
5. CloudWatch Metrics: Check 4XX, 5XX, Latency, Count

Common issues:
- Throttling: API rate limits exceeded
- Integration errors: Lambda/HTTP backend failures
- Authorizer failures: Cognito/Lambda authorizer issues
- Stage issues: Deployment or variable problems
- Caching: Cache invalidation or stale responses"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        api_id = self.api_id or "<api-id>"
        if "resource" in q:
            return f"I'll list resources.\n\nTOOL: aws apigateway get-resources --rest-api-id {api_id}"
        if "stage" in q:
            return f"I'll check stages.\n\nTOOL: aws apigateway get-stages --rest-api-id {api_id}"
        if "throttl" in q or "limit" in q:
            return "I'll check usage plans.\n\nTOOL: aws apigateway get-usage-plans"
        return "I'll list APIs.\n\nTOOL: aws apigateway get-rest-apis"
