"""Caddy Server Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CaddyAgent(ShellAgent):
    """Agent for Caddy server investigation."""

    COMMAND_PREFIX = ["caddy"]
    TOOL_NAME = "caddy"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "version", "list-modules", "validate", "adapt",
        "environ", "trust", "untrust",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "start", "stop", "reload", "run",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.admin_url = config.get("admin_url", "http://localhost:2019")
        self.config_path = config.get("config_path", "/etc/caddy/Caddyfile")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Caddy server investigation agent.

Available tools:
- caddy: Execute read-only Caddy commands
- caddy_write: Execute write commands (requires approval)

Investigation approach:
1. Version: caddy version
2. Validate: caddy validate --config {self.config_path}
3. Modules: caddy list-modules
4. Admin API: curl {self.admin_url}/config/
5. Logs: journalctl -u caddy

Common issues:
- TLS issues: Automatic HTTPS failures, certificate errors
- Reverse proxy: Upstream connection failures
- Config errors: Caddyfile syntax, JSON config
- Module issues: Missing or incompatible modules
- Performance: File server, compression settings"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "config" in q or "valid" in q:
            return f"I'll validate Caddy config.\n\nTOOL: caddy validate --config {self.config_path}"
        if "module" in q:
            return "I'll list modules.\n\nTOOL: caddy list-modules"
        if "tls" in q or "cert" in q:
            return f"I'll check config for TLS settings.\n\nTOOL: caddy adapt --config {self.config_path}"
        return "I'll check Caddy version.\n\nTOOL: caddy version"
