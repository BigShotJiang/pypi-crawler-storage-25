"""VPN Gateway Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class VPNAgent(ShellAgent):
    """Agent for VPN gateway investigation (WireGuard, OpenVPN, IPSec)."""

    COMMAND_PREFIX = ["wg"]
    TOOL_NAME = "vpn"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "show", "showconf", "status",
        "openvpn --version", "ipsec status", "ipsec statusall",
        "swanctl --list-sas", "swanctl --list-conns",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "set", "setconf", "genkey", "genpsk",
        "down", "up", "restart",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.vpn_type = config.get("type", "wireguard")  # wireguard, openvpn, ipsec
        self.interface = config.get("interface", "wg0")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.vpn_type == "wireguard":
            return ["wg"]
        elif self.vpn_type == "openvpn":
            return ["openvpn"]
        elif self.vpn_type == "ipsec":
            return ["ipsec"]
        return ["wg"]

    def _get_system_prompt(self) -> str:
        return f"""You are a VPN ({self.vpn_type}) investigation agent.

Available tools:
- vpn: Execute read-only VPN commands
- vpn_write: Execute write commands (requires approval)

Investigation approach for WireGuard:
1. Status: wg show {self.interface}
2. Config: wg showconf {self.interface}
3. Interface: ip addr show {self.interface}
4. Routing: ip route | grep {self.interface}

Investigation approach for IPSec:
1. Status: ipsec status
2. All Status: ipsec statusall
3. List SAs: swanctl --list-sas
4. Connections: swanctl --list-conns

Common issues:
- Tunnel drops: Handshake failures, NAT traversal
- Throughput: MTU issues, fragmentation
- Routing: Missing routes, split tunneling
- Certificate: Expiration, chain validation
- Firewall: UDP 500/4500 (IPSec), UDP 51820 (WG)"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.vpn_type == "wireguard":
            if "config" in q:
                return f"I'll check WireGuard config.\n\nTOOL: vpn wg showconf {self.interface}"
            return f"I'll check WireGuard status.\n\nTOOL: vpn wg show {self.interface}"
        elif self.vpn_type == "ipsec":
            if "sa" in q or "security" in q:
                return "I'll check security associations.\n\nTOOL: vpn swanctl --list-sas"
            return "I'll check IPSec status.\n\nTOOL: vpn ipsec statusall"
        return f"I'll check VPN status.\n\nTOOL: vpn wg show"
