"""Azure NSG/Firewall Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureNSGAgent(ShellAgent):
    """Agent for Azure Network Security Group and Firewall investigation."""

    COMMAND_PREFIX = ["az", "network", "nsg"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "show", "list", "rule list", "rule show",
        "flow-log show", "flow-log list",
        "watcher show-topology", "watcher show-next-hop",
        "watcher show-security-group-view",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create", "delete", "update",
        "rule create", "rule delete", "rule update",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.nsg_name = config.get("name")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure NSG investigation agent for '{self.nsg_name}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. NSG Info: az network nsg show -g {self.resource_group} -n {self.nsg_name}
2. Rules: az network nsg rule list -g {self.resource_group} --nsg-name {self.nsg_name}
3. Flow Logs: az network watcher flow-log show -g {self.resource_group} --nsg {self.nsg_name}
4. Effective Rules: az network nic show-effective-nsg --ids <nic-id>
5. Next Hop: az network watcher show-next-hop

Common issues:
- Blocked flows: Check rule priority, deny rules
- Overly permissive rules: * source/destination, any port
- Rule conflicts: Priority ordering
- Missing rules: Service tag not used
- Flow log analysis: Check NSG flow logs in storage"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "rule" in q:
            return f"I'll list NSG rules.\n\nTOOL: az network nsg rule list -g {self.resource_group} --nsg-name {self.nsg_name}"
        if "flow" in q or "log" in q:
            return f"I'll check flow logs.\n\nTOOL: az network watcher flow-log show -g {self.resource_group} --nsg {self.nsg_name}"
        if "effective" in q:
            return "I'll check effective rules.\n\nTOOL: az network nic list-effective-nsg"
        return f"I'll check NSG details.\n\nTOOL: az network nsg show -g {self.resource_group} -n {self.nsg_name}"
