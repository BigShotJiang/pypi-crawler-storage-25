"""HashiCorp Consul Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ConsulAgent(ShellAgent):
    """Agent for HashiCorp Consul investigation."""

    COMMAND_PREFIX = ["consul"]
    TOOL_NAME = "consul"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "members", "catalog services", "catalog nodes",
        "catalog service", "catalog datacenters",
        "operator raft", "operator autopilot",
        "info", "debug", "watch", "monitor",
        "kv get", "acl token list", "intention list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "kv put", "kv delete", "acl token create", "acl token delete",
        "intention create", "intention delete",
        "services deregister", "services register",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.consul_addr = config.get("addr", "http://localhost:8500")
        self.datacenter = config.get("datacenter")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["consul"]
        if self.consul_addr:
            prefix.extend(["-http-addr", self.consul_addr])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a HashiCorp Consul investigation agent for {self.consul_addr}.

Available tools:
- consul: Execute read-only Consul commands
- consul_write: Execute write commands (requires approval)

Investigation approach:
1. Members: consul members
2. Services: consul catalog services
3. Service Health: consul catalog service <name>
4. Nodes: consul catalog nodes
5. Raft: consul operator raft list-peers
6. KV: consul kv get -recurse <prefix>

Common issues:
- Service discovery: Health check failures, stale registrations
- Raft consensus: Leader election, peer failures
- KV store: Performance, storage size
- ACL: Token permissions, policy issues
- Intentions: Service-to-service connectivity"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "service" in q:
            return "I'll list services.\n\nTOOL: consul catalog services"
        if "member" in q or "node" in q:
            return "I'll check members.\n\nTOOL: consul members"
        if "health" in q:
            return "I'll check service health.\n\nTOOL: consul catalog services -tags"
        if "raft" in q or "leader" in q:
            return "I'll check Raft status.\n\nTOOL: consul operator raft list-peers"
        return "I'll check Consul members.\n\nTOOL: consul members"
