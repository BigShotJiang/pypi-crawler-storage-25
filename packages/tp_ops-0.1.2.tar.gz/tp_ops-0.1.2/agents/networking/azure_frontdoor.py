"""Azure Front Door Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureFrontDoorAgent(ShellAgent):
    """Agent for Azure Front Door investigation."""

    COMMAND_PREFIX = ["az", "afd"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "profile show", "profile list", "endpoint list", "endpoint show",
        "origin-group list", "origin list", "route list",
        "rule-set list", "rule list", "custom-domain list",
        "security-policy list", "log-analytic metric", "log-analytic ranking",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "profile create", "profile delete", "endpoint create", "endpoint delete",
        "origin-group create", "origin create", "route create",
        "purge", "rule create", "rule delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.profile_name = config.get("profile_name")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Front Door investigation agent for profile '{self.profile_name}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Profile Info: az afd profile show -g {self.resource_group} --profile-name {self.profile_name}
2. Endpoints: az afd endpoint list -g {self.resource_group} --profile-name {self.profile_name}
3. Origin Groups: az afd origin-group list -g {self.resource_group} --profile-name {self.profile_name}
4. Routes: az afd route list -g {self.resource_group} --profile-name {self.profile_name} --endpoint-name <endpoint>
5. WAF: az afd security-policy list -g {self.resource_group} --profile-name {self.profile_name}

Common issues:
- Routing issues: Route matching, origin group selection
- WAF blocks: Security policy false positives
- Origin health: Health probe failures
- Latency: Caching, origin response time
- SSL: Custom domain certificate issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "origin" in q:
            return f"I'll check origin groups.\n\nTOOL: az afd origin-group list -g {self.resource_group} --profile-name {self.profile_name}"
        if "route" in q:
            return f"I'll check routes.\n\nTOOL: az afd route list -g {self.resource_group} --profile-name {self.profile_name}"
        if "waf" in q or "security" in q:
            return f"I'll check security policies.\n\nTOOL: az afd security-policy list -g {self.resource_group} --profile-name {self.profile_name}"
        return f"I'll check Front Door profile.\n\nTOOL: az afd profile show -g {self.resource_group} --profile-name {self.profile_name}"
