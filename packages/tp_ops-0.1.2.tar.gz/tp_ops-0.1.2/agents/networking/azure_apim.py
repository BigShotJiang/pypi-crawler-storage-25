"""Azure API Management Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureAPIMAgent(ShellAgent):
    """Agent for Azure API Management investigation."""

    COMMAND_PREFIX = ["az", "apim"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "show", "list", "api list", "api show",
        "product list", "product show", "subscription list",
        "named-value list", "nv list", "backend list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create", "delete", "update", "backup", "restore",
        "api create", "api delete", "api update",
        "product create", "product delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.apim_name = config.get("name")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure API Management investigation agent for '{self.apim_name}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. APIM Info: az apim show -g {self.resource_group} -n {self.apim_name}
2. API List: az apim api list -g {self.resource_group} -n {self.apim_name}
3. Products: az apim product list -g {self.resource_group} -n {self.apim_name}
4. Subscriptions: az apim subscription list -g {self.resource_group} -n {self.apim_name}
5. Backends: az apim backend list -g {self.resource_group} -n {self.apim_name}

Common issues:
- Latency: Backend response time, policy overhead
- Auth failures: Subscription key, OAuth, certificate issues
- Rate limiting: Quota exceeded, throttling
- Backend errors: Backend service health
- Cost: High call volume, premium tier waste"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "api" in q and "list" in q:
            return f"I'll list APIs.\n\nTOOL: az apim api list -g {self.resource_group} -n {self.apim_name}"
        if "backend" in q:
            return f"I'll check backends.\n\nTOOL: az apim backend list -g {self.resource_group} -n {self.apim_name}"
        if "product" in q:
            return f"I'll list products.\n\nTOOL: az apim product list -g {self.resource_group} -n {self.apim_name}"
        return f"I'll check APIM details.\n\nTOOL: az apim show -g {self.resource_group} -n {self.apim_name}"
