"""Istio Service Mesh Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class IstioAgent(ShellAgent):
    """Agent for Istio service mesh investigation."""

    COMMAND_PREFIX = ["istioctl"]
    TOOL_NAME = "istioctl"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "version", "proxy-status", "proxy-config", "analyze",
        "describe", "dashboard", "profile list", "manifest",
        "authz check", "experimental", "validate",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "install", "uninstall", "upgrade", "kube-inject",
        "experimental injector",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace", "default")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["istioctl"]
        if self.kubeconfig:
            prefix.extend(["--kubeconfig", self.kubeconfig])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are an Istio service mesh investigation agent for namespace '{self.namespace}'.

Available tools:
- istioctl: Execute read-only istioctl commands
- istioctl_write: Execute write commands (requires approval)

Investigation approach:
1. Proxy Status: istioctl proxy-status
2. Analyze: istioctl analyze -n {self.namespace}
3. Proxy Config: istioctl proxy-config clusters <pod>
4. Check Auth: istioctl authz check <pod> -n {self.namespace}
5. Describe: istioctl describe pod <pod> -n {self.namespace}

Common issues:
- Sidecar injection failures: Check mutating webhook, namespace labels
- mTLS issues: Check PeerAuthentication, DestinationRule
- Traffic routing: VirtualService, DestinationRule conflicts
- Policy failures: AuthorizationPolicy misconfigurations
- Circuit breaker: DestinationRule outlier detection"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "proxy" in q or "status" in q:
            return "I'll check proxy status.\n\nTOOL: istioctl proxy-status"
        if "analyze" in q:
            return f"I'll analyze the mesh.\n\nTOOL: istioctl analyze -n {self.namespace}"
        if "auth" in q or "mtls" in q:
            return "I'll check authentication.\n\nTOOL: istioctl authz check"
        if "config" in q:
            return "I'll check proxy config.\n\nTOOL: istioctl proxy-config clusters"
        return "I'll check proxy status.\n\nTOOL: istioctl proxy-status"
