"""Kong API Gateway Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class KongAgent(ShellAgent):
    """Agent for Kong API Gateway investigation."""

    COMMAND_PREFIX = ["curl", "-s"]
    TOOL_NAME = "kong"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "/services", "/routes", "/plugins", "/consumers",
        "/upstreams", "/targets", "/certificates", "/snis",
        "/status", "/clustering/status",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "POST", "PUT", "PATCH", "DELETE",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.admin_url = config.get("admin_url", "http://localhost:8001")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["curl", "-s", self.admin_url]

    def _get_system_prompt(self) -> str:
        return f"""You are a Kong API Gateway investigation agent for {self.admin_url}.

Available tools:
- kong: Execute read-only Kong Admin API calls
- kong_write: Execute write operations (requires approval)

Investigation approach:
1. Status: curl {self.admin_url}/status
2. Services: curl {self.admin_url}/services
3. Routes: curl {self.admin_url}/routes
4. Plugins: curl {self.admin_url}/plugins
5. Upstreams: curl {self.admin_url}/upstreams
6. Targets: curl {self.admin_url}/upstreams/<upstream>/targets

Common issues:
- Plugin errors: Misconfigured rate limiting, auth, transformation
- Upstream health: Target failures, circuit breaker trips
- Route matching: Path conflicts, priority issues
- Certificate expiration: SSL/TLS certificate renewal
- Performance: Plugin latency, database connectivity"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "service" in q:
            return f"I'll list services.\n\nTOOL: kong /services"
        if "route" in q:
            return f"I'll list routes.\n\nTOOL: kong /routes"
        if "plugin" in q:
            return f"I'll list plugins.\n\nTOOL: kong /plugins"
        if "upstream" in q or "target" in q:
            return f"I'll check upstreams.\n\nTOOL: kong /upstreams"
        return f"I'll check Kong status.\n\nTOOL: kong /status"
