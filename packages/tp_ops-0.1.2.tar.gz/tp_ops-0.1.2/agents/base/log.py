"""LogAgent base class for log-based investigation agents.

Base class for 47 agents that work with logs:
- Splunk, Datadog, Loki, Elastic
- Application logs, system logs
- Cloud logging services

Provides:
- Log tailing and searching
- Error pattern extraction
- Event correlation
- Log level filtering
"""

import subprocess
import re
from abc import abstractmethod
from typing import Any, Optional

from agents.base.conversational import ConversationalAgent, Tool, ActionType
from agents.tools.log_parser import (
    LogLevel,
    LogEntry,
    ErrorMatch,
    COMMON_ERROR_PATTERNS,
    extract_errors,
    correlate_events,
    summarize_errors,
    filter_logs_by_level,
    tail_logs,
    grep_logs,
)


class LogAgent(ConversationalAgent):
    """Base class for log analysis agents.

    Subclasses configure log source and error patterns:

    class SplunkAgent(LogAgent):
        LOG_SOURCE = "api"
        TOOL_NAME = "splunk"
        ERROR_PATTERNS = {"custom_error": "CUSTOM_ERR_[0-9]+"}

        def _fetch_logs(self, query: str) -> str:
            # Splunk API call
    """

    # Subclasses must override these
    LOG_SOURCE: str = "file"  # file, api, journald, docker, kubectl
    TOOL_NAME: str = "logs"
    ERROR_PATTERNS: dict[str, str] = {}
    COMMAND_TIMEOUT: int = 60

    # Common log commands (used by file-based sources)
    SAFE_OPERATIONS = [
        "tail", "head", "grep", "awk", "sed", "cat", "less", "more",
        "journalctl", "dmesg", "zcat", "zgrep",
    ]
    DANGEROUS_OPERATIONS = [
        "rm", "truncate", "shred", ">", ">>", "|",
        "mv", "cp", "dd",
    ]

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal,
        llm=None,
    ):
        """Initialize LogAgent.

        Args:
            name: Agent name
            config: Configuration dict with:
                - log_path: Path to log file (for file sources)
                - host: Remote host (for remote sources)
                - api_key: API key (for API sources)
                - service: Service name (for service logs)
            terminal: Terminal for output
            llm: Optional LLM client
        """
        self.log_path = config.get("log_path", "/var/log/syslog")
        self.host = config.get("host")
        self.service = config.get("service")
        self.api_key = config.get("api_key")
        self.api_endpoint = config.get("api_endpoint")

        # Merge custom patterns with common patterns
        self.all_patterns = {**COMMON_ERROR_PATTERNS, **self.ERROR_PATTERNS}

        super().__init__(name, config, terminal, llm)

    def _register_tools(self) -> None:
        """Register log analysis tools."""
        # Tail - get recent logs
        self.register_tool(
            name=f"{self.TOOL_NAME}_tail",
            description=f"Get the last N lines of logs (default 100). Usage: {self.TOOL_NAME}_tail [lines] [filter]",
            execute=self._run_tail,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Grep - search logs
        self.register_tool(
            name=f"{self.TOOL_NAME}_search",
            description=f"Search logs for a pattern with context. Usage: {self.TOOL_NAME}_search <pattern> [context_lines]",
            execute=self._run_search,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Errors - find error patterns
        self.register_tool(
            name=f"{self.TOOL_NAME}_errors",
            description=f"Find error patterns in logs. Usage: {self.TOOL_NAME}_errors [lines_to_scan]",
            execute=self._run_errors,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Filter by level
        self.register_tool(
            name=f"{self.TOOL_NAME}_filter",
            description=f"Filter logs by minimum level (debug/info/warning/error/critical). Usage: {self.TOOL_NAME}_filter <level>",
            execute=self._run_filter,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Correlate events
        self.register_tool(
            name=f"{self.TOOL_NAME}_correlate",
            description=f"Find correlated events within a time window. Usage: {self.TOOL_NAME}_correlate [window_seconds]",
            execute=self._run_correlate,
            requires_approval=False,
            action_type=ActionType.READ,
        )

    @abstractmethod
    def _fetch_logs(self, query: Optional[str] = None, lines: int = 100) -> str:
        """Fetch logs from source. Subclasses must implement.

        Args:
            query: Optional search query
            lines: Number of lines to fetch

        Returns:
            Raw log content
        """
        pass

    def _validate_pattern(self, pattern: str) -> str:
        """Validate and compile a regex pattern."""
        try:
            re.compile(pattern)
            return pattern
        except re.error as e:
            raise ValueError(f"Invalid regex pattern: {e}")

    def _run_tail(self, args: str = "") -> str:
        """Get the last N lines of logs."""
        parts = args.split(maxsplit=1)
        lines = 100
        filter_pattern = None

        if parts:
            try:
                lines = int(parts[0])
            except ValueError:
                filter_pattern = parts[0]

        if len(parts) > 1:
            filter_pattern = parts[1]

        try:
            logs = self._fetch_logs(lines=lines)
            self.bytes_processed += len(logs)

            if filter_pattern:
                self._validate_pattern(filter_pattern)
                logs = tail_logs(logs, lines, filter_pattern)

            line_count = len(logs.split('\n'))
            return f"Last {line_count} lines:\n\n{logs}"

        except Exception as e:
            return f"Error fetching logs: {e}"

    def _run_search(self, args: str) -> str:
        """Search logs for a pattern."""
        parts = args.split()
        if not parts:
            return "Usage: search <pattern> [context_lines]"

        pattern = parts[0]
        context = 3

        if len(parts) > 1:
            try:
                context = int(parts[1])
            except ValueError:
                pass

        try:
            self._validate_pattern(pattern)
            logs = self._fetch_logs(lines=5000)  # Search more lines
            self.bytes_processed += len(logs)

            results = grep_logs(logs, pattern, context)
            return results

        except ValueError as e:
            return f"Error: {e}"
        except Exception as e:
            return f"Error searching logs: {e}"

    def _run_errors(self, args: str = "") -> str:
        """Find error patterns in logs."""
        lines = 1000
        if args:
            try:
                lines = int(args)
            except ValueError:
                pass

        try:
            logs = self._fetch_logs(lines=lines)
            self.bytes_processed += len(logs)

            matches = extract_errors(logs, self.all_patterns)
            return summarize_errors(matches)

        except Exception as e:
            return f"Error analyzing logs: {e}"

    def _run_filter(self, args: str) -> str:
        """Filter logs by minimum level."""
        level_map = {
            "debug": LogLevel.DEBUG,
            "info": LogLevel.INFO,
            "warning": LogLevel.WARNING,
            "warn": LogLevel.WARNING,
            "error": LogLevel.ERROR,
            "critical": LogLevel.CRITICAL,
            "fatal": LogLevel.FATAL,
        }

        level_name = args.lower().strip()
        if level_name not in level_map:
            return f"Invalid level. Use: {', '.join(level_map.keys())}"

        try:
            logs = self._fetch_logs(lines=1000)
            self.bytes_processed += len(logs)

            filtered = filter_logs_by_level(logs, level_map[level_name])
            line_count = len(filtered.split('\n'))
            return f"Found {line_count} {level_name}+ entries:\n\n{filtered}"

        except Exception as e:
            return f"Error filtering logs: {e}"

    def _run_correlate(self, args: str = "") -> str:
        """Find correlated events."""
        window = 300
        if args:
            try:
                window = int(args)
            except ValueError:
                pass

        try:
            logs = self._fetch_logs(lines=2000)
            self.bytes_processed += len(logs)

            # Extract errors first
            matches = extract_errors(logs, self.all_patterns)

            # Convert to LogEntry format
            from agents.tools.log_parser import parse_log_line
            entries = []
            for match in matches:
                entry = parse_log_line(match.line, match.line_number)
                entries.append(entry)

            # Find chains
            chains = correlate_events(entries, window)

            if not chains:
                return f"No correlated event chains found within {window}s window."

            lines = [f"Found {len(chains)} event chain(s) within {window}s window:\n"]
            for i, chain in enumerate(chains, 1):
                lines.append(f"\n## Chain {i}: {len(chain.events)} events")
                if chain.root_cause:
                    lines.append(f"Root cause: {chain.root_cause}")
                for event in chain.events[:5]:
                    lines.append(f"  - {event}")
                if len(chain.events) > 5:
                    lines.append(f"  ... and {len(chain.events) - 5} more")

            return '\n'.join(lines)

        except Exception as e:
            return f"Error correlating events: {e}"

    @abstractmethod
    def _get_system_prompt(self) -> str:
        """Return system prompt. Subclasses must implement."""
        pass


class FileLogAgent(LogAgent):
    """LogAgent for local file-based logs."""

    LOG_SOURCE = "file"

    def _fetch_logs(self, query: Optional[str] = None, lines: int = 100) -> str:
        """Fetch logs from a local file."""
        cmd = ["tail", "-n", str(lines), self.log_path]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )

            if result.returncode != 0:
                return f"Error reading log file: {result.stderr}"

            return result.stdout

        except subprocess.TimeoutExpired:
            return f"Timeout reading {self.log_path}"
        except FileNotFoundError:
            return f"Log file not found: {self.log_path}"
        except Exception as e:
            return f"Error: {e}"

    def _get_system_prompt(self) -> str:
        return f"""You are a log analysis agent for {self.name}.

Log file: {self.log_path}

Available tools:
- {self.TOOL_NAME}_tail: Get recent log lines
- {self.TOOL_NAME}_search: Search for patterns
- {self.TOOL_NAME}_errors: Find error patterns
- {self.TOOL_NAME}_filter: Filter by log level
- {self.TOOL_NAME}_correlate: Find related events

Investigation approach:
1. Start with recent logs (tail)
2. Search for specific patterns or errors
3. Filter to relevant severity levels
4. Correlate events to find root causes

Always explain what you find and suggest next steps."""


class JournaldLogAgent(LogAgent):
    """LogAgent for systemd journal logs."""

    LOG_SOURCE = "journald"
    TOOL_NAME = "journal"

    def _fetch_logs(self, query: Optional[str] = None, lines: int = 100) -> str:
        """Fetch logs from journald."""
        cmd = ["journalctl", "-n", str(lines), "--no-pager"]

        if self.service:
            cmd.extend(["-u", self.service])

        if query:
            cmd.extend(["--grep", query])

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )

            return result.stdout or result.stderr

        except subprocess.TimeoutExpired:
            return "Timeout reading journal"
        except FileNotFoundError:
            return "journalctl not found"
        except Exception as e:
            return f"Error: {e}"

    def _get_system_prompt(self) -> str:
        service_info = f" for service {self.service}" if self.service else ""
        return f"""You are a systemd journal analysis agent{service_info}.

Available tools:
- {self.TOOL_NAME}_tail: Get recent journal entries
- {self.TOOL_NAME}_search: Search journal for patterns
- {self.TOOL_NAME}_errors: Find error patterns
- {self.TOOL_NAME}_filter: Filter by priority level
- {self.TOOL_NAME}_correlate: Find related events

Investigation approach:
1. Check recent entries for errors
2. Filter by service or priority
3. Search for specific patterns
4. Correlate boot events and service restarts

Always explain findings and suggest remediation."""


class DockerLogAgent(LogAgent):
    """LogAgent for Docker container logs."""

    LOG_SOURCE = "docker"
    TOOL_NAME = "docker"

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.container = config.get("container", name)
        super().__init__(name, config, terminal, llm)

    def _fetch_logs(self, query: Optional[str] = None, lines: int = 100) -> str:
        """Fetch logs from Docker container."""
        cmd = ["docker", "logs", "--tail", str(lines), self.container]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )

            # Docker logs outputs to stderr by default
            output = result.stdout + result.stderr
            return output

        except subprocess.TimeoutExpired:
            return f"Timeout reading logs for {self.container}"
        except FileNotFoundError:
            return "docker command not found"
        except Exception as e:
            return f"Error: {e}"

    def _get_system_prompt(self) -> str:
        return f"""You are a Docker container log analysis agent for container {self.container}.

Available tools:
- {self.TOOL_NAME}_tail: Get recent container logs
- {self.TOOL_NAME}_search: Search for patterns
- {self.TOOL_NAME}_errors: Find error patterns
- {self.TOOL_NAME}_filter: Filter by log level
- {self.TOOL_NAME}_correlate: Find related events

Investigation approach:
1. Check recent logs for startup errors
2. Look for application-specific error patterns
3. Check for OOM kills or container restarts
4. Correlate with container events

Always explain findings and suggest container-specific fixes."""
