"""Conversational agent base class.

This is the core of TernaryPhysics Ops: an AI agent you TALK to.
The agent thinks, decides what tools to use, interprets results,
and has an ongoing conversation with you about your resource.
"""

import re
import shlex
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional, TYPE_CHECKING

from cli.output.terminal import Terminal

if TYPE_CHECKING:
    from engine.llm.inference import TernaryLLM
    from engine.knowledge import KnowledgeStore, Investigation, ToolExecution


# =============================================================================
# Security: Command Sanitization
# =============================================================================

class SecurityViolation(Exception):
    """Raised when a command fails security validation."""
    pass


# Shell metacharacters that could enable command injection
DANGEROUS_CHARS = set(';|&$`\\\'\"(){}[]<>!\n\r')

# Patterns that suggest path traversal
PATH_TRAVERSAL_PATTERNS = [
    r'\.\.',           # Parent directory
    r'^/',             # Absolute path (context dependent)
    r'^~',             # Home directory expansion
]


def sanitize_args(args: str, allow_paths: bool = False) -> str:
    """Sanitize command arguments to prevent injection attacks.

    Args:
        args: The argument string to sanitize
        allow_paths: Whether to allow path-like arguments

    Returns:
        Sanitized argument string

    Raises:
        SecurityViolation: If dangerous patterns are detected
    """
    # Check for dangerous characters
    dangerous_found = DANGEROUS_CHARS.intersection(set(args))
    if dangerous_found:
        raise SecurityViolation(
            f"Blocked: arguments contain dangerous characters: {dangerous_found}"
        )

    # Check for path traversal (if not allowed)
    if not allow_paths:
        for pattern in PATH_TRAVERSAL_PATTERNS:
            if re.search(pattern, args):
                raise SecurityViolation(
                    f"Blocked: arguments contain path traversal pattern"
                )

    # Normalize whitespace
    return ' '.join(args.split())


def validate_command_allowlist(
    command: str,
    allowlist: list[str],
    blocklist: Optional[list[str]] = None
) -> bool:
    """Validate a command against allow/block lists.

    Args:
        command: The command to validate
        allowlist: Patterns that are allowed (e.g., ["get", "describe", "logs"])
        blocklist: Patterns that are blocked (e.g., ["delete", "exec"])

    Returns:
        True if command is allowed

    Raises:
        SecurityViolation: If command is blocked
    """
    # Parse command into parts
    try:
        parts = shlex.split(command)
    except ValueError:
        raise SecurityViolation("Blocked: malformed command")

    if not parts:
        return True

    cmd = parts[0].lower()

    # Check blocklist first
    if blocklist:
        for blocked in blocklist:
            if blocked.lower() in command.lower():
                raise SecurityViolation(
                    f"Blocked: '{blocked}' requires explicit approval"
                )

    # Check allowlist
    if allowlist:
        allowed = any(
            allow.lower() == cmd or allow.lower() in command.lower()
            for allow in allowlist
        )
        if not allowed:
            raise SecurityViolation(
                f"Blocked: '{cmd}' is not in the allowed commands list"
            )

    return True


# =============================================================================
# Action Approval System
# =============================================================================

class ActionType(Enum):
    """Types of actions an agent can take."""
    READ = "read"           # Safe read-only operations
    WRITE = "write"         # Modifications that need approval
    DELETE = "delete"       # Destructive operations (extra confirmation)
    EXECUTE = "execute"     # Running commands on resources


@dataclass
class PendingAction:
    """An action waiting for user approval."""
    id: str
    tool_name: str
    args: str
    action_type: ActionType
    description: str
    risk_level: str  # "low", "medium", "high"
    approved: Optional[bool] = None

    def format_for_display(self) -> str:
        """Format the action for terminal display."""
        risk_color = {
            "low": "\033[32m",      # green
            "medium": "\033[33m",   # yellow
            "high": "\033[31m",     # red
        }.get(self.risk_level, "")
        reset = "\033[0m"

        return (
            f"\n  {risk_color}[{self.risk_level.upper()} RISK]{reset} {self.description}\n"
            f"  Command: {self.tool_name} {self.args}\n"
        )


# =============================================================================
# Tool Definition
# =============================================================================

@dataclass
class Tool:
    """A tool the agent can use."""
    name: str
    description: str
    execute: Callable[[str], str]  # Takes args string, returns result

    # Security settings
    requires_approval: bool = False
    action_type: ActionType = ActionType.READ
    allowlist: list[str] = field(default_factory=list)  # Allowed subcommands
    blocklist: list[str] = field(default_factory=list)  # Blocked subcommands
    allow_paths: bool = False  # Whether to allow path arguments


@dataclass
class Message:
    """A message in the conversation."""
    role: str  # "user", "assistant", "system", "tool_result"
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)


# =============================================================================
# Error Handling
# =============================================================================

class ToolExecutionError(Exception):
    """Raised when a tool fails to execute."""
    def __init__(self, tool_name: str, message: str, retryable: bool = False):
        self.tool_name = tool_name
        self.retryable = retryable
        super().__init__(f"[{tool_name}] {message}")


class AgentError(Exception):
    """Base class for agent errors."""
    pass


# =============================================================================
# Conversational Agent
# =============================================================================

class ConversationalAgent(ABC):
    """Base class for conversational AI agents.

    The agent:
    1. Receives user messages
    2. Thinks about what to do (via LLM)
    3. Decides to use tools or respond
    4. Validates tool calls for security
    5. Requests approval for dangerous operations
    6. Executes tools and interprets results
    7. Continues the conversation

    Subclasses define the available tools and system prompt.
    """

    # Default safety settings (subclasses can override)
    MAX_TOOL_CALLS_PER_TURN = 5
    MAX_CONVERSATION_LENGTH = 50
    MAX_RETRIES = 2
    TOOL_TIMEOUT_SEC = 30

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal: Terminal,
        llm: "TernaryLLM | None" = None,
    ):
        self.name = name
        self.config = config
        self.terminal = terminal
        self.llm = llm
        self.conversation: list[Message] = []
        self.tools: dict[str, Tool] = {}
        self.bytes_processed = 0

        # Action tracking
        self.pending_actions: list[PendingAction] = []
        self.approved_actions: list[PendingAction] = []
        self.rejected_actions: list[PendingAction] = []
        self._action_counter = 0

        # Knowledge tracking (set by wrapper)
        self._knowledge_store: Optional["KnowledgeStore"] = None
        self._current_investigation: Optional["Investigation"] = None

        # Register tools
        self._register_tools()

        # Add system prompt
        system_prompt = self._get_system_prompt()
        self.conversation.append(Message(role="system", content=system_prompt))

    @abstractmethod
    def _get_system_prompt(self) -> str:
        """Return the system prompt that defines the agent's behavior."""
        pass

    @abstractmethod
    def _register_tools(self) -> None:
        """Register the tools this agent can use."""
        pass

    def register_tool(
        self,
        name: str,
        description: str,
        execute: Callable[[str], str],
        requires_approval: bool = False,
        action_type: ActionType = ActionType.READ,
        allowlist: Optional[list[str]] = None,
        blocklist: Optional[list[str]] = None,
        allow_paths: bool = False,
    ) -> None:
        """Register a tool the agent can use.

        Args:
            name: Tool name (used in TOOL: calls)
            description: Human-readable description
            execute: Function that executes the tool
            requires_approval: Whether user must approve before execution
            action_type: Type of action (read/write/delete/execute)
            allowlist: Allowed subcommands (empty = allow all)
            blocklist: Blocked subcommands
            allow_paths: Whether to allow path-like arguments
        """
        self.tools[name] = Tool(
            name=name,
            description=description,
            execute=execute,
            requires_approval=requires_approval,
            action_type=action_type,
            allowlist=allowlist or [],
            blocklist=blocklist or [],
            allow_paths=allow_paths,
        )

    def chat(self, user_message: str) -> str:
        """Process a user message and generate a response.

        This is the main conversation loop. The agent may:
        - Respond directly
        - Use one or more tools
        - Ask clarifying questions
        - Request approval for actions

        Args:
            user_message: What the user said

        Returns:
            The agent's response
        """
        # Enforce conversation length limit
        if len(self.conversation) >= self.MAX_CONVERSATION_LENGTH:
            self._trim_conversation()

        # Add user message to conversation
        self.conversation.append(Message(role="user", content=user_message))

        # Build prompt from conversation history
        prompt = self._build_prompt()

        # Get LLM response
        if self.llm:
            try:
                response = self.llm.generate(prompt, max_tokens=512)
            except Exception as e:
                self.terminal.error(f"LLM error: {e}")
                response = self._mock_response(user_message)
        else:
            response = self._mock_response(user_message)

        # Check if response contains tool calls
        tool_calls = self._extract_tool_calls(response)

        if tool_calls:
            # Validate and execute tools
            return self._process_tool_calls(response, tool_calls)
        else:
            # Direct response
            self.conversation.append(Message(role="assistant", content=response))
            return response

    def _build_prompt(self) -> str:
        """Build the full prompt from conversation history.

        Creates a structured prompt with:
        - System context
        - Recent conversation history
        - Available tools
        - Current question
        """
        # Get system prompt
        system = self.conversation[0].content if self.conversation else ""

        # Build conversation context (last N messages)
        context_messages = []
        for msg in self.conversation[-10:]:  # Last 10 messages
            if msg.role == "user":
                context_messages.append(f"User: {msg.content}")
            elif msg.role == "assistant":
                context_messages.append(f"Assistant: {msg.content}")
            elif msg.role == "tool_result":
                # Truncate long tool outputs
                content = msg.content[:500] + "..." if len(msg.content) > 500 else msg.content
                context_messages.append(f"Tool Output: {content}")

        context = "\n".join(context_messages[-6:])  # Last 6 for prompt

        # Get the last user message
        user_msg = ""
        for msg in reversed(self.conversation):
            if msg.role == "user":
                user_msg = msg.content
                break

        # Build structured prompt
        tools_list = ", ".join(self.tools.keys())

        return f"""You are an expert assistant for "{self.name}".

{system}

Available tools: {tools_list}
To use a tool: TOOL: <tool_name> <arguments>

Recent conversation:
{context}

Current question: {user_msg}

Think step by step:
1. What is the user asking?
2. What information do I need?
3. Which tool(s) should I use?
4. What is my response?

Response:"""

    def _extract_tool_calls(self, response: str) -> list[tuple[str, str]]:
        """Extract tool calls from the response.

        Tools are called with: TOOL: <tool_name> <args>

        Returns:
            List of (tool_name, args) tuples
        """
        calls = []

        # Pattern: TOOL: tool_name args
        pattern = r'TOOL:\s*(\w+)\s*(.*?)(?=\nTOOL:|\n\n|$)'
        matches = re.findall(pattern, response, re.IGNORECASE | re.DOTALL)

        for tool_name, args in matches:
            tool_name = tool_name.strip().lower()
            args = args.strip()
            if tool_name in self.tools:
                calls.append((tool_name, args))

        # Limit tool calls per turn
        return calls[:self.MAX_TOOL_CALLS_PER_TURN]

    def _process_tool_calls(
        self,
        initial_response: str,
        tool_calls: list[tuple[str, str]],
        depth: int = 0,
    ) -> str:
        """Process tool calls with security validation and approval flow.

        Args:
            initial_response: The LLM's response containing tool calls
            tool_calls: List of (tool_name, args) to execute
            depth: Recursion depth (to prevent infinite loops)

        Returns:
            Final response after tool execution
        """
        if depth >= 5:  # Prevent infinite recursion
            return "I've reached my investigation limit. Let me summarize what I found."

        # Add the initial response to history
        self.conversation.append(Message(role="assistant", content=initial_response))

        # Process each tool call
        all_results = []
        for tool_name, args in tool_calls:
            tool = self.tools[tool_name]

            try:
                # 1. Security validation
                self._validate_tool_call(tool, args)

                # 2. Check if approval needed
                if tool.requires_approval or tool.action_type in (ActionType.WRITE, ActionType.DELETE):
                    result = self._request_approval_and_execute(tool, args)
                else:
                    result = self._execute_tool(tool, args)

                all_results.append(f"{tool_name}: {result}")

            except SecurityViolation as e:
                self.terminal.warning(f"Security: {e}")
                all_results.append(f"{tool_name}: BLOCKED - {e}")

            except ToolExecutionError as e:
                self.terminal.error(str(e))
                all_results.append(f"{tool_name}: ERROR - {e}")

            except Exception as e:
                self.terminal.error(f"Unexpected error in {tool_name}: {e}")
                all_results.append(f"{tool_name}: ERROR - {e}")

        # Add tool results to conversation
        tool_output = "\n".join(all_results)
        self.conversation.append(Message(role="tool_result", content=tool_output))

        # Get LLM to interpret results and continue
        prompt = self._build_prompt()

        if self.llm:
            try:
                continuation = self.llm.generate(prompt, max_tokens=512)
            except Exception as e:
                continuation = self._mock_continuation(tool_output)
        else:
            continuation = self._mock_continuation(tool_output)

        # Check for more tool calls
        more_tools = self._extract_tool_calls(continuation)

        if more_tools:
            return self._process_tool_calls(continuation, more_tools, depth + 1)
        else:
            self.conversation.append(Message(role="assistant", content=continuation))
            return continuation

    def _validate_tool_call(self, tool: Tool, args: str) -> None:
        """Validate a tool call for security.

        Args:
            tool: The tool being called
            args: Arguments to the tool

        Raises:
            SecurityViolation: If validation fails
        """
        # Sanitize arguments
        sanitize_args(args, allow_paths=tool.allow_paths)

        # Check allow/block lists
        if tool.allowlist or tool.blocklist:
            validate_command_allowlist(args, tool.allowlist, tool.blocklist)

    def _request_approval_and_execute(self, tool: Tool, args: str) -> str:
        """Request user approval before executing a tool.

        Args:
            tool: The tool to execute
            args: Arguments for the tool

        Returns:
            Tool result or rejection message
        """
        # Create pending action
        self._action_counter += 1
        action = PendingAction(
            id=f"{self.name}:action-{self._action_counter}",
            tool_name=tool.name,
            args=args,
            action_type=tool.action_type,
            description=f"Execute {tool.name} {args[:50]}{'...' if len(args) > 50 else ''}",
            risk_level="high" if tool.action_type == ActionType.DELETE else "medium",
        )

        # Show approval request
        self.terminal.print(action.format_for_display())

        # Get user confirmation
        try:
            response = input("  Approve? [y/N]: ").strip().lower()
            approved = response in ('y', 'yes')
        except (EOFError, KeyboardInterrupt):
            approved = False

        if approved:
            action.approved = True
            self.approved_actions.append(action)
            self.terminal.success("Action approved")
            return self._execute_tool(tool, args)
        else:
            action.approved = False
            self.rejected_actions.append(action)
            self.terminal.info("Action rejected")
            return "Action was rejected by user"

    def _execute_tool(self, tool: Tool, args: str, retry_count: int = 0) -> str:
        """Execute a tool with error handling and retries.

        Args:
            tool: The tool to execute
            args: Arguments for the tool
            retry_count: Current retry attempt

        Returns:
            Tool execution result

        Raises:
            ToolExecutionError: If execution fails after retries
        """
        # Show what we're doing
        display_args = f"{args[:60]}..." if len(args) > 60 else args
        self.terminal.info(f"[{tool.name}] {display_args}")

        start_time = time.time()
        success = True
        result = ""

        try:
            result = tool.execute(args)

            # Track bytes processed
            self.bytes_processed += len(result.encode('utf-8'))

            # Truncate very long results
            if len(result) > 2000:
                result = result[:2000] + "\n... (truncated)"

            return result

        except TimeoutError:
            success = False
            if retry_count < self.MAX_RETRIES:
                self.terminal.warning(f"Timeout, retrying ({retry_count + 1}/{self.MAX_RETRIES})...")
                return self._execute_tool(tool, args, retry_count + 1)
            raise ToolExecutionError(tool.name, "Command timed out", retryable=True)

        except ConnectionError as e:
            success = False
            if retry_count < self.MAX_RETRIES:
                self.terminal.warning(f"Connection error, retrying ({retry_count + 1}/{self.MAX_RETRIES})...")
                return self._execute_tool(tool, args, retry_count + 1)
            raise ToolExecutionError(tool.name, f"Connection failed: {e}", retryable=True)

        except Exception as e:
            success = False
            raise ToolExecutionError(tool.name, str(e), retryable=False)

        finally:
            # Record tool execution if tracking is enabled
            duration_ms = int((time.time() - start_time) * 1000)
            self._record_tool_execution(tool.name, args, result, success, duration_ms)

    def _record_tool_execution(
        self,
        tool_name: str,
        args: str,
        output: str,
        success: bool,
        duration_ms: int,
    ) -> None:
        """Record a tool execution to the knowledge store."""
        if self._knowledge_store and self._current_investigation and self._current_investigation.id:
            try:
                self._knowledge_store.record_tool_execution(
                    investigation_id=self._current_investigation.id,
                    tool_name=tool_name,
                    args=args,
                    output=output,
                    success=success,
                    duration_ms=duration_ms,
                )
            except Exception:
                pass  # Don't fail the tool execution if recording fails

    def set_knowledge_tracking(
        self,
        store: "KnowledgeStore",
        investigation: "Investigation",
    ) -> None:
        """Enable knowledge tracking for this agent session.

        Args:
            store: The knowledge store to record to
            investigation: The current investigation being tracked
        """
        self._knowledge_store = store
        self._current_investigation = investigation

    def _trim_conversation(self) -> None:
        """Trim conversation history to stay within limits.

        Keeps system prompt and recent messages.
        """
        if len(self.conversation) <= 10:
            return

        # Keep system prompt (first message) and last 10 messages
        system = self.conversation[0] if self.conversation else None
        recent = self.conversation[-10:]

        self.conversation = [system] + recent if system else recent
        self.terminal.info("(conversation history trimmed)")

    def _mock_response(self, user_message: str) -> str:
        """Mock response when LLM isn't available."""
        msg_lower = user_message.lower()

        if any(w in msg_lower for w in ["crash", "fail", "error", "wrong"]):
            return """Let me check what's happening.

TOOL: kubectl get pods -A --field-selector=status.phase!=Running"""

        elif any(w in msg_lower for w in ["log", "why"]):
            return """TOOL: kubectl logs --previous --tail=50"""

        elif any(w in msg_lower for w in ["fix", "help", "do"]):
            return """Based on what I found, I recommend checking the resource limits and recent deployments. Would you like me to investigate further?"""

        else:
            return """I'm monitoring this resource. What would you like to know?

I can check:
- Pod status and health
- Recent events and errors
- Resource utilization
- Logs from any container

What should I investigate?"""

    def _mock_continuation(self, tool_output: str) -> str:
        """Mock continuation after tool execution."""
        if "CrashLoopBackOff" in tool_output:
            return """I found pods that are crash-looping. Let me check the logs.

TOOL: kubectl logs --previous"""

        elif "Error" in tool_output or "error" in tool_output:
            return """I see errors in the output. This suggests a configuration or dependency issue. Let me check the events for more context.

TOOL: kubectl get events --sort-by='.lastTimestamp'"""

        elif "Running" in tool_output and "0/" not in tool_output:
            return """Everything looks healthy. All pods are running normally. Is there a specific issue you're seeing?"""

        elif "BLOCKED" in tool_output:
            return """I tried to run a command but it was blocked for security reasons. Let me try a safer approach.

TOOL: kubectl get pods"""

        else:
            return """I've gathered the information. Based on what I see, the system appears to be functioning. Let me know if you'd like me to dig deeper into any specific area."""

    def get_cost(self) -> float:
        """Get the cost based on GB processed."""
        gb = self.bytes_processed / (1024 * 1024 * 1024)
        return gb * 0.50  # $0.50/GB

    def get_stats(self) -> dict[str, Any]:
        """Get agent statistics."""
        return {
            "name": self.name,
            "messages": len(self.conversation),
            "bytes_processed": self.bytes_processed,
            "cost": self.get_cost(),
            "actions_approved": len(self.approved_actions),
            "actions_rejected": len(self.rejected_actions),
            "tools_available": list(self.tools.keys()),
        }
