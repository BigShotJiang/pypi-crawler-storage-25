"""Database Agent base class.

Base class for all database agents (58 agents):
- PostgreSQL, MySQL, MongoDB, Redis, Elasticsearch, etc.

Provides:
- Automatic tool registration (query, query_write, explain)
- Query validation and sanitization
- Result formatting
- Common performance queries
"""

import subprocess
from typing import Optional, Any

from agents.base.conversational import (
    ConversationalAgent,
    ActionType,
    sanitize_args,
    SecurityViolation,
)
from agents.tools.db_connector import (
    DatabaseType,
    QueryResult,
    ConnectionConfig,
    validate_query,
    validate_redis_command,
    validate_mongodb_query,
    QueryValidationError,
    format_results_table,
    POSTGRESQL_QUERIES,
    MYSQL_QUERIES,
    REDIS_COMMANDS,
    MONGODB_COMMANDS,
)


class DatabaseAgent(ConversationalAgent):
    """Base class for database agents.

    Subclasses should override:
    - DB_TYPE: DatabaseType enum value
    - DEFAULT_PORT: Default port for this database
    - CLI_COMMAND: CLI tool name (psql, mysql, redis-cli, etc.)
    - SAFE_OPERATIONS: Allowed read-only operations
    - DANGEROUS_OPERATIONS: Operations requiring approval
    - _get_system_prompt(): Domain-specific system prompt
    - _build_cli_command(): Build CLI command for query execution
    - _parse_cli_output(): Parse CLI output into structured data
    """

    # Subclasses override these class attributes
    DB_TYPE: DatabaseType = DatabaseType.POSTGRESQL
    DEFAULT_PORT: int = 5432
    CLI_COMMAND: str = "psql"
    TOOL_NAME: str = "query"
    COMMAND_TIMEOUT: int = 30

    # Query type validation
    SAFE_OPERATIONS: list[str] = ["SELECT", "SHOW", "DESCRIBE", "EXPLAIN"]
    DANGEROUS_OPERATIONS: list[str] = ["DROP", "DELETE", "TRUNCATE", "ALTER", "INSERT", "UPDATE"]

    def __init__(
        self,
        name: str,
        config: dict,
        terminal,
        llm=None,
    ):
        """Initialize DatabaseAgent.

        Args:
            name: Agent name (typically database name)
            config: Configuration dict with:
                - host: Database host
                - port: Database port (optional)
                - database: Database name
                - user: Database user
                - password: Database password (optional)
            terminal: Terminal for output
            llm: Optional LLM client
        """
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database", "")
        self.user = config.get("user", "")
        self.password = config.get("password", "")
        self.config = config
        super().__init__(name, config, terminal, llm)

    def _register_tools(self):
        """Register database tools automatically.

        Creates three tools:
        1. {TOOL_NAME}: Read-only queries
        2. {TOOL_NAME}_write: Write queries requiring approval
        3. explain: Query execution plan analysis
        """
        tool_name = self.TOOL_NAME

        # Read-only query tool
        self.register_tool(
            name=tool_name,
            description=f"Execute read-only {self.DB_TYPE.value} queries",
            execute=self._run_query,
            requires_approval=False,
            action_type=ActionType.READ,
            allowlist=self.SAFE_OPERATIONS,
            blocklist=self.DANGEROUS_OPERATIONS,
        )

        # Write query tool (requires approval)
        self.register_tool(
            name=f"{tool_name}_write",
            description=f"Execute {self.DB_TYPE.value} write operations (requires approval)",
            execute=self._run_write_query,
            requires_approval=True,
            action_type=ActionType.WRITE,
            allowlist=self.DANGEROUS_OPERATIONS,
            blocklist=[],
        )

        # Explain/analyze tool
        self.register_tool(
            name="explain",
            description="Analyze query execution plan",
            execute=self._run_explain,
            requires_approval=False,
            action_type=ActionType.READ,
            allowlist=["EXPLAIN", "ANALYZE"],
            blocklist=[],
        )

    def _validate_query(self, query: str, allow_writes: bool = False) -> str:
        """Validate a query for this database type.

        Args:
            query: Query string
            allow_writes: Whether to allow write operations

        Returns:
            Validated query string

        Raises:
            SecurityViolation: If query is blocked
        """
        try:
            # First sanitize for shell injection
            sanitized = sanitize_args(query, allow_paths=True)

            # Then validate for database-specific issues
            if self.DB_TYPE == DatabaseType.REDIS:
                return validate_redis_command(sanitized, allow_writes)
            elif self.DB_TYPE == DatabaseType.MONGODB:
                return validate_mongodb_query(sanitized, allow_writes)
            else:
                # SQL databases
                return validate_query(sanitized, self.DB_TYPE, allow_writes)

        except QueryValidationError as e:
            raise SecurityViolation(str(e))

    def _build_cli_command(self, query: str) -> list[str]:
        """Build CLI command for query execution.

        Subclasses MUST override this for their specific CLI tool.

        Args:
            query: Query to execute

        Returns:
            Complete CLI command as list of strings
        """
        raise NotImplementedError("Subclasses must implement _build_cli_command")

    def _parse_cli_output(self, stdout: str, stderr: str) -> QueryResult:
        """Parse CLI output into QueryResult.

        Subclasses can override for custom parsing.

        Args:
            stdout: Standard output from CLI
            stderr: Standard error from CLI

        Returns:
            QueryResult with parsed data
        """
        if stderr and "error" in stderr.lower():
            return QueryResult(
                success=False,
                error=stderr,
            )

        # Basic parsing - subclasses should override for better results
        lines = stdout.strip().split("\n") if stdout else []

        if not lines:
            return QueryResult(success=True, rows=[], row_count=0)

        # Try to detect tabular output
        if len(lines) >= 2 and "|" in lines[0]:
            return self._parse_table_output(lines)

        return QueryResult(
            success=True,
            rows=[{"output": stdout}],
            columns=["output"],
            row_count=len(lines),
        )

    def _parse_table_output(self, lines: list[str]) -> QueryResult:
        """Parse pipe-separated table output.

        Args:
            lines: Output lines

        Returns:
            QueryResult with parsed rows
        """
        # Find header row (first row with pipes)
        header_idx = 0
        for i, line in enumerate(lines):
            if "|" in line:
                header_idx = i
                break

        # Parse header
        header_line = lines[header_idx]
        columns = [col.strip() for col in header_line.split("|") if col.strip()]

        # Find data rows (skip separator lines)
        rows = []
        for line in lines[header_idx + 1:]:
            if not line.strip() or line.strip().startswith("-") or line.strip().startswith("+"):
                continue
            if "|" not in line:
                continue

            values = [val.strip() for val in line.split("|") if val.strip() or "|" in line]
            # Handle edge case of empty values
            if len(values) < len(columns):
                values.extend([""] * (len(columns) - len(values)))

            row = dict(zip(columns, values[:len(columns)]))
            rows.append(row)

        return QueryResult(
            success=True,
            rows=rows,
            columns=columns,
            row_count=len(rows),
        )

    def _execute_cli(self, query: str) -> tuple[str, str, int]:
        """Execute CLI command and return output.

        Args:
            query: Query to execute

        Returns:
            Tuple of (stdout, stderr, return_code)
        """
        cmd = self._build_cli_command(query)

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )
            return result.stdout, result.stderr, result.returncode

        except subprocess.TimeoutExpired:
            return "", f"Query timed out after {self.COMMAND_TIMEOUT} seconds", -1

        except FileNotFoundError:
            return "", f"CLI tool '{self.CLI_COMMAND}' not found", -1

        except Exception as e:
            return "", str(e), -1

    def _run_query(self, query: str) -> str:
        """Execute a read-only query.

        Args:
            query: Query string

        Returns:
            Query results or error message
        """
        try:
            validated = self._validate_query(query, allow_writes=False)
        except SecurityViolation as e:
            return f"Error: {e}"

        stdout, stderr, returncode = self._execute_cli(validated)

        # Track bytes for metering
        self.bytes_processed += len(stdout) + len(stderr)

        if returncode != 0:
            return f"Error: {stderr or 'Query failed'}"

        result = self._parse_cli_output(stdout, stderr)
        return str(result)

    def _run_write_query(self, query: str) -> str:
        """Execute a write query (requires approval).

        Args:
            query: Query string

        Returns:
            Query results or error message
        """
        try:
            validated = self._validate_query(query, allow_writes=True)
        except SecurityViolation as e:
            return f"Error: {e}"

        stdout, stderr, returncode = self._execute_cli(validated)
        self.bytes_processed += len(stdout) + len(stderr)

        if returncode != 0:
            return f"Error: {stderr or 'Query failed'}"

        return stdout if stdout else "Query executed successfully"

    def _run_explain(self, query: str) -> str:
        """Run EXPLAIN on a query.

        Args:
            query: Query to analyze

        Returns:
            Execution plan or error message
        """
        # Build explain query based on database type
        explain_query = self._build_explain_query(query)

        try:
            validated = self._validate_query(explain_query, allow_writes=False)
        except SecurityViolation as e:
            return f"Error: {e}"

        stdout, stderr, returncode = self._execute_cli(validated)
        self.bytes_processed += len(stdout) + len(stderr)

        if returncode != 0:
            return f"Error: {stderr or 'Explain failed'}"

        return stdout if stdout else "(no output)"

    def _build_explain_query(self, query: str) -> str:
        """Build EXPLAIN query for this database type.

        Args:
            query: Query to analyze

        Returns:
            EXPLAIN query string
        """
        # Default SQL EXPLAIN
        if query.upper().startswith("EXPLAIN"):
            return query
        return f"EXPLAIN {query}"

    def _get_performance_queries(self) -> dict[str, str]:
        """Get common performance queries for this database.

        Subclasses should override to provide database-specific queries.

        Returns:
            Dict mapping query name to query string
        """
        return {}

    def _get_system_prompt(self) -> str:
        """Get the system prompt for this agent.

        Subclasses should override for domain-specific guidance.

        Returns:
            System prompt string
        """
        return f"""You are a {self.DB_TYPE.value} database investigation agent for {self.database}.

Available tools:
- {self.TOOL_NAME}: Execute read-only queries
- {self.TOOL_NAME}_write: Execute write operations (requires approval)
- explain: Analyze query execution plans

When investigating:
1. Check active connections and queries
2. Look for slow queries and lock contention
3. Analyze table sizes and index usage
4. Check replication status if applicable

Always explain what you find and suggest optimizations."""

    def _mock_response(self, query: str) -> str:
        """Generate mock response for testing without database.

        Args:
            query: User query

        Returns:
            Mock response string
        """
        q = query.lower()

        if "slow" in q or "performance" in q:
            return f"I'll check for slow queries. TOOL: {self.TOOL_NAME} {self._get_slow_query_sql()}"

        if "connection" in q or "active" in q:
            return f"I'll check active connections. TOOL: {self.TOOL_NAME} {self._get_connections_sql()}"

        if "size" in q or "space" in q:
            return f"I'll check table sizes. TOOL: {self.TOOL_NAME} {self._get_sizes_sql()}"

        if "lock" in q or "block" in q:
            return f"I'll check for locks. TOOL: {self.TOOL_NAME} {self._get_locks_sql()}"

        if "replication" in q or "replica" in q:
            return f"I'll check replication status. TOOL: {self.TOOL_NAME} {self._get_replication_sql()}"

        return f"I'll help investigate this {self.DB_TYPE.value} database. TOOL: {self.TOOL_NAME} SELECT 1"

    def _mock_continuation(self, tool_output: str) -> str:
        """Generate mock continuation based on tool output.

        Args:
            tool_output: Output from tool execution

        Returns:
            Mock continuation string
        """
        output_lower = tool_output.lower()

        if "error" in output_lower:
            return "I found an error in the query. Let me investigate the cause."

        if "lock" in output_lower or "waiting" in output_lower:
            return """I detected lock contention in the database.

**Analysis:**
- There are queries waiting for locks
- This can cause performance degradation

**Recommendations:**
1. Identify the blocking queries
2. Consider query optimization or index improvements
3. Review transaction isolation levels

Would you like me to investigate the blocking queries?"""

        if "0 row" in output_lower or "no row" in output_lower:
            return "The query returned no results. Would you like me to try a different approach?"

        return "Query completed. Would you like me to analyze anything specific?"

    # Subclasses can override these for database-specific queries
    def _get_slow_query_sql(self) -> str:
        return "SELECT 'slow query check'"

    def _get_connections_sql(self) -> str:
        return "SELECT 'connections check'"

    def _get_sizes_sql(self) -> str:
        return "SELECT 'size check'"

    def _get_locks_sql(self) -> str:
        return "SELECT 'locks check'"

    def _get_replication_sql(self) -> str:
        return "SELECT 'replication check'"
