"""Executor for running commands with human approval."""

import subprocess
from dataclasses import dataclass
from typing import Callable

from cli.output.terminal import Terminal


@dataclass
class ExecutionResult:
    """Result of command execution."""
    success: bool
    stdout: str
    stderr: str
    return_code: int


class Executor:
    """Execute commands with safety checks and human approval.

    The executor enforces:
    - Read-only operations are autonomous
    - Write operations require explicit approval
    - All executions are logged to audit trail
    """

    def __init__(self, terminal: Terminal):
        self.terminal = terminal

    def run_readonly(
        self,
        command: list[str],
        timeout: int = 60,
        track_fn: Callable[[str], None] | None = None,
    ) -> ExecutionResult:
        """Run a read-only command autonomously.

        Args:
            command: Command and arguments to run
            timeout: Timeout in seconds
            track_fn: Optional function to track output data

        Returns:
            ExecutionResult with output
        """
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            if track_fn and result.stdout:
                track_fn(result.stdout)

            return ExecutionResult(
                success=result.returncode == 0,
                stdout=result.stdout,
                stderr=result.stderr,
                return_code=result.returncode,
            )

        except subprocess.TimeoutExpired:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=f"Command timed out after {timeout}s",
                return_code=-1,
            )
        except FileNotFoundError:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=f"Command not found: {command[0]}",
                return_code=-1,
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=str(e),
                return_code=-1,
            )

    def run_with_approval(
        self,
        command: str,
        description: str,
        timeout: int = 300,
    ) -> ExecutionResult | None:
        """Run a write command with human approval.

        Args:
            command: Shell command to run (string for shell=True)
            description: Human-readable description
            timeout: Timeout in seconds

        Returns:
            ExecutionResult if approved and executed, None if rejected
        """
        self.terminal.print()
        self.terminal.info(f"Action: {description}")
        self.terminal.info(f"Command: {command}")
        self.terminal.print()

        if not self.terminal.confirm("Execute this action?"):
            self.terminal.info("Action cancelled")
            return None

        self.terminal.info("Executing...")

        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            return ExecutionResult(
                success=result.returncode == 0,
                stdout=result.stdout,
                stderr=result.stderr,
                return_code=result.returncode,
            )

        except subprocess.TimeoutExpired:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=f"Command timed out after {timeout}s",
                return_code=-1,
            )
        except Exception as e:
            return ExecutionResult(
                success=False,
                stdout="",
                stderr=str(e),
                return_code=-1,
            )
