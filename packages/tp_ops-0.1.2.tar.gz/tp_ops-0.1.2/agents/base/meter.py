"""Metering for tracking data processed by agents."""


class Meter:
    """Track bytes/GB processed during an investigation or scan.

    Used for per-GB billing at $0.50/GB.
    """

    def __init__(self):
        self._bytes = 0

    def add_bytes(self, count: int) -> None:
        """Add bytes to the meter."""
        self._bytes += count

    def add_kb(self, count: float) -> None:
        """Add kilobytes to the meter."""
        self._bytes += int(count * 1024)

    def add_mb(self, count: float) -> None:
        """Add megabytes to the meter."""
        self._bytes += int(count * 1024 * 1024)

    def get_bytes(self) -> int:
        """Get total bytes processed."""
        return self._bytes

    def get_kb(self) -> float:
        """Get total KB processed."""
        return self._bytes / 1024

    def get_mb(self) -> float:
        """Get total MB processed."""
        return self._bytes / (1024 * 1024)

    def get_gb(self) -> float:
        """Get total GB processed."""
        return self._bytes / (1024 * 1024 * 1024)

    def reset(self) -> None:
        """Reset the meter."""
        self._bytes = 0
