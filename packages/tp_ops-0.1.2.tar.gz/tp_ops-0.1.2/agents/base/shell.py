"""Shell Agent base class.

Base class for all CLI-based agents (72 agents):
- kubectl, docker, aws, az, gcloud, ssh, etc.

Provides:
- Automatic tool registration (read, write, json variants)
- Command building with prefix
- Output parsing (JSON, table, text)
- Security validation (safe/dangerous command lists)
"""

import re
from typing import Optional, Callable

from agents.base.conversational import (
    ConversationalAgent,
    ActionType,
    sanitize_args,
    validate_command_allowlist,
    SecurityViolation,
)
from agents.tools.shell_executor import (
    execute_command,
    parse_json_output,
    parse_table_output,
    CommandResult,
)


class ShellAgent(ConversationalAgent):
    """Base class for CLI-based agents.

    Subclasses should override:
    - COMMAND_PREFIX: Base command (e.g., ["kubectl"], ["aws", "ec2"])
    - SAFE_SUBCOMMANDS: Allowed read-only subcommands
    - DANGEROUS_SUBCOMMANDS: Subcommands requiring approval
    - OUTPUT_FORMAT: Expected output format (json, text, yaml)
    - _get_system_prompt(): Domain-specific system prompt
    - _summarize_output(): Optional custom output summarization
    """

    # Subclasses override these class attributes
    COMMAND_PREFIX: list[str] = []
    SAFE_SUBCOMMANDS: list[str] = []
    DANGEROUS_SUBCOMMANDS: list[str] = []
    OUTPUT_FORMAT: str = "text"  # json, text, yaml
    TOOL_NAME: str = "cmd"  # Base tool name (e.g., "kubectl", "ssh", "aws")
    COMMAND_TIMEOUT: int = 60  # Default timeout in seconds

    def __init__(
        self,
        name: str,
        config: dict,
        terminal,
        llm=None,
    ):
        """Initialize ShellAgent.

        Args:
            name: Agent name
            config: Configuration dict with connection details
            terminal: Terminal for output
            llm: Optional LLM client
        """
        self.config = config
        super().__init__(name, config, terminal, llm)

    def _register_tools(self):
        """Register CLI tools automatically.

        Creates three tools:
        1. {TOOL_NAME}: Read-only commands (uses SAFE_SUBCOMMANDS)
        2. {TOOL_NAME}_write: Write commands requiring approval
        3. {TOOL_NAME}_json: Read commands with JSON output parsing
        """
        tool_name = self.TOOL_NAME

        # Read-only tool
        self.register_tool(
            name=tool_name,
            description=f"Execute read-only {tool_name} commands",
            execute=self._run_read_command,
            requires_approval=False,
            action_type=ActionType.READ,
            allowlist=self.SAFE_SUBCOMMANDS,
            blocklist=self.DANGEROUS_SUBCOMMANDS,
        )

        # Write tool (requires approval)
        if self.DANGEROUS_SUBCOMMANDS:
            self.register_tool(
                name=f"{tool_name}_write",
                description=f"Execute {tool_name} write operations (requires approval)",
                execute=self._run_write_command,
                requires_approval=True,
                action_type=ActionType.WRITE,
                allowlist=self.DANGEROUS_SUBCOMMANDS,
                blocklist=[],
            )

        # JSON output tool
        self.register_tool(
            name=f"{tool_name}_json",
            description=f"Execute {tool_name} commands with JSON output parsing",
            execute=self._run_json_command,
            requires_approval=False,
            action_type=ActionType.READ,
            allowlist=self.SAFE_SUBCOMMANDS,
            blocklist=self.DANGEROUS_SUBCOMMANDS,
        )

    def _build_command(self, args: str) -> list[str]:
        """Build full command from prefix and args.

        Subclasses can override to customize command building
        (e.g., adding SSH user@host, kubeconfig flags).

        Args:
            args: Command arguments string

        Returns:
            Complete command as list of strings
        """
        prefix = self._get_command_prefix()
        # Split args carefully, preserving quoted strings
        arg_list = self._parse_args(args)
        return prefix + arg_list

    def _get_command_prefix(self) -> list[str]:
        """Get the command prefix.

        Subclasses can override to add dynamic prefix elements
        (e.g., SSH connection details, cloud credentials).

        Returns:
            Command prefix as list of strings
        """
        return self.COMMAND_PREFIX.copy()

    def _parse_args(self, args: str) -> list[str]:
        """Parse argument string into list, preserving quoted strings.

        Args:
            args: Argument string (e.g., 'get pods -n default')

        Returns:
            List of argument strings
        """
        if not args or not args.strip():
            return []

        # Use shlex-like parsing to handle quotes
        result = []
        current = []
        in_quotes = False
        quote_char = None

        for char in args:
            if char in ('"', "'") and not in_quotes:
                in_quotes = True
                quote_char = char
            elif char == quote_char and in_quotes:
                in_quotes = False
                quote_char = None
            elif char == ' ' and not in_quotes:
                if current:
                    result.append(''.join(current))
                    current = []
            else:
                current.append(char)

        if current:
            result.append(''.join(current))

        return result

    def _validate_command(self, args: str, is_write: bool = False) -> str:
        """Validate command arguments.

        Args:
            args: Command arguments
            is_write: Whether this is a write operation

        Returns:
            Sanitized arguments

        Raises:
            SecurityViolation: If command is blocked
        """
        # Sanitize for injection
        sanitized = sanitize_args(args)

        # Check allowlist/blocklist
        if is_write:
            # Write commands must be in DANGEROUS_SUBCOMMANDS
            validate_command_allowlist(
                sanitized,
                allowlist=self.DANGEROUS_SUBCOMMANDS,
                blocklist=[],
            )
        else:
            # Read commands must not be in DANGEROUS_SUBCOMMANDS
            validate_command_allowlist(
                sanitized,
                allowlist=self.SAFE_SUBCOMMANDS,
                blocklist=self.DANGEROUS_SUBCOMMANDS,
            )

        return sanitized

    def _run_read_command(self, args: str) -> str:
        """Execute a read-only command.

        Args:
            args: Command arguments

        Returns:
            Command output or error message
        """
        try:
            validated = self._validate_command(args, is_write=False)
        except SecurityViolation as e:
            return f"Error: {e}. Use {self.TOOL_NAME}_write for write operations."

        cmd = self._build_command(validated)
        result = execute_command(cmd, timeout=self.COMMAND_TIMEOUT)

        # Track bytes for metering
        output = str(result)
        self.bytes_processed += len(output)

        if result.success:
            return self._format_output(result.stdout)
        return str(result)

    def _run_write_command(self, args: str) -> str:
        """Execute a write command (requires approval).

        Args:
            args: Command arguments

        Returns:
            Command output or error message
        """
        try:
            validated = self._validate_command(args, is_write=True)
        except SecurityViolation as e:
            return f"Error: {e}"

        cmd = self._build_command(validated)
        result = execute_command(cmd, timeout=self.COMMAND_TIMEOUT)

        output = str(result)
        self.bytes_processed += len(output)

        return str(result)

    def _run_json_command(self, args: str) -> str:
        """Execute command and parse JSON output.

        Args:
            args: Command arguments

        Returns:
            Summarized output or error message
        """
        try:
            validated = self._validate_command(args, is_write=False)
        except SecurityViolation as e:
            return f"Error: {e}"

        # Add JSON output flag if not present
        validated = self._ensure_json_output(validated)

        cmd = self._build_command(validated)
        result = execute_command(cmd, timeout=self.COMMAND_TIMEOUT)

        self.bytes_processed += len(result.stdout)

        if result.success:
            data = parse_json_output(result.stdout)
            return self._summarize_json(data)

        return str(result)

    def _ensure_json_output(self, args: str) -> str:
        """Ensure JSON output flag is present.

        Subclasses should override for their specific flag format.
        Default implementation adds '-o json' if not present.

        Args:
            args: Command arguments

        Returns:
            Arguments with JSON output flag
        """
        if '-o json' not in args and '--output json' not in args:
            return f"{args} -o json"
        return args

    def _format_output(self, raw: str) -> str:
        """Format command output based on OUTPUT_FORMAT.

        Args:
            raw: Raw command output

        Returns:
            Formatted output string
        """
        if not raw:
            return "(no output)"

        if self.OUTPUT_FORMAT == "json":
            data = parse_json_output(raw)
            return self._summarize_json(data)
        elif self.OUTPUT_FORMAT == "table":
            rows = parse_table_output(raw)
            return self._format_table(rows)
        else:
            return raw

    def _format_table(self, rows: list[dict]) -> str:
        """Format parsed table rows for display.

        Args:
            rows: List of row dictionaries

        Returns:
            Formatted table string
        """
        if not rows:
            return "(no data)"

        # Get all keys as headers
        headers = list(rows[0].keys())

        # Calculate column widths
        widths = {h: len(h) for h in headers}
        for row in rows:
            for h in headers:
                widths[h] = max(widths[h], len(str(row.get(h, ''))))

        # Build table
        lines = []
        header_line = '  '.join(h.upper().ljust(widths[h]) for h in headers)
        lines.append(header_line)
        lines.append('-' * len(header_line))

        for row in rows[:20]:  # Limit to 20 rows
            line = '  '.join(str(row.get(h, '')).ljust(widths[h]) for h in headers)
            lines.append(line)

        if len(rows) > 20:
            lines.append(f"... and {len(rows) - 20} more rows")

        return '\n'.join(lines)

    def _summarize_json(self, data: dict) -> str:
        """Summarize JSON data for display.

        Subclasses should override for domain-specific summarization.
        Default implementation provides basic summary.

        Args:
            data: Parsed JSON data

        Returns:
            Human-readable summary
        """
        if "error" in data:
            return f"Parse error: {data['error']}"

        if data.get("_empty"):
            return "(no data)"

        # Handle list items (common in kubectl, docker, aws)
        if "items" in data:
            items = data["items"]
            if not items:
                return "(no items found)"

            # Summarize first few items
            summaries = []
            for item in items[:10]:
                name = self._extract_name(item)
                status = self._extract_status(item)
                summaries.append(f"  - {name}: {status}")

            result = f"Found {len(items)} item(s):\n" + '\n'.join(summaries)
            if len(items) > 10:
                result += f"\n  ... and {len(items) - 10} more"
            return result

        # Generic dict summary
        return f"Response with {len(data)} fields: {', '.join(list(data.keys())[:5])}"

    def _extract_name(self, item: dict) -> str:
        """Extract name from an item dict.

        Args:
            item: Item dictionary

        Returns:
            Name string or "unknown"
        """
        # Common patterns
        if "metadata" in item and "name" in item["metadata"]:
            return item["metadata"]["name"]
        if "name" in item:
            return item["name"]
        if "Name" in item:
            return item["Name"]
        if "id" in item:
            return item["id"]
        return "unknown"

    def _extract_status(self, item: dict) -> str:
        """Extract status from an item dict.

        Args:
            item: Item dictionary

        Returns:
            Status string or "unknown"
        """
        # Common patterns
        if "status" in item:
            status = item["status"]
            if isinstance(status, dict):
                if "phase" in status:
                    return status["phase"]
                if "state" in status:
                    return status["state"]
            return str(status)
        if "Status" in item:
            return item["Status"]
        if "state" in item:
            return item["state"]
        return "unknown"

    def _get_system_prompt(self) -> str:
        """Get the system prompt for this agent.

        Subclasses MUST override this to provide domain-specific guidance.

        Returns:
            System prompt string
        """
        tools_desc = ', '.join(self.tools.keys())
        return f"""You are a {self.TOOL_NAME} investigation agent.

Available tools: {tools_desc}

Use the tools to investigate issues. Always explain what you find and suggest next steps."""

    def _mock_response(self, query: str) -> str:
        """Generate mock response for testing without actual CLI.

        Subclasses should override for domain-specific mock responses.

        Args:
            query: User query

        Returns:
            Mock response string
        """
        tool_name = self.TOOL_NAME
        return f"I'll investigate using {tool_name}. TOOL: {tool_name} status"

    def _mock_continuation(self, tool_output: str) -> str:
        """Generate mock continuation based on tool output.

        Subclasses should override for domain-specific continuations.

        Args:
            tool_output: Output from tool execution

        Returns:
            Mock continuation string
        """
        if "error" in tool_output.lower():
            return "I found an error. Let me investigate further."
        return "The output looks normal. Is there anything specific you'd like me to check?"
