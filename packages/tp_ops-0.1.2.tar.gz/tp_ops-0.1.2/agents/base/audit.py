"""AuditAgent base class for security and compliance agents.

Base class for 25 agents that audit configurations and policies:
- IAM policies, RBAC rules
- Security groups, firewall rules
- Compliance frameworks (CIS, SOC2, PCI)
- Configuration drift detection

Provides:
- Policy checking
- Compliance scoring
- Violation reporting
- Remediation suggestions
"""

import json
import subprocess
import re
from abc import abstractmethod
from typing import Any, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

from agents.base.conversational import ConversationalAgent, Tool, ActionType


class Severity(Enum):
    """Severity levels for violations."""
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ComplianceFramework(Enum):
    """Common compliance frameworks."""
    CIS = "CIS Benchmarks"
    SOC2 = "SOC 2"
    PCI_DSS = "PCI DSS"
    HIPAA = "HIPAA"
    GDPR = "GDPR"
    AWS_WELL_ARCHITECTED = "AWS Well-Architected"
    AZURE_SECURITY = "Azure Security Benchmark"
    GCP_CIS = "GCP CIS"


@dataclass
class PolicyRule:
    """A single policy rule to check."""

    id: str
    name: str
    description: str
    severity: Severity = Severity.MEDIUM
    framework: Optional[ComplianceFramework] = None
    check_fn: Optional[callable] = None  # Custom check function
    pattern: Optional[str] = None        # Regex pattern to match
    expected_value: Any = None           # Expected configuration value
    remediation: str = ""

    def __str__(self) -> str:
        return f"[{self.id}] {self.name} ({self.severity.value})"


@dataclass
class Violation:
    """A detected policy violation."""

    rule: PolicyRule
    resource: str
    actual_value: Any
    message: str
    timestamp: datetime = field(default_factory=datetime.now)

    def __str__(self) -> str:
        return f"[{self.rule.severity.value.upper()}] {self.rule.id}: {self.message}"


@dataclass
class ComplianceReport:
    """A compliance check report."""

    target: str
    framework: Optional[ComplianceFramework] = None
    violations: list[Violation] = field(default_factory=list)
    passed_rules: list[PolicyRule] = field(default_factory=list)
    skipped_rules: list[PolicyRule] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def total_rules(self) -> int:
        return len(self.violations) + len(self.passed_rules) + len(self.skipped_rules)

    @property
    def compliance_score(self) -> float:
        """Calculate compliance score as percentage."""
        if self.total_rules == 0:
            return 100.0
        passed = len(self.passed_rules)
        total = len(self.violations) + passed
        if total == 0:
            return 100.0
        return (passed / total) * 100

    @property
    def critical_violations(self) -> list[Violation]:
        return [v for v in self.violations if v.rule.severity == Severity.CRITICAL]

    @property
    def high_violations(self) -> list[Violation]:
        return [v for v in self.violations if v.rule.severity == Severity.HIGH]

    def __str__(self) -> str:
        lines = [
            f"Compliance Report for {self.target}",
            f"=" * 50,
            f"Score: {self.compliance_score:.1f}%",
            f"Rules checked: {self.total_rules}",
            f"Passed: {len(self.passed_rules)}",
            f"Failed: {len(self.violations)}",
            f"Skipped: {len(self.skipped_rules)}",
        ]

        if self.violations:
            lines.append("")
            lines.append("Violations:")
            by_severity = {}
            for v in self.violations:
                sev = v.rule.severity.value
                if sev not in by_severity:
                    by_severity[sev] = []
                by_severity[sev].append(v)

            for sev in ["critical", "high", "medium", "low", "info"]:
                if sev in by_severity:
                    lines.append(f"  {sev.upper()}: {len(by_severity[sev])}")
                    for v in by_severity[sev][:3]:
                        lines.append(f"    - {v.message}")
                    if len(by_severity[sev]) > 3:
                        lines.append(f"    ... and {len(by_severity[sev]) - 3} more")

        return "\n".join(lines)


# =============================================================================
# Common Policy Rules
# =============================================================================

# Generic security rules
GENERIC_SECURITY_RULES = [
    PolicyRule(
        id="SEC-001",
        name="No hardcoded credentials",
        description="Configuration should not contain hardcoded passwords or API keys",
        severity=Severity.CRITICAL,
        pattern=r"(?i)(password|secret|api_key|token)\s*[=:]\s*['\"][^'\"]{8,}['\"]",
        remediation="Use environment variables or a secrets manager instead of hardcoded values",
    ),
    PolicyRule(
        id="SEC-002",
        name="Encryption at rest",
        description="Data storage should be encrypted at rest",
        severity=Severity.HIGH,
        expected_value=True,
        remediation="Enable encryption for storage resources",
    ),
    PolicyRule(
        id="SEC-003",
        name="Encryption in transit",
        description="Network traffic should use TLS/SSL",
        severity=Severity.HIGH,
        expected_value=True,
        remediation="Enable TLS for all network connections",
    ),
    PolicyRule(
        id="SEC-004",
        name="No public access",
        description="Resources should not be publicly accessible unless required",
        severity=Severity.HIGH,
        expected_value=False,
        remediation="Restrict access to private networks or specific IPs",
    ),
]

# AWS IAM rules
AWS_IAM_RULES = [
    PolicyRule(
        id="IAM-001",
        name="No wildcard actions",
        description="IAM policies should not use Action: '*'",
        severity=Severity.HIGH,
        framework=ComplianceFramework.CIS,
        pattern=r'"Action"\s*:\s*"\*"',
        remediation="Replace wildcard actions with specific required actions",
    ),
    PolicyRule(
        id="IAM-002",
        name="No wildcard resources",
        description="IAM policies should not use Resource: '*' except for specific services",
        severity=Severity.MEDIUM,
        framework=ComplianceFramework.CIS,
        pattern=r'"Resource"\s*:\s*"\*"',
        remediation="Restrict resources to specific ARNs",
    ),
    PolicyRule(
        id="IAM-003",
        name="MFA required",
        description="IAM users should have MFA enabled",
        severity=Severity.HIGH,
        framework=ComplianceFramework.CIS,
        remediation="Enable MFA for all IAM users with console access",
    ),
    PolicyRule(
        id="IAM-004",
        name="Root account not used",
        description="Root account should not be used for daily operations",
        severity=Severity.CRITICAL,
        framework=ComplianceFramework.CIS,
        remediation="Create IAM users for daily tasks, reserve root for emergencies",
    ),
]

# Kubernetes RBAC rules
K8S_RBAC_RULES = [
    PolicyRule(
        id="K8S-001",
        name="No cluster-admin binding",
        description="Avoid binding cluster-admin role to users/groups",
        severity=Severity.HIGH,
        pattern=r"roleRef:\s*name:\s*cluster-admin",
        remediation="Create limited roles with specific permissions",
    ),
    PolicyRule(
        id="K8S-002",
        name="No wildcard verbs",
        description="RBAC rules should not use wildcard verbs",
        severity=Severity.MEDIUM,
        pattern=r"verbs:\s*\[.*\*.*\]",
        remediation="Specify explicit verbs needed",
    ),
    PolicyRule(
        id="K8S-003",
        name="Namespace-scoped roles preferred",
        description="Use Role instead of ClusterRole when possible",
        severity=Severity.LOW,
        remediation="Limit permissions to specific namespaces with Role",
    ),
]


class AuditAgent(ConversationalAgent):
    """Base class for security and compliance agents.

    Subclasses configure policies and config fetching:

    class IAMAuditAgent(AuditAgent):
        POLICIES = AWS_IAM_RULES
        TOOL_NAME = "iam"

        def _fetch_config(self, resource: str) -> dict:
            # Fetch IAM policy
    """

    # Subclasses must override these
    POLICIES: list[PolicyRule] = []
    TOOL_NAME: str = "audit"
    COMMAND_TIMEOUT: int = 60

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal,
        llm=None,
    ):
        """Initialize AuditAgent.

        Args:
            name: Agent name
            config: Configuration dict with:
                - target: What to audit
                - framework: Compliance framework
                - custom_rules: Additional rules
            terminal: Terminal for output
            llm: Optional LLM client
        """
        self.target = config.get("target", name)
        self.framework_name = config.get("framework")
        self.framework = None
        if self.framework_name:
            try:
                self.framework = ComplianceFramework(self.framework_name)
            except ValueError:
                pass

        # Merge custom rules
        custom_rules = config.get("custom_rules", [])
        self.all_rules = list(self.POLICIES) + custom_rules

        super().__init__(name, config, terminal, llm)

    def _register_tools(self) -> None:
        """Register audit tools."""
        # Full compliance check
        self.register_tool(
            name=f"{self.TOOL_NAME}_check",
            description=f"Run full compliance check. Usage: {self.TOOL_NAME}_check [resource]",
            execute=self._run_check,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Check specific rule
        self.register_tool(
            name=f"{self.TOOL_NAME}_rule",
            description=f"Check a specific rule. Usage: {self.TOOL_NAME}_rule <rule_id> [resource]",
            execute=self._run_rule,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # List rules
        self.register_tool(
            name=f"{self.TOOL_NAME}_rules",
            description=f"List available policy rules. Usage: {self.TOOL_NAME}_rules [severity]",
            execute=self._run_list_rules,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Fetch config
        self.register_tool(
            name=f"{self.TOOL_NAME}_config",
            description=f"Fetch configuration for a resource. Usage: {self.TOOL_NAME}_config <resource>",
            execute=self._run_fetch_config,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Get remediation
        self.register_tool(
            name=f"{self.TOOL_NAME}_remediate",
            description=f"Get remediation steps for a violation. Usage: {self.TOOL_NAME}_remediate <rule_id>",
            execute=self._run_remediate,
            requires_approval=False,
            action_type=ActionType.READ,
        )

    @abstractmethod
    def _fetch_config(self, resource: str) -> dict | str:
        """Fetch configuration for a resource. Subclasses must implement.

        Args:
            resource: Resource identifier

        Returns:
            Configuration dict or string
        """
        pass

    def _check_rule(
        self,
        rule: PolicyRule,
        config: dict | str,
        resource: str,
    ) -> Optional[Violation]:
        """Check a single rule against configuration.

        Args:
            rule: Policy rule to check
            config: Configuration to check
            resource: Resource identifier

        Returns:
            Violation if rule fails, None if passes
        """
        # Convert dict config to string for pattern matching
        config_str = json.dumps(config) if isinstance(config, dict) else str(config)

        # Check pattern match
        if rule.pattern:
            if re.search(rule.pattern, config_str, re.IGNORECASE | re.MULTILINE):
                return Violation(
                    rule=rule,
                    resource=resource,
                    actual_value=f"Pattern '{rule.pattern}' matched",
                    message=f"{rule.name} - Pattern found in {resource}",
                )

        # Check expected value
        if rule.expected_value is not None and isinstance(config, dict):
            # Try to find the relevant key
            for key, value in config.items():
                if key.lower() in rule.name.lower():
                    if value != rule.expected_value:
                        return Violation(
                            rule=rule,
                            resource=resource,
                            actual_value=value,
                            message=f"{rule.name} - Expected {rule.expected_value}, got {value}",
                        )

        # Custom check function
        if rule.check_fn:
            try:
                result = rule.check_fn(config, resource)
                if result:
                    return Violation(
                        rule=rule,
                        resource=resource,
                        actual_value=str(result),
                        message=f"{rule.name} - {result}",
                    )
            except Exception as e:
                return Violation(
                    rule=rule,
                    resource=resource,
                    actual_value=str(e),
                    message=f"{rule.name} - Check failed: {e}",
                )

        return None

    def _run_check(self, args: str = "") -> str:
        """Run full compliance check."""
        resource = args.strip() if args else self.target

        try:
            config = self._fetch_config(resource)
            self.bytes_processed += len(str(config))

            report = ComplianceReport(
                target=resource,
                framework=self.framework,
            )

            for rule in self.all_rules:
                # Skip rules from other frameworks if framework is specified
                if self.framework and rule.framework and rule.framework != self.framework:
                    report.skipped_rules.append(rule)
                    continue

                violation = self._check_rule(rule, config, resource)
                if violation:
                    report.violations.append(violation)
                else:
                    report.passed_rules.append(rule)

            return str(report)

        except Exception as e:
            return f"Error running compliance check: {e}"

    def _run_rule(self, args: str) -> str:
        """Check a specific rule."""
        parts = args.split()
        if not parts:
            return "Usage: rule <rule_id> [resource]"

        rule_id = parts[0]
        resource = parts[1] if len(parts) > 1 else self.target

        # Find rule
        rule = None
        for r in self.all_rules:
            if r.id.lower() == rule_id.lower():
                rule = r
                break

        if not rule:
            return f"Rule not found: {rule_id}"

        try:
            config = self._fetch_config(resource)
            self.bytes_processed += len(str(config))

            violation = self._check_rule(rule, config, resource)

            if violation:
                lines = [
                    f"❌ FAILED: {rule}",
                    f"",
                    f"Resource: {resource}",
                    f"Finding: {violation.message}",
                    f"",
                    f"Remediation:",
                    f"  {rule.remediation}",
                ]
            else:
                lines = [
                    f"✅ PASSED: {rule}",
                    f"",
                    f"Resource: {resource}",
                ]

            return "\n".join(lines)

        except Exception as e:
            return f"Error checking rule: {e}"

    def _run_list_rules(self, args: str = "") -> str:
        """List available policy rules."""
        severity_filter = args.strip().lower() if args else None

        lines = [f"Policy Rules ({len(self.all_rules)} total):", ""]

        by_severity = {}
        for rule in self.all_rules:
            sev = rule.severity.value
            if severity_filter and sev != severity_filter:
                continue
            if sev not in by_severity:
                by_severity[sev] = []
            by_severity[sev].append(rule)

        for sev in ["critical", "high", "medium", "low", "info"]:
            if sev in by_severity:
                lines.append(f"## {sev.upper()} ({len(by_severity[sev])})")
                for rule in by_severity[sev]:
                    framework = f" [{rule.framework.value}]" if rule.framework else ""
                    lines.append(f"  [{rule.id}] {rule.name}{framework}")
                lines.append("")

        if severity_filter and not any(by_severity.values()):
            return f"No rules found with severity: {severity_filter}"

        return "\n".join(lines)

    def _run_fetch_config(self, args: str) -> str:
        """Fetch configuration for a resource."""
        if not args:
            return "Usage: config <resource>"

        try:
            config = self._fetch_config(args.strip())
            self.bytes_processed += len(str(config))

            if isinstance(config, dict):
                return json.dumps(config, indent=2)
            return str(config)

        except Exception as e:
            return f"Error fetching config: {e}"

    def _run_remediate(self, args: str) -> str:
        """Get remediation steps for a rule."""
        if not args:
            return "Usage: remediate <rule_id>"

        rule_id = args.strip()

        # Find rule
        rule = None
        for r in self.all_rules:
            if r.id.lower() == rule_id.lower():
                rule = r
                break

        if not rule:
            return f"Rule not found: {rule_id}"

        lines = [
            f"Remediation for {rule}",
            "=" * 50,
            "",
            f"Description: {rule.description}",
            "",
            f"Steps:",
            f"  {rule.remediation}",
        ]

        if rule.framework:
            lines.append("")
            lines.append(f"Framework: {rule.framework.value}")

        return "\n".join(lines)

    @abstractmethod
    def _get_system_prompt(self) -> str:
        """Return system prompt. Subclasses must implement."""
        pass


class IAMAuditAgent(AuditAgent):
    """AuditAgent for AWS IAM policies."""

    POLICIES = AWS_IAM_RULES + GENERIC_SECURITY_RULES
    TOOL_NAME = "iam"

    def _fetch_config(self, resource: str) -> dict | str:
        """Fetch IAM policy or user configuration."""
        # Try to fetch as policy
        cmd = [
            "aws", "iam", "get-policy",
            "--policy-arn", resource,
            "--output", "json",
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )

            if result.returncode == 0:
                return json.loads(result.stdout)

            # Try as user
            cmd = ["aws", "iam", "get-user", "--user-name", resource, "--output", "json"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            if result.returncode == 0:
                return json.loads(result.stdout)

            return f"Could not fetch: {result.stderr}"

        except Exception as e:
            return f"Error: {e}"

    def _get_system_prompt(self) -> str:
        return f"""You are an AWS IAM audit agent for {self.name}.

Available tools:
- {self.TOOL_NAME}_check: Run full compliance check
- {self.TOOL_NAME}_rule: Check specific rule
- {self.TOOL_NAME}_rules: List policy rules
- {self.TOOL_NAME}_config: Fetch IAM configuration
- {self.TOOL_NAME}_remediate: Get remediation steps

Key IAM security principles:
1. Least privilege - only grant necessary permissions
2. No wildcards - avoid Action: '*' and Resource: '*'
3. Use roles instead of users for applications
4. Enable MFA for all console users
5. Rotate credentials regularly

Always explain findings and provide specific remediation steps."""


class K8sRBACAuditAgent(AuditAgent):
    """AuditAgent for Kubernetes RBAC."""

    POLICIES = K8S_RBAC_RULES + GENERIC_SECURITY_RULES
    TOOL_NAME = "rbac"

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace", "default")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _fetch_config(self, resource: str) -> dict | str:
        """Fetch Kubernetes RBAC configuration."""
        cmd = ["kubectl", "get", resource, "-o", "json"]

        if self.namespace and "namespace" not in resource.lower():
            cmd.extend(["-n", self.namespace])

        if self.kubeconfig:
            cmd.extend(["--kubeconfig", self.kubeconfig])

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )

            if result.returncode == 0:
                return json.loads(result.stdout)

            return f"Error: {result.stderr}"

        except Exception as e:
            return f"Error: {e}"

    def _get_system_prompt(self) -> str:
        return f"""You are a Kubernetes RBAC audit agent for {self.name}.

Namespace: {self.namespace}

Available tools:
- {self.TOOL_NAME}_check: Run full RBAC compliance check
- {self.TOOL_NAME}_rule: Check specific rule
- {self.TOOL_NAME}_rules: List policy rules
- {self.TOOL_NAME}_config: Fetch RBAC configuration
- {self.TOOL_NAME}_remediate: Get remediation steps

Key RBAC security principles:
1. Least privilege - only grant necessary permissions
2. Namespace-scoped roles preferred over ClusterRoles
3. Avoid binding cluster-admin to users
4. Use ServiceAccounts for workloads
5. Audit RoleBindings and ClusterRoleBindings regularly

Resource types to check:
- roles, clusterroles
- rolebindings, clusterrolebindings
- serviceaccounts

Always explain findings and provide kubectl commands for remediation."""
