"""StateAgent base class for metrics and state inspection agents.

Base class for 32 agents that work with metrics and state:
- Prometheus, CloudWatch, Datadog metrics
- Resource status and health checks
- Anomaly detection

Provides:
- Metric querying
- Baseline comparison
- Anomaly detection
- Period comparison
"""

import subprocess
import json
from abc import abstractmethod
from typing import Any, Optional
from datetime import datetime, timedelta

from agents.base.conversational import ConversationalAgent, Tool, ActionType
from agents.tools.metrics import (
    MetricType,
    MetricPoint,
    MetricSeries,
    Anomaly,
    Baseline,
    detect_spike,
    detect_dip,
    detect_threshold_breach,
    detect_trend,
    compare_periods,
    aggregate_series,
    format_metric_summary,
)


class StateAgent(ConversationalAgent):
    """Base class for state and metrics agents.

    Subclasses configure metric source and thresholds:

    class PrometheusAgent(StateAgent):
        METRIC_SOURCE = "prometheus"
        TOOL_NAME = "prom"

        def _fetch_metric(self, name: str, duration: str) -> MetricSeries:
            # Query Prometheus API
    """

    # Subclasses must override these
    METRIC_SOURCE: str = "prometheus"  # prometheus, cloudwatch, datadog
    TOOL_NAME: str = "metric"
    COMMAND_TIMEOUT: int = 30

    # Default thresholds (subclasses can override)
    DEFAULT_THRESHOLDS: dict[str, dict] = {
        "cpu_usage": {"warning": 80, "critical": 95},
        "memory_usage": {"warning": 85, "critical": 95},
        "disk_usage": {"warning": 80, "critical": 90},
        "error_rate": {"warning": 1, "critical": 5},
        "latency_p99": {"warning": 500, "critical": 1000},
    }

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal,
        llm=None,
    ):
        """Initialize StateAgent.

        Args:
            name: Agent name
            config: Configuration dict with:
                - endpoint: Metrics API endpoint
                - api_key: API key (if required)
                - namespace: Metric namespace
                - thresholds: Custom thresholds
            terminal: Terminal for output
            llm: Optional LLM client
        """
        self.endpoint = config.get("endpoint", "http://localhost:9090")
        self.api_key = config.get("api_key")
        self.namespace = config.get("namespace", "")
        self.thresholds = {**self.DEFAULT_THRESHOLDS, **config.get("thresholds", {})}

        # Cache for baselines
        self._baselines: dict[str, Baseline] = {}

        super().__init__(name, config, terminal, llm)

    def _register_tools(self) -> None:
        """Register state/metrics tools."""
        # Query metric
        self.register_tool(
            name=f"{self.TOOL_NAME}_query",
            description=f"Query a metric. Usage: {self.TOOL_NAME}_query <metric_name> [duration] (e.g., '15m', '1h', '24h')",
            execute=self._run_query,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Check health
        self.register_tool(
            name=f"{self.TOOL_NAME}_health",
            description=f"Check health of key metrics against thresholds. Usage: {self.TOOL_NAME}_health [metric_name]",
            execute=self._run_health,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Detect anomalies
        self.register_tool(
            name=f"{self.TOOL_NAME}_anomaly",
            description=f"Detect anomalies in a metric. Usage: {self.TOOL_NAME}_anomaly <metric_name> [sensitivity]",
            execute=self._run_anomaly,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Compare periods
        self.register_tool(
            name=f"{self.TOOL_NAME}_compare",
            description=f"Compare current period to previous. Usage: {self.TOOL_NAME}_compare <metric_name> [period]",
            execute=self._run_compare,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Get baseline
        self.register_tool(
            name=f"{self.TOOL_NAME}_baseline",
            description=f"Get or calculate baseline for a metric. Usage: {self.TOOL_NAME}_baseline <metric_name> [hours]",
            execute=self._run_baseline,
            requires_approval=False,
            action_type=ActionType.READ,
        )

    @abstractmethod
    def _fetch_metric(
        self,
        name: str,
        duration: str = "1h",
        step: str = "1m",
    ) -> MetricSeries:
        """Fetch metric from source. Subclasses must implement.

        Args:
            name: Metric name
            duration: Time range (e.g., '15m', '1h', '24h')
            step: Query resolution

        Returns:
            MetricSeries with data points
        """
        pass

    def _parse_duration(self, duration: str) -> timedelta:
        """Parse duration string to timedelta."""
        duration = duration.lower().strip()
        if duration.endswith('m'):
            return timedelta(minutes=int(duration[:-1]))
        elif duration.endswith('h'):
            return timedelta(hours=int(duration[:-1]))
        elif duration.endswith('d'):
            return timedelta(days=int(duration[:-1]))
        elif duration.endswith('w'):
            return timedelta(weeks=int(duration[:-1]))
        else:
            # Default to hours
            return timedelta(hours=int(duration))

    def _run_query(self, args: str) -> str:
        """Query a metric."""
        parts = args.split()
        if not parts:
            return "Usage: query <metric_name> [duration]"

        metric_name = parts[0]
        duration = parts[1] if len(parts) > 1 else "1h"

        try:
            series = self._fetch_metric(metric_name, duration)
            self.bytes_processed += len(str(series.points)) * 2

            return format_metric_summary(series)

        except Exception as e:
            return f"Error querying metric: {e}"

    def _run_health(self, args: str = "") -> str:
        """Check health against thresholds."""
        metric_name = args.strip() if args else None

        try:
            results = []
            metrics_to_check = (
                [metric_name] if metric_name
                else list(self.thresholds.keys())
            )

            for name in metrics_to_check:
                try:
                    series = self._fetch_metric(name, "5m")
                    self.bytes_processed += len(str(series.points))

                    if not series.points:
                        results.append(f"  ⚪ {name}: No data")
                        continue

                    current = series.latest
                    thresholds = self.thresholds.get(name, {})

                    anomaly = detect_threshold_breach(
                        current,
                        name,
                        warning_threshold=thresholds.get("warning"),
                        critical_threshold=thresholds.get("critical"),
                    )

                    if anomaly:
                        icon = "🔴" if anomaly.severity == "critical" else "🟡"
                        results.append(f"  {icon} {anomaly.message}")
                    else:
                        results.append(f"  🟢 {name}: {current:.2f} (OK)")

                except Exception as e:
                    results.append(f"  ⚪ {name}: Error - {e}")

            return "Health Check Results:\n" + "\n".join(results)

        except Exception as e:
            return f"Error checking health: {e}"

    def _run_anomaly(self, args: str) -> str:
        """Detect anomalies in a metric."""
        parts = args.split()
        if not parts:
            return "Usage: anomaly <metric_name> [sensitivity]"

        metric_name = parts[0]
        sensitivity = float(parts[1]) if len(parts) > 1 else 3.0

        try:
            # Get recent data
            series = self._fetch_metric(metric_name, "1h")
            self.bytes_processed += len(str(series.points))

            if not series.points:
                return f"No data for metric: {metric_name}"

            # Get or calculate baseline
            baseline = self._get_or_calculate_baseline(metric_name)

            # Check for various anomalies
            anomalies = []

            # Check spike/dip on latest value
            current = series.latest
            spike = detect_spike(current, baseline, sensitivity)
            if spike:
                anomalies.append(spike)

            dip = detect_dip(current, baseline, sensitivity)
            if dip:
                anomalies.append(dip)

            # Check for trend
            trend = detect_trend(series)
            if trend:
                anomalies.append(trend)

            if not anomalies:
                return f"No anomalies detected for {metric_name}\n\nCurrent: {current:.2f}\nBaseline: {baseline}"

            lines = [f"Anomalies detected for {metric_name}:\n"]
            for anomaly in anomalies:
                lines.append(f"  • {anomaly}")

            lines.append(f"\nBaseline: {baseline}")
            return "\n".join(lines)

        except Exception as e:
            return f"Error detecting anomalies: {e}"

    def _run_compare(self, args: str) -> str:
        """Compare current period to previous."""
        parts = args.split()
        if not parts:
            return "Usage: compare <metric_name> [period]"

        metric_name = parts[0]
        period = parts[1] if len(parts) > 1 else "1h"

        try:
            # Get current period
            current = self._fetch_metric(metric_name, period)
            self.bytes_processed += len(str(current.points))

            # Get previous period (same duration, offset back)
            duration = self._parse_duration(period)
            # For simplicity, we'll fetch double the duration and split
            previous = self._fetch_metric(metric_name, f"{int(duration.total_seconds() / 60) * 2}m")
            self.bytes_processed += len(str(previous.points))

            # Split into two halves
            if previous.points:
                mid = len(previous.points) // 2
                previous.points = previous.points[:mid]

            anomalies = compare_periods(current, previous)

            lines = [
                f"Period Comparison for {metric_name}:",
                f"",
                f"Current period ({period}):",
                f"  Mean: {current.mean():.2f}",
                f"  Max: {current.max():.2f}",
                f"  Min: {current.min():.2f}",
                f"",
                f"Previous period:",
                f"  Mean: {previous.mean():.2f}",
                f"  Max: {previous.max():.2f}",
                f"  Min: {previous.min():.2f}",
            ]

            if anomalies:
                lines.append("")
                lines.append("Changes detected:")
                for anomaly in anomalies:
                    lines.append(f"  • {anomaly.message}")

            return "\n".join(lines)

        except Exception as e:
            return f"Error comparing periods: {e}"

    def _run_baseline(self, args: str) -> str:
        """Get or calculate baseline for a metric."""
        parts = args.split()
        if not parts:
            return "Usage: baseline <metric_name> [hours]"

        metric_name = parts[0]
        hours = int(parts[1]) if len(parts) > 1 else 24

        try:
            # Force recalculate
            series = self._fetch_metric(metric_name, f"{hours}h")
            self.bytes_processed += len(str(series.points))

            if not series.points:
                return f"No data for metric: {metric_name}"

            baseline = Baseline.from_series(series, hours)
            self._baselines[metric_name] = baseline

            return f"Baseline calculated:\n{baseline}"

        except Exception as e:
            return f"Error calculating baseline: {e}"

    def _get_or_calculate_baseline(self, metric_name: str) -> Baseline:
        """Get cached baseline or calculate new one."""
        if metric_name in self._baselines:
            return self._baselines[metric_name]

        # Calculate from 24h of data
        series = self._fetch_metric(metric_name, "24h")
        baseline = Baseline.from_series(series, 24)
        self._baselines[metric_name] = baseline
        return baseline

    @abstractmethod
    def _get_system_prompt(self) -> str:
        """Return system prompt. Subclasses must implement."""
        pass


class PrometheusStateAgent(StateAgent):
    """StateAgent for Prometheus metrics."""

    METRIC_SOURCE = "prometheus"
    TOOL_NAME = "prom"

    def _fetch_metric(
        self,
        name: str,
        duration: str = "1h",
        step: str = "1m",
    ) -> MetricSeries:
        """Fetch metric from Prometheus."""
        import urllib.request
        import urllib.parse

        # Parse duration to seconds
        duration_td = self._parse_duration(duration)
        now = datetime.now()
        start = now - duration_td

        # Build query URL
        query = urllib.parse.quote(name)
        url = (
            f"{self.endpoint}/api/v1/query_range"
            f"?query={query}"
            f"&start={start.timestamp()}"
            f"&end={now.timestamp()}"
            f"&step={step}"
        )

        try:
            req = urllib.request.Request(url)
            if self.api_key:
                req.add_header("Authorization", f"Bearer {self.api_key}")

            with urllib.request.urlopen(req, timeout=self.COMMAND_TIMEOUT) as resp:
                data = json.loads(resp.read().decode())

            if data.get("status") != "success":
                return MetricSeries(name=name)

            results = data.get("data", {}).get("result", [])
            if not results:
                return MetricSeries(name=name)

            # Take first result
            result = results[0]
            values = result.get("values", [])

            points = []
            for ts, val in values:
                points.append(MetricPoint(
                    timestamp=datetime.fromtimestamp(ts),
                    value=float(val),
                ))

            return MetricSeries(
                name=name,
                points=points,
                labels=result.get("metric", {}),
            )

        except Exception as e:
            # Return empty series on error
            return MetricSeries(name=name)

    def _get_system_prompt(self) -> str:
        return f"""You are a Prometheus metrics agent for {self.name}.

Endpoint: {self.endpoint}

Available tools:
- {self.TOOL_NAME}_query: Query a metric with duration
- {self.TOOL_NAME}_health: Check metrics against thresholds
- {self.TOOL_NAME}_anomaly: Detect anomalies
- {self.TOOL_NAME}_compare: Compare current to previous period
- {self.TOOL_NAME}_baseline: Calculate baseline statistics

Investigation approach:
1. Start with health check for overview
2. Query specific metrics showing issues
3. Detect anomalies with statistical analysis
4. Compare to historical periods
5. Calculate baselines for ongoing monitoring

Common metrics:
- CPU: node_cpu_seconds_total, container_cpu_usage_seconds_total
- Memory: node_memory_MemAvailable_bytes, container_memory_usage_bytes
- Disk: node_filesystem_avail_bytes
- Network: node_network_receive_bytes_total
- HTTP: http_requests_total, http_request_duration_seconds

Always explain findings and suggest next steps."""


class CloudWatchStateAgent(StateAgent):
    """StateAgent for AWS CloudWatch metrics."""

    METRIC_SOURCE = "cloudwatch"
    TOOL_NAME = "cw"

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _fetch_metric(
        self,
        name: str,
        duration: str = "1h",
        step: str = "1m",
    ) -> MetricSeries:
        """Fetch metric from CloudWatch via AWS CLI."""
        duration_td = self._parse_duration(duration)
        now = datetime.now()
        start = now - duration_td

        # Parse step to period in seconds
        step_td = self._parse_duration(step)
        period = int(step_td.total_seconds())

        # Build AWS CLI command
        cmd = [
            "aws", "cloudwatch", "get-metric-statistics",
            "--region", self.region,
            "--namespace", self.namespace or "AWS/EC2",
            "--metric-name", name,
            "--start-time", start.isoformat(),
            "--end-time", now.isoformat(),
            "--period", str(period),
            "--statistics", "Average",
            "--output", "json",
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )

            if result.returncode != 0:
                return MetricSeries(name=name)

            data = json.loads(result.stdout)
            datapoints = data.get("Datapoints", [])

            points = []
            for dp in sorted(datapoints, key=lambda x: x["Timestamp"]):
                ts = datetime.fromisoformat(dp["Timestamp"].replace("Z", "+00:00"))
                points.append(MetricPoint(
                    timestamp=ts,
                    value=dp.get("Average", 0),
                ))

            return MetricSeries(name=name, points=points)

        except Exception:
            return MetricSeries(name=name)

    def _get_system_prompt(self) -> str:
        return f"""You are a CloudWatch metrics agent for {self.name} in {self.region}.

Available tools:
- {self.TOOL_NAME}_query: Query a metric with duration
- {self.TOOL_NAME}_health: Check metrics against thresholds
- {self.TOOL_NAME}_anomaly: Detect anomalies
- {self.TOOL_NAME}_compare: Compare current to previous period
- {self.TOOL_NAME}_baseline: Calculate baseline statistics

Common CloudWatch metrics:
- EC2: CPUUtilization, NetworkIn, NetworkOut, DiskReadOps
- RDS: CPUUtilization, DatabaseConnections, FreeStorageSpace
- ELB: RequestCount, TargetResponseTime, HealthyHostCount
- Lambda: Invocations, Duration, Errors, Throttles

Always explain findings and suggest AWS-specific remediation."""
