"""Base agent class for TernaryPhysics Ops agents."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from cli.output.terminal import Terminal
from agents.base.meter import Meter


@dataclass
class InvestigationResult:
    """Result of an investigation."""
    root_cause: str | None = None
    evidence: list[str] = field(default_factory=list)
    recommendations: list[dict[str, Any]] = field(default_factory=list)
    steps: list[dict[str, Any]] = field(default_factory=list)
    gb_processed: float = 0.0
    cost: float = 0.0


@dataclass
class ScanResult:
    """Result of a proactive scan."""
    findings: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    healthy: bool = True
    gb_processed: float = 0.0
    cost: float = 0.0


class BaseAgent(ABC):
    """Base class for all TernaryPhysics Ops agents.

    Each agent is dropped onto a specific resource and can:
    - Investigate problems (reactive)
    - Scan for issues (proactive)
    - Learn baseline patterns (via TNN)
    - Execute approved actions
    """

    # Cost per GB processed
    COST_PER_GB = 0.50

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal: Terminal,
    ):
        self.name = name
        self.config = config
        self.terminal = terminal
        self.meter = Meter()

    @property
    @abstractmethod
    def agent_type(self) -> str:
        """Return the agent type identifier."""
        pass

    @abstractmethod
    def investigate(self, problem: str) -> dict[str, Any]:
        """Investigate a reported problem.

        Args:
            problem: Description of the problem to investigate

        Returns:
            Investigation result with root cause, evidence, and recommendations
        """
        pass

    @abstractmethod
    def scan(self, deep: bool = False) -> dict[str, Any]:
        """Run a proactive scan for potential issues.

        Args:
            deep: Whether to run a deep scan (more thorough)

        Returns:
            Scan result with findings and warnings
        """
        pass

    def _track_data(self, data: str | bytes) -> int:
        """Track data processed for metering.

        Args:
            data: Data that was processed

        Returns:
            Number of bytes tracked
        """
        if isinstance(data, str):
            size = len(data.encode('utf-8'))
        else:
            size = len(data)

        self.meter.add_bytes(size)
        return size

    def _get_cost(self) -> float:
        """Get the current cost based on GB processed."""
        return self.meter.get_gb() * self.COST_PER_GB

    def _finalize_result(self, result: dict[str, Any]) -> dict[str, Any]:
        """Add metering info to result."""
        result["gb_processed"] = self.meter.get_gb()
        result["cost"] = self._get_cost()
        return result

    def _display_meter(self) -> None:
        """Display metering information."""
        self.terminal.meter(self.meter.get_gb(), self._get_cost())


class ReasoningPrinciples:
    """The five reasoning principles for investigation.

    1. OBSERVE: What is the current state?
    2. BASELINE: What does normal look like for THIS resource?
    3. DELTA: What changed recently (1h vs 23h)?
    4. CAUSAL CHAIN: Trace from change to symptom
    5. EVIDENCE GATE: Verify every link with specific data
    """

    @staticmethod
    def observe(terminal: Terminal, step: int, total: int, action: str) -> None:
        """Log an observation step."""
        terminal.step(step, total, action)

    @staticmethod
    def evidence(items: list[str], terminal: Terminal) -> None:
        """Display evidence list."""
        terminal.evidence(items)

    @staticmethod
    def root_cause(message: str, terminal: Terminal) -> None:
        """Display root cause finding."""
        terminal.root_cause(message)

    @staticmethod
    def recommend(
        terminal: Terminal,
        number: int,
        description: str,
        command: str | None = None,
        resource: str | None = None,
    ) -> None:
        """Display a recommendation."""
        terminal.recommendation(number, description, command)
        if command and resource:
            terminal.action_buttons(resource, number)
