"""StreamAgent base class for message queue and streaming agents.

Base class for 15 agents that work with message queues and streams:
- Kafka, SQS, RabbitMQ
- EventBridge, Kinesis, Pub/Sub
- Dead letter queue analysis

Provides:
- Queue/topic statistics
- Consumer lag monitoring
- Dead letter queue analysis
- Throughput metrics
"""

import subprocess
import json
from abc import abstractmethod
from typing import Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from agents.base.conversational import ConversationalAgent, Tool, ActionType


class QueueType(Enum):
    """Types of message queues."""
    KAFKA = "kafka"
    SQS = "sqs"
    RABBITMQ = "rabbitmq"
    KINESIS = "kinesis"
    PUBSUB = "pubsub"
    EVENTBRIDGE = "eventbridge"


@dataclass
class PartitionInfo:
    """Information about a topic partition."""

    partition: int
    leader: str = ""
    replicas: list[str] = field(default_factory=list)
    in_sync_replicas: list[str] = field(default_factory=list)
    offset_start: int = 0
    offset_end: int = 0

    @property
    def messages(self) -> int:
        return self.offset_end - self.offset_start


@dataclass
class ConsumerGroupInfo:
    """Information about a consumer group."""

    group_id: str
    state: str = "unknown"
    members: int = 0
    topics: list[str] = field(default_factory=list)
    lag_by_partition: dict[str, int] = field(default_factory=dict)

    @property
    def total_lag(self) -> int:
        return sum(self.lag_by_partition.values())

    def __str__(self) -> str:
        return f"{self.group_id}: {self.members} members, lag={self.total_lag}"


@dataclass
class QueueStats:
    """Statistics for a queue or topic."""

    name: str
    queue_type: QueueType
    messages_available: int = 0
    messages_in_flight: int = 0
    messages_delayed: int = 0
    dlq_messages: int = 0
    partitions: int = 0
    consumers: int = 0
    producers: int = 0
    throughput_in: float = 0.0  # messages/sec
    throughput_out: float = 0.0
    avg_message_size: int = 0
    retention_hours: int = 0
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def total_messages(self) -> int:
        return self.messages_available + self.messages_in_flight + self.messages_delayed

    def __str__(self) -> str:
        lines = [
            f"Queue: {self.name} ({self.queue_type.value})",
            f"  Messages: {self.messages_available} available, {self.messages_in_flight} in-flight",
            f"  Consumers: {self.consumers}",
            f"  Throughput: {self.throughput_in:.1f} in / {self.throughput_out:.1f} out msg/s",
        ]
        if self.dlq_messages > 0:
            lines.append(f"  ⚠️ DLQ: {self.dlq_messages} messages")
        return "\n".join(lines)


@dataclass
class LagReport:
    """Consumer lag report."""

    consumer_group: str
    topic: str
    total_lag: int = 0
    lag_by_partition: dict[int, int] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def is_healthy(self) -> bool:
        return self.total_lag < 1000

    def __str__(self) -> str:
        status = "🟢" if self.is_healthy else "🔴"
        lines = [
            f"{status} {self.consumer_group} on {self.topic}",
            f"  Total lag: {self.total_lag:,} messages",
        ]
        if self.lag_by_partition:
            max_lag_partition = max(self.lag_by_partition.items(), key=lambda x: x[1])
            lines.append(f"  Max lag: partition {max_lag_partition[0]} ({max_lag_partition[1]:,})")
        return "\n".join(lines)


class StreamAgent(ConversationalAgent):
    """Base class for message queue and streaming agents.

    Subclasses configure queue type and connection:

    class KafkaAgent(StreamAgent):
        QUEUE_TYPE = QueueType.KAFKA
        TOOL_NAME = "kafka"

        def _fetch_queue_stats(self, topic: str) -> QueueStats:
            # Query Kafka
    """

    # Subclasses must override these
    QUEUE_TYPE: QueueType = QueueType.KAFKA
    TOOL_NAME: str = "queue"
    COMMAND_TIMEOUT: int = 30

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal,
        llm=None,
    ):
        """Initialize StreamAgent.

        Args:
            name: Agent name
            config: Configuration dict with:
                - brokers: Broker addresses (Kafka)
                - queue_url: Queue URL (SQS)
                - host: RabbitMQ host
                - vhost: RabbitMQ virtual host
            terminal: Terminal for output
            llm: Optional LLM client
        """
        self.brokers = config.get("brokers", "localhost:9092")
        self.queue_url = config.get("queue_url", "")
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 5672)
        self.vhost = config.get("vhost", "/")
        self.region = config.get("region", "us-east-1")

        super().__init__(name, config, terminal, llm)

    def _register_tools(self) -> None:
        """Register streaming tools."""
        # Queue stats
        self.register_tool(
            name=f"{self.TOOL_NAME}_stats",
            description=f"Get queue/topic statistics. Usage: {self.TOOL_NAME}_stats <queue_or_topic>",
            execute=self._run_stats,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Consumer lag
        self.register_tool(
            name=f"{self.TOOL_NAME}_lag",
            description=f"Check consumer lag. Usage: {self.TOOL_NAME}_lag <consumer_group> [topic]",
            execute=self._run_lag,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # List queues/topics
        self.register_tool(
            name=f"{self.TOOL_NAME}_list",
            description=f"List queues or topics. Usage: {self.TOOL_NAME}_list [pattern]",
            execute=self._run_list,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # DLQ status
        self.register_tool(
            name=f"{self.TOOL_NAME}_dlq",
            description=f"Check dead letter queue status. Usage: {self.TOOL_NAME}_dlq [queue_name]",
            execute=self._run_dlq,
            requires_approval=False,
            action_type=ActionType.READ,
        )

        # Consumer groups
        self.register_tool(
            name=f"{self.TOOL_NAME}_consumers",
            description=f"List consumer groups. Usage: {self.TOOL_NAME}_consumers [topic]",
            execute=self._run_consumers,
            requires_approval=False,
            action_type=ActionType.READ,
        )

    @abstractmethod
    def _fetch_queue_stats(self, queue_name: str) -> QueueStats:
        """Fetch queue/topic statistics. Subclasses must implement."""
        pass

    @abstractmethod
    def _fetch_consumer_lag(
        self,
        consumer_group: str,
        topic: Optional[str] = None,
    ) -> LagReport:
        """Fetch consumer lag. Subclasses must implement."""
        pass

    @abstractmethod
    def _fetch_queue_list(self, pattern: Optional[str] = None) -> list[str]:
        """Fetch list of queues/topics. Subclasses must implement."""
        pass

    @abstractmethod
    def _fetch_consumer_groups(self, topic: Optional[str] = None) -> list[ConsumerGroupInfo]:
        """Fetch consumer groups. Subclasses must implement."""
        pass

    def _run_stats(self, args: str) -> str:
        """Get queue/topic statistics."""
        if not args:
            return "Usage: stats <queue_or_topic>"

        queue_name = args.strip()

        try:
            stats = self._fetch_queue_stats(queue_name)
            self.bytes_processed += 1000  # Estimate

            return str(stats)

        except Exception as e:
            return f"Error fetching stats: {e}"

    def _run_lag(self, args: str) -> str:
        """Check consumer lag."""
        parts = args.split()
        if not parts:
            return "Usage: lag <consumer_group> [topic]"

        consumer_group = parts[0]
        topic = parts[1] if len(parts) > 1 else None

        try:
            report = self._fetch_consumer_lag(consumer_group, topic)
            self.bytes_processed += 500

            return str(report)

        except Exception as e:
            return f"Error fetching lag: {e}"

    def _run_list(self, args: str = "") -> str:
        """List queues/topics."""
        pattern = args.strip() if args else None

        try:
            queues = self._fetch_queue_list(pattern)
            self.bytes_processed += len(queues) * 50

            if not queues:
                return "No queues/topics found"

            lines = [f"Found {len(queues)} queues/topics:", ""]
            for q in queues[:50]:
                lines.append(f"  • {q}")
            if len(queues) > 50:
                lines.append(f"  ... and {len(queues) - 50} more")

            return "\n".join(lines)

        except Exception as e:
            return f"Error listing queues: {e}"

    def _run_dlq(self, args: str = "") -> str:
        """Check dead letter queue status."""
        queue_name = args.strip() if args else None

        try:
            # DLQ is often named with -dlq or -deadletter suffix
            if queue_name:
                dlq_name = queue_name
            else:
                # List all DLQs
                all_queues = self._fetch_queue_list()
                dlq_queues = [q for q in all_queues if 'dlq' in q.lower() or 'deadletter' in q.lower()]

                if not dlq_queues:
                    return "No dead letter queues found"

                lines = [f"Found {len(dlq_queues)} dead letter queues:", ""]
                for dlq in dlq_queues:
                    try:
                        stats = self._fetch_queue_stats(dlq)
                        icon = "⚠️" if stats.messages_available > 0 else "✅"
                        lines.append(f"  {icon} {dlq}: {stats.messages_available} messages")
                    except Exception:
                        lines.append(f"  ⚪ {dlq}: Unable to fetch")

                return "\n".join(lines)

            stats = self._fetch_queue_stats(dlq_name)
            self.bytes_processed += 500

            if stats.messages_available > 0:
                return f"⚠️ DLQ Alert: {dlq_name} has {stats.messages_available} messages"
            return f"✅ DLQ OK: {dlq_name} is empty"

        except Exception as e:
            return f"Error checking DLQ: {e}"

    def _run_consumers(self, args: str = "") -> str:
        """List consumer groups."""
        topic = args.strip() if args else None

        try:
            groups = self._fetch_consumer_groups(topic)
            self.bytes_processed += len(groups) * 100

            if not groups:
                return "No consumer groups found"

            lines = [f"Found {len(groups)} consumer groups:", ""]
            for group in groups:
                lag_icon = "🟢" if group.total_lag < 1000 else "🔴" if group.total_lag > 10000 else "🟡"
                lines.append(f"  {lag_icon} {group.group_id}")
                lines.append(f"      State: {group.state}, Members: {group.members}, Lag: {group.total_lag:,}")

            return "\n".join(lines)

        except Exception as e:
            return f"Error listing consumers: {e}"

    @abstractmethod
    def _get_system_prompt(self) -> str:
        """Return system prompt. Subclasses must implement."""
        pass


class KafkaStreamAgent(StreamAgent):
    """StreamAgent for Apache Kafka."""

    QUEUE_TYPE = QueueType.KAFKA
    TOOL_NAME = "kafka"

    def _run_kafka_cmd(self, cmd: list[str]) -> str:
        """Run a kafka command."""
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )
            return result.stdout or result.stderr
        except Exception as e:
            return str(e)

    def _fetch_queue_stats(self, topic: str) -> QueueStats:
        """Fetch Kafka topic statistics."""
        # Use kafka-topics to describe topic
        output = self._run_kafka_cmd([
            "kafka-topics", "--describe",
            "--bootstrap-server", self.brokers,
            "--topic", topic,
        ])

        # Parse partition count from output
        partitions = 0
        if "PartitionCount:" in output:
            try:
                partitions = int(output.split("PartitionCount:")[1].split()[0])
            except (IndexError, ValueError):
                pass

        return QueueStats(
            name=topic,
            queue_type=self.QUEUE_TYPE,
            partitions=partitions,
        )

    def _fetch_consumer_lag(
        self,
        consumer_group: str,
        topic: Optional[str] = None,
    ) -> LagReport:
        """Fetch Kafka consumer group lag."""
        cmd = [
            "kafka-consumer-groups", "--describe",
            "--bootstrap-server", self.brokers,
            "--group", consumer_group,
        ]

        output = self._run_kafka_cmd(cmd)

        # Parse lag from output
        total_lag = 0
        lag_by_partition = {}
        topic_name = topic or "unknown"

        for line in output.split("\n"):
            if line.strip() and not line.startswith("GROUP"):
                parts = line.split()
                if len(parts) >= 6:
                    try:
                        topic_name = parts[1]
                        partition = int(parts[2])
                        lag = int(parts[5]) if parts[5] != "-" else 0
                        lag_by_partition[partition] = lag
                        total_lag += lag
                    except (ValueError, IndexError):
                        pass

        return LagReport(
            consumer_group=consumer_group,
            topic=topic_name,
            total_lag=total_lag,
            lag_by_partition=lag_by_partition,
        )

    def _fetch_queue_list(self, pattern: Optional[str] = None) -> list[str]:
        """Fetch list of Kafka topics."""
        output = self._run_kafka_cmd([
            "kafka-topics", "--list",
            "--bootstrap-server", self.brokers,
        ])

        topics = [t.strip() for t in output.split("\n") if t.strip()]

        if pattern:
            import re
            try:
                regex = re.compile(pattern, re.IGNORECASE)
                topics = [t for t in topics if regex.search(t)]
            except re.error:
                topics = [t for t in topics if pattern.lower() in t.lower()]

        return topics

    def _fetch_consumer_groups(self, topic: Optional[str] = None) -> list[ConsumerGroupInfo]:
        """Fetch Kafka consumer groups."""
        output = self._run_kafka_cmd([
            "kafka-consumer-groups", "--list",
            "--bootstrap-server", self.brokers,
        ])

        groups = []
        for group_id in output.split("\n"):
            group_id = group_id.strip()
            if not group_id:
                continue

            # Get lag for this group
            lag_report = self._fetch_consumer_lag(group_id, topic)

            groups.append(ConsumerGroupInfo(
                group_id=group_id,
                topics=[lag_report.topic] if lag_report.topic != "unknown" else [],
                lag_by_partition={str(k): v for k, v in lag_report.lag_by_partition.items()},
            ))

        return groups

    def _get_system_prompt(self) -> str:
        return f"""You are a Kafka streaming agent for {self.name}.

Brokers: {self.brokers}

Available tools:
- {self.TOOL_NAME}_stats: Get topic statistics
- {self.TOOL_NAME}_lag: Check consumer group lag
- {self.TOOL_NAME}_list: List topics
- {self.TOOL_NAME}_dlq: Check dead letter queues
- {self.TOOL_NAME}_consumers: List consumer groups

Investigation approach:
1. List topics to understand the landscape
2. Check consumer lag for processing issues
3. Look for DLQ accumulation
4. Analyze partition distribution

Common issues:
- **Consumer lag**: Processing slower than production rate
- **Rebalancing**: Consumer group instability
- **Partition skew**: Uneven message distribution
- **DLQ buildup**: Failed message handling

Always explain findings and suggest Kafka-specific remediation."""


class SQSStreamAgent(StreamAgent):
    """StreamAgent for AWS SQS."""

    QUEUE_TYPE = QueueType.SQS
    TOOL_NAME = "sqs"

    def _run_aws_cmd(self, cmd: list[str]) -> str:
        """Run an AWS CLI command."""
        try:
            result = subprocess.run(
                ["aws", "--region", self.region] + cmd,
                capture_output=True,
                text=True,
                timeout=self.COMMAND_TIMEOUT,
            )
            return result.stdout or result.stderr
        except Exception as e:
            return str(e)

    def _fetch_queue_stats(self, queue_name: str) -> QueueStats:
        """Fetch SQS queue statistics."""
        # Get queue URL if name given
        if not queue_name.startswith("https://"):
            output = self._run_aws_cmd([
                "sqs", "get-queue-url",
                "--queue-name", queue_name,
                "--output", "json",
            ])
            try:
                data = json.loads(output)
                queue_url = data["QueueUrl"]
            except (json.JSONDecodeError, KeyError):
                queue_url = queue_name
        else:
            queue_url = queue_name

        # Get queue attributes
        output = self._run_aws_cmd([
            "sqs", "get-queue-attributes",
            "--queue-url", queue_url,
            "--attribute-names", "All",
            "--output", "json",
        ])

        try:
            data = json.loads(output)
            attrs = data.get("Attributes", {})

            return QueueStats(
                name=queue_name,
                queue_type=self.QUEUE_TYPE,
                messages_available=int(attrs.get("ApproximateNumberOfMessages", 0)),
                messages_in_flight=int(attrs.get("ApproximateNumberOfMessagesNotVisible", 0)),
                messages_delayed=int(attrs.get("ApproximateNumberOfMessagesDelayed", 0)),
            )
        except (json.JSONDecodeError, KeyError):
            return QueueStats(name=queue_name, queue_type=self.QUEUE_TYPE)

    def _fetch_consumer_lag(
        self,
        consumer_group: str,
        topic: Optional[str] = None,
    ) -> LagReport:
        """SQS doesn't have consumer groups, return queue depth instead."""
        queue_name = consumer_group  # Use consumer_group as queue name
        stats = self._fetch_queue_stats(queue_name)

        return LagReport(
            consumer_group=consumer_group,
            topic=queue_name,
            total_lag=stats.messages_available,
        )

    def _fetch_queue_list(self, pattern: Optional[str] = None) -> list[str]:
        """Fetch list of SQS queues."""
        cmd = ["sqs", "list-queues", "--output", "json"]
        if pattern:
            cmd.extend(["--queue-name-prefix", pattern])

        output = self._run_aws_cmd(cmd)

        try:
            data = json.loads(output)
            urls = data.get("QueueUrls", [])
            # Extract queue names from URLs
            names = [url.split("/")[-1] for url in urls]
            return names
        except (json.JSONDecodeError, KeyError):
            return []

    def _fetch_consumer_groups(self, topic: Optional[str] = None) -> list[ConsumerGroupInfo]:
        """SQS doesn't have consumer groups, return queue info instead."""
        queues = self._fetch_queue_list()
        groups = []

        for queue_name in queues:
            stats = self._fetch_queue_stats(queue_name)
            groups.append(ConsumerGroupInfo(
                group_id=queue_name,
                state="active",
                topics=[queue_name],
                lag_by_partition={"0": stats.messages_available},
            ))

        return groups

    def _get_system_prompt(self) -> str:
        return f"""You are an AWS SQS streaming agent for {self.name}.

Region: {self.region}

Available tools:
- {self.TOOL_NAME}_stats: Get queue statistics
- {self.TOOL_NAME}_lag: Check queue depth (messages available)
- {self.TOOL_NAME}_list: List queues
- {self.TOOL_NAME}_dlq: Check dead letter queues
- {self.TOOL_NAME}_consumers: List queues as "consumer groups"

SQS concepts:
- Messages visible = available to receive
- Messages not visible = in-flight (being processed)
- Messages delayed = waiting for delay period

Investigation approach:
1. List queues and check depths
2. Look for DLQ accumulation
3. Check in-flight vs available ratio
4. Monitor delay queue buildup

Common issues:
- **Queue backup**: Processing can't keep up
- **DLQ overflow**: Too many failed messages
- **Visibility timeout**: Messages returning before processing
- **Message retention**: Messages expiring unprocessed

Always explain findings and suggest AWS-specific remediation."""
