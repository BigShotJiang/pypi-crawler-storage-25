"""Kubernetes Security Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class K8sSecurityAgent(ShellAgent):
    """Agent for Kubernetes security investigation."""

    COMMAND_PREFIX = ["kubectl"]
    TOOL_NAME = "kubectl"
    OUTPUT_FORMAT = "yaml"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "get networkpolicies", "get podsecuritypolicies", "get rolebindings",
        "get clusterrolebindings", "get serviceaccounts", "get secrets",
        "auth can-i", "describe", "get pods -o yaml",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete", "apply", "patch", "create",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cluster = config.get("cluster")
        self.namespace = config.get("namespace", "default")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["kubectl"]
        if self.kubeconfig:
            prefix.extend(["--kubeconfig", self.kubeconfig])
        return prefix

    def _get_system_prompt(self) -> str:
        cluster = self.cluster or "unknown"
        return f"""You are a Kubernetes Security investigation agent for cluster '{cluster}'.

Namespace: {self.namespace}

Available tools:
- kubectl: Execute read-only kubectl commands
- kubectl_write: Execute write commands (requires approval)
- kube-bench: Run CIS Kubernetes benchmark

Investigation approach:
1. RBAC Audit: kubectl get clusterrolebindings,rolebindings -A
2. Network Policies: kubectl get networkpolicies -A
3. Pod Security: kubectl get pods -o yaml | grep -E 'privileged|hostNetwork|hostPID'
4. Secrets: kubectl get secrets -A (check for default tokens)
5. Service Accounts: kubectl get sa -A
6. PSP/PSS: kubectl get podsecuritypolicies

Security checks:
- Privileged containers: Pods running as privileged
- Host namespaces: hostNetwork, hostPID, hostIPC
- Root users: Containers running as UID 0
- Missing network policies: Namespaces without policies
- Overprivileged RBAC: cluster-admin bindings
- Default service accounts: Pods using default SA
- Exposed secrets: Secrets mounted unnecessarily

Common issues:
- Overprivileged: cluster-admin given too broadly
- No network segmentation: Missing NetworkPolicies
- Privileged pods: Security contexts not enforced
- Secret exposure: Secrets in env vars instead of volumes"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        ns = self.namespace
        if "rbac" in q or "role" in q or "permission" in q:
            return "I'll audit RBAC bindings.\n\nTOOL: kubectl get clusterrolebindings -o wide"
        if "network" in q or "policy" in q:
            return f"I'll check network policies.\n\nTOOL: kubectl get networkpolicies -n {ns}"
        if "privileged" in q or "security context" in q:
            return f"I'll check for privileged pods.\n\nTOOL: kubectl get pods -n {ns} -o jsonpath='{{range .items[*]}}{{.metadata.name}}: {{range .spec.containers[*]}}{{.securityContext.privileged}}{{end}}{{\"\\n\"}}{{end}}'"
        if "secret" in q:
            return f"I'll list secrets.\n\nTOOL: kubectl get secrets -n {ns}"
        if "benchmark" in q or "cis" in q:
            return "I'll run kube-bench.\n\nTOOL: kube-bench run --targets node,master"
        return "I'll perform a security overview.\n\nTOOL: kubectl get clusterrolebindings,networkpolicies -A"
