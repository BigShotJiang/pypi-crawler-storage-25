"""SIEM Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SIEMAgent(ShellAgent):
    """Agent for SIEM (Security Information and Event Management) investigation."""

    COMMAND_PREFIX = ["az", "sentinel"]
    TOOL_NAME = "siem"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "incident list", "incident show", "alert-rule list",
        "data-connector list", "watchlist list", "threat-indicator list",
        "hunting query list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "incident update", "incident delete", "alert-rule create",
        "alert-rule delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.siem_type = config.get("siem_type", "sentinel")  # sentinel, splunk, qradar
        self.workspace = config.get("workspace")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        siem = self.siem_type.title()
        return f"""You are a SIEM investigation agent for {siem}.

Workspace: {self.workspace or 'default'}
Resource Group: {self.resource_group or 'default'}

Available tools:
- siem: Execute read-only SIEM queries
- siem_write: Execute write operations (requires approval)

Investigation approach for Azure Sentinel:
1. Incidents: az sentinel incident list
2. Incident Details: az sentinel incident show
3. Alert Rules: az sentinel alert-rule list
4. Data Connectors: az sentinel data-connector list
5. Hunting Queries: az sentinel hunting query list
6. Threat Intelligence: az sentinel threat-indicator list

For Splunk:
1. Search: splunk search "index=main error"
2. Alerts: splunk list alerts
3. Dashboards: splunk list dashboards
4. Saved searches: splunk list saved-searches

Incident triage:
- Severity: High, Medium, Low, Informational
- Status: New, Active, Closed
- Owner: Assigned analyst
- Entities: Users, IPs, hosts involved

Common issues:
- Alert fatigue: Too many false positives
- Data ingestion: Missing log sources
- Rule tuning: Thresholds too sensitive
- Correlation gaps: Missing detection rules
- Response time: Slow incident response
- Threat intel: Stale indicators"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        rg = self.resource_group or "<resource-group>"
        ws = self.workspace or "<workspace>"
        if "incident" in q:
            return f"I'll list incidents.\n\nTOOL: siem az sentinel incident list --resource-group {rg} --workspace-name {ws}"
        if "alert" in q or "rule" in q:
            return f"I'll list alert rules.\n\nTOOL: siem az sentinel alert-rule list --resource-group {rg} --workspace-name {ws}"
        if "connector" in q or "data" in q:
            return f"I'll list data connectors.\n\nTOOL: siem az sentinel data-connector list --resource-group {rg} --workspace-name {ws}"
        if "threat" in q or "indicator" in q:
            return f"I'll check threat indicators.\n\nTOOL: siem az sentinel threat-indicator list --resource-group {rg} --workspace-name {ws}"
        if "hunt" in q:
            return f"I'll list hunting queries.\n\nTOOL: siem az sentinel hunting query list --resource-group {rg} --workspace-name {ws}"
        return f"I'll list recent incidents.\n\nTOOL: siem az sentinel incident list --resource-group {rg} --workspace-name {ws}"
