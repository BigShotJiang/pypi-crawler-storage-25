"""Quantum Readiness Audit Agent.

Premium security agent that inventories all cryptographic assets
and flags quantum-vulnerable algorithms for post-quantum migration.

Scans:
- TLS certificates and cipher suites
- Key exchange algorithms (RSA, ECDH — quantum-vulnerable)
- Code dependencies using vulnerable crypto libraries
- Stored encrypted data (algorithm, key length)
- VPN tunnel configurations
- SSH key types
- JWT signing algorithms
- Database encryption at rest settings
- Kubernetes secrets and mTLS configurations

Classification based on NIST post-quantum standards and CISA/NSA guidance:
- QUANTUM-SAFE: AES-256, CRYSTALS-Kyber, CRYSTALS-Dilithium, SPHINCS+, SHA-3
- QUANTUM-VULNERABLE: RSA (any size), ECDSA, ECDH, DSA, SHA-1, MD5

References:
- NIST Post-Quantum Cryptography Standards (FIPS 203, 204, 205)
- CISA Post-Quantum Cryptography Initiative
- NSA CNSA 2.0 (Commercial National Security Algorithm Suite)
"""

import subprocess
import json
import re
from typing import Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from agents.base.audit import (
    AuditAgent,
    PolicyRule,
    Violation,
    ComplianceReport,
    Severity,
    ComplianceFramework,
)


class QuantumSafety(Enum):
    """Quantum safety classification."""
    SAFE = "quantum-safe"
    VULNERABLE = "quantum-vulnerable"
    UNKNOWN = "unknown"
    DEPRECATED = "deprecated"  # Already broken (MD5, SHA-1, DES)


@dataclass
class CryptoAsset:
    """A cryptographic asset found during scanning."""

    asset_type: str  # certificate, key, cipher, algorithm, library
    location: str    # Where it was found
    algorithm: str   # Algorithm name
    key_size: Optional[int] = None
    safety: QuantumSafety = QuantumSafety.UNKNOWN
    details: dict = field(default_factory=dict)
    recommendation: str = ""

    def __str__(self) -> str:
        icon = {
            QuantumSafety.SAFE: "🟢",
            QuantumSafety.VULNERABLE: "🔴",
            QuantumSafety.DEPRECATED: "⚫",
            QuantumSafety.UNKNOWN: "⚪",
        }.get(self.safety, "⚪")
        key_info = f" ({self.key_size}-bit)" if self.key_size else ""
        return f"{icon} {self.asset_type}: {self.algorithm}{key_info} @ {self.location}"


@dataclass
class CryptoInventory:
    """Complete cryptographic inventory of a system."""

    target: str
    assets: list[CryptoAsset] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)

    @property
    def vulnerable_count(self) -> int:
        return sum(1 for a in self.assets if a.safety == QuantumSafety.VULNERABLE)

    @property
    def safe_count(self) -> int:
        return sum(1 for a in self.assets if a.safety == QuantumSafety.SAFE)

    @property
    def quantum_readiness_score(self) -> float:
        """Percentage of assets that are quantum-safe."""
        total = len(self.assets)
        if total == 0:
            return 100.0
        return (self.safe_count / total) * 100

    def __str__(self) -> str:
        lines = [
            f"Cryptographic Inventory: {self.target}",
            "=" * 60,
            f"Quantum Readiness Score: {self.quantum_readiness_score:.1f}%",
            f"Total assets: {len(self.assets)}",
            f"  🟢 Quantum-safe: {self.safe_count}",
            f"  🔴 Quantum-vulnerable: {self.vulnerable_count}",
            "",
        ]

        if self.vulnerable_count > 0:
            lines.append("⚠️  VULNERABLE ASSETS REQUIRING MIGRATION:")
            for asset in self.assets:
                if asset.safety == QuantumSafety.VULNERABLE:
                    lines.append(f"  {asset}")
                    if asset.recommendation:
                        lines.append(f"     → {asset.recommendation}")

        return "\n".join(lines)


# =============================================================================
# Quantum Safety Classifications
# =============================================================================

# Algorithms broken by Shor's algorithm (factoring/discrete log)
QUANTUM_VULNERABLE_ALGORITHMS = {
    # Asymmetric encryption
    "RSA": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",
    "RSA-1024": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",
    "RSA-2048": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",
    "RSA-3072": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",
    "RSA-4096": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",

    # Elliptic curve
    "ECDSA": "Broken by Shor's algorithm - migrate to CRYSTALS-Dilithium (ML-DSA)",
    "ECDH": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",
    "ECDHE": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",
    "P-256": "Broken by Shor's algorithm - migrate to post-quantum curves",
    "P-384": "Broken by Shor's algorithm - migrate to post-quantum curves",
    "P-521": "Broken by Shor's algorithm - migrate to post-quantum curves",
    "secp256k1": "Broken by Shor's algorithm - migrate to post-quantum curves",
    "secp384r1": "Broken by Shor's algorithm - migrate to post-quantum curves",
    "Ed25519": "Broken by Shor's algorithm - migrate to CRYSTALS-Dilithium",
    "Ed448": "Broken by Shor's algorithm - migrate to CRYSTALS-Dilithium",
    "X25519": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber",
    "X448": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber",

    # Diffie-Hellman
    "DH": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",
    "DHE": "Broken by Shor's algorithm - migrate to CRYSTALS-Kyber (ML-KEM)",

    # Digital signatures
    "DSA": "Broken by Shor's algorithm - migrate to CRYSTALS-Dilithium (ML-DSA)",
}

# Algorithms safe against known quantum attacks
QUANTUM_SAFE_ALGORITHMS = {
    # Symmetric encryption (Grover's only halves effective key length)
    "AES-256": "Quantum-safe (256-bit provides 128-bit post-quantum security)",
    "AES-192": "Marginally safe (192-bit provides 96-bit post-quantum security)",
    "ChaCha20": "Quantum-safe with 256-bit key",
    "ChaCha20-Poly1305": "Quantum-safe with 256-bit key",

    # NIST post-quantum standards (FIPS 203, 204, 205)
    "CRYSTALS-Kyber": "NIST standard ML-KEM for key encapsulation",
    "ML-KEM": "NIST FIPS 203 - post-quantum key encapsulation",
    "Kyber512": "NIST ML-KEM-512 (128-bit security)",
    "Kyber768": "NIST ML-KEM-768 (192-bit security)",
    "Kyber1024": "NIST ML-KEM-1024 (256-bit security)",

    "CRYSTALS-Dilithium": "NIST standard ML-DSA for digital signatures",
    "ML-DSA": "NIST FIPS 204 - post-quantum digital signatures",
    "Dilithium2": "NIST ML-DSA-44 (128-bit security)",
    "Dilithium3": "NIST ML-DSA-65 (192-bit security)",
    "Dilithium5": "NIST ML-DSA-87 (256-bit security)",

    "SPHINCS+": "NIST standard SLH-DSA for hash-based signatures",
    "SLH-DSA": "NIST FIPS 205 - stateless hash-based signatures",

    # Hash functions
    "SHA-256": "Quantum-safe (256-bit provides 128-bit post-quantum security)",
    "SHA-384": "Quantum-safe",
    "SHA-512": "Quantum-safe",
    "SHA-3": "Quantum-safe",
    "SHA3-256": "Quantum-safe",
    "SHA3-384": "Quantum-safe",
    "SHA3-512": "Quantum-safe",
    "BLAKE2": "Quantum-safe",
    "BLAKE3": "Quantum-safe",
}

# Already deprecated (broken without quantum computers)
DEPRECATED_ALGORITHMS = {
    "MD5": "Cryptographically broken - do not use",
    "SHA-1": "Cryptographically broken - do not use",
    "DES": "Cryptographically broken - do not use",
    "3DES": "Deprecated - migrate to AES-256",
    "RC4": "Cryptographically broken - do not use",
    "AES-128": "Insufficient post-quantum security - migrate to AES-256",
}


def classify_algorithm(algorithm: str, key_size: Optional[int] = None) -> tuple[QuantumSafety, str]:
    """Classify an algorithm's quantum safety.

    Args:
        algorithm: Algorithm name
        key_size: Key size in bits (if applicable)

    Returns:
        Tuple of (QuantumSafety, recommendation)
    """
    algo_upper = algorithm.upper().replace("-", "").replace("_", "")

    # Check deprecated first
    for pattern, rec in DEPRECATED_ALGORITHMS.items():
        if pattern.upper().replace("-", "") in algo_upper:
            return QuantumSafety.DEPRECATED, rec

    # Check quantum-safe
    for pattern, rec in QUANTUM_SAFE_ALGORITHMS.items():
        if pattern.upper().replace("-", "") in algo_upper:
            return QuantumSafety.SAFE, rec

    # Check quantum-vulnerable
    for pattern, rec in QUANTUM_VULNERABLE_ALGORITHMS.items():
        if pattern.upper().replace("-", "") in algo_upper:
            return QuantumSafety.VULNERABLE, rec

    # Check by key size for symmetric algorithms
    if key_size:
        if key_size >= 256:
            return QuantumSafety.SAFE, "256-bit symmetric keys provide adequate post-quantum security"
        elif key_size >= 192:
            return QuantumSafety.SAFE, "192-bit provides marginal post-quantum security"
        elif key_size >= 128:
            return QuantumSafety.VULNERABLE, "128-bit symmetric only provides 64-bit post-quantum security"

    return QuantumSafety.UNKNOWN, "Unable to classify - manual review required"


# =============================================================================
# Policy Rules for Quantum Readiness
# =============================================================================

QUANTUM_READINESS_RULES = [
    # TLS/Certificate rules
    PolicyRule(
        id="QR-TLS-001",
        name="No RSA certificates",
        description="TLS certificates should not use RSA keys (quantum-vulnerable)",
        severity=Severity.HIGH,
        pattern=r"(?i)(RSA|rsaEncryption)",
        remediation="Replace RSA certificates with ECDSA (short-term) or wait for hybrid PQ certificates",
    ),
    PolicyRule(
        id="QR-TLS-002",
        name="No ECDSA certificates",
        description="ECDSA certificates are quantum-vulnerable",
        severity=Severity.MEDIUM,
        pattern=r"(?i)(ECDSA|ecdsaWithSHA)",
        remediation="Plan migration to hybrid post-quantum certificates when available",
    ),
    PolicyRule(
        id="QR-TLS-003",
        name="No weak cipher suites",
        description="Cipher suites using RSA key exchange are quantum-vulnerable",
        severity=Severity.HIGH,
        pattern=r"(?i)TLS_RSA_WITH",
        remediation="Use ECDHE key exchange (short-term) or hybrid PQ key exchange",
    ),

    # SSH rules
    PolicyRule(
        id="QR-SSH-001",
        name="No RSA SSH keys",
        description="RSA SSH keys are quantum-vulnerable",
        severity=Severity.HIGH,
        pattern=r"ssh-rsa",
        remediation="Migrate to hybrid post-quantum SSH keys when available",
    ),
    PolicyRule(
        id="QR-SSH-002",
        name="No ECDSA SSH keys",
        description="ECDSA SSH keys are quantum-vulnerable",
        severity=Severity.MEDIUM,
        pattern=r"ecdsa-sha2",
        remediation="Plan migration to post-quantum SSH algorithms",
    ),
    PolicyRule(
        id="QR-SSH-003",
        name="No Ed25519 SSH keys",
        description="Ed25519 SSH keys are quantum-vulnerable (elliptic curve based)",
        severity=Severity.MEDIUM,
        pattern=r"ssh-ed25519",
        remediation="Plan migration to post-quantum SSH algorithms",
    ),

    # JWT rules
    PolicyRule(
        id="QR-JWT-001",
        name="No RS256/RS384/RS512 JWT",
        description="RSA-based JWT signing is quantum-vulnerable",
        severity=Severity.HIGH,
        pattern=r'"alg"\s*:\s*"RS(256|384|512)"',
        remediation="Migrate to symmetric HS256 (if single issuer) or plan for PQ signatures",
    ),
    PolicyRule(
        id="QR-JWT-002",
        name="No ES256/ES384/ES512 JWT",
        description="ECDSA-based JWT signing is quantum-vulnerable",
        severity=Severity.HIGH,
        pattern=r'"alg"\s*:\s*"ES(256|384|512)"',
        remediation="Migrate to symmetric HS256 (if single issuer) or plan for PQ signatures",
    ),

    # Encryption at rest
    PolicyRule(
        id="QR-EAR-001",
        name="Weak symmetric encryption",
        description="AES-128 provides insufficient post-quantum security",
        severity=Severity.MEDIUM,
        pattern=r"(?i)AES.?128|aes128",
        remediation="Upgrade to AES-256 for quantum resistance",
    ),
    PolicyRule(
        id="QR-EAR-002",
        name="Deprecated encryption",
        description="3DES/DES/RC4 are cryptographically weak",
        severity=Severity.CRITICAL,
        pattern=r"(?i)(3DES|DES|RC4|ARCFOUR)",
        remediation="Migrate immediately to AES-256",
    ),

    # Hash functions
    PolicyRule(
        id="QR-HASH-001",
        name="Deprecated hash function",
        description="MD5 and SHA-1 are cryptographically broken",
        severity=Severity.CRITICAL,
        pattern=r"(?i)(MD5|SHA.?1[^0-9])",
        remediation="Migrate to SHA-256 or SHA-3",
    ),

    # Key exchange
    PolicyRule(
        id="QR-KEX-001",
        name="Quantum-vulnerable key exchange",
        description="DH/ECDH key exchange is vulnerable to Shor's algorithm",
        severity=Severity.HIGH,
        pattern=r"(?i)(DHE?_|ECDHE?_|diffie.?hellman)",
        remediation="Plan migration to hybrid post-quantum key exchange (ML-KEM + ECDH)",
    ),
]


class QuantumReadinessAgent(AuditAgent):
    """Agent for quantum cryptography readiness auditing.

    Scans infrastructure for quantum-vulnerable cryptography and provides
    a complete cryptographic inventory with migration recommendations.

    Premium agent - pricing reflects specialized cryptography expertise
    and compliance value (NIST, CISA, NSA CNSA 2.0).
    """

    POLICIES = QUANTUM_READINESS_RULES
    TOOL_NAME = "quantum"
    COMMAND_TIMEOUT = 60

    # Premium pricing factor
    PRICING_MULTIPLIER = 5.0  # 5x standard rate

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal,
        llm=None,
    ):
        """Initialize Quantum Readiness Agent.

        Args:
            name: Agent name
            config: Configuration dict with:
                - target: System to audit (host, cluster, etc.)
                - scan_tls: Scan TLS certificates (default: True)
                - scan_ssh: Scan SSH keys (default: True)
                - scan_secrets: Scan K8s secrets (default: True)
                - scan_deps: Scan code dependencies (default: False)
            terminal: Terminal for output
            llm: Optional LLM client
        """
        self.scan_tls = config.get("scan_tls", True)
        self.scan_ssh = config.get("scan_ssh", True)
        self.scan_secrets = config.get("scan_secrets", True)
        self.scan_deps = config.get("scan_deps", False)

        super().__init__(name, config, terminal, llm)

    def _register_tools(self) -> None:
        """Register quantum audit tools."""
        # Inherit base audit tools
        super()._register_tools()

        # Add quantum-specific tools
        self.register_tool(
            name=f"{self.TOOL_NAME}_inventory",
            description="Generate complete cryptographic inventory. Usage: quantum_inventory [target]",
            execute=self._run_inventory,
            requires_approval=False,
        )

        self.register_tool(
            name=f"{self.TOOL_NAME}_tls",
            description="Scan TLS certificates on a host:port. Usage: quantum_tls <host:port>",
            execute=self._run_tls_scan,
            requires_approval=False,
        )

        self.register_tool(
            name=f"{self.TOOL_NAME}_ssh",
            description="Scan SSH host keys. Usage: quantum_ssh <host>",
            execute=self._run_ssh_scan,
            requires_approval=False,
        )

        self.register_tool(
            name=f"{self.TOOL_NAME}_classify",
            description="Classify an algorithm's quantum safety. Usage: quantum_classify <algorithm>",
            execute=self._run_classify,
            requires_approval=False,
        )

    def _fetch_config(self, resource: str) -> dict | str:
        """Fetch configuration for quantum audit."""
        # For now, return placeholder - actual implementation depends on target type
        return {"resource": resource, "type": "generic"}

    def _run_inventory(self, args: str = "") -> str:
        """Generate complete cryptographic inventory."""
        target = args.strip() if args else self.target

        inventory = CryptoInventory(target=target)

        # Scan TLS if enabled
        if self.scan_tls:
            tls_assets = self._scan_tls_assets(target)
            inventory.assets.extend(tls_assets)

        # Scan SSH if enabled
        if self.scan_ssh:
            ssh_assets = self._scan_ssh_assets(target)
            inventory.assets.extend(ssh_assets)

        self.bytes_processed += len(str(inventory)) * 10  # Premium multiplier

        return str(inventory)

    def _run_tls_scan(self, args: str) -> str:
        """Scan TLS certificates on a host."""
        if not args:
            return "Usage: quantum_tls <host:port>"

        target = args.strip()
        if ":" not in target:
            target = f"{target}:443"

        host, port = target.rsplit(":", 1)

        try:
            # Use openssl s_client to get certificate info
            cmd = [
                "openssl", "s_client",
                "-connect", f"{host}:{port}",
                "-servername", host,
            ]

            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            stdout, stderr = proc.communicate(input=b"", timeout=10)
            output = stdout.decode() + stderr.decode()

            # Parse certificate details
            cert_cmd = ["openssl", "x509", "-text", "-noout"]
            proc2 = subprocess.Popen(
                cert_cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            cert_out, _ = proc2.communicate(input=stdout, timeout=5)
            cert_text = cert_out.decode()

            assets = []

            # Extract public key algorithm
            if "RSA Public-Key:" in cert_text or "rsaEncryption" in cert_text:
                key_match = re.search(r"RSA Public-Key: \((\d+) bit\)", cert_text)
                key_size = int(key_match.group(1)) if key_match else None
                safety, rec = classify_algorithm("RSA", key_size)
                assets.append(CryptoAsset(
                    asset_type="TLS Certificate",
                    location=target,
                    algorithm="RSA",
                    key_size=key_size,
                    safety=safety,
                    recommendation=rec,
                ))
            elif "EC Public-Key:" in cert_text or "ecdsa" in cert_text.lower():
                key_match = re.search(r"EC Public-Key: \((\d+) bit\)", cert_text)
                key_size = int(key_match.group(1)) if key_match else None
                safety, rec = classify_algorithm("ECDSA", key_size)
                assets.append(CryptoAsset(
                    asset_type="TLS Certificate",
                    location=target,
                    algorithm="ECDSA",
                    key_size=key_size,
                    safety=safety,
                    recommendation=rec,
                ))

            # Extract signature algorithm
            sig_match = re.search(r"Signature Algorithm: (\S+)", cert_text)
            if sig_match:
                sig_algo = sig_match.group(1)
                safety, rec = classify_algorithm(sig_algo)
                assets.append(CryptoAsset(
                    asset_type="Signature Algorithm",
                    location=target,
                    algorithm=sig_algo,
                    safety=safety,
                    recommendation=rec,
                ))

            self.bytes_processed += len(output) * 5

            if not assets:
                return f"Could not extract certificate details from {target}"

            lines = [f"TLS Scan Results for {target}:", ""]
            for asset in assets:
                lines.append(str(asset))
                if asset.recommendation:
                    lines.append(f"   → {asset.recommendation}")

            return "\n".join(lines)

        except subprocess.TimeoutExpired:
            return f"Timeout connecting to {target}"
        except FileNotFoundError:
            return "openssl command not found"
        except Exception as e:
            return f"Error scanning {target}: {e}"

    def _run_ssh_scan(self, args: str) -> str:
        """Scan SSH host keys."""
        if not args:
            return "Usage: quantum_ssh <host>"

        host = args.strip()

        try:
            # Use ssh-keyscan to get host keys
            result = subprocess.run(
                ["ssh-keyscan", "-T", "5", host],
                capture_output=True,
                text=True,
                timeout=10,
            )

            output = result.stdout + result.stderr
            assets = []

            for line in output.split("\n"):
                if not line or line.startswith("#"):
                    continue

                if "ssh-rsa" in line:
                    safety, rec = classify_algorithm("RSA")
                    assets.append(CryptoAsset(
                        asset_type="SSH Host Key",
                        location=host,
                        algorithm="RSA",
                        safety=safety,
                        recommendation=rec,
                    ))
                elif "ecdsa-sha2" in line:
                    safety, rec = classify_algorithm("ECDSA")
                    assets.append(CryptoAsset(
                        asset_type="SSH Host Key",
                        location=host,
                        algorithm="ECDSA",
                        safety=safety,
                        recommendation=rec,
                    ))
                elif "ssh-ed25519" in line:
                    safety, rec = classify_algorithm("Ed25519")
                    assets.append(CryptoAsset(
                        asset_type="SSH Host Key",
                        location=host,
                        algorithm="Ed25519",
                        safety=safety,
                        recommendation=rec,
                    ))

            self.bytes_processed += len(output) * 5

            if not assets:
                return f"No SSH host keys found for {host}"

            lines = [f"SSH Key Scan Results for {host}:", ""]
            for asset in assets:
                lines.append(str(asset))
                if asset.recommendation:
                    lines.append(f"   → {asset.recommendation}")

            return "\n".join(lines)

        except subprocess.TimeoutExpired:
            return f"Timeout connecting to {host}"
        except FileNotFoundError:
            return "ssh-keyscan command not found"
        except Exception as e:
            return f"Error scanning {host}: {e}"

    def _run_classify(self, args: str) -> str:
        """Classify an algorithm's quantum safety."""
        if not args:
            return "Usage: quantum_classify <algorithm>"

        algorithm = args.strip()
        safety, recommendation = classify_algorithm(algorithm)

        icon = {
            QuantumSafety.SAFE: "🟢 QUANTUM-SAFE",
            QuantumSafety.VULNERABLE: "🔴 QUANTUM-VULNERABLE",
            QuantumSafety.DEPRECATED: "⚫ DEPRECATED",
            QuantumSafety.UNKNOWN: "⚪ UNKNOWN",
        }.get(safety, "⚪ UNKNOWN")

        lines = [
            f"Algorithm: {algorithm}",
            f"Classification: {icon}",
            f"",
            f"Assessment: {recommendation}",
        ]

        if safety == QuantumSafety.VULNERABLE:
            lines.extend([
                "",
                "Why it's vulnerable:",
                "  Shor's algorithm can solve the discrete logarithm and",
                "  integer factorization problems in polynomial time on a",
                "  cryptographically relevant quantum computer (CRQC).",
                "",
                "Timeline:",
                "  CISA recommends completing migration by 2035.",
                "  NSA CNSA 2.0 mandates PQ algorithms for national security",
                "  systems starting 2025.",
            ])

        return "\n".join(lines)

    def _scan_tls_assets(self, target: str) -> list[CryptoAsset]:
        """Scan TLS assets for a target."""
        # Placeholder - would scan multiple endpoints
        return []

    def _scan_ssh_assets(self, target: str) -> list[CryptoAsset]:
        """Scan SSH assets for a target."""
        # Placeholder - would scan SSH configurations
        return []

    def _get_system_prompt(self) -> str:
        return f"""You are a Quantum Cryptography Readiness Agent for {self.name}.

You specialize in identifying quantum-vulnerable cryptography and providing
migration guidance based on NIST post-quantum standards.

Available tools:
- {self.TOOL_NAME}_inventory: Generate complete cryptographic inventory
- {self.TOOL_NAME}_tls: Scan TLS certificates on host:port
- {self.TOOL_NAME}_ssh: Scan SSH host keys
- {self.TOOL_NAME}_classify: Classify algorithm quantum safety
- {self.TOOL_NAME}_check: Run full compliance audit
- {self.TOOL_NAME}_rules: List policy rules

Quantum Safety Classifications:
🟢 QUANTUM-SAFE:
   - Symmetric: AES-256, ChaCha20-Poly1305
   - Hash: SHA-256, SHA-3, BLAKE3
   - Post-Quantum: ML-KEM (Kyber), ML-DSA (Dilithium), SLH-DSA (SPHINCS+)

🔴 QUANTUM-VULNERABLE (broken by Shor's algorithm):
   - Asymmetric: RSA (any size), DSA
   - Elliptic Curve: ECDSA, ECDH, Ed25519, X25519, P-256, P-384

⚫ DEPRECATED (already broken):
   - MD5, SHA-1, DES, 3DES, RC4

Key Standards:
- NIST FIPS 203: ML-KEM (key encapsulation)
- NIST FIPS 204: ML-DSA (digital signatures)
- NIST FIPS 205: SLH-DSA (hash-based signatures)
- NSA CNSA 2.0: Commercial National Security Algorithm Suite
- CISA: Post-Quantum Cryptography Initiative

Migration Timeline:
- 2024-2025: Inventory all cryptographic assets
- 2025-2030: Implement hybrid solutions (classical + PQ)
- 2030-2035: Complete migration to pure PQ algorithms

Always provide specific migration recommendations based on the asset type
and its criticality. Prioritize data that needs long-term confidentiality
("harvest now, decrypt later" attacks)."""
