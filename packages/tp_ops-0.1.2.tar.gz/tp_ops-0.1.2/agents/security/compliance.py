"""Compliance Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ComplianceAgent(ShellAgent):
    """Agent for compliance framework investigation."""

    COMMAND_PREFIX = ["aws", "securityhub"]
    TOOL_NAME = "compliance"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "get-findings", "describe-standards", "describe-standards-controls",
        "get-insight-results", "list-members", "describe-hub",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "update-findings", "batch-update-findings",
        "disable-security-hub", "update-standards-control",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.framework = config.get("framework", "cis")  # cis, soc2, pci, hipaa, nist
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "securityhub", "--region", self.region]

    def _get_system_prompt(self) -> str:
        framework = self.framework.upper()
        return f"""You are a Compliance investigation agent for {framework}.

Region: {self.region}

Available tools:
- compliance: Execute read-only compliance checks
- compliance_write: Execute remediations (requires approval)

Investigation approach:
1. Findings: aws securityhub get-findings
2. Standards: aws securityhub describe-standards
3. Controls: aws securityhub describe-standards-controls
4. Insights: aws securityhub get-insight-results

Compliance frameworks:
- CIS: Center for Internet Security benchmarks
- SOC2: Service Organization Control
- PCI DSS: Payment Card Industry
- HIPAA: Healthcare data protection
- NIST: National Institute of Standards

Finding severity:
- CRITICAL: Immediate remediation needed
- HIGH: Remediate within 7 days
- MEDIUM: Remediate within 30 days
- LOW: Best practice recommendations
- INFORMATIONAL: No action needed

Control status:
- PASSED: Control requirements met
- FAILED: Control requirements not met
- WARNING: Partial compliance
- NOT_AVAILABLE: Cannot determine

Common issues:
- Failed controls: Non-compliant resources
- Stale findings: Outdated assessments
- Scope gaps: Resources not evaluated
- Exemption expiry: Temporary waivers ending
- Evidence collection: Missing audit trails
- Remediation delays: Unfixed findings"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "finding" in q or "fail" in q:
            return "I'll get failed findings.\n\nTOOL: compliance aws securityhub get-findings --filters '{\"ComplianceStatus\":[{\"Value\":\"FAILED\",\"Comparison\":\"EQUALS\"}]}'"
        if "standard" in q:
            return "I'll describe standards.\n\nTOOL: compliance aws securityhub describe-standards"
        if "control" in q:
            return "I'll describe controls.\n\nTOOL: compliance aws securityhub describe-standards-controls --standards-subscription-arn <arn>"
        if "cis" in q:
            return "I'll check CIS findings.\n\nTOOL: compliance aws securityhub get-findings --filters '{\"GeneratorId\":[{\"Value\":\"cis\",\"Comparison\":\"PREFIX\"}]}'"
        if "pci" in q:
            return "I'll check PCI findings.\n\nTOOL: compliance aws securityhub get-findings --filters '{\"GeneratorId\":[{\"Value\":\"pci\",\"Comparison\":\"PREFIX\"}]}'"
        return "I'll get compliance findings.\n\nTOOL: compliance aws securityhub get-findings --max-results 20"
