"""Secret Manager Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SecretManagerAgent(ShellAgent):
    """Agent for secret management investigation."""

    COMMAND_PREFIX = ["vault"]
    TOOL_NAME = "vault"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "status", "secrets list", "auth list", "policy list",
        "policy read", "lease list", "token lookup", "audit list",
        "kv metadata get", "kv list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "kv put", "kv delete", "secrets enable", "secrets disable",
        "auth enable", "auth disable", "policy write", "policy delete",
        "lease revoke", "token revoke",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.backend = config.get("backend", "vault")  # vault, aws, azure
        self.vault_addr = config.get("vault_addr")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.backend == "vault":
            return ["vault"]
        elif self.backend == "aws":
            return ["aws", "secretsmanager", "--region", self.region]
        else:
            return ["az", "keyvault"]

    def _get_system_prompt(self) -> str:
        backend = self.backend.upper()
        return f"""You are a Secret Manager investigation agent for {backend}.

Backend: {self.backend}
{'Vault Address: ' + self.vault_addr if self.vault_addr else ''}

Available tools:
- {self.backend}: Execute read-only secret management commands
- {self.backend}_write: Execute write commands (requires approval)

Investigation approach for Vault:
1. Status: vault status
2. Secrets Engines: vault secrets list
3. Auth Methods: vault auth list
4. Policies: vault policy list
5. Audit Devices: vault audit list
6. Token Info: vault token lookup

Investigation approach for AWS Secrets Manager:
1. List Secrets: aws secretsmanager list-secrets
2. Describe Secret: aws secretsmanager describe-secret --secret-id <name>
3. Rotation Status: Check rotation configuration
4. Resource Policy: aws secretsmanager get-resource-policy --secret-id <name>

Investigation approach for Azure Key Vault:
1. List Vaults: az keyvault list
2. List Secrets: az keyvault secret list --vault-name <name>
3. Show Secret: az keyvault secret show --vault-name <name> --name <secret>
4. Access Policies: az keyvault show --name <name>

Security checks:
- Secret rotation: Are secrets rotated regularly?
- Access policies: Who has access to which secrets?
- Audit logging: Are secret accesses logged?
- Encryption: Are secrets encrypted at rest?
- Network access: Is access restricted?

Common issues:
- No rotation: Secrets never rotated
- Overprivileged: Too many entities with read access
- No audit: Secret access not logged
- Stale secrets: Old unused secrets still stored
- Hardcoded secrets: Secrets in code instead of manager"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.backend == "vault":
            if "status" in q:
                return "I'll check Vault status.\n\nTOOL: vault vault status"
            if "secret" in q or "list" in q:
                return "I'll list secrets engines.\n\nTOOL: vault vault secrets list"
            if "auth" in q:
                return "I'll list auth methods.\n\nTOOL: vault vault auth list"
            if "policy" in q or "policies" in q:
                return "I'll list policies.\n\nTOOL: vault vault policy list"
            if "audit" in q:
                return "I'll check audit devices.\n\nTOOL: vault vault audit list"
            return "I'll check Vault status.\n\nTOOL: vault vault status && vault secrets list"
        elif self.backend == "aws":
            if "list" in q:
                return "I'll list secrets.\n\nTOOL: aws aws secretsmanager list-secrets"
            if "rotation" in q:
                return "I'll check rotation status.\n\nTOOL: aws aws secretsmanager describe-secret --secret-id <secret-name>"
            return "I'll list secrets.\n\nTOOL: aws aws secretsmanager list-secrets"
        else:
            if "list" in q:
                return "I'll list Key Vaults.\n\nTOOL: az az keyvault list"
            return "I'll list Key Vaults.\n\nTOOL: az az keyvault list"
