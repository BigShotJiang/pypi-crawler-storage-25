"""Identity Governance Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class IdentityGovernanceAgent(ShellAgent):
    """Agent for identity governance and administration (IGA) investigation."""

    COMMAND_PREFIX = ["az", "ad"]
    TOOL_NAME = "iga"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "user list", "group list", "app list", "sp list",
        "role assignment list", "role definition list",
        "signed-in-user show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "user create", "user delete", "group create", "group delete",
        "role assignment create", "role assignment delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.provider = config.get("provider", "azure")  # azure, okta, sailpoint
        self.tenant = config.get("tenant")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        provider = self.provider.title()
        return f"""You are an Identity Governance investigation agent for {provider}.

Tenant: {self.tenant or 'current'}

Available tools:
- iga: Execute read-only identity governance commands
- iga_write: Execute changes (requires approval)

Investigation approach for Azure AD:
1. Users: az ad user list
2. Groups: az ad group list
3. Applications: az ad app list
4. Service Principals: az ad sp list
5. Role Assignments: az role assignment list
6. Role Definitions: az role definition list

Identity lifecycle:
- Provisioning: New user creation
- Access requests: Entitlement requests
- Access reviews: Periodic certification
- Deprovisioning: Offboarding

Governance areas:
- Access certification: Review permissions
- Segregation of duties: Conflict detection
- Privileged access: Admin monitoring
- Orphan accounts: Stale identities
- Service accounts: Non-human identities

Common issues:
- Stale accounts: Inactive users
- Orphan permissions: Unused roles
- Excessive access: Over-privileged users
- No MFA: Missing multi-factor
- Shared accounts: Non-individual access
- No attestation: Unreviewed access"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "user" in q:
            return "I'll list users.\n\nTOOL: iga az ad user list --query \"[].{Name:displayName,UPN:userPrincipalName,Enabled:accountEnabled}\" --output json"
        if "group" in q:
            return "I'll list groups.\n\nTOOL: iga az ad group list --query \"[].{Name:displayName,Id:id}\" --output json"
        if "role" in q:
            return "I'll list role assignments.\n\nTOOL: iga az role assignment list --output json"
        if "app" in q or "application" in q:
            return "I'll list applications.\n\nTOOL: iga az ad app list --query \"[].{Name:displayName,AppId:appId}\" --output json"
        if "service" in q or "sp" in q:
            return "I'll list service principals.\n\nTOOL: iga az ad sp list --query \"[].{Name:displayName,AppId:appId}\" --output json"
        if "inactive" in q or "stale" in q:
            return "I'll find inactive users.\n\nTOOL: iga az ad user list --filter \"accountEnabled eq false\" --output json"
        return "I'll check identity governance status.\n\nTOOL: iga az ad user list --query \"length(@)\" && az ad group list --query \"length(@)\""
