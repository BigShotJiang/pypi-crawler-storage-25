"""TLS/Certificate Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class TLSAgent(ShellAgent):
    """Agent for TLS/Certificate investigation."""

    COMMAND_PREFIX = ["openssl"]
    TOOL_NAME = "openssl"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "s_client", "x509", "verify", "ciphers", "version",
        "s_client -connect", "x509 -text", "x509 -dates",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "req -new", "genrsa", "ca", "pkcs12 -export",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.domain = config.get("domain")
        self.port = config.get("port", 443)
        self.cert_path = config.get("cert_path")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        domain = self.domain or "<domain>"
        return f"""You are a TLS/Certificate investigation agent for '{domain}:{self.port}'.

Available tools:
- openssl: Execute certificate inspection commands
- curl: Test HTTPS endpoints

Investigation approach:
1. Certificate Info: openssl s_client -connect {domain}:{self.port} </dev/null | openssl x509 -text
2. Expiry Date: openssl s_client -connect {domain}:{self.port} </dev/null | openssl x509 -dates
3. Chain Validation: openssl s_client -connect {domain}:{self.port} -showcerts
4. Cipher Suite: openssl s_client -connect {domain}:{self.port} -cipher 'ALL'
5. Protocol Test: openssl s_client -connect {domain}:{self.port} -tls1_2

Certificate checks:
- Expiry: Days until certificate expires
- Chain: Complete certificate chain present
- CN/SAN: Hostname matches certificate
- Signature: Strong signature algorithm (SHA256+)
- Key size: RSA 2048+ or ECDSA 256+

Cipher analysis:
- Weak ciphers: RC4, DES, 3DES, NULL
- Perfect forward secrecy: ECDHE, DHE
- Protocol versions: TLS 1.2+ required, SSLv3/TLS1.0/1.1 disabled

Common issues:
- Expired certificates: Certificate past validity date
- Incomplete chain: Missing intermediate certificates
- Weak ciphers: Legacy cipher suites enabled
- Mixed content: HTTP resources on HTTPS page
- Certificate mismatch: Wrong CN/SAN for domain"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        domain = self.domain or "<domain>"
        port = self.port
        if "expir" in q or "date" in q or "valid" in q:
            return f"I'll check certificate expiry.\n\nTOOL: openssl echo | openssl s_client -connect {domain}:{port} 2>/dev/null | openssl x509 -noout -dates"
        if "chain" in q:
            return f"I'll check certificate chain.\n\nTOOL: openssl echo | openssl s_client -connect {domain}:{port} -showcerts 2>/dev/null"
        if "cipher" in q:
            return f"I'll check cipher suites.\n\nTOOL: openssl openssl ciphers -v 'ALL' && echo | openssl s_client -connect {domain}:{port} 2>/dev/null | grep 'Cipher is'"
        if "protocol" in q or "tls" in q or "ssl" in q:
            return f"I'll test protocol versions.\n\nTOOL: openssl echo | openssl s_client -connect {domain}:{port} -tls1_2 2>/dev/null | grep -E 'Protocol|Cipher'"
        if "info" in q or "detail" in q:
            return f"I'll get certificate details.\n\nTOOL: openssl echo | openssl s_client -connect {domain}:{port} 2>/dev/null | openssl x509 -noout -text"
        return f"I'll check certificate status.\n\nTOOL: openssl echo | openssl s_client -connect {domain}:{port} 2>/dev/null | openssl x509 -noout -subject -issuer -dates"
