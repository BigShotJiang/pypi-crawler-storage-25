"""CASB (Cloud Access Security Broker) Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CASBAgent(ShellAgent):
    """Agent for CASB investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "casb"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "applications", "users", "activities", "alerts",
        "policies", "files", "sessions",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "block", "quarantine", "revoke", "delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.casb_type = config.get("casb_type", "mcas")  # mcas, netskope, zscaler
        self.api_url = config.get("api_url")
        self.tenant = config.get("tenant")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        casb = self.casb_type.upper()
        return f"""You are a CASB investigation agent for {casb}.

Tenant: {self.tenant or 'default'}

Available tools:
- casb: Execute read-only CASB API queries
- casb_write: Execute actions (requires approval)

Investigation approach:
1. Discovered Apps: List sanctioned/unsanctioned apps
2. User Activities: Query activity logs
3. Alerts: Check security alerts
4. Policies: Review DLP and access policies
5. Files: Check file sharing risks
6. Sessions: Monitor active sessions

App risk levels:
- SANCTIONED: Approved for use
- UNSANCTIONED: Not approved (shadow IT)
- MONITORED: Under review
- BLOCKED: Prohibited

Activity analysis:
- Logins: Sign-in patterns
- Downloads: Data exfiltration risk
- Shares: External sharing
- Admin actions: Privileged operations

Common issues:
- Shadow IT: Unauthorized apps
- Data sharing: External access
- Compromised accounts: Suspicious activity
- Policy violations: Rule breaches
- App risks: Insecure applications
- Impossible travel: Location anomalies"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "app" in q or "application" in q:
            return "I'll list discovered apps.\n\nTOOL: casb curl -s -H 'Authorization: Bearer $CASB_TOKEN' $CASB_URL/api/v1/discovered_apps"
        if "alert" in q:
            return "I'll check alerts.\n\nTOOL: casb curl -s -H 'Authorization: Bearer $CASB_TOKEN' $CASB_URL/api/v1/alerts?status=open"
        if "activity" in q or "user" in q:
            return "I'll check user activities.\n\nTOOL: casb curl -s -H 'Authorization: Bearer $CASB_TOKEN' $CASB_URL/api/v1/activities?limit=50"
        if "policy" in q:
            return "I'll list policies.\n\nTOOL: casb curl -s -H 'Authorization: Bearer $CASB_TOKEN' $CASB_URL/api/v1/policies"
        if "file" in q or "sharing" in q:
            return "I'll check file sharing.\n\nTOOL: casb curl -s -H 'Authorization: Bearer $CASB_TOKEN' $CASB_URL/api/v1/files?sharing=external"
        return "I'll check CASB alerts.\n\nTOOL: casb curl -s -H 'Authorization: Bearer $CASB_TOKEN' $CASB_URL/api/v1/alerts?status=open"
