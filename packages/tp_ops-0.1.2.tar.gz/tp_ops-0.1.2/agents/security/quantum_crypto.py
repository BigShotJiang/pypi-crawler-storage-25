"""Quantum Cryptography Readiness Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class QuantumCryptoAgent(ShellAgent):
    """Agent for quantum cryptography readiness assessment."""

    COMMAND_PREFIX = ["openssl"]
    TOOL_NAME = "openssl"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "version", "ciphers", "list", "s_client",
        "x509 -text", "pkey -text", "ec -text",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "genrsa", "genpkey", "req -new", "ca",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.target = config.get("target")  # Domain or system to assess
        self.scan_type = config.get("scan_type", "tls")  # tls, code, infra
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        target = self.target or "<target>"
        return f"""You are a Quantum Cryptography Readiness assessment agent for '{target}'.

Scan Type: {self.scan_type}

Available tools:
- openssl: Analyze cryptographic implementations
- nmap: Scan for cipher suites
- grep: Search code for cryptographic patterns

Assessment areas:

1. TLS/SSL Assessment:
   - Key exchange: Check for RSA (vulnerable) vs ECDHE (better, but still vulnerable)
   - Signature algorithms: RSA/ECDSA signatures are quantum-vulnerable
   - Certificate key sizes: Larger keys delay quantum attacks
   - Post-quantum ready: Check for hybrid key exchange support

2. Cryptographic Inventory:
   - RSA keys: All RSA keys are quantum-vulnerable
   - ECDSA/ECDH: Elliptic curve crypto is quantum-vulnerable
   - AES: Symmetric crypto needs 256-bit keys for quantum safety
   - SHA-2/SHA-3: Hash functions are relatively quantum-safe

3. Post-Quantum Cryptography (PQC):
   - CRYSTALS-Kyber: NIST-selected key encapsulation
   - CRYSTALS-Dilithium: NIST-selected digital signature
   - SPHINCS+: Hash-based signatures (stateless)
   - Hybrid modes: Classical + PQC combined

4. Code Analysis:
   - Hardcoded algorithms: Check for crypto algorithm hardcoding
   - Library versions: OpenSSL 3.x has PQC support
   - Key management: How are keys stored and rotated?

Risk assessment:
- CRITICAL: Long-term secrets encrypted with RSA
- HIGH: Authentication using ECDSA/RSA
- MEDIUM: Short-lived session keys with classical crypto
- LOW: Symmetric encryption with AES-256

Common issues:
- RSA key exchange: Vulnerable to "harvest now, decrypt later"
- Fixed algorithms: No crypto agility for migration
- Old libraries: OpenSSL < 3.0 lacks PQC support
- Missing inventory: Unknown cryptographic dependencies"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        target = self.target or "<target>"
        if "tls" in q or "cipher" in q:
            return f"I'll analyze TLS configuration.\n\nTOOL: openssl echo | openssl s_client -connect {target}:443 2>/dev/null | grep -E 'Protocol|Cipher|Server public key'"
        if "key" in q or "rsa" in q:
            return f"I'll check key exchange algorithms.\n\nTOOL: openssl nmap --script ssl-enum-ciphers -p 443 {target}"
        if "pqc" in q or "post-quantum" in q or "kyber" in q:
            return "I'll check OpenSSL PQC support.\n\nTOOL: openssl openssl version && openssl list -kem-algorithms 2>/dev/null || echo 'PQC not supported'"
        if "inventory" in q or "scan" in q:
            return f"I'll perform a cryptographic inventory.\n\nTOOL: openssl echo | openssl s_client -connect {target}:443 2>/dev/null | openssl x509 -noout -text | grep -E 'Signature Algorithm|Public Key Algorithm|Public-Key'"
        if "vulnerable" in q or "risk" in q:
            return f"I'll assess quantum vulnerability.\n\nTOOL: openssl echo | openssl s_client -connect {target}:443 2>/dev/null | grep -E 'Cipher|Server public key|Protocol'"
        return f"I'll perform a quantum readiness assessment.\n\nTOOL: openssl openssl version && echo | openssl s_client -connect {target}:443 2>/dev/null | grep -E 'Protocol|Cipher|Server public key'"
