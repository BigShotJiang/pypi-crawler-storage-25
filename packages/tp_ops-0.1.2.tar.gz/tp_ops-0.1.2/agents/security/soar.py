"""SOAR Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SOARAgent(ShellAgent):
    """Agent for SOAR (Security Orchestration, Automation and Response) investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "soar"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "playbooks", "incidents", "actions", "integrations",
        "workflows", "cases", "artifacts",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "execute", "run", "trigger", "delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.soar_type = config.get("soar_type", "xsoar")  # xsoar, splunk-soar, swimlane
        self.api_url = config.get("api_url")
        self.api_key = config.get("api_key")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        soar = self.soar_type.upper()
        return f"""You are a SOAR investigation agent for {soar}.

API URL: {self.api_url or 'not configured'}

Available tools:
- soar: Execute read-only SOAR API queries
- soar_write: Execute playbooks/actions (requires approval)

Investigation approach:
1. Playbooks: List available playbooks
2. Incidents: List open incidents/cases
3. Actions: Check available actions
4. Integrations: List connected tools
5. Workflows: Check automation workflows
6. Artifacts: Review incident artifacts

Playbook analysis:
- Execution history: Success/failure rates
- Timing: Average execution time
- Dependencies: External integrations used
- Triggers: What initiates the playbook

Integration health:
- Connection status: Online/offline
- Last sync: Data freshness
- Error rates: Integration failures
- API limits: Rate limiting issues

Common issues:
- Playbook failures: Script errors
- Integration disconnects: API key expiry
- Rate limiting: Too many API calls
- Action timeouts: Slow responses
- Case backlog: Unprocessed incidents
- Automation gaps: Manual steps needed"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "playbook" in q:
            return "I'll list playbooks.\n\nTOOL: soar curl -s -H 'Authorization: Bearer $SOAR_API_KEY' $SOAR_URL/api/playbooks"
        if "incident" in q or "case" in q:
            return "I'll list incidents.\n\nTOOL: soar curl -s -H 'Authorization: Bearer $SOAR_API_KEY' $SOAR_URL/api/incidents?status=open"
        if "integration" in q:
            return "I'll check integrations.\n\nTOOL: soar curl -s -H 'Authorization: Bearer $SOAR_API_KEY' $SOAR_URL/api/integrations"
        if "action" in q:
            return "I'll list actions.\n\nTOOL: soar curl -s -H 'Authorization: Bearer $SOAR_API_KEY' $SOAR_URL/api/actions"
        return "I'll check SOAR status.\n\nTOOL: soar curl -s -H 'Authorization: Bearer $SOAR_API_KEY' $SOAR_URL/api/health"
