"""CSPM (Cloud Security Posture Management) Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CSPMAgent(ShellAgent):
    """Agent for CSPM investigation."""

    COMMAND_PREFIX = ["az", "security"]
    TOOL_NAME = "cspm"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "secure-score list", "secure-score-controls list",
        "assessment list", "sub-assessment list", "alert list",
        "recommendation list", "pricing list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "assessment-metadata create", "auto-provisioning-setting update",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cspm_type = config.get("cspm_type", "defender")  # defender, prisma, lacework
        self.subscription = config.get("subscription")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        cspm = self.cspm_type.title()
        return f"""You are a CSPM investigation agent for {cspm}.

Subscription: {self.subscription or 'current'}

Available tools:
- cspm: Execute read-only CSPM commands
- cspm_write: Execute remediations (requires approval)

Investigation approach for Azure Defender:
1. Secure Score: az security secure-score list
2. Controls: az security secure-score-controls list
3. Assessments: az security assessment list
4. Alerts: az security alert list
5. Recommendations: az security recommendation list

Posture categories:
- Identity & Access: IAM misconfigurations
- Network Security: Exposure risks
- Data Protection: Encryption gaps
- Compute: VM vulnerabilities
- Storage: Bucket/blob misconfigs

Secure score:
- Current score: Percentage achieved
- Max score: Total possible
- Control scores: Per-category breakdown

Common issues:
- Public exposure: Resources internet-facing
- Missing encryption: Data at rest/transit
- Excessive permissions: Overprivileged access
- Logging gaps: Missing audit trails
- Patch delays: Unpatched systems
- Config drift: Non-compliant settings"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "score" in q:
            return "I'll check secure score.\n\nTOOL: cspm az security secure-score list --output json"
        if "control" in q:
            return "I'll list security controls.\n\nTOOL: cspm az security secure-score-controls list --output json"
        if "assessment" in q:
            return "I'll list assessments.\n\nTOOL: cspm az security assessment list --output json"
        if "alert" in q:
            return "I'll list security alerts.\n\nTOOL: cspm az security alert list --output json"
        if "recommendation" in q:
            return "I'll list recommendations.\n\nTOOL: cspm az security recommendation list --output json"
        return "I'll check secure score.\n\nTOOL: cspm az security secure-score list --output json"
