"""CWPP (Cloud Workload Protection Platform) Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CWPPAgent(ShellAgent):
    """Agent for CWPP investigation."""

    COMMAND_PREFIX = ["twistcli"]
    TOOL_NAME = "cwpp"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "images", "hosts", "containers", "registry",
        "vulnerabilities", "compliance", "runtime",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "quarantine", "block", "delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cwpp_type = config.get("cwpp_type", "prisma")  # prisma, aqua, twistlock
        self.api_url = config.get("api_url")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        cwpp = self.cwpp_type.title()
        return f"""You are a CWPP investigation agent for {cwpp} Cloud.

API URL: {self.api_url or 'not configured'}

Available tools:
- cwpp: Execute read-only workload protection commands
- cwpp_write: Execute actions (requires approval)

Investigation approach:
1. Images: List container images and vulnerabilities
2. Hosts: Check host security posture
3. Containers: Running container analysis
4. Registry: Image registry scanning
5. Compliance: Compliance check results
6. Runtime: Runtime protection events

Image analysis:
- Vulnerabilities: CVEs in base images/packages
- Compliance: CIS benchmark violations
- Malware: Detected malicious content
- Secrets: Embedded credentials

Runtime protection:
- Process monitoring: Unexpected processes
- Network activity: Anomalous connections
- File integrity: Unauthorized changes
- Crypto mining: Detection

Common issues:
- Vulnerable images: Unpatched CVEs
- Non-compliant configs: CIS violations
- Runtime threats: Detected attacks
- Defender gaps: Unprotected workloads
- Registry risks: Insecure images
- Outdated agents: Stale protection"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "image" in q:
            return "I'll list images.\n\nTOOL: cwpp curl -s -H 'Authorization: Bearer $CWPP_TOKEN' $CWPP_URL/api/v1/images"
        if "host" in q:
            return "I'll check hosts.\n\nTOOL: cwpp curl -s -H 'Authorization: Bearer $CWPP_TOKEN' $CWPP_URL/api/v1/hosts"
        if "container" in q:
            return "I'll list containers.\n\nTOOL: cwpp curl -s -H 'Authorization: Bearer $CWPP_TOKEN' $CWPP_URL/api/v1/containers"
        if "vuln" in q:
            return "I'll check vulnerabilities.\n\nTOOL: cwpp curl -s -H 'Authorization: Bearer $CWPP_TOKEN' $CWPP_URL/api/v1/vulnerabilities"
        if "compliance" in q:
            return "I'll check compliance.\n\nTOOL: cwpp curl -s -H 'Authorization: Bearer $CWPP_TOKEN' $CWPP_URL/api/v1/compliance"
        if "runtime" in q:
            return "I'll check runtime events.\n\nTOOL: cwpp curl -s -H 'Authorization: Bearer $CWPP_TOKEN' $CWPP_URL/api/v1/runtime/events"
        return "I'll check image vulnerabilities.\n\nTOOL: cwpp curl -s -H 'Authorization: Bearer $CWPP_TOKEN' $CWPP_URL/api/v1/images?vulnerabilities=true"
