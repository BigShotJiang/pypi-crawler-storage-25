"""WAF (Web Application Firewall) Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class WAFAgent(ShellAgent):
    """Agent for WAF investigation."""

    COMMAND_PREFIX = ["aws", "wafv2"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-web-acls", "get-web-acl", "list-rules", "get-rule",
        "list-ip-sets", "get-ip-set", "list-regex-pattern-sets",
        "get-sampled-requests", "list-logging-configurations",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-web-acl", "delete-web-acl", "update-web-acl",
        "create-rule", "delete-rule", "update-ip-set",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.waf_type = config.get("waf_type", "aws")  # aws, azure, cloudflare
        self.region = config.get("region", "us-east-1")
        self.scope = config.get("scope", "REGIONAL")  # REGIONAL or CLOUDFRONT
        self.web_acl_name = config.get("web_acl_name")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.waf_type == "aws":
            return ["aws", "wafv2", "--region", self.region]
        elif self.waf_type == "azure":
            return ["az", "network", "application-gateway", "waf-policy"]
        else:
            return ["curl", "-H", "Authorization: Bearer $CF_API_TOKEN"]

    def _get_system_prompt(self) -> str:
        waf_type = self.waf_type.upper()
        return f"""You are a WAF investigation agent for {waf_type} WAF.

Scope: {self.scope}
Web ACL: {self.web_acl_name or 'all'}

Available tools:
- aws/az/cf: Execute read-only WAF commands
- aws_write: Execute write commands (requires approval)

Investigation approach for AWS WAF:
1. List Web ACLs: aws wafv2 list-web-acls --scope {self.scope}
2. Get Web ACL: aws wafv2 get-web-acl --name <name> --scope {self.scope} --id <id>
3. Sampled Requests: aws wafv2 get-sampled-requests --web-acl-arn <arn> --rule-metric-name <rule> --scope {self.scope}
4. IP Sets: aws wafv2 list-ip-sets --scope {self.scope}
5. Logging: aws wafv2 list-logging-configurations

Rule analysis:
- Managed rules: AWS managed rule groups (SQLi, XSS, etc.)
- Rate limiting: Request rate rules
- IP blocking: IP set rules
- Geo blocking: Geographic match rules
- Custom rules: Application-specific patterns

Common issues:
- Bypass: Rules not covering all attack vectors
- False positives: Legitimate traffic blocked
- Missing logging: No visibility into blocked requests
- Rate limits: Thresholds too high or too low
- Rule priority: Wrong rule evaluation order
- Scope mismatch: Regional vs CloudFront rules"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        scope = self.scope
        if "acl" in q or "list" in q:
            return f"I'll list web ACLs.\n\nTOOL: aws aws wafv2 list-web-acls --scope {scope}"
        if "rule" in q:
            return f"I'll check rules.\n\nTOOL: aws aws wafv2 get-web-acl --scope {scope} --name <acl-name> --id <acl-id>"
        if "block" in q or "sample" in q:
            return f"I'll check sampled requests.\n\nTOOL: aws aws wafv2 get-sampled-requests --scope {scope} --web-acl-arn <arn> --rule-metric-name ALL --time-window Start=<start>,End=<end>"
        if "ip" in q:
            return f"I'll list IP sets.\n\nTOOL: aws aws wafv2 list-ip-sets --scope {scope}"
        if "log" in q:
            return "I'll check logging configuration.\n\nTOOL: aws aws wafv2 list-logging-configurations"
        return f"I'll get WAF overview.\n\nTOOL: aws aws wafv2 list-web-acls --scope {scope}"
