"""Linux Security Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class LinuxSecurityAgent(ShellAgent):
    """Agent for Linux security investigation."""

    COMMAND_PREFIX = ["ssh"]
    TOOL_NAME = "ssh"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "auditctl -l", "ausearch", "aureport", "sestatus", "getenforce",
        "aa-status", "cat /etc/passwd", "cat /etc/shadow", "lastlog",
        "last", "who", "w", "ps aux", "netstat", "ss", "lsof",
        "find / -perm", "rpm -Va", "debsums", "rkhunter", "chkrootkit",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "rm", "chmod 777", "chown", "userdel", "passwd",
        "setenforce", "aa-disable", "iptables -F",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host")
        self.user = config.get("user", "root")
        self.key_file = config.get("key_file")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["ssh", "-o", "StrictHostKeyChecking=no"]
        if self.key_file:
            prefix.extend(["-i", self.key_file])
        prefix.append(f"{self.user}@{self.host}")
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Linux Security investigation agent for host '{self.host}'.

Available tools:
- ssh: Execute read-only security commands
- ssh_write: Execute write commands (requires approval)

Investigation approach:
1. Audit Logs: ausearch -ts recent | aureport
2. SELinux/AppArmor: sestatus / aa-status
3. User Activity: last, lastlog, who
4. Open Ports: ss -tlnp, netstat -tlnp
5. Running Processes: ps auxf
6. SUID/SGID Files: find / -perm /6000 -type f
7. Rootkit Scan: rkhunter --check, chkrootkit

Security checks:
- Failed logins: grep 'Failed password' /var/log/auth.log
- Sudo usage: grep sudo /var/log/auth.log
- New users: diff /etc/passwd with backup
- Modified binaries: rpm -Va or debsums
- Hidden processes: ps -ef vs /proc enumeration
- Unusual cron jobs: crontab -l, /etc/cron.*

Common issues:
- Weak SSH config: PermitRootLogin, PasswordAuthentication
- Missing patches: Unpatched kernel vulnerabilities
- SUID binaries: Exploitable setuid programs
- Open ports: Unnecessary services exposed
- Weak permissions: World-readable sensitive files
- No audit: auditd not configured"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "audit" in q or "log" in q:
            return "I'll check audit logs.\n\nTOOL: ssh ausearch -ts recent -i | head -50"
        if "selinux" in q:
            return "I'll check SELinux status.\n\nTOOL: ssh sestatus && getenforce"
        if "apparmor" in q:
            return "I'll check AppArmor status.\n\nTOOL: ssh aa-status"
        if "login" in q or "user" in q:
            return "I'll check user activity.\n\nTOOL: ssh last -n 20 && lastlog"
        if "rootkit" in q:
            return "I'll scan for rootkits.\n\nTOOL: ssh rkhunter --check --skip-keypress"
        if "suid" in q or "setuid" in q:
            return "I'll find SUID/SGID files.\n\nTOOL: ssh find / -perm /6000 -type f 2>/dev/null"
        if "port" in q or "listen" in q:
            return "I'll check listening ports.\n\nTOOL: ssh ss -tlnp"
        return "I'll perform a security overview.\n\nTOOL: ssh sestatus && last -n 10 && ss -tlnp"
