"""Security agents package.

Agents for security auditing and compliance:
- Quantum cryptography readiness
- IAM policy auditing
- RBAC analysis
- Vulnerability scanning
- K8s security
- Linux security
- TLS/Certificate management
- WAF management
- Secret management
"""

from agents.security.quantum_audit import (
    QuantumReadinessAgent,
    QuantumSafety,
    CryptoAsset,
    CryptoInventory,
    classify_algorithm,
    QUANTUM_VULNERABLE_ALGORITHMS,
    QUANTUM_SAFE_ALGORITHMS,
)
from agents.security.k8s_security import K8sSecurityAgent
from agents.security.linux_security import LinuxSecurityAgent
from agents.security.tls import TLSAgent
from agents.security.waf import WAFAgent
from agents.security.secret_manager import SecretManagerAgent
from agents.security.quantum_crypto import QuantumCryptoAgent
from agents.security.siem import SIEMAgent
from agents.security.soar import SOARAgent
from agents.security.vulnerability_scanner import VulnerabilityScannerAgent
from agents.security.compliance import ComplianceAgent
from agents.security.dlp import DLPAgent
from agents.security.casb import CASBAgent
from agents.security.cspm import CSPMAgent
from agents.security.cwpp import CWPPAgent
from agents.security.identity_governance import IdentityGovernanceAgent

__all__ = [
    # Quantum audit
    "QuantumReadinessAgent",
    "QuantumSafety",
    "CryptoAsset",
    "CryptoInventory",
    "classify_algorithm",
    "QUANTUM_VULNERABLE_ALGORITHMS",
    "QUANTUM_SAFE_ALGORITHMS",
    # Security agents
    "K8sSecurityAgent",
    "LinuxSecurityAgent",
    "TLSAgent",
    "WAFAgent",
    "SecretManagerAgent",
    "QuantumCryptoAgent",
    # Enterprise security agents
    "SIEMAgent",
    "SOARAgent",
    "VulnerabilityScannerAgent",
    "ComplianceAgent",
    "DLPAgent",
    "CASBAgent",
    "CSPMAgent",
    "CWPPAgent",
    "IdentityGovernanceAgent",
]
