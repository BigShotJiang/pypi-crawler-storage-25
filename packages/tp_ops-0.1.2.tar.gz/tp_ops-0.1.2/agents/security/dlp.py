"""DLP (Data Loss Prevention) Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class DLPAgent(ShellAgent):
    """Agent for DLP investigation."""

    COMMAND_PREFIX = ["gcloud", "dlp"]
    TOOL_NAME = "dlp"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "jobs list", "jobs describe", "inspect-templates list",
        "deidentify-templates list", "stored-info-types list",
        "triggers list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "jobs create", "jobs delete", "jobs cancel",
        "inspect-templates create", "inspect-templates delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.dlp_type = config.get("dlp_type", "gcp")  # gcp, microsoft, symantec
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        dlp_type = self.dlp_type.upper()
        return f"""You are a DLP investigation agent for {dlp_type} DLP.

Project: {self.project or 'current'}

Available tools:
- dlp: Execute read-only DLP commands
- dlp_write: Execute scans/actions (requires approval)

Investigation approach for GCP DLP:
1. Jobs: gcloud dlp jobs list
2. Job Details: gcloud dlp jobs describe <job-id>
3. Templates: gcloud dlp inspect-templates list
4. Triggers: gcloud dlp triggers list
5. Info Types: gcloud dlp stored-info-types list

Sensitive data types:
- PII: Names, addresses, phone numbers
- Financial: Credit cards, bank accounts
- Health: Medical records, conditions
- Credentials: API keys, passwords
- Government: SSN, passport numbers

Finding likelihood:
- VERY_LIKELY: High confidence match
- LIKELY: Probable match
- POSSIBLE: Potential match
- UNLIKELY: Low confidence
- VERY_UNLIKELY: Minimal risk

Common issues:
- False positives: Incorrect detections
- Coverage gaps: Unscanned data stores
- Policy violations: Sensitive data exposure
- Remediation delays: Unaddressed findings
- Template errors: Misconfigured rules
- Performance impact: Slow scans"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        project = self.project or "<project>"
        if "job" in q:
            return f"I'll list DLP jobs.\n\nTOOL: dlp gcloud dlp jobs list --project={project} --format=json"
        if "template" in q:
            return f"I'll list inspect templates.\n\nTOOL: dlp gcloud dlp inspect-templates list --project={project} --format=json"
        if "trigger" in q:
            return f"I'll list triggers.\n\nTOOL: dlp gcloud dlp triggers list --project={project} --format=json"
        if "finding" in q or "result" in q:
            return f"I'll check job findings.\n\nTOOL: dlp gcloud dlp jobs describe <job-id> --project={project} --format=json"
        if "info" in q or "type" in q:
            return f"I'll list info types.\n\nTOOL: dlp gcloud dlp stored-info-types list --project={project} --format=json"
        return f"I'll list DLP jobs.\n\nTOOL: dlp gcloud dlp jobs list --project={project} --format=json"
