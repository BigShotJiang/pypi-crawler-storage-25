"""Prometheus Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class PrometheusAgent(ShellAgent):
    """Agent for Prometheus server investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "promql"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = ["query", "query_range", "series", "labels", "targets", "rules", "alerts"]
    DANGEROUS_SUBCOMMANDS = ["admin/tsdb/delete_series", "admin/tsdb/clean_tombstones"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 9090)
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["curl", "-s", f"http://{self.host}:{self.port}/api/v1"]

    def _get_system_prompt(self) -> str:
        return f"""You are a Prometheus investigation agent for {self.host}:{self.port}.

Available tools:
- promql: Execute PromQL queries via API
- promql_write: Execute admin commands (requires approval)

Investigation approach:
1. Targets: /api/v1/targets
2. Rules: /api/v1/rules
3. Alerts: /api/v1/alerts
4. TSDB Status: /api/v1/status/tsdb
5. Query: /api/v1/query?query=...

Common issues:
- Scrape failures: Check target health
- Storage: Check TSDB stats
- High cardinality: Check series count
- Alert rule errors: Check rules endpoint
- Query performance: Complex PromQL"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "target" in q or "scrape" in q:
            return f"I'll check targets.\n\nTOOL: promql curl -s 'http://{self.host}:{self.port}/api/v1/targets' | jq '.data.activeTargets[] | {{job: .labels.job, health: .health}}'"
        if "alert" in q:
            return f"I'll check alerts.\n\nTOOL: promql curl -s 'http://{self.host}:{self.port}/api/v1/alerts'"
        if "rule" in q:
            return f"I'll check rules.\n\nTOOL: promql curl -s 'http://{self.host}:{self.port}/api/v1/rules'"
        if "tsdb" in q or "storage" in q:
            return f"I'll check TSDB status.\n\nTOOL: promql curl -s 'http://{self.host}:{self.port}/api/v1/status/tsdb'"
        return f"I'll check Prometheus targets.\n\nTOOL: promql curl -s 'http://{self.host}:{self.port}/api/v1/targets'"
