"""Elasticsearch Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class ElasticsearchAgent(DatabaseAgent):
    """Agent for Elasticsearch investigation."""

    DB_TYPE = DatabaseType.ELASTICSEARCH
    DEFAULT_PORT = 9200
    SAFE_QUERIES = ["_search", "_cat", "_cluster", "_nodes", "_stats"]
    DANGEROUS_QUERIES = ["_delete", "_bulk", "_reindex", "_close", "_open"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.index = config.get("index")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "cluster_health": "GET /_cluster/health",
            "nodes_stats": "GET /_nodes/stats",
            "indices_stats": "GET /_cat/indices?v&s=store.size:desc",
            "shards": "GET /_cat/shards?v",
            "pending_tasks": "GET /_cluster/pending_tasks",
            "thread_pool": "GET /_cat/thread_pool?v",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are an Elasticsearch investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute read-only Elasticsearch API calls
- query_write: Execute write operations (requires approval)

Investigation approach:
1. Cluster Health: GET /_cluster/health
2. Node Stats: GET /_nodes/stats
3. Index Stats: GET /_cat/indices?v
4. Shards: GET /_cat/shards?v
5. Tasks: GET /_cat/tasks?v

Common issues:
- Cluster red/yellow: Unassigned shards
- Indexing lag: Check thread pool queues
- Search latency: Check query cache, segment count
- Disk pressure: Check watermarks
- Circuit breaker: Check fielddata usage"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "health" in q or "status" in q:
            return "I'll check cluster health.\n\nTOOL: query GET /_cluster/health?pretty"
        if "shard" in q:
            return "I'll check shards.\n\nTOOL: query GET /_cat/shards?v"
        if "index" in q:
            return "I'll check indices.\n\nTOOL: query GET /_cat/indices?v&s=store.size:desc"
        if "node" in q:
            return "I'll check nodes.\n\nTOOL: query GET /_cat/nodes?v"
        if "slow" in q or "latency" in q:
            return "I'll check thread pools.\n\nTOOL: query GET /_cat/thread_pool?v"
        return "I'll check cluster status.\n\nTOOL: query GET /_cluster/health?pretty"
