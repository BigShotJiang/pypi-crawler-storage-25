"""Google Cloud SQL Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CloudSQLAgent(ShellAgent):
    """Agent for Google Cloud SQL investigation."""

    COMMAND_PREFIX = ["gcloud", "sql"]
    TOOL_NAME = "gcloud"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "instances describe", "instances list",
        "databases list", "users list",
        "operations list", "backups list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "instances create", "instances delete", "instances restart",
        "instances patch", "instances failover",
        "databases create", "databases delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.instance = config.get("instance")
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["gcloud", "sql"]
        if self.project:
            prefix.extend(["--project", self.project])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Google Cloud SQL investigation agent for '{self.instance}'.

Available tools:
- gcloud: Execute read-only Cloud SQL commands
- gcloud_write: Execute write commands (requires approval)

Investigation approach:
1. Instance: gcloud sql instances describe {self.instance}
2. Databases: gcloud sql databases list -i {self.instance}
3. Operations: gcloud sql operations list -i {self.instance}
4. Backups: gcloud sql backups list -i {self.instance}

Common issues:
- Connection limits: Check max_connections
- Storage: Check disk utilization
- HA failover: Check operations
- Maintenance: Check maintenance window"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "database" in q:
            return f"I'll list databases.\n\nTOOL: gcloud sql databases list -i {self.instance} --format=json"
        if "backup" in q:
            return f"I'll check backups.\n\nTOOL: gcloud sql backups list -i {self.instance} --format=json"
        if "operation" in q:
            return f"I'll check operations.\n\nTOOL: gcloud sql operations list -i {self.instance} --limit=20 --format=json"
        return f"I'll describe the instance.\n\nTOOL: gcloud sql instances describe {self.instance} --format=json"
