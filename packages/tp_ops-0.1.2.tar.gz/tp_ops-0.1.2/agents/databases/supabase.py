"""Supabase Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SupabaseAgent(ShellAgent):
    """Agent for Supabase project investigation."""

    COMMAND_PREFIX = ["supabase"]
    TOOL_NAME = "supabase"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "status", "db diff", "db lint", "inspect db",
        "functions list", "secrets list", "projects list",
        "migration list", "branches list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "db reset", "db push", "migration repair",
        "functions delete", "secrets set", "secrets unset",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.project_id = config.get("project_id")
        self.project_ref = config.get("project_ref")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        project = self.project_id or "current"
        return f"""You are a Supabase investigation agent for project '{project}'.

Available tools:
- supabase: Execute read-only Supabase CLI commands
- psql: Direct PostgreSQL queries
- supabase_write: Execute write commands (requires approval)

Investigation approach:
1. Project Status: supabase status
2. Database Health: supabase inspect db
3. Database Lint: supabase db lint
4. Migrations: supabase migration list
5. Edge Functions: supabase functions list
6. Secrets: supabase secrets list

PostgreSQL checks (via underlying Postgres):
- Active queries: SELECT * FROM pg_stat_activity
- Table sizes: SELECT pg_size_pretty(pg_total_relation_size(tablename))
- Missing indexes: Check pg_stat_user_tables for seq_scans
- RLS policies: SELECT * FROM pg_policies

Common issues:
- RLS misconfiguration: Missing or incorrect policies
- Connection exhaustion: Too many pooler connections
- Missing indexes: Slow queries on large tables
- Edge function errors: Cold starts, timeouts
- Storage issues: Large file uploads, bucket policies
- Auth issues: JWT expiry, provider configuration
- Realtime issues: Channel subscription limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "status" in q:
            return "I'll check project status.\n\nTOOL: supabase supabase status"
        if "database" in q or "db" in q:
            return "I'll inspect the database.\n\nTOOL: supabase supabase inspect db"
        if "function" in q or "edge" in q:
            return "I'll list edge functions.\n\nTOOL: supabase supabase functions list"
        if "migration" in q:
            return "I'll list migrations.\n\nTOOL: supabase supabase migration list"
        if "rls" in q or "policy" in q:
            return "I'll check RLS policies.\n\nTOOL: supabase psql -c \"SELECT * FROM pg_policies\""
        return "I'll check Supabase status.\n\nTOOL: supabase supabase status"
