"""Vitess Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class VitessAgent(ShellAgent):
    """Agent for Vitess investigation."""

    COMMAND_PREFIX = ["vtctlclient"]
    TOOL_NAME = "vtctlclient"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "GetKeyspaces", "GetShards", "GetTablets", "GetTablet",
        "GetSrvKeyspace", "GetVSchema", "ListAllTablets",
        "VReplicationExec", "GetRoutingRules",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "DeleteKeyspace", "DeleteShard", "DeleteTablet",
        "InitShardPrimary", "ReparentShard", "PlannedReparentShard",
        "EmergencyReparentShard", "Reshard", "MoveTables",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.vtctld = config.get("vtctld", "localhost:15999")
        self.keyspace = config.get("keyspace")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["vtctlclient", "-server", self.vtctld]

    def _get_system_prompt(self) -> str:
        return f"""You are a Vitess investigation agent for cluster at '{self.vtctld}'.

Available tools:
- vtctlclient: Execute read-only Vitess commands
- vtctlclient_write: Execute write commands (requires approval)

Investigation approach:
1. Keyspaces: vtctlclient GetKeyspaces
2. Shards: vtctlclient GetShards {self.keyspace or '<keyspace>'}
3. Tablets: vtctlclient ListAllTablets
4. VReplication: Check workflow status
5. VSchema: vtctlclient GetVSchema {self.keyspace or '<keyspace>'}

Common issues:
- VReplication lag: Check workflow status
- Tablet health: Check tablet status
- Resharding: Monitor reshard progress
- Query routing: Check VSchema"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "keyspace" in q:
            return "I'll list keyspaces.\n\nTOOL: vtctlclient GetKeyspaces"
        if "shard" in q:
            return f"I'll check shards.\n\nTOOL: vtctlclient GetShards {self.keyspace or ''}"
        if "tablet" in q:
            return "I'll list tablets.\n\nTOOL: vtctlclient ListAllTablets"
        if "vreplication" in q or "workflow" in q:
            return f"I'll check VReplication.\n\nTOOL: vtctlclient VReplicationExec {self.keyspace or ''} 'select * from _vt.vreplication'"
        return "I'll check keyspaces.\n\nTOOL: vtctlclient GetKeyspaces"
