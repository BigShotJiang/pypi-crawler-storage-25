"""DynamoDB Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class DynamoDBAgent(ShellAgent):
    """Agent for AWS DynamoDB investigation."""

    COMMAND_PREFIX = ["aws", "dynamodb"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "describe-table", "list-tables", "describe-limits",
        "describe-time-to-live", "describe-continuous-backups",
        "scan", "query", "get-item",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-table", "delete-table", "update-table",
        "put-item", "delete-item", "batch-write-item",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.table_name = config.get("table_name")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "dynamodb", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are a DynamoDB investigation agent for table '{self.table_name}'.

Available tools:
- aws: Execute read-only DynamoDB commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Table Details: aws dynamodb describe-table --table-name {self.table_name}
2. CloudWatch Metrics: Check ConsumedReadCapacity, ThrottledRequests
3. GSI Status: Check GlobalSecondaryIndexes in describe-table
4. Capacity: Check ProvisionedThroughput vs consumed

Common issues:
- Throttling: Hot partitions, exceeded capacity
- GSI lag: Check GSI backfill status
- Capacity issues: Right-size provisioned capacity
- Hot keys: Partition key design issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "throttl" in q:
            return f"I'll check table capacity.\n\nTOOL: aws dynamodb describe-table --table-name {self.table_name}"
        if "gsi" in q or "index" in q:
            return f"I'll check GSI status.\n\nTOOL: aws dynamodb describe-table --table-name {self.table_name} --query 'Table.GlobalSecondaryIndexes'"
        return f"I'll describe the table.\n\nTOOL: aws dynamodb describe-table --table-name {self.table_name}"
