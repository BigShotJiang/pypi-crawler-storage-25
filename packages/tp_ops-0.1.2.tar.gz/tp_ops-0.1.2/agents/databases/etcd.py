"""etcd Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class EtcdAgent(ShellAgent):
    """Agent for etcd investigation."""

    COMMAND_PREFIX = ["etcdctl"]
    TOOL_NAME = "etcdctl"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "endpoint status", "endpoint health", "member list",
        "get", "alarm list", "lease list", "watch",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "put", "del", "txn", "compact", "defrag",
        "member add", "member remove", "lease grant", "lease revoke",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.endpoints = config.get("endpoints", "localhost:2379")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["etcdctl", "--endpoints", self.endpoints]

    def _get_system_prompt(self) -> str:
        return f"""You are an etcd investigation agent for endpoints '{self.endpoints}'.

Available tools:
- etcdctl: Execute read-only etcdctl commands
- etcdctl_write: Execute write commands (requires approval)

Investigation approach:
1. Cluster Health: etcdctl endpoint health
2. Member Status: etcdctl member list
3. Endpoint Status: etcdctl endpoint status
4. Alarms: etcdctl alarm list
5. Key Space: etcdctl get --prefix / --keys-only | wc -l

Common issues:
- Leader election: Check endpoint status
- Compaction: DB size growing
- Disk latency: Slow fsync
- Peer communication: Network issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "health" in q:
            return "I'll check cluster health.\n\nTOOL: etcdctl endpoint health --cluster -w json"
        if "member" in q:
            return "I'll check members.\n\nTOOL: etcdctl member list -w json"
        if "status" in q:
            return "I'll check endpoint status.\n\nTOOL: etcdctl endpoint status --cluster -w json"
        if "alarm" in q:
            return "I'll check alarms.\n\nTOOL: etcdctl alarm list"
        if "leader" in q:
            return "I'll check leader.\n\nTOOL: etcdctl endpoint status --cluster -w json"
        return "I'll check cluster health.\n\nTOOL: etcdctl endpoint health --cluster -w json"
