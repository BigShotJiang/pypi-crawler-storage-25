"""Database agents for SQL, NoSQL, time-series, and search engines."""

from agents.databases.postgresql import PostgreSQLAgent
from agents.databases.redis import RedisAgent
from agents.databases.mysql import MySQLAgent
from agents.databases.sqlserver import SQLServerAgent
from agents.databases.mongodb import MongoDBAgent
from agents.databases.elasticsearch import ElasticsearchAgent
from agents.databases.cassandra import CassandraAgent
from agents.databases.dynamodb import DynamoDBAgent
from agents.databases.cockroachdb import CockroachDBAgent
from agents.databases.clickhouse import ClickHouseAgent
from agents.databases.timescaledb import TimescaleDBAgent
from agents.databases.influxdb import InfluxDBAgent
from agents.databases.prometheus_db import PrometheusAgent
from agents.databases.snowflake import SnowflakeAgent
from agents.databases.bigquery import BigQueryAgent
from agents.databases.azure_sql import AzureSQLAgent
from agents.databases.cosmosdb import CosmosDBAgent
from agents.databases.neo4j import Neo4jAgent
from agents.databases.etcd import EtcdAgent
from agents.databases.memcached import MemcachedAgent
from agents.databases.oracle import OracleDBAgent
from agents.databases.rds import RDSAgent
from agents.databases.cloudsql import CloudSQLAgent
from agents.databases.sqlite import SQLiteAgent
from agents.databases.vitess import VitessAgent
from agents.databases.citus import CitusAgent
from agents.databases.supabase import SupabaseAgent
from agents.databases.planetscale import PlanetScaleAgent
from agents.databases.valkey import ValkeyAgent
from agents.databases.couchdb import CouchDBAgent

__all__ = [
    "PostgreSQLAgent",
    "RedisAgent",
    "MySQLAgent",
    "SQLServerAgent",
    "MongoDBAgent",
    "ElasticsearchAgent",
    "CassandraAgent",
    "DynamoDBAgent",
    "CockroachDBAgent",
    "ClickHouseAgent",
    "TimescaleDBAgent",
    "InfluxDBAgent",
    "PrometheusAgent",
    "SnowflakeAgent",
    "BigQueryAgent",
    "AzureSQLAgent",
    "CosmosDBAgent",
    "Neo4jAgent",
    "EtcdAgent",
    "MemcachedAgent",
    "OracleDBAgent",
    "RDSAgent",
    "CloudSQLAgent",
    "SQLiteAgent",
    "VitessAgent",
    "CitusAgent",
    "SupabaseAgent",
    "PlanetScaleAgent",
    "ValkeyAgent",
    "CouchDBAgent",
]
