"""BigQuery Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class BigQueryAgent(ShellAgent):
    """Agent for Google BigQuery investigation."""

    COMMAND_PREFIX = ["bq"]
    TOOL_NAME = "bq"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = ["show", "ls", "query", "head"]
    DANGEROUS_SUBCOMMANDS = ["rm", "mk", "cp", "load", "insert"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.project = config.get("project")
        self.dataset = config.get("dataset")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["bq", "--format=json"]
        if self.project:
            prefix.extend(["--project_id", self.project])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a BigQuery investigation agent for project '{self.project}'.

Available tools:
- bq: Execute BigQuery CLI commands
- bq_write: Execute write commands (requires approval)

Investigation approach:
1. Jobs: bq ls -j --all
2. Tables: bq ls {self.dataset}
3. Query: bq query --use_legacy_sql=false 'SELECT ...'
4. Show Table: bq show {self.dataset}.table_name

Common issues:
- Slot consumption: Check job stats
- Query costs: Review bytes processed
- Dataset issues: Check access controls
- Performance: Partition/cluster optimization"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "job" in q:
            return "I'll check jobs.\n\nTOOL: bq ls -j --all --max_results=20"
        if "cost" in q:
            return "I'll check recent queries.\n\nTOOL: bq query --use_legacy_sql=false 'SELECT job_id, total_bytes_processed, total_slot_ms FROM `region-us`.INFORMATION_SCHEMA.JOBS_BY_PROJECT ORDER BY creation_time DESC LIMIT 20'"
        if "table" in q:
            return f"I'll list tables.\n\nTOOL: bq ls {self.dataset or ''}"
        return "I'll check BigQuery jobs.\n\nTOOL: bq ls -j --all --max_results=20"
