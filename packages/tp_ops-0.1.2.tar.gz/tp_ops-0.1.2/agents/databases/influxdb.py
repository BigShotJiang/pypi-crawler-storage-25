"""InfluxDB Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class InfluxDBAgent(ShellAgent):
    """Agent for InfluxDB investigation."""

    COMMAND_PREFIX = ["influx"]
    TOOL_NAME = "influx"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "query", "bucket list", "org list", "task list",
        "dashboards list", "auth list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete", "bucket create", "bucket delete",
        "write", "task create", "task delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 8086)
        self.org = config.get("org")
        self.bucket = config.get("bucket")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["influx", "--host", f"http://{self.host}:{self.port}"]

    def _get_system_prompt(self) -> str:
        return f"""You are an InfluxDB investigation agent for {self.host}:{self.port}.

Available tools:
- influx: Execute InfluxDB CLI commands
- influx_write: Execute write commands (requires approval)

Investigation approach:
1. Buckets: influx bucket list
2. Query: influx query 'from(bucket:"...")'
3. Tasks: influx task list
4. Cardinality: Check series cardinality
5. Write issues: Check for errors

Common issues:
- High cardinality: Tag explosion
- Write throughput: Rate limiting
- Query timeouts: Expensive queries
- Retention: Check retention policies"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "bucket" in q:
            return "I'll list buckets.\n\nTOOL: influx bucket list"
        if "task" in q:
            return "I'll check tasks.\n\nTOOL: influx task list"
        if "cardinal" in q or "series" in q:
            return f"I'll check cardinality.\n\nTOOL: influx query 'import \"influxdata/influxdb/v1\" v1.databases()'"
        return "I'll check InfluxDB status.\n\nTOOL: influx bucket list"
