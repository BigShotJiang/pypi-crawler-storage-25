"""SQLite Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class SQLiteAgent(DatabaseAgent):
    """Agent for SQLite database investigation."""

    DB_TYPE = DatabaseType.SQLITE
    DEFAULT_PORT = 0  # Local file
    SAFE_QUERIES = ["SELECT", ".schema", ".tables", "EXPLAIN", "PRAGMA"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT", "VACUUM"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.db_path = config.get("db_path")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "tables": ".tables",
            "schema": ".schema",
            "integrity": "PRAGMA integrity_check",
            "wal_checkpoint": "PRAGMA wal_checkpoint",
            "page_count": "PRAGMA page_count",
            "freelist_count": "PRAGMA freelist_count",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a SQLite investigation agent for database '{self.db_path}'.

Available tools:
- query: Execute read-only SQL/PRAGMA commands
- query_write: Execute write commands (requires approval)

Investigation approach:
1. Tables: .tables
2. Schema: .schema
3. Integrity: PRAGMA integrity_check
4. WAL: PRAGMA wal_checkpoint
5. Size: PRAGMA page_count, PRAGMA page_size

Common issues:
- Lock contention: Multiple writers
- WAL checkpoint: Checkpoint not happening
- Corruption: Run integrity_check
- Size growth: Need VACUUM"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "table" in q:
            return "I'll list tables.\n\nTOOL: query .tables"
        if "schema" in q:
            return "I'll show schema.\n\nTOOL: query .schema"
        if "integrity" in q or "corrupt" in q:
            return "I'll check integrity.\n\nTOOL: query PRAGMA integrity_check"
        if "wal" in q or "checkpoint" in q:
            return "I'll check WAL.\n\nTOOL: query PRAGMA wal_checkpoint"
        if "size" in q:
            return "I'll check database size.\n\nTOOL: query SELECT page_count * page_size as size FROM pragma_page_count(), pragma_page_size()"
        return "I'll check database info.\n\nTOOL: query PRAGMA integrity_check"
