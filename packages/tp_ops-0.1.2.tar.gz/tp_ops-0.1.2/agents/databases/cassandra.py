"""Cassandra Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class CassandraAgent(DatabaseAgent):
    """Agent for Apache Cassandra investigation."""

    DB_TYPE = DatabaseType.CASSANDRA
    DEFAULT_PORT = 9042
    SAFE_QUERIES = ["SELECT", "DESCRIBE", "nodetool status", "nodetool info"]
    DANGEROUS_QUERIES = ["DROP", "TRUNCATE", "DELETE", "UPDATE", "INSERT"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.keyspace = config.get("keyspace")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "cluster_status": "nodetool status",
            "table_stats": "nodetool tablestats",
            "thread_pool": "nodetool tpstats",
            "compaction": "nodetool compactionstats",
            "gossip": "nodetool gossipinfo",
            "repair": "nodetool netstats",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a Cassandra investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute CQL queries and nodetool commands
- query_write: Execute write operations (requires approval)

Investigation approach:
1. Cluster Status: nodetool status
2. Thread Pools: nodetool tpstats
3. Compaction: nodetool compactionstats
4. Table Stats: nodetool tablestats <keyspace>
5. Gossip: nodetool gossipinfo

Common issues:
- Read/write latency: Check compaction, tombstones
- Compaction backlog: nodetool compactionstats
- Gossip failures: Network issues, overloaded nodes
- Tombstone buildup: TTL data, deletes
- Repair backlog: nodetool netstats"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "status" in q or "node" in q:
            return "I'll check cluster status.\n\nTOOL: query nodetool status"
        if "compact" in q:
            return "I'll check compaction.\n\nTOOL: query nodetool compactionstats"
        if "thread" in q or "pool" in q:
            return "I'll check thread pools.\n\nTOOL: query nodetool tpstats"
        if "repair" in q:
            return "I'll check repair status.\n\nTOOL: query nodetool netstats"
        if "latency" in q or "slow" in q:
            return "I'll check table stats.\n\nTOOL: query nodetool tablestats"
        return "I'll check cluster status.\n\nTOOL: query nodetool status"
