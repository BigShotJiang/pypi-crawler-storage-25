"""Neo4j Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class Neo4jAgent(DatabaseAgent):
    """Agent for Neo4j graph database investigation."""

    DB_TYPE = DatabaseType.NEO4J
    DEFAULT_PORT = 7687
    SAFE_QUERIES = ["MATCH", "RETURN", "CALL", "SHOW"]
    DANGEROUS_QUERIES = ["CREATE", "DELETE", "DETACH DELETE", "SET", "REMOVE", "MERGE"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database", "neo4j")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "db_info": "CALL dbms.components() YIELD name, versions, edition",
            "memory": "CALL dbms.listPools()",
            "transactions": "CALL dbms.listTransactions()",
            "queries": "CALL dbms.listQueries()",
            "indexes": "SHOW INDEXES",
            "constraints": "SHOW CONSTRAINTS",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a Neo4j investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute read-only Cypher queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. DB Info: CALL dbms.components()
2. Memory: CALL dbms.listPools()
3. Transactions: CALL dbms.listTransactions()
4. Queries: CALL dbms.listQueries()
5. Indexes: SHOW INDEXES

Common issues:
- Query performance: Missing indexes
- Memory issues: Heap size, page cache
- Cluster sync: Check cluster status
- Unbounded traversals: Cartesian products"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "query" in q or "slow" in q:
            return "I'll check running queries.\n\nTOOL: query CALL dbms.listQueries() YIELD queryId, query, elapsedTimeMillis RETURN * ORDER BY elapsedTimeMillis DESC"
        if "index" in q:
            return "I'll check indexes.\n\nTOOL: query SHOW INDEXES"
        if "memory" in q:
            return "I'll check memory.\n\nTOOL: query CALL dbms.listPools()"
        if "transaction" in q:
            return "I'll check transactions.\n\nTOOL: query CALL dbms.listTransactions()"
        return "I'll check database info.\n\nTOOL: query CALL dbms.components() YIELD name, versions, edition RETURN *"
