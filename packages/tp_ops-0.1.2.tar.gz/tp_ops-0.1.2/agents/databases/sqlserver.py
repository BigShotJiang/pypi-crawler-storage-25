"""SQL Server Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class SQLServerAgent(DatabaseAgent):
    """Agent for Microsoft SQL Server investigation."""

    DB_TYPE = DatabaseType.SQLSERVER
    DEFAULT_PORT = 1433
    SAFE_QUERIES = ["SELECT", "EXEC sp_who", "EXEC sp_lock", "DBCC"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT", "CREATE"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "active_queries": "SELECT * FROM sys.dm_exec_requests WHERE status = 'running'",
            "blocking": "SELECT * FROM sys.dm_exec_requests WHERE blocking_session_id > 0",
            "wait_stats": "SELECT * FROM sys.dm_os_wait_stats ORDER BY wait_time_ms DESC",
            "index_usage": "SELECT * FROM sys.dm_db_index_usage_stats",
            "tempdb": "SELECT * FROM sys.dm_db_file_space_usage",
            "always_on": "SELECT * FROM sys.dm_hadr_availability_replica_states",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a SQL Server investigation agent for {self.host}.

Available tools:
- query: Execute read-only T-SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Active Queries: sys.dm_exec_requests
2. Blocking: Check blocking_session_id
3. Wait Stats: sys.dm_os_wait_stats
4. TempDB: sys.dm_db_file_space_usage
5. Always On: sys.dm_hadr_availability_replica_states

Common issues:
- Blocking chains: Long-running transactions
- TempDB contention: Version store, spills
- Query plan regression: Parameter sniffing
- Always On sync issues: Check replica states
- High CPU: Missing indexes, expensive queries"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "block" in q:
            return "I'll check for blocking.\n\nTOOL: query SELECT blocking_session_id, session_id, wait_type, wait_time FROM sys.dm_exec_requests WHERE blocking_session_id > 0"
        if "tempdb" in q:
            return "I'll check TempDB usage.\n\nTOOL: query SELECT * FROM sys.dm_db_file_space_usage"
        if "always on" in q or "replica" in q:
            return "I'll check Always On status.\n\nTOOL: query SELECT * FROM sys.dm_hadr_availability_replica_states"
        if "wait" in q:
            return "I'll check wait statistics.\n\nTOOL: query SELECT TOP 10 * FROM sys.dm_os_wait_stats ORDER BY wait_time_ms DESC"
        return "I'll check active queries.\n\nTOOL: query SELECT session_id, status, command, wait_type FROM sys.dm_exec_requests WHERE status = 'running'"
