"""Redis Investigation Agent.

Agent for investigating Redis databases:
- Memory usage and key analysis
- Slow command detection
- Client connections
- Replication and cluster health
- Key expiration patterns
"""

from typing import Any

from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType, REDIS_COMMANDS


class RedisAgent(DatabaseAgent):
    """Agent for Redis investigation.

    Inherits from DatabaseAgent, providing:
    - redis: Read-only commands
    - redis_write: Write commands (requires approval)
    """

    # DatabaseAgent configuration
    DB_TYPE = DatabaseType.REDIS
    DEFAULT_PORT = 6379
    CLI_COMMAND = "redis-cli"
    TOOL_NAME = "redis"
    COMMAND_TIMEOUT = 30

    # Command validation
    SAFE_OPERATIONS = [
        "GET", "MGET", "KEYS", "SCAN", "TYPE", "TTL", "PTTL",
        "EXISTS", "DBSIZE", "INFO", "DEBUG OBJECT",
        "SLOWLOG", "CLIENT LIST", "CLIENT INFO",
        "MEMORY", "OBJECT", "LLEN", "SCARD", "ZCARD", "HLEN",
        "LRANGE", "SMEMBERS", "ZRANGE", "HGETALL", "HKEYS", "HVALS",
        "CLUSTER INFO", "CLUSTER NODES", "CLUSTER SLOTS",
        "CONFIG GET", "PING", "ECHO", "TIME",
    ]
    DANGEROUS_OPERATIONS = [
        "DEL", "UNLINK", "FLUSHDB", "FLUSHALL",
        "SET", "MSET", "SETEX", "SETNX", "APPEND",
        "LPUSH", "RPUSH", "LPOP", "RPOP", "LSET", "LREM",
        "SADD", "SREM", "SPOP", "SMOVE",
        "ZADD", "ZREM", "ZINCRBY",
        "HSET", "HMSET", "HDEL", "HINCRBY",
        "EXPIRE", "EXPIREAT", "PERSIST",
        "RENAME", "RENAMENX", "MOVE", "COPY",
        "SHUTDOWN", "BGSAVE", "BGREWRITEAOF",
        "CONFIG SET", "CONFIG REWRITE",
        "DEBUG", "SCRIPT", "EVAL", "EVALSHA",
        "MIGRATE", "DUMP", "RESTORE",
    ]

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal,
        llm=None,
    ):
        """Initialize Redis Agent.

        Args:
            name: Agent name (typically instance name)
            config: Configuration dict with:
                - host: Redis host (default: localhost)
                - port: Redis port (default: 6379)
                - password: Redis password (optional)
                - database: Database number (default: 0)
            terminal: Terminal for output
            llm: Optional LLM client
        """
        # Redis-specific config
        self.password = config.get("password")
        self.db_number = config.get("database", 0)
        super().__init__(name, config, terminal, llm)

    def _build_cli_command(self, command: str) -> list[str]:
        """Build redis-cli command for execution."""
        cmd = [self.CLI_COMMAND]

        # Connection parameters
        if self.host:
            cmd.extend(["-h", self.host])
        if self.port:
            cmd.extend(["-p", str(self.port)])
        if self.password:
            cmd.extend(["-a", self.password])
        if self.db_number:
            cmd.extend(["-n", str(self.db_number)])

        # Add the actual command (split into parts)
        cmd.extend(command.split())

        return cmd

    def _build_explain_query(self, command: str) -> str:
        """Build debug command for Redis.

        Redis doesn't have EXPLAIN, but we can use DEBUG OBJECT for keys
        or SLOWLOG for command analysis.
        """
        parts = command.upper().split()
        if len(parts) >= 2 and parts[0] in ("GET", "TYPE", "TTL"):
            # For key commands, use DEBUG OBJECT
            key = command.split()[1]
            return f"DEBUG OBJECT {key}"

        # For other commands, show recent slow queries
        return "SLOWLOG GET 10"

    def _get_performance_queries(self) -> dict[str, str]:
        """Get Redis performance queries."""
        return REDIS_COMMANDS

    def _get_memory_sql(self) -> str:
        """Get memory stats command."""
        return "INFO memory"

    def _get_clients_sql(self) -> str:
        """Get client list command."""
        return "CLIENT LIST"

    def _get_slowlog_sql(self) -> str:
        """Get slow log command."""
        return "SLOWLOG GET 25"

    def _get_keyspace_sql(self) -> str:
        """Get keyspace stats command."""
        return "INFO keyspace"

    def _get_replication_sql(self) -> str:
        """Get replication status command."""
        return "INFO replication"

    def _get_system_prompt(self) -> str:
        """System prompt for Redis investigation."""
        return f"""You are a Redis investigation agent for {self.name} on {self.host}:{self.port}.

Available tools:
- redis: Execute read-only Redis commands
- redis_write: Execute write commands (requires human approval)
- explain: Analyze key/command performance

Investigation approach:
1. **Memory Analysis**: INFO memory, MEMORY STATS, MEMORY DOCTOR
2. **Key Analysis**: SCAN for patterns, TYPE, TTL, OBJECT ENCODING
3. **Slow Commands**: SLOWLOG GET, CLIENT LIST for long-running commands
4. **Connections**: CLIENT LIST, INFO clients
5. **Replication**: INFO replication, check lag
6. **Cluster**: CLUSTER INFO, CLUSTER NODES (if clustered)

Common Redis issues:
- **Memory pressure**: Large keys, no eviction policy, memory fragmentation
- **Slow commands**: KEYS *, large HGETALL, blocking operations
- **Connection exhaustion**: Too many clients, connection leaks
- **Replication lag**: Network issues, slow replica
- **Hot keys**: High frequency access to same key
- **Big keys**: Keys with millions of elements

Useful commands:
- MEMORY USAGE <key>: Size of a specific key
- OBJECT ENCODING <key>: Internal encoding
- DEBUG OBJECT <key>: Detailed key info
- SCAN 0 COUNT 100: Iterate keys safely (never use KEYS in production)
- SLOWLOG GET 10: Recent slow commands

Always explain findings and suggest specific actions."""

    def _mock_response(self, query: str) -> str:
        """Generate mock response for Redis queries."""
        q = query.lower()

        if "memory" in q or "usage" in q:
            return f"""I'll check memory usage on this Redis instance.

TOOL: redis INFO memory"""

        if "slow" in q or "performance" in q or "latency" in q:
            return f"""I'll check for slow commands in the slowlog.

TOOL: redis SLOWLOG GET 10"""

        if "client" in q or "connection" in q:
            return f"""I'll check connected clients.

TOOL: redis CLIENT LIST"""

        if "key" in q or "scan" in q or "pattern" in q:
            return f"""I'll scan for keys. Using SCAN instead of KEYS for safety.

TOOL: redis SCAN 0 COUNT 100"""

        if "replication" in q or "replica" in q or "slave" in q:
            return f"""I'll check replication status.

TOOL: redis INFO replication"""

        if "cluster" in q:
            return f"""I'll check cluster status.

TOOL: redis CLUSTER INFO"""

        if "big" in q or "large" in q:
            return f"""I'll check for large keys. First, let me sample the keyspace.

TOOL: redis DEBUG OBJECT <key>"""

        if "ttl" in q or "expir" in q:
            return f"""I'll check keyspace for TTL distribution.

TOOL: redis INFO keyspace"""

        # Default response
        return f"""I'll help investigate this Redis instance ({self.name}).

Let me start by checking the overall status.

TOOL: redis INFO"""

    def _mock_continuation(self, tool_output: str) -> str:
        """Generate mock continuation based on Redis output."""
        output_lower = tool_output.lower()

        if "used_memory" in output_lower:
            return """I've gathered the memory statistics.

**Analysis:**
- Check `used_memory_human` for current usage
- Compare `used_memory_rss` to `used_memory` for fragmentation
- Look at `mem_fragmentation_ratio` (should be < 1.5)

**Recommendations:**
1. If fragmentation is high, consider `MEMORY PURGE` or restart
2. For memory pressure, review eviction policy (`maxmemory-policy`)
3. Check for large keys that could be optimized

Would you like me to identify the largest keys?"""

        if "slowlog" in output_lower or "time=" in output_lower:
            return """I've retrieved the slow log entries.

**Analysis:**
- Commands taking > 10ms appear in the slowlog
- Look for patterns: KEYS *, large HGETALL, blocking commands
- Check timestamps for correlation with incidents

**Recommendations:**
1. Replace KEYS with SCAN for production safety
2. Use pipelines for multiple commands
3. Consider data structure optimization for large collections

Would you like me to analyze specific slow commands?"""

        if "addr=" in output_lower and "cmd=" in output_lower:
            return """I've listed the connected clients.

**Analysis:**
- Check client count against `maxclients`
- Look for clients with high `age` and no recent command
- Identify clients with large `omem` (output buffer)

**Recommendations:**
1. Set appropriate client timeout
2. Review connection pooling in applications
3. Monitor for connection leaks

Would you like me to check client statistics?"""

        if "role:" in output_lower:
            return """I've gathered replication information.

**Analysis:**
- Check `master_link_status` should be "up"
- Monitor `master_last_io_seconds_ago`
- Look at `slave_repl_offset` lag

**Recommendations:**
1. If lag is high, check network between master/replica
2. Monitor `repl_backlog_size` for disconnect tolerance
3. Consider read replicas for read-heavy workloads

Would you like me to investigate replication lag further?"""

        if "cluster_state:" in output_lower:
            return """I've gathered cluster information.

**Analysis:**
- `cluster_state` should be "ok"
- Check `cluster_slots_assigned` (should be 16384)
- Monitor `cluster_known_nodes`

**Recommendations:**
1. If slots are missing, check for failed nodes
2. Use CLUSTER SLOTS to see slot distribution
3. Monitor cross-node latency

Would you like me to check specific cluster nodes?"""

        # Default response
        return """Query completed. Based on the results, I can:

1. Dig deeper into memory usage patterns
2. Analyze slow commands
3. Check key distribution and big keys
4. Monitor replication or cluster health

What would you like me to investigate further?"""
