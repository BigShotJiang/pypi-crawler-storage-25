"""Citus (Distributed PostgreSQL) Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class CitusAgent(DatabaseAgent):
    """Agent for Citus distributed PostgreSQL investigation."""

    DB_TYPE = DatabaseType.CITUS
    DEFAULT_PORT = 5432
    SAFE_QUERIES = ["SELECT", "SHOW", "EXPLAIN"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "nodes": "SELECT * FROM pg_dist_node",
            "shards": "SELECT * FROM pg_dist_shard",
            "placements": "SELECT * FROM pg_dist_placement",
            "dist_tables": "SELECT * FROM citus_tables",
            "active_queries": "SELECT * FROM citus_dist_stat_activity",
            "rebalance": "SELECT * FROM get_rebalance_progress()",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a Citus investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute read-only SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Nodes: pg_dist_node
2. Shards: pg_dist_shard
3. Placements: pg_dist_placement
4. Distributed Tables: citus_tables
5. Active Queries: citus_dist_stat_activity

Common issues:
- Distributed query performance: Cross-shard queries
- Shard rebalancing: Check rebalance progress
- Coordinator bottleneck: Check coordinator load
- Node failures: Check node status"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "node" in q:
            return "I'll check nodes.\n\nTOOL: query SELECT nodeid, nodename, nodeport, isactive FROM pg_dist_node"
        if "shard" in q:
            return "I'll check shards.\n\nTOOL: query SELECT logicalrelid, shardid, shardminvalue, shardmaxvalue FROM pg_dist_shard LIMIT 50"
        if "table" in q:
            return "I'll check distributed tables.\n\nTOOL: query SELECT * FROM citus_tables"
        if "query" in q or "active" in q:
            return "I'll check active queries.\n\nTOOL: query SELECT * FROM citus_dist_stat_activity WHERE state = 'active'"
        if "rebalance" in q:
            return "I'll check rebalance progress.\n\nTOOL: query SELECT * FROM get_rebalance_progress()"
        return "I'll check cluster nodes.\n\nTOOL: query SELECT * FROM pg_dist_node"
