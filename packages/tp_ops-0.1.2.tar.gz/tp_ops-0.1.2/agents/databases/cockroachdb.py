"""CockroachDB Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class CockroachDBAgent(DatabaseAgent):
    """Agent for CockroachDB investigation."""

    DB_TYPE = DatabaseType.COCKROACHDB
    DEFAULT_PORT = 26257
    SAFE_QUERIES = ["SELECT", "SHOW", "EXPLAIN"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "cluster_status": "SHOW CLUSTER SETTING",
            "nodes": "SELECT * FROM crdb_internal.gossip_nodes",
            "ranges": "SELECT * FROM crdb_internal.ranges LIMIT 50",
            "jobs": "SHOW JOBS",
            "sessions": "SHOW SESSIONS",
            "statements": "SELECT * FROM crdb_internal.node_statement_statistics ORDER BY count DESC LIMIT 20",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a CockroachDB investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute read-only SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Cluster Status: SHOW CLUSTER SETTING
2. Nodes: crdb_internal.gossip_nodes
3. Sessions: SHOW SESSIONS
4. Statements: crdb_internal.node_statement_statistics
5. Ranges: crdb_internal.ranges

Common issues:
- Range hotspots: Check range distribution
- Leaseholder imbalance: Check lease distribution
- Transaction contention: Check contention stats
- Node failures: Check node status"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "node" in q:
            return "I'll check node status.\n\nTOOL: query SELECT node_id, address, is_live FROM crdb_internal.gossip_nodes"
        if "range" in q or "hotspot" in q:
            return "I'll check ranges.\n\nTOOL: query SELECT range_id, start_key, lease_holder FROM crdb_internal.ranges LIMIT 50"
        if "session" in q or "connect" in q:
            return "I'll check sessions.\n\nTOOL: query SHOW SESSIONS"
        return "I'll check cluster status.\n\nTOOL: query SELECT * FROM crdb_internal.gossip_nodes"
