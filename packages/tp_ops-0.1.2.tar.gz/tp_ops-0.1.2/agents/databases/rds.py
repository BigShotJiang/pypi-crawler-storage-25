"""AWS RDS Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class RDSAgent(ShellAgent):
    """Agent for AWS RDS investigation."""

    COMMAND_PREFIX = ["aws", "rds"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "describe-db-instances", "describe-db-clusters",
        "describe-events", "describe-db-log-files", "download-db-log-file-portion",
        "describe-db-snapshots", "describe-db-parameter-groups",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-db-instance", "delete-db-instance", "modify-db-instance",
        "reboot-db-instance", "start-db-instance", "stop-db-instance",
        "failover-db-cluster", "create-db-snapshot",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.db_identifier = config.get("db_identifier")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "rds", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are an AWS RDS investigation agent for '{self.db_identifier}'.

Available tools:
- aws: Execute read-only RDS commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Instance Details: aws rds describe-db-instances --db-instance-identifier {self.db_identifier}
2. Events: aws rds describe-events --source-identifier {self.db_identifier} --source-type db-instance
3. Logs: aws rds describe-db-log-files --db-instance-identifier {self.db_identifier}
4. Performance Insights: Use CloudWatch metrics

Common issues:
- Storage full: Check AllocatedStorage
- CPU/memory: Check PerformanceInsights
- Failover: Check events
- Replication lag: Check for read replica lag"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "event" in q:
            return f"I'll check events.\n\nTOOL: aws rds describe-events --source-identifier {self.db_identifier} --source-type db-instance --duration 1440"
        if "log" in q:
            return f"I'll check logs.\n\nTOOL: aws rds describe-db-log-files --db-instance-identifier {self.db_identifier}"
        if "snapshot" in q:
            return f"I'll check snapshots.\n\nTOOL: aws rds describe-db-snapshots --db-instance-identifier {self.db_identifier}"
        return f"I'll check instance details.\n\nTOOL: aws rds describe-db-instances --db-instance-identifier {self.db_identifier}"
