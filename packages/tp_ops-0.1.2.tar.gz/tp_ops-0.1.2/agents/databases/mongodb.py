"""MongoDB Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class MongoDBAgent(DatabaseAgent):
    """Agent for MongoDB investigation."""

    DB_TYPE = DatabaseType.MONGODB
    DEFAULT_PORT = 27017
    SAFE_QUERIES = ["find", "aggregate", "count", "explain", "stats", "serverStatus"]
    DANGEROUS_QUERIES = ["drop", "delete", "remove", "update", "insert", "createIndex"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database")
        self.replica_set = config.get("replica_set")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "server_status": "db.serverStatus()",
            "current_op": "db.currentOp()",
            "repl_status": "rs.status()",
            "collection_stats": "db.collection.stats()",
            "profiler": "db.system.profile.find().sort({ts:-1}).limit(10)",
            "shard_status": "sh.status()",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a MongoDB investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute read-only MongoDB commands
- query_write: Execute write commands (requires approval)

Investigation approach:
1. Server Status: db.serverStatus()
2. Current Ops: db.currentOp()
3. Replication: rs.status()
4. Profiler: db.system.profile.find()
5. Sharding: sh.status()

Common issues:
- Slow queries: Missing indexes, collection scans
- Replication lag: Check rs.status().members[].optimeDate
- Shard imbalances: Check chunk distribution
- Connection storms: Check connections in serverStatus
- Memory pressure: Check wiredTiger cache"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "slow" in q:
            return "I'll check the profiler for slow queries.\n\nTOOL: query db.system.profile.find({millis:{$gt:100}}).sort({ts:-1}).limit(10)"
        if "replicat" in q or "lag" in q:
            return "I'll check replication status.\n\nTOOL: query rs.status()"
        if "shard" in q:
            return "I'll check shard status.\n\nTOOL: query sh.status()"
        if "connect" in q:
            return "I'll check connections.\n\nTOOL: query db.serverStatus().connections"
        if "index" in q:
            return "I'll check indexes.\n\nTOOL: query db.collection.getIndexes()"
        return "I'll check server status.\n\nTOOL: query db.serverStatus()"
