"""Valkey/KeyDB Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ValkeyAgent(ShellAgent):
    """Agent for Valkey/KeyDB investigation."""

    COMMAND_PREFIX = ["valkey-cli"]
    TOOL_NAME = "valkey"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "INFO", "DBSIZE", "KEYS", "SCAN", "CLIENT LIST",
        "SLOWLOG GET", "MEMORY STATS", "CLUSTER INFO",
        "CLUSTER NODES", "CONFIG GET", "DEBUG SLEEP",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "FLUSHDB", "FLUSHALL", "DEL", "SHUTDOWN",
        "CONFIG SET", "DEBUG SEGFAULT", "SLAVEOF",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 6379)
        self.password = config.get("password")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["valkey-cli", "-h", self.host, "-p", str(self.port)]
        if self.password:
            prefix.extend(["-a", self.password])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a Valkey/KeyDB investigation agent for {self.host}:{self.port}.

Valkey is a Redis-compatible, high-performance key-value store with multi-threading support.

Available tools:
- valkey: Execute read-only Valkey CLI commands
- valkey_write: Execute write commands (requires approval)

Investigation approach:
1. Server Info: INFO all
2. Memory Usage: MEMORY STATS
3. Client Connections: CLIENT LIST
4. Slow Commands: SLOWLOG GET 10
5. Keyspace: DBSIZE, SCAN
6. Cluster Status: CLUSTER INFO (if clustered)

Multi-threading analysis (Valkey/KeyDB specific):
- Thread utilization: Check server_threads in INFO
- IO threading: Check io_threads configuration
- Active threads: Monitor thread activity

Performance checks:
- Memory fragmentation: mem_fragmentation_ratio
- Eviction rate: evicted_keys
- Hit ratio: keyspace_hits / (keyspace_hits + keyspace_misses)
- Connected clients: connected_clients
- Blocked clients: blocked_clients

Common issues:
- Memory pressure: Used memory approaching maxmemory
- High latency: Slow commands blocking threads
- Connection exhaustion: Too many clients
- Replication lag: Master-replica sync delay
- Big keys: Large data structures causing latency
- Hot keys: Single keys with high access rate
- Thread contention: Multi-threaded bottlenecks"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "info" in q or "status" in q:
            return "I'll check server info.\n\nTOOL: valkey INFO all"
        if "memory" in q:
            return "I'll check memory stats.\n\nTOOL: valkey MEMORY STATS"
        if "slow" in q or "latency" in q:
            return "I'll check slow log.\n\nTOOL: valkey SLOWLOG GET 20"
        if "client" in q or "connection" in q:
            return "I'll check client connections.\n\nTOOL: valkey CLIENT LIST"
        if "cluster" in q:
            return "I'll check cluster status.\n\nTOOL: valkey CLUSTER INFO"
        if "key" in q:
            return "I'll scan keys.\n\nTOOL: valkey SCAN 0 COUNT 100"
        return "I'll check Valkey status.\n\nTOOL: valkey INFO"
