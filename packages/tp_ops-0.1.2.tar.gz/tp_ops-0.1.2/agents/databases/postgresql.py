"""PostgreSQL Investigation Agent.

Agent for investigating PostgreSQL databases:
- Slow queries and query plan analysis
- Connection and lock monitoring
- Table/index bloat detection
- Replication lag monitoring
- Vacuum and autovacuum status
"""

from typing import Any

from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType, POSTGRESQL_QUERIES


class PostgreSQLAgent(DatabaseAgent):
    """Agent for PostgreSQL investigation.

    Inherits from DatabaseAgent, providing:
    - query: Read-only SQL queries
    - query_write: Write queries (requires approval)
    - explain: Query plan analysis
    """

    # DatabaseAgent configuration
    DB_TYPE = DatabaseType.POSTGRESQL
    DEFAULT_PORT = 5432
    CLI_COMMAND = "psql"
    TOOL_NAME = "psql"
    COMMAND_TIMEOUT = 30

    # Query validation
    SAFE_OPERATIONS = [
        "SELECT", "SHOW", "EXPLAIN", "ANALYZE",
        "WITH",  # CTEs
        "TABLE",  # Shorthand for SELECT * FROM
        "VALUES",  # For testing
    ]
    DANGEROUS_OPERATIONS = [
        "DROP", "DELETE", "TRUNCATE", "ALTER", "CREATE",
        "INSERT", "UPDATE", "GRANT", "REVOKE",
        "VACUUM", "REINDEX", "CLUSTER",
    ]

    def __init__(
        self,
        name: str,
        config: dict[str, Any],
        terminal,
        llm=None,
    ):
        """Initialize PostgreSQL Agent.

        Args:
            name: Agent name (typically database name)
            config: Configuration dict with:
                - host: Database host (default: localhost)
                - port: Database port (default: 5432)
                - database: Database name
                - user: Database user
                - password: Database password (optional, uses .pgpass)
            terminal: Terminal for output
            llm: Optional LLM client
        """
        super().__init__(name, config, terminal, llm)

    def _build_cli_command(self, query: str) -> list[str]:
        """Build psql command for query execution."""
        cmd = [self.CLI_COMMAND]

        # Connection parameters
        if self.host:
            cmd.extend(["-h", self.host])
        if self.port:
            cmd.extend(["-p", str(self.port)])
        if self.database:
            cmd.extend(["-d", self.database])
        if self.user:
            cmd.extend(["-U", self.user])

        # Output formatting
        cmd.extend([
            "-A",  # Unaligned output
            "-t",  # Tuples only (no headers for simple queries)
            "-F", "|",  # Field separator
            "--no-psqlrc",  # Don't load psqlrc
            "-c", query,  # Command to execute
        ])

        return cmd

    def _build_explain_query(self, query: str) -> str:
        """Build EXPLAIN ANALYZE query for PostgreSQL."""
        if query.upper().startswith("EXPLAIN"):
            return query

        # Use EXPLAIN ANALYZE for actual execution stats
        # But be careful - this actually runs the query
        if "SELECT" in query.upper() or "WITH" in query.upper():
            return f"EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT) {query}"

        return f"EXPLAIN {query}"

    def _get_performance_queries(self) -> dict[str, str]:
        """Get PostgreSQL performance queries."""
        return POSTGRESQL_QUERIES

    def _get_slow_query_sql(self) -> str:
        return """SELECT query, calls, mean_exec_time::numeric(10,2) as avg_ms,
                         total_exec_time::numeric(10,2) as total_ms
                  FROM pg_stat_statements
                  ORDER BY mean_exec_time DESC
                  LIMIT 10"""

    def _get_connections_sql(self) -> str:
        return """SELECT pid, usename, application_name, client_addr,
                         state, query_start, query
                  FROM pg_stat_activity
                  WHERE state != 'idle'
                  ORDER BY query_start"""

    def _get_sizes_sql(self) -> str:
        return """SELECT schemaname, tablename,
                         pg_size_pretty(pg_total_relation_size(schemaname || '.' || tablename)) as total_size,
                         pg_size_pretty(pg_relation_size(schemaname || '.' || tablename)) as table_size,
                         pg_size_pretty(pg_indexes_size(schemaname || '.' || tablename)) as index_size
                  FROM pg_tables
                  WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
                  ORDER BY pg_total_relation_size(schemaname || '.' || tablename) DESC
                  LIMIT 20"""

    def _get_locks_sql(self) -> str:
        return """SELECT blocked_locks.pid AS blocked_pid,
                         blocked_activity.usename AS blocked_user,
                         blocking_locks.pid AS blocking_pid,
                         blocking_activity.usename AS blocking_user,
                         blocked_activity.query AS blocked_query,
                         blocking_activity.query AS blocking_query
                  FROM pg_catalog.pg_locks blocked_locks
                  JOIN pg_catalog.pg_stat_activity blocked_activity
                    ON blocked_activity.pid = blocked_locks.pid
                  JOIN pg_catalog.pg_locks blocking_locks
                    ON blocking_locks.locktype = blocked_locks.locktype
                    AND blocking_locks.database IS NOT DISTINCT FROM blocked_locks.database
                    AND blocking_locks.relation IS NOT DISTINCT FROM blocked_locks.relation
                    AND blocking_locks.page IS NOT DISTINCT FROM blocked_locks.page
                    AND blocking_locks.tuple IS NOT DISTINCT FROM blocked_locks.tuple
                    AND blocking_locks.virtualxid IS NOT DISTINCT FROM blocked_locks.virtualxid
                    AND blocking_locks.transactionid IS NOT DISTINCT FROM blocked_locks.transactionid
                    AND blocking_locks.classid IS NOT DISTINCT FROM blocked_locks.classid
                    AND blocking_locks.objid IS NOT DISTINCT FROM blocked_locks.objid
                    AND blocking_locks.objsubid IS NOT DISTINCT FROM blocked_locks.objsubid
                    AND blocking_locks.pid != blocked_locks.pid
                  JOIN pg_catalog.pg_stat_activity blocking_activity
                    ON blocking_activity.pid = blocking_locks.pid
                  WHERE NOT blocked_locks.granted"""

    def _get_replication_sql(self) -> str:
        return """SELECT client_addr, state, sent_lsn, write_lsn,
                         flush_lsn, replay_lsn,
                         pg_wal_lsn_diff(sent_lsn, replay_lsn) as lag_bytes
                  FROM pg_stat_replication"""

    def _get_system_prompt(self) -> str:
        """System prompt for PostgreSQL investigation."""
        return f"""You are a PostgreSQL database investigation agent for {self.database} on {self.host}.

Available tools:
- psql: Execute read-only SQL queries
- psql_write: Execute write operations (requires human approval)
- explain: Analyze query execution plans

Investigation approach:
1. **Active Queries**: Check pg_stat_activity for running queries
2. **Slow Queries**: Analyze pg_stat_statements for performance issues
3. **Locks**: Check for blocking queries and deadlocks
4. **Table Health**: Look at bloat, index usage, and vacuum status
5. **Replication**: Monitor pg_stat_replication for lag

Common PostgreSQL issues:
- **Connection exhaustion**: Too many connections, connection leaks
- **Lock contention**: Long transactions blocking others
- **Slow queries**: Missing indexes, bad query plans, bloated tables
- **Replication lag**: Network issues, slow replicas
- **Vacuum issues**: Autovacuum not keeping up, transaction ID wraparound

Useful system catalogs:
- pg_stat_activity: Active connections and queries
- pg_stat_statements: Query statistics (if extension enabled)
- pg_stat_user_tables: Table statistics
- pg_stat_user_indexes: Index usage statistics
- pg_locks: Current locks
- pg_stat_replication: Replication status

Always explain your findings and suggest specific actions."""

    def _mock_response(self, query: str) -> str:
        """Generate mock response for PostgreSQL queries."""
        q = query.lower()

        if "slow" in q or "performance" in q:
            return f"""I'll check for slow queries using pg_stat_statements.

TOOL: psql SELECT query, calls, mean_exec_time::numeric(10,2) as avg_ms FROM pg_stat_statements ORDER BY mean_exec_time DESC LIMIT 10"""

        if "connection" in q or "active" in q:
            return f"""I'll check active connections and queries.

TOOL: psql SELECT pid, usename, state, query FROM pg_stat_activity WHERE state != 'idle' LIMIT 20"""

        if "size" in q or "bloat" in q or "space" in q:
            return f"""I'll check table sizes and potential bloat.

TOOL: psql SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname || '.' || tablename)) as size FROM pg_tables WHERE schemaname = 'public' ORDER BY pg_total_relation_size(schemaname || '.' || tablename) DESC LIMIT 20"""

        if "lock" in q or "block" in q or "wait" in q:
            return f"""I'll check for lock contention and blocking queries.

TOOL: psql SELECT pid, usename, state, wait_event_type, wait_event, query FROM pg_stat_activity WHERE wait_event IS NOT NULL"""

        if "replication" in q or "replica" in q or "lag" in q:
            return f"""I'll check replication status and lag.

TOOL: psql SELECT client_addr, state, sent_lsn, replay_lsn, pg_wal_lsn_diff(sent_lsn, replay_lsn) as lag_bytes FROM pg_stat_replication"""

        if "vacuum" in q or "autovacuum" in q:
            return f"""I'll check vacuum and autovacuum status.

TOOL: psql SELECT schemaname, relname, last_vacuum, last_autovacuum, n_dead_tup FROM pg_stat_user_tables WHERE n_dead_tup > 1000 ORDER BY n_dead_tup DESC"""

        if "index" in q:
            return f"""I'll check index usage and missing indexes.

TOOL: psql SELECT schemaname, tablename, indexname, idx_scan, idx_tup_read, idx_tup_fetch FROM pg_stat_user_indexes ORDER BY idx_scan DESC LIMIT 20"""

        # Default response
        return f"""I'll help investigate this PostgreSQL database ({self.database}).

Let me start by checking the overall status.

TOOL: psql SELECT datname, numbackends, xact_commit, xact_rollback, blks_read, blks_hit, tup_returned, tup_fetched FROM pg_stat_database WHERE datname = current_database()"""

    def _mock_continuation(self, tool_output: str) -> str:
        """Generate mock continuation based on PostgreSQL output."""
        output_lower = tool_output.lower()

        if "deadlock" in output_lower:
            return """I detected a deadlock situation.

**Analysis:**
- Two or more transactions are waiting for each other
- PostgreSQL has detected and resolved the deadlock
- One transaction was terminated

**Recommendations:**
1. Review the application logic for transaction ordering
2. Consider shorter transactions
3. Use explicit locking with consistent ordering
4. Monitor for recurring patterns

Would you like me to analyze the queries involved?"""

        if "idle in transaction" in output_lower:
            return """I found connections in 'idle in transaction' state.

**Analysis:**
- These connections have started a transaction but haven't committed or rolled back
- They may be holding locks and preventing vacuum

**Recommendations:**
1. Set `idle_in_transaction_session_timeout` to terminate long-idle transactions
2. Review application code for missing COMMIT/ROLLBACK
3. Check for connection pool misconfigurations

Would you like me to identify the specific queries?"""

        if "seq_scan" in output_lower and "rows" in output_lower:
            return """I notice sequential scans that might benefit from indexes.

**Analysis:**
- Sequential scans read every row in the table
- For large tables, this can be very slow
- Adding an index on the filtered columns can help

**Recommendations:**
1. Identify the columns used in WHERE clauses
2. Create appropriate indexes
3. Analyze the tables after creating indexes

Would you like me to suggest specific indexes?"""

        if "lag_bytes" in output_lower or "replication" in output_lower:
            return """I've gathered the replication status.

If there's significant lag (lag_bytes > 0), possible causes include:
1. Network latency between primary and replica
2. High write load on the primary
3. Slow disk on the replica
4. Long-running queries on the replica

Would you like me to analyze the replication configuration?"""

        if "n_dead_tup" in output_lower:
            return """I found tables with dead tuples that may need vacuuming.

**Analysis:**
- Dead tuples are rows that have been deleted or updated
- They take up space until VACUUM cleans them up
- Too many dead tuples can slow down queries

**Recommendations:**
1. Check autovacuum settings
2. Consider manual VACUUM for heavily-used tables
3. Monitor vacuum progress

Would you like me to check the autovacuum configuration?"""

        # Default response
        return """Query completed. Based on the results, I can:

1. Dig deeper into specific queries or tables
2. Analyze index usage and suggest optimizations
3. Check for configuration issues
4. Monitor replication status

What would you like me to investigate further?"""
