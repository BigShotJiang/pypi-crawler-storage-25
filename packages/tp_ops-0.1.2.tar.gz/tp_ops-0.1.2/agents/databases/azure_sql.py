"""Azure SQL Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class AzureSQLAgent(DatabaseAgent):
    """Agent for Azure SQL Database investigation."""

    DB_TYPE = DatabaseType.AZURE_SQL
    DEFAULT_PORT = 1433
    SAFE_QUERIES = ["SELECT", "EXEC sp_who", "DBCC"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.server = config.get("server")
        self.database = config.get("database")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "resource_stats": "SELECT * FROM sys.dm_db_resource_stats ORDER BY end_time DESC",
            "wait_stats": "SELECT * FROM sys.dm_db_wait_stats ORDER BY wait_time_ms DESC",
            "query_stats": "SELECT * FROM sys.dm_exec_query_stats ORDER BY total_worker_time DESC",
            "connections": "SELECT * FROM sys.dm_exec_connections",
            "geo_replication": "SELECT * FROM sys.dm_geo_replication_link_status",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure SQL Database investigation agent for {self.server}.

Available tools:
- query: Execute read-only T-SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Resource Stats: sys.dm_db_resource_stats
2. Wait Stats: sys.dm_db_wait_stats
3. Query Stats: sys.dm_exec_query_stats
4. Connections: sys.dm_exec_connections
5. Geo-replication: sys.dm_geo_replication_link_status

Common issues:
- DTU/vCore saturation: Check resource_stats
- Blocking: Check wait stats
- Deadlocks: Check extended events
- Geo-replication lag: Check link status"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "resource" in q or "dtu" in q or "vcore" in q:
            return "I'll check resource usage.\n\nTOOL: query SELECT TOP 10 * FROM sys.dm_db_resource_stats ORDER BY end_time DESC"
        if "wait" in q or "block" in q:
            return "I'll check wait stats.\n\nTOOL: query SELECT * FROM sys.dm_db_wait_stats ORDER BY wait_time_ms DESC"
        if "replicat" in q or "geo" in q:
            return "I'll check geo-replication.\n\nTOOL: query SELECT * FROM sys.dm_geo_replication_link_status"
        return "I'll check resource stats.\n\nTOOL: query SELECT TOP 10 * FROM sys.dm_db_resource_stats ORDER BY end_time DESC"
