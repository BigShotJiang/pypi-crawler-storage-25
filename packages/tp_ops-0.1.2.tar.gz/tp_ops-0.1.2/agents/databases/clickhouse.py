"""ClickHouse Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class ClickHouseAgent(DatabaseAgent):
    """Agent for ClickHouse investigation."""

    DB_TYPE = DatabaseType.CLICKHOUSE
    DEFAULT_PORT = 8123
    SAFE_QUERIES = ["SELECT", "SHOW", "DESCRIBE", "EXPLAIN"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "INSERT"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "processes": "SELECT * FROM system.processes",
            "merges": "SELECT * FROM system.merges",
            "replication": "SELECT * FROM system.replication_queue",
            "parts": "SELECT database, table, count() as parts FROM system.parts GROUP BY database, table ORDER BY parts DESC LIMIT 20",
            "query_log": "SELECT * FROM system.query_log ORDER BY event_time DESC LIMIT 20",
            "metrics": "SELECT * FROM system.metrics",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a ClickHouse investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute read-only SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Running Queries: system.processes
2. Merges: system.merges
3. Parts: system.parts
4. Replication: system.replication_queue
5. Query Log: system.query_log

Common issues:
- Query performance: Check query_log for slow queries
- Merge issues: Too many parts, merge backlog
- Replication lag: Check replication_queue
- Disk pressure: Check disk usage per table"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "slow" in q or "query" in q:
            return "I'll check query log.\n\nTOOL: query SELECT query, query_duration_ms, read_rows FROM system.query_log WHERE type = 'QueryFinish' ORDER BY query_duration_ms DESC LIMIT 20"
        if "merge" in q:
            return "I'll check merges.\n\nTOOL: query SELECT * FROM system.merges"
        if "replicat" in q:
            return "I'll check replication.\n\nTOOL: query SELECT * FROM system.replication_queue"
        if "part" in q:
            return "I'll check parts.\n\nTOOL: query SELECT database, table, count() as parts FROM system.parts WHERE active GROUP BY database, table ORDER BY parts DESC"
        return "I'll check running queries.\n\nTOOL: query SELECT * FROM system.processes"
