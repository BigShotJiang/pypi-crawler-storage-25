"""Memcached Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class MemcachedAgent(ShellAgent):
    """Agent for Memcached investigation."""

    COMMAND_PREFIX = ["nc"]  # Using netcat to send commands
    TOOL_NAME = "memcached"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 10

    SAFE_SUBCOMMANDS = ["stats", "stats items", "stats slabs", "stats sizes"]
    DANGEROUS_SUBCOMMANDS = ["flush_all", "delete"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 11211)
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["echo", "stats", "|", "nc", self.host, str(self.port)]

    def _get_system_prompt(self) -> str:
        return f"""You are a Memcached investigation agent for {self.host}:{self.port}.

Available tools:
- memcached: Execute Memcached commands via netcat
- memcached_write: Execute write commands (requires approval)

Investigation approach:
1. Stats: echo "stats" | nc {self.host} {self.port}
2. Slabs: echo "stats slabs" | nc {self.host} {self.port}
3. Items: echo "stats items" | nc {self.host} {self.port}
4. Sizes: echo "stats sizes" | nc {self.host} {self.port}

Common issues:
- Evictions: High eviction rate, need more memory
- Hit/miss ratio: Low hit rate, caching issues
- Slab imbalances: Memory fragmentation
- Connection issues: Max connections reached"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "slab" in q:
            return f"I'll check slabs.\n\nTOOL: memcached echo 'stats slabs' | nc {self.host} {self.port}"
        if "item" in q:
            return f"I'll check items.\n\nTOOL: memcached echo 'stats items' | nc {self.host} {self.port}"
        if "evict" in q or "hit" in q or "miss" in q:
            return f"I'll check stats.\n\nTOOL: memcached echo 'stats' | nc {self.host} {self.port}"
        return f"I'll check memcached stats.\n\nTOOL: memcached echo 'stats' | nc {self.host} {self.port}"
