"""Snowflake Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class SnowflakeAgent(DatabaseAgent):
    """Agent for Snowflake investigation."""

    DB_TYPE = DatabaseType.SNOWFLAKE
    DEFAULT_PORT = 443
    SAFE_QUERIES = ["SELECT", "SHOW", "DESCRIBE", "EXPLAIN"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT", "CREATE"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.account = config.get("account")
        self.warehouse = config.get("warehouse")
        self.database = config.get("database")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "warehouses": "SHOW WAREHOUSES",
            "query_history": "SELECT * FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY()) ORDER BY START_TIME DESC LIMIT 50",
            "warehouse_metering": "SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY ORDER BY START_TIME DESC LIMIT 50",
            "storage_usage": "SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.STORAGE_USAGE ORDER BY USAGE_DATE DESC LIMIT 30",
            "login_history": "SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY ORDER BY EVENT_TIMESTAMP DESC LIMIT 50",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a Snowflake investigation agent for account '{self.account}'.

Available tools:
- query: Execute read-only SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Warehouses: SHOW WAREHOUSES
2. Query History: INFORMATION_SCHEMA.QUERY_HISTORY()
3. Credit Usage: SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
4. Storage: SNOWFLAKE.ACCOUNT_USAGE.STORAGE_USAGE
5. Logins: SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY

Common issues:
- High credit consumption: Check warehouse sizing
- Slow queries: Check query execution plans
- Storage growth: Check time travel, fail-safe
- Concurrency: Check warehouse queue"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "warehouse" in q:
            return "I'll check warehouses.\n\nTOOL: query SHOW WAREHOUSES"
        if "credit" in q or "cost" in q:
            return "I'll check credit usage.\n\nTOOL: query SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY ORDER BY START_TIME DESC LIMIT 20"
        if "slow" in q or "query" in q:
            return "I'll check query history.\n\nTOOL: query SELECT QUERY_ID, QUERY_TEXT, TOTAL_ELAPSED_TIME, WAREHOUSE_NAME FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY()) ORDER BY TOTAL_ELAPSED_TIME DESC LIMIT 20"
        if "storage" in q:
            return "I'll check storage.\n\nTOOL: query SELECT * FROM SNOWFLAKE.ACCOUNT_USAGE.STORAGE_USAGE ORDER BY USAGE_DATE DESC LIMIT 30"
        return "I'll check warehouses.\n\nTOOL: query SHOW WAREHOUSES"
