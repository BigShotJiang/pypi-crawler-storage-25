"""CouchDB Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CouchDBAgent(ShellAgent):
    """Agent for CouchDB investigation."""

    COMMAND_PREFIX = ["curl"]
    TOOL_NAME = "curl"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "_all_dbs", "_active_tasks", "_membership", "_cluster_setup",
        "_scheduler/jobs", "_scheduler/docs", "_node/_local/_stats",
        "_up", "_uuids",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "DELETE", "PUT", "_compact", "_view_cleanup",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", 5984)
        self.user = config.get("user", "admin")
        self.password = config.get("password")
        super().__init__(name, config, terminal, llm)

    def _get_base_url(self) -> str:
        auth = f"{self.user}:{self.password}@" if self.password else ""
        return f"http://{auth}{self.host}:{self.port}"

    def _get_system_prompt(self) -> str:
        return f"""You are a CouchDB investigation agent for {self.host}:{self.port}.

Available tools:
- curl: Execute read-only CouchDB API requests
- curl_write: Execute write requests (requires approval)

Investigation approach:
1. Server Status: curl {self._get_base_url()}/_up
2. All Databases: curl {self._get_base_url()}/_all_dbs
3. Active Tasks: curl {self._get_base_url()}/_active_tasks
4. Cluster Status: curl {self._get_base_url()}/_membership
5. Node Stats: curl {self._get_base_url()}/_node/_local/_stats
6. Replication Jobs: curl {self._get_base_url()}/_scheduler/jobs

Database checks:
- Document count: GET /dbname
- Design documents: GET /dbname/_design_docs
- View status: GET /dbname/_design/docname/_info
- Conflicts: GET /dbname/_all_docs?conflicts=true

Replication analysis:
- Continuous replications: _scheduler/docs
- Replication state: _scheduler/jobs
- Checkpoint documents: _local docs

Common issues:
- Replication conflicts: Documents modified on multiple nodes
- Compaction needed: Database file size growing
- View build slow: Large view index rebuilds
- Attachment bloat: Large binary attachments
- Conflict accumulation: Unresolved document conflicts
- Cluster quorum: Node failures affecting availability
- Slow views: Complex map/reduce functions"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        base = self._get_base_url()
        if "status" in q or "up" in q:
            return f"I'll check server status.\n\nTOOL: curl curl -s {base}/_up"
        if "database" in q or "list" in q:
            return f"I'll list databases.\n\nTOOL: curl curl -s {base}/_all_dbs"
        if "task" in q or "active" in q:
            return f"I'll check active tasks.\n\nTOOL: curl curl -s {base}/_active_tasks"
        if "replication" in q or "sync" in q:
            return f"I'll check replication jobs.\n\nTOOL: curl curl -s {base}/_scheduler/jobs"
        if "cluster" in q or "node" in q:
            return f"I'll check cluster membership.\n\nTOOL: curl curl -s {base}/_membership"
        if "conflict" in q:
            return f"I'll check for conflicts.\n\nTOOL: curl curl -s '{base}/dbname/_all_docs?conflicts=true&limit=10'"
        return f"I'll check CouchDB status.\n\nTOOL: curl curl -s {base}/_up && curl -s {base}/_all_dbs"
