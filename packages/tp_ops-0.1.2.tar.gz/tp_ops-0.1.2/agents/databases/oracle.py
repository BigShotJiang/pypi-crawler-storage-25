"""Oracle Database Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class OracleDBAgent(DatabaseAgent):
    """Agent for Oracle Database investigation."""

    DB_TYPE = DatabaseType.ORACLE
    DEFAULT_PORT = 1521
    SAFE_QUERIES = ["SELECT", "DESC", "EXPLAIN PLAN"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.service = config.get("service")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "sessions": "SELECT * FROM v$session WHERE status = 'ACTIVE'",
            "wait_events": "SELECT * FROM v$session_wait ORDER BY seconds_in_wait DESC",
            "tablespaces": "SELECT tablespace_name, bytes, maxbytes FROM dba_data_files",
            "top_sql": "SELECT * FROM v$sql ORDER BY elapsed_time DESC FETCH FIRST 20 ROWS ONLY",
            "rac_status": "SELECT * FROM gv$instance",
            "dataguard": "SELECT * FROM v$dataguard_status",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are an Oracle Database investigation agent for {self.host}:{self.port}/{self.service}.

Available tools:
- query: Execute read-only SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Sessions: v$session
2. Wait Events: v$session_wait
3. Tablespaces: dba_data_files
4. Top SQL: v$sql
5. RAC: gv$instance
6. Data Guard: v$dataguard_status

Common issues:
- Wait events: Library cache, buffer busy waits
- Tablespace: Running out of space
- RAC issues: Instance coordination
- Data Guard lag: Check apply rate"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "session" in q:
            return "I'll check active sessions.\n\nTOOL: query SELECT sid, serial#, username, status, sql_id FROM v$session WHERE status = 'ACTIVE'"
        if "wait" in q:
            return "I'll check wait events.\n\nTOOL: query SELECT sid, event, seconds_in_wait FROM v$session_wait ORDER BY seconds_in_wait DESC FETCH FIRST 20 ROWS ONLY"
        if "tablespace" in q or "space" in q:
            return "I'll check tablespaces.\n\nTOOL: query SELECT tablespace_name, SUM(bytes)/1024/1024 MB FROM dba_data_files GROUP BY tablespace_name"
        if "rac" in q:
            return "I'll check RAC status.\n\nTOOL: query SELECT inst_id, instance_name, status FROM gv$instance"
        if "dataguard" in q or "standby" in q:
            return "I'll check Data Guard.\n\nTOOL: query SELECT * FROM v$dataguard_status"
        return "I'll check active sessions.\n\nTOOL: query SELECT sid, serial#, username, status FROM v$session WHERE status = 'ACTIVE'"
