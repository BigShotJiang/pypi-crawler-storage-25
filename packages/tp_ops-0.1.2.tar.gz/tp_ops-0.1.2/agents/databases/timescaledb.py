"""TimescaleDB Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class TimescaleDBAgent(DatabaseAgent):
    """Agent for TimescaleDB investigation."""

    DB_TYPE = DatabaseType.TIMESCALEDB
    DEFAULT_PORT = 5432
    SAFE_QUERIES = ["SELECT", "SHOW", "EXPLAIN"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "hypertables": "SELECT * FROM timescaledb_information.hypertables",
            "chunks": "SELECT * FROM timescaledb_information.chunks ORDER BY range_start DESC LIMIT 50",
            "compression": "SELECT * FROM timescaledb_information.compressed_chunk_stats",
            "continuous_aggs": "SELECT * FROM timescaledb_information.continuous_aggregates",
            "jobs": "SELECT * FROM timescaledb_information.jobs",
            "job_stats": "SELECT * FROM timescaledb_information.job_stats",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a TimescaleDB investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute read-only SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Hypertables: timescaledb_information.hypertables
2. Chunks: timescaledb_information.chunks
3. Compression: timescaledb_information.compressed_chunk_stats
4. Continuous Aggs: timescaledb_information.continuous_aggregates
5. Jobs: timescaledb_information.jobs

Common issues:
- Chunk issues: Too many chunks, chunk size
- Compression: Uncompressed old chunks
- Continuous aggregate lag: Check job stats
- Policy issues: Check job failures"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "chunk" in q:
            return "I'll check chunks.\n\nTOOL: query SELECT * FROM timescaledb_information.chunks ORDER BY range_start DESC LIMIT 20"
        if "compress" in q:
            return "I'll check compression.\n\nTOOL: query SELECT * FROM timescaledb_information.compressed_chunk_stats"
        if "continuous" in q or "agg" in q:
            return "I'll check continuous aggregates.\n\nTOOL: query SELECT * FROM timescaledb_information.continuous_aggregates"
        if "job" in q:
            return "I'll check jobs.\n\nTOOL: query SELECT * FROM timescaledb_information.job_stats"
        return "I'll check hypertables.\n\nTOOL: query SELECT * FROM timescaledb_information.hypertables"
