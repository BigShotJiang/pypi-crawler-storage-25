"""Azure Cosmos DB Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CosmosDBAgent(ShellAgent):
    """Agent for Azure Cosmos DB investigation."""

    COMMAND_PREFIX = ["az", "cosmosdb"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "show", "list", "database list", "collection list",
        "sql database list", "sql container list", "sql container throughput show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create", "delete", "update", "sql database create", "sql container create",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.account = config.get("account")
        self.resource_group = config.get("resource_group")
        self.database = config.get("database")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["az", "cosmosdb"]

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Cosmos DB investigation agent for account '{self.account}'.

Available tools:
- az: Execute Azure CLI Cosmos DB commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Account Info: az cosmosdb show -n {self.account} -g {self.resource_group}
2. Databases: az cosmosdb sql database list
3. Containers: az cosmosdb sql container list
4. Throughput: az cosmosdb sql container throughput show
5. Metrics: Check Azure Monitor for RU consumption

Common issues:
- RU throttling: Check 429 errors, scale throughput
- Partition hot spots: Check partition key distribution
- Consistency: Check configured consistency level
- Cross-partition queries: Optimize queries"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "throughput" in q or "ru" in q:
            return f"I'll check throughput.\n\nTOOL: az cosmosdb sql container throughput show -a {self.account} -g {self.resource_group} -d {self.database} -n <container>"
        if "database" in q:
            return f"I'll list databases.\n\nTOOL: az cosmosdb sql database list -a {self.account} -g {self.resource_group}"
        if "container" in q:
            return f"I'll list containers.\n\nTOOL: az cosmosdb sql container list -a {self.account} -g {self.resource_group} -d {self.database}"
        return f"I'll check account.\n\nTOOL: az cosmosdb show -n {self.account} -g {self.resource_group}"
