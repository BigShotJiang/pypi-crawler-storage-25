"""MySQL/MariaDB Investigation Agent."""

from typing import Any
from agents.base.database import DatabaseAgent
from agents.tools.db_connector import DatabaseType


class MySQLAgent(DatabaseAgent):
    """Agent for MySQL/MariaDB investigation."""

    DB_TYPE = DatabaseType.MYSQL
    DEFAULT_PORT = 3306
    SAFE_QUERIES = ["SELECT", "SHOW", "DESCRIBE", "EXPLAIN"]
    DANGEROUS_QUERIES = ["DROP", "DELETE", "TRUNCATE", "ALTER", "UPDATE", "INSERT", "CREATE"]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.host = config.get("host", "localhost")
        self.port = config.get("port", self.DEFAULT_PORT)
        self.database = config.get("database")
        self.user = config.get("user")
        super().__init__(name, config, terminal, llm)

    def _get_performance_queries(self) -> dict[str, str]:
        return {
            "active_queries": "SHOW PROCESSLIST",
            "slow_queries": "SELECT * FROM mysql.slow_log ORDER BY query_time DESC LIMIT 10",
            "table_status": f"SHOW TABLE STATUS FROM {self.database}" if self.database else "SHOW DATABASES",
            "innodb_status": "SHOW ENGINE INNODB STATUS",
            "variables": "SHOW GLOBAL VARIABLES LIKE '%buffer%'",
            "status": "SHOW GLOBAL STATUS LIKE '%Innodb%'",
        }

    def _get_system_prompt(self) -> str:
        return f"""You are a MySQL/MariaDB investigation agent for {self.host}:{self.port}.

Available tools:
- query: Execute read-only SQL queries
- query_write: Execute write queries (requires approval)

Investigation approach:
1. Connections: SHOW PROCESSLIST
2. Slow Queries: Check slow_log or performance_schema
3. InnoDB Status: SHOW ENGINE INNODB STATUS
4. Table Health: SHOW TABLE STATUS
5. Replication: SHOW SLAVE STATUS (if replica)

Common issues:
- Slow queries: Missing indexes, full table scans
- Connection exhaustion: Check max_connections
- Deadlocks: Check InnoDB status
- Replication lag: Check SHOW SLAVE STATUS
- Buffer pool: Check innodb_buffer_pool_size"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "slow" in q:
            return "I'll check for slow queries.\n\nTOOL: query SHOW PROCESSLIST"
        if "connect" in q:
            return "I'll check connections.\n\nTOOL: query SHOW STATUS LIKE 'Threads_connected'"
        if "replicat" in q or "slave" in q:
            return "I'll check replication status.\n\nTOOL: query SHOW SLAVE STATUS"
        if "lock" in q or "deadlock" in q:
            return "I'll check for locks.\n\nTOOL: query SHOW ENGINE INNODB STATUS"
        return "I'll check database status.\n\nTOOL: query SHOW PROCESSLIST"
