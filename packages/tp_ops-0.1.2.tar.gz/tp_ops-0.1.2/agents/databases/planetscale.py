"""PlanetScale Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class PlanetScaleAgent(ShellAgent):
    """Agent for PlanetScale database investigation."""

    COMMAND_PREFIX = ["pscale"]
    TOOL_NAME = "pscale"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "database list", "branch list", "deploy-request list",
        "password list", "audit-log", "org list",
        "region list", "backup list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "database delete", "branch delete", "deploy-request deploy",
        "password delete", "branch promote",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.database = config.get("database")
        self.org = config.get("org")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["pscale"]
        if self.org:
            prefix.extend(["--org", self.org])
        return prefix

    def _get_system_prompt(self) -> str:
        db = self.database or "all"
        return f"""You are a PlanetScale investigation agent for database '{db}'.

Organization: {self.org or 'default'}

Available tools:
- pscale: Execute read-only PlanetScale CLI commands
- pscale_write: Execute write commands (requires approval)

Investigation approach:
1. Database List: pscale database list
2. Branch Status: pscale branch list {db if self.database else '<database>'}
3. Deploy Requests: pscale deploy-request list {db if self.database else '<database>'}
4. Backups: pscale backup list {db if self.database else '<database>'}
5. Audit Log: pscale audit-log

Branch workflow:
- Main branch: Production data
- Development branches: Schema changes
- Deploy requests: Safe schema migrations
- Reverts: Undo problematic changes

Vitess-specific checks:
- Sharding: Check vschema configuration
- VReplication: Replication lag between shards
- Query routing: Ensure queries hit correct shards

Common issues:
- Deploy request conflicts: Schema incompatibilities
- Branch divergence: Long-lived branches with conflicts
- Connection limits: Exceeded connection quota
- Query performance: Missing indexes on large tables
- Schema migration: Failed deploy requests
- Replication lag: VReplication falling behind"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        db = self.database or "<database>"
        if "database" in q or "list" in q:
            return "I'll list databases.\n\nTOOL: pscale pscale database list --format json"
        if "branch" in q:
            return f"I'll list branches.\n\nTOOL: pscale pscale branch list {db} --format json"
        if "deploy" in q or "migration" in q:
            return f"I'll check deploy requests.\n\nTOOL: pscale pscale deploy-request list {db} --format json"
        if "backup" in q:
            return f"I'll list backups.\n\nTOOL: pscale pscale backup list {db} --format json"
        if "audit" in q:
            return "I'll check audit log.\n\nTOOL: pscale pscale audit-log --format json"
        return f"I'll check database status.\n\nTOOL: pscale pscale database list --format json"
