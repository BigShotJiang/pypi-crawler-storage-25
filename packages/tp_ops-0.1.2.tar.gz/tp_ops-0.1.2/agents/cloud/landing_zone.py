"""Landing Zone Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class LandingZoneAgent(ShellAgent):
    """Agent for cloud landing zone investigation."""

    COMMAND_PREFIX = []  # Uses multiple CLIs based on cloud
    TOOL_NAME = "lz"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "aws organizations", "az account", "gcloud organizations",
        "terraform state", "pulumi stack",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete", "destroy", "remove",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cloud = config.get("cloud", "aws")  # aws, azure, gcp
        self.framework = config.get("framework")  # control-tower, caf, fabric
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        cloud = self.cloud.upper()
        framework = self.framework or "native"
        return f"""You are a Landing Zone investigation agent for {cloud}.

Framework: {framework}

Available tools:
- lz: Cloud CLI commands (aws/az/gcloud, terraform/pulumi)
- lz_write: Write operations (requires approval)

Investigation approach:

AWS Control Tower:
1. Account Factory: aws controltower list-enabled-controls
2. Guardrails: aws controltower list-guardrails
3. SCPs: aws organizations list-policies --filter SERVICE_CONTROL_POLICY
4. OU Structure: aws organizations list-organizational-units-for-parent

Azure CAF/Landing Zones:
1. Management Groups: az account management-group list
2. Subscriptions: az account list
3. Policy: az policy assignment list
4. Blueprints: az blueprint list

GCP Landing Zone:
1. Organizations: gcloud organizations list
2. Folders: gcloud resource-manager folders list
3. Org Policies: gcloud resource-manager org-policies list
4. IAM: gcloud asset search-all-iam-policies

Landing zone pillars:
- Identity: Centralized IAM
- Networking: Hub-spoke, transit
- Security: Guardrails, policies
- Governance: Tagging, cost management
- Operations: Logging, monitoring

Common issues:
- Guardrail violations: Non-compliant accounts
- Network connectivity: VPC/VNet peering issues
- IAM sprawl: Overprivileged roles
- Cost overruns: Uncontrolled spending
- Drift: Manual changes outside IaC
- Missing accounts: Not enrolled in landing zone"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.cloud == "aws":
            if "account" in q:
                return "I'll list accounts.\n\nTOOL: lz aws organizations list-accounts"
            if "guardrail" in q or "control" in q:
                return "I'll check guardrails.\n\nTOOL: lz aws controltower list-enabled-controls --target-identifier <ou-id>"
            if "scp" in q or "policy" in q:
                return "I'll list SCPs.\n\nTOOL: lz aws organizations list-policies --filter SERVICE_CONTROL_POLICY"
        elif self.cloud == "azure":
            if "subscription" in q:
                return "I'll list subscriptions.\n\nTOOL: lz az account list"
            if "management" in q:
                return "I'll list management groups.\n\nTOOL: lz az account management-group list"
            if "policy" in q:
                return "I'll check policies.\n\nTOOL: lz az policy assignment list"
        else:
            if "folder" in q:
                return "I'll list folders.\n\nTOOL: lz gcloud resource-manager folders list --organization=<org-id>"
            if "policy" in q:
                return "I'll list org policies.\n\nTOOL: lz gcloud resource-manager org-policies list --organization=<org-id>"
        return "I'll check landing zone status.\n\nTOOL: lz echo 'Checking landing zone...'"
