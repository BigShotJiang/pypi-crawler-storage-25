"""Terraform State Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class TerraformStateAgent(ShellAgent):
    """Agent for Terraform state file investigation."""

    COMMAND_PREFIX = ["terraform"]
    TOOL_NAME = "terraform"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "state list", "state show", "state pull",
        "show", "output", "providers", "version",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "state rm", "state mv", "state push",
        "import", "taint", "untaint",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.backend = config.get("backend", "local")
        self.state_path = config.get("state_path")
        self.working_dir = config.get("working_dir", ".")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["terraform", f"-chdir={self.working_dir}"]

    def _get_system_prompt(self) -> str:
        return f"""You are a Terraform state investigation agent.

Backend: {self.backend}
Working Directory: {self.working_dir}

Available tools:
- terraform: Execute read-only Terraform commands
- terraform_write: Execute write commands (requires approval)

Investigation approach:
1. List Resources: terraform state list
2. Show Resource: terraform state show <address>
3. Pull State: terraform state pull
4. Show Plan: terraform show
5. Outputs: terraform output

State analysis:
- Count resources by type
- Find resources without tags
- Identify drift candidates
- Check for orphaned resources

Common issues:
- State drift: Resources modified outside Terraform
- State corruption: Invalid JSON, missing resources
- Lock issues: State locked by another process
- Import needed: Resources exist but not in state
- State bloat: Old data in state file"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "list" in q:
            return "I'll list state resources.\n\nTOOL: terraform state list"
        if "drift" in q:
            return "I'll pull and analyze state.\n\nTOOL: terraform state pull"
        if "show" in q:
            return "I'll show state.\n\nTOOL: terraform show"
        return "I'll list resources in state.\n\nTOOL: terraform state list"
