"""Azure Subscription Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureSubscriptionAgent(ShellAgent):
    """Agent for Azure subscription-level investigation."""

    COMMAND_PREFIX = ["az"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "account show", "account list",
        "resource list", "resource show",
        "advisor recommendation list", "consumption usage list",
        "policy state list", "security assessment list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "resource delete", "resource create",
        "account set",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.subscription_id = config.get("subscription_id")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["az"]
        if self.subscription_id:
            prefix.extend(["--subscription", self.subscription_id])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Subscription investigation agent for '{self.subscription_id}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Account: az account show
2. Resources: az resource list
3. Advisor: az advisor recommendation list
4. Policy: az policy state list
5. Security: az security assessment list
6. Cost: az consumption usage list

Common issues:
- Cost anomalies: Unexpected spending
- Advisor recommendations: Performance, security, cost
- Policy violations: Non-compliant resources
- Resource health: Degraded or unhealthy resources
- Security alerts: Defender for Cloud findings"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "cost" in q or "spend" in q:
            return "I'll check consumption.\n\nTOOL: az consumption usage list --top 50"
        if "advisor" in q or "recommend" in q:
            return "I'll check Advisor recommendations.\n\nTOOL: az advisor recommendation list"
        if "policy" in q or "compliance" in q:
            return "I'll check policy state.\n\nTOOL: az policy state list"
        if "security" in q:
            return "I'll check security assessments.\n\nTOOL: az security assessment list"
        return "I'll check account.\n\nTOOL: az account show"
