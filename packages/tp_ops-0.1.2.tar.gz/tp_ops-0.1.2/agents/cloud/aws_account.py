"""AWS Account Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AWSAccountAgent(ShellAgent):
    """Agent for AWS account-level investigation."""

    COMMAND_PREFIX = ["aws"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "sts get-caller-identity", "account get-contact-information",
        "organizations describe-organization", "organizations list-accounts",
        "health describe-events", "ce get-cost-and-usage",
        "securityhub get-findings", "config get-compliance-summary-by-config-rule",
        "iam get-account-summary", "support describe-trusted-advisor-checks",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "organizations create-account", "organizations close-account",
        "iam create-user", "iam delete-user",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.account_id = config.get("account_id")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are an AWS Account investigation agent for account '{self.account_id}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Identity: aws sts get-caller-identity
2. Health Events: aws health describe-events
3. Cost: aws ce get-cost-and-usage --time-period Start=<start>,End=<end> --granularity DAILY --metrics BlendedCost
4. Security Hub: aws securityhub get-findings
5. Config: aws config get-compliance-summary-by-config-rule
6. Trusted Advisor: aws support describe-trusted-advisor-checks

Common issues:
- Cost anomalies: Unexpected spending spikes
- Security findings: Security Hub alerts
- Config violations: Non-compliant resources
- Service health: AWS service disruptions
- Unused resources: Cost optimization opportunities"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "cost" in q or "spend" in q:
            return "I'll check costs.\n\nTOOL: aws ce get-cost-and-usage --time-period Start=2024-01-01,End=2024-01-31 --granularity DAILY --metrics BlendedCost"
        if "security" in q:
            return "I'll check Security Hub.\n\nTOOL: aws securityhub get-findings"
        if "health" in q:
            return "I'll check service health.\n\nTOOL: aws health describe-events"
        return "I'll check account identity.\n\nTOOL: aws sts get-caller-identity"
