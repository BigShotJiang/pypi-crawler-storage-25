"""Pulumi Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class PulumiAgent(ShellAgent):
    """Agent for Pulumi infrastructure investigation."""

    COMMAND_PREFIX = ["pulumi"]
    TOOL_NAME = "pulumi"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "stack ls", "stack history", "stack export",
        "preview", "config", "whoami", "about",
        "state", "stack graph",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "up", "destroy", "refresh", "import",
        "state delete", "cancel",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.stack = config.get("stack")
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        stack = self.stack or "current"
        return f"""You are a Pulumi investigation agent for stack '{stack}'.

Project: {self.project or 'current'}

Available tools:
- pulumi: Execute read-only Pulumi commands
- pulumi_write: Execute write commands (requires approval)

Investigation approach:
1. Stack List: pulumi stack ls
2. Stack History: pulumi stack history
3. Stack Export: pulumi stack export
4. Preview: pulumi preview
5. Config: pulumi config
6. State: pulumi state

Stack analysis:
- Resources: List all managed resources
- Outputs: Stack output values
- History: Update history and changes
- Dependencies: Resource relationships

State inspection:
- Export: Full state JSON
- URNs: Resource identifiers
- Inputs/Outputs: Resource properties
- Dependencies: Resource graph

Common issues:
- Drift: State differs from actual
- Pending operations: Stuck updates
- Resource conflicts: Name collisions
- Import failures: Existing resources
- Stack corruption: Invalid state
- Secret exposure: Unencrypted secrets
- Provider errors: API failures"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "stack" in q and "list" in q:
            return "I'll list stacks.\n\nTOOL: pulumi pulumi stack ls --json"
        if "history" in q:
            return "I'll check stack history.\n\nTOOL: pulumi pulumi stack history --json"
        if "state" in q or "export" in q:
            return "I'll export state.\n\nTOOL: pulumi pulumi stack export"
        if "preview" in q:
            return "I'll preview changes.\n\nTOOL: pulumi pulumi preview --json"
        if "config" in q:
            return "I'll check config.\n\nTOOL: pulumi pulumi config --json"
        if "resource" in q:
            return "I'll list resources.\n\nTOOL: pulumi pulumi stack export | jq '.deployment.resources'"
        return "I'll check stack status.\n\nTOOL: pulumi pulumi stack ls --json && pulumi stack history --json | head -5"
