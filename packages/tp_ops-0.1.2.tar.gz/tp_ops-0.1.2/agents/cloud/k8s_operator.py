"""Kubernetes Operator Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class K8sOperatorAgent(ShellAgent):
    """Agent for Kubernetes operator investigation."""

    COMMAND_PREFIX = ["kubectl"]
    TOOL_NAME = "kubectl"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "get", "describe", "logs", "api-resources",
        "explain", "get events",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete", "apply", "patch", "edit",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.operator = config.get("operator")  # e.g., cert-manager, external-dns, strimzi
        self.namespace = config.get("namespace", "default")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["kubectl"]
        if self.kubeconfig:
            prefix.extend(["--kubeconfig", self.kubeconfig])
        return prefix

    def _get_system_prompt(self) -> str:
        operator = self.operator or "unknown"
        return f"""You are a Kubernetes Operator investigation agent for '{operator}'.

Namespace: {self.namespace}

Available tools:
- kubectl: Execute read-only kubectl commands
- kubectl_write: Execute write commands (requires approval)

Investigation approach:
1. Operator Pods: kubectl get pods -n {self.namespace} -l app={operator}
2. Operator Logs: kubectl logs -n {self.namespace} -l app={operator}
3. CRDs: kubectl get crds | grep {operator}
4. Custom Resources: kubectl get <crd-kind> -A
5. Events: kubectl get events -n {self.namespace} --sort-by='.lastTimestamp'
6. Webhooks: kubectl get mutatingwebhookconfigurations,validatingwebhookconfigurations

Common issues:
- CRD reconciliation: Custom resources not reconciling
- Operator crashes: Pod restarts, OOM
- Webhook issues: Admission webhook blocking requests
- RBAC: Operator missing permissions
- Leader election: Multiple operators fighting"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        operator = self.operator or "<operator>"
        ns = self.namespace
        if "log" in q:
            return f"I'll check operator logs.\n\nTOOL: kubectl logs -n {ns} -l app={operator} --tail=100"
        if "crd" in q or "custom" in q:
            return f"I'll list CRDs.\n\nTOOL: kubectl get crds | grep {operator}"
        if "event" in q:
            return f"I'll check events.\n\nTOOL: kubectl get events -n {ns} --sort-by='.lastTimestamp'"
        if "webhook" in q:
            return "I'll check webhooks.\n\nTOOL: kubectl get mutatingwebhookconfigurations,validatingwebhookconfigurations"
        return f"I'll check operator pods.\n\nTOOL: kubectl get pods -n {ns} -l app={operator}"
