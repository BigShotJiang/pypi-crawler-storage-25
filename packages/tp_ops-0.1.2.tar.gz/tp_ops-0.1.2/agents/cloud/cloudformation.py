"""AWS CloudFormation Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CloudFormationAgent(ShellAgent):
    """Agent for AWS CloudFormation investigation."""

    COMMAND_PREFIX = ["aws", "cloudformation"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-stacks", "describe-stacks", "describe-stack-resources",
        "describe-stack-events", "get-template", "get-template-summary",
        "list-exports", "list-imports", "detect-stack-drift",
        "describe-stack-drift-detection-status", "list-stack-sets",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-stack", "delete-stack", "update-stack",
        "execute-change-set", "cancel-update-stack",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.stack_name = config.get("stack_name")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "cloudformation", "--region", self.region]

    def _get_system_prompt(self) -> str:
        stack = self.stack_name or "all"
        return f"""You are an AWS CloudFormation investigation agent for stack '{stack}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. List Stacks: aws cloudformation list-stacks --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE
2. Describe Stack: aws cloudformation describe-stacks --stack-name {stack}
3. Resources: aws cloudformation describe-stack-resources --stack-name {stack}
4. Events: aws cloudformation describe-stack-events --stack-name {stack}
5. Drift: aws cloudformation detect-stack-drift --stack-name {stack}
6. Template: aws cloudformation get-template --stack-name {stack}

Common issues:
- Stack failures: Create/update failures
- Drift: Resources modified outside CloudFormation
- Rollback: Failed updates causing rollback
- Exports: Unused or circular exports
- Nested stacks: Child stack failures"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        stack = self.stack_name or "<stack-name>"
        if "event" in q or "fail" in q:
            return f"I'll check stack events.\n\nTOOL: aws cloudformation describe-stack-events --stack-name {stack}"
        if "drift" in q:
            return f"I'll detect drift.\n\nTOOL: aws cloudformation detect-stack-drift --stack-name {stack}"
        if "resource" in q:
            return f"I'll list stack resources.\n\nTOOL: aws cloudformation describe-stack-resources --stack-name {stack}"
        return "I'll list stacks.\n\nTOOL: aws cloudformation list-stacks --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE"
