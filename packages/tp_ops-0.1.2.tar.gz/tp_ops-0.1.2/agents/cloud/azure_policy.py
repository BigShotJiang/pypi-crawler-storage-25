"""Azure Policy Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzurePolicyAgent(ShellAgent):
    """Agent for Azure Policy compliance investigation."""

    COMMAND_PREFIX = ["az", "policy"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "definition list", "definition show", "set-definition list",
        "assignment list", "assignment show", "state list",
        "state summarize", "event list", "remediation list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "definition create", "definition delete", "assignment create",
        "assignment delete", "remediation create",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.subscription = config.get("subscription")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Policy investigation agent.

Subscription: {self.subscription or 'current'}
Resource Group: {self.resource_group or 'all'}

Available tools:
- az: Execute read-only Azure Policy commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Assignments: az policy assignment list
2. Definitions: az policy definition list
3. State Summary: az policy state summarize
4. State List: az policy state list
5. Events: az policy event list
6. Remediations: az policy remediation list

Policy effects:
- Deny: Block non-compliant resources
- Audit: Log non-compliance
- Append: Add properties
- Modify: Change properties
- DeployIfNotExists: Deploy remediation
- AuditIfNotExists: Audit missing resources

Compliance states:
- Compliant: Resource meets policy
- NonCompliant: Resource violates policy
- Exempt: Resource excluded
- Conflicting: Multiple policy conflicts

Common issues:
- Non-compliant resources: Policy violations
- Deny blocking deployments: Unexpected denies
- Remediation failures: DINE task errors
- Policy conflicts: Overlapping assignments
- Exemption expiry: Time-limited exemptions
- Initiative coverage: Missing policies"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "assignment" in q:
            return "I'll list policy assignments.\n\nTOOL: az az policy assignment list"
        if "definition" in q:
            return "I'll list policy definitions.\n\nTOOL: az az policy definition list --query \"[?policyType=='Custom']\""
        if "state" in q or "compliance" in q:
            return "I'll check compliance state.\n\nTOOL: az az policy state summarize"
        if "non-compliant" in q or "violation" in q:
            return "I'll find non-compliant resources.\n\nTOOL: az az policy state list --filter \"complianceState eq 'NonCompliant'\""
        if "remediation" in q:
            return "I'll check remediations.\n\nTOOL: az az policy remediation list"
        if "event" in q:
            return "I'll check policy events.\n\nTOOL: az az policy event list"
        return "I'll summarize policy state.\n\nTOOL: az az policy state summarize"
