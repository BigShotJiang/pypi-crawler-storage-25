"""Infracost Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class InfracostAgent(ShellAgent):
    """Agent for Infracost cloud cost estimation investigation."""

    COMMAND_PREFIX = ["infracost"]
    TOOL_NAME = "infracost"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 300

    SAFE_SUBCOMMANDS = [
        "breakdown", "diff", "output", "configure get",
        "auth status", "completion",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "configure set", "auth login",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.path = config.get("path", ".")
        self.usage_file = config.get("usage_file")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Infracost investigation agent for cloud cost estimation.

Path: {self.path}
Usage File: {self.usage_file or 'none'}

Available tools:
- infracost: Execute read-only Infracost commands
- infracost_write: Execute write commands (requires approval)

Investigation approach:
1. Breakdown: infracost breakdown --path {self.path}
2. Diff: infracost diff --path {self.path}
3. Output: infracost output --path infracost.json
4. Usage: infracost breakdown --usage-file {self.usage_file or 'usage.yml'}

Cost breakdown:
- Monthly cost: Projected monthly spend
- Hourly cost: Per-hour rate
- Resource costs: Individual resource pricing
- Free tier: What's included free

Supported resources:
- Compute: EC2, VMs, GCE
- Storage: S3, Blob, GCS
- Databases: RDS, Azure SQL, Cloud SQL
- Networking: Load balancers, NAT gateways
- Kubernetes: EKS, AKS, GKE

Diff analysis:
- Added resources: New costs
- Removed resources: Savings
- Changed resources: Cost impact

Common issues:
- Missing prices: Unsupported resources
- Usage estimation: Default vs actual usage
- Region pricing: Price variations
- Reserved pricing: Not reflected
- Spot/preemptible: Variable costs
- Data transfer: Often underestimated"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        path = self.path
        if "breakdown" in q or "cost" in q:
            return f"I'll show cost breakdown.\n\nTOOL: infracost infracost breakdown --path {path} --format json"
        if "diff" in q or "change" in q:
            return f"I'll show cost diff.\n\nTOOL: infracost infracost diff --path {path} --format json"
        if "usage" in q:
            return f"I'll check with usage file.\n\nTOOL: infracost infracost breakdown --path {path} --usage-file usage.yml --format json"
        return f"I'll estimate costs.\n\nTOOL: infracost infracost breakdown --path {path} --format json"
