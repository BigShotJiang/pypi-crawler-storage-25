"""AWS Config Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AWSConfigAgent(ShellAgent):
    """Agent for AWS Config compliance investigation."""

    COMMAND_PREFIX = ["aws", "configservice"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "describe-config-rules", "describe-compliance-by-config-rule",
        "describe-compliance-by-resource", "get-compliance-details-by-config-rule",
        "get-compliance-details-by-resource", "describe-configuration-recorders",
        "describe-delivery-channels", "get-resource-config-history",
        "select-resource-config", "list-discovered-resources",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "put-config-rule", "delete-config-rule", "start-remediation-execution",
        "delete-configuration-recorder",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "configservice", "--region", self.region]

    def _get_system_prompt(self) -> str:
        return f"""You are an AWS Config investigation agent.

Region: {self.region}

Available tools:
- aws: Execute read-only AWS Config commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Config Rules: aws configservice describe-config-rules
2. Compliance by Rule: aws configservice describe-compliance-by-config-rule
3. Compliance by Resource: aws configservice describe-compliance-by-resource
4. Rule Details: aws configservice get-compliance-details-by-config-rule
5. Resource History: aws configservice get-resource-config-history
6. Advanced Query: aws configservice select-resource-config

Compliance states:
- COMPLIANT: Resource meets rule requirements
- NON_COMPLIANT: Resource violates rule
- NOT_APPLICABLE: Rule doesn't apply
- INSUFFICIENT_DATA: Not enough info

Config rule types:
- Managed rules: AWS-provided rules
- Custom rules: Lambda-based rules
- Organization rules: Org-wide rules

Common issues:
- Non-compliant resources: Rule violations
- Recorder stopped: Config not recording
- Delivery failures: S3/SNS issues
- Rule evaluation errors: Lambda failures
- Resource coverage gaps: Not all types tracked
- Aggregator issues: Cross-account problems"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "rule" in q and "list" in q:
            return "I'll list config rules.\n\nTOOL: aws aws configservice describe-config-rules"
        if "compliance" in q and "rule" in q:
            return "I'll check compliance by rule.\n\nTOOL: aws aws configservice describe-compliance-by-config-rule"
        if "compliance" in q and "resource" in q:
            return "I'll check compliance by resource.\n\nTOOL: aws aws configservice describe-compliance-by-resource"
        if "non-compliant" in q or "violation" in q:
            return "I'll find non-compliant resources.\n\nTOOL: aws aws configservice describe-compliance-by-config-rule --compliance-types NON_COMPLIANT"
        if "history" in q:
            return "I'll check resource history.\n\nTOOL: aws aws configservice get-resource-config-history --resource-type AWS::EC2::Instance --resource-id <instance-id>"
        return "I'll check compliance status.\n\nTOOL: aws aws configservice describe-compliance-by-config-rule"
