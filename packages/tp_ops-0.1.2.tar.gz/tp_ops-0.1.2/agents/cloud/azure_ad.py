"""Azure AD / Entra ID Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureADAgent(ShellAgent):
    """Agent for Azure AD / Entra ID investigation."""

    COMMAND_PREFIX = ["az", "ad"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "user list", "user show", "group list", "group show",
        "sp list", "sp show", "app list", "app show",
        "signed-in-user show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "user create", "user delete", "group create", "group delete",
        "sp create", "sp delete", "app create", "app delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.tenant_id = config.get("tenant_id")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure AD / Entra ID investigation agent for tenant '{self.tenant_id}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Current User: az ad signed-in-user show
2. Users: az ad user list
3. Groups: az ad group list
4. Service Principals: az ad sp list
5. App Registrations: az ad app list
6. Sign-in Logs: Use Azure portal or Graph API

Common issues:
- Stale service principals: Unused app registrations
- Sign-in failures: Conditional access blocks
- MFA gaps: Users without MFA
- Overprivileged apps: Apps with excessive API permissions
- Risky users: Identity Protection alerts"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "user" in q:
            return "I'll list users.\n\nTOOL: az ad user list --top 50"
        if "sp" in q or "service principal" in q:
            return "I'll list service principals.\n\nTOOL: az ad sp list --top 50"
        if "app" in q:
            return "I'll list app registrations.\n\nTOOL: az ad app list --top 50"
        if "group" in q:
            return "I'll list groups.\n\nTOOL: az ad group list --top 50"
        return "I'll check current user.\n\nTOOL: az ad signed-in-user show"
