"""GCP Resource Manager Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GCPResourceManagerAgent(ShellAgent):
    """Agent for GCP Resource Manager investigation."""

    COMMAND_PREFIX = ["gcloud"]
    TOOL_NAME = "gcloud"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "organizations list", "projects list", "resource-manager folders list",
        "asset search-all-resources", "asset search-all-iam-policies",
        "resource-manager org-policies list", "resource-manager org-policies describe",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "projects delete", "projects create",
        "resource-manager org-policies set-policy",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.organization = config.get("organization")
        self.folder = config.get("folder")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a GCP Resource Manager investigation agent.

Organization: {self.organization or 'current'}
Folder: {self.folder or 'none'}

Available tools:
- gcloud: Execute read-only GCP commands
- gcloud_write: Execute write commands (requires approval)

Investigation approach:
1. Organizations: gcloud organizations list
2. Folders: gcloud resource-manager folders list --organization=<org-id>
3. Projects: gcloud projects list
4. Assets: gcloud asset search-all-resources --scope=organizations/<org-id>
5. IAM: gcloud asset search-all-iam-policies --scope=organizations/<org-id>
6. Org Policies: gcloud resource-manager org-policies list --organization=<org-id>

Resource hierarchy:
- Organization: Top-level (domain-based)
- Folders: Grouping mechanism
- Projects: Resource containers
- Resources: Actual GCP services

Organization Policies:
- Constraints: Boolean or list-based
- Inheritance: Parent to child
- Deny overrides: More restrictive wins

Common issues:
- Project sprawl: Too many unused projects
- IAM bindings: Overprivileged access
- Org policy violations: Non-compliant configurations
- Billing anomalies: Unexpected cost spikes
- Resource quotas: Limits approaching
- Label compliance: Missing required labels"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        org = self.organization or "<org-id>"
        if "project" in q:
            return "I'll list projects.\n\nTOOL: gcloud gcloud projects list --format=json"
        if "folder" in q:
            return f"I'll list folders.\n\nTOOL: gcloud gcloud resource-manager folders list --organization={org} --format=json"
        if "asset" in q or "resource" in q:
            return f"I'll search assets.\n\nTOOL: gcloud gcloud asset search-all-resources --scope=organizations/{org} --format=json"
        if "iam" in q or "permission" in q:
            return f"I'll search IAM policies.\n\nTOOL: gcloud gcloud asset search-all-iam-policies --scope=organizations/{org} --format=json"
        if "policy" in q:
            return f"I'll list org policies.\n\nTOOL: gcloud gcloud resource-manager org-policies list --organization={org} --format=json"
        return "I'll list organizations.\n\nTOOL: gcloud gcloud organizations list --format=json"
