"""Cloud Asset Inventory Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CloudAssetAgent(ShellAgent):
    """Agent for cloud asset inventory investigation."""

    COMMAND_PREFIX = ["gcloud", "asset"]
    TOOL_NAME = "gcloud"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "search-all-resources", "search-all-iam-policies",
        "list", "get-history", "analyze-iam-policy",
        "analyze-org-policy-governed-assets",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "feeds create", "feeds delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.scope = config.get("scope")  # organization, folder, or project
        self.scope_id = config.get("scope_id")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        scope = self.scope or "project"
        scope_id = self.scope_id or "current"
        return f"""You are a Cloud Asset Inventory investigation agent.

Scope: {scope}
Scope ID: {scope_id}

Available tools:
- gcloud: Execute read-only Cloud Asset Inventory commands
- gcloud_write: Execute write commands (requires approval)

Investigation approach:
1. Search Resources: gcloud asset search-all-resources --scope={scope}s/{scope_id}
2. Search IAM: gcloud asset search-all-iam-policies --scope={scope}s/{scope_id}
3. Asset History: gcloud asset get-history --asset-names=<asset>
4. Analyze IAM: gcloud asset analyze-iam-policy --organization=<org-id>

Asset types:
- compute.googleapis.com/Instance: VMs
- storage.googleapis.com/Bucket: GCS buckets
- container.googleapis.com/Cluster: GKE clusters
- sqladmin.googleapis.com/Instance: Cloud SQL

Query filters:
- asset_type: Filter by resource type
- state: Filter by resource state
- labels: Filter by labels
- location: Filter by region

Common queries:
- All VMs: asset_type:compute.googleapis.com/Instance
- All storage: asset_type:storage.googleapis.com/Bucket
- By label: labels.env:production

Common issues:
- Scope permissions: Missing IAM roles
- Large results: Pagination needed
- Asset gaps: Not all types indexed
- History retention: Limited history
- Feed delays: Near real-time not instant
- IAM complexity: Complex policy inheritance"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        scope = self.scope or "projects"
        scope_id = self.scope_id or "<project-id>"
        if "resource" in q or "asset" in q:
            return f"I'll search all resources.\n\nTOOL: gcloud gcloud asset search-all-resources --scope={scope}/{scope_id} --format=json"
        if "iam" in q or "policy" in q:
            return f"I'll search IAM policies.\n\nTOOL: gcloud gcloud asset search-all-iam-policies --scope={scope}/{scope_id} --format=json"
        if "history" in q:
            return "I'll get asset history.\n\nTOOL: gcloud gcloud asset get-history --asset-names=//compute.googleapis.com/projects/<project>/zones/<zone>/instances/<instance> --content-type=resource --format=json"
        if "vm" in q or "instance" in q:
            return f"I'll search VMs.\n\nTOOL: gcloud gcloud asset search-all-resources --scope={scope}/{scope_id} --asset-types=compute.googleapis.com/Instance --format=json"
        return f"I'll list all assets.\n\nTOOL: gcloud gcloud asset search-all-resources --scope={scope}/{scope_id} --format=json | head -50"
