"""Multi-Cloud Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class MultiCloudAgent(ShellAgent):
    """Agent for multi-cloud environment investigation."""

    COMMAND_PREFIX = []  # Uses multiple CLIs
    TOOL_NAME = "cloud"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "aws", "az", "gcloud", "steampipe query",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete", "remove", "terminate",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.clouds = config.get("clouds", ["aws", "azure", "gcp"])
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        clouds = ", ".join(self.clouds)
        return f"""You are a Multi-Cloud investigation agent for: {clouds}.

Available tools:
- aws: AWS CLI commands
- az: Azure CLI commands
- gcloud: GCP CLI commands
- steampipe: Cross-cloud SQL queries

Investigation approach:
1. AWS: aws ec2 describe-instances, aws s3 ls
2. Azure: az vm list, az storage account list
3. GCP: gcloud compute instances list, gcloud storage ls
4. Cross-cloud: steampipe query "SELECT * FROM aws_ec2_instance UNION SELECT * FROM azure_compute_virtual_machine"

Cross-cloud analysis:
- Compute inventory: VMs across all clouds
- Storage inventory: Buckets/blobs/objects
- Network topology: VPCs/VNets/VPCs
- IAM comparison: Roles and permissions
- Cost aggregation: Total spend

Steampipe queries (recommended):
- All VMs: SELECT cloud_provider, name, region FROM all_vms
- All storage: SELECT cloud_provider, name, location FROM all_storage
- All databases: SELECT cloud_provider, name, engine FROM all_databases

Common issues:
- Inconsistent naming: Different conventions per cloud
- Security gaps: Varying security postures
- Cost overruns: Unoptimized multi-cloud spend
- Data residency: Resources in wrong regions
- Connectivity: Cross-cloud networking issues
- Drift: Configuration differences"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "vm" in q or "instance" in q or "compute" in q:
            return "I'll list compute across clouds.\n\nTOOL: cloud aws ec2 describe-instances --query 'Reservations[].Instances[].{Id:InstanceId,Type:InstanceType}' && az vm list --query '[].{Name:name,Size:hardwareProfile.vmSize}' && gcloud compute instances list --format=json"
        if "storage" in q or "bucket" in q:
            return "I'll list storage across clouds.\n\nTOOL: cloud aws s3 ls && az storage account list --query '[].name' && gcloud storage ls"
        if "cost" in q or "billing" in q:
            return "I'll check costs.\n\nTOOL: cloud aws ce get-cost-and-usage --time-period Start=2024-01-01,End=2024-01-31 --granularity MONTHLY --metrics BlendedCost"
        if "network" in q or "vpc" in q:
            return "I'll list networks.\n\nTOOL: cloud aws ec2 describe-vpcs && az network vnet list && gcloud compute networks list"
        return "I'll summarize resources across clouds.\n\nTOOL: cloud echo 'AWS:' && aws ec2 describe-instances --query 'length(Reservations[].Instances[])' && echo 'Azure:' && az vm list --query 'length(@)' && echo 'GCP:' && gcloud compute instances list --format='value(name)' | wc -l"
