"""GCP Organization Policy Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GCPOrgPolicyAgent(ShellAgent):
    """Agent for GCP Organization Policy investigation."""

    COMMAND_PREFIX = ["gcloud", "resource-manager", "org-policies"]
    TOOL_NAME = "gcloud"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list", "describe", "list-constraints",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "set-policy", "reset", "delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.organization = config.get("organization")
        self.project = config.get("project")
        self.folder = config.get("folder")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a GCP Organization Policy investigation agent.

Organization: {self.organization or 'current'}
Project: {self.project or 'current'}
Folder: {self.folder or 'none'}

Available tools:
- gcloud: Execute read-only GCP commands
- gcloud_write: Execute write commands (requires approval)

Investigation approach:
1. List Policies: gcloud resource-manager org-policies list --organization=<org-id>
2. Describe Policy: gcloud resource-manager org-policies describe <constraint> --organization=<org-id>
3. List Constraints: gcloud resource-manager org-policies list-constraints --organization=<org-id>
4. Effective Policy: Check inherited policies

Constraint types:
- Boolean constraints: Allow/deny a capability
- List constraints: Allow/deny specific values

Common constraints:
- compute.vmExternalIpAccess: External IP restrictions
- iam.allowedPolicyMemberDomains: Domain restrictions
- compute.restrictVpcPeering: VPC peering limits
- storage.uniformBucketLevelAccess: Bucket ACL mode
- compute.skipDefaultNetworkCreation: Default network

Policy inheritance:
- Organization → Folder → Project
- Merge behavior for list constraints
- Override behavior configurable

Common issues:
- Blocked deployments: Constraint violations
- Inheritance conflicts: Overlapping policies
- Missing constraints: Security gaps
- Exception management: Policy overrides
- Drift detection: Unexpected changes
- Audit gaps: Missing logging"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        org = self.organization or "<org-id>"
        project = self.project or "<project-id>"
        if "list" in q and "constraint" in q:
            return f"I'll list available constraints.\n\nTOOL: gcloud gcloud resource-manager org-policies list-constraints --organization={org} --format=json"
        if "list" in q or "policy" in q:
            return f"I'll list org policies.\n\nTOOL: gcloud gcloud resource-manager org-policies list --organization={org} --format=json"
        if "describe" in q:
            return f"I'll describe a policy.\n\nTOOL: gcloud gcloud resource-manager org-policies describe compute.vmExternalIpAccess --organization={org} --format=json"
        if "effective" in q or "project" in q:
            return f"I'll check effective policy on project.\n\nTOOL: gcloud gcloud resource-manager org-policies list --project={project} --format=json"
        return f"I'll list org policies.\n\nTOOL: gcloud gcloud resource-manager org-policies list --organization={org} --format=json"
