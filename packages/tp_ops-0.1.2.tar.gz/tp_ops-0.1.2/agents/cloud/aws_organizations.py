"""AWS Organizations Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AWSOrganizationsAgent(ShellAgent):
    """Agent for AWS Organizations investigation."""

    COMMAND_PREFIX = ["aws", "organizations"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "describe-organization", "list-accounts", "list-roots",
        "list-organizational-units-for-parent", "list-policies",
        "describe-policy", "list-targets-for-policy",
        "describe-account", "list-parents", "list-children",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-account", "close-account", "move-account",
        "create-policy", "delete-policy", "attach-policy",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.org_id = config.get("org_id")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an AWS Organizations investigation agent.

Organization ID: {self.org_id or 'current'}

Available tools:
- aws: Execute read-only AWS Organizations commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Organization Info: aws organizations describe-organization
2. List Accounts: aws organizations list-accounts
3. OU Structure: aws organizations list-roots, then list-organizational-units-for-parent
4. Policies: aws organizations list-policies --filter SERVICE_CONTROL_POLICY
5. Policy Targets: aws organizations list-targets-for-policy --policy-id <id>

Organization structure:
- Root: Top-level container
- OUs: Organizational units for grouping accounts
- Accounts: Member AWS accounts
- Policies: SCPs, Tag policies, Backup policies

Service Control Policies (SCPs):
- Deny overrides allow
- Applied at OU or account level
- Don't grant permissions, only restrict

Common issues:
- SCP blocking: Legitimate actions denied
- Account limits: Max accounts reached
- OU nesting: Too deep hierarchy
- Policy conflicts: Overlapping SCPs
- Orphaned accounts: Accounts without proper OU
- Tag policy violations: Non-compliant tags"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "account" in q:
            return "I'll list accounts.\n\nTOOL: aws aws organizations list-accounts"
        if "ou" in q or "unit" in q:
            return "I'll list organizational units.\n\nTOOL: aws aws organizations list-roots && aws organizations list-organizational-units-for-parent --parent-id <root-id>"
        if "policy" in q or "scp" in q:
            return "I'll list SCPs.\n\nTOOL: aws aws organizations list-policies --filter SERVICE_CONTROL_POLICY"
        if "root" in q:
            return "I'll list roots.\n\nTOOL: aws aws organizations list-roots"
        return "I'll describe the organization.\n\nTOOL: aws aws organizations describe-organization"
