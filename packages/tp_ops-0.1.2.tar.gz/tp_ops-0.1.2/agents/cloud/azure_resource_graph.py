"""Azure Resource Graph Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureResourceGraphAgent(ShellAgent):
    """Agent for Azure Resource Graph investigation."""

    COMMAND_PREFIX = ["az", "graph", "query"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "query", "-q", "--query",
    ]

    DANGEROUS_SUBCOMMANDS = []  # Resource Graph is read-only

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.subscription = config.get("subscription")
        self.management_group = config.get("management_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are an Azure Resource Graph investigation agent.

Subscription: {self.subscription or 'all subscriptions'}
Management Group: {self.management_group or 'none'}

Available tools:
- az: Execute Azure Resource Graph queries (KQL)
- az graph query: Run cross-subscription queries

Investigation approach:
1. All Resources: az graph query -q "Resources | summarize count() by type"
2. VMs: az graph query -q "Resources | where type == 'microsoft.compute/virtualmachines'"
3. Storage: az graph query -q "Resources | where type == 'microsoft.storage/storageaccounts'"
4. Networking: az graph query -q "Resources | where type contains 'network'"
5. Security: az graph query -q "securityresources | where type == 'microsoft.security/assessments'"

Common queries:
- Untagged resources: where tags == {{}}
- By location: summarize count() by location
- By subscription: summarize count() by subscriptionId
- By resource group: summarize count() by resourceGroup

Resource types:
- Compute: VMs, VMSS, AKS, App Services
- Storage: Storage accounts, disks, blobs
- Networking: VNets, NSGs, load balancers
- Databases: SQL, Cosmos DB, Redis
- Security: Key Vaults, assessments

Common issues:
- Resource sprawl: Unused or orphaned resources
- Tag compliance: Missing required tags
- Region spread: Resources in unexpected regions
- Security findings: Non-compliant resources
- Cost attribution: Untagged resources"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "vm" in q or "virtual machine" in q:
            return "I'll query VMs.\n\nTOOL: az az graph query -q \"Resources | where type == 'microsoft.compute/virtualmachines' | project name, resourceGroup, location\""
        if "storage" in q:
            return "I'll query storage accounts.\n\nTOOL: az az graph query -q \"Resources | where type == 'microsoft.storage/storageaccounts' | project name, resourceGroup, location\""
        if "tag" in q:
            return "I'll find untagged resources.\n\nTOOL: az az graph query -q \"Resources | where tags == {} | summarize count() by type\""
        if "security" in q:
            return "I'll check security assessments.\n\nTOOL: az az graph query -q \"securityresources | where type == 'microsoft.security/assessments' | where properties.status.code == 'Unhealthy'\""
        if "count" in q or "summary" in q:
            return "I'll summarize resources.\n\nTOOL: az az graph query -q \"Resources | summarize count() by type | order by count_ desc\""
        return "I'll list all resources.\n\nTOOL: az az graph query -q \"Resources | summarize count() by type | order by count_ desc\""
