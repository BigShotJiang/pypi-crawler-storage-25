"""AWS IAM Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AWSIAMAgent(ShellAgent):
    """Agent for AWS IAM investigation."""

    COMMAND_PREFIX = ["aws", "iam"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list-users", "list-roles", "list-groups", "list-policies",
        "get-user", "get-role", "get-policy", "get-policy-version",
        "list-attached-user-policies", "list-attached-role-policies",
        "get-account-summary", "get-credential-report",
        "simulate-principal-policy", "list-access-keys",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-user", "delete-user", "create-role", "delete-role",
        "attach-user-policy", "detach-user-policy",
        "create-access-key", "delete-access-key",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return """You are an AWS IAM investigation agent.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Account Summary: aws iam get-account-summary
2. Users: aws iam list-users
3. Roles: aws iam list-roles
4. Credential Report: aws iam generate-credential-report && aws iam get-credential-report
5. Access Keys: aws iam list-access-keys --user-name <user>
6. Simulate: aws iam simulate-principal-policy --policy-source-arn <arn> --action-names <actions>

Common issues:
- Stale access keys: Keys not rotated in 90+ days
- Unused roles: Roles with no recent activity
- Overprivileged: Roles with AdministratorAccess
- MFA gaps: Users without MFA enabled
- Cross-account: Risky trust relationships"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "user" in q:
            return "I'll list users.\n\nTOOL: aws iam list-users"
        if "role" in q:
            return "I'll list roles.\n\nTOOL: aws iam list-roles"
        if "key" in q or "credential" in q:
            return "I'll check credential report.\n\nTOOL: aws iam get-credential-report"
        if "mfa" in q:
            return "I'll check account summary.\n\nTOOL: aws iam get-account-summary"
        return "I'll check IAM account summary.\n\nTOOL: aws iam get-account-summary"
