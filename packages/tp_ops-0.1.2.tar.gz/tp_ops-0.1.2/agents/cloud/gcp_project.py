"""GCP Project Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GCPProjectAgent(ShellAgent):
    """Agent for GCP project-level investigation."""

    COMMAND_PREFIX = ["gcloud"]
    TOOL_NAME = "gcloud"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "projects describe", "projects list",
        "services list", "iam service-accounts list",
        "compute instances list", "asset search-all-resources",
        "recommender recommendations list", "billing accounts list",
        "scc findings list",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "projects delete", "services disable",
        "iam service-accounts delete", "compute instances delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["gcloud"]
        if self.project:
            prefix.extend(["--project", self.project])
        return prefix

    def _get_system_prompt(self) -> str:
        return f"""You are a GCP Project investigation agent for '{self.project}'.

Available tools:
- gcloud: Execute read-only gcloud commands
- gcloud_write: Execute write commands (requires approval)

Investigation approach:
1. Project: gcloud projects describe {self.project}
2. Services: gcloud services list --enabled
3. IAM: gcloud iam service-accounts list
4. Resources: gcloud asset search-all-resources
5. Recommendations: gcloud recommender recommendations list --recommender=google.compute.instance.MachineTypeRecommender
6. Security: gcloud scc findings list

Common issues:
- Cost anomalies: Unexpected spending
- IAM issues: Overprivileged service accounts
- Security findings: Security Command Center alerts
- Unused resources: Idle VMs, unattached disks
- Quotas: Approaching quota limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "iam" in q or "service account" in q:
            return "I'll check service accounts.\n\nTOOL: gcloud iam service-accounts list"
        if "security" in q:
            return "I'll check Security Command Center.\n\nTOOL: gcloud scc findings list --organization=<org-id>"
        if "recommend" in q or "cost" in q:
            return "I'll check recommendations.\n\nTOOL: gcloud recommender recommendations list"
        return f"I'll describe the project.\n\nTOOL: gcloud projects describe {self.project}"
