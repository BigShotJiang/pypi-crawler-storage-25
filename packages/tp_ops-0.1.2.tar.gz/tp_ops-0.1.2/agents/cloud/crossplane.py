"""Crossplane Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CrossplaneAgent(ShellAgent):
    """Agent for Crossplane infrastructure investigation."""

    COMMAND_PREFIX = ["kubectl"]
    TOOL_NAME = "kubectl"
    OUTPUT_FORMAT = "yaml"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "get providers", "get providerconfigs", "get compositions",
        "get compositeresourcedefinitions", "get claims",
        "get managed", "describe", "get events",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete", "apply", "patch", "edit",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace", "crossplane-system")
        self.provider = config.get("provider")  # aws, azure, gcp
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        provider = self.provider or "all"
        return f"""You are a Crossplane investigation agent.

Namespace: {self.namespace}
Provider: {provider}

Available tools:
- kubectl: Execute read-only kubectl commands
- kubectl_write: Execute write commands (requires approval)

Investigation approach:
1. Providers: kubectl get providers
2. Provider Configs: kubectl get providerconfigs
3. XRDs: kubectl get compositeresourcedefinitions
4. Compositions: kubectl get compositions
5. Claims: kubectl get claims -A
6. Managed Resources: kubectl get managed

Crossplane concepts:
- Provider: Cloud provider controller (AWS, Azure, GCP)
- ProviderConfig: Cloud credentials
- XRD: Custom resource definition
- Composition: Resource template
- Claim: User request for resources
- Managed Resource: Actual cloud resource

Reconciliation status:
- Synced: Resource matches desired state
- Ready: Resource is operational
- LastTransitionTime: When state changed

Common issues:
- Provider not ready: Credential issues
- Composition errors: Template misconfiguration
- Claim pending: Resources not provisioning
- Drift: Managed resource differs from cloud
- Rate limiting: Too many API calls
- Resource conflicts: Name collisions
- Secret missing: Credentials not found"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        ns = self.namespace
        if "provider" in q:
            return "I'll check providers.\n\nTOOL: kubectl kubectl get providers"
        if "composition" in q:
            return "I'll list compositions.\n\nTOOL: kubectl kubectl get compositions"
        if "claim" in q:
            return "I'll list claims.\n\nTOOL: kubectl kubectl get claims -A"
        if "managed" in q or "resource" in q:
            return "I'll list managed resources.\n\nTOOL: kubectl kubectl get managed"
        if "xrd" in q or "definition" in q:
            return "I'll list XRDs.\n\nTOOL: kubectl kubectl get compositeresourcedefinitions"
        if "event" in q:
            return f"I'll check events.\n\nTOOL: kubectl kubectl get events -n {ns} --sort-by='.lastTimestamp'"
        return "I'll check Crossplane status.\n\nTOOL: kubectl kubectl get providers && kubectl get managed | head -20"
