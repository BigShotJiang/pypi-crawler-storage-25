"""FinOps Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class FinOpsAgent(ShellAgent):
    """Agent for cloud financial operations (FinOps) investigation."""

    COMMAND_PREFIX = ["aws", "ce"]
    TOOL_NAME = "finops"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "get-cost-and-usage", "get-cost-forecast", "get-reservation-utilization",
        "get-savings-plans-utilization", "get-rightsizing-recommendation",
        "get-anomalies", "list-cost-allocation-tags",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "update-cost-allocation-tags-status", "create-anomaly-monitor",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cloud = config.get("cloud", "aws")  # aws, azure, gcp
        self.account = config.get("account")
        self.time_period = config.get("time_period", "MONTHLY")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.cloud == "aws":
            return ["aws", "ce"]
        elif self.cloud == "azure":
            return ["az", "consumption"]
        else:
            return ["gcloud", "billing"]

    def _get_system_prompt(self) -> str:
        return f"""You are a FinOps investigation agent for {self.cloud.upper()}.

Account/Subscription: {self.account or 'current'}
Time Period: {self.time_period}

Available tools:
- finops: Execute read-only cost analysis commands
- finops_write: Execute write commands (requires approval)

Investigation approach for AWS:
1. Cost & Usage: aws ce get-cost-and-usage
2. Forecast: aws ce get-cost-forecast
3. RI Utilization: aws ce get-reservation-utilization
4. Savings Plans: aws ce get-savings-plans-utilization
5. Rightsizing: aws ce get-rightsizing-recommendation
6. Anomalies: aws ce get-anomalies

Cost dimensions:
- SERVICE: AWS service breakdown
- LINKED_ACCOUNT: Account-level costs
- REGION: Geographic distribution
- INSTANCE_TYPE: EC2 instance sizing
- USAGE_TYPE: Usage category

Optimization areas:
- Rightsizing: Oversized instances
- Reserved Instances: Unused RIs
- Savings Plans: Low utilization
- Spot instances: On-demand candidates
- Storage classes: Infrequent access data

Common issues:
- Cost spikes: Unexpected increases
- Orphaned resources: Unused but billable
- RI waste: Unused reservations
- Data transfer: Cross-region costs
- Idle resources: Running but unused
- Missing tags: Unattributed costs"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "cost" in q and "usage" in q:
            return "I'll check cost and usage.\n\nTOOL: finops aws ce get-cost-and-usage --time-period Start=2024-01-01,End=2024-01-31 --granularity MONTHLY --metrics BlendedCost --group-by Type=DIMENSION,Key=SERVICE"
        if "forecast" in q:
            return "I'll check cost forecast.\n\nTOOL: finops aws ce get-cost-forecast --time-period Start=2024-02-01,End=2024-02-28 --metric BLENDED_COST --granularity MONTHLY"
        if "reservation" in q or "ri" in q:
            return "I'll check RI utilization.\n\nTOOL: finops aws ce get-reservation-utilization --time-period Start=2024-01-01,End=2024-01-31"
        if "savings" in q:
            return "I'll check Savings Plans.\n\nTOOL: finops aws ce get-savings-plans-utilization --time-period Start=2024-01-01,End=2024-01-31"
        if "rightsize" in q or "recommend" in q:
            return "I'll get rightsizing recommendations.\n\nTOOL: finops aws ce get-rightsizing-recommendation --service AmazonEC2"
        if "anomal" in q:
            return "I'll check anomalies.\n\nTOOL: finops aws ce get-anomalies --date-interval StartDate=2024-01-01,EndDate=2024-01-31"
        return "I'll check current costs.\n\nTOOL: finops aws ce get-cost-and-usage --time-period Start=2024-01-01,End=2024-01-31 --granularity MONTHLY --metrics BlendedCost"
