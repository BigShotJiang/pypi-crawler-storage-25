"""Steampipe Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SteampipeAgent(ShellAgent):
    """Agent for Steampipe cloud resource investigation."""

    COMMAND_PREFIX = ["steampipe"]
    TOOL_NAME = "steampipe"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "query", "check", "plugin list", "mod list",
        "service status", "dashboard",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "plugin install", "plugin uninstall", "mod install",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.plugins = config.get("plugins", ["aws", "azure", "gcp"])
        self.mod = config.get("mod")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        plugins = ", ".join(self.plugins)
        return f"""You are a Steampipe investigation agent.

Plugins: {plugins}
Mod: {self.mod or 'none'}

Available tools:
- steampipe: Execute SQL queries against cloud APIs
- steampipe_write: Execute write operations (requires approval)

Investigation approach:
1. Query: steampipe query "SELECT * FROM aws_s3_bucket"
2. Check: steampipe check all
3. Plugin Status: steampipe plugin list
4. Compliance: steampipe check benchmark.cis_v140

SQL query examples:
- AWS EC2: SELECT instance_id, instance_type, state FROM aws_ec2_instance
- Azure VMs: SELECT name, vm_size, power_state FROM azure_compute_virtual_machine
- GCP Instances: SELECT name, machine_type, status FROM gcp_compute_instance

Cross-cloud queries:
- All VMs: Use UNION across cloud tables
- All storage: Combine S3/Blob/GCS tables
- All IAM: Query across IAM tables

Compliance checks:
- CIS benchmarks: Industry standards
- AWS Foundational: AWS best practices
- Azure CIS: Azure security
- GCP CIS: GCP security

Common issues:
- Plugin not installed: Missing plugin
- Connection errors: Credential issues
- Query timeout: Large result sets
- Rate limiting: Too many API calls
- Cache stale: Outdated data
- Mod errors: Incompatible versions"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "s3" in q or "bucket" in q:
            return "I'll query S3 buckets.\n\nTOOL: steampipe steampipe query \"SELECT name, region, versioning_enabled FROM aws_s3_bucket\" --output json"
        if "ec2" in q or "instance" in q:
            return "I'll query EC2 instances.\n\nTOOL: steampipe steampipe query \"SELECT instance_id, instance_type, state FROM aws_ec2_instance\" --output json"
        if "compliance" in q or "check" in q:
            return "I'll run compliance checks.\n\nTOOL: steampipe steampipe check all --output json"
        if "iam" in q or "user" in q:
            return "I'll query IAM users.\n\nTOOL: steampipe steampipe query \"SELECT name, create_date, mfa_enabled FROM aws_iam_user\" --output json"
        if "plugin" in q:
            return "I'll list plugins.\n\nTOOL: steampipe steampipe plugin list"
        return "I'll run compliance checks.\n\nTOOL: steampipe steampipe check all --output brief"
