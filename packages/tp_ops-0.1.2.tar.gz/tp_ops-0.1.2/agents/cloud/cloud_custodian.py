"""Cloud Custodian Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CloudCustodianAgent(ShellAgent):
    """Agent for Cloud Custodian policy investigation."""

    COMMAND_PREFIX = ["custodian"]
    TOOL_NAME = "custodian"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 120

    SAFE_SUBCOMMANDS = [
        "validate", "report", "schema", "run --dryrun",
        "version", "logs",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "run", "mugc", "org-run",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.policy_dir = config.get("policy_dir", "policies")
        self.output_dir = config.get("output_dir", "output")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a Cloud Custodian investigation agent.

Policy Directory: {self.policy_dir}
Output Directory: {self.output_dir}

Available tools:
- custodian: Execute read-only Cloud Custodian commands
- custodian_write: Execute policies (requires approval)

Investigation approach:
1. Validate: custodian validate {self.policy_dir}/*.yaml
2. Dry Run: custodian run --dryrun -s {self.output_dir} policy.yaml
3. Schema: custodian schema <resource-type>
4. Report: custodian report -s {self.output_dir}

Policy structure:
- name: Policy identifier
- resource: AWS/Azure/GCP resource type
- filters: Conditions to match
- actions: Operations to perform
- mode: Execution mode (pull/push)

Filter types:
- value: Attribute comparison
- tag: Tag-based filtering
- age: Time-based filtering
- event: CloudTrail/EventGrid events
- cross-account: Multi-account checks

Common policies:
- Untagged resources: Missing required tags
- Old snapshots: Snapshots older than N days
- Unused resources: No recent activity
- Security groups: Overly permissive rules
- Public resources: Exposed S3/storage

Common issues:
- Policy syntax errors: Invalid YAML
- Filter mismatches: No resources found
- Permission errors: IAM issues
- Rate limiting: Too many API calls
- Lambda timeouts: Complex policies
- Report gaps: Missing output"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        policy_dir = self.policy_dir
        output_dir = self.output_dir
        if "validate" in q:
            return f"I'll validate policies.\n\nTOOL: custodian custodian validate {policy_dir}/*.yaml"
        if "dry" in q or "preview" in q:
            return f"I'll do a dry run.\n\nTOOL: custodian custodian run --dryrun -s {output_dir} {policy_dir}/policy.yaml"
        if "schema" in q:
            return "I'll show the schema.\n\nTOOL: custodian custodian schema ec2"
        if "report" in q:
            return f"I'll generate a report.\n\nTOOL: custodian custodian report -s {output_dir}"
        return f"I'll validate policies.\n\nTOOL: custodian custodian validate {policy_dir}/*.yaml"
