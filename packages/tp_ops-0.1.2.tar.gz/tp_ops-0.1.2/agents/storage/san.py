"""iSCSI/Fibre Channel SAN Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class SANAgent(ShellAgent):
    """Agent for iSCSI and Fibre Channel SAN investigation."""

    COMMAND_PREFIX = ["iscsiadm"]
    TOOL_NAME = "san"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "iscsiadm -m session", "iscsiadm -m node", "iscsiadm -m discovery",
        "multipath -ll", "multipathd show paths", "multipathd show maps",
        "systool -c fc_host", "cat /sys/class/fc_host",
        "lsscsi", "sg_inq",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "iscsiadm -m node --logout", "iscsiadm -m node --login",
        "multipath -f", "multipath -F",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.san_type = config.get("type", "iscsi")  # iscsi or fc
        self.target = config.get("target")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        san_type = self.san_type.upper()
        return f"""You are a {san_type} SAN investigation agent.

Available tools:
- san: Execute read-only SAN commands
- san_write: Execute write commands (requires approval)

Investigation approach for iSCSI:
1. Sessions: iscsiadm -m session -P 3
2. Nodes: iscsiadm -m node
3. Discovery: iscsiadm -m discovery -t st -p <portal>
4. Multipath: multipath -ll

Investigation approach for Fibre Channel:
1. HBAs: systool -c fc_host -v
2. Port State: cat /sys/class/fc_host/*/port_state
3. SCSI Devices: lsscsi
4. Multipath: multipathd show paths

Common issues:
- Path failures: Network or switch issues
- Multipath: Paths not detected, wrong policy
- LUN visibility: Zoning or masking issues
- Performance: Congestion, queue depth
- Timeout: Session recovery issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.san_type == "fc":
            if "hba" in q or "port" in q:
                return "I'll check FC HBAs.\n\nTOOL: san systool -c fc_host -v"
            if "path" in q or "multipath" in q:
                return "I'll check multipath.\n\nTOOL: san multipathd show paths"
            return "I'll check FC ports.\n\nTOOL: san cat /sys/class/fc_host/*/port_state"
        else:
            if "session" in q:
                return "I'll check iSCSI sessions.\n\nTOOL: san iscsiadm -m session -P 3"
            if "path" in q or "multipath" in q:
                return "I'll check multipath.\n\nTOOL: san multipath -ll"
            if "discover" in q:
                return "I'll check iSCSI discovery.\n\nTOOL: san iscsiadm -m node"
            return "I'll check iSCSI sessions.\n\nTOOL: san iscsiadm -m session"
