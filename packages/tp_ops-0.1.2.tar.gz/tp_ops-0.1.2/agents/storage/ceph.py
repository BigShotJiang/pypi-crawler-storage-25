"""Ceph Storage Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class CephAgent(ShellAgent):
    """Agent for Ceph distributed storage investigation."""

    COMMAND_PREFIX = ["ceph"]
    TOOL_NAME = "ceph"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "status", "health", "health detail", "df",
        "osd stat", "osd tree", "osd df", "osd pool ls",
        "pg stat", "pg dump", "mds stat", "mon stat",
        "rados df", "rbd ls", "fs status",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "osd out", "osd in", "osd down", "osd rm",
        "osd pool create", "osd pool delete",
        "mds fail", "mon remove",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cluster = config.get("cluster", "ceph")
        self.conf = config.get("conf", "/etc/ceph/ceph.conf")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["ceph", "--conf", self.conf]

    def _get_system_prompt(self) -> str:
        return f"""You are a Ceph storage investigation agent for cluster '{self.cluster}'.

Available tools:
- ceph: Execute read-only Ceph commands
- ceph_write: Execute write commands (requires approval)

Investigation approach:
1. Health: ceph health detail
2. Status: ceph status
3. OSD Tree: ceph osd tree
4. OSD Stats: ceph osd df
5. PG Status: ceph pg stat
6. Pool Stats: ceph osd pool ls detail
7. Disk Usage: ceph df

Common issues:
- OSD failures: Drives down or out
- PG states: Degraded, misplaced, inactive PGs
- MDS issues: CephFS metadata server problems
- Slow requests: OSD latency spikes
- Capacity: OSDs approaching full threshold
- Rebalancing: PGs moving after topology change"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "health" in q:
            return "I'll check cluster health.\n\nTOOL: ceph health detail"
        if "osd" in q:
            return "I'll check OSD tree.\n\nTOOL: ceph osd tree"
        if "pg" in q or "placement" in q:
            return "I'll check PG status.\n\nTOOL: ceph pg stat"
        if "space" in q or "capacity" in q:
            return "I'll check disk usage.\n\nTOOL: ceph df"
        return "I'll check cluster status.\n\nTOOL: ceph status"
