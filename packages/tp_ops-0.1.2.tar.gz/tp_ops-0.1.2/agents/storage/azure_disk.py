"""Azure Managed Disk Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureDiskAgent(ShellAgent):
    """Agent for Azure Managed Disk investigation."""

    COMMAND_PREFIX = ["az", "disk"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "list", "show", "list-skus",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create", "delete", "update", "grant-access", "revoke-access",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.disk_name = config.get("name")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        disk = self.disk_name or "unknown"
        return f"""You are an Azure Managed Disk investigation agent for disk '{disk}'.

Resource Group: {self.resource_group}

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Disk Details: az disk show -g {self.resource_group} -n {disk}
2. List Disks: az disk list -g {self.resource_group}
3. Available SKUs: az disk list-skus --location <location>
4. Azure Monitor: Check Disk Read/Write operations, Disk Queue Depth

Common issues:
- Throttling: IOPS or throughput limit exceeded
- Performance tier: Wrong SKU for workload
- Snapshot failures: Snapshot operation issues
- Orphaned disks: Disks not attached to VMs
- Cost: Premium disks underutilized"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        disk = self.disk_name or "<disk-name>"
        if "list" in q:
            return f"I'll list disks.\n\nTOOL: az disk list -g {self.resource_group}"
        if "throttl" in q or "iops" in q or "performance" in q:
            return f"I'll check disk details.\n\nTOOL: az disk show -g {self.resource_group} -n {disk}"
        if "orphan" in q or "unattached" in q:
            return f"I'll check for unattached disks.\n\nTOOL: az disk list -g {self.resource_group} --query \"[?diskState=='Unattached']\""
        return f"I'll check disk details.\n\nTOOL: az disk show -g {self.resource_group} -n {disk}"
