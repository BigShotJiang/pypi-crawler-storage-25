"""NFS/CIFS File Share Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NFSAgent(ShellAgent):
    """Agent for NFS/CIFS file share investigation."""

    COMMAND_PREFIX = ["showmount"]
    TOOL_NAME = "nfs"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "showmount", "nfsstat", "rpcinfo", "mount",
        "df", "du", "ls", "stat", "lsof",
        "smbstatus", "smbclient",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "umount", "exportfs", "chmod", "chown",
        "rm", "mv", "cp",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.server = config.get("server")
        self.share = config.get("share")
        self.mount_point = config.get("mount_point")
        self.protocol = config.get("protocol", "nfs")  # nfs or cifs
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        server = self.server or "unknown"
        return f"""You are an NFS/CIFS file share investigation agent for {server}.

Protocol: {self.protocol.upper()}

Available tools:
- nfs: Execute read-only NFS/CIFS commands
- nfs_write: Execute write commands (requires approval)

Investigation approach for NFS:
1. Exports: showmount -e {server}
2. NFS Stats: nfsstat -c
3. RPC Info: rpcinfo -p {server}
4. Mounts: mount | grep nfs
5. Disk Usage: df -h {self.mount_point}

Investigation approach for CIFS:
1. Status: smbstatus
2. Client: smbclient -L {server}
3. Mounts: mount | grep cifs

Common issues:
- Stale mounts: NFS server unreachable
- Permission errors: UID/GID mapping issues
- I/O latency: Network or server performance
- Lock contention: Multiple clients, stale locks
- Quota: Approaching storage limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        server = self.server or "<server>"
        if "export" in q:
            return f"I'll check NFS exports.\n\nTOOL: nfs showmount -e {server}"
        if "mount" in q:
            return "I'll check mounted shares.\n\nTOOL: nfs mount | grep nfs"
        if "latency" in q or "performance" in q:
            return "I'll check NFS stats.\n\nTOOL: nfs nfsstat -c"
        if "space" in q or "disk" in q:
            return f"I'll check disk usage.\n\nTOOL: nfs df -h {self.mount_point}"
        return f"I'll check NFS exports.\n\nTOOL: nfs showmount -e {server}"
