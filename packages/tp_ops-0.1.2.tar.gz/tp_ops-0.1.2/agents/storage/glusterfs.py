"""GlusterFS Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GlusterFSAgent(ShellAgent):
    """Agent for GlusterFS distributed storage investigation."""

    COMMAND_PREFIX = ["gluster"]
    TOOL_NAME = "gluster"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "peer status", "pool list", "volume list",
        "volume info", "volume status", "volume heal info",
        "volume quota list", "volume rebalance status",
        "volume profile info", "volume top",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "volume create", "volume delete", "volume stop", "volume start",
        "peer probe", "peer detach",
        "volume heal enable", "volume heal full",
        "volume rebalance start",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.volume = config.get("volume")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        vol = self.volume or "all"
        return f"""You are a GlusterFS investigation agent for volume '{vol}'.

Available tools:
- gluster: Execute read-only GlusterFS commands
- gluster_write: Execute write commands (requires approval)

Investigation approach:
1. Peer Status: gluster peer status
2. Volume List: gluster volume list
3. Volume Info: gluster volume info {vol}
4. Volume Status: gluster volume status {vol}
5. Heal Info: gluster volume heal {vol} info
6. Rebalance: gluster volume rebalance {vol} status

Common issues:
- Split brain: Files with conflicting versions
- Heal backlog: Many entries pending heal
- Brick failures: Bricks offline or degraded
- Rebalancing: Data movement after expansion
- Quota exceeded: Volume quota limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        vol = self.volume or "<volume>"
        if "peer" in q:
            return "I'll check peer status.\n\nTOOL: gluster peer status"
        if "heal" in q or "split" in q:
            return f"I'll check heal info.\n\nTOOL: gluster volume heal {vol} info"
        if "status" in q:
            return f"I'll check volume status.\n\nTOOL: gluster volume status {vol}"
        if "rebalance" in q:
            return f"I'll check rebalance status.\n\nTOOL: gluster volume rebalance {vol} status"
        return f"I'll check volume info.\n\nTOOL: gluster volume info {vol}"
