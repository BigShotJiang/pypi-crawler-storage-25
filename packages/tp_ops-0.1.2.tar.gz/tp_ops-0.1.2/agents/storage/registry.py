"""Container Registry Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class ContainerRegistryAgent(ShellAgent):
    """Agent for container registry investigation (Docker Hub, ACR, ECR, GCR, Harbor)."""

    COMMAND_PREFIX = ["docker"]
    TOOL_NAME = "registry"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "images", "image ls", "image inspect",
        "manifest inspect", "history",
        "ecr describe-repositories", "ecr list-images",
        "acr repository list", "acr repository show-tags",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "rmi", "image rm", "image prune",
        "push", "tag",
        "ecr delete-repository", "acr repository delete",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.registry = config.get("registry")
        self.registry_type = config.get("type", "docker")  # docker, ecr, acr, gcr, harbor
        self.region = config.get("region", "us-east-1")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        registry = self.registry or "unknown"
        return f"""You are a container registry investigation agent for '{registry}'.

Registry Type: {self.registry_type.upper()}

Available tools:
- registry: Execute read-only registry commands
- registry_write: Execute write commands (requires approval)

Investigation approach varies by registry type:

For ECR:
1. Repos: aws ecr describe-repositories
2. Images: aws ecr list-images --repository-name <repo>
3. Scan Results: aws ecr describe-image-scan-findings

For ACR:
1. Repos: az acr repository list -n {registry}
2. Tags: az acr repository show-tags -n {registry} --repository <repo>
3. Manifests: az acr repository show-manifests -n {registry} --repository <repo>

For Docker/Harbor:
1. Images: docker images
2. Inspect: docker manifest inspect <image>

Common issues:
- Pull failures: Authentication, image not found
- Push errors: Authentication, quota exceeded
- Storage waste: Untagged images, stale manifests
- Vulnerabilities: CVEs in base images
- Rate limits: Docker Hub pull limits"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.registry_type == "ecr":
            if "repo" in q:
                return "I'll list ECR repositories.\n\nTOOL: registry aws ecr describe-repositories"
            if "scan" in q or "vulnerab" in q:
                return "I'll check image scan findings.\n\nTOOL: registry aws ecr describe-image-scan-findings"
            return "I'll list images.\n\nTOOL: registry aws ecr list-images"
        elif self.registry_type == "acr":
            if "repo" in q:
                return f"I'll list ACR repositories.\n\nTOOL: registry az acr repository list -n {self.registry}"
            return f"I'll show tags.\n\nTOOL: registry az acr repository show-tags -n {self.registry}"
        return "I'll list images.\n\nTOOL: registry docker images"
