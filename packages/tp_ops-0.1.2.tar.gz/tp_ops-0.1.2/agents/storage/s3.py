"""Amazon S3 Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class S3Agent(ShellAgent):
    """Agent for Amazon S3 investigation."""

    COMMAND_PREFIX = ["aws", "s3"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "ls", "s3api list-buckets", "s3api get-bucket-location",
        "s3api get-bucket-policy", "s3api get-bucket-versioning",
        "s3api get-bucket-lifecycle-configuration",
        "s3api get-bucket-replication", "s3api get-public-access-block",
        "s3api list-object-versions", "s3api head-object",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "rm", "mv", "cp", "sync", "mb", "rb",
        "s3api put-bucket-policy", "s3api delete-bucket",
        "s3api put-object", "s3api delete-object",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.bucket = config.get("bucket")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "--region", self.region]

    def _get_system_prompt(self) -> str:
        bucket = self.bucket or "unknown"
        return f"""You are an Amazon S3 investigation agent for bucket '{bucket}'.

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. List Buckets: aws s3 ls
2. Bucket Contents: aws s3 ls s3://{bucket}
3. Bucket Policy: aws s3api get-bucket-policy --bucket {bucket}
4. Versioning: aws s3api get-bucket-versioning --bucket {bucket}
5. Lifecycle: aws s3api get-bucket-lifecycle-configuration --bucket {bucket}
6. Public Access: aws s3api get-public-access-block --bucket {bucket}

Common issues:
- Access denied: IAM policies, bucket policies, ACLs
- Public access: Misconfigured bucket or object ACLs
- Lifecycle issues: Objects not transitioning, wrong storage class
- Replication lag: Cross-region replication delays
- Cost: Storage class optimization, unused objects"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        bucket = self.bucket or "<bucket>"
        if "policy" in q:
            return f"I'll check bucket policy.\n\nTOOL: aws s3api get-bucket-policy --bucket {bucket}"
        if "public" in q or "access" in q:
            return f"I'll check public access settings.\n\nTOOL: aws s3api get-public-access-block --bucket {bucket}"
        if "lifecycle" in q or "storage class" in q:
            return f"I'll check lifecycle configuration.\n\nTOOL: aws s3api get-bucket-lifecycle-configuration --bucket {bucket}"
        return f"I'll list bucket contents.\n\nTOOL: aws s3 ls s3://{bucket}"
