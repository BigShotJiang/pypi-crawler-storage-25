"""Azure Blob Storage Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class AzureBlobAgent(ShellAgent):
    """Agent for Azure Blob Storage investigation."""

    COMMAND_PREFIX = ["az", "storage"]
    TOOL_NAME = "az"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "account list", "account show",
        "container list", "container show",
        "blob list", "blob show",
        "account blob-service-properties show",
        "account management-policy show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "container create", "container delete",
        "blob upload", "blob delete", "blob copy",
        "account update",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.account_name = config.get("account_name")
        self.container = config.get("container")
        self.resource_group = config.get("resource_group")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        account = self.account_name or "unknown"
        return f"""You are an Azure Blob Storage investigation agent for account '{account}'.

Available tools:
- az: Execute read-only Azure CLI commands
- az_write: Execute write commands (requires approval)

Investigation approach:
1. Account Info: az storage account show -n {account} -g {self.resource_group}
2. Containers: az storage container list --account-name {account}
3. Blobs: az storage blob list --container-name {self.container} --account-name {account}
4. Properties: az storage account blob-service-properties show --account-name {account}
5. Lifecycle: az storage account management-policy show --account-name {account}

Common issues:
- Throttling: Request rate exceeded
- Access tier: Wrong tier for access pattern
- Replication: GRS/RAGRS replication status
- Lifecycle: Objects not transitioning tiers
- Cost: Optimize tier based on access patterns"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        account = self.account_name or "<account>"
        if "container" in q:
            return f"I'll list containers.\n\nTOOL: az storage container list --account-name {account}"
        if "lifecycle" in q or "tier" in q:
            return f"I'll check lifecycle policy.\n\nTOOL: az storage account management-policy show --account-name {account}"
        if "blob" in q:
            return f"I'll list blobs.\n\nTOOL: az storage blob list --container-name {self.container} --account-name {account}"
        return f"I'll check storage account.\n\nTOOL: az storage account show -n {account}"
