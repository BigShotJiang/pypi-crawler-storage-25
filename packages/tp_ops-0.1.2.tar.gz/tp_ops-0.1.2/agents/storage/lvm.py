"""LVM/ZFS Storage Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class LVMAgent(ShellAgent):
    """Agent for LVM and ZFS local storage investigation."""

    COMMAND_PREFIX = ["lvm"]
    TOOL_NAME = "storage"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 30

    SAFE_SUBCOMMANDS = [
        "pvs", "vgs", "lvs", "pvdisplay", "vgdisplay", "lvdisplay",
        "zpool status", "zpool list", "zfs list", "zpool iostat",
        "zfs get all", "zpool history",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "pvcreate", "vgcreate", "lvcreate", "pvremove", "vgremove", "lvremove",
        "zpool create", "zpool destroy", "zfs create", "zfs destroy",
        "zpool scrub", "zpool resilver",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.storage_type = config.get("type", "lvm")  # lvm or zfs
        self.volume_group = config.get("vg")
        self.zpool = config.get("pool")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        if self.storage_type == "zfs":
            pool = self.zpool or "all"
            return f"""You are a ZFS storage investigation agent for pool '{pool}'.

Available tools:
- storage: Execute read-only ZFS commands
- storage_write: Execute write commands (requires approval)

Investigation approach:
1. Pool Status: zpool status {pool}
2. Pool List: zpool list
3. ZFS List: zfs list
4. Pool I/O: zpool iostat {pool}
5. Properties: zfs get all {pool}
6. History: zpool history {pool}

Common issues:
- Pool degraded: Drive failure, resilver needed
- Scrub errors: Data corruption detected
- Space issues: Pool approaching capacity
- Snapshot buildup: Old snapshots consuming space
- I/O performance: Slow reads/writes"""
        else:
            vg = self.volume_group or "all"
            return f"""You are an LVM storage investigation agent for VG '{vg}'.

Available tools:
- storage: Execute read-only LVM commands
- storage_write: Execute write commands (requires approval)

Investigation approach:
1. Physical Volumes: pvs
2. Volume Groups: vgs
3. Logical Volumes: lvs
4. PV Details: pvdisplay
5. VG Details: vgdisplay {vg}
6. LV Details: lvdisplay

Common issues:
- VG full: No free extents
- PV failure: Drive issues
- Snapshot overflow: Snapshot COW space exhausted
- Thin pool: Approaching capacity
- Stripe issues: RAID degradation"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.storage_type == "zfs":
            pool = self.zpool or "<pool>"
            if "status" in q or "health" in q:
                return f"I'll check pool status.\n\nTOOL: storage zpool status {pool}"
            if "space" in q or "capacity" in q:
                return "I'll check pool list.\n\nTOOL: storage zpool list"
            if "io" in q or "performance" in q:
                return f"I'll check I/O stats.\n\nTOOL: storage zpool iostat {pool}"
            return f"I'll check pool status.\n\nTOOL: storage zpool status {pool}"
        else:
            vg = self.volume_group or "<vg>"
            if "pv" in q or "physical" in q:
                return "I'll check physical volumes.\n\nTOOL: storage pvs"
            if "lv" in q or "logical" in q:
                return "I'll check logical volumes.\n\nTOOL: storage lvs"
            if "space" in q or "free" in q:
                return f"I'll check volume group.\n\nTOOL: storage vgdisplay {vg}"
            return "I'll check volume groups.\n\nTOOL: storage vgs"
