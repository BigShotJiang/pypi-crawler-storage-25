"""Backup System Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class BackupAgent(ShellAgent):
    """Agent for backup system investigation (Velero, Restic, Azure Backup)."""

    COMMAND_PREFIX = ["velero"]
    TOOL_NAME = "backup"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "backup get", "backup describe", "backup logs",
        "restore get", "restore describe", "restore logs",
        "schedule get", "schedule describe",
        "get backup-locations", "get snapshot-locations",
        "restic snapshots", "restic stats",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "backup create", "backup delete",
        "restore create", "restore delete",
        "schedule create", "schedule delete",
        "restic forget", "restic prune",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.backup_type = config.get("type", "velero")  # velero, restic, azure
        self.namespace = config.get("namespace", "velero")
        self.repository = config.get("repository")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        if self.backup_type == "velero":
            return ["velero", "-n", self.namespace]
        elif self.backup_type == "restic":
            prefix = ["restic"]
            if self.repository:
                prefix.extend(["-r", self.repository])
            return prefix
        return ["velero"]

    def _get_system_prompt(self) -> str:
        return f"""You are a backup system ({self.backup_type}) investigation agent.

Available tools:
- backup: Execute read-only backup commands
- backup_write: Execute write commands (requires approval)

Investigation approach for Velero:
1. Backups: velero backup get
2. Backup Details: velero backup describe <backup>
3. Backup Logs: velero backup logs <backup>
4. Restores: velero restore get
5. Schedules: velero schedule get
6. Locations: velero get backup-locations

Investigation approach for Restic:
1. Snapshots: restic snapshots
2. Stats: restic stats
3. Check: restic check

Common issues:
- Backup failures: Volume snapshot errors, permissions
- Restore failures: Namespace conflicts, PV issues
- Schedule misses: Velero pod issues, schedule disabled
- Stale backups: Retention policy not applied
- Storage issues: Backup location unreachable"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if self.backup_type == "velero":
            if "restore" in q:
                return "I'll list restores.\n\nTOOL: backup restore get"
            if "schedule" in q:
                return "I'll list schedules.\n\nTOOL: backup schedule get"
            if "fail" in q or "error" in q:
                return "I'll check backup logs.\n\nTOOL: backup backup logs <backup>"
            return "I'll list backups.\n\nTOOL: backup backup get"
        elif self.backup_type == "restic":
            if "check" in q:
                return "I'll check repository.\n\nTOOL: backup restic check"
            return "I'll list snapshots.\n\nTOOL: backup restic snapshots"
        return "I'll list backups.\n\nTOOL: backup backup get"
