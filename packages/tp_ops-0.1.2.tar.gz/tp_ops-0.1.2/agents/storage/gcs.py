"""Google Cloud Storage Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class GCSAgent(ShellAgent):
    """Agent for Google Cloud Storage investigation."""

    COMMAND_PREFIX = ["gsutil"]
    TOOL_NAME = "gsutil"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "ls", "du", "stat", "cat", "hash",
        "lifecycle get", "versioning get", "iam get",
        "cors get", "logging get", "notification list",
        "retention get",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "rm", "mv", "cp", "rsync", "mb", "rb",
        "lifecycle set", "iam set", "acl set",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.bucket = config.get("bucket")
        self.project = config.get("project")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        bucket = self.bucket or "unknown"
        return f"""You are a Google Cloud Storage investigation agent for bucket 'gs://{bucket}'.

Available tools:
- gsutil: Execute read-only gsutil commands
- gsutil_write: Execute write commands (requires approval)

Investigation approach:
1. List Buckets: gsutil ls
2. Bucket Contents: gsutil ls -l gs://{bucket}
3. Storage Size: gsutil du -s gs://{bucket}
4. Lifecycle: gsutil lifecycle get gs://{bucket}
5. IAM: gsutil iam get gs://{bucket}
6. Versioning: gsutil versioning get gs://{bucket}

Common issues:
- Access denied: IAM policies, bucket permissions
- Lifecycle issues: Objects not transitioning classes
- Versioning: Noncurrent versions consuming space
- Cost: Wrong storage class, unused objects
- Retention: Policy blocking deletions"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        bucket = self.bucket or "<bucket>"
        if "iam" in q or "permission" in q:
            return f"I'll check IAM policies.\n\nTOOL: gsutil iam get gs://{bucket}"
        if "lifecycle" in q or "storage class" in q:
            return f"I'll check lifecycle policy.\n\nTOOL: gsutil lifecycle get gs://{bucket}"
        if "size" in q or "usage" in q:
            return f"I'll check storage usage.\n\nTOOL: gsutil du -s gs://{bucket}"
        return f"I'll list bucket contents.\n\nTOOL: gsutil ls -l gs://{bucket}"
