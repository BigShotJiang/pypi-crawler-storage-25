"""MinIO Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class MinIOAgent(ShellAgent):
    """Agent for MinIO object storage investigation."""

    COMMAND_PREFIX = ["mc"]
    TOOL_NAME = "mc"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "ls", "stat", "du", "diff", "find",
        "admin info", "admin service", "admin user list",
        "admin policy list", "admin bucket info",
        "admin heal", "admin prometheus",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "rm", "mv", "cp", "mb", "rb",
        "admin user add", "admin user remove",
        "admin policy add", "admin policy remove",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.alias = config.get("alias", "minio")
        self.endpoint = config.get("endpoint")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        return f"""You are a MinIO investigation agent for alias '{self.alias}'.

Endpoint: {self.endpoint}

Available tools:
- mc: Execute read-only MinIO client commands
- mc_write: Execute write commands (requires approval)

Investigation approach:
1. Server Info: mc admin info {self.alias}
2. List Buckets: mc ls {self.alias}
3. Bucket Stats: mc stat {self.alias}/<bucket>
4. Disk Usage: mc du {self.alias}/<bucket>
5. Heal Status: mc admin heal {self.alias} --dry-run
6. Users: mc admin user list {self.alias}

Common issues:
- Erasure coding health: Disk failures, healing needed
- Replication lag: Site replication delays
- Disk failures: Drives offline or degraded
- Policy issues: Bucket or IAM policy misconfigurations
- Capacity: Running out of storage space"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        if "info" in q or "status" in q:
            return f"I'll check server info.\n\nTOOL: mc admin info {self.alias}"
        if "heal" in q:
            return f"I'll check heal status.\n\nTOOL: mc admin heal {self.alias} --dry-run"
        if "bucket" in q or "list" in q:
            return f"I'll list buckets.\n\nTOOL: mc ls {self.alias}"
        if "user" in q or "policy" in q:
            return f"I'll list users.\n\nTOOL: mc admin user list {self.alias}"
        return f"I'll check server info.\n\nTOOL: mc admin info {self.alias}"
