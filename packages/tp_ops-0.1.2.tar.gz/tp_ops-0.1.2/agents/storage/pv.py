"""Kubernetes Persistent Volume Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class PersistentVolumeAgent(ShellAgent):
    """Agent for Kubernetes PersistentVolume investigation."""

    COMMAND_PREFIX = ["kubectl"]
    TOOL_NAME = "kubectl"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "get pv", "get pvc", "describe pv", "describe pvc",
        "get storageclass", "describe storageclass",
        "get volumeattachment", "describe volumeattachment",
        "get events",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "delete pv", "delete pvc", "patch pv", "patch pvc",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.namespace = config.get("namespace", "default")
        self.pv_name = config.get("pv_name")
        self.pvc_name = config.get("pvc_name")
        self.kubeconfig = config.get("kubeconfig")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        prefix = ["kubectl"]
        if self.kubeconfig:
            prefix.extend(["--kubeconfig", self.kubeconfig])
        return prefix

    def _get_system_prompt(self) -> str:
        pv = self.pv_name or "all"
        return f"""You are a Kubernetes PersistentVolume investigation agent for PV '{pv}'.

Namespace: {self.namespace}

Available tools:
- kubectl: Execute read-only kubectl commands
- kubectl_write: Execute write commands (requires approval)

Investigation approach:
1. List PVs: kubectl get pv
2. PV Details: kubectl describe pv {pv}
3. PVCs in Namespace: kubectl get pvc -n {self.namespace}
4. Storage Classes: kubectl get storageclass
5. Volume Attachments: kubectl get volumeattachment
6. Events: kubectl get events --field-selector involvedObject.kind=PersistentVolumeClaim

Common issues:
- Mount failures: Node cannot mount the volume
- Capacity issues: PV too small for PVC request
- Reclaim policy: PV stuck in Released state
- Storage class: Provisioner failures
- CSI driver: Driver not installed or misconfigured"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        pv = self.pv_name or "<pv-name>"
        if "pvc" in q or "claim" in q:
            return f"I'll list PVCs.\n\nTOOL: kubectl get pvc -n {self.namespace}"
        if "describe" in q or "detail" in q:
            return f"I'll describe the PV.\n\nTOOL: kubectl describe pv {pv}"
        if "storageclass" in q or "provisioner" in q:
            return "I'll check storage classes.\n\nTOOL: kubectl get storageclass"
        if "event" in q or "error" in q:
            return f"I'll check events.\n\nTOOL: kubectl get events -n {self.namespace} --field-selector involvedObject.kind=PersistentVolumeClaim"
        return "I'll list PVs.\n\nTOOL: kubectl get pv"
