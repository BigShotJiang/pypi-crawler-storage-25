"""NetApp/Pure Storage Enterprise Storage Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class NetAppAgent(ShellAgent):
    """Agent for NetApp and enterprise storage investigation."""

    COMMAND_PREFIX = ["ssh", "admin@netapp"]
    TOOL_NAME = "storage"
    OUTPUT_FORMAT = "text"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "volume show", "aggregate show", "disk show",
        "snapmirror show", "snapshot show", "lun show",
        "network interface show", "cluster show",
        "storage failover show", "metrocluster show",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "volume create", "volume delete", "volume offline",
        "aggregate create", "aggregate delete",
        "snapmirror break", "snapmirror delete",
        "storage failover takeover",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.cluster = config.get("cluster")
        self.vserver = config.get("vserver")
        super().__init__(name, config, terminal, llm)

    def _get_system_prompt(self) -> str:
        cluster = self.cluster or "unknown"
        return f"""You are a NetApp storage investigation agent for cluster '{cluster}'.

Available tools:
- storage: Execute read-only NetApp CLI commands (via SSH)
- storage_write: Execute write commands (requires approval)

Investigation approach:
1. Cluster: cluster show
2. Volumes: volume show -vserver {self.vserver}
3. Aggregates: aggregate show
4. Disks: disk show
5. SnapMirror: snapmirror show
6. LUNs: lun show
7. Failover: storage failover show

Common issues:
- Volume full: Aggregate space, snapshot reserve
- Replication lag: SnapMirror behind schedule
- Disk failures: Spare disks, RAID degradation
- Performance: Hot volumes, dedup overhead
- MetroCluster: Site sync issues"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        vserver = self.vserver or "<vserver>"
        if "volume" in q:
            return f"I'll check volumes.\n\nTOOL: storage volume show -vserver {vserver}"
        if "aggregate" in q or "space" in q:
            return "I'll check aggregates.\n\nTOOL: storage aggregate show"
        if "replica" in q or "snapmirror" in q or "snap" in q:
            return "I'll check SnapMirror status.\n\nTOOL: storage snapmirror show"
        if "disk" in q or "failure" in q:
            return "I'll check disks.\n\nTOOL: storage disk show"
        return "I'll check cluster status.\n\nTOOL: storage cluster show"
