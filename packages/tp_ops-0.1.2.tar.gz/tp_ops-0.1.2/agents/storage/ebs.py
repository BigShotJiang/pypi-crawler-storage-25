"""AWS EBS Investigation Agent."""

from typing import Any
from agents.base.shell import ShellAgent


class EBSAgent(ShellAgent):
    """Agent for AWS EBS volume investigation."""

    COMMAND_PREFIX = ["aws", "ec2"]
    TOOL_NAME = "aws"
    OUTPUT_FORMAT = "json"
    COMMAND_TIMEOUT = 60

    SAFE_SUBCOMMANDS = [
        "describe-volumes", "describe-volume-status",
        "describe-volume-attribute", "describe-volume-modifications",
        "describe-snapshots", "describe-fast-snapshot-restores",
    ]

    DANGEROUS_SUBCOMMANDS = [
        "create-volume", "delete-volume", "modify-volume",
        "create-snapshot", "delete-snapshot",
        "attach-volume", "detach-volume",
    ]

    def __init__(self, name: str, config: dict[str, Any], terminal, llm=None):
        self.volume_id = config.get("volume_id")
        self.region = config.get("region", "us-east-1")
        super().__init__(name, config, terminal, llm)

    def _get_command_prefix(self) -> list[str]:
        return ["aws", "ec2", "--region", self.region]

    def _get_system_prompt(self) -> str:
        vol_id = self.volume_id or "unknown"
        return f"""You are an AWS EBS investigation agent for volume '{vol_id}'.

Region: {self.region}

Available tools:
- aws: Execute read-only AWS CLI commands
- aws_write: Execute write commands (requires approval)

Investigation approach:
1. Volume Details: aws ec2 describe-volumes --volume-ids {vol_id}
2. Volume Status: aws ec2 describe-volume-status --volume-ids {vol_id}
3. Modifications: aws ec2 describe-volume-modifications --volume-ids {vol_id}
4. Snapshots: aws ec2 describe-snapshots --owner-ids self --filters Name=volume-id,Values={vol_id}
5. CloudWatch: Check VolumeReadOps, VolumeWriteOps, VolumeQueueLength

Common issues:
- IOPS throttling: Baseline IOPS exceeded (gp2/gp3)
- High latency: VolumeQueueLength spike
- Volume stuck: Modifying state not completing
- Snapshot issues: Snapshot stuck or failed
- Cost: Oversized volumes, wrong volume type"""

    def _mock_response(self, query: str) -> str:
        q = query.lower()
        vol_id = self.volume_id or "<volume-id>"
        if "status" in q or "health" in q:
            return f"I'll check volume status.\n\nTOOL: aws ec2 describe-volume-status --volume-ids {vol_id}"
        if "snapshot" in q:
            return f"I'll check snapshots.\n\nTOOL: aws ec2 describe-snapshots --filters Name=volume-id,Values={vol_id}"
        if "iops" in q or "throttl" in q or "performance" in q:
            return "I'll check CloudWatch metrics.\n\nTOOL: aws cloudwatch get-metric-statistics --namespace AWS/EBS --metric-name VolumeReadOps"
        return f"I'll describe the volume.\n\nTOOL: aws ec2 describe-volumes --volume-ids {vol_id}"
