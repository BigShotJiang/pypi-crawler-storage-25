"""Python TNN Binding Tests."""

import sys
import struct
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from mesh.tnn import TNN, TNNSignature, TNNProtocol, TNNHandshake


def test_tnn_init():
    """Test TNN initialization."""
    print("Testing TNN initialization...")
    tnn = TNN(seed=12345)
    assert tnn.model_id != 0, "model_id should be non-zero"
    print(f"  model_id: {tnn.model_id:#x}")
    print("  PASS")


def test_tnn_forward():
    """Test TNN forward pass."""
    print("Testing TNN forward pass...")
    tnn = TNN(seed=42)

    # Create input vector
    input_vec = [i * 4 - 128 for i in range(64)]
    output = tnn.forward(input_vec)

    assert len(output) == 16, f"Output should have 16 elements, got {len(output)}"
    print(f"  Output: {output[:4]}... (showing first 4)")
    print("  PASS")


def test_tnn_deterministic():
    """Test that TNN forward is deterministic."""
    print("Testing TNN determinism...")
    tnn = TNN(seed=999)

    input_vec = [100] * 64
    output1 = tnn.forward(input_vec)
    output2 = tnn.forward(input_vec)

    assert output1 == output2, "Forward pass should be deterministic"
    print("  PASS")


def test_tnn_sign_verify():
    """Test TNN signatures."""
    print("Testing TNN sign/verify...")
    tnn = TNN(seed=11111)

    data = b"Hello, TNN!"
    sig = tnn.sign(data)

    assert isinstance(sig, TNNSignature), "sign should return TNNSignature"
    assert len(sig.bytes) == 32, "Signature should be 32 bytes"

    # Verify should pass
    assert tnn.verify(data, sig), "Valid signature should verify"

    # Modified data should fail
    assert not tnn.verify(b"Hello, TNN?", sig), "Modified data should not verify"

    # Modified signature should fail
    bad_sig = TNNSignature(bytes([b ^ 0xFF for b in sig.bytes[:1]]) + sig.bytes[1:])
    assert not tnn.verify(data, bad_sig), "Modified signature should not verify"

    print("  PASS")


def test_tnn_different_models():
    """Test that different models produce different signatures."""
    print("Testing different models produce different signatures...")
    tnn1 = TNN(seed=111)
    tnn2 = TNN(seed=222)

    data = b"Same data"
    sig1 = tnn1.sign(data)
    sig2 = tnn2.sign(data)

    assert sig1 != sig2, "Different models should produce different signatures"
    print("  PASS")


def test_tnn_serialization():
    """Test TNN save/load."""
    print("Testing TNN serialization...")
    import tempfile
    import os

    tnn1 = TNN(seed=55555)
    input_vec = [50] * 64
    output1 = tnn1.forward(input_vec)

    # Save and load
    with tempfile.NamedTemporaryFile(delete=False, suffix=".tnn") as f:
        path = f.name

    try:
        tnn1.save(path)
        tnn2 = TNN(model_path=path)

        assert tnn2.model_id == tnn1.model_id, "model_id should match"
        output2 = tnn2.forward(input_vec)
        assert output1 == output2, "Output should match after load"
    finally:
        os.unlink(path)

    print("  PASS")


def test_tnn_protocol():
    """Test TNN protocol layer."""
    print("Testing TNN protocol...")
    tnn = TNN(seed=77777)
    protocol = TNNProtocol(tnn, "test-agent", "test-type", ["cap1", "cap2"])

    # Create probe
    probe_data = protocol.create_probe()
    assert len(probe_data) == 48, "Probe should be 48 bytes"
    assert probe_data[:4] == b"TNN1", "Probe should start with magic"

    # Sign message
    payload = b"test message payload"
    signed = protocol.sign_message(payload)
    assert len(signed) >= 48 + len(payload), "Signed message should include header + sig + payload"

    # Verify message
    valid, extracted = protocol.verify_message(signed)
    assert valid, "Message should verify"
    assert extracted == payload, "Payload should match"

    print("  PASS")


def test_tnn_handshake():
    """Test TNN challenge-response handshake."""
    print("Testing TNN handshake...")
    tnn1 = TNN(seed=88888)
    tnn2 = TNN(seed=88888)  # Same seed = same weights

    hs1 = TNNHandshake(tnn1)
    hs2 = TNNHandshake(tnn2)

    # Agent 1 creates challenge
    challenge, nonce = hs1.create_challenge()

    # Agent 2 responds
    response = hs2.respond_to_challenge(challenge, tnn1.model_id, nonce)
    assert len(response) == 32, "Response should be 32 bytes"

    # Agent 1 verifies (using tnn2 since they have same weights)
    valid = hs1.verify_response(response, nonce, tnn2)
    assert valid, "Handshake should succeed with same weights"

    print("  PASS")


def test_tnn_handshake_fails_different_weights():
    """Test that handshake fails with different TNN weights."""
    print("Testing handshake fails with different weights...")
    tnn1 = TNN(seed=11111)
    tnn2 = TNN(seed=22222)  # Different weights

    hs1 = TNNHandshake(tnn1)

    challenge, nonce = hs1.create_challenge()
    response = tnn2.challenge_response(challenge, tnn1.model_id, nonce)
    response_bytes = struct.pack("<16h", *response)

    # This should fail because tnn2 has different weights
    # We verify with tnn2's actual response vs what tnn1 expects
    valid = hs1.verify_response(response_bytes, nonce, tnn1)  # Using tnn1 to verify
    assert not valid, "Handshake should fail with different weights"

    print("  PASS")


if __name__ == "__main__":
    print("\n\033[1mPython TNN Tests\033[0m\n")

    tests = [
        test_tnn_init,
        test_tnn_forward,
        test_tnn_deterministic,
        test_tnn_sign_verify,
        test_tnn_different_models,
        test_tnn_serialization,
        test_tnn_protocol,
        test_tnn_handshake,
        test_tnn_handshake_fails_different_weights,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"  \033[31mFAIL\033[0m: {e}")
            failed += 1

    print(f"\n\033[1mResults: {passed}/{passed + failed} tests passed\033[0m\n")
    sys.exit(0 if failed == 0 else 1)
