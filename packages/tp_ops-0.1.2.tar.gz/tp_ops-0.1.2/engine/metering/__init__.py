"""Metering engine for tracking GB processed."""
