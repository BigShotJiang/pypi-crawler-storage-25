"""Reasoning engine for investigations."""
