"""Data models for the knowledge persistence system.

These dataclasses represent investigations, findings, solutions,
and tool executions that agents store for future reference.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
import hashlib
import json


class FindingType(Enum):
    """Types of findings an agent can discover."""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    ANOMALY = "anomaly"
    ROOT_CAUSE = "root_cause"
    SYMPTOM = "symptom"


class OutcomeType(Enum):
    """Outcome of an investigation or solution."""
    SUCCESS = "success"
    PARTIAL = "partial"
    FAILURE = "failure"
    PENDING = "pending"
    UNKNOWN = "unknown"


@dataclass
class ToolExecution:
    """Record of a tool execution during an investigation."""
    id: Optional[str] = None
    investigation_id: Optional[str] = None
    tool_name: str = ""
    args: str = ""
    output: str = ""
    success: bool = True
    duration_ms: int = 0
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "investigation_id": self.investigation_id,
            "tool_name": self.tool_name,
            "args": self.args,
            "output": self.output,
            "success": self.success,
            "duration_ms": self.duration_ms,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ToolExecution":
        data = data.copy()
        if isinstance(data.get("timestamp"), str):
            data["timestamp"] = datetime.fromisoformat(data["timestamp"])
        return cls(**data)


@dataclass
class Finding:
    """A finding discovered during an investigation."""
    id: Optional[str] = None
    investigation_id: Optional[str] = None
    finding_type: FindingType = FindingType.INFO
    category: str = ""  # e.g., "memory", "network", "config"
    description: str = ""
    evidence: str = ""  # The data that led to this finding
    confidence: float = 1.0  # 0.0 to 1.0
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "investigation_id": self.investigation_id,
            "finding_type": self.finding_type.value,
            "category": self.category,
            "description": self.description,
            "evidence": self.evidence,
            "confidence": self.confidence,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Finding":
        data = data.copy()
        if isinstance(data.get("finding_type"), str):
            data["finding_type"] = FindingType(data["finding_type"])
        if isinstance(data.get("timestamp"), str):
            data["timestamp"] = datetime.fromisoformat(data["timestamp"])
        return cls(**data)


@dataclass
class Solution:
    """A solution applied or suggested during an investigation."""
    id: Optional[str] = None
    investigation_id: Optional[str] = None
    action_type: str = ""  # e.g., "scale", "restart", "config_change"
    description: str = ""
    command: Optional[str] = None  # The actual command if applicable
    applied: bool = False
    successful: Optional[bool] = None
    outcome_observed_at: Optional[datetime] = None
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "investigation_id": self.investigation_id,
            "action_type": self.action_type,
            "description": self.description,
            "command": self.command,
            "applied": self.applied,
            "successful": self.successful,
            "outcome_observed_at": self.outcome_observed_at.isoformat() if self.outcome_observed_at else None,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Solution":
        data = data.copy()
        if isinstance(data.get("timestamp"), str):
            data["timestamp"] = datetime.fromisoformat(data["timestamp"])
        if isinstance(data.get("outcome_observed_at"), str):
            data["outcome_observed_at"] = datetime.fromisoformat(data["outcome_observed_at"])
        return cls(**data)


@dataclass
class Investigation:
    """A complete investigation record."""
    id: Optional[str] = None
    resource_name: str = ""
    agent_type: str = ""  # e.g., "k8s-agent", "postgres-agent"
    problem: str = ""  # Initial problem description
    root_cause: Optional[str] = None
    outcome: OutcomeType = OutcomeType.PENDING

    # Related records
    findings: list[Finding] = field(default_factory=list)
    solutions: list[Solution] = field(default_factory=list)
    tool_executions: list[ToolExecution] = field(default_factory=list)

    # Metadata
    tags: list[str] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    ended_at: Optional[datetime] = None

    # For similarity matching
    keywords: list[str] = field(default_factory=list)

    def compute_signature(self) -> bytes:
        """Compute a hash signature for this investigation's problem."""
        content = f"{self.agent_type}:{self.problem}:{','.join(sorted(self.keywords))}"
        return hashlib.sha256(content.encode()).digest()

    def extract_keywords(self) -> list[str]:
        """Extract keywords from the problem description."""
        # Simple keyword extraction - split on whitespace and punctuation
        import re
        words = re.findall(r'\b\w+\b', self.problem.lower())
        # Filter out common words
        stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
                     'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
                     'would', 'could', 'should', 'may', 'might', 'must', 'shall',
                     'can', 'need', 'dare', 'ought', 'used', 'to', 'of', 'in',
                     'for', 'on', 'with', 'at', 'by', 'from', 'as', 'into',
                     'through', 'during', 'before', 'after', 'above', 'below',
                     'between', 'under', 'again', 'further', 'then', 'once',
                     'here', 'there', 'when', 'where', 'why', 'how', 'all',
                     'each', 'few', 'more', 'most', 'other', 'some', 'such',
                     'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than',
                     'too', 'very', 'just', 'and', 'but', 'if', 'or', 'because',
                     'until', 'while', 'what', 'which', 'who', 'this', 'that',
                     'these', 'those', 'am', 'i', 'my', 'me', 'we', 'our', 'you',
                     'your', 'it', 'its', 'they', 'them', 'their'}
        keywords = [w for w in words if w not in stopwords and len(w) > 2]
        self.keywords = list(set(keywords))
        return self.keywords

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "resource_name": self.resource_name,
            "agent_type": self.agent_type,
            "problem": self.problem,
            "root_cause": self.root_cause,
            "outcome": self.outcome.value,
            "findings": [f.to_dict() for f in self.findings],
            "solutions": [s.to_dict() for s in self.solutions],
            "tool_executions": [t.to_dict() for t in self.tool_executions],
            "tags": self.tags,
            "started_at": self.started_at.isoformat(),
            "ended_at": self.ended_at.isoformat() if self.ended_at else None,
            "keywords": self.keywords,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Investigation":
        data = data.copy()
        if isinstance(data.get("outcome"), str):
            data["outcome"] = OutcomeType(data["outcome"])
        if isinstance(data.get("started_at"), str):
            data["started_at"] = datetime.fromisoformat(data["started_at"])
        if isinstance(data.get("ended_at"), str):
            data["ended_at"] = datetime.fromisoformat(data["ended_at"])

        data["findings"] = [Finding.from_dict(f) for f in data.get("findings", [])]
        data["solutions"] = [Solution.from_dict(s) for s in data.get("solutions", [])]
        data["tool_executions"] = [ToolExecution.from_dict(t) for t in data.get("tool_executions", [])]

        return cls(**data)


@dataclass
class ProblemPattern:
    """A recognized pattern of problems that agents have seen before."""
    id: Optional[str] = None
    pattern_name: str = ""
    agent_type: str = ""
    detection_criteria: str = ""  # JSON-encoded criteria
    description: str = ""
    recommended_actions: str = ""  # JSON-encoded list of actions
    occurrence_count: int = 0
    success_rate: float = 0.0  # How often recommended actions work
    last_seen: datetime = field(default_factory=datetime.now)
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "pattern_name": self.pattern_name,
            "agent_type": self.agent_type,
            "detection_criteria": self.detection_criteria,
            "description": self.description,
            "recommended_actions": self.recommended_actions,
            "occurrence_count": self.occurrence_count,
            "success_rate": self.success_rate,
            "last_seen": self.last_seen.isoformat(),
            "created_at": self.created_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProblemPattern":
        data = data.copy()
        if isinstance(data.get("last_seen"), str):
            data["last_seen"] = datetime.fromisoformat(data["last_seen"])
        if isinstance(data.get("created_at"), str):
            data["created_at"] = datetime.fromisoformat(data["created_at"])
        return cls(**data)
