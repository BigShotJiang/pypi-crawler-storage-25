"""SQLite-based knowledge store for persistent agent memory.

This module provides CRUD operations for investigations, findings,
solutions, and patterns. Uses keyword-based similarity search.
"""

import sqlite3
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional
from contextlib import contextmanager

from engine.knowledge.models import (
    Investigation,
    Finding,
    Solution,
    ToolExecution,
    ProblemPattern,
    FindingType,
    OutcomeType,
)


def get_db_path() -> Path:
    """Get the path to the knowledge database."""
    # Use XDG data directory standard
    data_home = os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share"))
    db_dir = Path(data_home) / "tp-ops"
    db_dir.mkdir(parents=True, exist_ok=True)
    return db_dir / "knowledge.db"


class KnowledgeStore:
    """SQLite-based persistent storage for agent knowledge."""

    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or get_db_path()
        self._ensure_schema()

    @contextmanager
    def _get_connection(self):
        """Get a database connection with proper cleanup."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _ensure_schema(self):
        """Create database schema if it doesn't exist."""
        from engine.knowledge.migration import ensure_schema
        ensure_schema(self.db_path)

    # =========================================================================
    # Investigation CRUD
    # =========================================================================

    def save_investigation(self, investigation: Investigation) -> str:
        """Save an investigation and all related records.

        Returns:
            The investigation ID
        """
        if not investigation.id:
            investigation.id = str(uuid.uuid4())

        # Extract keywords if not already done
        if not investigation.keywords:
            investigation.extract_keywords()

        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Insert/update investigation
            cursor.execute("""
                INSERT OR REPLACE INTO investigations
                (id, resource_name, agent_type, problem, root_cause, outcome,
                 tags, started_at, ended_at, keywords)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                investigation.id,
                investigation.resource_name,
                investigation.agent_type,
                investigation.problem,
                investigation.root_cause,
                investigation.outcome.value,
                ",".join(investigation.tags),
                investigation.started_at.isoformat(),
                investigation.ended_at.isoformat() if investigation.ended_at else None,
                ",".join(investigation.keywords),
            ))

            # Save findings
            for finding in investigation.findings:
                if not finding.id:
                    finding.id = str(uuid.uuid4())
                finding.investigation_id = investigation.id
                cursor.execute("""
                    INSERT OR REPLACE INTO findings
                    (id, investigation_id, finding_type, category, description,
                     evidence, confidence, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    finding.id,
                    finding.investigation_id,
                    finding.finding_type.value,
                    finding.category,
                    finding.description,
                    finding.evidence,
                    finding.confidence,
                    finding.timestamp.isoformat(),
                ))

            # Save solutions
            for solution in investigation.solutions:
                if not solution.id:
                    solution.id = str(uuid.uuid4())
                solution.investigation_id = investigation.id
                cursor.execute("""
                    INSERT OR REPLACE INTO solutions
                    (id, investigation_id, action_type, description, command,
                     applied, successful, outcome_observed_at, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    solution.id,
                    solution.investigation_id,
                    solution.action_type,
                    solution.description,
                    solution.command,
                    solution.applied,
                    solution.successful,
                    solution.outcome_observed_at.isoformat() if solution.outcome_observed_at else None,
                    solution.timestamp.isoformat(),
                ))

            # Save tool executions
            for execution in investigation.tool_executions:
                if not execution.id:
                    execution.id = str(uuid.uuid4())
                execution.investigation_id = investigation.id
                cursor.execute("""
                    INSERT OR REPLACE INTO tool_executions
                    (id, investigation_id, tool_name, args, output,
                     success, duration_ms, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    execution.id,
                    execution.investigation_id,
                    execution.tool_name,
                    execution.args,
                    execution.output[:10000],  # Truncate very long outputs
                    execution.success,
                    execution.duration_ms,
                    execution.timestamp.isoformat(),
                ))

            # Update investigation tags table
            cursor.execute("DELETE FROM investigation_tags WHERE investigation_id = ?",
                          (investigation.id,))
            for tag in investigation.tags:
                cursor.execute("""
                    INSERT INTO investigation_tags (investigation_id, tag, weight)
                    VALUES (?, ?, 1.0)
                """, (investigation.id, tag))

        return investigation.id

    def get_investigation(self, investigation_id: str) -> Optional[Investigation]:
        """Get an investigation by ID with all related records."""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Get investigation
            cursor.execute(
                "SELECT * FROM investigations WHERE id = ?",
                (investigation_id,)
            )
            row = cursor.fetchone()
            if not row:
                return None

            investigation = self._row_to_investigation(row)

            # Get findings
            cursor.execute(
                "SELECT * FROM findings WHERE investigation_id = ?",
                (investigation_id,)
            )
            investigation.findings = [
                self._row_to_finding(r) for r in cursor.fetchall()
            ]

            # Get solutions
            cursor.execute(
                "SELECT * FROM solutions WHERE investigation_id = ?",
                (investigation_id,)
            )
            investigation.solutions = [
                self._row_to_solution(r) for r in cursor.fetchall()
            ]

            # Get tool executions
            cursor.execute(
                "SELECT * FROM tool_executions WHERE investigation_id = ?",
                (investigation_id,)
            )
            investigation.tool_executions = [
                self._row_to_tool_execution(r) for r in cursor.fetchall()
            ]

            return investigation

    def find_similar(
        self,
        query: str,
        agent_type: Optional[str] = None,
        limit: int = 5,
    ) -> list[Investigation]:
        """Find investigations similar to the query.

        Uses keyword matching for similarity search.
        """
        # Extract keywords from query
        import re
        stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
                     'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
                     'would', 'could', 'should', 'may', 'might', 'must', 'shall',
                     'can', 'need', 'to', 'of', 'in', 'for', 'on', 'with', 'at',
                     'by', 'from', 'as', 'into', 'what', 'why', 'how', 'when',
                     'where', 'which', 'who', 'this', 'that', 'and', 'or', 'but',
                     'if', 'i', 'my', 'me', 'we', 'our', 'you', 'your', 'it'}
        words = re.findall(r'\b\w+\b', query.lower())
        query_keywords = [w for w in words if w not in stopwords and len(w) > 2]

        if not query_keywords:
            return []

        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Build query to find investigations with matching keywords
            # Score by number of matching keywords
            keyword_conditions = " OR ".join(
                f"keywords LIKE '%{kw}%'" for kw in query_keywords
            )

            sql = f"""
                SELECT *,
                    ({' + '.join(f"(CASE WHEN keywords LIKE '%{kw}%' THEN 1 ELSE 0 END)" for kw in query_keywords)}) as score
                FROM investigations
                WHERE ({keyword_conditions})
            """

            if agent_type:
                sql += f" AND agent_type = '{agent_type}'"

            sql += " ORDER BY score DESC, started_at DESC LIMIT ?"

            cursor.execute(sql, (limit,))

            investigations = []
            for row in cursor.fetchall():
                inv = self._row_to_investigation(row)
                investigations.append(inv)

            return investigations

    def find_successful_solutions(
        self,
        pattern: Optional[str] = None,
        agent_type: Optional[str] = None,
        limit: int = 10,
    ) -> list[Solution]:
        """Find solutions that were successful."""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            sql = """
                SELECT s.* FROM solutions s
                JOIN investigations i ON s.investigation_id = i.id
                WHERE s.successful = 1
            """
            params = []

            if pattern:
                sql += " AND (s.description LIKE ? OR s.action_type LIKE ?)"
                params.extend([f"%{pattern}%", f"%{pattern}%"])

            if agent_type:
                sql += " AND i.agent_type = ?"
                params.append(agent_type)

            sql += " ORDER BY s.timestamp DESC LIMIT ?"
            params.append(limit)

            cursor.execute(sql, params)
            return [self._row_to_solution(r) for r in cursor.fetchall()]

    # =========================================================================
    # Tool Execution Recording
    # =========================================================================

    def record_tool_execution(
        self,
        investigation_id: str,
        tool_name: str,
        args: str,
        output: str,
        success: bool = True,
        duration_ms: int = 0,
    ) -> str:
        """Record a tool execution during an investigation."""
        execution = ToolExecution(
            id=str(uuid.uuid4()),
            investigation_id=investigation_id,
            tool_name=tool_name,
            args=args,
            output=output[:10000],  # Truncate
            success=success,
            duration_ms=duration_ms,
        )

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO tool_executions
                (id, investigation_id, tool_name, args, output,
                 success, duration_ms, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                execution.id,
                execution.investigation_id,
                execution.tool_name,
                execution.args,
                execution.output,
                execution.success,
                execution.duration_ms,
                execution.timestamp.isoformat(),
            ))

        return execution.id

    # =========================================================================
    # Solution Tracking
    # =========================================================================

    def mark_solution_applied(
        self,
        solution_id: str,
        successful: Optional[bool] = None,
    ) -> None:
        """Mark a solution as applied and optionally record outcome."""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            if successful is not None:
                cursor.execute("""
                    UPDATE solutions
                    SET applied = 1, successful = ?, outcome_observed_at = ?
                    WHERE id = ?
                """, (successful, datetime.now().isoformat(), solution_id))
            else:
                cursor.execute("""
                    UPDATE solutions SET applied = 1 WHERE id = ?
                """, (solution_id,))

    # =========================================================================
    # Pattern Management
    # =========================================================================

    def save_pattern(self, pattern: ProblemPattern) -> str:
        """Save or update a problem pattern."""
        if not pattern.id:
            pattern.id = str(uuid.uuid4())

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO problem_patterns
                (id, pattern_name, agent_type, detection_criteria, description,
                 recommended_actions, occurrence_count, success_rate, last_seen, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                pattern.id,
                pattern.pattern_name,
                pattern.agent_type,
                pattern.detection_criteria,
                pattern.description,
                pattern.recommended_actions,
                pattern.occurrence_count,
                pattern.success_rate,
                pattern.last_seen.isoformat(),
                pattern.created_at.isoformat(),
            ))

        return pattern.id

    def find_pattern(
        self,
        keywords: list[str],
        agent_type: Optional[str] = None,
    ) -> Optional[ProblemPattern]:
        """Find a matching problem pattern."""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Look for patterns whose detection criteria match keywords
            conditions = " OR ".join(
                f"detection_criteria LIKE '%{kw}%'" for kw in keywords
            )

            sql = f"SELECT * FROM problem_patterns WHERE ({conditions})"
            if agent_type:
                sql += f" AND agent_type = '{agent_type}'"
            sql += " ORDER BY occurrence_count DESC LIMIT 1"

            cursor.execute(sql)
            row = cursor.fetchone()

            if row:
                return self._row_to_pattern(row)
            return None

    def increment_pattern_occurrence(self, pattern_id: str) -> None:
        """Increment the occurrence count for a pattern."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE problem_patterns
                SET occurrence_count = occurrence_count + 1, last_seen = ?
                WHERE id = ?
            """, (datetime.now().isoformat(), pattern_id))

    # =========================================================================
    # Conversion Helpers
    # =========================================================================

    def _row_to_investigation(self, row: sqlite3.Row) -> Investigation:
        return Investigation(
            id=row["id"],
            resource_name=row["resource_name"],
            agent_type=row["agent_type"],
            problem=row["problem"],
            root_cause=row["root_cause"],
            outcome=OutcomeType(row["outcome"]),
            tags=row["tags"].split(",") if row["tags"] else [],
            started_at=datetime.fromisoformat(row["started_at"]),
            ended_at=datetime.fromisoformat(row["ended_at"]) if row["ended_at"] else None,
            keywords=row["keywords"].split(",") if row["keywords"] else [],
        )

    def _row_to_finding(self, row: sqlite3.Row) -> Finding:
        return Finding(
            id=row["id"],
            investigation_id=row["investigation_id"],
            finding_type=FindingType(row["finding_type"]),
            category=row["category"],
            description=row["description"],
            evidence=row["evidence"],
            confidence=row["confidence"],
            timestamp=datetime.fromisoformat(row["timestamp"]),
        )

    def _row_to_solution(self, row: sqlite3.Row) -> Solution:
        return Solution(
            id=row["id"],
            investigation_id=row["investigation_id"],
            action_type=row["action_type"],
            description=row["description"],
            command=row["command"],
            applied=bool(row["applied"]),
            successful=bool(row["successful"]) if row["successful"] is not None else None,
            outcome_observed_at=datetime.fromisoformat(row["outcome_observed_at"]) if row["outcome_observed_at"] else None,
            timestamp=datetime.fromisoformat(row["timestamp"]),
        )

    def _row_to_tool_execution(self, row: sqlite3.Row) -> ToolExecution:
        return ToolExecution(
            id=row["id"],
            investigation_id=row["investigation_id"],
            tool_name=row["tool_name"],
            args=row["args"],
            output=row["output"],
            success=bool(row["success"]),
            duration_ms=row["duration_ms"],
            timestamp=datetime.fromisoformat(row["timestamp"]),
        )

    def _row_to_pattern(self, row: sqlite3.Row) -> ProblemPattern:
        return ProblemPattern(
            id=row["id"],
            pattern_name=row["pattern_name"],
            agent_type=row["agent_type"],
            detection_criteria=row["detection_criteria"],
            description=row["description"],
            recommended_actions=row["recommended_actions"],
            occurrence_count=row["occurrence_count"],
            success_rate=row["success_rate"],
            last_seen=datetime.fromisoformat(row["last_seen"]),
            created_at=datetime.fromisoformat(row["created_at"]),
        )

    # =========================================================================
    # Statistics
    # =========================================================================

    def get_stats(self) -> dict:
        """Get statistics about the knowledge store."""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            cursor.execute("SELECT COUNT(*) FROM investigations")
            investigations = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM findings")
            findings = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM solutions WHERE successful = 1")
            successful_solutions = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM tool_executions")
            tool_executions = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM problem_patterns")
            patterns = cursor.fetchone()[0]

            return {
                "investigations": investigations,
                "findings": findings,
                "successful_solutions": successful_solutions,
                "tool_executions": tool_executions,
                "patterns": patterns,
            }
