"""Database schema and migration for the knowledge store.

Handles initial schema creation and migration from JSON history files.
"""

import sqlite3
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional


SCHEMA_VERSION = 1

SCHEMA_SQL = """
-- Schema version tracking
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
);

-- Core investigations table
CREATE TABLE IF NOT EXISTS investigations (
    id TEXT PRIMARY KEY,
    resource_name TEXT NOT NULL,
    agent_type TEXT NOT NULL,
    problem TEXT NOT NULL,
    root_cause TEXT,
    outcome TEXT NOT NULL DEFAULT 'pending',
    tags TEXT,  -- Comma-separated
    started_at TEXT NOT NULL,
    ended_at TEXT,
    keywords TEXT  -- Comma-separated for similarity search
);

-- Findings discovered during investigations
CREATE TABLE IF NOT EXISTS findings (
    id TEXT PRIMARY KEY,
    investigation_id TEXT NOT NULL,
    finding_type TEXT NOT NULL,
    category TEXT,
    description TEXT NOT NULL,
    evidence TEXT,
    confidence REAL DEFAULT 1.0,
    timestamp TEXT NOT NULL,
    FOREIGN KEY (investigation_id) REFERENCES investigations(id)
);

-- Solutions applied or suggested
CREATE TABLE IF NOT EXISTS solutions (
    id TEXT PRIMARY KEY,
    investigation_id TEXT NOT NULL,
    action_type TEXT NOT NULL,
    description TEXT NOT NULL,
    command TEXT,
    applied INTEGER DEFAULT 0,
    successful INTEGER,
    outcome_observed_at TEXT,
    timestamp TEXT NOT NULL,
    FOREIGN KEY (investigation_id) REFERENCES investigations(id)
);

-- Tool execution history
CREATE TABLE IF NOT EXISTS tool_executions (
    id TEXT PRIMARY KEY,
    investigation_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    args TEXT,
    output TEXT,
    success INTEGER DEFAULT 1,
    duration_ms INTEGER DEFAULT 0,
    timestamp TEXT NOT NULL,
    FOREIGN KEY (investigation_id) REFERENCES investigations(id)
);

-- Recognized problem patterns
CREATE TABLE IF NOT EXISTS problem_patterns (
    id TEXT PRIMARY KEY,
    pattern_name TEXT NOT NULL UNIQUE,
    agent_type TEXT NOT NULL,
    detection_criteria TEXT,  -- JSON
    description TEXT,
    recommended_actions TEXT,  -- JSON
    occurrence_count INTEGER DEFAULT 0,
    success_rate REAL DEFAULT 0.0,
    last_seen TEXT,
    created_at TEXT NOT NULL
);

-- Tags for investigations (for efficient querying)
CREATE TABLE IF NOT EXISTS investigation_tags (
    investigation_id TEXT NOT NULL,
    tag TEXT NOT NULL,
    weight REAL DEFAULT 1.0,
    PRIMARY KEY (investigation_id, tag),
    FOREIGN KEY (investigation_id) REFERENCES investigations(id)
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_investigations_agent_type ON investigations(agent_type);
CREATE INDEX IF NOT EXISTS idx_investigations_outcome ON investigations(outcome);
CREATE INDEX IF NOT EXISTS idx_investigations_started_at ON investigations(started_at);
CREATE INDEX IF NOT EXISTS idx_findings_investigation ON findings(investigation_id);
CREATE INDEX IF NOT EXISTS idx_solutions_investigation ON solutions(investigation_id);
CREATE INDEX IF NOT EXISTS idx_solutions_successful ON solutions(successful);
CREATE INDEX IF NOT EXISTS idx_tool_executions_investigation ON tool_executions(investigation_id);
CREATE INDEX IF NOT EXISTS idx_patterns_agent_type ON problem_patterns(agent_type);
CREATE INDEX IF NOT EXISTS idx_tags_tag ON investigation_tags(tag);
"""


def ensure_schema(db_path: Path) -> None:
    """Ensure the database schema exists and is up to date."""
    conn = sqlite3.connect(str(db_path))
    try:
        cursor = conn.cursor()

        # Check current schema version
        cursor.execute("""
            SELECT name FROM sqlite_master
            WHERE type='table' AND name='schema_version'
        """)

        if not cursor.fetchone():
            # Fresh database - create schema
            cursor.executescript(SCHEMA_SQL)
            cursor.execute(
                "INSERT INTO schema_version (version, applied_at) VALUES (?, ?)",
                (SCHEMA_VERSION, datetime.now().isoformat())
            )
            conn.commit()

            # Try to migrate from JSON history
            _migrate_json_history(conn, db_path.parent)
        else:
            # Check if migration needed
            cursor.execute("SELECT MAX(version) FROM schema_version")
            current_version = cursor.fetchone()[0] or 0

            if current_version < SCHEMA_VERSION:
                _run_migrations(conn, current_version, SCHEMA_VERSION)
    finally:
        conn.close()


def _run_migrations(conn: sqlite3.Connection, from_version: int, to_version: int) -> None:
    """Run migrations from one version to another."""
    cursor = conn.cursor()

    # Add migration logic here as schema evolves
    # Example:
    # if from_version < 2:
    #     cursor.execute("ALTER TABLE investigations ADD COLUMN new_field TEXT")
    #     cursor.execute("INSERT INTO schema_version (version, applied_at) VALUES (2, ?)",
    #                   (datetime.now().isoformat(),))

    conn.commit()


def _migrate_json_history(conn: sqlite3.Connection, data_dir: Path) -> None:
    """Migrate existing JSON history files to SQLite.

    Looks for history.json files from previous tp-ops sessions.
    """
    import uuid
    import re

    cursor = conn.cursor()

    # Look for history files in common locations
    history_paths = [
        data_dir / "history.json",
        Path.home() / ".tp-ops" / "history.json",
        Path.home() / ".cache" / "tp-ops" / "history.json",
    ]

    for history_path in history_paths:
        if not history_path.exists():
            continue

        try:
            with open(history_path, 'r') as f:
                history = json.load(f)

            # Handle different history formats
            if isinstance(history, list):
                sessions = history
            elif isinstance(history, dict) and "sessions" in history:
                sessions = history["sessions"]
            else:
                continue

            for session in sessions:
                # Extract investigation data from session
                investigation_id = str(uuid.uuid4())
                resource_name = session.get("resource", session.get("resource_name", "unknown"))
                agent_type = session.get("agent_type", "unknown")

                # Try to get problem from first user message
                messages = session.get("messages", session.get("conversation", []))
                problem = ""
                for msg in messages:
                    if msg.get("role") == "user":
                        problem = msg.get("content", "")[:500]
                        break

                if not problem:
                    problem = f"Session with {resource_name}"

                # Extract keywords
                stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'what',
                            'why', 'how', 'can', 'you', 'i', 'my', 'to', 'do'}
                words = re.findall(r'\b\w+\b', problem.lower())
                keywords = [w for w in words if w not in stopwords and len(w) > 2]

                # Get timestamp
                started_at = session.get("started_at", session.get("timestamp", datetime.now().isoformat()))
                if isinstance(started_at, (int, float)):
                    started_at = datetime.fromtimestamp(started_at).isoformat()

                # Insert investigation
                cursor.execute("""
                    INSERT OR IGNORE INTO investigations
                    (id, resource_name, agent_type, problem, outcome, started_at, keywords)
                    VALUES (?, ?, ?, ?, 'unknown', ?, ?)
                """, (
                    investigation_id,
                    resource_name,
                    agent_type,
                    problem,
                    started_at,
                    ",".join(keywords[:20]),
                ))

                # Extract tool calls from messages
                for msg in messages:
                    content = msg.get("content", "")
                    if "TOOL:" in content:
                        # Parse tool calls
                        tool_matches = re.findall(r'TOOL:\s*(\w+)\s*(.*?)(?=\nTOOL:|\n\n|$)',
                                                  content, re.IGNORECASE)
                        for tool_name, args in tool_matches:
                            cursor.execute("""
                                INSERT INTO tool_executions
                                (id, investigation_id, tool_name, args, output, success, timestamp)
                                VALUES (?, ?, ?, ?, '', 1, ?)
                            """, (
                                str(uuid.uuid4()),
                                investigation_id,
                                tool_name.strip().lower(),
                                args.strip()[:500],
                                started_at,
                            ))

            conn.commit()

            # Rename old history file to mark as migrated
            migrated_path = history_path.with_suffix('.json.migrated')
            if not migrated_path.exists():
                history_path.rename(migrated_path)

        except (json.JSONDecodeError, KeyError, TypeError):
            # Skip malformed history files
            continue
