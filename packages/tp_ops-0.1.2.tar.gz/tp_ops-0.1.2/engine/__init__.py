"""TernaryPhysics Ops Engine - reasoning, execution, and metering."""
