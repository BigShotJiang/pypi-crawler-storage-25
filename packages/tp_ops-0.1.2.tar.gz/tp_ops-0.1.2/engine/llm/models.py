"""Model management - download and locate models automatically."""

import sys
from pathlib import Path
from typing import Optional

# Model configuration - TernaryPhysics hosted (primary)
PRIMARY_REPO = "TernaryPhysics/TernaryPhysics-7B-GGUF"
PRIMARY_FILE = "TernaryPhysics-7B-Q4_K_M.gguf"

# Fallback to bartowski if TernaryPhysics repo not available
FALLBACK_REPO = "bartowski/Qwen2.5-7B-Instruct-GGUF"
FALLBACK_FILE = "Qwen2.5-7B-Instruct-Q4_K_M.gguf"

MODEL_NAME = "TernaryPhysics-7B-Q4_K_M.gguf"
MODEL_SIZE_GB = 4.4


def get_models_dir() -> Path:
    """Get the models directory (~/.cache/tp-ops/models/)."""
    cache_dir = Path.home() / ".cache" / "tp-ops" / "models"
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir


def get_model_path() -> Optional[Path]:
    """Get path to the model if it exists."""
    models_dir = get_models_dir()

    # Check for our model name first
    model_path = models_dir / MODEL_NAME
    if model_path.exists():
        return model_path

    # Also check for bartowski's original name (fallback)
    alt_path = models_dir / FALLBACK_FILE
    if alt_path.exists():
        return alt_path

    return None


def is_model_installed() -> bool:
    """Check if the model is already installed."""
    return get_model_path() is not None


def ensure_model(terminal) -> bool:
    """Ensure model is installed, download if needed. Returns True if ready."""
    if is_model_installed():
        return True

    return download_model(terminal)


def download_model(terminal) -> bool:
    """Download the model. Returns True on success."""

    # Check for huggingface_hub
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        terminal.error("Missing dependency: huggingface_hub")
        terminal.info("Run: pip install huggingface_hub")
        return False

    # Check for llama-cpp-python
    try:
        from llama_cpp import Llama  # noqa: F401
    except ImportError:
        terminal.warning("Installing llama-cpp-python (this may take a minute)...")
        import subprocess
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-q", "llama-cpp-python"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            terminal.error("Failed to install llama-cpp-python")
            terminal.info("Try manually: pip install llama-cpp-python")
            return False

    models_dir = get_models_dir()

    terminal.print()
    terminal.info(f"Downloading TernaryPhysics-7B ({MODEL_SIZE_GB} GB)...")
    terminal.info("This is a one-time download.")
    terminal.print()

    # Try primary repo first (TernaryPhysics), fall back to bartowski
    repos_to_try = [
        (PRIMARY_REPO, PRIMARY_FILE),
        (FALLBACK_REPO, FALLBACK_FILE),
    ]

    for repo, filename in repos_to_try:
        try:
            terminal.info(f"Trying {repo}...")
            downloaded_path = hf_hub_download(
                repo_id=repo,
                filename=filename,
                local_dir=str(models_dir),
            )

            # Rename to our standard model name
            downloaded = Path(downloaded_path)
            if downloaded.exists() and downloaded.name != MODEL_NAME:
                target = models_dir / MODEL_NAME
                if not target.exists():
                    downloaded.rename(target)

            terminal.success("Model ready.")
            terminal.print()
            return True

        except Exception as e:
            terminal.warning(f"Failed to download from {repo}: {e}")
            continue

    terminal.error("Could not download model from any source")
    return False
