"""Local LLM inference using llama.cpp.

TernaryPhysics-7B runs entirely on your CPU using llama.cpp.
No external API calls. Your data never leaves the machine.
"""

import os
from pathlib import Path
from typing import Optional

# Try to import llama-cpp-python, fall back to subprocess if not available
try:
    from llama_cpp import Llama
    LLAMA_CPP_AVAILABLE = True
except ImportError:
    LLAMA_CPP_AVAILABLE = False


class TernaryLLM:
    """Local LLM using llama.cpp for GGUF model inference.

    Runs TernaryPhysics-7B (quantized Qwen2.5-7B-Instruct) at 20-40 tok/s on CPU.
    No GPU required. No API calls. Fully local.
    """

    # Model search paths (in order of preference)
    MODEL_NAMES = [
        "TernaryPhysics-7B-Q4_K_M.gguf",      # Our quantized model
        "TernaryPhysics-7B.gguf",              # Alias
        "Qwen2.5-7B-Instruct-Q4_K_M.gguf",    # Pre-quantized from HF
        "bitnet-2b4t.gguf",                    # Fallback to BitNet
    ]

    def __init__(
        self,
        model_path: Optional[str] = None,
        n_ctx: int = 4096,
        n_threads: Optional[int] = None,
        verbose: bool = False,
    ):
        """Initialize the LLM.

        Args:
            model_path: Path to GGUF model file. Auto-detects if not specified.
            n_ctx: Context window size (default 4096).
            n_threads: Number of CPU threads. Auto-detects if not specified.
            verbose: Show llama.cpp output.
        """
        self.model_path = model_path or self._find_model()
        self.n_ctx = n_ctx
        self.n_threads = n_threads or os.cpu_count()
        self.verbose = verbose
        self._model = None

        # Detect model type from filename
        self.is_qwen = "qwen" in self.model_path.lower() or "ternaryphysics-7b" in self.model_path.lower()
        self.is_bitnet = "bitnet" in self.model_path.lower()

        if not Path(self.model_path).exists():
            raise FileNotFoundError(f"Model not found: {self.model_path}")

    def _find_model(self) -> str:
        """Find model file in standard locations."""
        search_dirs = [
            Path.home() / ".cache" / "tp-ops" / "models",  # pip install location
            Path(__file__).parent.parent.parent / "models",  # dev location
            Path("/models"),  # container mount point
        ]

        for dir_path in search_dirs:
            if not dir_path.exists():
                continue
            for model_name in self.MODEL_NAMES:
                model_path = dir_path / model_name
                if model_path.exists():
                    return str(model_path)

        raise FileNotFoundError(
            "Model not found. Run 'tp-ops drop' to install automatically."
        )

    def _load_model(self) -> "Llama":
        """Lazy-load the model on first use."""
        if self._model is not None:
            return self._model

        if not LLAMA_CPP_AVAILABLE:
            raise ImportError(
                "llama-cpp-python not installed. Install with:\n"
                "  pip install llama-cpp-python\n"
                "Or for GPU acceleration:\n"
                "  CMAKE_ARGS='-DGGML_CUDA=on' pip install llama-cpp-python"
            )

        self._model = Llama(
            model_path=self.model_path,
            n_ctx=self.n_ctx,
            n_threads=self.n_threads,
            verbose=self.verbose,
        )
        return self._model

    def generate(self, prompt: str, max_tokens: int = 256) -> str:
        """Generate a completion from the LLM.

        Args:
            prompt: Text prompt for the model.
            max_tokens: Maximum tokens to generate.

        Returns:
            Generated text.
        """
        model = self._load_model()

        # Use chat completion for instruction models
        if self.is_qwen:
            return self._generate_chat(model, prompt, max_tokens)
        else:
            return self._generate_completion(model, prompt, max_tokens)

    def _generate_chat(self, model: "Llama", prompt: str, max_tokens: int) -> str:
        """Generate using chat format (for instruction-tuned models)."""
        # Parse the prompt into a chat message
        # Our prompts look like: "A Kubernetes expert was asked: X\nThe expert's response is:"
        messages = [
            {
                "role": "system",
                "content": "You are a Kubernetes operations expert. Give concise, accurate answers about cluster management, kubectl commands, and troubleshooting. Be direct and technical."
            },
            {
                "role": "user",
                "content": self._extract_question(prompt)
            }
        ]

        response = model.create_chat_completion(
            messages=messages,
            max_tokens=max_tokens,
            temperature=0.7,
            top_p=0.9,
            stop=["<|im_end|>", "<|endoftext|>"],
        )

        return response["choices"][0]["message"]["content"].strip()

    def _generate_completion(self, model: "Llama", prompt: str, max_tokens: int) -> str:
        """Generate using raw completion (for base models)."""
        response = model(
            prompt,
            max_tokens=max_tokens,
            temperature=0.7,
            top_p=0.9,
            stop=["\n\n", "Question:", "User:"],
            echo=False,
        )

        text = response["choices"][0]["text"].strip()
        return self._clean_response(text)

    def _extract_question(self, prompt: str) -> str:
        """Extract the user question from our prompt format."""
        # Handle format: "A Kubernetes expert was asked: X\nThe expert's response is:"
        if "was asked:" in prompt:
            parts = prompt.split("was asked:")
            if len(parts) > 1:
                question = parts[1].split("\n")[0].strip()
                return question

        # Handle format: "Context: ...\nQuestion: X\nAnswer:"
        if "Question:" in prompt:
            parts = prompt.split("Question:")
            if len(parts) > 1:
                question = parts[1].split("\n")[0].strip()
                return question

        # Fallback: use the whole prompt
        return prompt.strip()

    def _clean_response(self, text: str) -> str:
        """Clean up raw completion response."""
        if not text:
            return text

        # Take first few coherent sentences
        sentences = []
        current = ""
        for char in text:
            current += char
            if char in '.!?' and len(current.strip()) > 10:
                sentences.append(current.strip())
                current = ""
                if len(sentences) >= 3:
                    break

        if sentences:
            return ' '.join(sentences)

        # Fallback: truncate at reasonable length
        if len(text) > 300:
            text = text[:300].rsplit(' ', 1)[0] + '...'

        return text

    def get_model_info(self) -> dict:
        """Get information about the loaded model."""
        return {
            "path": self.model_path,
            "type": "qwen" if self.is_qwen else "bitnet" if self.is_bitnet else "unknown",
            "context_size": self.n_ctx,
            "threads": self.n_threads,
        }


# Convenience function for quick testing
def test_inference():
    """Quick test of the LLM."""
    print("Loading TernaryLLM...")
    llm = TernaryLLM(verbose=True)
    print(f"Model: {llm.model_path}")
    print(f"Type: {'Qwen (instruction-tuned)' if llm.is_qwen else 'Base model'}")
    print()

    questions = [
        "What is a Kubernetes pod?",
        "How do I check pod logs?",
        "What causes CrashLoopBackOff?",
    ]

    for q in questions:
        print(f"Q: {q}")
        response = llm.generate(f"A Kubernetes expert was asked: {q}\nThe expert's response is:")
        print(f"A: {response}")
        print()


if __name__ == "__main__":
    test_inference()
