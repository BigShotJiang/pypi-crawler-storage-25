"""Configuration for agent server."""

import os
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings


class MeshConfig(BaseModel):
    """Mesh network configuration."""
    enabled: bool = True
    port: int = 7100
    peers: list[dict[str, Any]] = Field(default_factory=list)


class ModelConfig(BaseModel):
    """LLM model configuration."""
    path: Optional[str] = None
    auto_download: bool = True
    n_ctx: int = 4096
    n_gpu_layers: int = 0


class ServerConfig(BaseModel):
    """HTTP server configuration."""
    host: str = "0.0.0.0"
    port: int = 8080
    workers: int = 1


class AgentServerConfig(BaseSettings):
    """Main configuration for the agent server."""

    # Agent identity
    agent_type: str = Field(..., description="Type of agent (k8s-agent, vm-agent, etc.)")
    resource_name: str = Field(..., description="Name of the resource this agent manages")

    # Resource connection config (varies by agent type)
    resource_config: dict[str, Any] = Field(default_factory=dict)

    # Sub-configurations
    mesh: MeshConfig = Field(default_factory=MeshConfig)
    model: ModelConfig = Field(default_factory=ModelConfig)
    server: ServerConfig = Field(default_factory=ServerConfig)

    # Data directories
    data_dir: Path = Field(default=Path("/var/lib/tp-ops"))

    # Backend API (for usage reporting)
    backend_url: Optional[str] = None
    api_token: Optional[str] = None

    class Config:
        env_prefix = "TP_OPS_"
        env_nested_delimiter = "__"

    @classmethod
    def from_yaml(cls, path: str | Path) -> "AgentServerConfig":
        """Load configuration from YAML file."""
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls(**data)

    @classmethod
    def from_env(cls) -> "AgentServerConfig":
        """Load configuration from environment variables."""
        return cls(
            agent_type=os.environ.get("TP_OPS_AGENT_TYPE", "k8s-agent"),
            resource_name=os.environ.get("TP_OPS_RESOURCE_NAME", "default"),
        )

    def get_knowledge_db_path(self) -> Path:
        """Get path to knowledge database."""
        return self.data_dir / "knowledge.db"

    def get_model_cache_dir(self) -> Path:
        """Get path to model cache directory."""
        model_dir = self.data_dir / "models"
        model_dir.mkdir(parents=True, exist_ok=True)
        return model_dir


def load_config(config_path: Optional[str] = None) -> AgentServerConfig:
    """Load configuration from file or environment."""
    if config_path:
        return AgentServerConfig.from_yaml(config_path)

    # Check for config file in standard locations
    standard_paths = [
        Path("/etc/tp-ops/agent.yaml"),
        Path.home() / ".config" / "tp-ops" / "agent.yaml",
        Path("agent.yaml"),
    ]

    for path in standard_paths:
        if path.exists():
            return AgentServerConfig.from_yaml(path)

    # Fall back to environment variables
    return AgentServerConfig.from_env()
