"""FastAPI server for deployed tp-ops agents."""

import asyncio
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Any, Optional

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware

from agent_server.config import AgentServerConfig
from agent_server.protocol import (
    AgentStatus,
    ActionStatus,
    ChatRequest,
    ChatResponse,
    InvestigateRequest,
    InvestigateResponse,
    ScanRequest,
    ScanResponse,
    StatusResponse,
    HealthResponse,
    ApproveRequest,
    ApproveResponse,
    HistoryEntry,
    HistoryResponse,
    MeshPeer,
    MeshStatusResponse,
    Finding,
    Solution,
    ScanIssue,
)

# Version
__version__ = "0.1.0"


class AgentServer:
    """Server that hosts a deployed tp-ops agent."""

    def __init__(self, config: AgentServerConfig):
        self.config = config
        self.started_at = datetime.utcnow()
        self.status = AgentStatus.STARTING
        self.total_requests = 0
        self.bytes_processed = 0

        # Agent instance (created on startup)
        self._agent = None
        self._mesh_wrapper = None
        self._llm = None

        # Session management
        self._sessions: dict[str, dict[str, Any]] = {}

        # Pending actions
        self._pending_actions: dict[str, dict[str, Any]] = {}

        # History
        self._history: list[HistoryEntry] = []

    async def initialize(self) -> None:
        """Initialize the agent and LLM."""
        try:
            # Load LLM
            self._llm = await self._load_llm()

            # Create agent
            self._agent = await self._create_agent()

            # Wrap with mesh
            self._mesh_wrapper = await self._create_mesh_wrapper()

            # Start mesh
            if self._mesh_wrapper:
                self._mesh_wrapper.start()

            self.status = AgentStatus.READY

        except Exception as e:
            self.status = AgentStatus.ERROR
            raise RuntimeError(f"Failed to initialize agent: {e}")

    async def shutdown(self) -> None:
        """Shutdown the agent and mesh."""
        self.status = AgentStatus.STOPPING

        if self._mesh_wrapper:
            self._mesh_wrapper.stop()

        self.status = AgentStatus.STOPPING

    async def _load_llm(self):
        """Load the LLM model."""
        if not self.config.model.auto_download:
            return None

        try:
            from engine.llm.inference import TernaryLLM

            # Use custom path if specified
            model_path = self.config.model.path
            if model_path:
                return TernaryLLM(model_path=model_path)

            return TernaryLLM()

        except ImportError:
            return None
        except FileNotFoundError:
            return None

    async def _create_agent(self):
        """Create the appropriate agent based on type."""
        agent_type = self.config.agent_type
        resource_config = self.config.resource_config

        # Import agent classes
        if agent_type == "k8s-agent":
            from agents.kubernetes.chat_agent import KubernetesChatAgent
            agent_class = KubernetesChatAgent
        elif agent_type == "vm-agent":
            from agents.compute.linux_vm import LinuxVMAgent
            agent_class = LinuxVMAgent
        elif agent_type == "postgres-agent":
            from agents.databases.postgresql import PostgreSQLAgent
            agent_class = PostgreSQLAgent
        elif agent_type == "redis-agent":
            from agents.databases.redis import RedisAgent
            agent_class = RedisAgent
        else:
            raise ValueError(f"Unknown agent type: {agent_type}")

        # Create a server-compatible terminal
        terminal = ServerTerminal()

        return agent_class(
            name=self.config.resource_name,
            config=resource_config,
            terminal=terminal,
            llm=self._llm,
        )

    async def _create_mesh_wrapper(self):
        """Create mesh wrapper for the agent."""
        if not self.config.mesh.enabled:
            return None

        try:
            from mesh import MeshAgentWrapper

            wrapper = MeshAgentWrapper(
                self._agent,
                agent_type=self.config.agent_type,
                port=self.config.mesh.port,
            )

            # Add static peers
            for peer in self.config.mesh.peers:
                wrapper.add_peer(
                    peer["name"],
                    peer["agent_type"],
                    peer["host"],
                    peer.get("port", 7100),
                )

            return wrapper

        except ImportError:
            return None

    def chat(self, request: ChatRequest) -> ChatResponse:
        """Process a chat message."""
        self.total_requests += 1

        if self.status != AgentStatus.READY:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Agent not ready: {self.status.value}",
            )

        # Get or create session
        session_id = request.session_id or str(uuid.uuid4())
        if session_id not in self._sessions:
            self._sessions[session_id] = {
                "created_at": datetime.utcnow(),
                "messages": [],
            }

        # Use mesh wrapper if available, otherwise base agent
        agent = self._mesh_wrapper or self._agent

        # Get response
        try:
            response = agent.chat(request.message)
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Chat failed: {e}",
            )

        # Track session
        self._sessions[session_id]["messages"].append({
            "user": request.message,
            "assistant": response,
            "timestamp": datetime.utcnow().isoformat(),
        })

        # Update bytes processed
        self.bytes_processed = agent.bytes_processed

        # Get pending actions
        pending = [
            action.id for action in agent.pending_actions
            if action.approved is None
        ] if hasattr(agent, 'pending_actions') else []

        return ChatResponse(
            response=response,
            session_id=session_id,
            pending_actions=pending,
        )

    def investigate(self, request: InvestigateRequest) -> InvestigateResponse:
        """Run an investigation."""
        self.total_requests += 1
        start_time = datetime.utcnow()
        investigation_id = str(uuid.uuid4())

        if self.status != AgentStatus.READY:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Agent not ready: {self.status.value}",
            )

        agent = self._mesh_wrapper or self._agent

        # For now, run investigation through chat
        # Full investigation would use the BaseAgent.investigate() method
        try:
            response = agent.chat(f"Investigate: {request.problem}")
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Investigation failed: {e}",
            )

        duration = (datetime.utcnow() - start_time).total_seconds()
        self.bytes_processed = agent.bytes_processed

        # Parse response into findings and solutions
        # This is a simplified version - full implementation would parse structured output
        findings = [
            Finding(
                category="general",
                description=response[:500] if response else "No findings",
                severity="info",
            )
        ]

        # Record in history
        self._history.append(HistoryEntry(
            id=investigation_id,
            type="investigation",
            timestamp=start_time,
            problem=request.problem,
            findings_count=len(findings),
            solutions_count=0,
            issues_count=0,
            duration_seconds=duration,
            bytes_processed=agent.bytes_processed,
        ))

        return InvestigateResponse(
            investigation_id=investigation_id,
            problem=request.problem,
            findings=findings,
            solutions=[],
            root_cause=None,
            duration_seconds=duration,
            bytes_processed=agent.bytes_processed,
        )

    def scan(self, request: ScanRequest) -> ScanResponse:
        """Run a scan."""
        self.total_requests += 1
        start_time = datetime.utcnow()
        scan_id = str(uuid.uuid4())

        if self.status != AgentStatus.READY:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"Agent not ready: {self.status.value}",
            )

        agent = self._mesh_wrapper or self._agent

        # Run scan through chat
        scan_type = "deep" if request.deep else "quick"
        try:
            response = agent.chat(f"Run a {scan_type} health scan")
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Scan failed: {e}",
            )

        duration = (datetime.utcnow() - start_time).total_seconds()
        self.bytes_processed = agent.bytes_processed

        # Parse response into issues
        issues: list[ScanIssue] = []
        summary = {"info": 0, "warning": 0, "critical": 0}

        # Record in history
        self._history.append(HistoryEntry(
            id=scan_id,
            type="scan",
            timestamp=start_time,
            problem=None,
            findings_count=0,
            solutions_count=0,
            issues_count=len(issues),
            duration_seconds=duration,
            bytes_processed=agent.bytes_processed,
        ))

        return ScanResponse(
            scan_id=scan_id,
            issues=issues,
            summary=summary,
            duration_seconds=duration,
            bytes_processed=agent.bytes_processed,
        )

    def get_status(self) -> StatusResponse:
        """Get agent status."""
        uptime = (datetime.utcnow() - self.started_at).total_seconds()

        mesh_peers = 0
        if self._mesh_wrapper and hasattr(self._mesh_wrapper, 'get_peers'):
            peers = self._mesh_wrapper.get_peers()
            mesh_peers = len(peers) if peers else 0

        model_name = None
        if self._llm and hasattr(self._llm, 'model_path'):
            model_name = self._llm.model_path.split("/")[-1].replace(".gguf", "")

        return StatusResponse(
            agent_type=self.config.agent_type,
            resource_name=self.config.resource_name,
            status=self.status,
            uptime_seconds=uptime,
            model_loaded=self._llm is not None,
            model_name=model_name,
            mesh_enabled=self.config.mesh.enabled,
            mesh_peers=mesh_peers,
            active_sessions=len(self._sessions),
            total_requests=self.total_requests,
            bytes_processed_total=self.bytes_processed,
            started_at=self.started_at,
            version=__version__,
        )

    def health_check(self) -> HealthResponse:
        """Health check endpoint."""
        checks = {
            "agent_initialized": self._agent is not None,
            "llm_loaded": self._llm is not None or not self.config.model.auto_download,
            "status_ready": self.status == AgentStatus.READY,
        }

        if self.config.mesh.enabled:
            checks["mesh_running"] = self._mesh_wrapper is not None

        healthy = all(checks.values())

        return HealthResponse(
            healthy=healthy,
            status=self.status,
            checks=checks,
            message=None if healthy else "Some health checks failed",
        )

    def approve_action(self, request: ApproveRequest) -> ApproveResponse:
        """Approve or reject a pending action."""
        action_id = request.action_id

        if action_id not in self._pending_actions:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Action not found: {action_id}",
            )

        action = self._pending_actions[action_id]

        if request.approved:
            # Execute the action
            try:
                # This would execute the actual tool
                result = "Action executed successfully"
                action_status = ActionStatus.EXECUTED
            except Exception as e:
                result = None
                error = str(e)
                action_status = ActionStatus.FAILED
        else:
            result = None
            error = request.reason or "Rejected by user"
            action_status = ActionStatus.REJECTED

        del self._pending_actions[action_id]

        return ApproveResponse(
            action_id=action_id,
            status=action_status,
            result=result if request.approved else None,
            error=error if not request.approved or action_status == ActionStatus.FAILED else None,
        )

    def get_history(self, page: int = 1, page_size: int = 20) -> HistoryResponse:
        """Get investigation/scan history."""
        start = (page - 1) * page_size
        end = start + page_size

        entries = sorted(
            self._history,
            key=lambda x: x.timestamp,
            reverse=True,
        )[start:end]

        return HistoryResponse(
            entries=entries,
            total_count=len(self._history),
            page=page,
            page_size=page_size,
        )

    def get_mesh_status(self) -> MeshStatusResponse:
        """Get mesh network status."""
        if not self.config.mesh.enabled or not self._mesh_wrapper:
            return MeshStatusResponse(
                enabled=False,
                local_port=self.config.mesh.port,
            )

        peers = []
        if hasattr(self._mesh_wrapper, 'get_peers'):
            raw_peers = self._mesh_wrapper.get_peers() or []
            for peer in raw_peers:
                peers.append(MeshPeer(
                    name=peer.name,
                    agent_type=peer.agent_type,
                    host=peer.host,
                    port=peer.port,
                    status="healthy" if peer.is_healthy() else "unhealthy",
                    last_seen=getattr(peer, 'last_seen', None),
                ))

        stats = {}
        if hasattr(self._mesh_wrapper, 'get_stats'):
            stats = self._mesh_wrapper.get_stats()

        return MeshStatusResponse(
            enabled=True,
            local_port=self.config.mesh.port,
            peers=peers,
            knowledge_version=stats.get("knowledge_version", 0),
            broadcasts_sent=stats.get("broadcasts_sent", 0),
            broadcasts_received=stats.get("broadcasts_received", 0),
        )


class ServerTerminal:
    """A no-op terminal for server-side agent execution."""

    def print(self, message: str = "") -> None:
        pass

    def info(self, message: str) -> None:
        pass

    def warning(self, message: str) -> None:
        pass

    def error(self, message: str) -> None:
        pass

    def success(self, message: str) -> None:
        pass


# Global agent server instance
_agent_server: Optional[AgentServer] = None


def get_agent_server() -> AgentServer:
    """Get the global agent server instance."""
    if _agent_server is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Agent server not initialized",
        )
    return _agent_server


def create_app(config: AgentServerConfig) -> FastAPI:
    """Create the FastAPI application."""
    global _agent_server

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        """Manage application lifecycle."""
        global _agent_server
        _agent_server = AgentServer(config)
        await _agent_server.initialize()
        yield
        await _agent_server.shutdown()

    app = FastAPI(
        title="tp-ops Agent Server",
        description="Deployed tp-ops agent API",
        version=__version__,
        lifespan=lifespan,
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # --- Routes ---

    @app.get("/api/v1/health", response_model=HealthResponse)
    async def health():
        """Health check endpoint."""
        return get_agent_server().health_check()

    @app.get("/api/v1/status", response_model=StatusResponse)
    async def get_status():
        """Get agent status."""
        return get_agent_server().get_status()

    @app.post("/api/v1/chat", response_model=ChatResponse)
    async def chat(request: ChatRequest):
        """Chat with the agent."""
        return get_agent_server().chat(request)

    @app.post("/api/v1/investigate", response_model=InvestigateResponse)
    async def investigate(request: InvestigateRequest):
        """Run an investigation."""
        return get_agent_server().investigate(request)

    @app.post("/api/v1/scan", response_model=ScanResponse)
    async def scan(request: ScanRequest):
        """Run a scan."""
        return get_agent_server().scan(request)

    @app.post("/api/v1/approve", response_model=ApproveResponse)
    async def approve(request: ApproveRequest):
        """Approve or reject a pending action."""
        return get_agent_server().approve_action(request)

    @app.get("/api/v1/history", response_model=HistoryResponse)
    async def history(page: int = 1, page_size: int = 20):
        """Get investigation/scan history."""
        return get_agent_server().get_history(page, page_size)

    @app.get("/api/v1/mesh", response_model=MeshStatusResponse)
    async def mesh_status():
        """Get mesh network status."""
        return get_agent_server().get_mesh_status()

    return app
