"""Protocol models for CLI <-> Agent communication."""

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class AgentStatus(str, Enum):
    """Agent runtime status."""
    STARTING = "starting"
    READY = "ready"
    BUSY = "busy"
    ERROR = "error"
    STOPPING = "stopping"


class ActionStatus(str, Enum):
    """Status of a pending action."""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXECUTED = "executed"
    FAILED = "failed"


# --- Chat ---

class ChatRequest(BaseModel):
    """Request to chat with the agent."""
    message: str = Field(..., description="User message")
    session_id: Optional[str] = Field(None, description="Session ID for conversation continuity")


class ChatResponse(BaseModel):
    """Response from agent chat."""
    response: str = Field(..., description="Agent response")
    session_id: str = Field(..., description="Session ID for follow-up messages")
    pending_actions: list[str] = Field(default_factory=list, description="Actions awaiting approval")


# --- Investigate ---

class InvestigateRequest(BaseModel):
    """Request to run an investigation."""
    problem: str = Field(..., description="Problem description to investigate")
    deep: bool = Field(False, description="Run deep investigation")


class Finding(BaseModel):
    """A finding from investigation."""
    category: str
    description: str
    severity: str = "info"
    evidence: Optional[str] = None


class Solution(BaseModel):
    """A proposed solution."""
    action_type: str
    description: str
    command: Optional[str] = None
    requires_approval: bool = True


class InvestigateResponse(BaseModel):
    """Response from investigation."""
    investigation_id: str
    problem: str
    findings: list[Finding] = Field(default_factory=list)
    solutions: list[Solution] = Field(default_factory=list)
    root_cause: Optional[str] = None
    duration_seconds: float
    bytes_processed: int


# --- Scan ---

class ScanRequest(BaseModel):
    """Request to scan the resource."""
    deep: bool = Field(False, description="Run deep scan")
    categories: Optional[list[str]] = Field(None, description="Categories to scan")


class ScanIssue(BaseModel):
    """An issue found during scan."""
    category: str
    severity: str
    title: str
    description: str
    recommendation: Optional[str] = None


class ScanResponse(BaseModel):
    """Response from scan."""
    scan_id: str
    issues: list[ScanIssue] = Field(default_factory=list)
    summary: dict[str, int] = Field(default_factory=dict, description="Count by severity")
    duration_seconds: float
    bytes_processed: int


# --- Status ---

class StatusResponse(BaseModel):
    """Agent status information."""
    agent_type: str
    resource_name: str
    status: AgentStatus
    uptime_seconds: float
    model_loaded: bool
    model_name: Optional[str] = None
    mesh_enabled: bool
    mesh_peers: int = 0
    active_sessions: int = 0
    total_requests: int = 0
    bytes_processed_total: int = 0
    started_at: datetime
    version: str


# --- Health ---

class HealthResponse(BaseModel):
    """Health check response."""
    healthy: bool
    status: AgentStatus
    checks: dict[str, bool] = Field(default_factory=dict)
    message: Optional[str] = None


# --- Approve ---

class ApproveRequest(BaseModel):
    """Request to approve or reject an action."""
    action_id: str = Field(..., description="ID of the action to approve/reject")
    approved: bool = Field(..., description="True to approve, False to reject")
    reason: Optional[str] = Field(None, description="Optional reason for decision")


class ApproveResponse(BaseModel):
    """Response from approval."""
    action_id: str
    status: ActionStatus
    result: Optional[str] = None
    error: Optional[str] = None


# --- History ---

class HistoryEntry(BaseModel):
    """A historical investigation or scan."""
    id: str
    type: str  # "investigation" or "scan"
    timestamp: datetime
    problem: Optional[str] = None
    findings_count: int = 0
    solutions_count: int = 0
    issues_count: int = 0
    duration_seconds: float
    bytes_processed: int


class HistoryResponse(BaseModel):
    """Response with investigation/scan history."""
    entries: list[HistoryEntry] = Field(default_factory=list)
    total_count: int = 0
    page: int = 1
    page_size: int = 20


# --- Mesh ---

class MeshPeer(BaseModel):
    """Information about a mesh peer."""
    name: str
    agent_type: str
    host: str
    port: int
    status: str
    last_seen: Optional[datetime] = None


class MeshStatusResponse(BaseModel):
    """Mesh network status."""
    enabled: bool
    local_port: int
    peers: list[MeshPeer] = Field(default_factory=list)
    knowledge_version: int = 0
    broadcasts_sent: int = 0
    broadcasts_received: int = 0
