"""Daemon entry point for tp-ops agent server."""

import argparse
import logging
import os
import signal
import sys
from pathlib import Path

import uvicorn

from agent_server.config import AgentServerConfig, load_config
from agent_server.server import create_app

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("tp-ops-agent")


def download_model_only() -> int:
    """Download the model and exit."""
    logger.info("Downloading model...")

    try:
        from engine.llm.models import ensure_model

        class FakeTerminal:
            def print(self, msg=""): logger.info(msg)
            def info(self, msg): logger.info(msg)
            def warning(self, msg): logger.warning(msg)
            def error(self, msg): logger.error(msg)
            def success(self, msg): logger.info(msg)

        terminal = FakeTerminal()
        if ensure_model(terminal):
            logger.info("Model downloaded successfully")
            return 0
        else:
            logger.error("Failed to download model")
            return 1

    except Exception as e:
        logger.error(f"Failed to download model: {e}")
        return 1


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        prog="tp-ops-agent-server",
        description="Run a deployed tp-ops agent server",
    )

    parser.add_argument(
        "--config", "-c",
        type=str,
        help="Path to configuration file (YAML)",
    )

    parser.add_argument(
        "--agent-type",
        type=str,
        choices=["k8s-agent", "vm-agent", "postgres-agent", "redis-agent"],
        help="Type of agent to run",
    )

    parser.add_argument(
        "--resource-name",
        type=str,
        help="Name of the resource this agent manages",
    )

    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Host to bind to (default: 0.0.0.0)",
    )

    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port to listen on (default: 8080)",
    )

    parser.add_argument(
        "--mesh-port",
        type=int,
        default=7100,
        help="Port for mesh communication (default: 7100)",
    )

    parser.add_argument(
        "--no-mesh",
        action="store_true",
        help="Disable mesh networking",
    )

    parser.add_argument(
        "--no-model",
        action="store_true",
        help="Don't load LLM model (mock mode)",
    )

    parser.add_argument(
        "--model-path",
        type=str,
        help="Path to LLM model file",
    )

    parser.add_argument(
        "--download-model-only",
        action="store_true",
        help="Download the model and exit",
    )

    parser.add_argument(
        "--data-dir",
        type=str,
        default="/var/lib/tp-ops",
        help="Data directory (default: /var/lib/tp-ops)",
    )

    parser.add_argument(
        "--log-level",
        type=str,
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Log level (default: INFO)",
    )

    # Resource-specific options
    parser.add_argument(
        "--kubeconfig",
        type=str,
        help="Path to kubeconfig file (for k8s-agent)",
    )

    parser.add_argument(
        "--context",
        type=str,
        help="Kubernetes context to use (for k8s-agent)",
    )

    parser.add_argument(
        "--ssh-host",
        type=str,
        help="SSH host (for vm-agent)",
    )

    parser.add_argument(
        "--ssh-user",
        type=str,
        default="root",
        help="SSH user (for vm-agent)",
    )

    parser.add_argument(
        "--ssh-key",
        type=str,
        help="Path to SSH private key (for vm-agent)",
    )

    parser.add_argument(
        "--db-host",
        type=str,
        help="Database host (for database agents)",
    )

    parser.add_argument(
        "--db-port",
        type=int,
        help="Database port (for database agents)",
    )

    parser.add_argument(
        "--db-user",
        type=str,
        help="Database user (for database agents)",
    )

    parser.add_argument(
        "--db-password",
        type=str,
        help="Database password (for database agents)",
    )

    parser.add_argument(
        "--db-name",
        type=str,
        help="Database name (for database agents)",
    )

    return parser.parse_args()


def build_config_from_args(args: argparse.Namespace) -> AgentServerConfig:
    """Build configuration from command line arguments."""
    # Start with file config if provided
    if args.config:
        config = load_config(args.config)
    else:
        # Build from args
        if not args.agent_type:
            raise ValueError("--agent-type is required when not using --config")
        if not args.resource_name:
            raise ValueError("--resource-name is required when not using --config")

        # Build resource config based on agent type
        resource_config = {}

        if args.agent_type == "k8s-agent":
            if args.kubeconfig:
                resource_config["kubeconfig"] = args.kubeconfig
            if args.context:
                resource_config["context"] = args.context

        elif args.agent_type == "vm-agent":
            if args.ssh_host:
                resource_config["host"] = args.ssh_host
            if args.ssh_user:
                resource_config["user"] = args.ssh_user
            if args.ssh_key:
                resource_config["key_path"] = args.ssh_key

        elif args.agent_type in ("postgres-agent", "redis-agent"):
            if args.db_host:
                resource_config["host"] = args.db_host
            if args.db_port:
                resource_config["port"] = args.db_port
            if args.db_user:
                resource_config["user"] = args.db_user
            if args.db_password:
                resource_config["password"] = args.db_password
            if args.db_name:
                resource_config["database"] = args.db_name

        config = AgentServerConfig(
            agent_type=args.agent_type,
            resource_name=args.resource_name,
            resource_config=resource_config,
            data_dir=Path(args.data_dir),
        )

    # Override with CLI args
    config.server.host = args.host
    config.server.port = args.port
    config.mesh.port = args.mesh_port
    config.mesh.enabled = not args.no_mesh
    config.model.auto_download = not args.no_model

    if args.model_path:
        config.model.path = args.model_path

    return config


def main() -> int:
    """Main entry point."""
    args = parse_args()

    # Set log level
    logging.getLogger().setLevel(args.log_level)

    # Handle download-only mode
    if args.download_model_only:
        return download_model_only()

    # Build configuration
    try:
        config = build_config_from_args(args)
    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        return 1

    logger.info(f"Starting tp-ops agent server")
    logger.info(f"Agent type: {config.agent_type}")
    logger.info(f"Resource: {config.resource_name}")
    logger.info(f"API server: {config.server.host}:{config.server.port}")
    logger.info(f"Mesh: {'enabled' if config.mesh.enabled else 'disabled'} (port {config.mesh.port})")
    logger.info(f"Model: {'auto-download' if config.model.auto_download else 'disabled'}")

    # Create the FastAPI app
    app = create_app(config)

    # Setup signal handlers
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}, shutting down...")
        sys.exit(0)

    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    # Run the server
    try:
        uvicorn.run(
            app,
            host=config.server.host,
            port=config.server.port,
            log_level=args.log_level.lower(),
            access_log=True,
        )
        return 0

    except Exception as e:
        logger.error(f"Server failed: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
