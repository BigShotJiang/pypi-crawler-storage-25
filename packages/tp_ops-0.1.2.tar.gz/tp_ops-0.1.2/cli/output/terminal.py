"""Terminal output formatting for tp-ops CLI."""

import sys
from dataclasses import dataclass
from typing import TextIO


# ANSI color codes
class Colors:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_YELLOW = "\033[43m"
    BG_BLUE = "\033[44m"


class Terminal:
    """Terminal output handler with formatting support."""

    # Unicode bullet point
    BULLET = "\u2022"

    def __init__(
        self,
        verbose: bool = False,
        use_color: bool = True,
        stdout: TextIO = sys.stdout,
        stderr: TextIO = sys.stderr,
    ):
        self.verbose = verbose
        self.use_color = use_color and stdout.isatty()
        self.stdout = stdout
        self.stderr = stderr

    def _colorize(self, text: str, *codes: str) -> str:
        """Apply color codes to text if colors are enabled."""
        if not self.use_color:
            return text
        return "".join(codes) + text + Colors.RESET

    def print(self, message: str = "", end: str = "\n") -> None:
        """Print a message to stdout."""
        print(message, end=end, file=self.stdout, flush=True)

    def debug(self, message: str) -> None:
        """Print debug message (only in verbose mode)."""
        if self.verbose:
            text = self._colorize(f"[DEBUG] {message}", Colors.DIM)
            print(text, file=self.stderr)

    def info(self, message: str) -> None:
        """Print info message."""
        text = self._colorize(message, Colors.CYAN)
        print(text, file=self.stdout)

    def success(self, message: str) -> None:
        """Print success message."""
        prefix = self._colorize("OK", Colors.GREEN, Colors.BOLD)
        print(f"{prefix} {message}", file=self.stdout)

    def warning(self, message: str) -> None:
        """Print warning message."""
        prefix = self._colorize("WARNING", Colors.YELLOW, Colors.BOLD)
        print(f"{prefix} {message}", file=self.stderr)

    def error(self, message: str) -> None:
        """Print error message."""
        prefix = self._colorize("ERROR", Colors.RED, Colors.BOLD)
        print(f"{prefix} {message}", file=self.stderr)

    def header(self, title: str) -> None:
        """Print a section header."""
        line = "=" * 60
        self.print()
        self.print(self._colorize(line, Colors.DIM))
        self.print(self._colorize(f"  {title}", Colors.BOLD))
        self.print(self._colorize(line, Colors.DIM))
        self.print()

    def subheader(self, title: str) -> None:
        """Print a subsection header."""
        line = "-" * 40
        self.print()
        self.print(self._colorize(f"-- {title} --", Colors.BOLD))
        self.print()

    def step(self, number: int, total: int, message: str) -> None:
        """Print an investigation step."""
        prefix = self._colorize(f"[{number}/{total}]", Colors.BLUE, Colors.BOLD)
        self.print(f"{prefix} {message}")

    def step_result(self, message: str, indent: int = 6) -> None:
        """Print a step result (indented)."""
        spaces = " " * indent
        self.print(f"{spaces}{message}")

    def evidence(self, items: list[str]) -> None:
        """Print evidence list."""
        self.print()
        self.print(self._colorize("EVIDENCE:", Colors.BOLD))
        for item in items:
            bullet = self._colorize("-", Colors.DIM)
            self.print(f"  {bullet} {item}")

    def root_cause(self, message: str) -> None:
        """Print root cause finding."""
        self.print()
        label = self._colorize("ROOT CAUSE:", Colors.RED, Colors.BOLD)
        self.print(f"{label} {message}")

    def recommendation(self, number: int, message: str, command: str | None = None) -> None:
        """Print a recommended action."""
        num = self._colorize(f"{number}.", Colors.YELLOW, Colors.BOLD)
        self.print(f"  {num} {message}")
        if command:
            cmd = self._colorize(f"     Command: {command}", Colors.DIM)
            self.print(cmd)

    def action_buttons(self, resource: str, action_num: int) -> None:
        """Print approve/reject hints."""
        approve_cmd = f"tp-ops approve {resource}:action-{action_num}"
        reject_cmd = f"tp-ops reject {resource}:action-{action_num}"

        approve = self._colorize("[Approve]", Colors.GREEN)
        reject = self._colorize("[Reject]", Colors.RED)
        self.print(f"     {approve} {reject}")
        self.print(self._colorize(f"     {approve_cmd}", Colors.DIM))

    def meter(self, gb_processed: float, cost: float) -> None:
        """Print metering information."""
        self.print()
        line = "-" * 60
        self.print(self._colorize(line, Colors.DIM))
        gb_str = self._colorize(f"{gb_processed:.2f} GB", Colors.CYAN)
        cost_str = self._colorize(f"${cost:.2f}", Colors.GREEN)
        self.print(f"Processed: {gb_str} | Cost: {cost_str}")
        self.print(self._colorize(line, Colors.DIM))

    def table(self, headers: list[str], rows: list[list[str]]) -> None:
        """Print a simple table."""
        if not rows:
            self.print("(no data)")
            return

        # Calculate column widths
        widths = [len(h) for h in headers]
        for row in rows:
            for i, cell in enumerate(row):
                if i < len(widths):
                    widths[i] = max(widths[i], len(str(cell)))

        # Print header
        header_row = "  ".join(
            self._colorize(h.ljust(widths[i]), Colors.BOLD)
            for i, h in enumerate(headers)
        )
        self.print(header_row)
        self.print(self._colorize("-" * sum(widths) + "-" * (len(widths) * 2), Colors.DIM))

        # Print rows
        for row in rows:
            row_str = "  ".join(
                str(cell).ljust(widths[i]) if i < len(widths) else str(cell)
                for i, cell in enumerate(row)
            )
            self.print(row_str)

    def spinner_start(self, message: str) -> None:
        """Start a spinner (placeholder - actual implementation would use threading)."""
        self.print(f"{message}...", end=" ")

    def spinner_stop(self, success: bool = True) -> None:
        """Stop the spinner."""
        if success:
            self.print(self._colorize("done", Colors.GREEN))
        else:
            self.print(self._colorize("failed", Colors.RED))

    def confirm(self, message: str, default: bool = False) -> bool:
        """Ask for confirmation."""
        suffix = "[Y/n]" if default else "[y/N]"
        prompt_str = f"{message} {suffix} "

        try:
            response = input(prompt_str).strip().lower()
            if not response:
                return default
            return response in ("y", "yes")
        except (EOFError, KeyboardInterrupt):
            self.print()
            return False

    def prompt(self, message: str) -> str:
        """Prompt for user input."""
        try:
            return input(message)
        except (EOFError, KeyboardInterrupt):
            self.print()
            return ""
