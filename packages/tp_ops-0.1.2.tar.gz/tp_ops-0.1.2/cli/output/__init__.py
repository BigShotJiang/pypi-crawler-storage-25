"""Output formatting for tp-ops CLI."""
