"""TernaryPhysics Ops CLI - Drop AI agents onto infrastructure resources."""

__version__ = "0.1.2"
