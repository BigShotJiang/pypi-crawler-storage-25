"""HTTP client for TernaryPhysics backend API."""

import os
from datetime import datetime
from typing import Optional

from cli.api.models import (
    AccountInfo,
    TokenValidation,
    UsageReport,
    CurrentUsage,
)
from cli.auth.token import get_token


# API configuration
API_BASE_URL = os.environ.get(
    "TP_OPS_API_URL",
    "https://api.ternaryphysics.com/v1"
)
API_TIMEOUT = 30.0


class APIError(Exception):
    """Error from the API."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"API Error ({status_code}): {message}")


class TPOpsAPIClient:
    """Client for TernaryPhysics backend API."""

    def __init__(self, token: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize API client.

        Args:
            token: API token. If not provided, retrieves from stored credentials.
            base_url: API base URL. If not provided, uses default or env var.
        """
        self.token = token or get_token()
        self.base_url = base_url or API_BASE_URL
        self._client = None

    def _get_client(self):
        """Get or create HTTP client."""
        if self._client is None:
            import httpx
            self._client = httpx.Client(
                base_url=self.base_url,
                headers=self._get_headers(),
                timeout=API_TIMEOUT,
            )
        return self._client

    def _get_headers(self) -> dict:
        """Get request headers."""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "tp-ops-cli/0.1.0",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _handle_response(self, response) -> dict:
        """Handle API response, raising APIError on failure."""
        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get("detail", error_data.get("message", "Unknown error"))
            except Exception:
                message = response.text or "Unknown error"
            raise APIError(response.status_code, message)
        return response.json()

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    # Authentication endpoints

    def validate_token(self, token: Optional[str] = None) -> TokenValidation:
        """
        Validate an API token and return account info.

        Args:
            token: Token to validate. Uses stored token if not provided.

        Returns:
            TokenValidation with account info if valid.

        Raises:
            APIError: If token is invalid or API error occurs.
        """
        headers = self._get_headers()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        response = self._get_client().post("/auth/validate", headers=headers)
        data = self._handle_response(response)
        return TokenValidation.from_dict(data)

    # Account endpoints

    def get_account(self) -> AccountInfo:
        """
        Get current account information.

        Returns:
            AccountInfo for the authenticated account.

        Raises:
            APIError: If not authenticated or API error occurs.
        """
        response = self._get_client().get("/accounts/me")
        data = self._handle_response(response)
        return AccountInfo.from_dict(data)

    # Usage endpoints

    def report_usage(
        self,
        resource_name: str,
        agent_type: str,
        command: str,
        bytes_processed: int,
        duration_seconds: float,
        timestamp: Optional[datetime] = None,
    ) -> UsageReport:
        """
        Report usage to the backend.

        Args:
            resource_name: Name of the resource (e.g., "prod-cluster")
            agent_type: Type of agent (e.g., "k8s-agent")
            command: Command executed (e.g., "run", "scan", "ask")
            bytes_processed: Number of bytes processed
            duration_seconds: Duration of the operation
            timestamp: When the operation occurred (defaults to now)

        Returns:
            UsageReport with current period totals.

        Raises:
            APIError: If not authenticated or API error occurs.
        """
        if timestamp is None:
            timestamp = datetime.utcnow()

        payload = {
            "resource_name": resource_name,
            "agent_type": agent_type,
            "command": command,
            "bytes_processed": bytes_processed,
            "duration_seconds": duration_seconds,
            "timestamp": timestamp.isoformat() + "Z",
        }

        response = self._get_client().post("/usage/report", json=payload)
        data = self._handle_response(response)
        return UsageReport.from_dict(data)

    def get_current_usage(self) -> CurrentUsage:
        """
        Get usage for the current billing period.

        Returns:
            CurrentUsage with breakdown by resource and agent type.

        Raises:
            APIError: If not authenticated or API error occurs.
        """
        response = self._get_client().get("/usage/current")
        data = self._handle_response(response)
        return CurrentUsage.from_dict(data)

    def get_usage_history(self, days: int = 30) -> list[dict]:
        """
        Get historical usage data.

        Args:
            days: Number of days of history to retrieve (1-365)

        Returns:
            List of daily usage records.

        Raises:
            APIError: If not authenticated or API error occurs.
        """
        response = self._get_client().get(
            "/usage/history",
            params={"days": days},
        )
        data = self._handle_response(response)
        return data.get("daily", [])
