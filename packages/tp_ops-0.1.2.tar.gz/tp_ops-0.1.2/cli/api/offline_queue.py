"""Offline usage queue for when backend is unreachable.

Queues usage events locally and syncs them when connectivity is restored.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from cli.auth.credentials import get_data_dir


def _get_queue_file() -> Path:
    """Get path to offline usage queue file."""
    return get_data_dir() / "usage_queue.json"


def _load_queue() -> list[dict]:
    """Load queued usage events."""
    queue_file = _get_queue_file()

    if not queue_file.exists():
        return []

    try:
        return json.loads(queue_file.read_text())
    except (json.JSONDecodeError, IOError):
        return []


def _save_queue(queue: list[dict]) -> None:
    """Save queued usage events."""
    queue_file = _get_queue_file()
    queue_file.write_text(json.dumps(queue, indent=2))


def queue_usage(
    resource_name: str,
    agent_type: str,
    command: str,
    bytes_processed: int,
    duration_seconds: float,
    timestamp: Optional[datetime] = None,
) -> None:
    """
    Queue a usage event for later sync.

    Called when the backend API is unreachable.
    """
    if timestamp is None:
        timestamp = datetime.utcnow()

    event = {
        "resource_name": resource_name,
        "agent_type": agent_type,
        "command": command,
        "bytes_processed": bytes_processed,
        "duration_seconds": duration_seconds,
        "timestamp": timestamp.isoformat() + "Z",
        "queued_at": datetime.utcnow().isoformat() + "Z",
    }

    queue = _load_queue()
    queue.append(event)

    # Keep only last 1000 events to prevent unbounded growth
    if len(queue) > 1000:
        queue = queue[-1000:]

    _save_queue(queue)


def get_pending_count() -> int:
    """Get number of pending usage events in queue."""
    return len(_load_queue())


def sync_queued_usage(client) -> tuple[int, int]:
    """
    Sync queued usage events to the backend.

    Args:
        client: TPOpsAPIClient instance

    Returns:
        Tuple of (synced_count, failed_count)
    """
    from cli.api.client import APIError

    queue = _load_queue()
    if not queue:
        return (0, 0)

    synced = 0
    remaining = []

    for event in queue:
        try:
            client.report_usage(
                resource_name=event["resource_name"],
                agent_type=event["agent_type"],
                command=event["command"],
                bytes_processed=event["bytes_processed"],
                duration_seconds=event["duration_seconds"],
            )
            synced += 1
        except APIError:
            # Keep event for retry
            remaining.append(event)
        except Exception:
            # Keep event for retry on unexpected errors
            remaining.append(event)

    _save_queue(remaining)
    return (synced, len(remaining))


def clear_queue() -> int:
    """
    Clear all queued usage events.

    Returns:
        Number of events cleared.
    """
    queue = _load_queue()
    count = len(queue)
    _save_queue([])
    return count
