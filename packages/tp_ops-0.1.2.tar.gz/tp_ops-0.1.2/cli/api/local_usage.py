"""Local usage tracking for free tier enforcement.

Tracks total bytes processed locally, even without login.
Used to prompt users to sign up when they exceed the free tier.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from cli.auth.credentials import get_data_dir


FREE_TIER_BYTES = 1 * 1024 * 1024 * 1024  # 1 GB
PRICE_PER_GB = 0.50


def _get_local_usage_file() -> Path:
    """Get path to local usage tracking file."""
    return get_data_dir() / "local_usage.json"


def _load_local_usage() -> dict:
    """Load local usage data."""
    usage_file = _get_local_usage_file()

    if not usage_file.exists():
        return {
            "total_bytes": 0,
            "first_used_at": None,
            "last_used_at": None,
            "prompted_for_signup": False,
        }

    try:
        return json.loads(usage_file.read_text())
    except (json.JSONDecodeError, IOError):
        return {
            "total_bytes": 0,
            "first_used_at": None,
            "last_used_at": None,
            "prompted_for_signup": False,
        }


def _save_local_usage(usage: dict) -> None:
    """Save local usage data."""
    usage_file = _get_local_usage_file()
    usage_file.parent.mkdir(parents=True, exist_ok=True)
    usage_file.write_text(json.dumps(usage, indent=2))


def track_local_usage(bytes_processed: int) -> None:
    """
    Track usage locally (regardless of login status).

    Args:
        bytes_processed: Number of bytes processed in this session
    """
    if bytes_processed <= 0:
        return

    usage = _load_local_usage()
    now = datetime.utcnow().isoformat() + "Z"

    if usage["first_used_at"] is None:
        usage["first_used_at"] = now

    usage["total_bytes"] += bytes_processed
    usage["last_used_at"] = now

    _save_local_usage(usage)


def get_local_usage() -> dict:
    """
    Get local usage statistics.

    Returns:
        Dict with total_bytes, total_gb, free_remaining_gb, is_over_free_tier
    """
    usage = _load_local_usage()
    total_bytes = usage.get("total_bytes", 0)
    total_gb = total_bytes / (1024 * 1024 * 1024)
    free_remaining_gb = max(0, 1.0 - total_gb)
    is_over_free_tier = total_bytes > FREE_TIER_BYTES

    return {
        "total_bytes": total_bytes,
        "total_gb": total_gb,
        "free_remaining_gb": free_remaining_gb,
        "is_over_free_tier": is_over_free_tier,
        "billable_gb": max(0, total_gb - 1.0),
        "estimated_cost": max(0, total_gb - 1.0) * PRICE_PER_GB,
    }


def should_prompt_signup() -> bool:
    """
    Check if we should prompt the user to sign up.

    Returns True if:
    - User is not logged in
    - User has exceeded free tier
    - We haven't prompted them recently
    """
    from cli.auth.token import get_token

    # Don't prompt if already logged in
    if get_token():
        return False

    usage = _load_local_usage()

    # Don't prompt if under free tier
    if usage.get("total_bytes", 0) <= FREE_TIER_BYTES:
        return False

    # Don't prompt if we already prompted
    if usage.get("prompted_for_signup", False):
        return False

    return True


def mark_signup_prompted() -> None:
    """Mark that we've prompted the user to sign up."""
    usage = _load_local_usage()
    usage["prompted_for_signup"] = True
    _save_local_usage(usage)


def get_signup_prompt_message() -> str:
    """Get the signup prompt message."""
    stats = get_local_usage()
    return f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FREE TIER EXCEEDED

  You've processed {stats['total_gb']:.2f} GB (free tier: 1 GB).
  Estimated charges: ${stats['estimated_cost']:.2f}

  Sign up to continue using TernaryPhysics:
    https://ternaryphysics.com/signup

  Then add your API key:
    tp-ops login --token <your-api-key>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
