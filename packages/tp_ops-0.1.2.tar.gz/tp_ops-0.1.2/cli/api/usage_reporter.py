"""Usage reporting utility.

Reports usage to the backend API in the background.
Falls back to offline queue if API is unreachable.
Also tracks usage locally for free tier enforcement.
"""

import threading
import logging

from cli.api.client import TPOpsAPIClient, APIError
from cli.api.offline_queue import queue_usage, sync_queued_usage, get_pending_count
from cli.api.local_usage import (
    track_local_usage,
    should_prompt_signup,
    get_signup_prompt_message,
    mark_signup_prompted,
)
from cli.auth.token import get_token

logger = logging.getLogger(__name__)


def report_usage_async(
    resource_name: str,
    agent_type: str,
    command: str,
    bytes_processed: int,
    duration_seconds: float,
) -> None:
    """Report usage to the backend API in a background thread.

    This is fire-and-forget. It will:
    1. Track usage locally (always, for free tier enforcement)
    2. Try to report to the API (if logged in)
    3. If API is unreachable, queue for later
    4. Never raise exceptions to the caller

    Args:
        resource_name: Name of the resource (e.g., "prod-cluster")
        agent_type: Type of agent (e.g., "k8s-agent")
        command: Command that was run (e.g., "ask", "run", "scan")
        bytes_processed: Total bytes processed during the session
        duration_seconds: Duration of the session in seconds
    """
    # Don't report zero usage
    if bytes_processed <= 0:
        return

    # Always track locally for free tier enforcement
    track_local_usage(bytes_processed)

    # Only report to API if logged in
    if not get_token():
        return

    thread = threading.Thread(
        target=_do_report,
        args=(resource_name, agent_type, command, bytes_processed, duration_seconds),
        daemon=True,
    )
    thread.start()


def _do_report(
    resource_name: str,
    agent_type: str,
    command: str,
    bytes_processed: int,
    duration_seconds: float,
) -> None:
    """Actually perform the usage report.

    Called in a background thread.
    """
    try:
        client = TPOpsAPIClient()
        client.report_usage(
            resource_name=resource_name,
            agent_type=agent_type,
            command=command,
            bytes_processed=bytes_processed,
            duration_seconds=duration_seconds,
        )
        logger.debug(
            f"Usage reported: {bytes_processed} bytes for {command} on {resource_name}"
        )

        # Try to flush any queued events while we have connectivity
        _flush_offline_queue(client)

    except APIError as e:
        # API error - queue for later
        logger.debug(f"API error, queuing usage: {e}")
        queue_usage(resource_name, agent_type, command, bytes_processed, duration_seconds)

    except Exception as e:
        # Network error or other issue - queue for later
        logger.debug(f"Failed to report usage, queuing: {e}")
        queue_usage(resource_name, agent_type, command, bytes_processed, duration_seconds)


def _flush_offline_queue(client: TPOpsAPIClient) -> None:
    """Try to flush any queued offline events."""
    try:
        if get_pending_count() > 0:
            synced, remaining = sync_queued_usage(client)
            if synced > 0:
                logger.debug(f"Flushed {synced} queued usage events")
    except Exception as e:
        logger.debug(f"Failed to flush offline queue: {e}")


def sync_offline_usage() -> tuple[int, int]:
    """Manually sync any offline usage events.

    Returns:
        Tuple of (synced_count, failed_count)
    """
    token = get_token()
    if not token:
        return (0, 0)

    try:
        client = TPOpsAPIClient(token=token)
        return sync_queued_usage(client)
    except Exception:
        return (0, 0)


def check_and_show_signup_prompt(terminal) -> bool:
    """Check if user has exceeded free tier and show signup prompt.

    Args:
        terminal: Terminal instance for output

    Returns:
        True if prompt was shown, False otherwise
    """
    if should_prompt_signup():
        terminal.warning(get_signup_prompt_message())
        mark_signup_prompted()
        return True
    return False
