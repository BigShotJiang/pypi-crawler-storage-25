"""Data models for tp-ops API responses."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class AccountInfo:
    """Account information from the API."""
    id: str
    email: str
    name: str
    plan: str  # "free", "pro", "enterprise"
    created_at: Optional[datetime] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AccountInfo":
        created = data.get("created_at")
        if created and isinstance(created, str):
            created = datetime.fromisoformat(created.replace("Z", "+00:00"))
        return cls(
            id=data["id"],
            email=data["email"],
            name=data.get("name", ""),
            plan=data.get("plan", "free"),
            created_at=created,
        )


@dataclass
class TokenValidation:
    """Token validation response."""
    valid: bool
    account: Optional[AccountInfo] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "TokenValidation":
        account = None
        if data.get("account"):
            account = AccountInfo.from_dict(data["account"])
        return cls(
            valid=data.get("valid", False),
            account=account,
            error=data.get("error"),
        )


@dataclass
class UsageReport:
    """Response from usage report submission."""
    event_id: str
    current_period_gb: float
    current_period_cost: float

    @classmethod
    def from_dict(cls, data: dict) -> "UsageReport":
        return cls(
            event_id=data["event_id"],
            current_period_gb=data.get("current_period_gb", 0.0),
            current_period_cost=data.get("current_period_cost", 0.0),
        )


@dataclass
class UsageBreakdown:
    """Usage breakdown by resource or agent type."""
    name: str
    gb_processed: float
    cost: float
    count: int  # Number of operations

    @classmethod
    def from_dict(cls, data: dict) -> "UsageBreakdown":
        return cls(
            name=data["name"],
            gb_processed=data.get("gb_processed", 0.0),
            cost=data.get("cost", 0.0),
            count=data.get("count", 0),
        )


@dataclass
class CurrentUsage:
    """Current billing period usage."""
    period_start: datetime
    period_end: datetime
    total_bytes: int
    total_gb: float
    cost: float
    by_resource: list[UsageBreakdown]
    by_agent_type: list[UsageBreakdown]

    @classmethod
    def from_dict(cls, data: dict) -> "CurrentUsage":
        period_start = datetime.fromisoformat(
            data["period_start"].replace("Z", "+00:00")
        )
        period_end = datetime.fromisoformat(
            data["period_end"].replace("Z", "+00:00")
        )

        by_resource = [
            UsageBreakdown.from_dict(r)
            for r in data.get("breakdown", {}).get("by_resource", [])
        ]
        by_agent_type = [
            UsageBreakdown.from_dict(r)
            for r in data.get("breakdown", {}).get("by_agent_type", [])
        ]

        return cls(
            period_start=period_start,
            period_end=period_end,
            total_bytes=data.get("total_bytes", 0),
            total_gb=data.get("total_gb", 0.0),
            cost=data.get("cost", 0.0),
            by_resource=by_resource,
            by_agent_type=by_agent_type,
        )
