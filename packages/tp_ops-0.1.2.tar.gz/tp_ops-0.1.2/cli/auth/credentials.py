"""Credential and configuration management for tp-ops CLI."""

import json
import os
from pathlib import Path
from typing import Any


def get_config_dir() -> Path:
    """Get the tp-ops configuration directory."""
    # Use XDG_CONFIG_HOME if set, otherwise ~/.config
    config_home = os.environ.get("XDG_CONFIG_HOME")
    if config_home:
        base = Path(config_home)
    else:
        base = Path.home() / ".config"

    config_dir = base / "tp-ops"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_data_dir() -> Path:
    """Get the tp-ops data directory."""
    # Use XDG_DATA_HOME if set, otherwise ~/.local/share
    data_home = os.environ.get("XDG_DATA_HOME")
    if data_home:
        base = Path(data_home)
    else:
        base = Path.home() / ".local" / "share"

    data_dir = base / "tp-ops"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def load_agents() -> dict[str, Any]:
    """Load the agents configuration file."""
    agents_file = get_config_dir() / "agents.json"

    if not agents_file.exists():
        return {}

    try:
        with open(agents_file, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def save_agents(agents: dict[str, Any]) -> None:
    """Save the agents configuration file."""
    agents_file = get_config_dir() / "agents.json"

    with open(agents_file, "w") as f:
        json.dump(agents, f, indent=2)


def get_agent(name: str) -> dict[str, Any] | None:
    """Get a specific agent by name."""
    agents = load_agents()
    return agents.get(name)


def remove_agent(name: str) -> bool:
    """Remove an agent by name."""
    agents = load_agents()
    if name in agents:
        del agents[name]
        save_agents(agents)
        return True
    return False


def load_history(resource: str) -> list[dict[str, Any]]:
    """Load investigation history for a resource."""
    history_dir = get_data_dir() / "history"
    history_dir.mkdir(exist_ok=True)

    history_file = history_dir / f"{resource}.json"

    if not history_file.exists():
        return []

    try:
        with open(history_file, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def save_investigation(resource: str, investigation: dict[str, Any]) -> None:
    """Save an investigation to history."""
    history_dir = get_data_dir() / "history"
    history_dir.mkdir(exist_ok=True)

    history_file = history_dir / f"{resource}.json"

    history = load_history(resource)
    history.append(investigation)

    # Keep only last 100 investigations
    if len(history) > 100:
        history = history[-100:]

    with open(history_file, "w") as f:
        json.dump(history, f, indent=2)


def load_pending_actions() -> dict[str, Any]:
    """Load pending actions awaiting approval."""
    actions_file = get_data_dir() / "pending_actions.json"

    if not actions_file.exists():
        return {}

    try:
        with open(actions_file, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def save_pending_actions(actions: dict[str, Any]) -> None:
    """Save pending actions."""
    actions_file = get_data_dir() / "pending_actions.json"

    with open(actions_file, "w") as f:
        json.dump(actions, f, indent=2)


def add_pending_action(
    resource: str,
    action_num: int,
    command: str,
    description: str,
    investigation_id: str
) -> str:
    """Add a pending action and return its ID."""
    actions = load_pending_actions()

    action_id = f"{resource}:action-{action_num}"
    actions[action_id] = {
        "resource": resource,
        "action_num": action_num,
        "command": command,
        "description": description,
        "investigation_id": investigation_id,
        "status": "pending",
    }

    save_pending_actions(actions)
    return action_id


def get_pending_action(action_id: str) -> dict[str, Any] | None:
    """Get a pending action by ID."""
    actions = load_pending_actions()
    return actions.get(action_id)


def resolve_pending_action(action_id: str, approved: bool, result: str | None = None) -> bool:
    """Mark a pending action as approved or rejected."""
    actions = load_pending_actions()

    if action_id not in actions:
        return False

    actions[action_id]["status"] = "approved" if approved else "rejected"
    if result:
        actions[action_id]["result"] = result

    save_pending_actions(actions)
    return True
