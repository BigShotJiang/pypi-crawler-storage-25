"""Secure API token storage for tp-ops CLI.

Stores tokens in system keyring when available, falls back to file with
restricted permissions.
"""

import os
import re
from pathlib import Path
from typing import Optional

from cli.auth.credentials import get_config_dir


# Token format: tp_live_* or tp_test_*
TOKEN_PATTERN = re.compile(r"^sk_(live|test)_[a-zA-Z0-9]{32,}$")

# Keyring service name
KEYRING_SERVICE = "tp-ops"
KEYRING_USERNAME = "api_token"


def validate_token_format(token: str) -> bool:
    """Validate that token matches expected format."""
    return bool(TOKEN_PATTERN.match(token))


def is_test_token(token: str) -> bool:
    """Check if token is a test token."""
    return token.startswith("tp_test_")


def get_token_prefix(token: str) -> str:
    """Get displayable prefix of token (e.g., tp_live_abc...)."""
    if len(token) > 15:
        return f"{token[:15]}..."
    return token


def _get_config_file() -> Path:
    """Get path to config file for token storage."""
    return get_config_dir() / "config.toml"


def _try_keyring_store(token: str) -> bool:
    """Try to store token in system keyring. Returns True if successful."""
    try:
        import keyring
        keyring.set_password(KEYRING_SERVICE, KEYRING_USERNAME, token)
        return True
    except ImportError:
        return False
    except Exception:
        # Keyring may fail on headless systems
        return False


def _try_keyring_get() -> Optional[str]:
    """Try to get token from system keyring. Returns None if not available."""
    try:
        import keyring
        return keyring.get_password(KEYRING_SERVICE, KEYRING_USERNAME)
    except ImportError:
        return None
    except Exception:
        return None


def _try_keyring_delete() -> bool:
    """Try to delete token from system keyring. Returns True if successful."""
    try:
        import keyring
        keyring.delete_password(KEYRING_SERVICE, KEYRING_USERNAME)
        return True
    except ImportError:
        return False
    except Exception:
        return False


def _store_in_file(token: str) -> None:
    """Store token in config file with restricted permissions."""
    config_file = _get_config_file()

    # Write TOML format
    content = f"""# tp-ops configuration
# This file contains sensitive credentials - do not share

[auth]
token = "{token}"
"""

    config_file.write_text(content)

    # Set restrictive permissions (owner read/write only)
    os.chmod(config_file, 0o600)


def _get_from_file() -> Optional[str]:
    """Get token from config file."""
    config_file = _get_config_file()

    if not config_file.exists():
        return None

    try:
        # Python 3.11+ has tomllib, otherwise fall back to simple parsing
        try:
            import tomllib
            config = tomllib.loads(config_file.read_text())
            return config.get("auth", {}).get("token")
        except ImportError:
            # Simple fallback parser for token = "value"
            content = config_file.read_text()
            for line in content.split("\n"):
                line = line.strip()
                if line.startswith("token"):
                    # Extract value between quotes
                    match = re.search(r'token\s*=\s*"([^"]+)"', line)
                    if match:
                        return match.group(1)
            return None
    except Exception:
        return None


def _delete_from_file() -> None:
    """Delete config file containing token."""
    config_file = _get_config_file()
    if config_file.exists():
        config_file.unlink()


def store_token(token: str) -> None:
    """
    Store API token securely.

    Priority:
    1. System keyring (if available)
    2. Config file with restricted permissions
    """
    # Always try keyring first
    if _try_keyring_store(token):
        # Also store in file as backup (some systems lose keyring on reboot)
        _store_in_file(token)
        return

    # Fall back to file storage
    _store_in_file(token)


def get_token() -> Optional[str]:
    """
    Retrieve stored API token.

    Checks keyring first, then config file.
    """
    # Try keyring first
    token = _try_keyring_get()
    if token:
        return token

    # Fall back to file
    return _get_from_file()


def clear_token() -> None:
    """Remove stored API token from all storage locations."""
    _try_keyring_delete()
    _delete_from_file()


def is_authenticated() -> bool:
    """Check if user has a stored token."""
    return get_token() is not None
