"""Authentication and configuration for tp-ops CLI."""
