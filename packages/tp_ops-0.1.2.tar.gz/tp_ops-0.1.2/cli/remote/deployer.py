"""Agent deployment orchestration."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Optional

from cli.output.terminal import Terminal


@dataclass
class DeploymentResult:
    """Result of an agent deployment."""
    success: bool
    endpoint: Optional[str] = None
    error: Optional[str] = None
    details: dict[str, Any] = None

    def __post_init__(self):
        if self.details is None:
            self.details = {}


class BaseDeployer(ABC):
    """Base class for agent deployers."""

    def __init__(self, terminal: Terminal):
        self.terminal = terminal

    @abstractmethod
    def deploy(
        self,
        resource_name: str,
        agent_type: str,
        config: dict[str, Any],
    ) -> DeploymentResult:
        """Deploy an agent to a resource.

        Args:
            resource_name: Name of the resource
            agent_type: Type of agent to deploy
            config: Agent configuration

        Returns:
            DeploymentResult with endpoint or error
        """
        pass

    @abstractmethod
    def undeploy(
        self,
        resource_name: str,
        agent_type: str,
    ) -> DeploymentResult:
        """Remove a deployed agent.

        Args:
            resource_name: Name of the resource
            agent_type: Type of agent

        Returns:
            DeploymentResult indicating success or failure
        """
        pass

    @abstractmethod
    def status(
        self,
        resource_name: str,
        agent_type: str,
    ) -> dict[str, Any]:
        """Get status of a deployed agent.

        Args:
            resource_name: Name of the resource
            agent_type: Type of agent

        Returns:
            Status dictionary
        """
        pass


class AgentDeployer:
    """Orchestrates agent deployment to various resource types."""

    def __init__(self, terminal: Terminal):
        self.terminal = terminal
        self._deployers: dict[str, BaseDeployer] = {}

    def _get_deployer(self, agent_type: str) -> BaseDeployer:
        """Get the appropriate deployer for an agent type."""
        if agent_type not in self._deployers:
            if agent_type == "k8s-agent":
                from cli.remote.k8s_deployer import K8sDeployer
                self._deployers[agent_type] = K8sDeployer(self.terminal)
            elif agent_type == "vm-agent":
                from cli.remote.vm_deployer import VMDeployer
                self._deployers[agent_type] = VMDeployer(self.terminal)
            elif agent_type in ("postgres-agent", "redis-agent"):
                # Database agents deploy as sidecars or on the DB host
                from cli.remote.vm_deployer import VMDeployer
                self._deployers[agent_type] = VMDeployer(self.terminal)
            else:
                raise ValueError(f"No deployer available for agent type: {agent_type}")

        return self._deployers[agent_type]

    def deploy(
        self,
        resource_name: str,
        agent_type: str,
        config: dict[str, Any],
    ) -> DeploymentResult:
        """Deploy an agent to a resource.

        Args:
            resource_name: Name of the resource
            agent_type: Type of agent to deploy
            config: Agent configuration

        Returns:
            DeploymentResult with endpoint or error
        """
        self.terminal.info(f"Deploying {agent_type} to {resource_name}...")

        try:
            deployer = self._get_deployer(agent_type)
            result = deployer.deploy(resource_name, agent_type, config)

            if result.success:
                self.terminal.success(f"Agent deployed at {result.endpoint}")
            else:
                self.terminal.error(f"Deployment failed: {result.error}")

            return result

        except Exception as e:
            self.terminal.error(f"Deployment error: {e}")
            return DeploymentResult(success=False, error=str(e))

    def undeploy(
        self,
        resource_name: str,
        agent_type: str,
    ) -> DeploymentResult:
        """Remove a deployed agent.

        Args:
            resource_name: Name of the resource
            agent_type: Type of agent

        Returns:
            DeploymentResult indicating success or failure
        """
        self.terminal.info(f"Removing {agent_type} from {resource_name}...")

        try:
            deployer = self._get_deployer(agent_type)
            result = deployer.undeploy(resource_name, agent_type)

            if result.success:
                self.terminal.success("Agent removed")
            else:
                self.terminal.error(f"Removal failed: {result.error}")

            return result

        except Exception as e:
            self.terminal.error(f"Undeploy error: {e}")
            return DeploymentResult(success=False, error=str(e))

    def status(
        self,
        resource_name: str,
        agent_type: str,
    ) -> dict[str, Any]:
        """Get status of a deployed agent.

        Args:
            resource_name: Name of the resource
            agent_type: Type of agent

        Returns:
            Status dictionary
        """
        try:
            deployer = self._get_deployer(agent_type)
            return deployer.status(resource_name, agent_type)
        except Exception as e:
            return {"error": str(e), "running": False}
