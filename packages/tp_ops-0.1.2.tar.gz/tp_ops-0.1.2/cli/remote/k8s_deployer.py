"""Kubernetes deployer for tp-ops agents."""

import json
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional

from cli.output.terminal import Terminal
from cli.remote.deployer import BaseDeployer, DeploymentResult


# Default agent image
DEFAULT_AGENT_IMAGE = "ghcr.io/ternaryphysics/tp-ops-agent:latest"

# Namespace for tp-ops agents
DEFAULT_NAMESPACE = "tp-ops"


class K8sDeployer(BaseDeployer):
    """Deploy tp-ops agents to Kubernetes clusters."""

    def __init__(self, terminal: Terminal):
        super().__init__(terminal)
        self._kubectl_base: list[str] = ["kubectl"]

    def _kubectl(self, args: list[str], kubeconfig: Optional[str] = None, context: Optional[str] = None) -> subprocess.CompletedProcess:
        """Run a kubectl command."""
        cmd = self._kubectl_base.copy()

        if kubeconfig:
            cmd.extend(["--kubeconfig", kubeconfig])
        if context:
            cmd.extend(["--context", context])

        cmd.extend(args)

        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
        )

    def _generate_manifests(
        self,
        resource_name: str,
        agent_type: str,
        config: dict[str, Any],
    ) -> str:
        """Generate Kubernetes manifests for the agent."""
        namespace = config.get("namespace", DEFAULT_NAMESPACE)
        image = config.get("image", DEFAULT_AGENT_IMAGE)
        mesh_port = config.get("mesh_port", 7100)
        api_port = config.get("api_port", 8080)

        # Sanitize resource name for k8s
        safe_name = resource_name.lower().replace("_", "-")[:63]

        # Generate service account and RBAC
        rbac_manifest = f"""---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: tp-ops-agent-{safe_name}
  namespace: {namespace}
  labels:
    app: tp-ops-agent
    resource: {safe_name}
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: tp-ops-agent-{safe_name}
  labels:
    app: tp-ops-agent
    resource: {safe_name}
rules:
  - apiGroups: [""]
    resources: ["pods", "pods/log", "services", "endpoints", "configmaps", "secrets", "events", "namespaces", "nodes"]
    verbs: ["get", "list", "watch"]
  - apiGroups: [""]
    resources: ["pods/exec"]
    verbs: ["create"]
  - apiGroups: ["apps"]
    resources: ["deployments", "replicasets", "statefulsets", "daemonsets"]
    verbs: ["get", "list", "watch"]
  - apiGroups: ["batch"]
    resources: ["jobs", "cronjobs"]
    verbs: ["get", "list", "watch"]
  - apiGroups: ["networking.k8s.io"]
    resources: ["ingresses", "networkpolicies"]
    verbs: ["get", "list", "watch"]
  - apiGroups: ["autoscaling"]
    resources: ["horizontalpodautoscalers"]
    verbs: ["get", "list", "watch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: tp-ops-agent-{safe_name}
  labels:
    app: tp-ops-agent
    resource: {safe_name}
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: tp-ops-agent-{safe_name}
subjects:
  - kind: ServiceAccount
    name: tp-ops-agent-{safe_name}
    namespace: {namespace}
"""

        # Generate deployment
        deployment_manifest = f"""---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tp-ops-agent-{safe_name}
  namespace: {namespace}
  labels:
    app: tp-ops-agent
    resource: {safe_name}
    agent-type: {agent_type}
spec:
  replicas: 1
  selector:
    matchLabels:
      app: tp-ops-agent
      resource: {safe_name}
  template:
    metadata:
      labels:
        app: tp-ops-agent
        resource: {safe_name}
        agent-type: {agent_type}
    spec:
      serviceAccountName: tp-ops-agent-{safe_name}
      containers:
        - name: agent
          image: {image}
          imagePullPolicy: Always
          args:
            - "--agent-type"
            - "{agent_type}"
            - "--resource-name"
            - "{resource_name}"
            - "--port"
            - "{api_port}"
            - "--mesh-port"
            - "{mesh_port}"
          ports:
            - name: api
              containerPort: {api_port}
              protocol: TCP
            - name: mesh
              containerPort: {mesh_port}
              protocol: TCP
          env:
            - name: TP_OPS_AGENT_TYPE
              value: "{agent_type}"
            - name: TP_OPS_RESOURCE_NAME
              value: "{resource_name}"
            - name: TP_OPS_DATA_DIR
              value: "/var/lib/tp-ops"
          volumeMounts:
            - name: data
              mountPath: /var/lib/tp-ops
            - name: model-cache
              mountPath: /models
          resources:
            requests:
              memory: "2Gi"
              cpu: "500m"
            limits:
              memory: "8Gi"
              cpu: "4"
          livenessProbe:
            httpGet:
              path: /api/v1/health
              port: api
            initialDelaySeconds: 30
            periodSeconds: 10
          readinessProbe:
            httpGet:
              path: /api/v1/health
              port: api
            initialDelaySeconds: 10
            periodSeconds: 5
      volumes:
        - name: data
          emptyDir: {{}}
        - name: model-cache
          persistentVolumeClaim:
            claimName: tp-ops-models
      initContainers:
        - name: model-downloader
          image: {image}
          args: ["--download-model-only"]
          volumeMounts:
            - name: model-cache
              mountPath: /models
          env:
            - name: TP_OPS_DATA_DIR
              value: "/models"
"""

        # Generate service
        service_manifest = f"""---
apiVersion: v1
kind: Service
metadata:
  name: tp-ops-agent-{safe_name}
  namespace: {namespace}
  labels:
    app: tp-ops-agent
    resource: {safe_name}
spec:
  type: ClusterIP
  ports:
    - name: api
      port: {api_port}
      targetPort: api
      protocol: TCP
    - name: mesh
      port: {mesh_port}
      targetPort: mesh
      protocol: TCP
  selector:
    app: tp-ops-agent
    resource: {safe_name}
"""

        # Generate PVC for model cache (if not exists)
        pvc_manifest = f"""---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: tp-ops-models
  namespace: {namespace}
  labels:
    app: tp-ops-agent
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 10Gi
"""

        # Generate namespace (if needed)
        namespace_manifest = f"""---
apiVersion: v1
kind: Namespace
metadata:
  name: {namespace}
  labels:
    app: tp-ops-agent
"""

        return namespace_manifest + pvc_manifest + rbac_manifest + deployment_manifest + service_manifest

    def deploy(
        self,
        resource_name: str,
        agent_type: str,
        config: dict[str, Any],
    ) -> DeploymentResult:
        """Deploy an agent to a Kubernetes cluster."""
        kubeconfig = config.get("kubeconfig")
        context = config.get("context")
        namespace = config.get("namespace", DEFAULT_NAMESPACE)
        api_port = config.get("api_port", 8080)

        # Sanitize resource name
        safe_name = resource_name.lower().replace("_", "-")[:63]

        # Generate manifests
        self.terminal.info("Generating Kubernetes manifests...")
        manifests = self._generate_manifests(resource_name, agent_type, config)

        # Apply manifests
        self.terminal.info("Applying manifests to cluster...")

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(manifests)
            manifest_path = f.name

        try:
            result = self._kubectl(
                ["apply", "-f", manifest_path],
                kubeconfig=kubeconfig,
                context=context,
            )

            if result.returncode != 0:
                return DeploymentResult(
                    success=False,
                    error=f"kubectl apply failed: {result.stderr}",
                )

            # Wait for deployment to be ready
            self.terminal.info("Waiting for agent to be ready...")
            result = self._kubectl(
                [
                    "rollout", "status",
                    f"deployment/tp-ops-agent-{safe_name}",
                    "-n", namespace,
                    "--timeout=180s",
                ],
                kubeconfig=kubeconfig,
                context=context,
            )

            if result.returncode != 0:
                return DeploymentResult(
                    success=False,
                    error=f"Deployment not ready: {result.stderr}",
                )

            # Get service endpoint
            # For ClusterIP, construct the internal DNS name
            endpoint = f"http://tp-ops-agent-{safe_name}.{namespace}.svc.cluster.local:{api_port}"

            # If user wants external access, they can port-forward
            # or change service type to LoadBalancer

            return DeploymentResult(
                success=True,
                endpoint=endpoint,
                details={
                    "namespace": namespace,
                    "deployment": f"tp-ops-agent-{safe_name}",
                    "service": f"tp-ops-agent-{safe_name}",
                    "internal_endpoint": endpoint,
                    "port_forward_cmd": f"kubectl port-forward -n {namespace} svc/tp-ops-agent-{safe_name} {api_port}:{api_port}",
                },
            )

        finally:
            os.unlink(manifest_path)

    def undeploy(
        self,
        resource_name: str,
        agent_type: str,
        config: Optional[dict[str, Any]] = None,
    ) -> DeploymentResult:
        """Remove a deployed agent from Kubernetes."""
        config = config or {}
        kubeconfig = config.get("kubeconfig")
        context = config.get("context")
        namespace = config.get("namespace", DEFAULT_NAMESPACE)

        safe_name = resource_name.lower().replace("_", "-")[:63]

        # Delete deployment
        self.terminal.info(f"Removing deployment tp-ops-agent-{safe_name}...")
        result = self._kubectl(
            ["delete", "deployment", f"tp-ops-agent-{safe_name}", "-n", namespace, "--ignore-not-found"],
            kubeconfig=kubeconfig,
            context=context,
        )

        # Delete service
        self.terminal.info(f"Removing service tp-ops-agent-{safe_name}...")
        self._kubectl(
            ["delete", "service", f"tp-ops-agent-{safe_name}", "-n", namespace, "--ignore-not-found"],
            kubeconfig=kubeconfig,
            context=context,
        )

        # Delete RBAC (optional, keep for other agents)
        # self._kubectl(["delete", "clusterrole", f"tp-ops-agent-{safe_name}", "--ignore-not-found"])
        # self._kubectl(["delete", "clusterrolebinding", f"tp-ops-agent-{safe_name}", "--ignore-not-found"])
        # self._kubectl(["delete", "serviceaccount", f"tp-ops-agent-{safe_name}", "-n", namespace])

        return DeploymentResult(success=True)

    def status(
        self,
        resource_name: str,
        agent_type: str,
        config: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Get status of a deployed agent."""
        config = config or {}
        kubeconfig = config.get("kubeconfig")
        context = config.get("context")
        namespace = config.get("namespace", DEFAULT_NAMESPACE)

        safe_name = resource_name.lower().replace("_", "-")[:63]

        # Get deployment status
        result = self._kubectl(
            ["get", "deployment", f"tp-ops-agent-{safe_name}", "-n", namespace, "-o", "json"],
            kubeconfig=kubeconfig,
            context=context,
        )

        if result.returncode != 0:
            return {"running": False, "error": "Deployment not found"}

        try:
            deployment = json.loads(result.stdout)
            status = deployment.get("status", {})

            ready_replicas = status.get("readyReplicas", 0)
            replicas = status.get("replicas", 0)

            return {
                "running": ready_replicas > 0,
                "ready_replicas": ready_replicas,
                "replicas": replicas,
                "conditions": status.get("conditions", []),
            }

        except json.JSONDecodeError:
            return {"running": False, "error": "Invalid deployment status"}
