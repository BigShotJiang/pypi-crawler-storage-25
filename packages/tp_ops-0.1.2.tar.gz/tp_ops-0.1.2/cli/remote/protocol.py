"""Shared protocol models for CLI <-> Agent communication.

This module re-exports the protocol models from agent_server
for use in the CLI client.
"""

# Re-export from agent_server.protocol
from agent_server.protocol import (
    AgentStatus,
    ActionStatus,
    ChatRequest,
    ChatResponse,
    InvestigateRequest,
    InvestigateResponse,
    ScanRequest,
    ScanResponse,
    StatusResponse,
    HealthResponse,
    ApproveRequest,
    ApproveResponse,
    HistoryEntry,
    HistoryResponse,
    MeshPeer,
    MeshStatusResponse,
    Finding,
    Solution,
    ScanIssue,
)

__all__ = [
    "AgentStatus",
    "ActionStatus",
    "ChatRequest",
    "ChatResponse",
    "InvestigateRequest",
    "InvestigateResponse",
    "ScanRequest",
    "ScanResponse",
    "StatusResponse",
    "HealthResponse",
    "ApproveRequest",
    "ApproveResponse",
    "HistoryEntry",
    "HistoryResponse",
    "MeshPeer",
    "MeshStatusResponse",
    "Finding",
    "Solution",
    "ScanIssue",
]
