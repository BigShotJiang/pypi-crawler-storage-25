"""HTTP client for communicating with deployed tp-ops agents."""

import asyncio
from typing import Optional
from urllib.parse import urljoin

import httpx

from cli.remote.protocol import (
    AgentStatus,
    ChatRequest,
    ChatResponse,
    InvestigateRequest,
    InvestigateResponse,
    ScanRequest,
    ScanResponse,
    StatusResponse,
    HealthResponse,
    ApproveRequest,
    ApproveResponse,
    HistoryResponse,
    MeshStatusResponse,
)


class AgentClientError(Exception):
    """Error communicating with agent."""
    pass


class AgentClient:
    """HTTP client for communicating with a deployed tp-ops agent."""

    DEFAULT_TIMEOUT = 30.0
    LONG_TIMEOUT = 120.0  # For investigations/scans

    def __init__(
        self,
        endpoint: str,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        """Initialize the agent client.

        Args:
            endpoint: Base URL of the agent server (e.g., "http://localhost:8080")
            timeout: Default request timeout in seconds
        """
        # Ensure endpoint doesn't end with /
        self.endpoint = endpoint.rstrip("/")
        self.timeout = timeout
        self._session_id: Optional[str] = None

    def _url(self, path: str) -> str:
        """Build full URL for an API path."""
        return f"{self.endpoint}/api/v1{path}"

    async def _request(
        self,
        method: str,
        path: str,
        json: Optional[dict] = None,
        timeout: Optional[float] = None,
    ) -> dict:
        """Make an HTTP request to the agent."""
        url = self._url(path)
        timeout_val = timeout or self.timeout

        try:
            async with httpx.AsyncClient() as client:
                response = await client.request(
                    method=method,
                    url=url,
                    json=json,
                    timeout=timeout_val,
                )

                if response.status_code >= 400:
                    try:
                        error_detail = response.json().get("detail", response.text)
                    except Exception:
                        error_detail = response.text
                    raise AgentClientError(
                        f"Request failed ({response.status_code}): {error_detail}"
                    )

                return response.json()

        except httpx.ConnectError as e:
            raise AgentClientError(f"Cannot connect to agent at {self.endpoint}: {e}")
        except httpx.TimeoutException:
            raise AgentClientError(f"Request timed out after {timeout_val}s")
        except httpx.RequestError as e:
            raise AgentClientError(f"Request failed: {e}")

    # --- Synchronous wrappers for CLI use ---

    def _sync(self, coro):
        """Run an async coroutine synchronously."""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        return loop.run_until_complete(coro)

    # --- Health & Status ---

    async def health_async(self) -> HealthResponse:
        """Check agent health."""
        data = await self._request("GET", "/health")
        return HealthResponse(**data)

    def health(self) -> HealthResponse:
        """Check agent health (sync)."""
        return self._sync(self.health_async())

    async def status_async(self) -> StatusResponse:
        """Get agent status."""
        data = await self._request("GET", "/status")
        return StatusResponse(**data)

    def status(self) -> StatusResponse:
        """Get agent status (sync)."""
        return self._sync(self.status_async())

    async def wait_ready_async(
        self,
        timeout: float = 120.0,
        poll_interval: float = 2.0,
    ) -> bool:
        """Wait for agent to become ready.

        Args:
            timeout: Maximum time to wait in seconds
            poll_interval: Time between health checks

        Returns:
            True if agent is ready, False if timeout
        """
        import time
        start = time.time()

        while time.time() - start < timeout:
            try:
                health = await self.health_async()
                if health.healthy and health.status == AgentStatus.READY:
                    return True
            except AgentClientError:
                pass  # Agent not reachable yet

            await asyncio.sleep(poll_interval)

        return False

    def wait_ready(self, timeout: float = 120.0, poll_interval: float = 2.0) -> bool:
        """Wait for agent to become ready (sync)."""
        return self._sync(self.wait_ready_async(timeout, poll_interval))

    # --- Chat ---

    async def chat_async(
        self,
        message: str,
        session_id: Optional[str] = None,
    ) -> ChatResponse:
        """Send a chat message to the agent.

        Args:
            message: User message
            session_id: Optional session ID for conversation continuity

        Returns:
            Agent response
        """
        request = ChatRequest(
            message=message,
            session_id=session_id or self._session_id,
        )
        data = await self._request("POST", "/chat", json=request.model_dump())
        response = ChatResponse(**data)

        # Track session ID
        self._session_id = response.session_id

        return response

    def chat(self, message: str, session_id: Optional[str] = None) -> ChatResponse:
        """Send a chat message to the agent (sync)."""
        return self._sync(self.chat_async(message, session_id))

    # --- Investigate ---

    async def investigate_async(
        self,
        problem: str,
        deep: bool = False,
    ) -> InvestigateResponse:
        """Run an investigation.

        Args:
            problem: Problem description
            deep: Whether to run deep investigation

        Returns:
            Investigation results
        """
        request = InvestigateRequest(problem=problem, deep=deep)
        data = await self._request(
            "POST", "/investigate",
            json=request.model_dump(),
            timeout=self.LONG_TIMEOUT,
        )
        return InvestigateResponse(**data)

    def investigate(self, problem: str, deep: bool = False) -> InvestigateResponse:
        """Run an investigation (sync)."""
        return self._sync(self.investigate_async(problem, deep))

    # --- Scan ---

    async def scan_async(
        self,
        deep: bool = False,
        categories: Optional[list[str]] = None,
    ) -> ScanResponse:
        """Run a scan.

        Args:
            deep: Whether to run deep scan
            categories: Optional categories to scan

        Returns:
            Scan results
        """
        request = ScanRequest(deep=deep, categories=categories)
        data = await self._request(
            "POST", "/scan",
            json=request.model_dump(),
            timeout=self.LONG_TIMEOUT,
        )
        return ScanResponse(**data)

    def scan(self, deep: bool = False, categories: Optional[list[str]] = None) -> ScanResponse:
        """Run a scan (sync)."""
        return self._sync(self.scan_async(deep, categories))

    # --- Actions ---

    async def approve_async(
        self,
        action_id: str,
        approved: bool,
        reason: Optional[str] = None,
    ) -> ApproveResponse:
        """Approve or reject a pending action.

        Args:
            action_id: ID of the action
            approved: True to approve, False to reject
            reason: Optional reason for decision

        Returns:
            Approval result
        """
        request = ApproveRequest(
            action_id=action_id,
            approved=approved,
            reason=reason,
        )
        data = await self._request("POST", "/approve", json=request.model_dump())
        return ApproveResponse(**data)

    def approve(
        self,
        action_id: str,
        approved: bool,
        reason: Optional[str] = None,
    ) -> ApproveResponse:
        """Approve or reject a pending action (sync)."""
        return self._sync(self.approve_async(action_id, approved, reason))

    # --- History ---

    async def history_async(
        self,
        page: int = 1,
        page_size: int = 20,
    ) -> HistoryResponse:
        """Get investigation/scan history.

        Args:
            page: Page number (1-indexed)
            page_size: Number of entries per page

        Returns:
            History entries
        """
        data = await self._request(
            "GET",
            f"/history?page={page}&page_size={page_size}",
        )
        return HistoryResponse(**data)

    def history(self, page: int = 1, page_size: int = 20) -> HistoryResponse:
        """Get investigation/scan history (sync)."""
        return self._sync(self.history_async(page, page_size))

    # --- Mesh ---

    async def mesh_status_async(self) -> MeshStatusResponse:
        """Get mesh network status."""
        data = await self._request("GET", "/mesh")
        return MeshStatusResponse(**data)

    def mesh_status(self) -> MeshStatusResponse:
        """Get mesh network status (sync)."""
        return self._sync(self.mesh_status_async())

    # --- Session Management ---

    def reset_session(self) -> None:
        """Reset the session ID to start a new conversation."""
        self._session_id = None

    @property
    def session_id(self) -> Optional[str]:
        """Get current session ID."""
        return self._session_id
