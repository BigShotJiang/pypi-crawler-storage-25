"""VM/systemd deployer for tp-ops agents."""

import subprocess
import tempfile
from pathlib import Path
from typing import Any, Optional

from cli.output.terminal import Terminal
from cli.remote.deployer import BaseDeployer, DeploymentResult


# Systemd service template
SYSTEMD_SERVICE_TEMPLATE = """[Unit]
Description=TernaryPhysics Ops Agent ({resource_name})
After=network.target
Documentation=https://github.com/ternaryphysics/tp-ops

[Service]
Type=simple
User=tp-ops
Group=tp-ops
WorkingDirectory=/var/lib/tp-ops

ExecStart=/usr/local/bin/tp-ops-agent-server \\
    --agent-type {agent_type} \\
    --resource-name {resource_name} \\
    --port {api_port} \\
    --mesh-port {mesh_port} \\
    --data-dir /var/lib/tp-ops \\
    {extra_args}

Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

# Security hardening
NoNewPrivileges=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=/var/lib/tp-ops
PrivateTmp=yes

[Install]
WantedBy=multi-user.target
"""

# Install script template
INSTALL_SCRIPT_TEMPLATE = """#!/bin/bash
set -e

echo "Installing tp-ops agent on {host}..."

# Create user if not exists
if ! id -u tp-ops > /dev/null 2>&1; then
    useradd -r -s /bin/false -d /var/lib/tp-ops tp-ops
fi

# Create directories
mkdir -p /var/lib/tp-ops
mkdir -p /etc/tp-ops
chown -R tp-ops:tp-ops /var/lib/tp-ops

# Install tp-ops
pip3 install --upgrade tp-ops

# Copy systemd service
cat > /etc/systemd/system/tp-ops-agent-{safe_name}.service << 'SYSTEMD_EOF'
{systemd_service}
SYSTEMD_EOF

# Reload and start
systemctl daemon-reload
systemctl enable tp-ops-agent-{safe_name}
systemctl start tp-ops-agent-{safe_name}

echo "tp-ops agent installed and started"
echo "Check status: systemctl status tp-ops-agent-{safe_name}"
echo "View logs: journalctl -u tp-ops-agent-{safe_name} -f"
"""


class VMDeployer(BaseDeployer):
    """Deploy tp-ops agents to VMs via SSH."""

    def __init__(self, terminal: Terminal):
        super().__init__(terminal)

    def _ssh(
        self,
        host: str,
        command: str,
        user: str = "root",
        key_path: Optional[str] = None,
        port: int = 22,
    ) -> subprocess.CompletedProcess:
        """Run a command on a remote host via SSH."""
        ssh_cmd = ["ssh", "-o", "StrictHostKeyChecking=no", "-o", "BatchMode=yes"]

        if key_path:
            ssh_cmd.extend(["-i", key_path])

        ssh_cmd.extend(["-p", str(port)])
        ssh_cmd.append(f"{user}@{host}")
        ssh_cmd.append(command)

        return subprocess.run(
            ssh_cmd,
            capture_output=True,
            text=True,
            timeout=120,
        )

    def _scp(
        self,
        local_path: str,
        remote_path: str,
        host: str,
        user: str = "root",
        key_path: Optional[str] = None,
        port: int = 22,
    ) -> subprocess.CompletedProcess:
        """Copy a file to a remote host via SCP."""
        scp_cmd = ["scp", "-o", "StrictHostKeyChecking=no", "-o", "BatchMode=yes"]

        if key_path:
            scp_cmd.extend(["-i", key_path])

        scp_cmd.extend(["-P", str(port)])
        scp_cmd.append(local_path)
        scp_cmd.append(f"{user}@{host}:{remote_path}")

        return subprocess.run(
            scp_cmd,
            capture_output=True,
            text=True,
            timeout=120,
        )

    def _generate_systemd_service(
        self,
        resource_name: str,
        agent_type: str,
        config: dict[str, Any],
    ) -> str:
        """Generate systemd service file content."""
        api_port = config.get("api_port", 8080)
        mesh_port = config.get("mesh_port", 7100)

        # Build extra args based on agent type
        extra_args = []

        if agent_type == "vm-agent":
            # VM agent runs locally, no extra connection args needed
            pass
        elif agent_type == "postgres-agent":
            if config.get("db_host"):
                extra_args.append(f"--db-host {config['db_host']}")
            if config.get("db_port"):
                extra_args.append(f"--db-port {config['db_port']}")
            if config.get("db_user"):
                extra_args.append(f"--db-user {config['db_user']}")
            if config.get("db_name"):
                extra_args.append(f"--db-name {config['db_name']}")
        elif agent_type == "redis-agent":
            if config.get("db_host"):
                extra_args.append(f"--db-host {config['db_host']}")
            if config.get("db_port"):
                extra_args.append(f"--db-port {config['db_port']}")

        return SYSTEMD_SERVICE_TEMPLATE.format(
            resource_name=resource_name,
            agent_type=agent_type,
            api_port=api_port,
            mesh_port=mesh_port,
            extra_args=" \\\n    ".join(extra_args) if extra_args else "",
        )

    def _generate_install_script(
        self,
        resource_name: str,
        agent_type: str,
        config: dict[str, Any],
    ) -> str:
        """Generate install script."""
        host = config.get("host", "localhost")
        safe_name = resource_name.lower().replace("_", "-").replace(" ", "-")[:63]

        systemd_service = self._generate_systemd_service(resource_name, agent_type, config)

        return INSTALL_SCRIPT_TEMPLATE.format(
            host=host,
            safe_name=safe_name,
            systemd_service=systemd_service,
        )

    def deploy(
        self,
        resource_name: str,
        agent_type: str,
        config: dict[str, Any],
    ) -> DeploymentResult:
        """Deploy an agent to a VM via SSH."""
        host = config.get("host")
        if not host:
            return DeploymentResult(
                success=False,
                error="Host is required for VM deployment",
            )

        user = config.get("user", "root")
        key_path = config.get("key_path")
        ssh_port = config.get("ssh_port", 22)
        api_port = config.get("api_port", 8080)

        safe_name = resource_name.lower().replace("_", "-").replace(" ", "-")[:63]

        # Test SSH connection
        self.terminal.info(f"Testing SSH connection to {user}@{host}...")
        result = self._ssh(host, "echo 'Connection OK'", user=user, key_path=key_path, port=ssh_port)

        if result.returncode != 0:
            return DeploymentResult(
                success=False,
                error=f"SSH connection failed: {result.stderr}",
            )

        # Generate install script
        self.terminal.info("Generating install script...")
        install_script = self._generate_install_script(resource_name, agent_type, config)

        # Create temp file and copy to remote
        with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False) as f:
            f.write(install_script)
            script_path = f.name

        try:
            # Copy script to remote
            self.terminal.info("Copying install script to remote host...")
            result = self._scp(
                script_path,
                "/tmp/tp-ops-install.sh",
                host,
                user=user,
                key_path=key_path,
                port=ssh_port,
            )

            if result.returncode != 0:
                return DeploymentResult(
                    success=False,
                    error=f"Failed to copy install script: {result.stderr}",
                )

            # Run install script
            self.terminal.info("Running install script...")
            result = self._ssh(
                host,
                "chmod +x /tmp/tp-ops-install.sh && /tmp/tp-ops-install.sh",
                user=user,
                key_path=key_path,
                port=ssh_port,
            )

            if result.returncode != 0:
                return DeploymentResult(
                    success=False,
                    error=f"Install script failed: {result.stderr}",
                    details={"stdout": result.stdout, "stderr": result.stderr},
                )

            # Verify service is running
            self.terminal.info("Verifying agent is running...")
            result = self._ssh(
                host,
                f"systemctl is-active tp-ops-agent-{safe_name}",
                user=user,
                key_path=key_path,
                port=ssh_port,
            )

            if result.returncode != 0 or "active" not in result.stdout:
                return DeploymentResult(
                    success=False,
                    error="Agent service failed to start",
                    details={"stdout": result.stdout, "stderr": result.stderr},
                )

            # Build endpoint
            endpoint = f"http://{host}:{api_port}"

            return DeploymentResult(
                success=True,
                endpoint=endpoint,
                details={
                    "host": host,
                    "service": f"tp-ops-agent-{safe_name}",
                    "ssh_command": f"ssh {user}@{host}",
                    "logs_command": f"ssh {user}@{host} 'journalctl -u tp-ops-agent-{safe_name} -f'",
                },
            )

        finally:
            import os
            os.unlink(script_path)

    def undeploy(
        self,
        resource_name: str,
        agent_type: str,
        config: Optional[dict[str, Any]] = None,
    ) -> DeploymentResult:
        """Remove a deployed agent from a VM."""
        config = config or {}
        host = config.get("host")

        if not host:
            return DeploymentResult(
                success=False,
                error="Host is required for VM undeployment",
            )

        user = config.get("user", "root")
        key_path = config.get("key_path")
        ssh_port = config.get("ssh_port", 22)

        safe_name = resource_name.lower().replace("_", "-").replace(" ", "-")[:63]

        # Stop and disable service
        self.terminal.info(f"Stopping agent service on {host}...")
        result = self._ssh(
            host,
            f"systemctl stop tp-ops-agent-{safe_name} || true; "
            f"systemctl disable tp-ops-agent-{safe_name} || true; "
            f"rm -f /etc/systemd/system/tp-ops-agent-{safe_name}.service; "
            f"systemctl daemon-reload",
            user=user,
            key_path=key_path,
            port=ssh_port,
        )

        if result.returncode != 0:
            return DeploymentResult(
                success=False,
                error=f"Failed to stop agent: {result.stderr}",
            )

        return DeploymentResult(success=True)

    def status(
        self,
        resource_name: str,
        agent_type: str,
        config: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """Get status of a deployed agent."""
        config = config or {}
        host = config.get("host")

        if not host:
            return {"running": False, "error": "Host not configured"}

        user = config.get("user", "root")
        key_path = config.get("key_path")
        ssh_port = config.get("ssh_port", 22)

        safe_name = resource_name.lower().replace("_", "-").replace(" ", "-")[:63]

        # Check service status
        result = self._ssh(
            host,
            f"systemctl is-active tp-ops-agent-{safe_name}",
            user=user,
            key_path=key_path,
            port=ssh_port,
        )

        running = result.returncode == 0 and "active" in result.stdout

        # Get more details if running
        if running:
            result = self._ssh(
                host,
                f"systemctl show tp-ops-agent-{safe_name} --property=MainPID,ActiveEnterTimestamp,MemoryCurrent",
                user=user,
                key_path=key_path,
                port=ssh_port,
            )

            details = {}
            for line in result.stdout.strip().split("\n"):
                if "=" in line:
                    key, value = line.split("=", 1)
                    details[key] = value

            return {
                "running": True,
                "pid": details.get("MainPID"),
                "started_at": details.get("ActiveEnterTimestamp"),
                "memory": details.get("MemoryCurrent"),
            }

        return {"running": False}
