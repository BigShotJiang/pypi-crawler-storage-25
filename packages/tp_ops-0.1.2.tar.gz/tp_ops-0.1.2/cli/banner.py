"""ASCII art banner for tp-ops CLI."""

# Green color code for terminal
GREEN = "\033[32m"
BRIGHT_GREEN = "\033[92m"
RESET = "\033[0m"
DIM = "\033[2m"

BANNER = f"""{BRIGHT_GREEN}
  _                                        _               _
 | |_ ___ _ __ _ __   __ _ _ __ _   _ _ __ | |__  _   _ ___(_) ___ ___
 | __/ _ \\ '__| '_ \\ / _` | '__| | | | '_ \\| '_ \\| | | / __| |/ __/ __|
 | ||  __/ |  | | | | (_| | |  | |_| | |_) | | | | |_| \\__ \\ | (__\\__ \\
  \\__\\___|_|  |_| |_|\\__,_|_|   \\__, | .__/|_| |_|\\__, |___/_|\\___|___/
                                |___/|_|          |___/
{RESET}"""

TAGLINE = f"{DIM}  Drop an AI agent onto any resource. Pay per GB.{RESET}"

BANNER_SIMPLE = f"""{BRIGHT_GREEN}
 ╔╦╗╔═╗╦═╗╔╗╔╔═╗╦═╗╦ ╦╔═╗╦ ╦╦ ╦╔═╗╦╔═╗╔═╗
  ║ ║╣ ╠╦╝║║║╠═╣╠╦╝╚╦╝╠═╝╠═╣╚╦╝╚═╗║║  ╚═╗
  ╩ ╚═╝╩╚═╝╚╝╩ ╩╩╚═ ╩ ╩  ╩ ╩ ╩ ╚═╝╩╚═╝╚═╝
{RESET}"""

BANNER_COMPACT = f"""{BRIGHT_GREEN}
  ┌┬┐┌─┐   ┌─┐┌─┐┌─┐
   │ ├─┘───│ │├─┘└─┐
   ┴ ┴     └─┘┴  └─┘
{RESET}"""


def get_banner(compact: bool = False) -> str:
    """Get the ASCII art banner.

    Args:
        compact: If True, return the compact version.

    Returns:
        The banner string with ANSI color codes.
    """
    if compact:
        return BANNER_COMPACT + TAGLINE + "\n"
    return BANNER + TAGLINE + "\n"


def print_banner(compact: bool = False) -> None:
    """Print the ASCII art banner to stdout."""
    print(get_banner(compact))
