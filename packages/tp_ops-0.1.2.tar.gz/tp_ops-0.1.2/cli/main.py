#!/usr/bin/env python3
"""
TernaryPhysics Ops CLI

Drop an AI agent onto any resource. Pay per GB.

Usage:
    # On the resource itself:
    tp-ops drop

    # From anywhere, talk to the mesh:
    tp-ops ask my-server "what's wrong?"
    tp-ops list
"""

import argparse
import sys
from pathlib import Path

from cli import __version__
from cli.banner import print_banner
from cli.commands import (
    drop, run, scan, audit, approve, list_agents, history, remove, ask,
    init_cmd, login, logout, account, usage,
)
from cli.output.terminal import Terminal


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser for tp-ops CLI."""
    parser = argparse.ArgumentParser(
        prog="tp-ops",
        description="Drop an AI agent onto any resource. Pay per GB.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # On the resource itself:
  tp-ops drop                                      # Auto-detects and starts agent

  # From anywhere (via mesh):
  tp-ops ask my-server "why is CPU high?"          # Talk to an agent
  tp-ops list                                      # List all agents in mesh
        """
    )

    parser.add_argument(
        "--version", "-v",
        action="version",
        version=f"tp-ops {__version__}"
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose output"
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # drop command - run ON the resource, auto-detects everything
    drop_parser = subparsers.add_parser(
        "drop",
        help="Drop an agent onto THIS resource (run on the resource itself)"
    )
    drop_parser.add_argument(
        "--name",
        metavar="NAME",
        help="Override auto-detected resource name"
    )
    drop_parser.add_argument(
        "--type",
        metavar="TYPE",
        help="Override auto-detected agent type (e.g., relay-agent, apigw-agent)"
    )
    drop_parser.add_argument(
        "--apim",
        metavar="APIM_NAME",
        help="Azure API Management instance name (required for apigw-agent)"
    )
    drop_parser.add_argument(
        "--subscription",
        metavar="SUB_ID",
        help="Azure subscription ID (required for azure-agent)"
    )
    drop_parser.add_argument(
        "--host",
        metavar="HOST",
        help="Override auto-detected host (for database agents)"
    )
    drop_parser.add_argument(
        "--kubeconfig",
        metavar="PATH",
        help="Path to kubeconfig (for k8s-agent)"
    )
    drop_parser.add_argument(
        "--context",
        metavar="NAME",
        help="Kubernetes context to use (for k8s-agent)"
    )
    drop_parser.add_argument(
        "--skip-verify",
        action="store_true",
        help="Skip service verification"
    )
    drop_parser.set_defaults(func=drop.execute)

    # run command
    run_parser = subparsers.add_parser(
        "run",
        help="Run an investigation on a resource"
    )
    run_parser.add_argument(
        "resource",
        help="Resource name to investigate"
    )
    run_parser.add_argument(
        "problem",
        help="Description of the problem to investigate"
    )
    run_parser.add_argument(
        "--auto-approve",
        action="store_true",
        help="Automatically approve recommended actions (use with caution)"
    )
    run_parser.set_defaults(func=run.execute)

    # scan command
    scan_parser = subparsers.add_parser(
        "scan",
        help="Run a proactive scan on a resource"
    )
    scan_parser.add_argument(
        "resource",
        help="Resource name to scan"
    )
    scan_parser.add_argument(
        "--deep",
        action="store_true",
        help="Run a deep scan (more thorough, processes more data)"
    )
    scan_parser.set_defaults(func=scan.execute)

    # audit command
    audit_parser = subparsers.add_parser(
        "audit",
        help="Run a security audit on a resource"
    )
    audit_parser.add_argument(
        "resource",
        help="Resource name to audit"
    )
    audit_parser.add_argument(
        "--compliance",
        choices=["cis", "soc2", "hipaa", "pci"],
        help="Compliance framework to audit against"
    )
    audit_parser.set_defaults(func=audit.execute)

    # approve command
    approve_parser = subparsers.add_parser(
        "approve",
        help="Approve a recommended action"
    )
    approve_parser.add_argument(
        "action_id",
        help="Action ID to approve (format: resource:action-N)"
    )
    approve_parser.set_defaults(func=approve.execute)

    # reject command
    reject_parser = subparsers.add_parser(
        "reject",
        help="Reject a recommended action"
    )
    reject_parser.add_argument(
        "action_id",
        help="Action ID to reject (format: resource:action-N)"
    )
    reject_parser.set_defaults(func=approve.execute_reject)

    # list command
    list_parser = subparsers.add_parser(
        "list",
        help="List all dropped agents"
    )
    list_parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON"
    )
    list_parser.set_defaults(func=list_agents.execute)

    # history command
    history_parser = subparsers.add_parser(
        "history",
        help="View investigation history for a resource"
    )
    history_parser.add_argument(
        "resource",
        help="Resource name"
    )
    history_parser.add_argument(
        "--limit",
        type=int,
        default=10,
        help="Number of entries to show (default: 10)"
    )
    history_parser.set_defaults(func=history.execute)

    # remove command
    remove_parser = subparsers.add_parser(
        "remove",
        help="Remove an agent from a resource"
    )
    remove_parser.add_argument(
        "resource",
        help="Resource name to remove agent from"
    )
    remove_parser.add_argument(
        "--force",
        action="store_true",
        help="Force removal without confirmation"
    )
    remove_parser.set_defaults(func=remove.execute)

    # ask command - interactive conversation
    ask_parser = subparsers.add_parser(
        "ask",
        help="Talk to an agent (interactive conversation)"
    )
    ask_parser.add_argument(
        "resource",
        help="Resource name to talk to"
    )
    ask_parser.add_argument(
        "--mock",
        action="store_true",
        help="Use mock LLM responses for testing"
    )
    ask_parser.set_defaults(func=ask.execute)

    # init command
    init_cmd.add_parser(subparsers)

    # login command
    login.add_parser(subparsers)

    # logout command
    logout.add_parser(subparsers)

    # account command
    account.add_parser(subparsers)

    # usage command
    usage.add_parser(subparsers)

    return parser


def main(args: list[str] | None = None) -> int:
    """Main entry point for tp-ops CLI."""
    parser = create_parser()
    parsed = parser.parse_args(args)

    if not parsed.command:
        print_banner()
        parser.print_help()
        return 0

    terminal = Terminal(verbose=parsed.verbose)

    try:
        return parsed.func(parsed, terminal)
    except KeyboardInterrupt:
        terminal.error("\nInterrupted by user")
        return 130
    except Exception as e:
        terminal.error(f"Error: {e}")
        if parsed.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
