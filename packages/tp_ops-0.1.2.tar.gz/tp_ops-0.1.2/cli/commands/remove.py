"""Remove command - remove an agent from a resource."""

import argparse

from cli.output.terminal import Terminal
from cli.auth.credentials import get_agent, remove_agent


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the remove command."""
    agent = get_agent(args.resource)

    if not agent:
        terminal.error(f"No agent found for resource '{args.resource}'")
        return 1

    terminal.header(f"Remove Agent: {args.resource}")
    terminal.info(f"Agent type: {agent.get('type')}")
    terminal.info(f"Total GB processed: {agent.get('total_gb_processed', 0):.2f}")
    terminal.info(f"Total cost: ${agent.get('total_cost', 0):.2f}")
    terminal.print()

    if not args.force:
        if not terminal.confirm("Remove this agent?"):
            terminal.info("Cancelled")
            return 0

    if remove_agent(args.resource):
        terminal.success(f"Agent removed from '{args.resource}'")
        terminal.info("Investigation history is preserved.")
        return 0
    else:
        terminal.error("Failed to remove agent")
        return 1
