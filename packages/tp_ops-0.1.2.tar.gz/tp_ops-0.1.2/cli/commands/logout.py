"""tp-ops logout command - clear stored credentials."""

import argparse

from cli.output.terminal import Terminal
from cli.auth.token import clear_token, get_token
from cli.api.offline_queue import get_pending_count, clear_queue


def add_parser(subparsers) -> None:
    """Add the logout command parser."""
    parser = subparsers.add_parser(
        "logout",
        help="Log out and clear stored credentials",
        description="Remove stored API token and optionally clear local data.",
    )
    parser.add_argument(
        "--purge",
        action="store_true",
        help="Also clear pending usage events queue",
    )
    parser.set_defaults(func=execute)


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the logout command."""
    # Check if logged in
    if not get_token():
        terminal.info("Not currently logged in.")
        return 0

    # Check for pending usage
    pending = get_pending_count()
    if pending > 0 and not args.purge:
        terminal.warning(f"Warning: {pending} usage events pending sync.")
        terminal.info("These events have not been reported to the billing backend.")
        terminal.info("")
        terminal.info("Options:")
        terminal.info("  1. Run 'tp-ops login' to sync before logging out")
        terminal.info("  2. Run 'tp-ops logout --purge' to discard pending events")
        terminal.info("")

        try:
            confirm = input("Continue logout without syncing? [y/N]: ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            terminal.info("")
            terminal.info("Logout cancelled.")
            return 0

        if confirm not in ("y", "yes"):
            terminal.info("Logout cancelled.")
            return 0

    # Clear token
    clear_token()
    terminal.success("Logged out successfully.")

    # Clear pending queue if requested
    if args.purge and pending > 0:
        cleared = clear_queue()
        terminal.info(f"Cleared {cleared} pending usage events.")

    return 0
