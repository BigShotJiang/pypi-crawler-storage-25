"""Scan command - run a proactive scan on a resource."""

import argparse
import time
from datetime import datetime

from cli.output.terminal import Terminal
from cli.auth.credentials import get_agent, save_agents, load_agents, save_investigation
from cli.api.usage_reporter import report_usage_async


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the scan command."""
    agent = get_agent(args.resource)

    if not agent:
        terminal.error(f"No agent found for resource '{args.resource}'")
        terminal.info("List agents with: tp-ops list")
        return 1

    terminal.header(f"Proactive Scan: {args.resource}")

    scan_type = "deep" if args.deep else "standard"
    terminal.info(f"Scan type: {scan_type}")
    terminal.print()

    # Check if this agent has a remote endpoint (deployed agent)
    endpoint = agent.get("endpoint")

    if endpoint:
        # Remote mode: forward to deployed agent
        return _execute_remote(args, terminal, agent, endpoint)
    else:
        # Local mode (legacy): run agent locally
        terminal.warning("Running in local mode (agent not deployed to resource)")
        terminal.info("For production use, re-deploy with: tp-ops remove && tp-ops drop")
        terminal.print()
        return _execute_local(args, terminal, agent)


def _execute_remote(
    args: argparse.Namespace,
    terminal: Terminal,
    agent: dict,
    endpoint: str
) -> int:
    """Execute scan via remote deployed agent."""
    from cli.remote.client import AgentClient, AgentClientError

    client = AgentClient(endpoint)

    # Check agent health first
    terminal.spinner_start("Connecting to agent...")
    try:
        health = client.health()
        if not health.healthy:
            terminal.spinner_stop(False)
            terminal.error(f"Agent is unhealthy: {health.message}")
            return 1
        terminal.spinner_stop(True)
    except AgentClientError as e:
        terminal.spinner_stop(False)
        terminal.error(f"Cannot connect to agent at {endpoint}: {e}")
        terminal.info("Check agent status with: tp-ops status <resource>")
        return 1

    # Run the scan
    categories = getattr(args, 'categories', None)
    terminal.spinner_start("Running proactive scan...")

    try:
        result = client.scan(deep=args.deep, categories=categories)
        terminal.spinner_stop(True)

        # Display issues by severity
        issues_by_severity = {"critical": [], "warning": [], "info": []}
        for issue in result.issues:
            severity = issue.severity.lower()
            if severity in issues_by_severity:
                issues_by_severity[severity].append(issue)

        # Critical issues
        if issues_by_severity["critical"]:
            terminal.subheader("Critical Issues")
            for issue in issues_by_severity["critical"]:
                terminal.error(f"  {issue.category}: {issue.description}")
                if issue.recommendation:
                    terminal.print(f"    Recommendation: {issue.recommendation}")

        # Warnings
        if issues_by_severity["warning"]:
            terminal.subheader("Warnings")
            for issue in issues_by_severity["warning"]:
                terminal.warning(f"  {issue.category}: {issue.description}")
                if issue.recommendation:
                    terminal.print(f"    Recommendation: {issue.recommendation}")

        # Info
        if issues_by_severity["info"]:
            terminal.subheader("Informational")
            for issue in issues_by_severity["info"]:
                terminal.info(f"  {issue.category}: {issue.description}")

        # Summary
        terminal.print()
        summary = result.summary or {}
        critical = summary.get("critical", 0)
        warning = summary.get("warning", 0)
        info = summary.get("info", 0)

        if critical == 0 and warning == 0:
            terminal.success("No critical or warning issues found")
        else:
            terminal.print(f"Summary: {critical} critical, {warning} warnings, {info} info")

        # Update agent stats
        agents = load_agents()
        if args.resource in agents:
            gb_processed = result.bytes_processed / (1024 * 1024 * 1024) if result.bytes_processed else 0
            agents[args.resource]["total_gb_processed"] += gb_processed
            save_agents(agents)

        # Report usage
        report_usage_async(
            resource_name=args.resource,
            agent_type=agent.get("type", "unknown"),
            command="scan",
            bytes_processed=result.bytes_processed or 0,
            duration_seconds=result.duration_seconds or 0,
        )

        # Display meter
        gb = result.bytes_processed / (1024 * 1024 * 1024) if result.bytes_processed else 0
        cost = gb * 0.50  # $0.50 per GB estimate
        terminal.print()
        terminal.meter(gb, cost)

        return 0

    except AgentClientError as e:
        terminal.spinner_stop(False)
        terminal.error(f"Scan failed: {e}")
        return 1


def _execute_local(args: argparse.Namespace, terminal: Terminal, agent: dict) -> int:
    """Execute scan locally (legacy mode)."""
    agent_type = agent.get("type")

    if agent_type == "k8s-agent":
        return scan_k8s(args, agent, terminal)
    elif agent_type == "vm-agent":
        return scan_vm(args, agent, terminal)
    elif agent_type == "postgres-agent":
        return scan_postgres(args, agent, terminal)
    else:
        terminal.info(f"Proactive scanning for {agent_type} coming soon.")
        return 0


def scan_k8s(args: argparse.Namespace, agent: dict, terminal: Terminal) -> int:
    """Run Kubernetes proactive scan."""
    from agents.kubernetes.agent import KubernetesAgent

    k8s_agent = KubernetesAgent(
        name=args.resource,
        config=agent.get("config", {}),
        terminal=terminal,
    )

    start_time = time.time()

    try:
        result = k8s_agent.scan(deep=args.deep)
        duration = time.time() - start_time

        # Update stats
        agents = load_agents()
        if args.resource in agents:
            agents[args.resource]["total_gb_processed"] += result.get("gb_processed", 0)
            agents[args.resource]["total_cost"] += result.get("cost", 0)
            save_agents(agents)

        # Report usage to backend for billing
        report_usage_async(
            resource_name=args.resource,
            agent_type="k8s-agent",
            command="scan",
            bytes_processed=k8s_agent.meter.get_bytes(),
            duration_seconds=duration,
        )

        return 0

    except Exception as e:
        terminal.error(f"Scan failed: {e}")
        return 1


def scan_vm(args: argparse.Namespace, agent: dict, terminal: Terminal) -> int:
    """Run VM proactive scan."""
    terminal.step(1, 5, "Checking for runaway processes...")
    terminal.step_result("No runaway processes detected")

    terminal.step(2, 5, "Checking disk usage...")
    terminal.step_result("/var/log: 45% (OK)")

    terminal.step(3, 5, "Checking for zombie processes...")
    terminal.step_result("No zombie processes")

    terminal.step(4, 5, "Checking log rotation...")
    terminal.step_result("Log rotation configured correctly")

    terminal.step(5, 5, "Checking swap usage...")
    terminal.step_result("Swap: 0% (OK)")

    terminal.print()
    terminal.success("No issues found")
    terminal.meter(0.3, 0.15)
    return 0


def scan_postgres(args: argparse.Namespace, agent: dict, terminal: Terminal) -> int:
    """Run PostgreSQL proactive scan."""
    terminal.step(1, 6, "Checking for missing indexes...")
    terminal.step_result("Found 2 potential missing indexes")

    terminal.step(2, 6, "Checking for bloated tables...")
    terminal.step_result("users table: 15% bloat")

    terminal.step(3, 6, "Checking for unused indexes...")
    terminal.step_result("idx_users_deprecated: 0 scans in 7 days")

    terminal.step(4, 6, "Checking connection leaks...")
    terminal.step_result("No connection leaks detected")

    terminal.step(5, 6, "Checking long-running transactions...")
    terminal.step_result("No long-running transactions")

    terminal.step(6, 6, "Checking autovacuum status...")
    terminal.step_result("Autovacuum running normally")

    terminal.print()
    terminal.subheader("Findings")

    terminal.warning("2 potential issues found:")
    terminal.print("  1. Missing index on orders.customer_id (sequential scans: 1.2M/day)")
    terminal.print("  2. Unused index idx_users_deprecated (consider dropping)")

    terminal.meter(1.2, 0.60)
    return 0
