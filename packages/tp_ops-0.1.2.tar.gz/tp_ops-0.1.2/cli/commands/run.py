"""Run command - run an investigation on a resource."""

import argparse
import asyncio
import time
import uuid
from datetime import datetime

from cli.output.terminal import Terminal
from cli.auth.credentials import (
    get_agent,
    save_agents,
    load_agents,
    save_investigation,
    add_pending_action,
)
from cli.api.usage_reporter import report_usage_async


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the run command."""
    agent = get_agent(args.resource)

    if not agent:
        terminal.error(f"No agent found for resource '{args.resource}'")
        terminal.info("List agents with: tp-ops list")
        terminal.info("Drop an agent on the resource: ssh <host> && pip install tp-ops && tp-ops drop")
        return 1

    terminal.header(f"Investigating {args.resource}")
    terminal.info(f"Problem: {args.problem}")
    terminal.print()

    # Check if this agent has a remote endpoint (deployed agent)
    endpoint = agent.get("endpoint")

    if endpoint:
        # Remote mode: forward to deployed agent
        return _execute_remote(args, terminal, agent, endpoint)
    else:
        # Local mode (legacy): run agent locally
        terminal.warning("Running in local mode (agent not deployed to resource)")
        terminal.info("For production use, re-deploy with: tp-ops remove && tp-ops drop")
        terminal.print()
        return _execute_local(args, terminal, agent)


def _execute_remote(
    args: argparse.Namespace,
    terminal: Terminal,
    agent: dict,
    endpoint: str
) -> int:
    """Execute investigation via remote deployed agent."""
    from cli.remote.client import AgentClient, AgentClientError

    client = AgentClient(endpoint)

    # Check agent health first
    terminal.spinner_start("Connecting to agent...")
    try:
        health = client.health()
        if not health.healthy:
            terminal.spinner_stop(False)
            terminal.error(f"Agent is unhealthy: {health.message}")
            return 1
        terminal.spinner_stop(True)
    except AgentClientError as e:
        terminal.spinner_stop(False)
        terminal.error(f"Cannot connect to agent at {endpoint}: {e}")
        terminal.info("Check agent status with: tp-ops status <resource>")
        return 1

    # Run the investigation
    deep = getattr(args, 'deep', False)
    terminal.spinner_start("Running investigation...")

    try:
        result = client.investigate(args.problem, deep=deep)
        terminal.spinner_stop(True)

        # Display findings
        if result.findings:
            terminal.subheader("Findings")
            for finding in result.findings:
                severity_color = {
                    "critical": "red",
                    "high": "yellow",
                    "medium": "blue",
                    "low": "dim",
                }.get(finding.severity, "white")
                terminal.print(f"  [{finding.severity.upper()}] {finding.description}")

        # Display root cause
        if result.root_cause:
            terminal.print()
            terminal.subheader("Root Cause")
            terminal.print(f"  {result.root_cause}")

        # Display solutions
        if result.solutions:
            terminal.print()
            terminal.subheader("Recommended Solutions")
            for i, solution in enumerate(result.solutions, 1):
                terminal.print(f"  {i}. {solution.description}")
                if solution.command:
                    terminal.print(f"     Command: {solution.command}")

        # Save investigation to history
        investigation_id = result.investigation_id
        investigation_record = {
            "id": investigation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "problem": args.problem,
            "root_cause": result.root_cause,
            "findings_count": len(result.findings),
            "solutions_count": len(result.solutions),
            "gb_processed": result.bytes_processed / (1024 * 1024 * 1024) if result.bytes_processed else 0,
            "duration_seconds": result.duration_seconds,
        }
        save_investigation(args.resource, investigation_record)

        # Register pending actions
        for i, solution in enumerate(result.solutions, 1):
            if solution.command:
                add_pending_action(
                    resource=args.resource,
                    action_num=i,
                    command=solution.command,
                    description=solution.description,
                    investigation_id=investigation_id,
                )

        # Update agent stats
        agents = load_agents()
        if args.resource in agents:
            gb_processed = result.bytes_processed / (1024 * 1024 * 1024) if result.bytes_processed else 0
            agents[args.resource]["total_gb_processed"] += gb_processed
            save_agents(agents)

        # Report usage
        report_usage_async(
            resource_name=args.resource,
            agent_type=agent.get("type", "unknown"),
            command="run",
            bytes_processed=result.bytes_processed or 0,
            duration_seconds=result.duration_seconds or 0,
        )

        # Display meter
        gb = result.bytes_processed / (1024 * 1024 * 1024) if result.bytes_processed else 0
        cost = gb * 0.50  # $0.50 per GB estimate
        terminal.print()
        terminal.meter(gb, cost)

        return 0

    except AgentClientError as e:
        terminal.spinner_stop(False)
        terminal.error(f"Investigation failed: {e}")
        return 1


def _execute_local(args: argparse.Namespace, terminal: Terminal, agent: dict) -> int:
    """Execute investigation locally (legacy mode)."""
    agent_type = agent.get("type")

    if agent_type == "k8s-agent":
        return run_k8s_investigation(args, agent, terminal)
    elif agent_type == "vm-agent":
        return run_vm_investigation(args, agent, terminal)
    elif agent_type == "postgres-agent":
        return run_postgres_investigation(args, agent, terminal)
    elif agent_type == "apigw-agent":
        return run_apigw_investigation(args, agent, terminal)
    elif agent_type == "azure-agent":
        return run_azure_investigation(args, agent, terminal)
    elif agent_type == "security-agent":
        terminal.info("For security audits, use: tp-ops audit <resource>")
        return 1
    else:
        terminal.error(f"Unknown agent type: {agent_type}")
        return 1


def run_k8s_investigation(
    args: argparse.Namespace,
    agent: dict,
    terminal: Terminal
) -> int:
    """Run a Kubernetes investigation."""
    from agents.kubernetes.agent import KubernetesAgent

    k8s_agent = KubernetesAgent(
        name=args.resource,
        config=agent.get("config", {}),
        terminal=terminal,
    )

    investigation_id = str(uuid.uuid4())[:8]
    start_time = time.time()

    try:
        result = k8s_agent.investigate(args.problem)
        duration = time.time() - start_time

        # Save investigation to history
        investigation_record = {
            "id": investigation_id,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "problem": args.problem,
            "root_cause": result.get("root_cause"),
            "evidence": result.get("evidence", []),
            "recommendations": result.get("recommendations", []),
            "gb_processed": result.get("gb_processed", 0),
            "cost": result.get("cost", 0),
        }
        save_investigation(args.resource, investigation_record)

        # Update agent stats
        agents = load_agents()
        if args.resource in agents:
            agents[args.resource]["total_gb_processed"] += result.get("gb_processed", 0)
            agents[args.resource]["total_cost"] += result.get("cost", 0)
            save_agents(agents)

        # Register pending actions
        for i, rec in enumerate(result.get("recommendations", []), 1):
            if rec.get("command"):
                add_pending_action(
                    resource=args.resource,
                    action_num=i,
                    command=rec["command"],
                    description=rec["description"],
                    investigation_id=investigation_id,
                )

        # Report usage to backend for billing
        report_usage_async(
            resource_name=args.resource,
            agent_type="k8s-agent",
            command="run",
            bytes_processed=k8s_agent.meter.get_bytes(),
            duration_seconds=duration,
        )

        return 0

    except Exception as e:
        terminal.error(f"Investigation failed: {e}")
        return 1


def run_vm_investigation(
    args: argparse.Namespace,
    agent: dict,
    terminal: Terminal
) -> int:
    """Run a VM investigation."""
    terminal.info("VM Agent investigation")
    terminal.print()

    # Placeholder - will be implemented with VM agent
    terminal.step(1, 4, "Connecting to VM...")
    terminal.step_result(f"Connected to {agent['config'].get('host', 'unknown')}")

    terminal.step(2, 4, "Checking system resources...")
    terminal.step_result("CPU: 45%, Memory: 72%, Disk: 58%")

    terminal.step(3, 4, "Analyzing processes...")
    terminal.step_result("Top process: python3 (32% CPU)")

    terminal.step(4, 4, "Checking recent changes...")
    terminal.step_result("No recent deployments detected")

    terminal.print()
    terminal.info("VM Agent is not fully implemented yet.")
    terminal.info("Investigation capabilities coming soon.")

    terminal.meter(0.5, 0.25)
    return 0


def run_postgres_investigation(
    args: argparse.Namespace,
    agent: dict,
    terminal: Terminal
) -> int:
    """Run a PostgreSQL investigation."""
    terminal.info("PostgreSQL Agent investigation")
    terminal.print()

    # Placeholder - will be implemented with PostgreSQL agent
    terminal.step(1, 4, "Connecting to database...")
    terminal.step_result(f"Connected to {agent['config'].get('host', 'unknown')}")

    terminal.step(2, 4, "Analyzing slow queries...")
    terminal.step_result("Found 3 queries > 1s")

    terminal.step(3, 4, "Checking connections...")
    terminal.step_result("Active: 45/100, Idle: 12")

    terminal.step(4, 4, "Analyzing indexes...")
    terminal.step_result("2 missing indexes detected")

    terminal.print()
    terminal.info("PostgreSQL Agent is not fully implemented yet.")
    terminal.info("Investigation capabilities coming soon.")

    terminal.meter(0.8, 0.40)
    return 0


def run_apigw_investigation(
    args: argparse.Namespace,
    agent: dict,
    terminal: Terminal
) -> int:
    """Run an API Gateway investigation."""
    terminal.info("API Gateway Agent investigation")
    terminal.print()

    # Placeholder
    terminal.info("API Gateway Agent is not fully implemented yet.")
    terminal.meter(0.3, 0.15)
    return 0


def run_azure_investigation(
    args: argparse.Namespace,
    agent: dict,
    terminal: Terminal
) -> int:
    """Run an Azure Monitor investigation."""
    terminal.info("Azure Monitor Agent investigation")
    terminal.print()

    # Placeholder
    terminal.info("Azure Monitor Agent is not fully implemented yet.")
    terminal.meter(0.5, 0.25)
    return 0
