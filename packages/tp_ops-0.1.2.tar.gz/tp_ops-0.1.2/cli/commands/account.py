"""tp-ops account command - show account information."""

import argparse
import json

from cli.output.terminal import Terminal
from cli.auth.token import get_token, get_token_prefix, is_test_token


def add_parser(subparsers) -> None:
    """Add the account command parser."""
    parser = subparsers.add_parser(
        "account",
        help="Show account information",
        description="Display account details, plan, and current usage.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON",
    )
    parser.set_defaults(func=execute)


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the account command."""
    token = get_token()

    if not token:
        terminal.error("Not logged in.")
        terminal.info("")
        terminal.info("Run 'tp-ops login --token <your-token>' to authenticate.")
        terminal.info("Get your token at: https://ternaryphysics.com/dashboard/tokens")
        return 1

    try:
        from cli.api.client import TPOpsAPIClient, APIError

        with TPOpsAPIClient(token=token) as client:
            account = client.get_account()
            usage = client.get_current_usage()

    except ImportError:
        terminal.error("httpx not installed.")
        terminal.info("Install with: pip install httpx")
        return 1

    except APIError as e:
        terminal.error(f"API Error: {e.message}")
        return 1

    except Exception as e:
        terminal.error(f"Connection error: {e}")
        terminal.info("Check your internet connection and try again.")
        return 1

    if args.json:
        output = {
            "account": {
                "id": account.id,
                "email": account.email,
                "name": account.name,
                "plan": account.plan,
            },
            "billing_period": {
                "start": usage.period_start.isoformat(),
                "end": usage.period_end.isoformat(),
            },
            "usage": {
                "total_gb": usage.total_gb,
                "cost": usage.cost,
            },
            "token_prefix": get_token_prefix(token),
        }
        print(json.dumps(output, indent=2))
        return 0

    # Display formatted output
    terminal.header("Account")
    terminal.info(f"Email: {account.email}")
    if account.name:
        terminal.info(f"Name: {account.name}")
    terminal.info(f"Plan: {account.plan.title()}")
    terminal.info("")

    terminal.header("Billing Period")
    terminal.info(f"{usage.period_start.strftime('%b %d, %Y')} - {usage.period_end.strftime('%b %d, %Y')}")
    terminal.info("")

    terminal.header("Current Usage")
    terminal.info(f"Data Processed: {usage.total_gb:.2f} GB")
    terminal.info(f"Cost to Date: ${usage.cost:.2f}")
    terminal.info("")

    terminal.header("API Token")
    terminal.info(get_token_prefix(token))

    if is_test_token(token):
        terminal.warning("")
        terminal.warning("Using test token - usage not billed")

    return 0
