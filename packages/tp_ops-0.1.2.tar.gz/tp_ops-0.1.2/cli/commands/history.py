"""History command - view investigation history for a resource."""

import argparse
from datetime import datetime

from cli.output.terminal import Terminal
from cli.auth.credentials import get_agent, load_history


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the history command."""
    agent = get_agent(args.resource)

    if not agent:
        terminal.error(f"No agent found for resource '{args.resource}'")
        return 1

    history = load_history(args.resource)

    if not history:
        terminal.info(f"No investigation history for '{args.resource}'")
        terminal.info(f"Run an investigation: tp-ops run {args.resource} \"<problem>\"")
        return 0

    terminal.header(f"Investigation History: {args.resource}")

    # Show most recent first, limited
    recent = list(reversed(history[-args.limit:]))

    for i, inv in enumerate(recent, 1):
        timestamp = inv.get("timestamp", "")
        if timestamp:
            try:
                dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                timestamp = dt.strftime("%Y-%m-%d %H:%M UTC")
            except ValueError:
                pass

        terminal.print(f"{i}. [{inv.get('id', 'unknown')}] {timestamp}")
        terminal.print(f"   Problem: {inv.get('problem', 'N/A')}")

        if inv.get("root_cause"):
            terminal.print(f"   Root cause: {inv.get('root_cause')}")

        gb = inv.get("gb_processed", 0)
        cost = inv.get("cost", 0)
        terminal.print(f"   Processed: {gb:.2f} GB | Cost: ${cost:.2f}")
        terminal.print()

    terminal.info(f"Showing {len(recent)} of {len(history)} investigations")

    return 0
