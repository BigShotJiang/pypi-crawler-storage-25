"""tp-ops usage command - show detailed usage breakdown."""

import argparse
import json

from cli.output.terminal import Terminal
from cli.auth.token import get_token


def add_parser(subparsers) -> None:
    """Add the usage command parser."""
    parser = subparsers.add_parser(
        "usage",
        help="Show detailed usage breakdown",
        description="Display usage breakdown by resource and agent type.",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=30,
        help="Number of days to show (default: 30)",
    )
    parser.add_argument(
        "--by-resource",
        action="store_true",
        help="Show breakdown by resource",
    )
    parser.add_argument(
        "--by-agent",
        action="store_true",
        help="Show breakdown by agent type",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output as JSON",
    )
    parser.set_defaults(func=execute)


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the usage command."""
    token = get_token()

    if not token:
        terminal.error("Not logged in.")
        terminal.info("")
        terminal.info("Run 'tp-ops login --token <your-token>' to authenticate.")
        return 1

    try:
        from cli.api.client import TPOpsAPIClient, APIError

        with TPOpsAPIClient(token=token) as client:
            usage = client.get_current_usage()

    except ImportError:
        terminal.error("httpx not installed.")
        terminal.info("Install with: pip install httpx")
        return 1

    except APIError as e:
        terminal.error(f"API Error: {e.message}")
        return 1

    except Exception as e:
        terminal.error(f"Connection error: {e}")
        return 1

    # Default to showing both breakdowns if neither specified
    show_resource = args.by_resource or (not args.by_resource and not args.by_agent)
    show_agent = args.by_agent or (not args.by_resource and not args.by_agent)

    if args.json:
        output = {
            "period": {
                "start": usage.period_start.isoformat(),
                "end": usage.period_end.isoformat(),
            },
            "total": {
                "bytes": usage.total_bytes,
                "gb": usage.total_gb,
                "cost": usage.cost,
            },
        }
        if show_resource:
            output["by_resource"] = [
                {"name": r.name, "gb": r.gb_processed, "cost": r.cost, "count": r.count}
                for r in usage.by_resource
            ]
        if show_agent:
            output["by_agent_type"] = [
                {"name": r.name, "gb": r.gb_processed, "cost": r.cost, "count": r.count}
                for r in usage.by_agent_type
            ]
        print(json.dumps(output, indent=2))
        return 0

    # Header
    terminal.header(f"Usage (last {args.days} days)")
    terminal.info(f"Period: {usage.period_start.strftime('%b %d')} - {usage.period_end.strftime('%b %d, %Y')}")
    terminal.info("")

    # Summary
    terminal.info(f"Total: {usage.total_gb:.2f} GB | ${usage.cost:.2f}")
    terminal.info("")

    # By Resource
    if show_resource and usage.by_resource:
        terminal.header("By Resource")
        _print_breakdown_table(terminal, usage.by_resource)
        terminal.info("")

    # By Agent Type
    if show_agent and usage.by_agent_type:
        terminal.header("By Agent Type")
        _print_breakdown_table(terminal, usage.by_agent_type)
        terminal.info("")

    if not usage.by_resource and not usage.by_agent_type:
        terminal.info("No usage recorded in this period.")

    return 0


def _print_breakdown_table(terminal: Terminal, breakdown: list) -> None:
    """Print a formatted breakdown table."""
    if not breakdown:
        terminal.info("  No data")
        return

    # Calculate column widths
    name_width = max(len(r.name) for r in breakdown)
    name_width = max(name_width, 8)  # Minimum width

    # Header
    terminal.info(
        f"  {'NAME':<{name_width}}  {'GB':>10}  {'COST':>10}  {'OPS':>6}"
    )
    terminal.info(
        f"  {'-' * name_width}  {'-' * 10}  {'-' * 10}  {'-' * 6}"
    )

    # Rows
    for r in breakdown:
        terminal.info(
            f"  {r.name:<{name_width}}  {r.gb_processed:>10.2f}  ${r.cost:>9.2f}  {r.count:>6}"
        )
