"""Drop command - drop an agent onto THIS resource.

Run this ON the resource itself. The agent auto-detects what it's monitoring.

Usage:
    ssh my-server
    pip install tp-ops
    tp-ops drop

That's it. The agent figures out the rest.
"""

import argparse
import os
import sys
import socket
import subprocess
from datetime import datetime
from pathlib import Path

from cli.output.terminal import Terminal
from cli.auth.credentials import load_agents, save_agents
from cli.banner import print_banner
from engine.llm.models import ensure_model
from mesh.tnn.network_check import (
    check_network_requirements,
    display_network_check,
    show_relay_instructions,
    show_port_opening_instructions,
    NetworkCheckResult,
)


# Agent types and their descriptions
AGENT_TYPES = {
    "k8s-agent": {
        "name": "Kubernetes Agent",
        "description": "Investigates pod failures, deployment issues, resource contention",
        "auto_detect": True,
    },
    "vm-agent": {
        "name": "VM Agent",
        "description": "Investigates CPU, memory, disk, and process issues",
        "auto_detect": True,
    },
    "postgres-agent": {
        "name": "PostgreSQL Agent",
        "description": "Investigates queries, connections, replication, and indexes",
        "auto_detect": True,
    },
    "mysql-agent": {
        "name": "MySQL Agent",
        "description": "Investigates queries, connections, replication, and indexes",
        "auto_detect": True,
    },
    "mongodb-agent": {
        "name": "MongoDB Agent",
        "description": "Investigates queries, indexes, replication, and sharding",
        "auto_detect": True,
    },
    "redis-agent": {
        "name": "Redis Agent",
        "description": "Investigates memory, keys, slow commands, and cluster health",
        "auto_detect": True,
    },
    "apigw-agent": {
        "name": "API Gateway Agent",
        "description": "Investigates latency, errors, and endpoint health",
        "auto_detect": False,
        "requires": ["--apim"],
    },
    "azure-agent": {
        "name": "Azure Monitor Agent",
        "description": "Investigates App Insights, Log Analytics, and Azure health",
        "auto_detect": False,
        "requires": ["--subscription"],
    },
    "security-agent": {
        "name": "Security Agent",
        "description": "Audits RBAC, secrets, CVEs, and TLS configuration",
        "auto_detect": False,
    },
    "relay-agent": {
        "name": "Relay Agent",
        "description": "Routes mesh traffic between agents that can't reach each other directly",
        "auto_detect": False,
    },
}


def detect_resource_type() -> tuple[str, dict]:
    """Auto-detect what type of resource we're running on.

    Returns:
        Tuple of (agent_type, config_dict)
    """
    # Check for Kubernetes (highest priority - if we're in a cluster)
    if _is_kubernetes():
        return "k8s-agent", _get_k8s_config()

    # Check for databases (check processes and ports)
    if _is_postgres():
        return "postgres-agent", _get_postgres_config()

    if _is_redis():
        return "redis-agent", _get_redis_config()

    if _is_mongodb():
        return "mongodb-agent", _get_mongodb_config()

    if _is_mysql():
        return "mysql-agent", _get_mysql_config()

    # Default to VM/Linux agent
    return "vm-agent", _get_vm_config()


def _is_kubernetes() -> bool:
    """Check if we're running in/with a Kubernetes cluster."""
    # In-cluster: service account exists
    if Path("/var/run/secrets/kubernetes.io/serviceaccount/token").exists():
        return True
    # In-cluster: env var set
    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        return True
    # Has kubectl configured
    try:
        result = subprocess.run(
            ["kubectl", "cluster-info"],
            capture_output=True,
            timeout=5
        )
        return result.returncode == 0
    except:
        pass
    return False


def _get_k8s_config() -> dict:
    """Get Kubernetes configuration."""
    config = {}
    try:
        result = subprocess.run(
            ["kubectl", "config", "current-context"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            config["context"] = result.stdout.strip()
    except:
        pass
    return config


def _is_postgres() -> bool:
    """Check if PostgreSQL is running locally."""
    try:
        result = subprocess.run(["pgrep", "-x", "postgres"], capture_output=True, timeout=5)
        if result.returncode == 0:
            return True
    except:
        pass
    return _port_listening(5432)


def _get_postgres_config() -> dict:
    return {"host": "localhost", "port": 5432}


def _is_redis() -> bool:
    """Check if Redis is running locally."""
    try:
        result = subprocess.run(["pgrep", "-x", "redis-server"], capture_output=True, timeout=5)
        if result.returncode == 0:
            return True
    except:
        pass
    return _port_listening(6379)


def _get_redis_config() -> dict:
    return {"host": "localhost", "port": 6379}


def _is_mongodb() -> bool:
    """Check if MongoDB is running locally."""
    try:
        result = subprocess.run(["pgrep", "-x", "mongod"], capture_output=True, timeout=5)
        if result.returncode == 0:
            return True
    except:
        pass
    return _port_listening(27017)


def _get_mongodb_config() -> dict:
    return {"host": "localhost", "port": 27017}


def _is_mysql() -> bool:
    """Check if MySQL is running locally."""
    try:
        result = subprocess.run(["pgrep", "-x", "mysqld"], capture_output=True, timeout=5)
        if result.returncode == 0:
            return True
    except:
        pass
    return _port_listening(3306)


def _get_mysql_config() -> dict:
    return {"host": "localhost", "port": 3306}


def _get_vm_config() -> dict:
    """Get VM/Linux configuration."""
    return {"hostname": socket.gethostname()}


def _port_listening(port: int) -> bool:
    """Check if a port is listening locally."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            return s.connect_ex(("127.0.0.1", port)) == 0
    except:
        return False


# =============================================================================
# Service Verification Functions
# =============================================================================

def verify_service(agent_type: str, config: dict, terminal: Terminal) -> bool:
    """Verify the local service is accessible."""
    if agent_type == "k8s-agent":
        return _verify_k8s(config, terminal)
    elif agent_type == "postgres-agent":
        return _verify_postgres(config, terminal)
    elif agent_type == "mysql-agent":
        return _verify_mysql(config, terminal)
    elif agent_type == "mongodb-agent":
        return _verify_mongodb(config, terminal)
    elif agent_type == "redis-agent":
        return _verify_redis(config, terminal)
    elif agent_type == "apigw-agent":
        return _verify_apigw(config, terminal)
    elif agent_type == "azure-agent":
        return _verify_azure(config, terminal)
    elif agent_type in ("vm-agent", "security-agent", "relay-agent"):
        # These don't need specific service verification
        return True
    return True


def _verify_k8s(config: dict, terminal: Terminal) -> bool:
    """Verify Kubernetes cluster is accessible."""
    terminal.spinner_start("Verifying Kubernetes connection...")
    try:
        cmd = ["kubectl", "cluster-info"]
        if config.get("context"):
            cmd.extend(["--context", config["context"]])

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

        if result.returncode == 0:
            terminal.spinner_stop(True)
            return True
        else:
            terminal.spinner_stop(False)
            terminal.warning(f"kubectl error: {result.stderr.strip()}")
            return False
    except FileNotFoundError:
        terminal.spinner_stop(False)
        terminal.warning("kubectl not found")
        return False
    except subprocess.TimeoutExpired:
        terminal.spinner_stop(False)
        terminal.warning("kubectl timed out")
        return False
    except Exception as e:
        terminal.spinner_stop(False)
        terminal.warning(f"Verification failed: {e}")
        return False


def _verify_postgres(config: dict, terminal: Terminal) -> bool:
    """Verify PostgreSQL is accessible."""
    terminal.spinner_start("Verifying PostgreSQL connection...")
    try:
        host = config.get("host", "localhost")
        port = config.get("port", 5432)

        result = subprocess.run(
            ["psql", "-h", host, "-p", str(port), "-c", "SELECT 1", "-t"],
            capture_output=True, text=True, timeout=15,
            env={**os.environ, "PGCONNECT_TIMEOUT": "10"}
        )

        if result.returncode == 0:
            terminal.spinner_stop(True)
            return True
        else:
            terminal.spinner_stop(False)
            terminal.warning("PostgreSQL connection could not be verified")
            terminal.info("Ensure database credentials are configured")
            return True  # Continue anyway
    except FileNotFoundError:
        terminal.spinner_stop(False)
        terminal.warning("psql not found - connection not verified")
        return True
    except Exception as e:
        terminal.spinner_stop(False)
        terminal.warning(f"Verification skipped: {e}")
        return True


def _verify_mysql(config: dict, terminal: Terminal) -> bool:
    """Verify MySQL is accessible."""
    terminal.spinner_start("Verifying MySQL connection...")
    try:
        host = config.get("host", "localhost")
        port = config.get("port", 3306)

        result = subprocess.run(
            ["mysql", "-h", host, "-P", str(port), "-e", "SELECT 1"],
            capture_output=True, text=True, timeout=15
        )

        if result.returncode == 0:
            terminal.spinner_stop(True)
            return True
        else:
            terminal.spinner_stop(False)
            terminal.warning("MySQL connection could not be verified")
            return True
    except FileNotFoundError:
        terminal.spinner_stop(False)
        terminal.warning("mysql client not found - connection not verified")
        return True
    except Exception as e:
        terminal.spinner_stop(False)
        terminal.warning(f"Verification skipped: {e}")
        return True


def _verify_mongodb(config: dict, terminal: Terminal) -> bool:
    """Verify MongoDB is accessible."""
    terminal.spinner_start("Verifying MongoDB connection...")
    try:
        host = config.get("host", "localhost")
        port = config.get("port", 27017)

        result = subprocess.run(
            ["mongosh", "--host", host, "--port", str(port), "--eval", "db.runCommand({ping:1})", "--quiet"],
            capture_output=True, text=True, timeout=15
        )

        if result.returncode == 0:
            terminal.spinner_stop(True)
            return True
        else:
            terminal.spinner_stop(False)
            terminal.warning("MongoDB connection could not be verified")
            return True
    except FileNotFoundError:
        terminal.spinner_stop(False)
        terminal.warning("mongosh not found - connection not verified")
        return True
    except Exception as e:
        terminal.spinner_stop(False)
        terminal.warning(f"Verification skipped: {e}")
        return True


def _verify_redis(config: dict, terminal: Terminal) -> bool:
    """Verify Redis is accessible."""
    terminal.spinner_start("Verifying Redis connection...")
    try:
        host = config.get("host", "localhost")
        port = config.get("port", 6379)

        result = subprocess.run(
            ["redis-cli", "-h", host, "-p", str(port), "PING"],
            capture_output=True, text=True, timeout=10
        )

        if result.returncode == 0 and "PONG" in result.stdout:
            terminal.spinner_stop(True)
            return True
        else:
            terminal.spinner_stop(False)
            terminal.warning("Redis connection could not be verified")
            return True
    except FileNotFoundError:
        terminal.spinner_stop(False)
        terminal.warning("redis-cli not found - connection not verified")
        return True
    except Exception as e:
        terminal.spinner_stop(False)
        terminal.warning(f"Verification skipped: {e}")
        return True


def _verify_apigw(config: dict, terminal: Terminal) -> bool:
    """Verify Azure API Management is accessible."""
    apim = config.get("apim")
    if not apim:
        terminal.error("--apim is required for apigw-agent")
        return False

    terminal.spinner_start(f"Verifying APIM connection to {apim}...")
    try:
        result = subprocess.run(
            ["az", "apim", "show", "--name", apim, "-o", "json"],
            capture_output=True, text=True, timeout=30
        )

        if result.returncode == 0:
            terminal.spinner_stop(True)
            return True
        else:
            terminal.spinner_stop(False)
            terminal.error(f"APIM verification failed: {result.stderr.strip()}")
            terminal.info("Ensure you are logged in with 'az login'")
            return False
    except FileNotFoundError:
        terminal.spinner_stop(False)
        terminal.error("Azure CLI not found. Please install 'az' CLI.")
        return False
    except Exception as e:
        terminal.spinner_stop(False)
        terminal.error(f"Verification failed: {e}")
        return False


def _verify_azure(config: dict, terminal: Terminal) -> bool:
    """Verify Azure subscription is accessible."""
    subscription = config.get("subscription")
    if not subscription:
        terminal.error("--subscription is required for azure-agent")
        return False

    terminal.spinner_start(f"Verifying Azure subscription {subscription}...")
    try:
        result = subprocess.run(
            ["az", "account", "show", "--subscription", subscription, "-o", "json"],
            capture_output=True, text=True, timeout=30
        )

        if result.returncode == 0:
            terminal.spinner_stop(True)
            return True
        else:
            terminal.spinner_stop(False)
            terminal.error(f"Azure verification failed: {result.stderr.strip()}")
            terminal.info("Ensure you are logged in with 'az login'")
            return False
    except FileNotFoundError:
        terminal.spinner_stop(False)
        terminal.error("Azure CLI not found. Please install 'az' CLI.")
        return False
    except Exception as e:
        terminal.spinner_stop(False)
        terminal.error(f"Verification failed: {e}")
        return False


def get_resource_name() -> str:
    """Get a name for this resource."""
    # In K8s, use pod name
    pod_name = os.environ.get("POD_NAME") or os.environ.get("HOSTNAME")
    if pod_name:
        return pod_name

    return socket.gethostname()


def start_agent_daemon(agent_type: str, resource_name: str, config: dict, terminal: Terminal) -> bool:
    """Start the agent daemon on this machine."""
    mesh_port = config.get("mesh_port", 7100)
    api_port = config.get("api_port", 8080)

    # Check if already running
    if _port_listening(api_port):
        terminal.warning(f"Agent already running on port {api_port}")
        return True

    terminal.spinner_start("Starting agent daemon...")

    try:
        # Build command
        cmd = [
            sys.executable, "-m", "agent_server.daemon",
            "--agent-type", agent_type,
            "--resource-name", resource_name,
            "--mesh-port", str(mesh_port),
            "--port", str(api_port),
        ]

        # Create log directory
        log_dir = Path.home() / ".local" / "share" / "tp-ops" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / f"{resource_name}.log"

        # Start detached process
        with open(log_file, "a") as f:
            process = subprocess.Popen(
                cmd,
                stdout=f,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )

        # Wait and verify
        import time
        time.sleep(2)

        if process.poll() is not None:
            terminal.spinner_stop(False)
            terminal.error(f"Agent failed to start. Check logs: {log_file}")
            return False

        # Wait for port to be ready
        for _ in range(15):
            if _port_listening(api_port):
                terminal.spinner_stop(True)
                return True
            time.sleep(0.5)

        terminal.spinner_stop(False)
        terminal.warning("Agent started but not responding yet")
        terminal.info(f"Check logs: {log_file}")
        return True

    except Exception as e:
        terminal.spinner_stop(False)
        terminal.error(f"Failed to start agent: {e}")
        return False


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the drop command.

    Auto-detects resource type and starts the agent daemon locally.
    """
    print_banner()
    terminal.header("Dropping agent")

    # Check for manual type override (e.g., relay-agent, apigw-agent, azure-agent)
    manual_type = getattr(args, 'type', None)

    if manual_type:
        if manual_type not in AGENT_TYPES:
            terminal.error(f"Unknown agent type: {manual_type}")
            terminal.info(f"Available types: {', '.join(AGENT_TYPES.keys())}")
            return 1
        agent_type = manual_type
        config = {}

        # Handle type-specific args
        if agent_type == "apigw-agent":
            apim = getattr(args, 'apim', None)
            if not apim:
                terminal.error("--apim is required for apigw-agent")
                return 1
            config["apim"] = apim
        elif agent_type == "azure-agent":
            subscription = getattr(args, 'subscription', None)
            if not subscription:
                terminal.error("--subscription is required for azure-agent")
                return 1
            config["subscription"] = subscription

        terminal.info(f"Using specified type: {agent_type}")
    else:
        # Auto-detect resource type
        terminal.spinner_start("Detecting resource type...")
        agent_type, config = detect_resource_type()
        terminal.spinner_stop(True)

    # Apply any command-line overrides to config
    if getattr(args, 'host', None):
        config["host"] = args.host
    if getattr(args, 'kubeconfig', None):
        config["kubeconfig"] = args.kubeconfig
    if getattr(args, 'context', None):
        config["context"] = args.context

    # Get resource name (can be overridden with --name)
    resource_name = getattr(args, 'name', None) or get_resource_name()

    agent_info = AGENT_TYPES[agent_type]
    terminal.info(f"Agent: {agent_info['name']}")
    terminal.info(f"Resource: {resource_name}")
    terminal.print()

    # Verify the service is accessible (unless --skip-verify)
    if not getattr(args, 'skip_verify', False):
        if not verify_service(agent_type, config, terminal):
            return 1
        terminal.print()

    # Ensure model is downloaded (4.4GB, one-time download)
    if not ensure_model(terminal):
        terminal.error("Cannot start agent without model")
        return 1

    # Check if already registered
    agents = load_agents()
    if resource_name in agents:
        terminal.warning(f"Agent '{resource_name}' already exists")
        terminal.info("Use 'tp-ops remove' to remove it first, or 'tp-ops status' to check it")
        # Still try to start daemon in case it's not running
        if not _port_listening(8080):
            terminal.info("Agent daemon not running, starting it...")
            start_agent_daemon(agent_type, resource_name, config, terminal)
        return 0

    # Add mesh config
    config["mesh_port"] = 7100
    config["api_port"] = 8080

    # Start the agent daemon
    if not start_agent_daemon(agent_type, resource_name, config, terminal):
        return 1

    # Check network requirements for mesh
    terminal.print()
    reqs = check_network_requirements(agent_type, resource_name)
    result = display_network_check(reqs, terminal)

    mesh_enabled = True
    if result == NetworkCheckResult.PROCEED_FULL_MESH:
        mesh_enabled = True
    elif result == NetworkCheckResult.OPEN_PORTS:
        show_port_opening_instructions(reqs, terminal)
        mesh_enabled = True  # They said they'll open ports
    elif result == NetworkCheckResult.DROP_RELAY:
        show_relay_instructions(terminal)
        mesh_enabled = True  # They'll add relay later
    elif result == NetworkCheckResult.CONTINUE_STANDALONE:
        terminal.warning("Agent will work independently without mesh")
        mesh_enabled = False

    # Save agent record
    agent_record = {
        "type": agent_type,
        "name": resource_name,
        "created_at": datetime.utcnow().isoformat() + "Z",
        "config": config,
        "endpoint": f"http://localhost:8080",
        "status": "active",
        "mesh_enabled": mesh_enabled,
        "investigations": [],
        "total_gb_processed": 0.0,
        "total_cost": 0.0,
    }
    agents[resource_name] = agent_record
    save_agents(agents)

    # Success output
    terminal.print()
    terminal.success(f"Agent dropped on {resource_name}")
    terminal.print()
    terminal.info("Agent is now:")
    terminal.print("  • Running as a daemon on this machine")
    terminal.print("  • Listening for mesh connections on port 7100")
    terminal.print("  • API available on port 8080")
    terminal.print()
    terminal.info("The agent will automatically:")
    terminal.print("  • Discover and join the mesh network")
    terminal.print("  • Monitor this resource continuously")
    terminal.print("  • Share knowledge with other agents")
    terminal.print()
    terminal.info("From any machine that can reach this one:")
    terminal.print(f"  tp-ops ask {resource_name} \"what's wrong?\"")

    # Check if logged in, prompt signup if not
    from cli.auth.token import get_token
    if not get_token():
        terminal.print()
        terminal.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        terminal.info("Free tier: 1 GB included. $0.50/GB after.")
        terminal.info("")
        terminal.info("Sign up to track usage and add payment method:")
        terminal.print("  https://ternaryphysics.com/signup")
        terminal.info("")
        terminal.info("Then run:")
        terminal.print("  tp-ops login --token <your-api-key>")
        terminal.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

    return 0
