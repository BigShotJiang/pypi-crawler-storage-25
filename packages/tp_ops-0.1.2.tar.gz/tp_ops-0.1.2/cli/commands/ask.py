"""Ask command - interactive conversation with an agent."""

import argparse
import sys
from datetime import datetime

from cli.output.terminal import Terminal
from cli.auth.credentials import get_agent, load_agents
from cli.api.usage_reporter import report_usage_async, check_and_show_signup_prompt


def format_uptime(created_at: str) -> str:
    """Format how long the agent has been active."""
    try:
        # Parse ISO format timestamp
        created = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
        now = datetime.now(created.tzinfo)
        delta = now - created
        days = delta.days
        if days == 0:
            hours = delta.seconds // 3600
            if hours == 0:
                minutes = delta.seconds // 60
                return f"{minutes} minutes" if minutes > 1 else "less than a minute"
            return f"{hours} hours" if hours > 1 else "1 hour"
        elif days == 1:
            return "1 day"
        else:
            return f"{days} days"
    except Exception:
        return "recently"


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the ask command - start interactive conversation."""
    agent_config = get_agent(args.resource)

    if not agent_config:
        terminal.error(f"No agent found for resource '{args.resource}'")
        terminal.info("Drop an agent first: ssh <host> && pip install tp-ops && tp-ops drop")
        return 1

    agent_type = agent_config.get("type")
    endpoint = agent_config.get("endpoint")

    # Check if this is a deployed agent or legacy local agent
    if endpoint:
        return _execute_remote(args, terminal, agent_config, endpoint)
    else:
        return _execute_local(args, terminal, agent_config)


def _execute_remote(args: argparse.Namespace, terminal: Terminal, agent_config: dict, endpoint: str) -> int:
    """Execute ask command against a deployed remote agent."""
    from cli.remote.client import AgentClient, AgentClientError

    agent_type = agent_config.get("type")
    resource = args.resource

    # Create client
    client = AgentClient(endpoint)

    # Check agent health
    terminal.info(f"Connecting to agent at {endpoint}...")
    try:
        health = client.health()
        if not health.healthy:
            terminal.warning(f"Agent health check failed: {health.message}")
    except AgentClientError as e:
        terminal.error(f"Cannot connect to agent: {e}")
        terminal.info("The agent may be restarting. Try again in a moment.")
        return 1

    # Get agent status
    try:
        status = client.status()
        model_name = status.model_name or "TernaryPhysics-7B"
        mesh_peers = status.mesh_peers
    except AgentClientError:
        model_name = "TernaryPhysics-7B"
        mesh_peers = 0

    # Print connection header
    terminal.print()
    uptime = format_uptime(agent_config.get("created_at", ""))

    mesh_status = f"{mesh_peers} agents in mesh" if mesh_peers > 0 else "no mesh peers"
    terminal.print(f"  \033[1;33m⚡\033[0m Connected to {agent_type} on \033[1m{resource}\033[0m ({mesh_status})")
    terminal.print(f"  Agent has been on this resource for {uptime}.")

    if agent_type == "k8s-agent":
        terminal.print("  TNN anomaly detector: \033[32m●\033[0m active (no anomalies)")

    terminal.print()
    terminal.print(f"  Powered by \033[1m{model_name}\033[0m — running on the resource")
    terminal.print("  Type 'exit' to leave. Type 'cost' for session stats. Type 'mesh' for peers.")
    terminal.print()

    # Track session stats
    questions_asked = 0
    bytes_processed = 0
    session_start = datetime.now()

    # Interactive conversation loop
    while True:
        try:
            # Get user input with resource-name prompt
            user_input = input(f"  \033[1m{resource}\033[0m > ").strip()

            if not user_input:
                continue

            if user_input.lower() in ("exit", "quit", "q"):
                break

            if user_input.lower() == "cost":
                _show_session_stats_remote(terminal, bytes_processed, questions_asked, session_start)
                continue

            if user_input.lower() == "mesh":
                _show_mesh_peers_remote(terminal, client)
                continue

            if user_input.lower() == "status":
                _show_agent_status(terminal, client)
                continue

            # Send message to remote agent
            questions_asked += 1
            try:
                response = client.chat(user_input)
                reply = response.response

                # Print response with formatting
                terminal.print()
                for line in reply.split('\n'):
                    terminal.print(f"  {line}")
                terminal.print()

                # Show pending actions if any
                if response.pending_actions:
                    terminal.warning(f"  {len(response.pending_actions)} action(s) pending approval")
                    for action_id in response.pending_actions:
                        terminal.print(f"    - {action_id}")
                    terminal.print()

                # Estimate bytes processed (actual tracking is on the agent)
                bytes_processed += len(user_input.encode()) + len(reply.encode())

                # Show cost estimate
                gb = bytes_processed / (1024 * 1024 * 1024)
                cost = gb * 0.50
                terminal.print(f"  \033[2mProcessed: {gb:.4f} GB | Running cost: ${cost:.4f}\033[0m")
                terminal.print()

            except AgentClientError as e:
                terminal.error(f"  Communication error: {e}")
                terminal.info("  Try again or check agent status with 'status'")
                terminal.print()

        except KeyboardInterrupt:
            terminal.print()
            break
        except EOFError:
            break

    # Show exit summary
    _show_exit_summary_remote(terminal, resource, questions_asked, bytes_processed, session_start)

    # Report usage to backend for billing
    duration = (datetime.now() - session_start).total_seconds()
    report_usage_async(
        resource_name=resource,
        agent_type=agent_type,
        command="ask",
        bytes_processed=bytes_processed,
        duration_seconds=duration,
    )

    # Check if user has exceeded free tier and prompt signup
    check_and_show_signup_prompt(terminal)

    return 0


def _execute_local(args: argparse.Namespace, terminal: Terminal, agent_config: dict) -> int:
    """Execute ask command with local agent (legacy mode)."""
    from engine.knowledge import KnowledgeStore, Investigation, OutcomeType

    agent_type = agent_config.get("type")

    # Get the appropriate conversational agent
    if agent_type == "k8s-agent":
        from agents.kubernetes.chat_agent import KubernetesChatAgent
        agent_class = KubernetesChatAgent
    elif agent_type == "vm-agent":
        from agents.compute.linux_vm import LinuxVMAgent
        agent_class = LinuxVMAgent
    elif agent_type == "postgres-agent":
        from agents.databases.postgresql import PostgreSQLAgent
        agent_class = PostgreSQLAgent
    elif agent_type == "redis-agent":
        from agents.databases.redis import RedisAgent
        agent_class = RedisAgent
    else:
        terminal.error(f"Chat not supported for agent type: {agent_type}")
        return 1

    terminal.warning("Running in local mode (agent not deployed to resource)")
    terminal.info("Consider re-deploying with 'tp-ops drop' for full functionality")
    terminal.print()

    # Try to load the LLM
    llm = None
    model_name = None
    if not args.mock:
        try:
            from engine.llm.inference import TernaryLLM
            llm = TernaryLLM()
            model_name = llm.model_path.split("/")[-1].replace(".gguf", "")
        except ImportError as e:
            terminal.warning(f"llama-cpp-python not installed: {e}")
            terminal.info("Using mock responses for demonstration")
        except FileNotFoundError as e:
            terminal.warning(f"Model not found: {e}")
            terminal.info("Using mock responses for demonstration")

    # Create the agent
    base_agent = agent_class(
        name=args.resource,
        config=agent_config.get("config", {}),
        terminal=terminal,
        llm=llm,
    )

    # Wrap with mesh capabilities
    from mesh import MeshAgentWrapper
    mesh_port = agent_config.get("config", {}).get("mesh_port", 7100)
    agent = MeshAgentWrapper(base_agent, agent_type=agent_type, port=mesh_port)

    # Add other agents as mesh peers
    all_agents = load_agents()
    peer_count = 0
    for peer_name, peer_config in all_agents.items():
        if peer_name != args.resource:
            peer_host = peer_config.get("config", {}).get("host", "localhost")
            peer_port = peer_config.get("config", {}).get("mesh_port", 7100)
            peer_type = peer_config.get("type", "unknown")
            agent.add_peer(peer_name, peer_type, peer_host, peer_port)
            peer_count += 1

    # Start the mesh
    agent.start()

    # Initialize knowledge store
    knowledge_store = KnowledgeStore()
    investigation = Investigation(
        resource_name=args.resource,
        agent_type=agent_type,
        problem="",
    )
    investigation_id = knowledge_store.save_investigation(investigation)
    investigation.id = investigation_id
    base_agent.set_knowledge_tracking(knowledge_store, investigation)

    # Print connection header
    terminal.print()
    uptime = format_uptime(agent_config.get("created_at", ""))

    mesh_status = f"{peer_count} agents in mesh" if peer_count > 0 else "no mesh peers"
    mode_str = "mock mode, " if not llm else ""
    terminal.print(f"  \033[1;33m⚡\033[0m Connected to {agent_type} on \033[1m{args.resource}\033[0m ({mode_str}{mesh_status})")
    terminal.print(f"  Agent created {uptime} ago.")

    terminal.print()
    if llm:
        terminal.print(f"  Powered by \033[1m{model_name}\033[0m — running locally via llama.cpp")
    else:
        terminal.print("  Running in mock mode — no LLM loaded")
    terminal.print("  Type 'exit' to leave. Type 'cost' for session stats. Type 'mesh' for peers.")
    terminal.print()

    # Track session stats
    questions_asked = 0
    actions_executed = 0
    session_start = datetime.now()

    # Interactive conversation loop
    while True:
        try:
            user_input = input(f"  \033[1m{args.resource}\033[0m > ").strip()

            if not user_input:
                continue

            if user_input.lower() in ("exit", "quit", "q"):
                break

            if user_input.lower() == "cost":
                _show_session_stats_local(terminal, agent, questions_asked, actions_executed, session_start)
                continue

            if user_input.lower() == "mesh":
                _show_mesh_peers_local(terminal, agent)
                continue

            # Set problem from first user message
            if not investigation.problem:
                investigation.problem = user_input
                investigation.extract_keywords()

                similar = knowledge_store.find_similar(user_input, agent_type=agent_type, limit=3)
                if similar:
                    terminal.print()
                    terminal.print("  \033[2mFound similar past investigations:\033[0m")
                    for inv in similar[:2]:
                        outcome_icon = "\033[32m✓\033[0m" if inv.outcome == OutcomeType.SUCCESS else "\033[33m?\033[0m"
                        terminal.print(f"    {outcome_icon} {inv.problem[:60]}...")
                    terminal.print()

            # Get agent response
            questions_asked += 1
            response = agent.chat(user_input)

            # Print response
            terminal.print()
            for line in response.split('\n'):
                terminal.print(f"  {line}")
            terminal.print()

            # Show cost
            gb = agent.bytes_processed / (1024 * 1024 * 1024)
            cost = agent.get_cost()
            terminal.print(f"  \033[2mProcessed: {gb:.2f} GB | Running cost: ${cost:.2f}\033[0m")
            terminal.print()

        except KeyboardInterrupt:
            terminal.print()
            break
        except EOFError:
            break

    # Cleanup
    agent.stop()

    investigation.ended_at = datetime.now()
    if questions_asked > 0:
        if agent.approved_actions:
            investigation.outcome = OutcomeType.SUCCESS
        elif questions_asked > 0:
            investigation.outcome = OutcomeType.PARTIAL
        knowledge_store.save_investigation(investigation)

    _show_exit_summary_local(terminal, agent, args.resource, questions_asked, actions_executed, session_start)

    # Report usage
    duration = (datetime.now() - session_start).total_seconds()
    report_usage_async(
        resource_name=args.resource,
        agent_type=agent_type,
        command="ask",
        bytes_processed=agent.bytes_processed,
        duration_seconds=duration,
    )

    # Check if user has exceeded free tier and prompt signup
    check_and_show_signup_prompt(terminal)

    return 0


# --- Helper functions for remote mode ---

def _show_mesh_peers_remote(terminal: Terminal, client) -> None:
    """Show mesh peers from remote agent."""
    from cli.remote.client import AgentClientError

    try:
        mesh_status = client.mesh_status()
        terminal.print()
        if not mesh_status.peers:
            terminal.print("  No mesh peers discovered yet.")
        else:
            terminal.print(f"  Mesh peers ({len(mesh_status.peers)}):")
            for peer in mesh_status.peers:
                status_icon = "\033[32m●\033[0m" if peer.status == "healthy" else "\033[31m●\033[0m"
                terminal.print(f"    {status_icon} {peer.name} ({peer.agent_type}) @ {peer.host}:{peer.port}")
        terminal.print()
    except AgentClientError as e:
        terminal.error(f"  Could not get mesh status: {e}")


def _show_session_stats_remote(terminal: Terminal, bytes_processed: int, questions: int, start: datetime) -> None:
    """Show session stats for remote mode."""
    gb = bytes_processed / (1024 * 1024 * 1024)
    cost = gb * 0.50
    duration = datetime.now() - start
    minutes = int(duration.total_seconds() / 60)

    terminal.print()
    terminal.print("  ┌─────────────────────────────────────────────┐")
    terminal.print(f"  │ Questions asked:    {questions:<22} │")
    terminal.print(f"  │ GB processed:       {gb:.4f} GB{' ' * (15 - len(f'{gb:.4f}'))}│")
    terminal.print(f"  │ Session cost:       ${cost:.4f}{' ' * (18 - len(f'{cost:.4f}'))}│")
    terminal.print(f"  │ Session duration:   {minutes} minute{'s' if minutes != 1 else ''}{' ' * (14 - len(str(minutes)))}│")
    terminal.print("  └─────────────────────────────────────────────┘")
    terminal.print()


def _show_agent_status(terminal: Terminal, client) -> None:
    """Show detailed agent status."""
    from cli.remote.client import AgentClientError

    try:
        status = client.status()
        terminal.print()
        terminal.print("  Agent Status:")
        terminal.print(f"    Type:           {status.agent_type}")
        terminal.print(f"    Resource:       {status.resource_name}")
        terminal.print(f"    Status:         {status.status.value}")
        terminal.print(f"    Uptime:         {int(status.uptime_seconds)}s")
        terminal.print(f"    Model loaded:   {'yes' if status.model_loaded else 'no'}")
        if status.model_name:
            terminal.print(f"    Model:          {status.model_name}")
        terminal.print(f"    Mesh enabled:   {'yes' if status.mesh_enabled else 'no'}")
        terminal.print(f"    Mesh peers:     {status.mesh_peers}")
        terminal.print(f"    Total requests: {status.total_requests}")
        terminal.print()
    except AgentClientError as e:
        terminal.error(f"  Could not get status: {e}")


def _show_exit_summary_remote(terminal: Terminal, resource: str, questions: int, bytes_processed: int, start: datetime) -> None:
    """Show session summary for remote mode."""
    gb = bytes_processed / (1024 * 1024 * 1024)
    cost = gb * 0.50
    duration = datetime.now() - start
    minutes = int(duration.total_seconds() / 60)

    terminal.print()
    terminal.print("  Session summary:")
    terminal.print(f"  • {questions} questions answered")
    terminal.print(f"  • {gb:.4f} GB processed")
    terminal.print(f"  • Cost: ${cost:.4f}")
    terminal.print()
    terminal.print(f"  Agent continues running on {resource}.")
    terminal.print("  TNN anomaly detector: \033[32m●\033[0m watching")
    terminal.print("  Mesh: \033[32m●\033[0m listening for cross-agent queries")
    terminal.print()
    terminal.print(f"  Run 'tp-ops ask {resource}' to reconnect anytime.")
    terminal.print()


# --- Helper functions for local mode ---

def _show_mesh_peers_local(terminal: Terminal, agent) -> None:
    """Show mesh peers for local agent."""
    peers = agent.get_peers()

    terminal.print()
    if not peers:
        terminal.print("  No mesh peers discovered yet.")
    else:
        terminal.print(f"  Mesh peers ({len(peers)}):")
        for peer in peers:
            status_icon = "\033[32m●\033[0m" if peer.is_healthy() else "\033[31m●\033[0m"
            terminal.print(f"    {status_icon} {peer.name} ({peer.agent_type}) @ {peer.address}")
    terminal.print()


def _show_session_stats_local(terminal: Terminal, agent, questions: int, actions: int, start: datetime) -> None:
    """Show session stats for local agent."""
    gb = agent.bytes_processed / (1024 * 1024 * 1024)
    cost = agent.get_cost()
    duration = datetime.now() - start
    minutes = int(duration.total_seconds() / 60)

    terminal.print()
    terminal.print("  ┌─────────────────────────────────────────────┐")
    terminal.print(f"  │ Questions asked:    {questions:<22} │")
    terminal.print(f"  │ GB processed:       {gb:.2f} GB{' ' * (18 - len(f'{gb:.2f}'))}│")
    terminal.print(f"  │ Session cost:       ${cost:.2f}{' ' * (19 - len(f'{cost:.2f}'))}│")
    terminal.print(f"  │ Session duration:   {minutes} minute{'s' if minutes != 1 else ''}{' ' * (14 - len(str(minutes)))}│")
    terminal.print("  └─────────────────────────────────────────────┘")
    terminal.print()


def _show_exit_summary_local(terminal: Terminal, agent, resource: str, questions: int, actions: int, start: datetime) -> None:
    """Show session summary for local agent."""
    gb = agent.bytes_processed / (1024 * 1024 * 1024)
    cost = agent.get_cost()
    duration = datetime.now() - start
    minutes = int(duration.total_seconds() / 60)

    terminal.print()
    terminal.print("  Session summary:")
    terminal.print(f"  • {questions} questions answered")
    terminal.print(f"  • {gb:.2f} GB processed")
    terminal.print(f"  • Cost: ${cost:.2f}")
    if actions > 0:
        terminal.print(f"  • {actions} actions approved and executed")
    terminal.print()
    terminal.print(f"  (Local mode - agent stopped when session ended)")
    terminal.print(f"  Consider deploying with 'tp-ops drop' for persistent monitoring.")
    terminal.print()
