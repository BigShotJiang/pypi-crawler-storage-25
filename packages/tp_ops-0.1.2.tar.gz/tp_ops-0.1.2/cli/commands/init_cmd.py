"""tp-ops init command - first-time setup wizard."""

import argparse

from cli.output.terminal import Terminal
from cli.auth.credentials import get_config_dir, get_data_dir
from cli.auth.token import store_token, get_token, validate_token_format


def add_parser(subparsers) -> None:
    """Add the init command parser."""
    parser = subparsers.add_parser(
        "init",
        help="Initialize tp-ops configuration",
        description="First-time setup wizard for tp-ops CLI.",
    )
    parser.add_argument(
        "--token",
        "-t",
        help="API token (can also be provided interactively)",
    )
    parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Overwrite existing configuration",
    )
    parser.set_defaults(func=execute)


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the init command."""
    terminal.info("Welcome to TernaryPhysics Ops!")
    terminal.info("")

    # Check if already initialized
    existing_token = get_token()
    if existing_token and not args.force:
        terminal.warning("tp-ops is already initialized.")
        terminal.info(f"Config directory: {get_config_dir()}")
        terminal.info("")
        terminal.info("Use --force to reinitialize, or run:")
        terminal.info("  tp-ops login --token <your-token>")
        return 0

    # Create directories
    terminal.info("Creating configuration directory...", end=" ")
    config_dir = get_config_dir()
    terminal.success("done")
    terminal.info(f"  {config_dir}")

    terminal.info("Creating data directory...", end=" ")
    data_dir = get_data_dir()
    terminal.success("done")
    terminal.info(f"  {data_dir}")
    terminal.info("")

    # Get token
    token = args.token
    if not token:
        terminal.info("To use tp-ops, you need an API token.")
        terminal.info("Get your token at: https://ternaryphysics.com/dashboard/tokens")
        terminal.info("")

        try:
            token = input("Enter your API token (or press Enter to skip): ").strip()
        except (KeyboardInterrupt, EOFError):
            terminal.info("")
            terminal.info("Setup incomplete. Run 'tp-ops login' when ready.")
            return 0

    if not token:
        terminal.info("")
        terminal.info("Setup complete (no token configured).")
        terminal.info("")
        terminal.info("To authenticate later, run:")
        terminal.info("  tp-ops login --token <your-token>")
        return 0

    # Validate token format
    if not validate_token_format(token):
        terminal.error("Invalid token format.")
        terminal.info("Token should start with 'tp_live_' or 'tp_test_'")
        return 1

    # Validate token with backend
    terminal.info("Validating token...", end=" ")
    try:
        from cli.api.client import TPOpsAPIClient, APIError

        with TPOpsAPIClient(token=token) as client:
            validation = client.validate_token(token)

        if not validation.valid:
            terminal.error("invalid")
            terminal.error(f"Error: {validation.error or 'Token not recognized'}")
            return 1

        terminal.success("done")

        # Store token
        store_token(token)

        # Show account info
        account = validation.account
        terminal.info("")
        terminal.success(f"Logged in as: {account.email}")
        terminal.info(f"Plan: {account.plan.title()}")
        terminal.info("")
        terminal.info("Setup complete! On your resource, run:")
        terminal.info("  pip install tp-ops && tp-ops drop")
        terminal.info("")
        terminal.info("Then from anywhere:")
        terminal.info("  tp-ops ask <resource-name>")

    except ImportError:
        # httpx not installed - store token anyway
        terminal.warning("skipped (httpx not installed)")
        store_token(token)
        terminal.info("")
        terminal.info("Token stored. Install httpx for API features:")
        terminal.info("  pip install httpx")

    except APIError as e:
        terminal.error("failed")
        terminal.error(f"API Error: {e.message}")
        return 1

    except Exception as e:
        terminal.warning("skipped (offline)")
        # Store token anyway - will validate on first API call
        store_token(token)
        terminal.info("")
        terminal.info("Token stored (offline mode).")
        terminal.info("Will validate on next API request.")

    return 0
