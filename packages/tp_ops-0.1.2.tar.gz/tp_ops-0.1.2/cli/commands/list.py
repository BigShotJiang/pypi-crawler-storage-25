"""List command - list all dropped agents."""

import argparse
import json
from datetime import datetime

from cli.output.terminal import Terminal
from cli.auth.credentials import load_agents


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the list command."""
    agents = load_agents()

    if not agents:
        terminal.info("No agents dropped yet.")
        terminal.print()
        terminal.info("Drop an agent on a resource:")
        terminal.print("  ssh <host> && pip install tp-ops && tp-ops drop")
        return 0

    if args.json:
        print(json.dumps(agents, indent=2))
        return 0

    terminal.header("Dropped Agents")

    headers = ["NAME", "TYPE", "STATUS", "GB PROCESSED", "COST", "CREATED"]
    rows = []

    for name, agent in agents.items():
        created = agent.get("created_at", "")
        if created:
            try:
                dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                created = dt.strftime("%Y-%m-%d %H:%M")
            except ValueError:
                pass

        rows.append([
            name,
            agent.get("type", "unknown"),
            agent.get("status", "unknown"),
            f"{agent.get('total_gb_processed', 0):.2f}",
            f"${agent.get('total_cost', 0):.2f}",
            created,
        ])

    terminal.table(headers, rows)
    terminal.print()
    terminal.info(f"Total agents: {len(agents)}")

    return 0
