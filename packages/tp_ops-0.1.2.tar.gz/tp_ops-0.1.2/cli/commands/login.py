"""tp-ops login command - authenticate with API token."""

import argparse

from cli.output.terminal import Terminal
from cli.auth.token import (
    store_token,
    get_token,
    validate_token_format,
    is_test_token,
    get_token_prefix,
)


def add_parser(subparsers) -> None:
    """Add the login command parser."""
    parser = subparsers.add_parser(
        "login",
        help="Authenticate with TernaryPhysics",
        description="Authenticate with your TernaryPhysics API token.",
    )
    parser.add_argument(
        "--token",
        "-t",
        required=True,
        help="API token from https://ternaryphysics.com/dashboard/tokens",
    )
    parser.set_defaults(func=execute)


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the login command."""
    token = args.token.strip()

    # Validate token format
    if not validate_token_format(token):
        terminal.error("Invalid token format.")
        terminal.info("Token should start with 'tp_live_' or 'tp_test_'")
        terminal.info("")
        terminal.info("Get your token at: https://ternaryphysics.com/dashboard/tokens")
        return 1

    # Check if already logged in with same token
    existing = get_token()
    if existing == token:
        terminal.info("Already logged in with this token.")
        return 0

    # Validate token with backend
    terminal.info("Validating token...", end=" ")

    try:
        from cli.api.client import TPOpsAPIClient, APIError

        with TPOpsAPIClient(token=token) as client:
            validation = client.validate_token(token)

        if not validation.valid:
            terminal.error("invalid")
            terminal.error(f"Error: {validation.error or 'Token not recognized'}")
            return 1

        terminal.success("done")

        # Store token
        store_token(token)

        # Show account info
        account = validation.account
        terminal.info("")
        terminal.success(f"Logged in as: {account.email}")
        terminal.info(f"Plan: {account.plan.title()}")
        terminal.info(f"Token: {get_token_prefix(token)}")

        if is_test_token(token):
            terminal.warning("")
            terminal.warning("Note: Using a test token. Usage will not be billed.")

        # Sync any offline usage
        from cli.api.offline_queue import get_pending_count, sync_queued_usage

        pending = get_pending_count()
        if pending > 0:
            terminal.info("")
            terminal.info(f"Syncing {pending} pending usage events...", end=" ")
            synced, failed = sync_queued_usage(client)
            if failed == 0:
                terminal.success(f"done ({synced} synced)")
            else:
                terminal.warning(f"partial ({synced} synced, {failed} pending)")

    except ImportError:
        terminal.warning("skipped (httpx not installed)")
        terminal.info("")
        terminal.info("Install httpx for API features:")
        terminal.info("  pip install httpx")
        terminal.info("")
        # Store token anyway
        store_token(token)
        terminal.info("Token stored locally.")

    except APIError as e:
        terminal.error("failed")
        terminal.error(f"API Error: {e.message}")
        return 1

    except Exception as e:
        terminal.warning("skipped (offline)")
        terminal.info("")
        # Store token anyway
        store_token(token)
        terminal.info("Token stored (offline mode).")
        terminal.info("Will validate on next API request.")

    return 0
