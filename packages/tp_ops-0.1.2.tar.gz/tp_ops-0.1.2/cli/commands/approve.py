"""Approve/Reject commands - handle recommended actions."""

import argparse
import subprocess

from cli.output.terminal import Terminal
from cli.auth.credentials import get_pending_action, resolve_pending_action


def execute(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the approve command."""
    action = get_pending_action(args.action_id)

    if not action:
        terminal.error(f"No pending action found: {args.action_id}")
        terminal.info("Pending actions are created during investigations.")
        return 1

    if action.get("status") != "pending":
        terminal.error(f"Action already {action.get('status')}")
        return 1

    terminal.header(f"Approving Action: {args.action_id}")
    terminal.info(f"Description: {action.get('description')}")
    terminal.info(f"Command: {action.get('command')}")
    terminal.print()

    # Confirm execution
    if not terminal.confirm("Execute this action?"):
        terminal.info("Action cancelled")
        return 0

    terminal.print()
    terminal.info("Executing...")

    # Execute the command
    command = action.get("command")
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=300,  # 5 minute timeout
        )

        if result.returncode == 0:
            terminal.success("Action executed successfully")
            if result.stdout.strip():
                terminal.print()
                terminal.print(result.stdout.strip())

            resolve_pending_action(args.action_id, approved=True, result="success")
            return 0
        else:
            terminal.error("Action failed")
            if result.stderr.strip():
                terminal.print(result.stderr.strip())

            resolve_pending_action(args.action_id, approved=True, result=f"failed: {result.stderr}")
            return 1

    except subprocess.TimeoutExpired:
        terminal.error("Action timed out (5 minute limit)")
        resolve_pending_action(args.action_id, approved=True, result="timeout")
        return 1
    except Exception as e:
        terminal.error(f"Execution error: {e}")
        resolve_pending_action(args.action_id, approved=True, result=f"error: {e}")
        return 1


def execute_reject(args: argparse.Namespace, terminal: Terminal) -> int:
    """Execute the reject command."""
    action = get_pending_action(args.action_id)

    if not action:
        terminal.error(f"No pending action found: {args.action_id}")
        return 1

    if action.get("status") != "pending":
        terminal.error(f"Action already {action.get('status')}")
        return 1

    resolve_pending_action(args.action_id, approved=False, result="rejected by user")
    terminal.success(f"Action {args.action_id} rejected")

    return 0
