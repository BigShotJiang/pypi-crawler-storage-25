"""Knowledge broadcaster for sharing learned patterns.

Broadcasts high-confidence patterns to mesh peers.
"""

import struct
import hashlib
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import IntEnum
from typing import Optional, Callable, Any

from mesh.learning.bloom import BloomFilter
from mesh.learning.feedback import WeightDelta


class KnowledgeType(IntEnum):
    """Types of knowledge that can be broadcast."""
    PATTERN = 1       # A problem-solution pattern
    DELTA = 2         # A weight delta from learning
    EXPERIENCE = 3    # An investigation summary


@dataclass
class KnowledgePacket:
    """A packet of knowledge to broadcast through the mesh.

    Format:
    - header (16 bytes): Standard TNN message header
    - signature (32 bytes): TNN signature for verification
    - knowledge_type (1 byte)
    - version (4 bytes): Monotonic version for ordering
    - origin_id (8 bytes): Author's model_id
    - hop_count (1 byte): TTL for gossip
    - payload_len (4 bytes)
    - payload (variable): Compressed knowledge
    """
    knowledge_type: KnowledgeType
    version: int
    origin_id: bytes  # 8 bytes
    hop_count: int = 3  # Default TTL
    payload: bytes = b""
    signature: bytes = b""  # Filled by TNN signing
    timestamp: datetime = field(default_factory=datetime.now)

    def packet_hash(self) -> bytes:
        """Compute hash for deduplication."""
        content = (
            self.knowledge_type.to_bytes(1, 'big') +
            self.version.to_bytes(4, 'big') +
            self.origin_id +
            self.payload
        )
        return hashlib.sha256(content).digest()

    def to_bytes(self) -> bytes:
        """Serialize to bytes for transmission."""
        return (
            self.signature.ljust(32, b'\x00')[:32] +
            self.knowledge_type.to_bytes(1, 'big') +
            self.version.to_bytes(4, 'big') +
            self.origin_id.ljust(8, b'\x00')[:8] +
            self.hop_count.to_bytes(1, 'big') +
            len(self.payload).to_bytes(4, 'big') +
            self.payload
        )

    @classmethod
    def from_bytes(cls, data: bytes) -> "KnowledgePacket":
        """Deserialize from bytes."""
        signature = data[:32]
        knowledge_type = KnowledgeType(data[32])
        version = int.from_bytes(data[33:37], 'big')
        origin_id = data[37:45]
        hop_count = data[45]
        payload_len = int.from_bytes(data[46:50], 'big')
        payload = data[50:50 + payload_len]

        return cls(
            knowledge_type=knowledge_type,
            version=version,
            origin_id=origin_id,
            hop_count=hop_count,
            payload=payload,
            signature=signature,
        )


class KnowledgeBroadcaster:
    """Broadcasts learned knowledge to mesh peers.

    Flow:
    1. Agent learns a high-confidence pattern
    2. KnowledgeBroadcaster.broadcast_pattern() called
    3. Packet signed with TNN
    4. Sent to all connected peers
    5. Peers forward if hop_count > 0
    """

    # Minimum confidence to broadcast
    MIN_BROADCAST_CONFIDENCE = 0.7

    # Rate limiting
    MAX_BROADCASTS_PER_MINUTE = 10

    def __init__(
        self,
        model_id: bytes,
        sign_callback: Optional[Callable[[bytes], bytes]] = None,
        send_callback: Optional[Callable[[bytes], None]] = None,
    ):
        """Initialize the broadcaster.

        Args:
            model_id: This agent's 8-byte model identifier
            sign_callback: TNN signing function
            send_callback: Function to send packet to peers
        """
        self.model_id = model_id.ljust(8, b'\x00')[:8]
        self._sign = sign_callback
        self._send = send_callback

        # Version counter for ordering
        self._version_counter = int(time.time())

        # Rate limiting
        self._recent_broadcasts: list[float] = []

        # Deduplication - don't rebroadcast our own packets
        self._sent_hashes = BloomFilter(capacity=1000)

    def _next_version(self) -> int:
        """Get next monotonic version number."""
        self._version_counter += 1
        return self._version_counter

    def _rate_limit_ok(self) -> bool:
        """Check if we can broadcast (rate limiting)."""
        now = time.time()
        # Remove old entries
        self._recent_broadcasts = [
            t for t in self._recent_broadcasts
            if now - t < 60
        ]
        return len(self._recent_broadcasts) < self.MAX_BROADCASTS_PER_MINUTE

    def broadcast_delta(
        self,
        delta: WeightDelta,
        hop_count: int = 3,
    ) -> Optional[KnowledgePacket]:
        """Broadcast a weight delta to peers.

        Args:
            delta: The weight delta to broadcast
            hop_count: TTL for gossip

        Returns:
            KnowledgePacket if broadcast, None if rate limited
        """
        if not self._rate_limit_ok():
            return None

        if delta.confidence < self.MIN_BROADCAST_CONFIDENCE:
            return None

        packet = KnowledgePacket(
            knowledge_type=KnowledgeType.DELTA,
            version=self._next_version(),
            origin_id=self.model_id,
            hop_count=hop_count,
            payload=delta.to_bytes(),
        )

        return self._sign_and_send(packet)

    def broadcast_pattern(
        self,
        pattern_name: str,
        agent_type: str,
        detection_criteria: dict,
        recommended_actions: list[str],
        success_rate: float,
        hop_count: int = 3,
    ) -> Optional[KnowledgePacket]:
        """Broadcast a learned problem pattern.

        Args:
            pattern_name: Name of the pattern
            agent_type: Type of agent this applies to
            detection_criteria: JSON-encodable criteria
            recommended_actions: List of recommended actions
            success_rate: How often this pattern works
            hop_count: TTL for gossip

        Returns:
            KnowledgePacket if broadcast, None if rate limited
        """
        if not self._rate_limit_ok():
            return None

        if success_rate < self.MIN_BROADCAST_CONFIDENCE:
            return None

        import json
        payload = json.dumps({
            "pattern_name": pattern_name,
            "agent_type": agent_type,
            "detection_criteria": detection_criteria,
            "recommended_actions": recommended_actions,
            "success_rate": success_rate,
        }).encode('utf-8')

        packet = KnowledgePacket(
            knowledge_type=KnowledgeType.PATTERN,
            version=self._next_version(),
            origin_id=self.model_id,
            hop_count=hop_count,
            payload=payload,
        )

        return self._sign_and_send(packet)

    def broadcast_experience(
        self,
        investigation_summary: dict,
        hop_count: int = 2,  # Lower TTL for verbose data
    ) -> Optional[KnowledgePacket]:
        """Broadcast an investigation experience.

        Args:
            investigation_summary: Summary of the investigation
            hop_count: TTL for gossip

        Returns:
            KnowledgePacket if broadcast, None if rate limited
        """
        if not self._rate_limit_ok():
            return None

        import json
        payload = json.dumps(investigation_summary).encode('utf-8')

        # Limit payload size
        if len(payload) > 4096:
            return None

        packet = KnowledgePacket(
            knowledge_type=KnowledgeType.EXPERIENCE,
            version=self._next_version(),
            origin_id=self.model_id,
            hop_count=hop_count,
            payload=payload,
        )

        return self._sign_and_send(packet)

    def _sign_and_send(self, packet: KnowledgePacket) -> Optional[KnowledgePacket]:
        """Sign and send a packet."""
        # Check dedup
        packet_hash = packet.packet_hash()
        if not self._sent_hashes.add_if_new(packet_hash):
            return None  # Already sent

        # Sign if callback available
        if self._sign:
            data_to_sign = packet.to_bytes()[32:]  # Exclude signature field
            packet.signature = self._sign(data_to_sign)[:32]

        # Send if callback available
        if self._send:
            self._send(packet.to_bytes())
            self._recent_broadcasts.append(time.time())

        return packet

    def set_sign_callback(self, callback: Callable[[bytes], bytes]) -> None:
        """Set the TNN signing callback."""
        self._sign = callback

    def set_send_callback(self, callback: Callable[[bytes], None]) -> None:
        """Set the send callback."""
        self._send = callback

    def get_stats(self) -> dict:
        """Get broadcaster statistics."""
        return {
            "model_id": self.model_id.hex(),
            "current_version": self._version_counter,
            "recent_broadcasts": len(self._recent_broadcasts),
            "sent_hashes_count": self._sent_hashes.item_count,
        }
