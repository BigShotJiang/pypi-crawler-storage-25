"""Knowledge absorber for receiving broadcast patterns.

Receives and applies knowledge from mesh peers.
"""

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Callable

from mesh.learning.bloom import BloomFilter
from mesh.learning.broadcast import KnowledgePacket, KnowledgeType
from mesh.learning.feedback import WeightDelta, LearningFeedback


@dataclass
class TrustScore:
    """Trust score for a peer."""
    model_id: bytes
    score: float  # 0.0 to 1.0
    interactions: int
    successful_patterns: int
    failed_patterns: int
    last_updated: datetime


class KnowledgeAbsorber:
    """Receives and applies knowledge from mesh peers.

    Flow:
    1. Receive KnowledgePacket from peer
    2. Verify TNN signature
    3. Check bloom filter for duplicates
    4. Apply trust weighting
    5. Absorb the knowledge
    6. Forward if hop_count > 1
    """

    # Default trust for unknown peers
    DEFAULT_TRUST = 0.5

    # Minimum trust to accept knowledge
    MIN_TRUST_THRESHOLD = 0.2

    # Trust decay per failed pattern
    TRUST_DECAY = 0.1

    # Trust increase per successful pattern
    TRUST_INCREASE = 0.05

    def __init__(
        self,
        model_id: bytes,
        verify_callback: Optional[Callable[[bytes, bytes], bool]] = None,
        learning_feedback: Optional[LearningFeedback] = None,
        forward_callback: Optional[Callable[[bytes], None]] = None,
    ):
        """Initialize the absorber.

        Args:
            model_id: This agent's 8-byte model identifier
            verify_callback: TNN signature verification function
            learning_feedback: LearningFeedback instance for applying deltas
            forward_callback: Function to forward packets to other peers
        """
        self.model_id = model_id.ljust(8, b'\x00')[:8]
        self._verify = verify_callback
        self._learning_feedback = learning_feedback
        self._forward = forward_callback

        # Deduplication
        self._seen_hashes = BloomFilter(capacity=10000)

        # Peer trust scores
        self._trust_scores: dict[bytes, TrustScore] = {}

        # Absorbed knowledge for later verification
        self._absorbed_patterns: list[dict] = []
        self._absorbed_deltas: list[WeightDelta] = []

        # Callbacks for when knowledge is absorbed
        self._on_pattern_absorbed: Optional[Callable[[dict], None]] = None
        self._on_delta_absorbed: Optional[Callable[[WeightDelta], None]] = None

    def receive_packet(self, data: bytes) -> bool:
        """Receive and process a knowledge packet.

        Args:
            data: Raw packet bytes

        Returns:
            True if packet was processed, False if rejected
        """
        try:
            packet = KnowledgePacket.from_bytes(data)
        except Exception:
            return False

        # Don't process our own packets
        if packet.origin_id == self.model_id:
            return False

        # Check for duplicates
        packet_hash = packet.packet_hash()
        if not self._seen_hashes.add_if_new(packet_hash):
            return False

        # Verify signature
        if self._verify:
            data_to_verify = data[32:]  # Exclude signature
            if not self._verify(packet.signature, data_to_verify):
                return False

        # Get peer trust
        trust = self._get_trust(packet.origin_id)
        if trust < self.MIN_TRUST_THRESHOLD:
            return False

        # Process based on type
        absorbed = False
        if packet.knowledge_type == KnowledgeType.DELTA:
            absorbed = self._absorb_delta(packet, trust)
        elif packet.knowledge_type == KnowledgeType.PATTERN:
            absorbed = self._absorb_pattern(packet, trust)
        elif packet.knowledge_type == KnowledgeType.EXPERIENCE:
            absorbed = self._absorb_experience(packet, trust)

        # Forward if hop_count > 1
        if absorbed and packet.hop_count > 1 and self._forward:
            # Decrement hop count
            forwarded_packet = KnowledgePacket(
                knowledge_type=packet.knowledge_type,
                version=packet.version,
                origin_id=packet.origin_id,
                hop_count=packet.hop_count - 1,
                payload=packet.payload,
                signature=packet.signature,
            )
            self._forward(forwarded_packet.to_bytes())

        return absorbed

    def _absorb_delta(self, packet: KnowledgePacket, trust: float) -> bool:
        """Absorb a weight delta."""
        try:
            delta = WeightDelta.from_bytes(packet.payload)
        except Exception:
            return False

        # Scale delta by trust
        delta.delta *= trust
        delta.confidence *= trust

        # Apply to learning feedback
        if self._learning_feedback and self._learning_feedback._tnn_apply_delta:
            self._learning_feedback._tnn_apply_delta(delta.to_bytes())

        self._absorbed_deltas.append(delta)

        if self._on_delta_absorbed:
            self._on_delta_absorbed(delta)

        return True

    def _absorb_pattern(self, packet: KnowledgePacket, trust: float) -> bool:
        """Absorb a problem pattern."""
        try:
            pattern = json.loads(packet.payload.decode('utf-8'))
        except Exception:
            return False

        # Scale success rate by trust
        if "success_rate" in pattern:
            pattern["success_rate"] *= trust

        # Add origin info
        pattern["origin_id"] = packet.origin_id.hex()
        pattern["absorbed_at"] = datetime.now().isoformat()
        pattern["trust_score"] = trust

        self._absorbed_patterns.append(pattern)

        if self._on_pattern_absorbed:
            self._on_pattern_absorbed(pattern)

        return True

    def _absorb_experience(self, packet: KnowledgePacket, trust: float) -> bool:
        """Absorb an investigation experience."""
        try:
            experience = json.loads(packet.payload.decode('utf-8'))
        except Exception:
            return False

        # Store for reference (not actively used yet)
        experience["origin_id"] = packet.origin_id.hex()
        experience["trust_score"] = trust

        return True

    def _get_trust(self, peer_id: bytes) -> float:
        """Get trust score for a peer."""
        if peer_id in self._trust_scores:
            return self._trust_scores[peer_id].score
        return self.DEFAULT_TRUST

    def update_trust(
        self,
        peer_id: bytes,
        pattern_worked: bool,
    ) -> float:
        """Update trust score for a peer based on pattern outcome.

        Args:
            peer_id: The peer's model ID
            pattern_worked: Whether the pattern worked

        Returns:
            New trust score
        """
        if peer_id not in self._trust_scores:
            self._trust_scores[peer_id] = TrustScore(
                model_id=peer_id,
                score=self.DEFAULT_TRUST,
                interactions=0,
                successful_patterns=0,
                failed_patterns=0,
                last_updated=datetime.now(),
            )

        trust = self._trust_scores[peer_id]
        trust.interactions += 1
        trust.last_updated = datetime.now()

        if pattern_worked:
            trust.successful_patterns += 1
            trust.score = min(1.0, trust.score + self.TRUST_INCREASE)
        else:
            trust.failed_patterns += 1
            trust.score = max(0.0, trust.score - self.TRUST_DECAY)

        return trust.score

    def set_verify_callback(self, callback: Callable[[bytes, bytes], bool]) -> None:
        """Set the TNN verification callback."""
        self._verify = callback

    def set_forward_callback(self, callback: Callable[[bytes], None]) -> None:
        """Set the forward callback."""
        self._forward = callback

    def on_pattern_absorbed(self, callback: Callable[[dict], None]) -> None:
        """Set callback for when a pattern is absorbed."""
        self._on_pattern_absorbed = callback

    def on_delta_absorbed(self, callback: Callable[[WeightDelta], None]) -> None:
        """Set callback for when a delta is absorbed."""
        self._on_delta_absorbed = callback

    def get_absorbed_patterns(self) -> list[dict]:
        """Get all absorbed patterns."""
        return self._absorbed_patterns.copy()

    def get_trust_scores(self) -> dict[str, float]:
        """Get all peer trust scores."""
        return {
            peer_id.hex(): score.score
            for peer_id, score in self._trust_scores.items()
        }

    def get_stats(self) -> dict:
        """Get absorber statistics."""
        return {
            "model_id": self.model_id.hex(),
            "seen_packets": self._seen_hashes.item_count,
            "absorbed_patterns": len(self._absorbed_patterns),
            "absorbed_deltas": len(self._absorbed_deltas),
            "tracked_peers": len(self._trust_scores),
        }
