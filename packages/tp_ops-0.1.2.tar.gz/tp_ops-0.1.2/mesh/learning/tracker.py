"""Outcome tracker for monitoring fix results.

Watches for changes after a fix is applied to determine if it worked.
"""

import asyncio
import uuid
from datetime import datetime
from typing import Callable, Optional, Any
from dataclasses import dataclass, field

from mesh.learning.outcome import FixOutcome, OutcomeType


@dataclass
class TrackedFix:
    """A fix being tracked for outcome observation."""
    outcome: FixOutcome
    check_callback: Optional[Callable[[], dict]] = None  # Returns current metrics
    on_complete: Optional[Callable[[FixOutcome], None]] = None


class OutcomeTracker:
    """Tracks fix outcomes by observing system state over time.

    Usage:
        tracker = OutcomeTracker()

        # When a fix is applied
        outcome = tracker.track_fix(
            action_id="solution-123",
            agent_type="k8s-agent",
            resource_name="prod-cluster",
            problem_keywords=["crashloop", "oom"],
            fix_type="scale",
            fix_command="kubectl scale deployment/api --replicas=3",
            check_callback=lambda: {"pod_restarts": get_restart_count()},
        )

        # Later, observe the outcome
        tracker.observe_outcome(outcome.outcome_id, new_metrics)
    """

    DEFAULT_OBSERVATION_WINDOW = 300  # 5 minutes

    def __init__(self):
        self.tracked_fixes: dict[str, TrackedFix] = {}
        self._observation_tasks: dict[str, asyncio.Task] = {}

    def track_fix(
        self,
        action_id: str,
        agent_type: str,
        resource_name: str,
        problem_keywords: list[str],
        fix_type: str,
        fix_command: Optional[str] = None,
        metrics_before: Optional[dict] = None,
        check_callback: Optional[Callable[[], dict]] = None,
        on_complete: Optional[Callable[[FixOutcome], None]] = None,
        observation_window_sec: int = DEFAULT_OBSERVATION_WINDOW,
    ) -> FixOutcome:
        """Start tracking a fix that was just applied.

        Args:
            action_id: ID of the solution/action being tracked
            agent_type: Type of agent that applied the fix
            resource_name: Name of the resource being fixed
            problem_keywords: Keywords describing the problem
            fix_type: Type of fix (e.g., "restart", "scale")
            fix_command: The actual command run (if any)
            metrics_before: Metrics captured before the fix
            check_callback: Function to call to get current metrics
            on_complete: Callback when observation is complete
            observation_window_sec: How long to observe

        Returns:
            FixOutcome object for this fix
        """
        outcome = FixOutcome(
            outcome_id=str(uuid.uuid4()),
            action_id=action_id,
            agent_type=agent_type,
            resource_name=resource_name,
            problem_keywords=problem_keywords,
            fix_type=fix_type,
            fix_command=fix_command,
            metrics_before=metrics_before or {},
            observation_window_sec=observation_window_sec,
        )

        # Compute signatures
        outcome.problem_signature = outcome.compute_problem_signature()
        outcome.fix_signature = outcome.compute_fix_signature()

        # Store tracked fix
        self.tracked_fixes[outcome.outcome_id] = TrackedFix(
            outcome=outcome,
            check_callback=check_callback,
            on_complete=on_complete,
        )

        return outcome

    def observe_outcome(
        self,
        outcome_id: str,
        metrics_after: Optional[dict] = None,
        outcome_type: Optional[OutcomeType] = None,
    ) -> Optional[FixOutcome]:
        """Record the observed outcome of a fix.

        Args:
            outcome_id: ID of the outcome to update
            metrics_after: Metrics captured after observation window
            outcome_type: Override the outcome type (if known)

        Returns:
            Updated FixOutcome or None if not found
        """
        tracked = self.tracked_fixes.get(outcome_id)
        if not tracked:
            return None

        outcome = tracked.outcome

        # Update metrics
        if metrics_after:
            outcome.metrics_after = metrics_after

        # Determine outcome
        if outcome_type:
            outcome.outcome = outcome_type
        else:
            outcome.outcome = self._determine_outcome(outcome)

        outcome.outcome_observed_at = datetime.now()
        outcome.confidence = self._calculate_confidence(outcome)

        # Trigger callback
        if tracked.on_complete:
            tracked.on_complete(outcome)

        return outcome

    def _determine_outcome(self, outcome: FixOutcome) -> OutcomeType:
        """Determine the outcome based on before/after metrics.

        This is a simple heuristic - specific agents can override
        with domain-specific logic.
        """
        before = outcome.metrics_before
        after = outcome.metrics_after

        if not before or not after:
            return OutcomeType.PENDING

        # Look for common improvement indicators
        improvements = 0
        regressions = 0

        # Check for error/restart counts
        for key in ["errors", "restarts", "failures", "crash_count", "pod_restarts"]:
            if key in before and key in after:
                if after[key] < before[key]:
                    improvements += 1
                elif after[key] > before[key]:
                    regressions += 1

        # Check for health indicators
        for key in ["healthy", "ready", "available", "success_rate"]:
            if key in before and key in after:
                if after[key] > before[key]:
                    improvements += 1
                elif after[key] < before[key]:
                    regressions += 1

        # Determine overall outcome
        if regressions > improvements:
            return OutcomeType.REGRESSION
        elif improvements > 0 and regressions == 0:
            return OutcomeType.SUCCESS
        elif improvements > 0:
            return OutcomeType.PARTIAL
        else:
            return OutcomeType.FAILURE

    def _calculate_confidence(self, outcome: FixOutcome) -> float:
        """Calculate confidence in the outcome determination."""
        # More metrics = more confidence
        metric_count = len(outcome.metrics_before) + len(outcome.metrics_after)

        if metric_count == 0:
            return 0.1

        # Base confidence on metric availability
        confidence = min(1.0, metric_count / 10)

        # Higher confidence if observation window completed
        if outcome.is_observation_complete():
            confidence = min(1.0, confidence + 0.2)

        return confidence

    def get_pending_outcomes(self) -> list[FixOutcome]:
        """Get all outcomes still pending observation."""
        return [
            tracked.outcome
            for tracked in self.tracked_fixes.values()
            if tracked.outcome.outcome == OutcomeType.PENDING
        ]

    def get_ready_for_observation(self) -> list[FixOutcome]:
        """Get outcomes whose observation window has passed."""
        return [
            tracked.outcome
            for tracked in self.tracked_fixes.values()
            if tracked.outcome.is_observation_complete()
            and tracked.outcome.outcome == OutcomeType.PENDING
        ]

    def cleanup_completed(self, max_age_sec: int = 3600) -> int:
        """Remove old completed outcomes from tracking.

        Returns:
            Number of outcomes cleaned up
        """
        now = datetime.now()
        to_remove = []

        for outcome_id, tracked in self.tracked_fixes.items():
            outcome = tracked.outcome
            if outcome.outcome != OutcomeType.PENDING:
                if outcome.outcome_observed_at:
                    age = (now - outcome.outcome_observed_at).total_seconds()
                    if age > max_age_sec:
                        to_remove.append(outcome_id)

        for outcome_id in to_remove:
            del self.tracked_fixes[outcome_id]

        return len(to_remove)
