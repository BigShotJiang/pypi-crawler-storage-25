"""Outcome tracking schema for fix results.

Defines the data structures for tracking whether fixes work.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional
import hashlib


class OutcomeType(Enum):
    """The result of applying a fix."""
    SUCCESS = "success"        # Problem resolved
    PARTIAL = "partial"        # Problem improved but not fully resolved
    FAILURE = "failure"        # Fix didn't help
    REGRESSION = "regression"  # Fix made things worse
    PENDING = "pending"        # Waiting for observation


class RewardSignal(Enum):
    """Reward values for TNN weight updates."""
    SUCCESS = 1.0
    PARTIAL = 0.3
    FAILURE = -0.5
    REGRESSION = -1.0

    @classmethod
    def from_outcome(cls, outcome: OutcomeType) -> float:
        """Convert outcome type to reward signal value."""
        mapping = {
            OutcomeType.SUCCESS: cls.SUCCESS.value,
            OutcomeType.PARTIAL: cls.PARTIAL.value,
            OutcomeType.FAILURE: cls.FAILURE.value,
            OutcomeType.REGRESSION: cls.REGRESSION.value,
            OutcomeType.PENDING: 0.0,
        }
        return mapping.get(outcome, 0.0)


@dataclass
class FixOutcome:
    """Record of a fix and its outcome."""
    outcome_id: str = ""
    action_id: str = ""  # Links to Solution.id in knowledge store

    # Problem identification
    problem_signature: bytes = field(default_factory=bytes)  # TNN hash
    problem_keywords: list[str] = field(default_factory=list)
    agent_type: str = ""
    resource_name: str = ""

    # Fix identification
    fix_signature: bytes = field(default_factory=bytes)  # TNN hash
    fix_type: str = ""  # e.g., "restart", "scale", "config_change"
    fix_command: Optional[str] = None

    # Outcome
    outcome: OutcomeType = OutcomeType.PENDING
    confidence: float = 0.0  # How confident we are in the outcome

    # Timing
    fix_applied_at: datetime = field(default_factory=datetime.now)
    outcome_observed_at: Optional[datetime] = None
    observation_window_sec: int = 300  # 5 minutes default

    # Metrics before and after (for comparison)
    metrics_before: dict = field(default_factory=dict)
    metrics_after: dict = field(default_factory=dict)

    def compute_problem_signature(self) -> bytes:
        """Compute TNN-compatible hash of the problem."""
        content = f"{self.agent_type}:{','.join(sorted(self.problem_keywords))}"
        return hashlib.sha256(content.encode()).digest()[:16]

    def compute_fix_signature(self) -> bytes:
        """Compute TNN-compatible hash of the fix."""
        content = f"{self.fix_type}:{self.fix_command or ''}"
        return hashlib.sha256(content.encode()).digest()[:16]

    def get_reward(self) -> float:
        """Get the reward signal for this outcome."""
        return RewardSignal.from_outcome(self.outcome)

    def is_observation_complete(self) -> bool:
        """Check if the observation window has passed."""
        if self.outcome != OutcomeType.PENDING:
            return True
        elapsed = (datetime.now() - self.fix_applied_at).total_seconds()
        return elapsed >= self.observation_window_sec

    def to_dict(self) -> dict:
        return {
            "outcome_id": self.outcome_id,
            "action_id": self.action_id,
            "problem_signature": self.problem_signature.hex(),
            "problem_keywords": self.problem_keywords,
            "agent_type": self.agent_type,
            "resource_name": self.resource_name,
            "fix_signature": self.fix_signature.hex(),
            "fix_type": self.fix_type,
            "fix_command": self.fix_command,
            "outcome": self.outcome.value,
            "confidence": self.confidence,
            "fix_applied_at": self.fix_applied_at.isoformat(),
            "outcome_observed_at": self.outcome_observed_at.isoformat() if self.outcome_observed_at else None,
            "observation_window_sec": self.observation_window_sec,
            "metrics_before": self.metrics_before,
            "metrics_after": self.metrics_after,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "FixOutcome":
        data = data.copy()
        if isinstance(data.get("problem_signature"), str):
            data["problem_signature"] = bytes.fromhex(data["problem_signature"])
        if isinstance(data.get("fix_signature"), str):
            data["fix_signature"] = bytes.fromhex(data["fix_signature"])
        if isinstance(data.get("outcome"), str):
            data["outcome"] = OutcomeType(data["outcome"])
        if isinstance(data.get("fix_applied_at"), str):
            data["fix_applied_at"] = datetime.fromisoformat(data["fix_applied_at"])
        if isinstance(data.get("outcome_observed_at"), str):
            data["outcome_observed_at"] = datetime.fromisoformat(data["outcome_observed_at"])
        return cls(**data)
