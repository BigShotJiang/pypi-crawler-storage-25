"""Bloom filter for knowledge broadcast deduplication.

Prevents agents from processing the same broadcast multiple times.
"""

import hashlib
import math
from typing import Optional


class BloomFilter:
    """Space-efficient probabilistic set for deduplication.

    Used to track which knowledge broadcasts have been seen,
    preventing redundant processing during mesh gossip.

    Default configuration:
    - Capacity: 10,000 items
    - False positive rate: 1%
    - Size: ~12KB
    """

    def __init__(
        self,
        capacity: int = 10000,
        false_positive_rate: float = 0.01,
    ):
        """Initialize the bloom filter.

        Args:
            capacity: Expected number of items
            false_positive_rate: Acceptable false positive rate (0-1)
        """
        self.capacity = capacity
        self.fp_rate = false_positive_rate

        # Calculate optimal size and hash count
        # m = -n * ln(p) / (ln(2)^2)
        # k = (m / n) * ln(2)
        self.size = self._optimal_size(capacity, false_positive_rate)
        self.hash_count = self._optimal_hash_count(self.size, capacity)

        # Initialize bit array (using bytearray for efficiency)
        self.bit_array = bytearray(math.ceil(self.size / 8))
        self.item_count = 0

    def _optimal_size(self, n: int, p: float) -> int:
        """Calculate optimal bit array size."""
        m = -n * math.log(p) / (math.log(2) ** 2)
        return int(math.ceil(m))

    def _optimal_hash_count(self, m: int, n: int) -> int:
        """Calculate optimal number of hash functions."""
        k = (m / n) * math.log(2)
        return max(1, int(math.ceil(k)))

    def _hashes(self, item: bytes) -> list[int]:
        """Generate hash values for an item.

        Uses double hashing technique:
        h(i) = (h1 + i * h2) mod m
        """
        # Use SHA-256 to generate two independent hashes
        h = hashlib.sha256(item).digest()
        h1 = int.from_bytes(h[:8], 'big')
        h2 = int.from_bytes(h[8:16], 'big')

        return [(h1 + i * h2) % self.size for i in range(self.hash_count)]

    def _get_bit(self, index: int) -> bool:
        """Get the value of a bit."""
        byte_index = index // 8
        bit_index = index % 8
        return bool(self.bit_array[byte_index] & (1 << bit_index))

    def _set_bit(self, index: int) -> None:
        """Set a bit to 1."""
        byte_index = index // 8
        bit_index = index % 8
        self.bit_array[byte_index] |= (1 << bit_index)

    def add(self, item: bytes) -> None:
        """Add an item to the filter."""
        for index in self._hashes(item):
            self._set_bit(index)
        self.item_count += 1

    def add_str(self, item: str) -> None:
        """Add a string item to the filter."""
        self.add(item.encode('utf-8'))

    def contains(self, item: bytes) -> bool:
        """Check if an item might be in the filter.

        Returns:
            True if item might be in set (possible false positive)
            False if item is definitely not in set
        """
        return all(self._get_bit(index) for index in self._hashes(item))

    def contains_str(self, item: str) -> bool:
        """Check if a string item might be in the filter."""
        return self.contains(item.encode('utf-8'))

    def add_if_new(self, item: bytes) -> bool:
        """Add item if not already present.

        Returns:
            True if item was new (added)
            False if item was already present
        """
        if self.contains(item):
            return False
        self.add(item)
        return True

    def clear(self) -> None:
        """Clear the filter."""
        self.bit_array = bytearray(math.ceil(self.size / 8))
        self.item_count = 0

    def estimated_fill_ratio(self) -> float:
        """Estimate the fill ratio of the filter."""
        # Count set bits
        set_bits = sum(bin(byte).count('1') for byte in self.bit_array)
        return set_bits / self.size

    def estimated_false_positive_rate(self) -> float:
        """Estimate the current false positive rate."""
        fill = self.estimated_fill_ratio()
        return fill ** self.hash_count

    def merge(self, other: "BloomFilter") -> None:
        """Merge another bloom filter into this one.

        Both filters must have the same size.
        """
        if self.size != other.size:
            raise ValueError("Cannot merge filters of different sizes")

        for i in range(len(self.bit_array)):
            self.bit_array[i] |= other.bit_array[i]

        self.item_count += other.item_count

    def to_bytes(self) -> bytes:
        """Serialize the filter to bytes."""
        # Header: size(4) + hash_count(4) + item_count(4)
        header = (
            self.size.to_bytes(4, 'big') +
            self.hash_count.to_bytes(4, 'big') +
            self.item_count.to_bytes(4, 'big')
        )
        return header + bytes(self.bit_array)

    @classmethod
    def from_bytes(cls, data: bytes) -> "BloomFilter":
        """Deserialize a filter from bytes."""
        size = int.from_bytes(data[:4], 'big')
        hash_count = int.from_bytes(data[4:8], 'big')
        item_count = int.from_bytes(data[8:12], 'big')

        # Create filter with matching parameters
        filter = cls.__new__(cls)
        filter.size = size
        filter.hash_count = hash_count
        filter.item_count = item_count
        filter.capacity = 10000  # Approximate
        filter.fp_rate = 0.01
        filter.bit_array = bytearray(data[12:])

        return filter

    def get_stats(self) -> dict:
        """Get filter statistics."""
        return {
            "capacity": self.capacity,
            "size_bits": self.size,
            "size_bytes": len(self.bit_array),
            "hash_count": self.hash_count,
            "item_count": self.item_count,
            "fill_ratio": self.estimated_fill_ratio(),
            "estimated_fp_rate": self.estimated_false_positive_rate(),
        }
