"""Learning feedback system for TNN weight updates.

Processes fix outcomes and applies updates to TNN weights.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Callable
import struct

from mesh.learning.outcome import FixOutcome, OutcomeType, RewardSignal


@dataclass
class WeightDelta:
    """A weight update to apply to the TNN."""
    problem_signature: bytes  # 16 bytes
    fix_signature: bytes      # 16 bytes
    delta: float              # Reward signal (-1.0 to +1.0)
    confidence: float         # Weight of this update
    timestamp: datetime

    def to_bytes(self) -> bytes:
        """Serialize to bytes for TNN processing."""
        # Format: problem_sig(16) + fix_sig(16) + delta(4) + confidence(4)
        return (
            self.problem_signature[:16].ljust(16, b'\x00') +
            self.fix_signature[:16].ljust(16, b'\x00') +
            struct.pack('f', self.delta) +
            struct.pack('f', self.confidence)
        )

    @classmethod
    def from_bytes(cls, data: bytes) -> "WeightDelta":
        """Deserialize from bytes."""
        problem_sig = data[:16]
        fix_sig = data[16:32]
        delta = struct.unpack('f', data[32:36])[0]
        confidence = struct.unpack('f', data[36:40])[0]
        return cls(
            problem_signature=problem_sig,
            fix_signature=fix_sig,
            delta=delta,
            confidence=confidence,
            timestamp=datetime.now(),
        )


class LearningFeedback:
    """Processes outcomes and generates TNN weight updates.

    The feedback loop:
    1. Fix is applied → OutcomeTracker records it
    2. Observation window passes → outcome determined
    3. LearningFeedback.process_outcome() called
    4. WeightDelta generated and applied to TNN
    """

    # Minimum confidence to apply update
    MIN_CONFIDENCE_THRESHOLD = 0.3

    # Learning rate (scales the delta)
    LEARNING_RATE = 0.1

    def __init__(
        self,
        tnn_apply_delta: Optional[Callable[[bytes], bool]] = None,
    ):
        """Initialize the learning feedback system.

        Args:
            tnn_apply_delta: Callback to apply delta to TNN weights.
                            Takes serialized WeightDelta bytes.
        """
        self._tnn_apply_delta = tnn_apply_delta
        self._pending_deltas: list[WeightDelta] = []
        self._applied_deltas: list[WeightDelta] = []

    def process_outcome(self, outcome: FixOutcome) -> Optional[WeightDelta]:
        """Process a fix outcome and generate weight delta.

        Args:
            outcome: The completed FixOutcome

        Returns:
            WeightDelta if update was generated, None otherwise
        """
        # Skip pending outcomes
        if outcome.outcome == OutcomeType.PENDING:
            return None

        # Skip low-confidence outcomes
        if outcome.confidence < self.MIN_CONFIDENCE_THRESHOLD:
            return None

        # Generate weight delta
        raw_delta = outcome.get_reward()
        scaled_delta = raw_delta * self.LEARNING_RATE

        delta = WeightDelta(
            problem_signature=outcome.problem_signature,
            fix_signature=outcome.fix_signature,
            delta=scaled_delta,
            confidence=outcome.confidence,
            timestamp=datetime.now(),
        )

        # Apply to TNN if callback available
        if self._tnn_apply_delta:
            success = self._tnn_apply_delta(delta.to_bytes())
            if success:
                self._applied_deltas.append(delta)
        else:
            # Queue for later application
            self._pending_deltas.append(delta)

        return delta

    def set_tnn_callback(self, callback: Callable[[bytes], bool]) -> None:
        """Set the TNN apply delta callback.

        Also applies any pending deltas.
        """
        self._tnn_apply_delta = callback

        # Apply pending deltas
        for delta in self._pending_deltas:
            if callback(delta.to_bytes()):
                self._applied_deltas.append(delta)

        self._pending_deltas.clear()

    def get_pending_deltas(self) -> list[WeightDelta]:
        """Get deltas waiting to be applied."""
        return self._pending_deltas.copy()

    def get_applied_deltas(self) -> list[WeightDelta]:
        """Get deltas that have been applied."""
        return self._applied_deltas.copy()

    def get_stats(self) -> dict:
        """Get learning statistics."""
        return {
            "pending_deltas": len(self._pending_deltas),
            "applied_deltas": len(self._applied_deltas),
            "total_positive_updates": sum(
                1 for d in self._applied_deltas if d.delta > 0
            ),
            "total_negative_updates": sum(
                1 for d in self._applied_deltas if d.delta < 0
            ),
        }


# =============================================================================
# TNN Weight Update Functions (to be called from C)
# =============================================================================

def compute_outcome_delta(
    problem_sig: bytes,
    fix_sig: bytes,
    outcome_value: int,
    confidence: float,
) -> bytes:
    """Compute a weight delta for TNN.

    This function can be called from the C runtime to generate
    weight updates based on fix outcomes.

    Args:
        problem_sig: 16-byte problem signature
        fix_sig: 16-byte fix signature
        outcome_value: 0=failure, 1=partial, 2=success, 3=regression
        confidence: 0.0 to 1.0

    Returns:
        40-byte serialized WeightDelta
    """
    outcome_map = {
        0: OutcomeType.FAILURE,
        1: OutcomeType.PARTIAL,
        2: OutcomeType.SUCCESS,
        3: OutcomeType.REGRESSION,
    }
    outcome_type = outcome_map.get(outcome_value, OutcomeType.FAILURE)
    reward = RewardSignal.from_outcome(outcome_type)

    delta = WeightDelta(
        problem_signature=problem_sig,
        fix_signature=fix_sig,
        delta=reward * 0.1,  # Apply learning rate
        confidence=confidence,
        timestamp=datetime.now(),
    )

    return delta.to_bytes()
